jQuery(document).ready(function($){
	
	/*
	*	Author - Darie Demis
	*	Change language
	*/
	var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},_utf8_encode:function(e){e=e.replace(/rn/g,"n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t},_utf8_decode:function(e){var t="";var n=0;var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}}	
	$('.lang').on('change', function(){
		$('.lang-form').submit();
	});

	/*
	*	Author - Darie Demis
	*	Delete token
	*/

	$(document).on('click', '.delete_token', function(events){
		if ( $('.language-switcher').val() == "English" ) {
			$message = "Are you sure you want to delete the token?"
		} else { 
			$message = "Ești sigur că vrei să ștergi token-ul?"; 
		}
		if (confirm($message)) {
			window.location.href = $(this).attr("data-href");
		}
	});

	// change period for graphic
	$('.date-picker').datepicker( {
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,
        dateFormat: 'MM yy',
        yearRange: "1900:c",
        maxDate: "dateToday",
        closeText : "Ok",
        onClose: function(dateText, inst) { 
            $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
        }
    });

	// get data from database for graphic
	function callAjax(){
		perioada = $.cookie('period');
		var csrf = $.cookie('svs_csrf_cookie');
		$.ajax({
			url:"/diabet/dateGrafic" + uri_params,
			data: {
				'period': perioada,
				'svs_token': csrf
			},
			type: "POST",
			dataType: 'json',
			complete: function(data){
				data.responseText = data.responseText.replace(String.fromCharCode(65279), "" );
				data = JSON.parse(data.responseText);
				addGrafice(data);
			}
		});
	}

	// format values for graphic
	function addGrafice(datagrafice){
		var values = [];
		var nuafisa = true;
		$.each(datagrafice, function(key, element){
			var array = $.map(element, function(value, index) {
				if (key == 0){
					return [value];
				}
				if (index == 'date'){
					var tempDate = new Date(value);
					// value = new Date (tempDate.getUTCFullYear(), tempDate.getUTCMonth(), tempDate.getUTCDate());
				} else if(!isNaN(parseInt(value))){
					value = parseInt(value);
					nuafisa = false;
				}	
			    return [value];
			});
			values.push(array);
		}); 
		if ( nuafisa === false ) {
			drawChart(values);
		} else{ 
			$('#chart_div').css("display", "none"); 
			$('.grafic_user_id').css("display", "none"); 
			$('.btns_export').css("display", "none");  
			$('.row.trenlines').css("display", "none");
			$('#no_data_period').css("display", "block");
		}
	}

	// charge data for grahic
	function drawChart(values) {
        diabet_chart_data = google.visualization.arrayToDataTable(values);

        var trendlines = {};
        var series = {};
        var cookieTrendlines = {};
        try {
        	var cookieTrendlines = JSON.parse($.cookie("trendlines"));
        } catch (e){}
    	for (var i = 0; i < 10; i++){
    		if (i in cookieTrendlines){
    			$("input[name='trendlines'][value='" + i + "']").prop("checked", true);
    			trendlines[i] = {
        	      type: 'linear',
        	      lineWidth: 2,
        	      tooltip: false
	        	}
    		}
    	}
    	for (var i = 10; i < 12; i++){
    		if (i in cookieTrendlines){
    			$("input[name='trendlines'][value='" + i + "']").prop("checked", true);
    			series[i] = {
					type: "line",
					color: 'red',
					visibleInLegend: false
				}
    		} else {
				series[i] = {
					type: "line",
					color: 'transparent',
					visibleInLegend: false
				}	
			}	
    	}

        
        if (diabet_chart_data.getNumberOfRows() <= 3){
        	var chartAreaLeft = "6%"	;
        	var chartAreaWidth = "75%";
        } else if (diabet_chart_data.getNumberOfRows() <= 5){
        	var chartAreaLeft = "4%"	;
        	var chartAreaWidth = "83%";
        } else if (diabet_chart_data.getNumberOfRows() <= 7){
        	var chartAreaLeft = "3%"	;
        	var chartAreaWidth = "88%";
        } else {
        	var chartAreaLeft = "2.5%"	;
        	var chartAreaWidth = "91%";
        }
    	
        
        var options = {
            vAxis: {
            	viewWindowMode:'explicit',
            	format: '# mg/dL',
            	viewWindow: {
                    min: 0.987654321,
                    max: 700
                }
	        },
	        hAxis: {
	            format: 'dd-MM-yyyy'
	            ,viewWindow: {
	            	min: 1
	            }
	        },
	        bars: 'vertical',
			chartArea: {
				left: chartAreaLeft,
				width: chartAreaWidth, 
				top: "0",
				bottom: "8%",
			},
			bar: {groupWidth: "80%"},
	        width: diabet_chart_data.getNumberOfRows() * 800,
	        height: 450,
	        trendlines: trendlines,
            seriesType: "bars",
			series: series,
			enableInteractivity: false
	    };

        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
		google.visualization.events.addListener(chart, 'ready', AddNamespaceHandler);
		chart.draw(diabet_chart_data, options);
    }

    // horizontal scroll graphic view
	function AddNamespaceHandler(){
		var svg = $('#chart_div svg');
		svg.attr("xmlns", "http://www.w3.org/2000/svg");
		svg.css('overflow','visible');
		$("#chart_div svg > g:first-of-type g > rect").on("click", function(){
			console.log('da');
			if(typeof svs_path_color !== 'undefined'){
				if (svs_path_color == $(this).attr("fill")){
					$("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] rect").removeAttr("fill-opacity");	
					delete svs_path_color;
				} else {
					$("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] rect").removeAttr("fill-opacity");	
					svs_path_color = $(this).attr("fill");				
					$("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] rect[fill!='" + svs_path_color + "']").attr("fill-opacity", "0.2");		
				}
		
			} else {
				svs_path_color = $(this).attr("fill");				
				$("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] rect[fill!='" + svs_path_color + "']").attr("fill-opacity", "0.2");	
			}
				
		})


		// !!! DO NOT REMOVE
		
		// $("#chart_div svg rect").on('mouseleave', function () {
		// 	if (typeof svs_path_color == 'undefined'){
		// 		return;
		//   	}
		//   	$("#chart_div svg rect").removeAttr("fill-opacity");
		//   	$("#chart_div svg rect[fill!='" + svs_path_color +  "']").attr("fill-opacity", "0.2");
		//   	$("#chart_div svg rect[fill='" + svs_path_color +  "']").next().attr("fill-opacity", "0");
		// });	

		// !!! DO NOT REMOVE


		$("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] g:nth-of-type(2) rect").on("mouseenter", function(e){
			var logicalName = $(this).prop("logicalname");
			var column = parseInt(logicalName.substr(logicalName.lastIndexOf("#") + 1));
			var row = parseInt($(this).prop("logicalname").substr(4, 1));
			var date = diabet_chart_data.Lf[column].c[0].v;
			var interval = diabet_chart_data.Kf[row+1].label;
			var value = diabet_chart_data.Lf[column].c[row+1].v;

			// display tooltip for graphic
			var position = $(this).position();
			var left =  $(this).offset().left - $(this).width();
			var top = $(this).offset().top - $('#graphic_tooltip').height() - $(this).height() - 20;
			$('#grapchic_date').text(date);
			$('#graphic_interval').text(interval);
			$('#bar_value').text(value);
			$('#graphic_tooltip').css({"top":top, "left":left, "display":"block"});

			$(this).attr("stroke", "#777");
			$(this).attr("stroke-width", 4);
		})

		$("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] g:nth-of-type(2) rect").on("mouseleave", function(){
			$(this).attr("stroke", "none");
			$(this).attr("stroke-width", 0);

			// hide tooltip
			$("#graphic_tooltip").css("display", "none");
		})

		redesenareGrafic();
	}

	function redesenareGrafic(){
	 	var barList = $("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] g:nth-of-type(2) rect").sort(function (a, b) {
			var contentA = parseInt( $(a).attr('x'));
			var contentB = parseInt( $(b).attr('x'));
			return (contentA < contentB) ? -1 : (contentA > contentB) ? 1 : 0;
		})
		var labelList = $("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)']").next().next().find("text[text-anchor!='end']");
		var deplasare = 0;
		$.each(barList, function(index, value){
			if ($(value).attr("height") == "0.5"){
				var numarBara = parseInt($(this).prop('logicalname').substr(6));
				deplasare = deplasare + parseInt($(value).attr("width"));
				for (var i = numarBara - 1; i < labelList.length; i++){
					if (i !== numarBara - 1){
						ajustare = 2
					} else {
						ajustare = 1;
					};
					$(labelList[i]).attr("x", parseInt($(labelList[i]).attr("x")) - parseInt($(value).attr("width")) / 2 * ajustare );
				}
				$(value).remove();
			} if (parseInt($(value).attr("x")) < 35) {
				$(value).remove();
			} else {
				$(value).attr("x", $(value).attr("x") - deplasare );
			}
		})
		$.each($("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] g:nth-of-type(1) rect"), function(index, value){
			$(this).attr("width", parseInt($(this).attr("width")) - deplasare);
		})
		$.each($("#chart_div svg path"), function(index, value){
			var path = $(this).attr("d");
			var pathWidth = $("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] g:nth-of-type(1) rect").attr("width");
			var xCoordStart = $("#chart_div svg g[clip-path='url(" + window.location.origin + "/diabet/dateDiabet#_ABSTRACT_RENDERER_ID_0)'] g:nth-of-type(1) rect").attr("x");
			var yCoord = path.substr(path.indexOf(",") + 1 , path.indexOf("L") - path.indexOf(",") - 1); 
			$(this).attr("d", "M" + xCoordStart + "," + yCoord + "L" + (parseInt(pathWidth) + parseInt(xCoordStart)) + "," + yCoord);
		})
		$.each($("#chart_div svg > g:nth-of-type(1) rect, svg > g:nth-of-type(1) text"), function(index, value){
			$(this).attr("x", parseInt($(this).attr("x")) - deplasare);
		});
		$("#chart_div div[dir='ltr'], #chart_div svg").css("width", parseInt($("#chart_div svg").width()) - deplasare - 100);
		$("#chart_div svg").attr("width", parseInt($("#chart_div svg").attr("width")) - deplasare - 100);

		$("#chart_div svg > g:nth-of-type(2) > rect").attr("width", parseInt($("#chart_div svg > g:nth-of-type(2) > rect").attr("width")) - deplasare - 100);
		
	 }

	// load graphic on page
	if ( $('.graphic_glucose').length != 0 ) {
		google.charts.load("current", {'packages':['corechart', 'bar']});
		google.charts.setOnLoadCallback(callAjax);
	}

	// change data graphic
	$('.select_period').on('change', function() {
	  	$('#no_data_period').css("display", "none");
	  	$('#chart_div').css("display", "block"); 
	  	$('.grafic_user_id').css("display", "block"); 
	  	$('.btns_export').css("display", "block");
	  	perioada = $.cookie('period', $(this).val());
	  	location.reload();
	});


	// change icon plus or minus for toogle
	$('#accordion .panel-default').on('click', function () {
	    $('#accordion .panel-collapse').collapse('hide');
	    $('#accordion .fa-minus').removeClass('fa-minus').addClass('fa-plus');
	});

	$('#accordion').on('shown.bs.collapse', function () {
  
	  var panel = $(this).find('.in').prev('.panel-heading');
	  var icon = panel.find('.fa.fa-plus').removeClass('fa-plus').addClass('fa-minus');
	  
	  $('html, body').animate({
	        scrollTop: panel.offset().top
	  }, 500);
	  
	});

	// Tiny Editor
	if ( $('#editor').length != 0 ) {
		$('#editor').wysiwyg();
  		$('#editor').cleanHtml();
  	}

  	// Save post 
	$('.save_post').on('click', function(){
		var title = $('#title_post').val();
		var textarea = $('#editor').html();
		var post_id = $('#post_id').val();
		if( $('#featured_post').is(':checked') ) {
			var featured = 1;
		} else {
			var featured = 0;
		}
		if (!title || !textarea || textarea == "<br>" ) {
			$('.error_empty_fields').show();
		} else {
			$('.error_empty_fields').hide();
			$.ajax({
				url:"/diabet/salvarePost",
				type: "POST",
				data: {
					'title': title,
					'featured': featured,
					'textarea': textarea,
					'post_id':post_id
				},
				success: function(){
					var url = window.location.origin + "/diabet/listPosts";
					window.location.href = url;
				}
			});
		}
	});

	/*
	*	Author - Darie Demis
	*	Delete post
	*/

	$(document).on('click', '.delete_post', function(events){
		if ( $('.language-switcher').val() == "English" ) {
			$message = "Are you sure you want to delete the post?"
		} else { 
			$message = "Ești sigur că vrei să ștergi articolul?"; 
		}
		if (confirm($message)) {
			window.location.href = $(this).attr("data-href");
		}
	});

	/*
	*	Author - Darie Demis
	*	Exit post without save
	*/

	$(document).on('click', '.close_post_btn', function(events){
		if ( $('.language-switcher').val() == "English" ) {
			$message = "Your data will be lost. Are you sure you want to exit without save?"
		} else { 
			$message = "Datele dumneavoastră vor fi șterse. Ești sigur că vrei să ieși fără să salvezi articolul?"; 
		}
		if (confirm($message)) {
			window.location.href = $(this).attr("data-href");
		}
	});

	// Save post 
	$('#btn-promotion').on('click', function(){
		if ( $(this).parent().find('.in').length != 0 ) {
			$(this).find('.fa').removeClass('fa-long-arrow-up').addClass('fa-long-arrow-down');
		} else {
			$(this).find('.fa').removeClass('fa-long-arrow-down').addClass('fa-long-arrow-up');
		}
	});

	$("input[name='trendlines'").change(function(){
		var trendlines = {};
		$.each($("input[name='trendlines']:checked"), function(index, value){
			var trenlineValue = $(value).val()
			trendlines[trenlineValue] = trenlineValue; 
		});
		$.cookie('trendlines', JSON.stringify(trendlines));
		location.reload();
	});

	// get post from database for homepage
	function postsAjax(){
		$.ajax({
			url:"/website/listPosts",
			dataType: 'json',
			complete: function(data){
				data.responseText = data.responseText.replace(String.fromCharCode(65279), "" );
				try {
					data = JSON.parse(data.responseText);
					data.posts = data.posts || [];
					var diabet_category = '';
					var platform_category = '';

					$.each(data.posts, function(key, element){
			              if( element.featured == 1) {
			                diabet_category += '<article>';
							diabet_category += '<div class="article-header"><h4 class="title_post">'+ element.title + '</h4></div>';
							diabet_category += '<div class="content_post">'+ $("<div/>").html(Base64.decode(element.content)).text().substr(0, 250) +' ... </div> ';
							diabet_category += '<div class="article-footer"><a class="btn btn-primary btn-sm" href="'+ window.location.origin + '/website/post_view/' + element.id + '">' + data.read_more + '</a></div>';
							diabet_category += '</article>';
			              } else {
			               	platform_category += '<article>';
							platform_category += '<div class="article-header"><h4 class="title_post">'+ element.title + '</h4></div>';
							platform_category += '<div class="content_post">'+ $("<div/>").html(Base64.decode(element.content)).text().substr(0, 250) +' ... </div> ';
							platform_category += '<div class="article-footer"><a class="btn btn-primary btn-sm" href="'+ window.location.origin + '/website/post_view/' + element.id + '">' + data.read_more + '</a></div>';
							platform_category += '</article>';
			              }
		            })	
					
		            !diabet_category || $('.diabet_posts').html(diabet_category);
		            !platform_category || $('.platform_posts').html(platform_category);

				} catch (e) {}				
			}
		});
	}

	if ( $('.index_page, .login_page').length != 0  ) {
		postsAjax();
	}

	var url = window.location;
	// Will only work if string in href matches with location
	$('ul.sidebar-menu a[href="'+ url +'"]').parent().addClass('active');

	// Will also work for relative and absolute hrefs
	$('ul.sidebar-menu a').filter(function() {
	    return this.href == url;
	}).parent().addClass('active');

});