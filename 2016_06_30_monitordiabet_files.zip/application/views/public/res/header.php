<!DOCTYPE html>
<html>
<head>
  	<meta charset="utf-8">
  	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $page_title; ?></title>
	<!-- Tell the browser to be responsive to screen width -->
  	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/bootstrap/css/bootstrap.min.css">
    <!-- Font-Awesome -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- Font diacritice -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/animate.css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/owl.theme.default.min.css">
    <!-- Theme Style -->
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/style_theme.css">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/icomoon.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/magnific-popup.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/style.css">
    <!-- Modernizr JS -->
    <script src="<?php echo base_url()."public";?>/js/modernizr-2.6.2.min.js"></script>
    <!-- Google Captcha -->
    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body class="<?php if (isset($page_class)) { echo $page_class; } ?> public_part">
    <header id="fh5co-header" role="banner">
      <nav class="navbar navbar-default" role="navigation">
        <div class="container-fluid">
          <div class="navbar-header"> 
          <!-- Mobile Toggle Menu Button -->
          <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle" data-toggle="collapse" data-target="#fh5co-navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
          <a class="navbar-brand" href="<?php echo base_url();?>">Monitor Diabet</a>
          </div>
          <div id="fh5co-navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
              <li>
                <a data-toggle="modal" data-target="#terms_modal">
                  <span><?php echo lang('terms_conditions');?><span class="border"></span></span>
                </a>
                <!-- Terms Modal -->
                <div id="terms_modal" class="modal fade" role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><?php echo lang('terms_conditions');?></h4>
                      </div>
                      <div class="modal-body">
                        <p><?php echo lang('terms_description');?></p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang('close_btn');?></button>
                      </div>
                    </div>

                  </div>
                </div>
              </li>
              <li>
                <a data-toggle="modal" data-target="#works_modal">
                  <span><?php echo lang('how_it_works');?><span class="border"></span></span>
                </a>
              </li>
              <!-- How it works Modal -->
              <div id="works_modal" class="modal fade" role="dialog">
                <div class="modal-dialog">

                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title"><?php echo lang('how_it_works');?></h4>
                    </div>
                    <div class="modal-body">
                      <p><?php echo lang('terms_description');?></p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang('close_btn');?></button>
                    </div>
                  </div>

                </div>
              </div>
<!--               <li>
                <a href="<?php //echo base_url();?>auth/login">
                  <span><?php //echo lang('login_heading');?> / <?php //echo lang('create_user_heading');?><span class="border"></span></span>
                </a>
              </li> -->
              <li>
              <?php 
              if ($languages) {
              ?>
                <form method="post" class="lang-form" action="<?php echo base_url() . "set_language"; ?>">
                  <select name="lang" class="language-switcher lang form-control">
                    <?php
                      foreach($languages as $lang){
                    ?>
                      <option value="<?php echo $lang ?>" <?php echo ( $lang == $current_language ) ? "selected" : "" ?> ><?php echo $lang ?></option>
                    <?php
                      }
                    ?>
                  </select>
                  <?php
                    }
                  ?>
                  <input type="hidden" name="curent_url" value="<?php echo current_url() ?>">
                  <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                </form>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <div class="collapse-div">
      <div id="demo" class="collapse" aria-expanded="false">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </div>
      <button id="btn-promotion" type="button" class="btn btn-info btn-xs" data-toggle="collapse" data-target="#demo"><i class="fa fa-long-arrow-down"></i></button>
      <div style="clear:both"></div>
    </div>
    <!-- END .header -->
  