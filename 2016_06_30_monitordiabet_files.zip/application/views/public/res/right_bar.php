<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="right-bar col-xs-12 col-sm-4">
  <?php 
    $this->load->view('auth/login'); 
  ?>
</div>