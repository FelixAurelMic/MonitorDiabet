	<footer id="fh5co-footer">
	    <div class="row">
	    	<div class="col-xs-12 col-sm-4">
	    		<p>Powered by <a href="http://svs-websoft.com/">SVS WebSoft</a></p>
	    	</div>
	    	<div class="col-xs-12 col-sm-4">
	    		<p class="text-center">
	    			Copyright &copy; <?php echo Date('Y'); ?> Monitor Diabet <br class="xs-hidden">
	    			contact@monitordiabet.ro
	    		</p>		
	    	</div>
	    	<div class="col-xs-12 col-sm-4 footer_icons">
	    		<a href="https://twitter.com/@monitordiabet"><i class="fa fa-twitter-square"></i></a>
	    		<a href="https://www.facebook.com/MonitorDiabet-616797018475363/"><i class="fa fa-facebook-official"></i></a>
	    	</div>
	    </div>
  	</footer>
	<!-- jQuery 2.2.0 -->
	<script src="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/plugins/jQuery/jQuery-2.2.0.min.js"></script>
	<!-- jQuery Easing -->
	<script src="<?php echo base_url()."public";?>/js/jquery.easing.1.3.js"></script>
	<!-- jQuery UI 1.11.4 -->
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
	  $.widget.bridge('uibutton', $.ui.button);
	</script>
	<!-- Bootstrap 3.3.6 -->
	<script src="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/bootstrap/js/bootstrap.min.js"></script>
	<!-- Owl carousel -->
	<script src="<?php echo base_url()."public";?>/js/owl.carousel.min.js"></script>
    <!-- Custom Style -->
    <script src="<?php echo base_url()."public";?>/js/scripts.js"></script>
	<!-- Waypoints -->
	<script src="<?php echo base_url()."public";?>/js/jquery.waypoints.min.js"></script>
	<!-- Magnific Popup -->
	<script src="<?php echo base_url()."public";?>/js/jquery.magnific-popup.min.js"></script>
	<!-- Main JS -->
	<script src="<?php echo base_url()."public";?>/js/main.js"></script>
</body>
</html>
