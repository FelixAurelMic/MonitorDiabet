<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="min_height_container row single_post">
  <div class="col-xs-12 col-sm-12">
      <section>
        <?php 
          if ( $post_data ) {
          foreach ($post_data as $element) {
        ?>
        <article> 
          <div class="article-header">
            <h4 class="title_post"><?php echo $element['title']; ?></h4>
            <p class="category_post"><?php echo ($element['featured'] == 1 ) ? lang('dashboard_diabetes_news_display') : lang('dashboard_platform_news_display'); ?></p>
          </div> 
          <div class="content_post"><?php echo base64_decode($element['content']); ?></div> 
        </article>
        <?php } 
        } else {
          echo lang('no_post');
        }
         ?>
      </section>
  </div>
</div>
<?php //require_once(APPPATH.'views/public/res/right_bar.php'); ?>