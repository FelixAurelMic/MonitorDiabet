<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
    <div class="min_height_container row news">
      <div class="col-xs-12 col-sm-8 posts_content">
          <!-- Posts Diabet -->
          <h3><?php echo lang('dashboard_diabetes_news_display'); ?></h3>
          <section class="max_height_scroll category_post diabet_posts">
            <?php echo lang('no_post'); ?>
          </section>
          <h3><?php echo lang('dashboard_platform_news_display'); ?></h3>
          <section class="max_height_scroll category_post platform_posts">
            <?php echo lang('no_post'); ?>
          </section>
      </div>
      <?php require_once(APPPATH.'views/public/res/right_bar.php'); ?>
  </div>