<div class="min_height_container content-wrapper" id="content">
    <div class="row">
            <div class="register_form col-xs-12 col-sm-6">
              <h3><?php echo lang('create_user_heading');?></h3>
              <p><?php echo lang('create_user_subheading');?></p>

              <div class="text-danger" id="infoMessage"><?php echo $message;?></div>

              <?php echo form_open("auth/create_user");?>
                  
                    <?php
                    if($identity_column!=='email') {
                        echo '<p>';
                        echo lang('create_user_identity_label', 'identity');
                        echo '<br />';
                        echo form_error('identity');
                        echo form_input($identity);
                        echo '</p>';
                    }
                    ?>

                    <p>
                          <?php echo lang('create_user_email_label', 'email');?> <br />
                          <?php echo form_input($email,'','class="form-control" required');?>
                    </p>

                    <p>
                          <?php echo lang('create_user_password_label', 'password');?> <br />
                          <?php echo form_input($password,'','class="form-control" required');?>
                    </p>

                    <p>
                          <?php echo lang('create_user_password_confirm_label', 'password_confirm');?> <br />
                          <?php echo form_input($password_confirm,'','class="form-control" required');?>
                    </p>
                    <p>

                          <?php echo lang('login_doctor_label', 'doctor');?>
                          <?php echo form_checkbox('doctor', '1', FALSE, 'id="doctor"');?>
                    </p>
                    <p>
                          <?php echo lang('login_terms_label', 'terms');?>
                          <?php echo form_checkbox('terms', '1', FALSE, 'id="terms" required');?>
                    </p>
                    <p><?php echo form_submit('submit', lang('create_user_submit_btn'), 'class="btn btn-primary btn-lg btn-block"');?></p>

              <?php echo form_close();?>
            </div>
      </div>
</div>
