<div class="content-wrapper" id="content">
    <div class="row">
      <div class="col-xs-12">
        <h3><?php echo lang('edit_user_heading');?></h3>
        <p><?php echo lang('edit_user_subheading');?></p>

        <div class="text-danger" id="infoMessage"><?php echo $message;?></div>
      </div>  
      <?php echo form_open(uri_string());?>
      <div class="col-xs-12 edit_user_form">
              <div class="pull-xs-left edit_div">
                    <?php echo lang('edit_user_fname_label', 'first_name');?>
                    <?php echo form_input($first_name,'','required size="20" minlength="3" maxlength="30"');?>
              </div>
              <div class="pull-xs-left edit_div">
                    <?php echo lang('edit_user_lname_label', 'last_name');?>
                    <?php echo form_input($last_name,'','required size="20" minlength="3" maxlength="30"');?>
              </div>
              <div class="pull-xs-left edit_div">
                    <?php echo lang('edit_user_phone_label', 'phone');?>
                    <?php echo form_input($phone,'','required size="10" minlength="9" maxlength="15"');?>
              </div>
              <div class="pull-xs-left edit_div">
                    <?php echo lang('edit_user_validation_age_label', 'age');?>
                    <?php echo form_input($age,'','required minlength="0" maxlength="3" min="1" max="120" style="width:60px"');?>
              </div>
              <div class="pull-xs-left edit_div">
                    <?php echo lang('edit_user_validation_sex_label', 'sex');?>
                    <?php echo form_dropdown($sex, array('male' => lang('edit_user_validation_sex_male_option'),'female' => lang('edit_user_validation_sex_female_option')),'','required');?>
              </div>
              <div class="pull-xs-left edit_div">
                    <?php echo lang('edit_user_validation_diabetes_period_label', 'diabetes_period');?>
                    <input type="text" value="<?php echo $diabetes_period['value']; ?>" name="diabetes_period" id="diabetes_period" class="date-picker" size="20" autocomplete="off" required/>
              </div>
              <div style="clear:both"></div>
              <div class="edit_div">
                    <?php echo lang('edit_user_validation_diabetes_type_label', 'diabetes_type');?>
                    <?php echo form_input($diabetes_type,'','required size="50" minlength="1" maxlength="50"');?>
              </div>
              <div class="edit_div">
                    <?php echo lang('edit_user_validation_diabetes_treatment_label', 'treatment');?>
                    <?php echo form_textarea($treatment,'','class="form-control" required');?>
              </div>
              </br>
              <?php echo form_hidden('id', $user->id);?>
              <?php echo form_hidden($csrf); ?>
    </div>
    <div class="col-xs-12">
        <p><?php echo form_submit('submit', lang('edit_user_submit_btn'), 'class="float-right btn btn-primary btn-lg btn-block"');?></p>
        <div style="clear:both"></div>
    </div>  
    <?php echo form_close();?>
  </div>
</div>
