<div class="min_height_container content-wrapper login_form" id="content">
    <div class="row">
    <?php
      if ( $_SERVER['REQUEST_URI'] == '/') {
       $col_number =  12; 
     } elseif ($_SERVER['REQUEST_URI'] == '/auth/login'){
        if (array_key_exists('HTTP_REFERER', $_SERVER) && $_SERVER['HTTP_REFERER'] == base_url()){
            $col_number =  12; 
        } else {
            $col_number = 6;  
        }
     }
    ?>
      <div class="col-xs-12 col-sm-<?php echo $col_number;?>">
        <div class="col_equal">
        <h3><?php echo lang('login_heading');?></h3>
        <p><?php echo lang('login_subheading');?></p>

        <div class="text-danger" id="infoMessage"><?php echo $message;?></div>

        <?php echo form_open("auth/login");?>

          <p>
            <?php echo lang('login_identity_label', 'identity');?>
            <?php echo form_input($identity,'','class="form-control" required');?>
          </p>

          <p>
            <?php echo lang('login_password_label', 'password');?>
            <?php echo form_input($password,'','class="form-control" required');?>
          </p>

          <img id="captcha" src="/securimage/securimage_show.php" alt="CAPTCHA Image" />
          <input type="text" name="captcha_code" size="10" maxlength="6" required/>
          <a href="#" onclick="document.getElementById('captcha').src = '/securimage/securimage_show.php?' + Math.random(); return false"><br>[ Different Image ]</a>
             <p>
              <?php echo lang('login_remember_label', 'remember');?>
              <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?>
            </p>
          <p><?php echo form_submit('submit', lang('login_submit_btn'), 'class="btn btn-primary btn-lg btn-block"');?></p>

        <?php echo form_close();?>
        <p><a href="/auth/forgot_password"><?php echo lang('login_forgot_password');?></a></p>
        </div>
      </div>
      <div class="col-xs-12 col-sm-<?php echo $col_number;?>">
        <div class="col_equal">
            <h3><?php echo lang('create_user_new');?></h3>
            <p><?php echo lang('create_user_new_description');?></p>
            <p><a class="btn btn-primary btn-lg btn-block" href="/auth/create_user"><?php echo lang('create_user_new_register');?></a></p>
        </div>
      </div>
  </div>
</div>