<div class="min_height_container content-wrapper" id="content">
    <div class="row">
        <div class="col-xs-12 col-sm-6 forgot_password_form">
			<h3><?php echo lang('forgot_password_heading');?></h3>
			<p><?php echo sprintf(lang('forgot_password_subheading'), $identity_label);?></p>

			<div class="text-danger" id="infoMessage"><?php echo $message;?></div>

			<?php echo form_open("auth/forgot_password");?>

			      <p>
			      	<label for="identity"><?php echo (($type=='email') ? sprintf(lang('forgot_password_email_label'), $identity_label) : sprintf(lang('forgot_password_identity_label'), $identity_label));?></label> <br />
			      	<?php echo form_input($identity,'','class="form-control" required');?>
			      </p>

			      <p><?php echo form_submit('submit', lang('forgot_password_submit_btn'), 'class="btn btn-primary btn-lg btn-block"');?></p>

			<?php echo form_close();?>
		</div>
	</div>
</div>
