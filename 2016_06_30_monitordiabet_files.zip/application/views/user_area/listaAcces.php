<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="content-wrapper" id="content">
<div class="row">
    <div class="col-xs-12">
         <div class="box">
            <div class="box-header">
              <h3><?php echo lang('dashboard_patients_label');?></h3>
            </div>
            <div class="box-body table-responsive no-padding">
    		<table class="table table-hover table-glucose">
                <tbody>
	                <tr>
	                  <th>#</th>
	                  <th><?php echo lang('dashboard_name_token_label');?></th>
	                  <th><?php echo lang('dashboard_email_address_label');?></th>
	                  <th></th>
	                </tr>
					<?php 
						$i = 1;
		     			foreach ($pacienti as $pacient){
					?>
		                <tr>
	                		<td><?php echo $i; ?></th>
		                  	<td><a target="_blank" href="<?php echo base_url() . 'diabet/dateDiabet?token=' . $pacient['token']; ?>"><?php echo $pacient['first_name']." ".$pacient['last_name'] ?></a></td>
		   					<td><?php echo $pacient['email']; ?></td>
		                  	<td><a target="_blank" href="<?php echo base_url() . 'diabet/dateDiabet?token=' . $pacient['token']; ?>"><i class="fa fa-eye"></i></a></td>
		                </tr>
					<?php
						$i++;
						}
					?>
              	</tbody>
            </table>
            </div> 
		</div>
	</div>
</div>
</div>