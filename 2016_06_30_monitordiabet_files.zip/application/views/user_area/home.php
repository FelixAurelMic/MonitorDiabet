<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper" id="content"> 
     <?php if ($this->callType === 'Token') $this->load->view('user_area/res/partial_user_data');?>
     <?php if($this->ion_auth->in_group('pacient') && $this->callType !== 'Token') { $this->load->view('user_area/res/partial_glicemie_adaugare');};?>
     <?php if($this->ion_auth->in_group('pacient') || $this->callType == 'Token') { $this->load->view('user_area/res/partial_glicemie_grafic');};?>
     <?php if($this->ion_auth->in_group('pacient') || $this->callType == 'Token') { $this->load->view('user_area/res/partial_glicemie_tabel');};?>
</div>