<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="content-wrapper add_post" id="content">
    <div class="row">
    	<a class="btn btn-primary add_post_btn" href="<?php echo base_url() . "diabet/addPost" . $uri_params?>">
        	<i class="fa fa-pencil-square-o"></i> <span><?php echo lang('add_post');?></span> <i class="fa"></i>
      	</a>
	  	<div class="col-xs-12">
        	<h3><?php echo lang('list_posts');?></h3>
        	<div class="box-body table-responsive no-padding">
	    		<table class="table table-hover table-glucose">
	                <tbody>
		                <tr>
		                  <th><?php echo lang('dashboard_post_title_label');?></th>
		                  <th><?php echo lang('dashboard_post_content_label');?></th>
		                  <th><?php echo lang('dashboard_post_featured_label');?></th>
		                  <th></th>
		                  <th></th>
		                </tr>
						<?php
							foreach ($posts as $key => $post) {
						?>
			                <tr>
			                  	<td><a href="<?php echo base_url() . 'diabet/addPost/' . $post['id']; ?>"><?php echo $post['title']; ?></a></td>
			   					<td><?php echo substr(strip_tags(base64_decode($post['content'])),0,150)." ..."; ?></td>
			   					<td><?php echo ($post['featured'] == 1 ) ? lang('dashboard_diabetes_news_display') : lang('dashboard_platform_news_display'); ?></td>
			                  	<td><a href="<?php echo base_url() . 'diabet/addPost/' . $post['id']; ?>"><i class="fa fa-eye"></i></a></td>   	
			                	<th><a class="delete_post" data-href="<?php echo base_url() . 'diabet/deletePost/' . $post['id']; ?>"><i class="fa fa-trash"></i></a></th>
			                </tr>
						<?php
							}
						?>
	              	</tbody>
	            </table>
            </div> 
        </div>
    </div>
</div>