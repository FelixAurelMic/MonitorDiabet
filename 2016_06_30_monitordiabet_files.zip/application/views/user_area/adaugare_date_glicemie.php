<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="content-wrapper add_values_glucose" id="content">
    <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3><?php echo lang('dashboard_complete_glucose_label');?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
            	<?php echo form_open(base_url()."diabet/salvareDateGlicemie");?>
		    		<table class="table table-hover table-glucose">
		                <tbody>
		                <tr>
		                  <th><?php echo lang('dashboard_number_label');?></th>
		                  <th><?php echo lang('dashboard_glucose_value_label');?></th>
		                  <th><?php echo lang('dashboard_time_label');?></th>
		                  <th><?php echo lang('dashboard_date_label');?></th>
		                  <th><?php echo lang('dashboard_notes_label');?></th>
		                </tr>
							<?php 
								$user = $this->ion_auth->user()->row();
								$i = 1;
								foreach ($units as $key => $value) {
									if ( $glucose_values ) {
										if ( $$key != "0" ) {
											$value_edit = $$key;
										} else {
											$value_edit = "";
										}
									} else {
										$value_edit = "";
									}
									if ( $notes_values ) {
										$key_note = $key . "_nota";
										$value_note_edit = $notes->$key_note;
									} else {
										$value_note_edit = "";
									}
							?>
					                <tr>
					                  <td><input type="hidden" name="count[]"><?php echo $i;?></td>
					                  <td><input class="only_numbers" pattern="[0-9]*" maxlength="3" type="text" name="<?php echo $key; ?>" value="<?php echo set_value($key,$value_edit);?>"><span><?php echo lang('dashboard_unity_label');?></span></td>
					                  <td><?php echo $value;?></td>
					                  <td><?php echo date("d/m/Y");?></td>
					                  <?php $key_nota = $key . "_nota"; ?>
					                  <td><input type="text" name="<?php echo $key . "_nota"; ?>" value="<?php echo set_value($key . "_nota", $value_note_edit);?>"></td>
					                </tr>
							<?php
								$i++;
								}
							?>
		              	</tbody>
		              </table>
                <input type="hidden" name="curent_url" value="<?php echo $current_url ?>">
				<?php for ($i=0; $i <= 10; $i++) { 
					echo "<span class='text-danger message'>" . form_error("interval_$i") . "</span>";
				} ?>
          	    <div class="col-xs-12">
	                <th><input type="submit" class="btn btn-primary save_info" value="<?php echo lang('dashboard_save_label');?>"></th>
			    </div>  
              	<?php echo form_close();?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
	</div>
</div>