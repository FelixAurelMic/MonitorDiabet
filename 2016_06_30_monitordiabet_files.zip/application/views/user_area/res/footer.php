	<!-- jQuery 2.2.0 -->
	<script src="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/plugins/jQuery/jQuery-2.2.0.min.js"></script>
	<!-- Jquery cookie plugin  -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
	<!-- jQuery UI 1.11.4 -->
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
	  $.widget.bridge('uibutton', $.ui.button);
	</script>
	<!-- Bootstrap 3.3.6 -->
	<script src="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/bootstrap/js/bootstrap.min.js"></script>
	<!-- datepicker -->
	  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<!-- Google Charts  -->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="<?php echo base_url()."public";?>/js/xepOnline.jqPlugin.js"></script>	
	    <!-- Hotkeys Editor -->
    <script src="<?php echo base_url()."public";?>/js/jquery.hotkeys.js"></script>
    	<!-- AdminLTE for demo purposes -->
	<script src="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/dist/js/app.min.js"></script>
	    <!-- Tiny Editor -->
    <script src="<?php echo base_url()."public";?>/js/bootstrap-wysiwyg.js"></script>
	    <!-- Custom Scripts -->
    <script src="<?php echo base_url()."public";?>/js/scripts.js"></script>
</div>
</body>
</html>
