<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
    <div class="col-xs-12">
         <div class="box">
            <div class="box-header">
              <h3><?php echo lang('dashboard_glucose_tabel');?></h3>
            </div>
            <div class="box-body table-responsive no-padding">
				<div class="panel-group" id="accordion">
					<?php
		     			foreach ($glicemie_table as $key => $value ){
							if ( !empty($value) ) {
						?>
						<div class="panel panel-default">
							<div class="panel-heading">
								<button type="button" class="btn-table-glucose btn btn-block btn-social btn-dropbox panel-heading" data-parent="#accordion_<?php echo $key; ?>" data-toggle="collapse" data-target="#div_<?php echo $key; ?>">
									<i class="fa fa-plus"></i>
									<?php echo $value['date'];?>
								</button>
							</div>
	                		<div id="div_<?php echo $key; ?>" class="panel-collapse collapse">
							<table class="table table-hover table-glucose">
            					<tbody>
					                <tr>
					                  <th><?php echo lang('dashboard_time_label');?></th>
					                  <th><?php echo lang('dashboard_glucose_value_label');?></th>
					                  <th><?php echo lang('dashboard_notes_label');?></th>
					                </tr>
								<?php if ( $value['interval_1'] != "0" ) { ?>
									<tr>
					                  	<td><?php echo lang('interval_1');?></td>
					   					<td><?php echo $value['interval_1']; ?></td>
					   					<td><?php echo $value['interval_1_nota']; ?></td>
			                		</tr>
				                  	<?php } ?>
									<?php if ( $value['interval_2'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_2');?></td>
						   					<td><?php echo $value['interval_2']; ?></td>
						   					<td><?php echo $value['interval_2_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
									<?php if ( $value['interval_3'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_3');?></td>
						   					<td><?php echo $value['interval_3']; ?></td>
						   					<td><?php echo $value['interval_3_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
									<?php if ( $value['interval_4'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_4');?></td>
						   					<td><?php echo $value['interval_4']; ?></td>
						   					<td><?php echo $value['interval_4_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
									<?php if ( $value['interval_5'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_5');?></td>
						   					<td><?php echo $value['interval_5']; ?></td>
						   					<td><?php echo $value['interval_5_nota']; ?></td>
						                  	
				                		</tr>
				                  	<?php } ?>
									<?php if ( $value['interval_6'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_6');?></td>
						   					<td><?php echo $value['interval_6']; ?></td>
						   					<td><?php echo $value['interval_6_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
									<?php if ( $value['interval_7'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_7');?></td>
						   					<td><?php echo $value['interval_7']; ?></td>
						   					<td><?php echo $value['interval_7_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
				                  	<?php if ( $value['interval_8'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_8');?></td>
						   					<td><?php echo $value['interval_8']; ?></td>
						   					<td><?php echo $value['interval_8_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
				                  	<?php if ( $value['interval_9'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_9');?></td>
						   					<td><?php echo $value['interval_9']; ?></td>
						   					<td><?php echo $value['interval_9_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
				                  	<?php if ( $value['interval_10'] != "0" ) { ?>
										<tr>
						                  	<td><?php echo lang('interval_10');?></td>
						   					<td><?php echo $value['interval_10']; ?></td>
						   					<td><?php echo $value['interval_10_nota']; ?></td>
				                		</tr>
				                  	<?php } ?>
				              	</tbody>
				            	</table>
		                	</div>
		                </div>
						<?php
							}
						}
					?>
            	</div>
            </div> 
		</div>
	</div>
</div>