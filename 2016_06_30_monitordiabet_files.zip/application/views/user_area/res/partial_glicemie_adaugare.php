<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
    <div class="col-xs-12">
      <?php if ( 1 == 1 ) { ?>
      <div class="box no-background">
        <div class="box-header">
          <h3><?php echo lang('dashboard_select_unity_label');?></h3>
        </div>
        <!-- /.box-header -->
        <div class="row">
	        <div class="col-md-4">
	          <div class="box box-solid">
	            <div class="box-header with-border">
	              	<i class="fa fa-info"></i>
	              	<h3 class="box-title"><?php echo lang('dashboard_8_units_button');?></h3>
	              	<div class="svs-tooltip">
                		<ul class="svs-tooltip-message">
			                <li><?php echo lang('interval_1');?></li>
			                <li><?php echo lang('interval_2');?></li>
			                <li><?php echo lang('interval_3');?></li>
			                <li><?php echo lang('interval_4');?></li>
			                <li><?php echo lang('interval_5');?></li>
			                <li><?php echo lang('interval_6');?></li>
			                <li><?php echo lang('interval_7');?></li>
			                <li><?php echo lang('interval_8');?></li>
			                <li><?php echo lang('interval_9');?></li>
			                <li><?php echo lang('interval_10');?></li>
             			</ul>
                	</div>
	            </div>
	            <!-- /.box-header -->
	            <div class="box-footer with-border">
	              	<a href="<?php echo base_url();?>diabet/adaugareDateGlicemie/8" class="btn btn-primary save_info"><?php echo lang('dashboard_select_unity_button');?></a>
	            </div>
	          </div>
	          <!-- /.box -->
	        </div>
	        <div class="col-md-4">
	          	<div class="box box-solid">
		            <div class="box-header with-border">
		              	<i class="fa fa-info"></i>
			            <h3 class="box-title"><?php echo lang('dashboard_4_units_button');?></h3> 
	  	              	<div class="svs-tooltip">
	                		<ul class="svs-tooltip-message">
				                <li><?php echo lang('interval_1');?></li>
				                <li><?php echo lang('interval_3');?></li>
				                <li><?php echo lang('interval_5');?></li>
				                <li><?php echo lang('interval_7');?></li>
				                <li><?php echo lang('interval_9');?></li>
				                <li><?php echo lang('interval_10');?></li>
	                		</ul>
		            	</div>
		          	</div>
	           		<!-- /.box-header -->
		            <div class="box-footer with-border">
		              	<a href="<?php echo base_url();?>diabet/adaugareDateGlicemie/4" class="btn btn-primary save_info"><?php echo lang('dashboard_select_unity_button');?></a>
		            </div>
	          		<!-- /.box -->
	        	</div>
	        </div>
	        <div class="col-md-4">
	          <div class="box box-solid">
	            <div class="box-header with-border">
	            	<i class="fa fa-info"></i>
	        	    <h3 class="box-title"><?php echo lang('dashboard_3_units_button');?></h3>
		            <div class="svs-tooltip">
	        			<ul class="svs-tooltip-message">
			                <li><?php echo lang('interval_1');?></li>
			                <li><?php echo lang('interval_7');?></li>
			                <li><?php echo lang('interval_8');?></li>
			                <li><?php echo lang('interval_9');?></li>
			                <li><?php echo lang('interval_10');?></li>
	        			</ul>
	            	</div>
	          	</div>
	            <!-- /.box-header -->
	            <div class="box-footer with-border">
	              	<a href="<?php echo base_url();?>diabet/adaugareDateGlicemie/3" class="btn btn-primary save_info"><?php echo lang('dashboard_select_unity_button');?></a>
	            </div>
	          <!-- /.box -->
	        </div>
	      </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
      <?php } else { ?>
   		<div class="box">
            <div class="box-header">
              <h3><?php echo lang('dashboard_questions_unity_label');?></h3>
            </div>
	  	</div>
	  <?php } ?>

    </div>
</div>