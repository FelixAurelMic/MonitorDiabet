<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $page_title; ?></title>
  <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/bootstrap/css/bootstrap.min.css">
    <!-- Font-Awesome -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <!-- Theme Style -->
    <link rel="stylesheet" href="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/dist/css/AdminLTE.css">
    <!-- Skin -->
    <link rel="stylesheet" href="<?php echo base_url()."assets";?>/AdminLTE-2.3.3/dist/css/skins/skin-blue.min.css">
    <!-- Font diacritice -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <!-- Date Picker -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="<?php echo base_url()."public";?>/css/style.css">
    <script type="text/javascript">
    //<![CDATA[
      uri_params = "<?php echo $uri_params; ?>";
    //]]>    
    </script>
</head>
<body class="hold-transition skin-blue sidebar-mini <?php if (isset($page_class)) { echo $page_class; } ?>">
  <div class="wrapper">
    <header class="main-header">
      <!-- Logo -->
      <a href="<?php echo base_url();?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>P</b>D</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>Monitor</b> Diabet</span>
      </a>

      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <li>
              <a data-toggle="modal" data-target="#works_modal">
                <span><?php echo lang('how_it_works');?><span class="border"></span></span>
              </a>
            </li>
            <li>
              <?php 
              if ($languages){
            ?>
             <form method="post" class="lang-form" action="<?php echo base_url() . "set_language"; ?>">
              <select name="lang" class="language-switcher lang form-control">
                <?php
                  foreach($languages as $lang){
                ?>
                <option value="<?php echo $lang ?>" <?php echo ( $lang == get_cookie('svs_language') ) ? "selected" : "" ?> ><?php echo $lang ?></option>
                <?php
                  }
                ?>
              </select>
              <?php
                }
              ?>
              <input type="hidden" name="curent_url" value="<?php echo $current_url ?>">
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
            </form>
            </li>
              <!-- How it works Modal -->
              <div id="works_modal" class="modal fade" role="dialog">
                <div class="modal-dialog">
                  <!-- Modal content-->
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title"><?php echo lang('how_it_works');?></h4>
                    </div>
                    <div class="modal-body">
                      <p><?php echo lang('terms_description');?></p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo lang('close_btn');?></button>
                    </div>
                  </div>

                </div>
              </div>
          </ul>
        </div>
      </nav>
    </header>
