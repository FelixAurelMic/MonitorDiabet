<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user = isset($user) ? $user : $this->ion_auth->user()->row();
?>
<aside class="main-sidebar">
  <!-- Inner sidebar -->
  <div class="sidebar">
    <!-- user panel (Optional) -->
    <div class="user-panel">
        <div class="pull-left image">
          <i class="fa fa-3x fa-user"></i>
        </div>
        <div class="pull-left info">
          <?php 
            if ($user) {
              if ( $this->callType !== 'Token' ) { 
                echo "<h4>".lang('dashboard_hello_label')." ".$user->first_name."!</h4>";
              } else {
                echo "<h4>{$user->first_name} {$user->last_name}</h4>";
              } 
            }
          ?>
        </div>
    </div><!-- /.user-panel -->

    <!-- Sidebar Menu -->
    <ul class="sidebar-menu">
      <?php 
      // if ( !$this->ion_auth->in_group('doctor') || $this->callType == 'Token') { 
      if ( $this->ion_auth->in_group('pacient') && !$this->ion_auth->in_group('admin') ) { 
        $this->load->view('user_area/res/menu/date_diabet');
      }
      if ( !$this->ion_auth->in_group('admin') && $this->ion_auth->in_group('doctor') || $this->callType == 'Token') { 
        $this->load->view('user_area/res/menu/lista_persoanelor_cu_access');
      }
      if ( $this->ion_auth->in_group('admin') && $this->callType !== 'Token') { 
        $this->load->view('user_area/res/menu/lista_utilizatori');
        $this->load->view('user_area/res/menu/list_posts');
      }
      
      if (!$this->ion_auth->in_group('admin') && $this->ion_auth->in_group('pacient') && $this->callType !== 'Token') {
        $this->load->view('user_area/res/menu/editare_privilegii_access');
        $this->load->view('user_area/res/menu/informatii_cont');
      }
      if ($this->ion_auth->in_group('doctor') || $this->callType !== 'Token'){
        $this->load->view('user_area/res/menu/schimba_parola');   
        $this->load->view('user_area/res/menu/logout'); 
      }
      ?>

      
    </ul><!-- /.sidebar-menu -->

  </div><!-- /.sidebar -->
</aside><!-- /.main-sidebar -->