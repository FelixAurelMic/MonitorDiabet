<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row details-pacient">
  	<div class="col-xs-12">
            <div class="pull-xs-left col-xs-6 col-sm-2">
                  <?php echo lang('edit_user_fname_label', 'first_name') . $user->first_name;?></br>
                  <?php echo lang('edit_user_lname_label', 'last_name'). $user->last_name;?></br>
                  <?php echo lang('edit_user_phone_label', 'phone') . $user->phone;?></br>
            </div>
            <div class="pull-xs-left col-xs-6 col-sm-3">
                  <?php echo lang('edit_user_validation_age_label', 'age') . $user->age;?></br>
                  <?php echo lang('edit_user_validation_sex_label', 'sex') . $user->sex;?></br>
                  <?php echo lang('edit_user_validation_diabetes_period_label', 'diabetes_period') . $user->diabetes_period;?></br>
            </div>
            <div class="pull-xs-left col-xs-6 col-sm-6">
                  <?php echo lang('edit_user_validation_diabetes_type_label', 'diabetes_type') . $user->diabetes_type;?></br>
                  <?php echo lang('edit_user_validation_diabetes_treatment_label', 'treatment') . $user->treatment;?>
            </div>
            <div style="clear:both"></div>
	</div>
</div>