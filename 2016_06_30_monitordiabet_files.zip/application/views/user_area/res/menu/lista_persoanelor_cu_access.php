<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<li class="">
    <a href="<?php echo base_url() . "diabet/listaPersoanelorAccess" . $uri_params?>">
        <i class="fa fa-users"></i> <span><?php echo lang('dashboard_patients_label');?></span> <i class="fa"></i>
    </a>
</li>