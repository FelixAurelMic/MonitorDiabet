<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<li>
  <a href="<?php echo base_url() . "diabet/listPosts" . $uri_params?>">
      <i class="fa fa-list"></i> <span><?php echo lang('list_posts');?></span>
  </a>
</li>