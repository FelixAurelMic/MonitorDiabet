<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <li>
      <a href="<?php echo base_url() . "diabet/dateDiabet" . $uri_params?>">
          <i class="fa fa-dashboard"></i> <span><?php echo lang('dashboard_dashboard_label');?></span> <i class="fa"></i>
      </a>
  </li>