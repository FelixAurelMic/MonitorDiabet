<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<li class="">
    <a href="<?php echo base_url();?>diabet/editarePrivilegii">
        <i class="fa fa-unlock"></i> <span><?php echo lang('dashboard_access_label');?></span> <i class="fa"></i>
    </a>
</li>