<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<li class="">
  <a href="<?php echo base_url();?>auth/logout">
      <i class="fa fa-sign-out"></i> <span><?php echo lang('dashboard_logout_label');?></span> <i class="fa"></i>
  </a>
</li>