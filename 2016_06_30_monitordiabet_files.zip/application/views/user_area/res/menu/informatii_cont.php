<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// echo USER_ID;exit;
?>
<li class="">
  <a href="<?php echo base_url() . "auth/edit_user/" . USER_ID ?>">
      <i class="fa fa-info"></i> <span><?php echo lang('dashboard_informations_label');?></span> <i class="fa"></i>
  </a>
</li>