<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<li class="">
  <a href="<?php echo base_url();?>auth/change_password">
      <i class="fa fa-exchange"></i> <span><?php echo lang('dashboard_change_password_label');?></span> <i class="fa"></i>
  </a>
</li>