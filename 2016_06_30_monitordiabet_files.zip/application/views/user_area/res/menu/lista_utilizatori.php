<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<li class="">
    <a href="<?php echo base_url().'diabet/listaUtilizatori';?>">
        <i class="fa fa-unlock"></i> <span><?php echo lang('dashboard_users_label');?></span> <i class="fa"></i>
    </a>
</li>