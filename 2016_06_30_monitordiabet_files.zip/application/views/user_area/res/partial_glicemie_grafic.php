<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<script>
     var csfrData = {};
     csfrData['<?php echo $this->security->get_csrf_token_name(); ?>']
                       = '<?php echo $this->security->get_csrf_hash(); ?>';
</script>
<div class="add_values_glucose graphic_glucose">
    <div class="row">
        <div class="col-xs-12">
            <h3 class="grafic_user_id" data-for="<?php echo USER_ID ?>"><?php echo lang('dashboard_grafic_glucose_label');?></h3>
                <div class="col-xs-12 graphic_filters">
                    <select class="select_period">
        			    <option <?php echo ( $cookie_value == "7" ) ? "selected" : ""; ?> value="7"><?php echo lang('7_day_period');?></option>
        			    <option <?php echo ( $cookie_value == "30" ) ? "selected" : ""; ?> value="30"><?php echo lang('30_day_period');?></option>
        			    <option <?php echo ( $cookie_value == "60" ) ? "selected" : ""; ?> value="60"><?php echo lang('60_day_period');?></option>
        			    <option <?php echo ( $cookie_value == "90" ) ? "selected" : ""; ?> value="90"><?php echo lang('90_day_period');?></option>
        			    <option <?php echo ( $cookie_value == "120" ) ? "selected" : ""; ?> value="120"><?php echo lang('120_day_period');?></option>
                        <option <?php echo ( $cookie_value == "360" ) ? "selected" : ""; ?> value="360"><?php echo lang('360_day_period');?></option>
        			</select>
                </div>
                <div style="clear:both"></div>
                <!-- <div id="chart_div"></div> -->
                <div class="row">
                    <div class="col-md-12">
                      <!-- Bar chart -->
                      <div class="box box-primary">
                        <div class="box-body">
                          <div id="chart_div" style="height: 450px;"></div>
                        </div>
                      </div>
                    </div>
                </div>
                <div id="no_data_period"><h4><?php echo lang('no_data_period');?></h4></div>
                <div style="clear:both"></div>
            <div class="row trenlines">
                <div class="col-md-3 col-sm-12">
                    <?php for ($i = 1; $i <= 10; $i++){ break;?>
                    <input type="checkbox" name="trendlines" value="<?php echo ($i - 1) ?>">Trendline <?php echo lang("interval_$i") ?><br/>
                        <?php if ($i % 3 == 0){?> 
                        </div>
                        <div class="col-md-3 col-sm-12">
                        <?php } ?>
                    <?php } ?>
                    <input type="checkbox" name="trendlines" value="10"> <?php echo lang("hipoglicemie") ?><br/>
                    <input type="checkbox" name="trendlines" value="11"> <?php echo lang("hiperglicemie") ?><br/>
                </div>
            </div>
            <br/>
            <div class="row btns_export">
                <div class="col-xs-4">
                    <a class="btn btn-block btn-danger export_btn" type="button" onclick="return xepOnline.Formatter.Format('chart_div', {render:'download', srctype:'svg', pageMargin:'0mm'})">PDF</a>
                </div>
                <div class="col-xs-4">
                    <a href="<?php echo base_url() . "diabet/exportExcel" . $uri_params?>" class="btn btn-block btn-primary export_btn" type="button">EXCEL</a>
                </div>
                <div class="col-xs-4">
                    <a href="<?php echo base_url() . "diabet/exportCsv" . $uri_params?>" class="btn btn-block btn-success export_btn" type="button">CSV</a>
                </div>
            </div>
        </div>
            
    </div>
    <div class="row glucose_averages_values">   
        <h4><?php echo lang('average_label');?></h4>
        <div class="col-xs-4 col-sm-4"><?php echo "<b>".lang('7_day_period').":</b> <span>".$averages['7']."</span>";?></div>
        <div class="col-xs-4 col-sm-4"><?php echo "<b>".lang('30_day_period').":</b> <span>".$averages['30']."</span>";?></div>
        <div class="col-xs-4 col-sm-4"><?php echo "<b>".lang('60_day_period').":</b> <span>".$averages['60']."</span>";?></div>
        <div class="col-xs-4 col-sm-4"><?php echo "<b>".lang('90_day_period').":</b> <span>".$averages['90']."</span>";?></div>
        <div class="col-xs-4 col-sm-4"><?php echo "<b>".lang('120_day_period').":</b> <span>".$averages['120']."</span>";?></div>
        <div class="col-xs-4 col-sm-4"><?php echo "<b>".lang('360_day_period').":</b> <span>".$averages['360']."</span>";?></div>
    </div>
</div>
<div id="graphic_tooltip">
    <h4 id="grapchic_date">21.06.2016</h4>
    <span id="graphic_interval">Dimineata</span></br>
    <span id="bar_value">90</span><span>mg/dL</span>
</div>