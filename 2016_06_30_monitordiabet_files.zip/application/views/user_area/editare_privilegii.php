<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$limit = $this->config->item('limit_tokens');
?>
<div class="content-wrapper" id="content">
    <div class="row">
        <div class="col-xs-12">
          	<div class="box">
            <?php if ( $token24h['last24h'] == 10 || $tokenList['total'] == 10 ) { ?>
	            <div class="box-header">
	              <h3><?php echo lang('dashboard_limit_tokens_label');?></h3>
	            </div>
        	<?php } else { ?>
	            <div class="box-header">
	              <h3><?php echo lang('dashboard_access_add_label');?></h3>
	            </div>
	            <!-- /.box-header -->
	            <div class="box-body table-responsive no-padding">
	            	<?php echo form_open(base_url()."diabet/addToken");?>
					<?php 
						$user = $this->ion_auth->user()->row();
						$select_type = "<select class='form-control' id='type_person' name='type_person' required><option value=''>".lang('dashboard_select_person_label')."</option><option ". set_select('type_person','doctor') ." value='doctor'>".lang('dashboard_doctor_label')."</option><option ". set_select('type_person','family') ." value='family'>".lang('dashboard_family_label')."</option></select>"; ?>
	                  	<div class="row">
		                  	<div class="col-xs-6 col-sm-4">
			                  	<div class="form-group">
				                  <label for="email"><?php echo lang('dashboard_email_address_label'); ?></label>
				                  <input class="form-control" name="email" id="email" type="email" value="<?php echo set_value('email')?>" required>
				                </div>
			                </div>
		                  	<div class="col-xs-6 col-sm-4">
			                  	<div class="form-group">
				                  <label for="name_person"><?php echo lang('dashboard_name_token_label'); ?></label>
				                  <input class="form-control" name="name_person" id="name_person" type="text" value="<?php echo set_value('name_person')?>" required>
				                </div>
			                </div>
		                  	<div class="col-xs-6 col-sm-4">
			                  	<div class="form-group">
				                  <label for="type_person"><?php echo lang('dashboard_type_token_label'); ?></label>
				                  <?php echo $select_type;?>
				                </div>
			                </div>
			                <span class="text-danger message"><?php echo form_error('email'); ?></span>
			                <span class="text-danger message"><?php echo form_error('name_person'); ?></span>
			                <span class="text-danger message"><?php echo form_error('type_person'); ?></span>
			                <span class="text-danger message"><?php echo $error_type; ?></span>
				      	    <div class="col-xs-12">
				                <input type="submit" class="btn btn-primary save_info" value="<?php echo lang('dashboard_save_access_label');?>">
						    </div>  
		                </div>
		          	<?php echo form_close();?>
	            </div>
	            <!-- /.box-body -->
	            <?php } ?>
          	</div>
          	<!-- /.box -->
        </div>
        <?php if(!empty($tokenList['data'])) {?>
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3><?php echo lang('dashboard_access_added_label');?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              	<table class="table table-hover table-glucose">
                	<tbody>
		                <tr>
		                  <th><?php echo lang('dashboard_number_label');?></th>
		                  <th><?php echo lang('dashboard_token_label');?></th>
		                  <th><?php echo lang('dashboard_name_token_label');?></th>
		                  <th><?php echo lang('dashboard_email_address_label');?></th>
		                  <th><?php echo lang('dashboard_type_token_label');?></th>
		                  <th><?php echo lang('dashboard_action_label');?></th>
		                </tr>
		            	<?php
		            		$i = 1;
			            	foreach ($tokenList['data'] as $row){
		            		?>
			                <tr>
			                  <td><?php echo $i;?></td>
			                  <td><?php echo base_url() . "diabet/dateDiabet?token=" . $row['token'];?></td>
			                  <td><?php echo $row['name'];?></td>
			                  <td><?php echo $row['email'];?></td>
			                  <td><?php echo $row['type'];?></td>
			                  <td><a data-href="<?php echo base_url();?>diabet/deleteToken/<?php echo $row['token'];?>" type="button" class="delete_token btn btn-block btn-danger"> <?php echo lang('dashboard_action_delete_label');?> </a></td>
			                </tr>
			            <?php
			            	$i++;	}
		        		?>
              		</tbody>
              	</table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <?php } ?>
	</div>
</div>