<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="content-wrapper" id="content">
<div class="row">
    <div class="col-xs-12">
         <div class="box">
            <div class="box-header">
              <h3><?php echo lang('dashboard_users_list_label');?></h3>
            </div>
            <div class="box-body table-responsive no-padding">
	    		<table class="table table-hover table-glucose">
	                <tbody>
		                <tr>
		                  <th>#</th>
		                  <th><?php echo lang('dashboard_name_token_label');?></th>
		                  <th><?php echo lang('dashboard_email_address_label');?></th>
		                </tr>
						<?php 
							if ( $offset ) {
								$i = $offset;
							} else {
								$i = 1;
							}

			     			foreach ($users as $user){
						?>
			                <tr>
		                		<td><?php echo $i; ?></th>
			                  	<td>
			                  	<?php	if ( $user['token'] != "" ) { ?>
			                  		<a target="_blank" href="<?php echo base_url() . 'diabet/dateDiabet?token=' . $user['token']; ?>">
			                  	<?php } ?> 
			                  		<?php echo $user['first_name']." ".$user['last_name'] ?>
			                  	<?php	if ( $user['token'] != "" ) { ?>	
			                  		</a>
			                  	<?php } ?>
		                  		</td>
			   					<td><?php echo $user['email']; ?></td>
			                </tr>
						<?php
							$i++;
						}
						?>
	              	</tbody>
	            </table>
            </div> 
            <div class="box-footer">
			<?php echo $this->pagination->create_links(); ?>
			</div>
		</div>
	</div>
</div>
</div>