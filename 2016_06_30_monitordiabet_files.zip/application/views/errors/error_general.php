<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="alert  alert-warning">
	<h1><?php echo $error_title; ?></h1>
	<p><?php echo $error_message; ?></p>
</div>