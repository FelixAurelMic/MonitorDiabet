<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SVS_Controller extends CI_Controller 
{

	public $outputFormat = 'html';
	public $callType = 'Normal';

	public function __construct (){
		parent::__construct();
		$this->load->helper('languages');

		// set system language on app initialization
		$this->set_language();

		// set timezone GMT +2
		date_default_timezone_set('Europe/Bucharest');
	}


# ============== BEGIN VIEW FUNCTIONS ============= #

	/**
	* @author demis
	* Load the template and the view.
	* @param string $file array $data string $output
	* @return void
	*/
	protected function view($file, $data = array(), $output = "html") 
	{
		if ( $output == "json" ) {
			$this->viewDisplayJSON($data);
		} else if ( $output == "xml" ) {
			$this->viewDisplayXML($data);
		} else {
			$this->viewDisplayHTML($file, $data);
		}
      	
	}

	/**
	* Display as XML
	* 
	*/
	private function viewDisplayXML($data){
		$this->load->helper('display');
		header("Content-type: text/xml");
		$xml = new SimpleXMLElement('<response/>');
		echo array_to_xml($data, $xml)->asXML();
		exit;
	}

	/**
	* Display as JSON
	* 
	*/
	private function viewDisplayJSON($data){
		header('Content-Type: application/json');
		echo json_encode($data);
		exit;
	}

	/**
	* Normal display (HTML)
	* 
	*/
	private function viewDisplayHTML($file, $data){
		$folderLocation = ($this->ion_auth->logged_in() || $this->callType == 'Token' ? "user_area" : "public");
		$filePath = APPPATH . 'views/' . $file . '.php';

		if (!file_exists($filePath) || !is_readable($filePath) ){
			log_message('error', "File '$file' doesn't exist.");
			$this->view_error($this->lang->line('error_general_message'));
			return;
		};

		$data['call_type'] = $this->callType;
		$data['page_class'] = $this->router->fetch_method()."_page";
		$data['page_title'] = array_key_exists('page_title', $data) ? $data['page_title'] : 'Home';
		
		//common data
		$data['languages'] = get_languages();
		$data['current_language'] = $this->get_current_language();
		$data['current_url'] = current_url() . $this->get_uri_params();
		$data['uri_params'] = $this->get_uri_params();
		
		$this->load->view("$folderLocation/res/header", $data);
		if ( $this->ion_auth->logged_in() || $this->callType === 'Token' ) {			
			$this->load->view("$folderLocation/res/left_bar", $data);
		}
		$this->load->view($file, $data);
		$this->load->view("$folderLocation/res/footer", $data);
	}


	/**
	* @author demis
	* Load the template and the error view.
	* @param string $file string $error_message string $error_title
	* @return void
	*/
	public function view_error($error_message = null, $error_title = null)
	{
		$folderLocation = ($this->ion_auth->logged_in() || $this->callType == 'Token' ? "user_area" : "public");

		// set values for view
		$data['error_message'] = $error_message ? $error_message : $this->lang->line('error_general_message');
		$data['error_title'] = $error_title ? $error_title : $this->lang->line('error_general_title');
		$data['page_title'] = $this->lang->line('error_page_title');
		$data['languages'] = get_languages();
		$data['current_language'] = $this->get_current_language();
		$data['current_url'] = current_url() . $this->get_uri_params();

		log_message('error', $error_message);

		echo $this->load->view("$folderLocation/res/header", $data, true);
		echo $this->load->view("errors/error_general.php" , $data, true);
		echo $this->load->view("$folderLocation/res/footer", $data, true);
		exit;
	}

# ============== END VIEW FUNCTIONS ============= #






# ============== BEGIN LANGUAGE FUNCTIONS ============= #

	/** 
	* Get current system language
	*/
	private function get_current_language(){
		$this->load->helper('cookie');
		$languageFromCookie = get_cookie('svs_language');
		if ( !in_array($languageFromCookie, get_languages()) ) {
			$languageFromCookie = 'Romanian';
		}
		return $languageFromCookie;	
	}

	/**
	* Set system language depending on value from cookies.
	* If no cookies set load default language
	*/ 

	private function set_language(){
		$this->load->helper('cookie');

		$languageFromCookie = strtolower($this->get_current_language());
		$this->config->set_item('language', $languageFromCookie);	
		$this->lang->load(array('general', 'auth', 'db', 'errors_generals', 'form_validation', 'ion_auth'), $languageFromCookie);
	}

# ============== END LANGUAGE FUNCTIONS ============= #



# ============== BEGIN URI FUNCTIONS ============= #

	protected function get_uri_params(){
		$uriParams = parse_url($_SERVER['REQUEST_URI']);
		return (array_key_exists('query', $uriParams ) ?  "?{$uriParams['query']}" : "");
	}

# ============== END URI FUNCTIONS ============= #

}