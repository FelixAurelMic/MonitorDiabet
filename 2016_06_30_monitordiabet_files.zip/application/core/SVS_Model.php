<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SVS_Model extends CI_Model 
{

}