<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n";
$config['wordwrap'] = TRUE;

?>
