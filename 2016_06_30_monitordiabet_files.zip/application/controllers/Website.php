<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website extends SVS_Controller {

	public function __construct(){
		parent::__construct();
		if ($this->ion_auth->logged_in() && !$this->ion_auth->in_group('doctor')){
			redirect('diabet/dateDiabet', 'refresh');
		} else if ($this->ion_auth->logged_in()) {
			if ( $this->ion_auth->in_group('admin') ) {
				redirect('diabet/listaUtilizatori', 'refresh');
			} else {
				redirect('diabet/listaPersoanelorAccess', 'refresh');
			}
		}
		$this->load->model('Diabet_model');
	}

	public function index()
	{
		$data['page_title'] = 'Home';
		// $data['posts'] = $this->Diabet_model->getPosts();
		$this->load->library('form_validation');
		$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

		$data['identity'] = array('name' => 'identity',
			'id'    => 'identity',
			'type'  => 'text',
			'value' => $this->form_validation->set_value('identity'),
		);
		$data['password'] = array('name' => 'password',
			'id'   => 'password',
			'type' => 'password',
		);
		$this->view('public/home', $data);
	}

	public function contact()
	{
		$data['page_title'] = 'Contact';
		$this->view('public/contact', $data);
	}

	public function post_view($post_id)
	{
		$data['page_title'] = 'Home';
		$data['post_data'] = $this->Diabet_model->getEditDatePost($post_id);
		$this->view('public/post_view',$data);
	}


	/**
	* Display posts list
	*/
	public function listPosts()
	{
		$data['posts'] = $this->Diabet_model->getPosts();
		$data['read_more'] =  $this->lang->line('read_more');
        $this->output->set_content_type('application/json')
             ->set_output(json_encode($data));
	}
}
