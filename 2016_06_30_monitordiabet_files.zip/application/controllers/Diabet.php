<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Diabet extends SVS_Controller {

	public $get = array();

	public function __construct(){
		parent::__construct();
        $this->load->helper('cookie');
		$this->load->model('Diabet_model');
		$this->load->library('form_validation');
		$this->get = $this->input->get();
  
		if (array_key_exists('apiKey', $this->get)){
	   		$this->initializeApiCall($this->get['apiKey']);	   		
		} else if (array_key_exists('token', $this->get)){
	   		$this->initializeTokenCall($this->get['token']);
		} else {
	   		$this->initializeNormalCall();	
		}

		// set cookie period if is not set yet
		if ( !$this->input->cookie('period', TRUE) ) {
	        $cookie = array(
			    'name'   => 'period',
		        'value'  => 7,
		        'expire' => '86500',
			);
	        $this->input->set_cookie($cookie);
		}
	}

# ============== BEGIN INITIALIZE FUNCTIONS ============= #

	/**
	* This is an API call
	*/
	private function initializeApiCall($apiKey){
		$this->outputFormat = 'json';
		$this->callType = 'Api';
		$userId = $this->Diabet_model->checkApi($apiKey);

   		if (array_key_exists('output', $this->get) && $this->get['output'] == 'xml'){
	   		$this->outputFormat = 'xml';
	   	}
   		if ($userId === false){
	   		$this->view(
				'',
				array(
					'success' => false,
					'error' => 'Mesaj api key invalid'
				),
				$this->outputFormat
			);
   		}
   		DEFINE("USER_ID", $userId);		
	}

	/**
	* Initializes application for 3rd party
	* Uses token to grant access
	*/ 	
	private function initializeTokenCall($token){
		$this->callType = 'Token';
		$userId = $this->Diabet_model->checkToken($token);
   		if ($userId === false){
   			$this->view_error($this->lang->line('error_invalid_token'));
   			exit;
   		}
		if (!in_array($this->router->fetch_method(), array('dateDiabet', 'dateGrafic', 'listaPersoanelorAccess'))){
			$this->view_error($this->lang->line('error_invalid_operation'));
   			exit;
		}
   		DEFINE("USER_ID", $userId);
	}

	/**
	* Initializes application when user is logged in on web browser
	*/ 
	private function initializeNormalCall(){
		$this->load->helper('form'); 
        if (!$this->ion_auth->logged_in()){
			redirect('auth/login', 'refresh');
		}
		DEFINE("USER_ID", $this->ion_auth->user()->row()->id);
	}

# ============== END INITIALIZE FUNCTIONS ============= #

	/**
	* Display account information for patients (Menu Informatii) (view)
	*/
	public function dateDiabet()
	{

		// pass the user to the view
		$data['user'] = $this->Diabet_model->getUserData();	   
		$data['page_title'] = $this->lang->line('dashboard_dashboard_label');
		$data['title'] = $this->lang->line('edit_user_heading');
		$periodsaverages = array(7,30,60,90,120,360);
		foreach ($periodsaverages as $key => $value) {
			$averagesintervales[$value] = $this->Diabet_model->getGlucoseValuesAverageCSV($value);
			foreach ($averagesintervales[$value][0] as $key2 => $value2) {
				$averagesintervales[$value][0][$key2] = intval($value2);
			}
			if ( count(array_filter($averagesintervales[$value][0])) != 0 ) {
				$data['averages'][$value] = round(array_sum($averagesintervales[$value][0])/count(array_filter($averagesintervales[$value][0])));
			} else {
				$data['averages'][$value] = " -- ";
			}
		}
		$data['glicemie_table'] = $this->dateTabel();
		$data['cookie_value'] = $this->input->cookie('period', TRUE);
		$this->view('user_area/home', $data);
	}


	/**
	* Edit access privilegges though tokens
	*/
	public function editarePrivilegii( $errortype = false ){
		if (!$this->ion_auth->in_group('pacient')){
			$this->view_error($this->lang->line('error_invalid_operation'));
		}
		if ( $errortype ) {
			$data['error_type'] = $this->lang->line('error_invalid_format');
		} else {
			$data['error_type'] = "";
		}
		$data['tokenList'] = $this->Diabet_model->getTokens();
		$data['token24h'] = $this->Diabet_model->getTokenCount24h();
		$this->view('user_area/editare_privilegii', $data, $this->outputFormat);
	}


	/**
	* Display tokens list
	*/
	public function listaPersoanelorAccess(){
		if (!$this->ion_auth->in_group('doctor') && $this->callType !== 'Token' ){
			$this->view_error($this->lang->line('error_invalid_operation'));
		}
		if ($this->callType == 'Token'){
			$data['pacienti'] = $this->Diabet_model->getListAccessByToken($this->get['token']);
		} else {
			$data['pacienti'] = $this->Diabet_model->getListAccessByEmail($this->ion_auth->user()->row()->email);
		}
		
		$this->view('user_area/listaAcces', $data);
	}

	
	/** 
	* Add access tokens 
	*/
	public function addToken(){
		if (!$this->ion_auth->in_group('pacient')){
			$this->view_error($this->lang->line('error_invalid_operation'));
		}
		// validate form 
		if ( $this->input->server('REQUEST_METHOD') !== 'POST' ) {
			redirect("diabet/editarePrivilegii", 'refresh');
		}
		$this->load->library('form_validation');
		$email = $this->input->post('email');
		$name_person = $this->input->post('name_person');
		$type_person = $this->input->post('type_person');

		if (!is_string($email) || !is_string($name_person) || !is_string($type_person) || !in_array($type_person, array('doctor', 'family')) ){
			$this->editarePrivilegii(true);
			return;
		}
		$this->form_validation->set_rules('email', $this->lang->line('dashboard_email_address_label'), 'required|valid_email|is_unique_email['.$email.']');
		$this->form_validation->set_rules('name_person', $this->lang->line('dashboard_name_token_label'), 'required');
		$this->form_validation->set_rules('type_person', $this->lang->line('dashboard_type_token_label'), 'required');
	
		// if form validation is true 
      	if ($this->form_validation->run() == FALSE) {
         	$this->editarePrivilegii();
      	} else {
      		$token = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 32);
      		$data = array(
      			$token,
	      		$email,
	      		$name_person,
	      		$type_person,
      	);

		    $this->Diabet_model->saveToken($data);
			
			// send mail to corespondant 
			$this->load->library('email', $this->config);

            $this->email->from($this->config->item('form_email'), $this->config->item('name_email'));
          	$this->email->to($email);
          	$this->email->subject($name_person);
          	$this->email->message($this->lang->line('email_sent_message').$token);

            try{
        	    $this->email->send();
              	redirect("diabet/editarePrivilegii", 'refresh');
          	}catch(Exception $e){
          	    echo $e->getMessage();
          	}

      	}

	}

	/**
	* Delete access token
	*/ 
	public function deleteToken($token){
		if (!$this->ion_auth->in_group('pacient')){
			$this->view_error($this->lang->line('error_invalid_operation'));
		}
		$this->Diabet_model->deleteToken($token);
		redirect("diabet/editarePrivilegii", 'refresh');
	}

	/**
	* Add glucose values (view)
	*/ 
	public function adaugareDateGlicemie($units = 8)
	{
		if (!$this->ion_auth->in_group('pacient')){
			$this->view_error($this->lang->line('error_invalid_operation'));
		}
		$data['page_title'] = $this->lang->line('dashboard_dashboard_label');
		$units_array = array(
    		'interval_1' => $this->lang->line('interval_1'),
        	'interval_7' => $this->lang->line('interval_7'),
        	'interval_9' => $this->lang->line('interval_9'),
        	'interval_10' => $this->lang->line('interval_10')
    	);
    	if ($units == 3){
			$units_array['interval_8'] = $this->lang->line('interval_8');
    	} else if ($units == 4){
			$units_array['interval_3'] = $this->lang->line('interval_3');
	        $units_array['interval_5'] = $this->lang->line('interval_5'); 
		} else {
			$units_array['interval_2'] = $this->lang->line('interval_2'); 
			$units_array['interval_3'] = $this->lang->line('interval_3'); 
			$units_array['interval_4'] = $this->lang->line('interval_4'); 
			$units_array['interval_5'] = $this->lang->line('interval_5'); 
			$units_array['interval_6'] = $this->lang->line('interval_6'); 
			$units_array['interval_8'] = $this->lang->line('interval_8'); 
		}
		$this->load->helper('sort_array');
		knatsort($units_array);
		$data['units'] = $units_array;

		// get data for current day edit glucose
		$glucose_value = $this->Diabet_model->getGlucoseValues();
		if ( !empty($glucose_value) ) {
			$this->load->library('form_validation'); 
			$data['interval_1'] = $glucose_value[0]['interval_1'];
			$data['interval_2'] = $glucose_value[0]['interval_2'];
			$data['interval_3'] = $glucose_value[0]['interval_3'];
			$data['interval_4'] = $glucose_value[0]['interval_4'];
			$data['interval_5'] = $glucose_value[0]['interval_5'];
			$data['interval_6'] = $glucose_value[0]['interval_6'];
			$data['interval_7'] = $glucose_value[0]['interval_7'];
			$data['interval_8'] = $glucose_value[0]['interval_8'];
			$data['interval_9'] = $glucose_value[0]['interval_9'];
			$data['interval_10'] = $glucose_value[0]['interval_10'];
			$data['notes'] = json_decode($glucose_value[0]['notes']);
			$data['glucose_values'] = TRUE;
			$data['notes_values'] = TRUE;
		} else {
			$data['glucose_values'] = FALSE;
			$data['notes_values'] = FALSE;
		}
		$this->view('user_area/adaugare_date_glicemie', $data);
	}


	/**
	* save glucose values
	*/ 
	public function salvareDateGlicemie()
	{
		if (!$this->ion_auth->in_group('pacient')){
			$this->view_error($this->lang->line('error_invalid_operation'));
		}
		$this->load->library('form_validation'); 

		$array = $this->input->post();
		// create array of expected input values
		for ($i = 1; $i <= 10; $i++){
			$array_intervals["interval_$i"] = '0';
			$array_notes["interval_{$i}_nota"] = '';
		}

		// map actual input values with expected values
		foreach ($array as $key => $value) {
			if (array_key_exists($key, $array_intervals) && !empty($value)) {
				$array_intervals[$key] = intval($value);
			}
			if (array_key_exists($key, $array_notes)) {
				$array_notes[$key] = is_string($value) ? $value : "";
			}
		}

		$units = count($this->input->post('count')) - 2;

		if ( implode($array_intervals) == "0000000000" ) {
			$this->form_validation->set_rules('interval_1', $this->lang->line('dashboard_glucose_value_label'), 'required');
			$this->form_validation->set_message('required', $this->lang->line('error_value_glucose_required'));
		} else if ( implode($array_notes) != "" ) {
			foreach ($array_notes as $key => $value) {
				if( !empty($value) && $array_intervals[substr($key, 0, -5)] == "0" ) {
					$this->form_validation->set_rules(substr($key, 0, -5), $this->lang->line('dashboard_glucose_value_label'), 'required');
					$this->form_validation->set_message('required', $this->lang->line('error_note_whithout_glucose_required'));
				} else {
					$this->form_validation->set_rules(substr($key, 0, -5), $this->lang->line('dashboard_glucose_value_label'), 'numeric|greater_than[0]');
				}
			}
		} else {
			foreach ($array_intervals as $key => $value) {
				$this->form_validation->set_rules($key, $this->lang->line('dashboard_glucose_value_label'), 'numeric|greater_than[0]');
			}
		} 
      	if ($this->form_validation->run() == FALSE) {
         	$this->adaugareDateGlicemie($units);
      	} else {
      		$data = array(
      			$array_intervals,
	      		$array_notes,
	      	);
	      	$this->Diabet_model->salveazaDateGlicemie($data);
	      	redirect("diabet/dateDiabet", 'refresh');
      	}
		
		
	}

	// ion auth csrf
	public function _get_csrf_nonce()
	{
		$this->load->helper('string');
		$key   = random_string('alnum', 8);
		$value = random_string('alnum', 20);
		$this->session->set_flashdata('csrfkey', $key);
		$this->session->set_flashdata('csrfvalue', $value);

		return array($key => $value);
	}

	/**
	* Glucose values for table display
	*/ 
	public function dateTabel(){
        $period = intval($this->input->cookie('period', TRUE));
        if (!in_array($period, array(7, 30, 60, 90, 120, 360))){
        	$period = 7;
        }
		$data = $this->Diabet_model->getGlucoseValues($period);
		foreach ($data as $key => &$value) {
			$value = array_merge($value, (array)json_decode($value['notes']));
			unset($data[$key]['notes']);
		}
		return $data;
	}

	/**
	* Glucose values for graphic display
	*/
	public function dateGrafic(){
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
        $period = intval(@$_POST['period']);
        if (!in_array($period, array(7,30,60,90,120,360))){
        	$period = 7;
        }

        $cookie = array(
		    'name'   => 'period',
	        'value'  => $period,
	        'expire' => '86500',
		);
        $this->input->set_cookie($cookie);

		$data = $this->Diabet_model->getGlucoseValues($period, 'array', 'ASC');
		if (!empty($data)){
			$coloanaHeader = array_keys($data[0]);
			array_unshift($data, array_combine($coloanaHeader, $coloanaHeader));
	
			foreach ($data as $key => $value) {
				unset($data[$key]['notes']);
			}

			array_splice($data, 1, 0, array(array()));
			foreach ($data[0] as $key => $value) {
				$data[0][$key] = $this->lang->line("$value");
				$data[1][$key] = '100';
				$data[0]['hipoglicemiei'] = $this->lang->line('hipoglicemie');
				$data[0]['hiperglicemiei'] = $this->lang->line('hiperglicemie');
			}
			
			foreach ($data as $key => $value) {
				if ( $key != 0 ) {
					$data[$key]['hipoglicemiei'] = 70;
					$data[$key]['hiperglicemiei'] = 110;
				}
			}
		} else {
			$data = "";
		}

        $this->output->set_content_type('application/json')
             ->set_output(json_encode($data));
	}

	/**
	* Display tokens list
	*/
	public function listaUtilizatori($offset = null ){

        $config['base_url'] = base_url().'diabet/listaUtilizatori';
        $config['total_rows'] = $this->db->select('id')->from('users')->get()->num_rows();

        //config for bootstrap pagination class integration
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        // limit from database
        $config['per_page'] = 4;
        $config['num_links'] = 1;

        $this->load->library('pagination');
        $this->pagination->initialize($config);
		
		$data['users'] = $this->Diabet_model->getAllUsers($offset, $config['per_page']);
        $data['offset'] = $offset;
		$this->view('user_area/listaUtilizatori', $data);
	}

# ============== BEGIN EXPORT ============= #

	/**
	* Export glucose values into excel
	*/
	public function exportExcel() {
	    $this->load->library('excel');
		$data = $this->Diabet_model->getGlucoseValues($this->input->cookie('period', TRUE));
		if (!empty($data)){
			$coloanaHeader = array_keys($data[0]);
			array_unshift($data, array_combine($coloanaHeader, $coloanaHeader));
		}
		foreach ($data as $key => $value) {
			unset($data[$key]['notes']);
		}

		foreach ($data[0] as $key => $value) {
			$titles[$key] = $this->lang->line("$value");
		}

		unset($data[0]);

		$name = $this->Diabet_model->getPacientName();
	    $this->excel->filename = $name[0]->first_name."_".$name[0]->last_name."_".date('Y-m-d_h:i:s');
	    
	    // print_r($data);exit();
	    $this->excel->make_from_array($titles, $data);
	}

	/**
	* Export glucose values into csv
	*/
	public function exportCsv()
	{
        $this->load->dbutil();
        $this->load->helper('file');
        $this->load->helper('download');
        $delimiter = ",";
        $newline = "\r\n";
        $name = $this->Diabet_model->getPacientName();
    	$filename = $name[0]->first_name."_".$name[0]->last_name."_".date('Y-m-d_h:i:s').".csv";
        
        $result = $this->Diabet_model->getGlucoseValues($this->input->cookie('period', TRUE), 'query');
        $data = $this->dbutil->csv_from_result($result, $delimiter, $newline);
        force_download($filename, $data);
	}

# ============== END EXPORT ============= #


# ============== BEGIN NEWS POSTS ============= #

	/**
	* Add new post (view)
	*/ 
	public function addPost($post_id = null)
	{
		if ( $post_id ) {
			$data['id'] = $post_id;
			$data['post'] = $this->Diabet_model->getEditDatePost($post_id);
			$this->view('user_area/adaugare_post',$data);
		} else {
			$data['id'] = false;
			$data['post'] = false;
			$this->view('user_area/adaugare_post',$data);
		}
	}

	/**
	* Save a post (new/edit)
	*/ 
	public function salvarePost()
	{
		if ( $this->input->server('REQUEST_METHOD') !== 'POST' ) {
			$this->addPost();
		}

		$title = @$_POST['title'];
		$content = base64_encode(@$_POST['textarea']);
		$featured = @$_POST['featured'];
		$post_id = intval(@$_POST['post_id']);

		$this->Diabet_model->salveazaDatePost($post_id, $title, $content, $featured);

	}

	/**
	* Display posts list
	*/
	public function listPosts()
	{
		$data['posts'] = $this->Diabet_model->getPosts();
		$this->view('user_area/listare_posturi', $data);
	}

	/**
	* Delete post
	*/ 
	public function deletePost($post_id)
	{
		$id = intval($post_id);
		$this->Diabet_model->deletePosts($id);
		$this->listPosts();

	}
# ============== END NEWS POSTS ============= #

}
