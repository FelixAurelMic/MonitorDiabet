<?php defined('BASEPATH') OR exit('No direct script access allowed');

class General extends SVS_Controller
{
 /**
  * @author demis
  * set language
  */
    public function set_language()
    {
        $this->load->helper('languages');

        if ( $this->input->server('REQUEST_METHOD') !== 'POST' ){
            exit();
        }

        $lang = ucfirst($this->input->post('lang'));
        if (in_array($lang, get_languages())){
            set_language_cookie($lang);    
        }
        

        redirect($this->input->post('curent_url'));
    }
}