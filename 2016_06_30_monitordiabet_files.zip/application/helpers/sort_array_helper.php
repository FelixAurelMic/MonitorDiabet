<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @author demis
 * Sort array by key
 * @return array
 */

function knatsort(&$arr){
	return uksort($arr, function($a, $b){
		return strnatcmp($a,$b);
	});
}
