<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @author demis
 * Convert an array to SimpleXMLObject
 * @return array || FALSE
 */
function array_to_xml(array $arr, SimpleXMLElement $xml)
{
    foreach ($arr as $k => $v) {
        is_array($v)
            ? array_to_xml($v, $xml->addChild($k))
            : $xml->addChild($k, $v);
    }
    return $xml;
}