<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @author demis
 * Get all languages
 * @return array || FALSE
 */
function get_languages()
{
	$files = array_values( array_diff( scandir(APPPATH . 'language'), array('..', '.', 'index.html') ) );

	foreach($files as $key => $value){
		$files[$key] = ucfirst($value);
	}

	return $files;
}

function set_language_cookie($language){
	$cookie = array(
        'name'   => 'svs_language',
        'value'  => ucfirst($language),
        'expire' => COOKIE_EXPIRATION,
        'path'   => '/'
    );

    set_cookie($cookie);

}