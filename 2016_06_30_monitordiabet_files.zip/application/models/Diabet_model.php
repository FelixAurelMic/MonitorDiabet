<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Diabet_model extends SVS_Model {
	
	/**
	* Check API key in database
	*/
	public function checkApi($apiKey){
		$result = $this->db->query("
			SELECT 
				`id`
			FROM 
				`users`
			WHERE 
				`apikey` = ?
			LIMIT 1
		", $apiKey);

		if ($result->num_rows() == 0){
			return false;
		}

		return $result->row()->id;

	}

	/**
	* Check token in database
	*/
	public function checkToken($token){
		$result = $this->db->query("
			SELECT 
				`fk_user`
			FROM 
				`tokens`
			WHERE 
				`token` = ?
			LIMIT 1
		", $token);

		if ($result->num_rows() == 0){
			return false;
		}

		return $result->row()->fk_user;
	}

	/**
	* Get list of active tokens for current user
	*/
	public function getTokens($limit = 30, $offset = 0){
		$count = $this->db->query("
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_is_active` = 1
			", USER_ID
		);
		$count = $count->row()->total;


		$result = $this->db->query("
			SELECT
				`token`,
				`fk_user`,
				`name`,
				`email`,
				`type`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_is_active` = 1
			LIMIT $offset, $limit
			", USER_ID
		);

		return array(
			'total' => $count,
			'data' => $result->result_array()
		);
	}

    /**
    * Get how many tokens were modified during last 24h
    */
	public function getTokenCount24h(){
		$last24h = $this->db->query("
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_create_date` > DATE_SUB(NOW(), INTERVAL 24 HOUR)
			", USER_ID
		);
		$last24h = $last24h->row()->total;

		return array(
			'last24h' => $last24h
		);
	}


    /*
     * @author Demis
     * function for save data from tokens form to database
     *   @param data with all fields from post
     */
	public function saveToken($data){
        $this->db->query("
        INSERT INTO 
        	`tokens`
        SET
            `token` = ?,
            `fk_user` = ?,
            `name` = ?,
            `email` = ?,
            `type` = ?,
            `_is_active` = 1
        ", array($data[0], USER_ID, $data[2], $data[1], $data[3]));
	}


	/*
    * @author Demis
    * function to check unique email for patient
    *   @param $email
    */
	public function checkEmail($email) {

    	$query = $this->db->query("
    		SELECT 
    			`email` 
    		FROM 
    			`tokens` 
    		WHERE 
    			`fk_user` = ? 
    		AND 
    			`email` = ? 
        ", array(USER_ID, $email) );

    	if ($query->num_rows() > 0) {
	        return TRUE;
	    } else{
	        return FALSE;
	    } 

    }

	/*
    * @author Demis
    * Delete access token
    *   @param $email
    */
	public function deleteToken($token) {
    	$this->db->where('token', $token);
    	$this->db->where('fk_user', USER_ID);
    	$this->db->limit(1);
    	$this->db->delete('tokens'); 
    }


    /**
    * Get user information
    */ 
    function getUserData(){
		$query = $this->db->query("
    		SELECT 
    			`first_name`,
    			`last_name`,
    			`phone`,
    			`sex`,
    			`age`,
    			`diabetes_type`,
    			`diabetes_period`,
    			`treatment`
    		FROM 
    			`users` 
    		WHERE 
    			`id` = '" . USER_ID . "'
    		LIMIT 1
    		");
    	return $query->row_object(); 	
    }

    /**
    * Lista cu persoanele a caror conturi poate fi vizualizat prin token
    */
    function getListAccessByToken($token = '', $limit = 30, $offset = 0){
    	$query = $this->db->query("
    		SELECT 
    			t1.first_name,
                t1.last_name,
                t1.email,
                t2.token
    		FROM 
    			`users` as t1 
            JOIN 
                `tokens` as t2
            ON 
                t1.id = t2.fk_user
    		WHERE 
    			t2.email = (
    					SELECT 
    						`email` 
    					FROM
    						`tokens`
    					WHERE
    						`token` = ?
    					LIMIT 1
    				)
    		
    		LIMIT $offset, $limit
    		", $token);
    	   
    	return $query->result_array();
    }
    /**
    * Lista cu persoanele a caror conturi poate fi vizualizat prin email
    */
    function getListAccessByEmail($email = '', $limit = 30, $offset = 0){

        $query = $this->db->query("
            SELECT 
                t1.first_name,
                t1.last_name,
                t1.email,
                t2.token
            FROM 
                `users` as t1 
            JOIN 
                `tokens` as t2
            ON 
                t1.id = t2.fk_user
            WHERE 
                t2.email = ?
            LIMIT $offset, $limit
            ", $email);
           
        return $query->result_array();
    }

    /**
    * Lista cu persoanele a caror conturi poate fi vizualizat
    */

    function salveazaDateGlicemie($data){
        $values = array(
            USER_ID, 
            json_encode($data[1])
        );
        $values = array_values(array_merge($values, $data[0]));
        $values = array_merge($values, $values);

        $table_name = ceil(USER_ID/1000)."_glicemie";

        $query = $this->db->query("
            INSERT INTO $table_name 
                ( `fk_user`, `notes`, `date`, `interval_1`, `interval_2`, `interval_3`, `interval_4`, `interval_5`, `interval_6`, `interval_7`, `interval_8`, `interval_9`, `interval_10` ) 
            VALUES
                ( ?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )
            ON DUPLICATE KEY UPDATE
                `fk_user` = ?,
                `notes` = ?,
                `interval_1` = ?,
                `interval_2` = ?,
                `interval_3` = ?,
                `interval_4` = ?,
                `interval_5` = ?,
                `interval_6` = ?,
                `interval_7` = ?,
                `interval_8` = ?,
                `interval_9` = ?,
                `interval_10` = ?
        ", $values);
    }

    /*
    * @author Demis
    * Get Glucose values for export excel
    */
    function getGlucoseValues($period = 1, $output = 'array', $order = 'DESC'){
        $table_name = ceil(USER_ID/1000)."_glicemie";
        $query = $this->db->query("
            SELECT 
                `date`,
                `interval_1`,
                `interval_2`,
                `interval_3`,
                `interval_4`,
                `interval_5`,
                `interval_6`,
                `interval_7`,
                `interval_8`,
                `interval_9`,
                `interval_10`,
                `notes`             
            FROM 
                $table_name 
            WHERE 
                `fk_user` = " . USER_ID . ".
            AND 
                ".( $period === 1 ? "DATE(`date`) >= CURDATE()" : "DATE(`date`) >= (NOW() - INTERVAL $period DAY)") . "
            ORDER BY 
                DATE(`date`) $order
            LIMIT
                $period
            
        ");
        if ($output == 'array'){
            return $query->result_array();    
        } else {
            return $query;
        }
        
    }

    /*
    * @author Demis
    * Get patient post
    */
    function getPacientName(){
        $query = $this->db->query("
            SELECT 
                `first_name`,
                `last_name`
            FROM 
                `users`
            WHERE 
                `id` = ?
            LIMIT 1
        ", USER_ID);

        return $query->result();
    }

    /*
    * @author Demis
    * Get averrages values
    *   @param period
    */
    function getGlucoseValuesAverageCSV($period){
        $table_name = ceil(USER_ID/1000)."_glicemie";
        $query = $this->db->query("
            SELECT 
                AVG(NULLIF(interval_1 ,0)),
                AVG(NULLIF(interval_2 ,0)),
                AVG(NULLIF(interval_3 ,0)),
                AVG(NULLIF(interval_4 ,0)),
                AVG(NULLIF(interval_5 ,0)),
                AVG(NULLIF(interval_6 ,0)),
                AVG(NULLIF(interval_7 ,0)),
                AVG(NULLIF(interval_8 ,0)),
                AVG(NULLIF(interval_9 ,0)),
                AVG(NULLIF(interval_10 ,0))          
            FROM 
                $table_name 
            WHERE 
                `fk_user` = " . USER_ID . ".
            AND 
                DATE(`date`) > (NOW() - INTERVAL $period DAY)
            LIMIT
                $period
        ");
        return $query->result_array();
    }

    /*
    * @author Demis
    * Save post
    *   @param post_id, title, content, featured
    */
    function salveazaDatePost($id, $title, $content, $featured){
        $this->db->query("
            INSERT INTO 
                `posts`
            SET
                `id` = ?,
                `title` = ?,
                `content` = ?,
                `featured` = ?

            ON DUPLICATE KEY UPDATE
                `title` = ?,
                `content` = ?,
                `featured` = ?                
            ", array($id, $title, $content, $featured, $title, $content, $featured)
        );
    }

    /*
    * @author Demis
    * List posts
    *   @param post_id
    */
    function getPosts($featured = null){
        $query = $this->db->query("
            SELECT 
                `id`,
                `title`,
                `content`,
                `featured`,
                `_create_date`             
            FROM 
                `posts` 
                ".( $featured === 1 ? " WHERE `featured` = 1" : "" ) . "
            ORDER BY 
                DATE(`_create_date`) ASC    
        ");
        return $query->result_array();
    }

    /*
    * @author Demis
    * Edit post
    *   @param post_id
    */
    function getEditDatePost($id){
        $query = $this->db->query("
            SELECT 
                `title`,
                `content`,
                `featured`
            FROM 
                `posts`
            WHERE 
                `id` = ?
            LIMIT 1
        ", $id);

        return $query->result_array();
    }

    /*
    * @author Demis
    * Delete post
    *   @param post_id
    */
    public function deletePosts($id) {
        $this->db->where('id', $id);
        $this->db->limit(1);
        $this->db->delete('posts'); 
    }

    /**
    * Get user information
    */ 
    function getAllUsers($offset, $limit){
        $query = $this->db->query("
            SELECT 
                t1.id,
                t1.first_name,
                t1.last_name,
                t1.email,
                t2.token
            FROM 
                `users` as t1  
            LEFT JOIN 
                `tokens` as t2
            ON 
                t1.id = t2.fk_user  
            GROUP BY t1.id 
            LIMIT "
            .$offset. (empty($offset) ? "" : ",") .$limit
            );

        return $query->result_array();    
    }
}

