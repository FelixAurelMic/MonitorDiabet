<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

// General Errors
$lang['error_page_title'] = 'Eroare';
$lang['error_general_title'] = 'Eroare';
$lang['error_general_message'] = 'Mesaj Eroare.';

// Database Errors
$lang['error_db_title'] = 'DB Eroare  Titlu.';
$lang['error_db_message'] = 'DB Mesaj Eroare.';