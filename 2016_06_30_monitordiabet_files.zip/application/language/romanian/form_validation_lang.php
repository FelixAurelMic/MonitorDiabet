<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_validation_required']		= ' Câmpul "{field}" este obigatoriu.';
$lang['form_validation_isset']			= 'Câmpul {field} trebuie să fie completat.';
$lang['form_validation_valid_email']		= 'Câmpul {field} trebuie să conțină un email valid.';
$lang['form_validation_valid_emails']		= 'Câmpul {field} trebuie să conțină adrese de email valide.';
$lang['form_validation_valid_url']		= 'Câmpul {field} trebuie să conțină un URL valid.';
$lang['form_validation_valid_ip']		= 'Câmpul {field} trebuie să conțină un IP valid.';
$lang['form_validation_min_length']		= 'Câmpul {field} trebuie să conțină o lungime minimă de {param} caractere.';
$lang['form_validation_max_length']		= 'Câmpul {field} nu poate depăși numarul de {param} caractere.';
$lang['form_validation_exact_length']		= 'Câmpul {field} trebuie să conțină exact {param} caractere.';
$lang['form_validation_alpha']			= 'Câmpul {field} trebuie să conțină doar litere.';
$lang['form_validation_alpha_numeric']		= 'Câmpul {field} trebuie să conțină doar litere și numere.';
$lang['form_validation_alpha_numeric_spaces']	= 'Câmpul {field} trebuie să conțină doar litere, numere și spații.';
$lang['form_validation_alpha_dash']		= 'Câmpul {field} trebuie să conțină doar litere, numere, underscoruri si slash-uri.';
$lang['form_validation_numeric']		= 'Câmpul {field} trebuie să conțină doar numere.';
$lang['form_validation_is_numeric']		= 'Câmpul {field} trebuie să conțină doar caractere numerice.';
$lang['form_validation_integer']		= 'Câmpul {field} trebuie să fie întreg.';
$lang['form_validation_regex_match']		= 'Câmpul {field} nu are formatul corect.';
$lang['form_validation_matches']		= 'Câmpul {field} trebuie să fie identic cu  câmpul {param}.';
$lang['form_validation_differs']		= 'Câmpul {field} trebuie să fie diferit de  câmpul {param}.';
$lang['form_validation_is_unique'] 		= 'Câmpul {field} trebuie să conțină o valoare unică.';
$lang['form_validation_is_natural']		= 'Câmpul {field} trebuie să conțină doar cifre.';
$lang['form_validation_is_natural_no_zero']	= 'Câmpul {field} trebuie să conțină doar cifre mai mari decât 0.';
$lang['form_validation_decimal']		= 'Câmpul {field} trebuie să conțină un număr decimal.';
$lang['form_validation_less_than']		= 'Câmpul {field} trebuie să conțină un număr mai mic decât {param}.';
$lang['form_validation_less_than_equal_to']	= 'Câmpul {field} trebuie să conțină un număr mai mic sau egal cu {param}.';
$lang['form_validation_greater_than']		= 'Câmpul {field} trebuie să conțină un număr mai mare decât {param}.';
$lang['form_validation_greater_than_equal_to']	= 'Câmpul {field} trebuie să conțină un număr mai mare sau egal cu {param}.';
$lang['form_validation_error_message_not_set']	= 'Nu a fost găsit nici un mesaj de eroare pentru câmpul {field}.';
$lang['form_validation_in_list']		= 'Câmpul {field} trebuie să conțină una dintre valorile predefinite: {param}.';
$lang['form_validation_unique_email_custom']		= 'Deja aveți in lista dumneavoastră o persoană cu acest email.';
$lang['error_captcha']		= 'Deja aveți in lista dumneavoastră o persoană cu acest email.';
$lang['error_captcha']  = 'Codul introdus nu este corect.';