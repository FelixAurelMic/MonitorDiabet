<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Dashboard
$lang['dashboard_dashboard_label'] = 'Date Diabet';
$lang['dashboard_glucose_tabel'] = 'Date Glicemii in funcție de perioadă';
$lang['dashboard_complete_glucose_label'] = 'Vă rugăm să introduceți valorile glicemice (zi curentă)';
$lang['dashboard_access_add_label'] = 'Vă rugăm să introduceți o persoană care poate să acceseze datele dumneavoastră';
$lang['dashboard_access_added_label'] = 'Listă responsabili pentru starea dumneavoastră';
$lang['dashboard_patients_label'] = 'Lista de access';
$lang['dashboard_users_list_label'] = 'Lista utilizatori';
$lang['dashboard_informations_label'] = 'Informaţii';
$lang['dashboard_change_password_label'] = 'Schimbă parola cont';
$lang['dashboard_profile_label'] = 'Profil';
$lang['dashboard_access_label'] = 'Acces la date';
$lang['dashboard_users_label'] = 'Utilizatori sistem';
$lang['dashboard_logout_label'] = 'Logout';
$lang['dashboard_hello_label'] = 'Buna';
$lang['dashboard_number_label'] = 'Număr';
$lang['dashboard_glucose_value_label'] = 'Valoare Glicemie mg/dL';
$lang['dashboard_time_label'] = 'Timp';
$lang['dashboard_date_label'] = 'Dată';
$lang['dashboard_notes_label'] = 'Notă';
$lang['dashboard_save_label'] = 'Afișează grafic';
$lang['dashboard_save_access_label'] = 'Acordă permisiune';
$lang['dashboard_action_label'] = 'Acţiune';
$lang['dashboard_unity_label'] = ' mg/dL';
$lang['dashboard_select_unity_label'] = '- Selectează Interval -';
$lang['dashboard_select_person_label'] = '- Selectează Persoană -';
$lang['dashboard_token_label'] = 'Token';
$lang['dashboard_name_token_label'] = 'Nume';
$lang['dashboard_statut_label'] = 'Rol';
$lang['dashboard_email_address_label'] = 'Adresă Email';
$lang['dashboard_type_token_label'] = 'Tip Persoană';
$lang['dashboard_action_delete_label'] = 'Șterge Token';
$lang['dashboard_pacient_label'] = 'Pacient';
$lang['dashboard_doctor_label'] = 'Doctor';
$lang['dashboard_family_label'] = 'Familie';
$lang['dashboard_grafic_glucose_label'] = 'Grafic Date Glicemie';
$lang['error_value_glucose_required'] = 'Trebuie să fie completată cel puţin o valoare din câmpul Valoare Glicemie';
$lang['error_note_whithout_glucose_required'] = 'Trebuie să fie completată Valoare Glicemie din dreptul notei completate';

// Time unity - 8 (10)
// $lang['interval_1'] = 'înainte de mic dejun';
// $lang['interval_2'] = 'după mic dejun';
// $lang['interval_3'] = 'înainte de prânz';
// $lang['interval_4'] = 'după prânz';
// $lang['interval_5'] = 'înainte de cină';
// $lang['interval_6'] = 'după cină';
// $lang['interval_7'] = 'înainte de culcare';
// $lang['interval_8'] = 'noaptea la ora 3';
// $lang['interval_9'] = 'după gustare';
// $lang['interval_10'] = 'după efort fizic';
$lang['interval_1'] = 'inainte de mic dejun';
$lang['interval_2'] = 'dupa mic dejun';
$lang['interval_3'] = 'inainte de pranz';
$lang['interval_4'] = 'dupa pranz';
$lang['interval_5'] = 'inainte de cina';
$lang['interval_6'] = 'dupa cina';
$lang['interval_7'] = 'inainte de culcare';
$lang['interval_8'] = 'noaptea la ora 3';
$lang['interval_9'] = 'dupa gustare';
$lang['interval_10'] = 'dupa efort fizic';

// Send email 
$lang['email_sent_message'] = "Buna ziua! <br> In calitate de pacient va trimit un link de unde puteti vedea starea mea. Pentru a intra pe platforma accesati link-ul:". base_url() ."diabet/dateDiabet?token=";
$lang['dashboard_limit_tokens_label'] = 'Limita maximă de token-uri pe zi sau totală a fost atinsă';

$lang['dashboard_select_unity_label'] = 'Tipul măsurătorilor';
$lang['dashboard_select_unity_type_label'] = 'Tipul glicemiei';
$lang['dashboard_select_unity_button'] = 'Selectați';
$lang['dashboard_8_units_button'] = 'Profil glicemic';
$lang['dashboard_4_units_button'] = 'Diabet de tip I';
$lang['dashboard_3_units_button'] = 'Diabet de tip II';

$lang['terms_conditions'] = 'Termeni de Utilizare';
$lang['terms_description'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';
$lang['close_btn'] = 'Închide';
$lang['how_it_works'] = 'Ghid de Utilizare';
$lang['works_description'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';

$lang['date'] = 'Data';
$lang['no_data_period'] = 'Nu există date pentru această perioadă, vă rugăm selectați un alt interval dacă aveți date introduse deja pentru grafic.';

$lang['average_label'] = 'Medie valori glicemie / Zile (mg/dL)';
$lang['7_day_period'] = '7 Zile';
$lang['30_day_period'] = '30 Zile';
$lang['60_day_period'] = '60 Zile';
$lang['90_day_period'] = '90 Zile';
$lang['120_day_period'] = '120 Zile';
$lang['360_day_period'] = '360 Zile';

$lang['hipoglicemie'] = 'Hipoglicemie';
$lang['hiperglicemie'] = 'Hiperglicemie';
$lang['add_post'] = 'Adăugare Post';
$lang['list_posts'] = 'Posturi';
$lang['dashboard_post_title_label'] = 'Titlu Post';
$lang['dashboard_post_content_label'] = 'Conținut Post';
$lang['dashboard_post_featured_label'] = 'Categorie';
$lang['dashboard_error_empty_fields'] = 'Vă rugăm să completați câmpurile titlu și continuț';
$lang['dashboard_diabetes_news_display'] = 'Noutăți Diabet';
$lang['dashboard_platform_news_display'] = 'Noutăți Platformă';
$lang['read_more'] = 'Mai Mult';
$lang['no_post'] = 'Nu a fost găsit nici un articol';