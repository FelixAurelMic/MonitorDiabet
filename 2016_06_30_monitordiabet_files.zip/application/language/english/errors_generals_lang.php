<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

// General Errors
$lang['error_page_title'] = 'Error';
$lang['error_general_title'] = 'Error';
$lang['error_general_message'] = 'Message Error.';

// Database Errors
$lang['error_db_title'] = 'DB Error Title.';
$lang['error_db_message'] = 'DB Message Error.';