<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Dashboard
$lang['dashboard_dashboard_label'] = 'Dashboard';
$lang['dashboard_glucose_tabel'] = 'Glucose data by period';
$lang['dashboard_complete_glucose_label'] = 'Please insert your blood glucose values (current day )';
$lang['dashboard_access_add_label'] = 'Please add a person who can view your data';
$lang['dashboard_access_added_label'] = 'Tokens List';
$lang['dashboard_patients_label'] = 'Patients';
$lang['dashboard_users_list_label'] = 'List users';
$lang['dashboard_informations_label'] = 'Informations';
$lang['dashboard_change_password_label'] = 'Change Password';
$lang['dashboard_profile_label'] = 'Profile';
$lang['dashboard_access_label'] = 'Access';
$lang['dashboard_logout_label'] = 'Logout';
$lang['dashboard_hello_label'] = 'Hello';
$lang['dashboard_number_label'] = 'Number';
$lang['dashboard_glucose_value_label'] = 'Blood Glucose Value mg/dL';
$lang['dashboard_time_label'] = 'Time';
$lang['dashboard_date_label'] = 'Date';
$lang['dashboard_notes_label'] = 'Notes';
$lang['dashboard_save_label'] = 'Save';
$lang['dashboard_save_access_label'] = 'Allow permision';
$lang['dashboard_action_label'] = 'Action';
$lang['dashboard_unity_label'] = ' mg/dL';
$lang['dashboard_select_unity_label'] = '- Select Interval -';
$lang['dashboard_select_person_label'] = '- Select Person -';
$lang['dashboard_token_label'] = 'Token';
$lang['dashboard_name_token_label'] = 'Name';
$lang['dashboard_statut_label'] = 'Role';
$lang['dashboard_email_address_label'] = 'Email Address';
$lang['dashboard_type_token_label'] = 'Type Person';
$lang['dashboard_action_delete_label'] = 'Delete Token';
$lang['dashboard_pacient_label'] = 'Patient';
$lang['dashboard_doctor_label'] = 'Doctor';
$lang['dashboard_family_label'] = 'Family';
$lang['dashboard_grafic_glucose_label'] = 'Graphic Dates Glucose';
$lang['error_value_glucose_required'] = 'The field Blood Glucose Value must have at least one value completed.';
$lang['error_note_whithout_glucose_required'] = 'The field Blood Glucose Value is required for the completed notes';

// Time unity - 8 (10)
$lang['interval_1'] = 'before breakfast';
$lang['interval_2'] = 'after breakfast';
$lang['interval_3'] = 'before lunch';
$lang['interval_4'] = 'after lunch';
$lang['interval_5'] = 'before dinner';
$lang['interval_6'] = 'after dinner';
$lang['interval_7'] = 'before bedtime';       
$lang['interval_8'] = '3am';
$lang['interval_9'] = 'after snack';
$lang['interval_10'] = 'after workout';

// Send email 
$lang['email_sent_message'] = "Hello! <br>  As a patient I was sending you a link from where you can see my details. You can access the platform with the link:". base_url() ."diabet/dateDiabet?token=";
$lang['dashboard_limit_tokens_label'] = 'Upper limit tokens per day or total reached';

$lang['dashboard_select_unity_label'] = 'Select glucose units';
$lang['dashboard_select_unity_type_label'] = 'Glycemic type';
$lang['dashboard_select_unity_button'] = 'Select';
$lang['dashboard_8_units_button'] = 'Profile glycemic';
$lang['dashboard_4_units_button'] = 'Diabetes type I';
$lang['dashboard_3_units_button'] = 'Diabetes type II';

$lang['terms_conditions'] = 'Disclaimer';
$lang['terms_description'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';
$lang['close_btn'] = 'Close';
$lang['how_it_works'] = 'User Guide';
$lang['works_description'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.';

$lang['date'] = 'Date';
$lang['no_data_period'] = 'no data found for this period, please select another interval if you have data saved for graphic.';

$lang['average_label'] = 'Average glucose values / Days (mg/dL)';
$lang['7_day_period'] = '7 Days';
$lang['30_day_period'] = '30 Days';
$lang['60_day_period'] = '60 Days';
$lang['90_day_period'] = '90 Days';
$lang['120_day_period'] = '120 Days';
$lang['360_day_period'] = '360 Days';

$lang['hipoglicemie'] = 'Hypoglycemia';
$lang['hiperglicemie'] = 'Hyperglycemia';
$lang['add_post'] = 'Add Post';
$lang['list_posts'] = 'Posts';
$lang['dashboard_post_title_label'] = 'Post Title';
$lang['dashboard_post_content_label'] = 'Content Post';
$lang['dashboard_post_featured_label'] = 'Category';
$lang['dashboard_error_empty_fields'] = 'Please complete the title and the content area';
$lang['dashboard_diabetes_news_display'] = 'Diabetes News';
$lang['dashboard_platform_news_display'] = 'Platform News';
$lang['read_more'] = 'Read More';
$lang['no_post'] = 'No post found here';