<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_Install_all_tables extends CI_Migration {

	public function up()
	{
		// Drop table 'groups' if it exists
		$this->dbforge->drop_table('groups', TRUE);

		// Table structure for table 'groups'
		$this->dbforge->add_field(array(
			'id' => array(
				'type' => 'MEDIUMINT',
				'constraint' => '8',
				'unsigned' => TRUE,
				'auto_increment' => TRUE
			),
			'name' => array(
				'type' => 'VARCHAR',
				'constraint' => '20',
			),
			'description' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
			),
		));
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('groups');

		// Dumping data for table 'groups'
		$data = array(
			array(
				'id' => '1',
				'name' => 'admin',
				'description' => 'Administrator'
			),
			array(
				'id' => '2',
				'name' => 'doctor',
				'description' => 'Doctor'
			),
			array(
				'id' => '3',
				'name' => 'pacient',
				'description' => 'Pacient'
			),
		);
		$this->db->insert_batch('groups', $data);


		// Drop table 'users' if it exists
		$this->dbforge->drop_table('users', TRUE);

		// Table structure for table 'users'
		$this->dbforge->add_field(array(
			'id' => array(
				'type' => 'MEDIUMINT',
				'constraint' => '8',
				'unsigned' => TRUE,
				'auto_increment' => TRUE
			),
			'ip_address' => array(
				'type' => 'VARCHAR',
				'constraint' => '16'
			),
			'username' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
			),
			'password' => array(
				'type' => 'VARCHAR',
				'constraint' => '80',
			),
			'salt' => array(
				'type' => 'VARCHAR',
				'constraint' => '40'
			),
			'email' => array(
				'type' => 'VARCHAR',
				'constraint' => '100'
			),
			'activation_code' => array(
				'type' => 'VARCHAR',
				'constraint' => '40',
				'null' => TRUE
			),
			'forgotten_password_code' => array(
				'type' => 'VARCHAR',
				'constraint' => '40',
				'null' => TRUE
			),
			'forgotten_password_time' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'remember_code' => array(
				'type' => 'VARCHAR',
				'constraint' => '40',
				'null' => TRUE
			),
			'created_on' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
			),
			'last_login' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'active' => array(
				'type' => 'TINYINT',
				'constraint' => '1',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'first_name' => array(
				'type' => 'VARCHAR',
				'constraint' => '50',
				'null' => TRUE
			),
			'last_name' => array(
				'type' => 'VARCHAR',
				'constraint' => '50',
				'null' => TRUE
			),
			'company' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'null' => TRUE
			),
			'phone' => array(
				'type' => 'VARCHAR',
				'constraint' => '20',
				'null' => TRUE
			),
			'age' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'sex' => array(
				'type' => 'VARCHAR',
				'constraint' => '255',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'diabetes_type' => array(
				'type' => 'VARCHAR',
				'constraint' => '255',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'diabetes_period' => array(
				'type' => 'VARCHAR',
				'constraint' => '255',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'treatment' => array(
				'type' => 'TEXT',
				'unsigned' => TRUE,
				'null' => TRUE
			),
			'apikey' => array(
				'type' => 'VARCHAR',
				'constraint' => '255',
				'unsigned' => TRUE,
				'null' => TRUE
			),

		));
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('users');

		// Dumping data for table 'users'
		$data = array(
			'id' => '1',
			'ip_address' => '127.0.0.1',
			'username' => 'administrator',
			'password' => '$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36',
			'salt' => '',
			'email' => 'admin@example.com',
			'activation_code' => '',
			'forgotten_password_code' => NULL,
			'created_on' => '1268889823',
			'last_login' => '1268889823',
			'active' => '1',
			'first_name' => 'Admin',
			'last_name' => 'istrator',
			'company' => 'ADMIN',
			'phone' => '0',
			'age' => '',
			'sex' => '',
			'diabetes_type' => '',
			'diabetes_period' => '',
			'treatment' => '',
			'apikey' => 'MqCPRZBoVXEz6lUrSInf82d0jyA1TbuH',
		);
		$this->db->insert('users', $data);


		// Drop table 'users_groups' if it exists
		$this->dbforge->drop_table('users_groups', TRUE);

		// Table structure for table 'users_groups'
		$this->dbforge->add_field(array(
			'id' => array(
				'type' => 'MEDIUMINT',
				'constraint' => '8',
				'unsigned' => TRUE,
				'auto_increment' => TRUE
			),
			'user_id' => array(
				'type' => 'MEDIUMINT',
				'constraint' => '8',
				'unsigned' => TRUE
			),
			'group_id' => array(
				'type' => 'MEDIUMINT',
				'constraint' => '8',
				'unsigned' => TRUE
			),
		));
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('users_groups');

		// Dumping data for table 'users_groups'
		$data = array(
			array(
				'id' => '1',
				'user_id' => '1',
				'group_id' => '1',
			),
			array(
				'id' => '2',
				'user_id' => '1',
				'group_id' => '2',
			),
			array(
				'id' => '3',
				'user_id' => '1',
				'group_id' => '3',
			),
		);
		$this->db->insert_batch('users_groups', $data);


		// Drop table 'login_attempts' if it exists
		$this->dbforge->drop_table('login_attempts', TRUE);

		// Table structure for table 'login_attempts'
		$this->dbforge->add_field(array(
			'id' => array(
				'type' => 'MEDIUMINT',
				'constraint' => '8',
				'unsigned' => TRUE,
				'auto_increment' => TRUE
			),
			'ip_address' => array(
				'type' => 'VARCHAR',
				'constraint' => '16'
			),
			'login' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'null', TRUE
			),
			'time' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
				'null' => TRUE
			),
		));
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('login_attempts');

		// Drop table 'tokens' if it exists
		$this->dbforge->drop_table('tokens', TRUE);

		// Table structure for table 'tokens'
		$this->dbforge->add_field(array(
			'token' => array(
				'type' => 'VARCHAR',
				'constraint' => '32',
				'unsigned' => TRUE,
			),
			'fk_user' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
			),
			'name' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'email' => array(
				'type' => 'VARCHAR',
				'constraint' => '100'
			),
			'type' => array(
				'type' => 'ENUM("doctor", "family")',
				'unsigned' => TRUE,
			),
			'_is_active' => array(
				'type' => 'TINYINT',
				'constraint' => '1',
				'default' => '1',
				'unsigned' => TRUE,
			),		
			'_create_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
		));
		$this->dbforge->add_key('token', TRUE);
		$this->dbforge->create_table('tokens');

		// Drop table '0_glicemie' if it exists
		$this->dbforge->drop_table('0_glicemie', TRUE);

		// Table structure for table '0_glicemie'
		$this->dbforge->add_field(array(
			'id' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
				'auto_increment' => TRUE
			),
			'fk_user' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
			),
			'interval_1' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_2' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_3' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_4' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_5' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_6' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_7' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_8' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_9' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'interval_10' => array(
				'type' => 'VARCHAR',
				'constraint' => '100',
				'unsigned' => TRUE,
			),
			'notes' => array(
				'type' => 'TEXT',
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'date' => array(
				'type' => 'DATE',
				'unsigned' => TRUE,
			),	
		));
		$this->dbforge->create_table('0_glicemie');
		$query = "ALTER TABLE `0_glicemie` ADD UNIQUE `Valori_unice` (`fk_user`, `date`);";
		$this->db->query($query);

		// Drop table 'posts' if it exists
		$this->dbforge->drop_table('posts', TRUE);

		// Table structure for table 'tokens'
		$this->dbforge->add_field(array(
			'id' => array(
				'type' => 'INT',
				'constraint' => '11',
				'unsigned' => TRUE,
			),
			'title' => array(
				'type' => 'VARCHAR',
				'constraint' => '255',
				'unsigned' => TRUE,
			),
			'content' => array(
				'type' => 'TEXT',
			),
			'featured' => array(
				'type' => 'INT',
				'constraint' => '1',
				'unsigned' => TRUE,
			),		
			'_create_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
		));
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('posts');
	}

	public function down()
	{
		$this->dbforge->drop_table('users', TRUE);
		$this->dbforge->drop_table('groups', TRUE);
		$this->dbforge->drop_table('users_groups', TRUE);
		$this->dbforge->drop_table('login_attempts', TRUE);
		$this->dbforge->drop_table('tokens', TRUE);
		$this->dbforge->drop_table('posts', TRUE);
		$this->dbforge->drop_table('0_glicemie', TRUE);
	}
}
