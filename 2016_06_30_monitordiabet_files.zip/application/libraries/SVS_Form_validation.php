<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/*
 *  @author Darie Demis Severian
 *  New rule for validation php for phone number
 *  add message for rules for languages
 *
 */

class SVS_Form_validation extends CI_Form_validation {
    public $CI = null;

    public function __construct()
    {
        parent::__construct();
        $this->CI = & get_instance();
    }

    /*
     * @author Darie Demis
     * function to check email for unique value
     * param1 1 email ($str)
     * param 2 email and pk_user
     */

    function is_unique_email($email)
    {
        if ( $this->CI->Diabet_model->checkEmail($email) === TRUE ) {
            $this->CI->form_validation->set_message('is_unique_email', $this->CI->lang->line('form_validation_unique_email_custom'));
            return FALSE;
        } else {
            return TRUE;
        }
    }

    function captcha_check($str)
    {
        include_once $_SERVER['DOCUMENT_ROOT'] . '/securimage/securimage.php';
        $securimage = new Securimage();
        if ($securimage->check($str) == false) {
            $this->CI->form_validation->set_message('captcha_check', $this->CI->lang->line('error_captcha'));
            return FALSE;
        } else {
            return TRUE;
        }
    }

}

