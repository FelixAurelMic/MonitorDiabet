<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-26 11:22:57 --> Config Class Initialized
INFO - 2016-06-26 11:22:57 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:22:57 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:22:57 --> Utf8 Class Initialized
INFO - 2016-06-26 11:22:57 --> URI Class Initialized
DEBUG - 2016-06-26 11:22:57 --> No URI present. Default controller set.
INFO - 2016-06-26 11:22:57 --> Router Class Initialized
INFO - 2016-06-26 11:22:57 --> Output Class Initialized
INFO - 2016-06-26 11:22:57 --> Security Class Initialized
DEBUG - 2016-06-26 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:22:57 --> Input Class Initialized
INFO - 2016-06-26 11:22:57 --> Language Class Initialized
INFO - 2016-06-26 11:22:57 --> Loader Class Initialized
INFO - 2016-06-26 11:22:58 --> Helper loaded: form_helper
INFO - 2016-06-26 11:22:58 --> Database Driver Class Initialized
INFO - 2016-06-26 11:22:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:22:58 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:22:58 --> Email Class Initialized
INFO - 2016-06-26 11:22:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:22:58 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:22:58 --> Helper loaded: language_helper
INFO - 2016-06-26 11:22:58 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:22:58 --> Model Class Initialized
INFO - 2016-06-26 11:22:58 --> Helper loaded: date_helper
INFO - 2016-06-26 11:22:58 --> Controller Class Initialized
INFO - 2016-06-26 11:22:58 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:22:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:22:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:22:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:22:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:22:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:22:59 --> Model Class Initialized
INFO - 2016-06-26 14:22:59 --> Form Validation Class Initialized
INFO - 2016-06-26 14:22:59 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-26 14:22:59 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-26 14:22:59 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-26 14:22:59 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-26 14:22:59 --> Final output sent to browser
DEBUG - 2016-06-26 14:22:59 --> Total execution time: 1.8622
INFO - 2016-06-26 11:23:02 --> Config Class Initialized
INFO - 2016-06-26 11:23:02 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:03 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:03 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:03 --> URI Class Initialized
INFO - 2016-06-26 11:23:03 --> Router Class Initialized
INFO - 2016-06-26 11:23:03 --> Output Class Initialized
INFO - 2016-06-26 11:23:03 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:03 --> Input Class Initialized
INFO - 2016-06-26 11:23:03 --> Language Class Initialized
INFO - 2016-06-26 11:23:03 --> Loader Class Initialized
INFO - 2016-06-26 11:23:03 --> Helper loaded: form_helper
INFO - 2016-06-26 11:23:03 --> Database Driver Class Initialized
INFO - 2016-06-26 11:23:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:23:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:23:03 --> Email Class Initialized
INFO - 2016-06-26 11:23:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:23:03 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:23:03 --> Helper loaded: language_helper
INFO - 2016-06-26 11:23:03 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:23:03 --> Model Class Initialized
INFO - 2016-06-26 11:23:03 --> Helper loaded: date_helper
INFO - 2016-06-26 11:23:03 --> Controller Class Initialized
INFO - 2016-06-26 11:23:03 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:23:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:23:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:23:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:23:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:23:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:23:03 --> Model Class Initialized
INFO - 2016-06-26 14:23:03 --> Final output sent to browser
DEBUG - 2016-06-26 14:23:03 --> Total execution time: 0.1347
INFO - 2016-06-26 11:23:03 --> Config Class Initialized
INFO - 2016-06-26 11:23:03 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:03 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:03 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:03 --> URI Class Initialized
INFO - 2016-06-26 11:23:03 --> Router Class Initialized
INFO - 2016-06-26 11:23:03 --> Output Class Initialized
INFO - 2016-06-26 11:23:03 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:03 --> Input Class Initialized
INFO - 2016-06-26 11:23:03 --> Language Class Initialized
ERROR - 2016-06-26 11:23:03 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-26 11:23:03 --> Config Class Initialized
INFO - 2016-06-26 11:23:03 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:03 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:03 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:03 --> URI Class Initialized
INFO - 2016-06-26 11:23:03 --> Router Class Initialized
INFO - 2016-06-26 11:23:03 --> Output Class Initialized
INFO - 2016-06-26 11:23:03 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:03 --> Input Class Initialized
INFO - 2016-06-26 11:23:03 --> Language Class Initialized
ERROR - 2016-06-26 11:23:03 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-26 11:23:31 --> Config Class Initialized
INFO - 2016-06-26 11:23:31 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:31 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:31 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:31 --> URI Class Initialized
INFO - 2016-06-26 11:23:31 --> Router Class Initialized
INFO - 2016-06-26 11:23:31 --> Output Class Initialized
INFO - 2016-06-26 11:23:31 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:31 --> Input Class Initialized
INFO - 2016-06-26 11:23:31 --> Language Class Initialized
INFO - 2016-06-26 11:23:31 --> Loader Class Initialized
INFO - 2016-06-26 11:23:31 --> Helper loaded: form_helper
INFO - 2016-06-26 11:23:31 --> Database Driver Class Initialized
INFO - 2016-06-26 11:23:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:23:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:23:31 --> Email Class Initialized
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:23:31 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:23:31 --> Helper loaded: language_helper
INFO - 2016-06-26 11:23:31 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:23:31 --> Model Class Initialized
INFO - 2016-06-26 11:23:31 --> Helper loaded: date_helper
INFO - 2016-06-26 11:23:31 --> Controller Class Initialized
INFO - 2016-06-26 11:23:31 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-26 14:23:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-26 14:23:31 --> Form Validation Class Initialized
DEBUG - 2016-06-26 14:23:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:23:31 --> Config Class Initialized
INFO - 2016-06-26 11:23:31 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:31 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:31 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:31 --> URI Class Initialized
DEBUG - 2016-06-26 11:23:31 --> No URI present. Default controller set.
INFO - 2016-06-26 11:23:31 --> Router Class Initialized
INFO - 2016-06-26 11:23:31 --> Output Class Initialized
INFO - 2016-06-26 11:23:31 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:31 --> Input Class Initialized
INFO - 2016-06-26 11:23:31 --> Language Class Initialized
INFO - 2016-06-26 11:23:31 --> Loader Class Initialized
INFO - 2016-06-26 11:23:31 --> Helper loaded: form_helper
INFO - 2016-06-26 11:23:31 --> Database Driver Class Initialized
INFO - 2016-06-26 11:23:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:23:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:23:31 --> Email Class Initialized
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:23:31 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:23:31 --> Helper loaded: language_helper
INFO - 2016-06-26 11:23:31 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:23:31 --> Model Class Initialized
INFO - 2016-06-26 11:23:31 --> Helper loaded: date_helper
INFO - 2016-06-26 11:23:31 --> Controller Class Initialized
INFO - 2016-06-26 11:23:31 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:23:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 11:23:32 --> Config Class Initialized
INFO - 2016-06-26 11:23:32 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:32 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:32 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:32 --> URI Class Initialized
INFO - 2016-06-26 11:23:32 --> Router Class Initialized
INFO - 2016-06-26 11:23:32 --> Output Class Initialized
INFO - 2016-06-26 11:23:32 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:32 --> Input Class Initialized
INFO - 2016-06-26 11:23:32 --> Language Class Initialized
INFO - 2016-06-26 11:23:32 --> Loader Class Initialized
INFO - 2016-06-26 11:23:32 --> Helper loaded: form_helper
INFO - 2016-06-26 11:23:32 --> Database Driver Class Initialized
INFO - 2016-06-26 11:23:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:23:32 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:23:32 --> Email Class Initialized
INFO - 2016-06-26 11:23:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:23:32 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:23:32 --> Helper loaded: language_helper
INFO - 2016-06-26 11:23:32 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:23:32 --> Model Class Initialized
INFO - 2016-06-26 11:23:32 --> Helper loaded: date_helper
INFO - 2016-06-26 11:23:32 --> Controller Class Initialized
INFO - 2016-06-26 11:23:32 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:23:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:23:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:23:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:23:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:23:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:23:32 --> Model Class Initialized
INFO - 2016-06-26 14:23:32 --> Form Validation Class Initialized
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-26 14:23:32 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-26 14:23:32 --> Final output sent to browser
DEBUG - 2016-06-26 14:23:32 --> Total execution time: 0.3855
INFO - 2016-06-26 11:23:35 --> Config Class Initialized
INFO - 2016-06-26 11:23:35 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:35 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:35 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:35 --> URI Class Initialized
INFO - 2016-06-26 11:23:35 --> Router Class Initialized
INFO - 2016-06-26 11:23:35 --> Output Class Initialized
INFO - 2016-06-26 11:23:35 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:35 --> Input Class Initialized
INFO - 2016-06-26 11:23:35 --> Language Class Initialized
INFO - 2016-06-26 11:23:35 --> Loader Class Initialized
INFO - 2016-06-26 11:23:35 --> Helper loaded: form_helper
INFO - 2016-06-26 11:23:35 --> Database Driver Class Initialized
INFO - 2016-06-26 11:23:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:23:35 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:23:35 --> Email Class Initialized
INFO - 2016-06-26 11:23:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:23:35 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:23:35 --> Helper loaded: language_helper
INFO - 2016-06-26 11:23:35 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:23:35 --> Model Class Initialized
INFO - 2016-06-26 11:23:35 --> Helper loaded: date_helper
INFO - 2016-06-26 11:23:35 --> Controller Class Initialized
INFO - 2016-06-26 11:23:35 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:23:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:23:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:23:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:23:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:23:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:23:35 --> Model Class Initialized
INFO - 2016-06-26 14:23:35 --> Form Validation Class Initialized
INFO - 2016-06-26 14:23:35 --> Final output sent to browser
DEBUG - 2016-06-26 14:23:35 --> Total execution time: 0.0918
INFO - 2016-06-26 11:23:45 --> Config Class Initialized
INFO - 2016-06-26 11:23:45 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:23:45 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:23:45 --> Utf8 Class Initialized
INFO - 2016-06-26 11:23:45 --> URI Class Initialized
INFO - 2016-06-26 11:23:45 --> Router Class Initialized
INFO - 2016-06-26 11:23:45 --> Output Class Initialized
INFO - 2016-06-26 11:23:45 --> Security Class Initialized
DEBUG - 2016-06-26 11:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:23:45 --> Input Class Initialized
INFO - 2016-06-26 11:23:45 --> Language Class Initialized
INFO - 2016-06-26 11:23:45 --> Loader Class Initialized
INFO - 2016-06-26 11:23:45 --> Helper loaded: form_helper
INFO - 2016-06-26 11:23:45 --> Database Driver Class Initialized
INFO - 2016-06-26 11:23:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:23:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:23:45 --> Email Class Initialized
INFO - 2016-06-26 11:23:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:23:45 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:23:45 --> Helper loaded: language_helper
INFO - 2016-06-26 11:23:45 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:23:45 --> Model Class Initialized
INFO - 2016-06-26 11:23:45 --> Helper loaded: date_helper
INFO - 2016-06-26 11:23:45 --> Controller Class Initialized
INFO - 2016-06-26 11:23:45 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:23:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:23:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:23:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:23:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:23:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:23:45 --> Model Class Initialized
INFO - 2016-06-26 14:23:45 --> Form Validation Class Initialized
INFO - 2016-06-26 14:23:46 --> Helper loaded: sort_array_helper
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-26 14:23:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-26 14:23:46 --> Final output sent to browser
DEBUG - 2016-06-26 14:23:46 --> Total execution time: 0.1305
INFO - 2016-06-26 11:24:01 --> Config Class Initialized
INFO - 2016-06-26 11:24:01 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:24:01 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:24:01 --> Utf8 Class Initialized
INFO - 2016-06-26 11:24:01 --> URI Class Initialized
INFO - 2016-06-26 11:24:01 --> Router Class Initialized
INFO - 2016-06-26 11:24:01 --> Output Class Initialized
INFO - 2016-06-26 11:24:01 --> Security Class Initialized
DEBUG - 2016-06-26 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:24:01 --> Input Class Initialized
INFO - 2016-06-26 11:24:01 --> Language Class Initialized
INFO - 2016-06-26 11:24:01 --> Loader Class Initialized
INFO - 2016-06-26 11:24:01 --> Helper loaded: form_helper
INFO - 2016-06-26 11:24:01 --> Database Driver Class Initialized
INFO - 2016-06-26 11:24:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:24:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:24:01 --> Email Class Initialized
INFO - 2016-06-26 11:24:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:24:01 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:24:01 --> Helper loaded: language_helper
INFO - 2016-06-26 11:24:01 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:24:01 --> Model Class Initialized
INFO - 2016-06-26 11:24:01 --> Helper loaded: date_helper
INFO - 2016-06-26 11:24:01 --> Controller Class Initialized
INFO - 2016-06-26 11:24:01 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:24:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:24:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:24:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:24:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:24:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:24:01 --> Model Class Initialized
INFO - 2016-06-26 14:24:01 --> Form Validation Class Initialized
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-26 14:24:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-26 14:24:01 --> Final output sent to browser
DEBUG - 2016-06-26 14:24:01 --> Total execution time: 0.1458
INFO - 2016-06-26 11:24:05 --> Config Class Initialized
INFO - 2016-06-26 11:24:05 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:24:05 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:24:05 --> Utf8 Class Initialized
INFO - 2016-06-26 11:24:05 --> URI Class Initialized
INFO - 2016-06-26 11:24:05 --> Router Class Initialized
INFO - 2016-06-26 11:24:05 --> Output Class Initialized
INFO - 2016-06-26 11:24:05 --> Security Class Initialized
DEBUG - 2016-06-26 11:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:24:05 --> Input Class Initialized
INFO - 2016-06-26 11:24:05 --> Language Class Initialized
INFO - 2016-06-26 11:24:05 --> Loader Class Initialized
INFO - 2016-06-26 11:24:05 --> Helper loaded: form_helper
INFO - 2016-06-26 11:24:05 --> Database Driver Class Initialized
INFO - 2016-06-26 11:24:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:24:05 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:24:05 --> Email Class Initialized
INFO - 2016-06-26 11:24:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:24:05 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:24:05 --> Helper loaded: language_helper
INFO - 2016-06-26 11:24:05 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:24:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:24:05 --> Model Class Initialized
INFO - 2016-06-26 11:24:05 --> Helper loaded: date_helper
INFO - 2016-06-26 11:24:05 --> Controller Class Initialized
INFO - 2016-06-26 11:24:05 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:24:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:24:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:24:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:24:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:24:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:24:05 --> Model Class Initialized
INFO - 2016-06-26 14:24:05 --> Form Validation Class Initialized
INFO - 2016-06-26 14:24:05 --> Final output sent to browser
DEBUG - 2016-06-26 14:24:05 --> Total execution time: 0.1028
INFO - 2016-06-26 11:24:07 --> Config Class Initialized
INFO - 2016-06-26 11:24:07 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:24:07 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:24:07 --> Utf8 Class Initialized
INFO - 2016-06-26 11:24:07 --> URI Class Initialized
INFO - 2016-06-26 11:24:07 --> Router Class Initialized
INFO - 2016-06-26 11:24:07 --> Output Class Initialized
INFO - 2016-06-26 11:24:07 --> Security Class Initialized
DEBUG - 2016-06-26 11:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:24:07 --> Input Class Initialized
INFO - 2016-06-26 11:24:07 --> Language Class Initialized
INFO - 2016-06-26 11:24:07 --> Loader Class Initialized
INFO - 2016-06-26 11:24:07 --> Helper loaded: form_helper
INFO - 2016-06-26 11:24:07 --> Database Driver Class Initialized
INFO - 2016-06-26 11:24:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:24:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:24:07 --> Email Class Initialized
INFO - 2016-06-26 11:24:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:24:07 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:24:07 --> Helper loaded: language_helper
INFO - 2016-06-26 11:24:07 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:24:07 --> Model Class Initialized
INFO - 2016-06-26 11:24:07 --> Helper loaded: date_helper
INFO - 2016-06-26 11:24:07 --> Controller Class Initialized
INFO - 2016-06-26 11:24:07 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:24:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:24:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:24:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:24:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:24:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:24:07 --> Model Class Initialized
INFO - 2016-06-26 14:24:07 --> Form Validation Class Initialized
INFO - 2016-06-26 14:24:07 --> Helper loaded: sort_array_helper
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-26 14:24:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-26 14:24:07 --> Final output sent to browser
DEBUG - 2016-06-26 14:24:07 --> Total execution time: 0.1215
INFO - 2016-06-26 11:25:00 --> Config Class Initialized
INFO - 2016-06-26 11:25:00 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:25:00 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:25:00 --> Utf8 Class Initialized
INFO - 2016-06-26 11:25:00 --> URI Class Initialized
INFO - 2016-06-26 11:25:00 --> Router Class Initialized
INFO - 2016-06-26 11:25:00 --> Output Class Initialized
INFO - 2016-06-26 11:25:00 --> Security Class Initialized
DEBUG - 2016-06-26 11:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:25:00 --> Input Class Initialized
INFO - 2016-06-26 11:25:00 --> Language Class Initialized
INFO - 2016-06-26 11:25:00 --> Loader Class Initialized
INFO - 2016-06-26 11:25:00 --> Helper loaded: form_helper
INFO - 2016-06-26 11:25:00 --> Database Driver Class Initialized
INFO - 2016-06-26 11:25:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:25:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:25:00 --> Email Class Initialized
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:25:00 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:25:00 --> Helper loaded: language_helper
INFO - 2016-06-26 11:25:00 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:25:00 --> Model Class Initialized
INFO - 2016-06-26 11:25:00 --> Helper loaded: date_helper
INFO - 2016-06-26 11:25:00 --> Controller Class Initialized
INFO - 2016-06-26 11:25:00 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:25:00 --> Model Class Initialized
INFO - 2016-06-26 14:25:00 --> Form Validation Class Initialized
DEBUG - 2016-06-26 14:25:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:25:00 --> Config Class Initialized
INFO - 2016-06-26 11:25:00 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:25:00 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:25:00 --> Utf8 Class Initialized
INFO - 2016-06-26 11:25:00 --> URI Class Initialized
INFO - 2016-06-26 11:25:00 --> Router Class Initialized
INFO - 2016-06-26 11:25:00 --> Output Class Initialized
INFO - 2016-06-26 11:25:00 --> Security Class Initialized
DEBUG - 2016-06-26 11:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:25:00 --> Input Class Initialized
INFO - 2016-06-26 11:25:00 --> Language Class Initialized
INFO - 2016-06-26 11:25:00 --> Loader Class Initialized
INFO - 2016-06-26 11:25:00 --> Helper loaded: form_helper
INFO - 2016-06-26 11:25:00 --> Database Driver Class Initialized
INFO - 2016-06-26 11:25:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:25:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:25:00 --> Email Class Initialized
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:25:00 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:25:00 --> Helper loaded: language_helper
INFO - 2016-06-26 11:25:00 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:25:00 --> Model Class Initialized
INFO - 2016-06-26 11:25:00 --> Helper loaded: date_helper
INFO - 2016-06-26 11:25:00 --> Controller Class Initialized
INFO - 2016-06-26 11:25:00 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:25:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:25:00 --> Model Class Initialized
INFO - 2016-06-26 14:25:00 --> Form Validation Class Initialized
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-26 14:25:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-26 14:25:00 --> Final output sent to browser
DEBUG - 2016-06-26 14:25:00 --> Total execution time: 0.1078
INFO - 2016-06-26 11:25:02 --> Config Class Initialized
INFO - 2016-06-26 11:25:02 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:25:02 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:25:02 --> Utf8 Class Initialized
INFO - 2016-06-26 11:25:02 --> URI Class Initialized
INFO - 2016-06-26 11:25:02 --> Router Class Initialized
INFO - 2016-06-26 11:25:02 --> Output Class Initialized
INFO - 2016-06-26 11:25:02 --> Security Class Initialized
DEBUG - 2016-06-26 11:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:25:02 --> Input Class Initialized
INFO - 2016-06-26 11:25:02 --> Language Class Initialized
INFO - 2016-06-26 11:25:02 --> Loader Class Initialized
INFO - 2016-06-26 11:25:02 --> Helper loaded: form_helper
INFO - 2016-06-26 11:25:02 --> Database Driver Class Initialized
INFO - 2016-06-26 11:25:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:25:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:25:02 --> Email Class Initialized
INFO - 2016-06-26 11:25:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:25:02 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:25:02 --> Helper loaded: language_helper
INFO - 2016-06-26 11:25:02 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:25:02 --> Model Class Initialized
INFO - 2016-06-26 11:25:02 --> Helper loaded: date_helper
INFO - 2016-06-26 11:25:02 --> Controller Class Initialized
INFO - 2016-06-26 11:25:02 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:25:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:25:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:25:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:25:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:25:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:25:02 --> Model Class Initialized
INFO - 2016-06-26 14:25:02 --> Form Validation Class Initialized
INFO - 2016-06-26 14:25:02 --> Final output sent to browser
DEBUG - 2016-06-26 14:25:02 --> Total execution time: 0.0902
INFO - 2016-06-26 11:26:29 --> Config Class Initialized
INFO - 2016-06-26 11:26:29 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:26:29 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:26:29 --> Utf8 Class Initialized
INFO - 2016-06-26 11:26:29 --> URI Class Initialized
INFO - 2016-06-26 11:26:29 --> Router Class Initialized
INFO - 2016-06-26 11:26:29 --> Output Class Initialized
INFO - 2016-06-26 11:26:29 --> Security Class Initialized
DEBUG - 2016-06-26 11:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:26:29 --> Input Class Initialized
INFO - 2016-06-26 11:26:29 --> Language Class Initialized
INFO - 2016-06-26 11:26:29 --> Loader Class Initialized
INFO - 2016-06-26 11:26:29 --> Helper loaded: form_helper
INFO - 2016-06-26 11:26:29 --> Database Driver Class Initialized
INFO - 2016-06-26 11:26:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:26:29 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:26:29 --> Email Class Initialized
INFO - 2016-06-26 11:26:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:26:29 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:26:29 --> Helper loaded: language_helper
INFO - 2016-06-26 11:26:29 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:26:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:26:29 --> Model Class Initialized
INFO - 2016-06-26 11:26:29 --> Helper loaded: date_helper
INFO - 2016-06-26 11:26:29 --> Controller Class Initialized
INFO - 2016-06-26 11:26:29 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:26:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:26:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:26:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:26:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:26:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:26:29 --> Model Class Initialized
INFO - 2016-06-26 14:26:29 --> Form Validation Class Initialized
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-26 14:26:29 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-26 14:26:29 --> Final output sent to browser
DEBUG - 2016-06-26 14:26:29 --> Total execution time: 0.1268
INFO - 2016-06-26 11:26:33 --> Config Class Initialized
INFO - 2016-06-26 11:26:33 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:26:33 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:26:33 --> Utf8 Class Initialized
INFO - 2016-06-26 11:26:33 --> URI Class Initialized
INFO - 2016-06-26 11:26:33 --> Router Class Initialized
INFO - 2016-06-26 11:26:33 --> Output Class Initialized
INFO - 2016-06-26 11:26:33 --> Security Class Initialized
DEBUG - 2016-06-26 11:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:26:33 --> Input Class Initialized
INFO - 2016-06-26 11:26:33 --> Language Class Initialized
INFO - 2016-06-26 11:26:33 --> Loader Class Initialized
INFO - 2016-06-26 11:26:33 --> Helper loaded: form_helper
INFO - 2016-06-26 11:26:33 --> Database Driver Class Initialized
INFO - 2016-06-26 11:26:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:26:33 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:26:33 --> Email Class Initialized
INFO - 2016-06-26 11:26:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:26:33 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:26:33 --> Helper loaded: language_helper
INFO - 2016-06-26 11:26:33 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:26:33 --> Model Class Initialized
INFO - 2016-06-26 11:26:33 --> Helper loaded: date_helper
INFO - 2016-06-26 11:26:33 --> Controller Class Initialized
INFO - 2016-06-26 11:26:33 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:26:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:26:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:26:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:26:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:26:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:26:33 --> Model Class Initialized
INFO - 2016-06-26 14:26:33 --> Form Validation Class Initialized
INFO - 2016-06-26 14:26:33 --> Final output sent to browser
DEBUG - 2016-06-26 14:26:33 --> Total execution time: 0.1162
INFO - 2016-06-26 11:27:55 --> Config Class Initialized
INFO - 2016-06-26 11:27:55 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:27:55 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:27:55 --> Utf8 Class Initialized
INFO - 2016-06-26 11:27:55 --> URI Class Initialized
INFO - 2016-06-26 11:27:55 --> Router Class Initialized
INFO - 2016-06-26 11:27:55 --> Output Class Initialized
INFO - 2016-06-26 11:27:55 --> Security Class Initialized
DEBUG - 2016-06-26 11:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:27:55 --> Input Class Initialized
INFO - 2016-06-26 11:27:55 --> Language Class Initialized
INFO - 2016-06-26 11:27:55 --> Loader Class Initialized
INFO - 2016-06-26 11:27:55 --> Helper loaded: form_helper
INFO - 2016-06-26 11:27:55 --> Database Driver Class Initialized
INFO - 2016-06-26 11:27:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:27:55 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:27:55 --> Email Class Initialized
INFO - 2016-06-26 11:27:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:27:55 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:27:55 --> Helper loaded: language_helper
INFO - 2016-06-26 11:27:55 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:27:55 --> Model Class Initialized
INFO - 2016-06-26 11:27:55 --> Helper loaded: date_helper
INFO - 2016-06-26 11:27:55 --> Controller Class Initialized
INFO - 2016-06-26 11:27:55 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:27:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:27:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:27:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:27:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:27:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:27:55 --> Model Class Initialized
INFO - 2016-06-26 14:27:55 --> Form Validation Class Initialized
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-26 14:27:55 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-26 14:27:55 --> Final output sent to browser
DEBUG - 2016-06-26 14:27:55 --> Total execution time: 0.1261
INFO - 2016-06-26 11:28:02 --> Config Class Initialized
INFO - 2016-06-26 11:28:02 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:28:02 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:28:02 --> Utf8 Class Initialized
INFO - 2016-06-26 11:28:02 --> URI Class Initialized
INFO - 2016-06-26 11:28:02 --> Router Class Initialized
INFO - 2016-06-26 11:28:02 --> Output Class Initialized
INFO - 2016-06-26 11:28:02 --> Security Class Initialized
DEBUG - 2016-06-26 11:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:28:02 --> Input Class Initialized
INFO - 2016-06-26 11:28:02 --> Language Class Initialized
INFO - 2016-06-26 11:28:02 --> Loader Class Initialized
INFO - 2016-06-26 11:28:02 --> Helper loaded: form_helper
INFO - 2016-06-26 11:28:02 --> Database Driver Class Initialized
INFO - 2016-06-26 11:28:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:28:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:28:02 --> Email Class Initialized
INFO - 2016-06-26 11:28:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:28:02 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:28:02 --> Helper loaded: language_helper
INFO - 2016-06-26 11:28:02 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:28:02 --> Model Class Initialized
INFO - 2016-06-26 11:28:02 --> Helper loaded: date_helper
INFO - 2016-06-26 11:28:02 --> Controller Class Initialized
INFO - 2016-06-26 11:28:02 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:28:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:28:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:28:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:28:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:28:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-26 14:28:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-26 14:28:02 --> Form Validation Class Initialized
INFO - 2016-06-26 11:28:03 --> Config Class Initialized
INFO - 2016-06-26 11:28:03 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:28:03 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:28:03 --> Utf8 Class Initialized
INFO - 2016-06-26 11:28:03 --> URI Class Initialized
DEBUG - 2016-06-26 11:28:03 --> No URI present. Default controller set.
INFO - 2016-06-26 11:28:03 --> Router Class Initialized
INFO - 2016-06-26 11:28:03 --> Output Class Initialized
INFO - 2016-06-26 11:28:03 --> Security Class Initialized
DEBUG - 2016-06-26 11:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:28:03 --> Input Class Initialized
INFO - 2016-06-26 11:28:03 --> Language Class Initialized
INFO - 2016-06-26 11:28:03 --> Loader Class Initialized
INFO - 2016-06-26 11:28:03 --> Helper loaded: form_helper
INFO - 2016-06-26 11:28:03 --> Database Driver Class Initialized
INFO - 2016-06-26 11:28:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:28:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:28:03 --> Email Class Initialized
INFO - 2016-06-26 11:28:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:28:03 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:28:03 --> Helper loaded: language_helper
INFO - 2016-06-26 11:28:03 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:28:03 --> Model Class Initialized
INFO - 2016-06-26 11:28:03 --> Helper loaded: date_helper
INFO - 2016-06-26 11:28:03 --> Controller Class Initialized
INFO - 2016-06-26 11:28:03 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:28:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:28:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:28:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:28:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:28:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:28:03 --> Model Class Initialized
INFO - 2016-06-26 14:28:03 --> Form Validation Class Initialized
INFO - 2016-06-26 14:28:03 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-26 14:28:03 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-26 14:28:03 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-26 14:28:03 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-26 14:28:03 --> Final output sent to browser
DEBUG - 2016-06-26 14:28:03 --> Total execution time: 0.0956
INFO - 2016-06-26 11:28:04 --> Config Class Initialized
INFO - 2016-06-26 11:28:04 --> Hooks Class Initialized
DEBUG - 2016-06-26 11:28:04 --> UTF-8 Support Enabled
INFO - 2016-06-26 11:28:04 --> Utf8 Class Initialized
INFO - 2016-06-26 11:28:04 --> URI Class Initialized
INFO - 2016-06-26 11:28:04 --> Router Class Initialized
INFO - 2016-06-26 11:28:04 --> Output Class Initialized
INFO - 2016-06-26 11:28:04 --> Security Class Initialized
DEBUG - 2016-06-26 11:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-26 11:28:04 --> Input Class Initialized
INFO - 2016-06-26 11:28:04 --> Language Class Initialized
INFO - 2016-06-26 11:28:04 --> Loader Class Initialized
INFO - 2016-06-26 11:28:04 --> Helper loaded: form_helper
INFO - 2016-06-26 11:28:04 --> Database Driver Class Initialized
INFO - 2016-06-26 11:28:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-26 11:28:04 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-26 11:28:04 --> Email Class Initialized
INFO - 2016-06-26 11:28:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-26 11:28:04 --> Helper loaded: cookie_helper
INFO - 2016-06-26 11:28:04 --> Helper loaded: language_helper
INFO - 2016-06-26 11:28:04 --> Helper loaded: url_helper
DEBUG - 2016-06-26 11:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-26 11:28:04 --> Model Class Initialized
INFO - 2016-06-26 11:28:04 --> Helper loaded: date_helper
INFO - 2016-06-26 11:28:04 --> Controller Class Initialized
INFO - 2016-06-26 11:28:04 --> Helper loaded: languages_helper
INFO - 2016-06-26 11:28:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-26 11:28:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-26 11:28:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-26 11:28:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-26 11:28:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-26 14:28:04 --> Model Class Initialized
INFO - 2016-06-26 14:28:04 --> Final output sent to browser
DEBUG - 2016-06-26 14:28:04 --> Total execution time: 0.1623
