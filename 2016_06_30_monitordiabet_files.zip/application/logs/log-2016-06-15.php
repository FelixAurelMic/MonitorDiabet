<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-15 10:24:19 --> Config Class Initialized
INFO - 2016-06-15 10:24:19 --> Hooks Class Initialized
DEBUG - 2016-06-15 10:24:19 --> UTF-8 Support Enabled
INFO - 2016-06-15 10:24:19 --> Utf8 Class Initialized
INFO - 2016-06-15 10:24:19 --> URI Class Initialized
INFO - 2016-06-15 10:24:20 --> Router Class Initialized
INFO - 2016-06-15 10:24:20 --> Output Class Initialized
INFO - 2016-06-15 10:24:20 --> Security Class Initialized
DEBUG - 2016-06-15 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 10:24:20 --> Input Class Initialized
INFO - 2016-06-15 10:24:20 --> Language Class Initialized
INFO - 2016-06-15 10:24:20 --> Loader Class Initialized
INFO - 2016-06-15 10:24:20 --> Helper loaded: form_helper
INFO - 2016-06-15 10:24:20 --> Database Driver Class Initialized
INFO - 2016-06-15 10:24:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 10:24:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 10:24:20 --> Email Class Initialized
INFO - 2016-06-15 10:24:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 10:24:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 10:24:20 --> Helper loaded: language_helper
INFO - 2016-06-15 10:24:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 10:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 10:24:20 --> Model Class Initialized
INFO - 2016-06-15 10:24:20 --> Helper loaded: date_helper
INFO - 2016-06-15 10:24:20 --> Controller Class Initialized
INFO - 2016-06-15 10:24:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 10:24:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 10:24:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 10:24:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 10:24:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 10:24:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 10:24:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-15 10:24:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 10:24:20 --> Form Validation Class Initialized
DEBUG - 2016-06-15 10:24:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 10:24:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 10:24:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 10:24:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 10:24:20 --> Final output sent to browser
DEBUG - 2016-06-15 10:24:20 --> Total execution time: 0.8909
INFO - 2016-06-15 12:51:19 --> Config Class Initialized
INFO - 2016-06-15 12:51:19 --> Hooks Class Initialized
DEBUG - 2016-06-15 12:51:19 --> UTF-8 Support Enabled
INFO - 2016-06-15 12:51:19 --> Utf8 Class Initialized
INFO - 2016-06-15 12:51:19 --> URI Class Initialized
DEBUG - 2016-06-15 12:51:19 --> No URI present. Default controller set.
INFO - 2016-06-15 12:51:19 --> Router Class Initialized
INFO - 2016-06-15 12:51:19 --> Output Class Initialized
INFO - 2016-06-15 12:51:19 --> Security Class Initialized
DEBUG - 2016-06-15 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 12:51:19 --> Input Class Initialized
INFO - 2016-06-15 12:51:19 --> Language Class Initialized
INFO - 2016-06-15 12:51:19 --> Loader Class Initialized
INFO - 2016-06-15 12:51:19 --> Helper loaded: form_helper
INFO - 2016-06-15 12:51:19 --> Database Driver Class Initialized
INFO - 2016-06-15 12:51:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 12:51:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 12:51:19 --> Email Class Initialized
INFO - 2016-06-15 12:51:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 12:51:19 --> Helper loaded: cookie_helper
INFO - 2016-06-15 12:51:19 --> Helper loaded: language_helper
INFO - 2016-06-15 12:51:19 --> Helper loaded: url_helper
DEBUG - 2016-06-15 12:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 12:51:19 --> Model Class Initialized
INFO - 2016-06-15 12:51:19 --> Helper loaded: date_helper
INFO - 2016-06-15 12:51:19 --> Controller Class Initialized
INFO - 2016-06-15 12:51:19 --> Helper loaded: languages_helper
INFO - 2016-06-15 12:51:19 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 12:51:19 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 12:51:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 12:51:19 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 12:51:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 12:51:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 12:51:19 --> Model Class Initialized
INFO - 2016-06-15 12:51:19 --> Form Validation Class Initialized
INFO - 2016-06-15 12:51:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 12:51:19 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 12:51:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 12:51:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 12:51:19 --> Final output sent to browser
DEBUG - 2016-06-15 12:51:19 --> Total execution time: 0.1957
INFO - 2016-06-15 12:51:28 --> Config Class Initialized
INFO - 2016-06-15 12:51:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 12:51:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 12:51:28 --> Utf8 Class Initialized
INFO - 2016-06-15 12:51:28 --> URI Class Initialized
INFO - 2016-06-15 12:51:28 --> Router Class Initialized
INFO - 2016-06-15 12:51:28 --> Output Class Initialized
INFO - 2016-06-15 12:51:28 --> Security Class Initialized
DEBUG - 2016-06-15 12:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 12:51:28 --> Input Class Initialized
INFO - 2016-06-15 12:51:28 --> Language Class Initialized
INFO - 2016-06-15 12:51:28 --> Loader Class Initialized
INFO - 2016-06-15 12:51:28 --> Helper loaded: form_helper
INFO - 2016-06-15 12:51:28 --> Database Driver Class Initialized
INFO - 2016-06-15 12:51:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 12:51:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 12:51:28 --> Email Class Initialized
INFO - 2016-06-15 12:51:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 12:51:28 --> Helper loaded: cookie_helper
INFO - 2016-06-15 12:51:28 --> Helper loaded: language_helper
INFO - 2016-06-15 12:51:28 --> Helper loaded: url_helper
DEBUG - 2016-06-15 12:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 12:51:28 --> Model Class Initialized
INFO - 2016-06-15 12:51:28 --> Helper loaded: date_helper
INFO - 2016-06-15 12:51:28 --> Controller Class Initialized
INFO - 2016-06-15 12:51:28 --> Helper loaded: languages_helper
INFO - 2016-06-15 12:51:28 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 12:51:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 12:51:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 12:51:28 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 12:51:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 12:51:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 12:51:28 --> Model Class Initialized
INFO - 2016-06-15 12:51:28 --> Final output sent to browser
DEBUG - 2016-06-15 12:51:28 --> Total execution time: 0.1330
INFO - 2016-06-15 12:51:29 --> Config Class Initialized
INFO - 2016-06-15 12:51:29 --> Hooks Class Initialized
DEBUG - 2016-06-15 12:51:29 --> UTF-8 Support Enabled
INFO - 2016-06-15 12:51:29 --> Utf8 Class Initialized
INFO - 2016-06-15 12:51:29 --> URI Class Initialized
INFO - 2016-06-15 12:51:29 --> Router Class Initialized
INFO - 2016-06-15 12:51:29 --> Output Class Initialized
INFO - 2016-06-15 12:51:29 --> Security Class Initialized
DEBUG - 2016-06-15 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 12:51:29 --> Input Class Initialized
INFO - 2016-06-15 12:51:29 --> Language Class Initialized
ERROR - 2016-06-15 12:51:29 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 12:56:33 --> Config Class Initialized
INFO - 2016-06-15 12:56:33 --> Hooks Class Initialized
DEBUG - 2016-06-15 12:56:33 --> UTF-8 Support Enabled
INFO - 2016-06-15 12:56:33 --> Utf8 Class Initialized
INFO - 2016-06-15 12:56:33 --> URI Class Initialized
DEBUG - 2016-06-15 12:56:33 --> No URI present. Default controller set.
INFO - 2016-06-15 12:56:33 --> Router Class Initialized
INFO - 2016-06-15 12:56:33 --> Output Class Initialized
INFO - 2016-06-15 12:56:33 --> Security Class Initialized
DEBUG - 2016-06-15 12:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 12:56:33 --> Input Class Initialized
INFO - 2016-06-15 12:56:33 --> Language Class Initialized
INFO - 2016-06-15 12:56:33 --> Loader Class Initialized
INFO - 2016-06-15 12:56:33 --> Helper loaded: form_helper
INFO - 2016-06-15 12:56:33 --> Database Driver Class Initialized
INFO - 2016-06-15 12:56:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 12:56:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 12:56:33 --> Email Class Initialized
INFO - 2016-06-15 12:56:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 12:56:33 --> Helper loaded: cookie_helper
INFO - 2016-06-15 12:56:33 --> Helper loaded: language_helper
INFO - 2016-06-15 12:56:33 --> Helper loaded: url_helper
DEBUG - 2016-06-15 12:56:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 12:56:33 --> Model Class Initialized
INFO - 2016-06-15 12:56:33 --> Helper loaded: date_helper
INFO - 2016-06-15 12:56:33 --> Controller Class Initialized
INFO - 2016-06-15 12:56:33 --> Helper loaded: languages_helper
INFO - 2016-06-15 12:56:33 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 12:56:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 12:56:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 12:56:33 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 12:56:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 12:56:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 12:56:33 --> Model Class Initialized
INFO - 2016-06-15 12:56:33 --> Form Validation Class Initialized
INFO - 2016-06-15 12:56:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 12:56:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 12:56:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 12:56:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 12:56:33 --> Final output sent to browser
DEBUG - 2016-06-15 12:56:33 --> Total execution time: 0.0148
INFO - 2016-06-15 12:56:35 --> Config Class Initialized
INFO - 2016-06-15 12:56:35 --> Hooks Class Initialized
DEBUG - 2016-06-15 12:56:35 --> UTF-8 Support Enabled
INFO - 2016-06-15 12:56:35 --> Utf8 Class Initialized
INFO - 2016-06-15 12:56:35 --> URI Class Initialized
INFO - 2016-06-15 12:56:35 --> Router Class Initialized
INFO - 2016-06-15 12:56:35 --> Output Class Initialized
INFO - 2016-06-15 12:56:35 --> Security Class Initialized
DEBUG - 2016-06-15 12:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 12:56:35 --> Input Class Initialized
INFO - 2016-06-15 12:56:35 --> Language Class Initialized
INFO - 2016-06-15 12:56:35 --> Loader Class Initialized
INFO - 2016-06-15 12:56:35 --> Helper loaded: form_helper
INFO - 2016-06-15 12:56:35 --> Database Driver Class Initialized
INFO - 2016-06-15 12:56:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 12:56:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 12:56:35 --> Email Class Initialized
INFO - 2016-06-15 12:56:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 12:56:35 --> Helper loaded: cookie_helper
INFO - 2016-06-15 12:56:35 --> Helper loaded: language_helper
INFO - 2016-06-15 12:56:35 --> Helper loaded: url_helper
DEBUG - 2016-06-15 12:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 12:56:35 --> Model Class Initialized
INFO - 2016-06-15 12:56:35 --> Helper loaded: date_helper
INFO - 2016-06-15 12:56:35 --> Controller Class Initialized
INFO - 2016-06-15 12:56:35 --> Helper loaded: languages_helper
INFO - 2016-06-15 12:56:35 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 12:56:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 12:56:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 12:56:35 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 12:56:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 12:56:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 12:56:35 --> Model Class Initialized
INFO - 2016-06-15 12:56:35 --> Final output sent to browser
DEBUG - 2016-06-15 12:56:35 --> Total execution time: 0.0149
INFO - 2016-06-15 13:00:00 --> Config Class Initialized
INFO - 2016-06-15 13:00:00 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:00:00 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:00:00 --> Utf8 Class Initialized
INFO - 2016-06-15 13:00:00 --> URI Class Initialized
INFO - 2016-06-15 13:00:00 --> Router Class Initialized
INFO - 2016-06-15 13:00:00 --> Output Class Initialized
INFO - 2016-06-15 13:00:00 --> Security Class Initialized
DEBUG - 2016-06-15 13:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:00:00 --> Input Class Initialized
INFO - 2016-06-15 13:00:00 --> Language Class Initialized
INFO - 2016-06-15 13:00:00 --> Loader Class Initialized
INFO - 2016-06-15 13:00:00 --> Helper loaded: form_helper
INFO - 2016-06-15 13:00:00 --> Database Driver Class Initialized
INFO - 2016-06-15 13:00:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:00:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:00:00 --> Email Class Initialized
INFO - 2016-06-15 13:00:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:00:00 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:00:00 --> Helper loaded: language_helper
INFO - 2016-06-15 13:00:00 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:00 --> Model Class Initialized
INFO - 2016-06-15 13:00:00 --> Helper loaded: date_helper
INFO - 2016-06-15 13:00:00 --> Controller Class Initialized
INFO - 2016-06-15 13:00:00 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:00:00 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:00:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:00:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:00:00 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:00:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:00:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-15 13:00:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:00 --> Form Validation Class Initialized
DEBUG - 2016-06-15 13:00:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:00:00 --> Final output sent to browser
DEBUG - 2016-06-15 13:00:00 --> Total execution time: 0.0261
INFO - 2016-06-15 13:00:55 --> Config Class Initialized
INFO - 2016-06-15 13:00:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:00:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:00:55 --> Utf8 Class Initialized
INFO - 2016-06-15 13:00:55 --> URI Class Initialized
INFO - 2016-06-15 13:00:55 --> Router Class Initialized
INFO - 2016-06-15 13:00:55 --> Output Class Initialized
INFO - 2016-06-15 13:00:55 --> Security Class Initialized
DEBUG - 2016-06-15 13:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:00:55 --> Input Class Initialized
INFO - 2016-06-15 13:00:55 --> Language Class Initialized
INFO - 2016-06-15 13:00:55 --> Loader Class Initialized
INFO - 2016-06-15 13:00:55 --> Helper loaded: form_helper
INFO - 2016-06-15 13:00:55 --> Database Driver Class Initialized
INFO - 2016-06-15 13:00:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:00:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:00:55 --> Email Class Initialized
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:00:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:00:55 --> Helper loaded: language_helper
INFO - 2016-06-15 13:00:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:55 --> Model Class Initialized
INFO - 2016-06-15 13:00:55 --> Helper loaded: date_helper
INFO - 2016-06-15 13:00:55 --> Controller Class Initialized
INFO - 2016-06-15 13:00:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-15 13:00:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:55 --> Form Validation Class Initialized
DEBUG - 2016-06-15 13:00:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:55 --> Config Class Initialized
INFO - 2016-06-15 13:00:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:00:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:00:55 --> Utf8 Class Initialized
INFO - 2016-06-15 13:00:55 --> URI Class Initialized
DEBUG - 2016-06-15 13:00:55 --> No URI present. Default controller set.
INFO - 2016-06-15 13:00:55 --> Router Class Initialized
INFO - 2016-06-15 13:00:55 --> Output Class Initialized
INFO - 2016-06-15 13:00:55 --> Security Class Initialized
DEBUG - 2016-06-15 13:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:00:55 --> Input Class Initialized
INFO - 2016-06-15 13:00:55 --> Language Class Initialized
INFO - 2016-06-15 13:00:55 --> Loader Class Initialized
INFO - 2016-06-15 13:00:55 --> Helper loaded: form_helper
INFO - 2016-06-15 13:00:55 --> Database Driver Class Initialized
INFO - 2016-06-15 13:00:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:00:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:00:55 --> Email Class Initialized
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:00:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:00:55 --> Helper loaded: language_helper
INFO - 2016-06-15 13:00:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:55 --> Model Class Initialized
INFO - 2016-06-15 13:00:55 --> Helper loaded: date_helper
INFO - 2016-06-15 13:00:55 --> Controller Class Initialized
INFO - 2016-06-15 13:00:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:00:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:00:56 --> Config Class Initialized
INFO - 2016-06-15 13:00:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:00:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:00:56 --> Utf8 Class Initialized
INFO - 2016-06-15 13:00:56 --> URI Class Initialized
INFO - 2016-06-15 13:00:56 --> Router Class Initialized
INFO - 2016-06-15 13:00:56 --> Output Class Initialized
INFO - 2016-06-15 13:00:56 --> Security Class Initialized
DEBUG - 2016-06-15 13:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:00:56 --> Input Class Initialized
INFO - 2016-06-15 13:00:56 --> Language Class Initialized
INFO - 2016-06-15 13:00:56 --> Loader Class Initialized
INFO - 2016-06-15 13:00:56 --> Helper loaded: form_helper
INFO - 2016-06-15 13:00:56 --> Database Driver Class Initialized
INFO - 2016-06-15 13:00:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:00:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:00:56 --> Email Class Initialized
INFO - 2016-06-15 13:00:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:00:56 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:00:56 --> Helper loaded: language_helper
INFO - 2016-06-15 13:00:56 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:56 --> Model Class Initialized
INFO - 2016-06-15 13:00:56 --> Helper loaded: date_helper
INFO - 2016-06-15 13:00:56 --> Controller Class Initialized
INFO - 2016-06-15 13:00:56 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:00:56 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:00:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:00:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:00:56 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:00:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:00:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:00:56 --> Model Class Initialized
INFO - 2016-06-15 13:00:56 --> Form Validation Class Initialized
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-15 13:00:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 13:00:56 --> Final output sent to browser
DEBUG - 2016-06-15 13:00:56 --> Total execution time: 0.4615
INFO - 2016-06-15 13:00:58 --> Config Class Initialized
INFO - 2016-06-15 13:00:58 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:00:58 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:00:58 --> Utf8 Class Initialized
INFO - 2016-06-15 13:00:58 --> URI Class Initialized
INFO - 2016-06-15 13:00:58 --> Router Class Initialized
INFO - 2016-06-15 13:00:58 --> Output Class Initialized
INFO - 2016-06-15 13:00:58 --> Security Class Initialized
DEBUG - 2016-06-15 13:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:00:58 --> Input Class Initialized
INFO - 2016-06-15 13:00:58 --> Language Class Initialized
INFO - 2016-06-15 13:00:58 --> Loader Class Initialized
INFO - 2016-06-15 13:00:58 --> Helper loaded: form_helper
INFO - 2016-06-15 13:00:58 --> Database Driver Class Initialized
INFO - 2016-06-15 13:00:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:00:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:00:58 --> Email Class Initialized
INFO - 2016-06-15 13:00:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:00:58 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:00:58 --> Helper loaded: language_helper
INFO - 2016-06-15 13:00:58 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:00:58 --> Model Class Initialized
INFO - 2016-06-15 13:00:58 --> Helper loaded: date_helper
INFO - 2016-06-15 13:00:58 --> Controller Class Initialized
INFO - 2016-06-15 13:00:58 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:00:58 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:00:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:00:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:00:58 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:00:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:00:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:00:58 --> Model Class Initialized
INFO - 2016-06-15 13:00:58 --> Form Validation Class Initialized
INFO - 2016-06-15 13:00:58 --> Final output sent to browser
DEBUG - 2016-06-15 13:00:58 --> Total execution time: 0.0396
INFO - 2016-06-15 13:05:45 --> Config Class Initialized
INFO - 2016-06-15 13:05:45 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:05:45 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:05:45 --> Utf8 Class Initialized
INFO - 2016-06-15 13:05:45 --> URI Class Initialized
DEBUG - 2016-06-15 13:05:45 --> No URI present. Default controller set.
INFO - 2016-06-15 13:05:45 --> Router Class Initialized
INFO - 2016-06-15 13:05:45 --> Output Class Initialized
INFO - 2016-06-15 13:05:45 --> Security Class Initialized
DEBUG - 2016-06-15 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:05:45 --> Input Class Initialized
INFO - 2016-06-15 13:05:45 --> Language Class Initialized
INFO - 2016-06-15 13:05:45 --> Loader Class Initialized
INFO - 2016-06-15 13:05:45 --> Helper loaded: form_helper
INFO - 2016-06-15 13:05:45 --> Database Driver Class Initialized
INFO - 2016-06-15 13:05:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:05:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:05:45 --> Email Class Initialized
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:05:45 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:05:45 --> Helper loaded: language_helper
INFO - 2016-06-15 13:05:45 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:05:45 --> Model Class Initialized
INFO - 2016-06-15 13:05:45 --> Helper loaded: date_helper
INFO - 2016-06-15 13:05:45 --> Controller Class Initialized
INFO - 2016-06-15 13:05:45 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:05:45 --> Config Class Initialized
INFO - 2016-06-15 13:05:45 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:05:45 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:05:45 --> Utf8 Class Initialized
INFO - 2016-06-15 13:05:45 --> URI Class Initialized
INFO - 2016-06-15 13:05:45 --> Router Class Initialized
INFO - 2016-06-15 13:05:45 --> Output Class Initialized
INFO - 2016-06-15 13:05:45 --> Security Class Initialized
DEBUG - 2016-06-15 13:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:05:45 --> Input Class Initialized
INFO - 2016-06-15 13:05:45 --> Language Class Initialized
INFO - 2016-06-15 13:05:45 --> Loader Class Initialized
INFO - 2016-06-15 13:05:45 --> Helper loaded: form_helper
INFO - 2016-06-15 13:05:45 --> Database Driver Class Initialized
INFO - 2016-06-15 13:05:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:05:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:05:45 --> Email Class Initialized
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:05:45 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:05:45 --> Helper loaded: language_helper
INFO - 2016-06-15 13:05:45 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:05:45 --> Model Class Initialized
INFO - 2016-06-15 13:05:45 --> Helper loaded: date_helper
INFO - 2016-06-15 13:05:45 --> Controller Class Initialized
INFO - 2016-06-15 13:05:45 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:05:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:05:45 --> Model Class Initialized
INFO - 2016-06-15 13:05:45 --> Form Validation Class Initialized
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-15 13:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 13:05:45 --> Final output sent to browser
DEBUG - 2016-06-15 13:05:45 --> Total execution time: 0.0467
INFO - 2016-06-15 13:05:48 --> Config Class Initialized
INFO - 2016-06-15 13:05:48 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:05:48 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:05:48 --> Utf8 Class Initialized
INFO - 2016-06-15 13:05:48 --> URI Class Initialized
INFO - 2016-06-15 13:05:48 --> Router Class Initialized
INFO - 2016-06-15 13:05:48 --> Output Class Initialized
INFO - 2016-06-15 13:05:48 --> Security Class Initialized
DEBUG - 2016-06-15 13:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:05:48 --> Input Class Initialized
INFO - 2016-06-15 13:05:48 --> Language Class Initialized
INFO - 2016-06-15 13:05:48 --> Loader Class Initialized
INFO - 2016-06-15 13:05:48 --> Helper loaded: form_helper
INFO - 2016-06-15 13:05:48 --> Database Driver Class Initialized
INFO - 2016-06-15 13:05:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:05:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:05:48 --> Email Class Initialized
INFO - 2016-06-15 13:05:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:05:48 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:05:48 --> Helper loaded: language_helper
INFO - 2016-06-15 13:05:48 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:05:48 --> Model Class Initialized
INFO - 2016-06-15 13:05:48 --> Helper loaded: date_helper
INFO - 2016-06-15 13:05:48 --> Controller Class Initialized
INFO - 2016-06-15 13:05:48 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:05:48 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:05:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:05:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:05:48 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:05:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:05:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:05:48 --> Model Class Initialized
INFO - 2016-06-15 13:05:48 --> Form Validation Class Initialized
INFO - 2016-06-15 13:05:48 --> Final output sent to browser
DEBUG - 2016-06-15 13:05:48 --> Total execution time: 0.0453
INFO - 2016-06-15 13:05:51 --> Config Class Initialized
INFO - 2016-06-15 13:05:51 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:05:51 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:05:51 --> Utf8 Class Initialized
INFO - 2016-06-15 13:05:51 --> URI Class Initialized
INFO - 2016-06-15 13:05:51 --> Router Class Initialized
INFO - 2016-06-15 13:05:51 --> Output Class Initialized
INFO - 2016-06-15 13:05:51 --> Security Class Initialized
DEBUG - 2016-06-15 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:05:51 --> Input Class Initialized
INFO - 2016-06-15 13:05:51 --> Language Class Initialized
INFO - 2016-06-15 13:05:51 --> Loader Class Initialized
INFO - 2016-06-15 13:05:51 --> Helper loaded: form_helper
INFO - 2016-06-15 13:05:51 --> Database Driver Class Initialized
INFO - 2016-06-15 13:05:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:05:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:05:51 --> Email Class Initialized
INFO - 2016-06-15 13:05:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:05:51 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:05:51 --> Helper loaded: language_helper
INFO - 2016-06-15 13:05:51 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:05:51 --> Model Class Initialized
INFO - 2016-06-15 13:05:51 --> Helper loaded: date_helper
INFO - 2016-06-15 13:05:51 --> Controller Class Initialized
INFO - 2016-06-15 13:05:51 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:05:51 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:05:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:05:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:05:51 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:05:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:05:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-15 13:05:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:05:51 --> Form Validation Class Initialized
INFO - 2016-06-15 13:05:52 --> Config Class Initialized
INFO - 2016-06-15 13:05:52 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:05:52 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:05:52 --> Utf8 Class Initialized
INFO - 2016-06-15 13:05:52 --> URI Class Initialized
DEBUG - 2016-06-15 13:05:52 --> No URI present. Default controller set.
INFO - 2016-06-15 13:05:52 --> Router Class Initialized
INFO - 2016-06-15 13:05:52 --> Output Class Initialized
INFO - 2016-06-15 13:05:52 --> Security Class Initialized
DEBUG - 2016-06-15 13:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:05:52 --> Input Class Initialized
INFO - 2016-06-15 13:05:52 --> Language Class Initialized
INFO - 2016-06-15 13:05:52 --> Loader Class Initialized
INFO - 2016-06-15 13:05:52 --> Helper loaded: form_helper
INFO - 2016-06-15 13:05:52 --> Database Driver Class Initialized
INFO - 2016-06-15 13:05:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:05:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:05:52 --> Email Class Initialized
INFO - 2016-06-15 13:05:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:05:52 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:05:52 --> Helper loaded: language_helper
INFO - 2016-06-15 13:05:52 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:05:52 --> Model Class Initialized
INFO - 2016-06-15 13:05:52 --> Helper loaded: date_helper
INFO - 2016-06-15 13:05:52 --> Controller Class Initialized
INFO - 2016-06-15 13:05:52 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:05:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:05:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:05:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:05:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:05:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:05:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:05:52 --> Model Class Initialized
INFO - 2016-06-15 13:05:52 --> Form Validation Class Initialized
INFO - 2016-06-15 13:05:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:05:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:05:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 13:05:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:05:52 --> Final output sent to browser
DEBUG - 2016-06-15 13:05:52 --> Total execution time: 0.0152
INFO - 2016-06-15 13:05:54 --> Config Class Initialized
INFO - 2016-06-15 13:05:54 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:05:54 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:05:54 --> Utf8 Class Initialized
INFO - 2016-06-15 13:05:54 --> URI Class Initialized
INFO - 2016-06-15 13:05:54 --> Router Class Initialized
INFO - 2016-06-15 13:05:54 --> Output Class Initialized
INFO - 2016-06-15 13:05:54 --> Security Class Initialized
DEBUG - 2016-06-15 13:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:05:54 --> Input Class Initialized
INFO - 2016-06-15 13:05:54 --> Language Class Initialized
INFO - 2016-06-15 13:05:54 --> Loader Class Initialized
INFO - 2016-06-15 13:05:54 --> Helper loaded: form_helper
INFO - 2016-06-15 13:05:54 --> Database Driver Class Initialized
INFO - 2016-06-15 13:05:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:05:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:05:54 --> Email Class Initialized
INFO - 2016-06-15 13:05:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:05:54 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:05:54 --> Helper loaded: language_helper
INFO - 2016-06-15 13:05:54 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:05:54 --> Model Class Initialized
INFO - 2016-06-15 13:05:54 --> Helper loaded: date_helper
INFO - 2016-06-15 13:05:54 --> Controller Class Initialized
INFO - 2016-06-15 13:05:54 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:05:54 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:05:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:05:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:05:54 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:05:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:05:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:05:54 --> Model Class Initialized
INFO - 2016-06-15 13:05:54 --> Final output sent to browser
DEBUG - 2016-06-15 13:05:54 --> Total execution time: 0.0143
INFO - 2016-06-15 13:06:11 --> Config Class Initialized
INFO - 2016-06-15 13:06:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:06:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:06:11 --> Utf8 Class Initialized
INFO - 2016-06-15 13:06:11 --> URI Class Initialized
DEBUG - 2016-06-15 13:06:11 --> No URI present. Default controller set.
INFO - 2016-06-15 13:06:11 --> Router Class Initialized
INFO - 2016-06-15 13:06:11 --> Output Class Initialized
INFO - 2016-06-15 13:06:11 --> Security Class Initialized
DEBUG - 2016-06-15 13:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:06:11 --> Input Class Initialized
INFO - 2016-06-15 13:06:11 --> Language Class Initialized
INFO - 2016-06-15 13:06:11 --> Loader Class Initialized
INFO - 2016-06-15 13:06:11 --> Helper loaded: form_helper
INFO - 2016-06-15 13:06:11 --> Database Driver Class Initialized
INFO - 2016-06-15 13:06:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:06:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:06:11 --> Email Class Initialized
INFO - 2016-06-15 13:06:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:06:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:06:11 --> Helper loaded: language_helper
INFO - 2016-06-15 13:06:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:06:11 --> Model Class Initialized
INFO - 2016-06-15 13:06:11 --> Helper loaded: date_helper
INFO - 2016-06-15 13:06:11 --> Controller Class Initialized
INFO - 2016-06-15 13:06:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:06:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:06:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:06:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:06:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:06:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:06:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:06:11 --> Model Class Initialized
INFO - 2016-06-15 13:06:11 --> Form Validation Class Initialized
INFO - 2016-06-15 13:06:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:06:11 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:06:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 13:06:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:06:11 --> Final output sent to browser
DEBUG - 2016-06-15 13:06:11 --> Total execution time: 0.0228
INFO - 2016-06-15 13:06:13 --> Config Class Initialized
INFO - 2016-06-15 13:06:13 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:06:13 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:06:13 --> Utf8 Class Initialized
INFO - 2016-06-15 13:06:13 --> URI Class Initialized
INFO - 2016-06-15 13:06:13 --> Router Class Initialized
INFO - 2016-06-15 13:06:13 --> Output Class Initialized
INFO - 2016-06-15 13:06:13 --> Security Class Initialized
DEBUG - 2016-06-15 13:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:06:13 --> Input Class Initialized
INFO - 2016-06-15 13:06:13 --> Language Class Initialized
INFO - 2016-06-15 13:06:13 --> Loader Class Initialized
INFO - 2016-06-15 13:06:13 --> Helper loaded: form_helper
INFO - 2016-06-15 13:06:13 --> Database Driver Class Initialized
INFO - 2016-06-15 13:06:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:06:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:06:13 --> Email Class Initialized
INFO - 2016-06-15 13:06:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:06:13 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:06:13 --> Helper loaded: language_helper
INFO - 2016-06-15 13:06:13 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:06:13 --> Model Class Initialized
INFO - 2016-06-15 13:06:13 --> Helper loaded: date_helper
INFO - 2016-06-15 13:06:13 --> Controller Class Initialized
INFO - 2016-06-15 13:06:13 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:06:13 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:06:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:06:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:06:13 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:06:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:06:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:06:13 --> Model Class Initialized
INFO - 2016-06-15 13:06:13 --> Final output sent to browser
DEBUG - 2016-06-15 13:06:13 --> Total execution time: 0.0180
INFO - 2016-06-15 13:07:54 --> Config Class Initialized
INFO - 2016-06-15 13:07:54 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:07:54 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:07:54 --> Utf8 Class Initialized
INFO - 2016-06-15 13:07:54 --> URI Class Initialized
DEBUG - 2016-06-15 13:07:54 --> No URI present. Default controller set.
INFO - 2016-06-15 13:07:54 --> Router Class Initialized
INFO - 2016-06-15 13:07:54 --> Output Class Initialized
INFO - 2016-06-15 13:07:54 --> Security Class Initialized
DEBUG - 2016-06-15 13:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:07:54 --> Input Class Initialized
INFO - 2016-06-15 13:07:54 --> Language Class Initialized
INFO - 2016-06-15 13:07:54 --> Loader Class Initialized
INFO - 2016-06-15 13:07:54 --> Helper loaded: form_helper
INFO - 2016-06-15 13:07:54 --> Database Driver Class Initialized
INFO - 2016-06-15 13:07:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:07:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:07:54 --> Email Class Initialized
INFO - 2016-06-15 13:07:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:07:54 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:07:54 --> Helper loaded: language_helper
INFO - 2016-06-15 13:07:54 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:07:54 --> Model Class Initialized
INFO - 2016-06-15 13:07:54 --> Helper loaded: date_helper
INFO - 2016-06-15 13:07:54 --> Controller Class Initialized
INFO - 2016-06-15 13:07:54 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:07:54 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:07:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:07:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:07:54 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:07:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:07:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:07:54 --> Model Class Initialized
INFO - 2016-06-15 13:07:54 --> Form Validation Class Initialized
INFO - 2016-06-15 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:07:54 --> Final output sent to browser
DEBUG - 2016-06-15 13:07:54 --> Total execution time: 0.0260
INFO - 2016-06-15 13:07:55 --> Config Class Initialized
INFO - 2016-06-15 13:07:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:07:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:07:55 --> Utf8 Class Initialized
INFO - 2016-06-15 13:07:55 --> URI Class Initialized
INFO - 2016-06-15 13:07:55 --> Router Class Initialized
INFO - 2016-06-15 13:07:55 --> Output Class Initialized
INFO - 2016-06-15 13:07:55 --> Security Class Initialized
DEBUG - 2016-06-15 13:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:07:55 --> Input Class Initialized
INFO - 2016-06-15 13:07:55 --> Language Class Initialized
INFO - 2016-06-15 13:07:55 --> Loader Class Initialized
INFO - 2016-06-15 13:07:55 --> Helper loaded: form_helper
INFO - 2016-06-15 13:07:55 --> Database Driver Class Initialized
INFO - 2016-06-15 13:07:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:07:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:07:55 --> Email Class Initialized
INFO - 2016-06-15 13:07:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:07:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:07:55 --> Helper loaded: language_helper
INFO - 2016-06-15 13:07:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:07:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:07:55 --> Model Class Initialized
INFO - 2016-06-15 13:07:55 --> Helper loaded: date_helper
INFO - 2016-06-15 13:07:55 --> Controller Class Initialized
INFO - 2016-06-15 13:07:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:07:55 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:07:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:07:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:07:55 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:07:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:07:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:07:55 --> Model Class Initialized
INFO - 2016-06-15 13:07:55 --> Final output sent to browser
DEBUG - 2016-06-15 13:07:55 --> Total execution time: 0.0130
INFO - 2016-06-15 13:09:11 --> Config Class Initialized
INFO - 2016-06-15 13:09:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:09:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:09:11 --> Utf8 Class Initialized
INFO - 2016-06-15 13:09:11 --> URI Class Initialized
DEBUG - 2016-06-15 13:09:11 --> No URI present. Default controller set.
INFO - 2016-06-15 13:09:11 --> Router Class Initialized
INFO - 2016-06-15 13:09:11 --> Output Class Initialized
INFO - 2016-06-15 13:09:11 --> Security Class Initialized
DEBUG - 2016-06-15 13:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:09:11 --> Input Class Initialized
INFO - 2016-06-15 13:09:11 --> Language Class Initialized
INFO - 2016-06-15 13:09:11 --> Loader Class Initialized
INFO - 2016-06-15 13:09:11 --> Helper loaded: form_helper
INFO - 2016-06-15 13:09:11 --> Database Driver Class Initialized
INFO - 2016-06-15 13:09:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:09:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:09:11 --> Email Class Initialized
INFO - 2016-06-15 13:09:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:09:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:09:11 --> Helper loaded: language_helper
INFO - 2016-06-15 13:09:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:09:11 --> Model Class Initialized
INFO - 2016-06-15 13:09:11 --> Helper loaded: date_helper
INFO - 2016-06-15 13:09:11 --> Controller Class Initialized
INFO - 2016-06-15 13:09:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:09:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:09:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:09:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:09:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:09:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:09:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:09:11 --> Model Class Initialized
INFO - 2016-06-15 13:09:11 --> Form Validation Class Initialized
INFO - 2016-06-15 13:09:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:09:11 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:09:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 13:09:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:09:11 --> Final output sent to browser
DEBUG - 2016-06-15 13:09:11 --> Total execution time: 0.0617
INFO - 2016-06-15 13:09:12 --> Config Class Initialized
INFO - 2016-06-15 13:09:12 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:09:12 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:09:12 --> Utf8 Class Initialized
INFO - 2016-06-15 13:09:12 --> URI Class Initialized
INFO - 2016-06-15 13:09:12 --> Router Class Initialized
INFO - 2016-06-15 13:09:12 --> Output Class Initialized
INFO - 2016-06-15 13:09:12 --> Security Class Initialized
DEBUG - 2016-06-15 13:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:09:12 --> Input Class Initialized
INFO - 2016-06-15 13:09:12 --> Language Class Initialized
INFO - 2016-06-15 13:09:12 --> Loader Class Initialized
INFO - 2016-06-15 13:09:12 --> Helper loaded: form_helper
INFO - 2016-06-15 13:09:12 --> Database Driver Class Initialized
INFO - 2016-06-15 13:09:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:09:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:09:12 --> Email Class Initialized
INFO - 2016-06-15 13:09:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:09:12 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:09:12 --> Helper loaded: language_helper
INFO - 2016-06-15 13:09:12 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:09:12 --> Model Class Initialized
INFO - 2016-06-15 13:09:12 --> Helper loaded: date_helper
INFO - 2016-06-15 13:09:12 --> Controller Class Initialized
INFO - 2016-06-15 13:09:12 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:09:12 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:09:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:09:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:09:12 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:09:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:09:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:09:12 --> Model Class Initialized
INFO - 2016-06-15 13:09:12 --> Final output sent to browser
DEBUG - 2016-06-15 13:09:12 --> Total execution time: 0.0194
INFO - 2016-06-15 13:12:46 --> Config Class Initialized
INFO - 2016-06-15 13:12:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:12:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:12:46 --> Utf8 Class Initialized
INFO - 2016-06-15 13:12:46 --> URI Class Initialized
DEBUG - 2016-06-15 13:12:46 --> No URI present. Default controller set.
INFO - 2016-06-15 13:12:46 --> Router Class Initialized
INFO - 2016-06-15 13:12:46 --> Output Class Initialized
INFO - 2016-06-15 13:12:46 --> Security Class Initialized
DEBUG - 2016-06-15 13:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:12:46 --> Input Class Initialized
INFO - 2016-06-15 13:12:46 --> Language Class Initialized
INFO - 2016-06-15 13:12:46 --> Loader Class Initialized
INFO - 2016-06-15 13:12:46 --> Helper loaded: form_helper
INFO - 2016-06-15 13:12:46 --> Database Driver Class Initialized
INFO - 2016-06-15 13:12:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:12:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:12:46 --> Email Class Initialized
INFO - 2016-06-15 13:12:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:12:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:12:46 --> Helper loaded: language_helper
INFO - 2016-06-15 13:12:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:12:46 --> Model Class Initialized
INFO - 2016-06-15 13:12:46 --> Helper loaded: date_helper
INFO - 2016-06-15 13:12:46 --> Controller Class Initialized
INFO - 2016-06-15 13:12:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:12:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:12:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:12:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:12:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:12:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:12:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:12:46 --> Model Class Initialized
INFO - 2016-06-15 13:12:46 --> Form Validation Class Initialized
INFO - 2016-06-15 13:12:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:12:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:12:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 13:12:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:12:46 --> Final output sent to browser
DEBUG - 2016-06-15 13:12:46 --> Total execution time: 0.0558
INFO - 2016-06-15 13:12:47 --> Config Class Initialized
INFO - 2016-06-15 13:12:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:12:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:12:47 --> Utf8 Class Initialized
INFO - 2016-06-15 13:12:47 --> URI Class Initialized
INFO - 2016-06-15 13:12:47 --> Router Class Initialized
INFO - 2016-06-15 13:12:47 --> Output Class Initialized
INFO - 2016-06-15 13:12:47 --> Security Class Initialized
DEBUG - 2016-06-15 13:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:12:47 --> Input Class Initialized
INFO - 2016-06-15 13:12:47 --> Language Class Initialized
INFO - 2016-06-15 13:12:47 --> Loader Class Initialized
INFO - 2016-06-15 13:12:47 --> Helper loaded: form_helper
INFO - 2016-06-15 13:12:47 --> Database Driver Class Initialized
INFO - 2016-06-15 13:12:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:12:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:12:47 --> Email Class Initialized
INFO - 2016-06-15 13:12:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:12:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:12:47 --> Helper loaded: language_helper
INFO - 2016-06-15 13:12:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:12:47 --> Model Class Initialized
INFO - 2016-06-15 13:12:47 --> Helper loaded: date_helper
INFO - 2016-06-15 13:12:47 --> Controller Class Initialized
INFO - 2016-06-15 13:12:47 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:12:47 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:12:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:12:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:12:47 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:12:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:12:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:12:47 --> Model Class Initialized
INFO - 2016-06-15 13:12:47 --> Final output sent to browser
DEBUG - 2016-06-15 13:12:47 --> Total execution time: 0.0153
INFO - 2016-06-15 13:16:50 --> Config Class Initialized
INFO - 2016-06-15 13:16:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:16:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:16:50 --> Utf8 Class Initialized
INFO - 2016-06-15 13:16:50 --> URI Class Initialized
DEBUG - 2016-06-15 13:16:50 --> No URI present. Default controller set.
INFO - 2016-06-15 13:16:50 --> Router Class Initialized
INFO - 2016-06-15 13:16:50 --> Output Class Initialized
INFO - 2016-06-15 13:16:50 --> Security Class Initialized
DEBUG - 2016-06-15 13:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:16:50 --> Input Class Initialized
INFO - 2016-06-15 13:16:50 --> Language Class Initialized
INFO - 2016-06-15 13:16:50 --> Loader Class Initialized
INFO - 2016-06-15 13:16:50 --> Helper loaded: form_helper
INFO - 2016-06-15 13:16:50 --> Database Driver Class Initialized
INFO - 2016-06-15 13:16:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:16:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:16:50 --> Email Class Initialized
INFO - 2016-06-15 13:16:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:16:50 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:16:50 --> Helper loaded: language_helper
INFO - 2016-06-15 13:16:50 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:16:50 --> Model Class Initialized
INFO - 2016-06-15 13:16:50 --> Helper loaded: date_helper
INFO - 2016-06-15 13:16:50 --> Controller Class Initialized
INFO - 2016-06-15 13:16:50 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:16:50 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:16:50 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:16:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:16:50 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:16:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:16:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:16:50 --> Model Class Initialized
INFO - 2016-06-15 13:16:50 --> Form Validation Class Initialized
INFO - 2016-06-15 13:16:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:16:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:16:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 13:16:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:16:50 --> Final output sent to browser
DEBUG - 2016-06-15 13:16:50 --> Total execution time: 0.0455
INFO - 2016-06-15 13:16:52 --> Config Class Initialized
INFO - 2016-06-15 13:16:52 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:16:52 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:16:52 --> Utf8 Class Initialized
INFO - 2016-06-15 13:16:52 --> URI Class Initialized
INFO - 2016-06-15 13:16:52 --> Router Class Initialized
INFO - 2016-06-15 13:16:52 --> Output Class Initialized
INFO - 2016-06-15 13:16:52 --> Security Class Initialized
DEBUG - 2016-06-15 13:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:16:52 --> Input Class Initialized
INFO - 2016-06-15 13:16:52 --> Language Class Initialized
INFO - 2016-06-15 13:16:52 --> Loader Class Initialized
INFO - 2016-06-15 13:16:52 --> Helper loaded: form_helper
INFO - 2016-06-15 13:16:52 --> Database Driver Class Initialized
INFO - 2016-06-15 13:16:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:16:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:16:52 --> Email Class Initialized
INFO - 2016-06-15 13:16:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:16:52 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:16:52 --> Helper loaded: language_helper
INFO - 2016-06-15 13:16:52 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:16:52 --> Model Class Initialized
INFO - 2016-06-15 13:16:52 --> Helper loaded: date_helper
INFO - 2016-06-15 13:16:52 --> Controller Class Initialized
INFO - 2016-06-15 13:16:52 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:16:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:16:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:16:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:16:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:16:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:16:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:16:52 --> Model Class Initialized
INFO - 2016-06-15 13:16:52 --> Final output sent to browser
DEBUG - 2016-06-15 13:16:52 --> Total execution time: 0.0128
INFO - 2016-06-15 13:17:08 --> Config Class Initialized
INFO - 2016-06-15 13:17:08 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:17:08 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:17:08 --> Utf8 Class Initialized
INFO - 2016-06-15 13:17:08 --> URI Class Initialized
DEBUG - 2016-06-15 13:17:08 --> No URI present. Default controller set.
INFO - 2016-06-15 13:17:08 --> Router Class Initialized
INFO - 2016-06-15 13:17:08 --> Output Class Initialized
INFO - 2016-06-15 13:17:08 --> Security Class Initialized
DEBUG - 2016-06-15 13:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:17:08 --> Input Class Initialized
INFO - 2016-06-15 13:17:08 --> Language Class Initialized
INFO - 2016-06-15 13:17:08 --> Loader Class Initialized
INFO - 2016-06-15 13:17:08 --> Helper loaded: form_helper
INFO - 2016-06-15 13:17:08 --> Database Driver Class Initialized
INFO - 2016-06-15 13:17:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:17:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:17:08 --> Email Class Initialized
INFO - 2016-06-15 13:17:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:17:08 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:17:08 --> Helper loaded: language_helper
INFO - 2016-06-15 13:17:08 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:17:08 --> Model Class Initialized
INFO - 2016-06-15 13:17:08 --> Helper loaded: date_helper
INFO - 2016-06-15 13:17:08 --> Controller Class Initialized
INFO - 2016-06-15 13:17:08 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:17:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:17:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:17:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:17:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:17:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:17:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:17:08 --> Model Class Initialized
INFO - 2016-06-15 13:17:08 --> Form Validation Class Initialized
INFO - 2016-06-15 13:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 13:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 13:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 13:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 13:17:08 --> Final output sent to browser
DEBUG - 2016-06-15 13:17:08 --> Total execution time: 0.0217
INFO - 2016-06-15 13:17:11 --> Config Class Initialized
INFO - 2016-06-15 13:17:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 13:17:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 13:17:11 --> Utf8 Class Initialized
INFO - 2016-06-15 13:17:11 --> URI Class Initialized
INFO - 2016-06-15 13:17:11 --> Router Class Initialized
INFO - 2016-06-15 13:17:11 --> Output Class Initialized
INFO - 2016-06-15 13:17:11 --> Security Class Initialized
DEBUG - 2016-06-15 13:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 13:17:11 --> Input Class Initialized
INFO - 2016-06-15 13:17:11 --> Language Class Initialized
INFO - 2016-06-15 13:17:11 --> Loader Class Initialized
INFO - 2016-06-15 13:17:11 --> Helper loaded: form_helper
INFO - 2016-06-15 13:17:11 --> Database Driver Class Initialized
INFO - 2016-06-15 13:17:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 13:17:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 13:17:11 --> Email Class Initialized
INFO - 2016-06-15 13:17:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 13:17:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 13:17:11 --> Helper loaded: language_helper
INFO - 2016-06-15 13:17:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 13:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 13:17:11 --> Model Class Initialized
INFO - 2016-06-15 13:17:11 --> Helper loaded: date_helper
INFO - 2016-06-15 13:17:11 --> Controller Class Initialized
INFO - 2016-06-15 13:17:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 13:17:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 13:17:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 13:17:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 13:17:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 13:17:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 13:17:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 13:17:11 --> Model Class Initialized
INFO - 2016-06-15 13:17:11 --> Final output sent to browser
DEBUG - 2016-06-15 13:17:11 --> Total execution time: 0.0131
INFO - 2016-06-15 14:51:53 --> Config Class Initialized
INFO - 2016-06-15 14:51:53 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:51:53 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:51:53 --> Utf8 Class Initialized
INFO - 2016-06-15 14:51:53 --> URI Class Initialized
DEBUG - 2016-06-15 14:51:53 --> No URI present. Default controller set.
INFO - 2016-06-15 14:51:53 --> Router Class Initialized
INFO - 2016-06-15 14:51:53 --> Output Class Initialized
INFO - 2016-06-15 14:51:53 --> Security Class Initialized
DEBUG - 2016-06-15 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:51:53 --> Input Class Initialized
INFO - 2016-06-15 14:51:53 --> Language Class Initialized
INFO - 2016-06-15 14:51:53 --> Loader Class Initialized
INFO - 2016-06-15 14:51:53 --> Helper loaded: form_helper
INFO - 2016-06-15 14:51:53 --> Database Driver Class Initialized
INFO - 2016-06-15 14:51:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:51:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:51:53 --> Email Class Initialized
INFO - 2016-06-15 14:51:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:51:53 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:51:53 --> Helper loaded: language_helper
INFO - 2016-06-15 14:51:53 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:51:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:51:53 --> Model Class Initialized
INFO - 2016-06-15 14:51:53 --> Helper loaded: date_helper
INFO - 2016-06-15 14:51:53 --> Controller Class Initialized
INFO - 2016-06-15 14:51:53 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:51:53 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:51:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:51:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:51:53 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:51:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:51:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 14:51:53 --> Model Class Initialized
INFO - 2016-06-15 14:51:53 --> Form Validation Class Initialized
INFO - 2016-06-15 14:51:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 14:51:53 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 14:51:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 14:51:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 14:51:53 --> Final output sent to browser
DEBUG - 2016-06-15 14:51:53 --> Total execution time: 0.0639
INFO - 2016-06-15 14:51:55 --> Config Class Initialized
INFO - 2016-06-15 14:51:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:51:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:51:55 --> Utf8 Class Initialized
INFO - 2016-06-15 14:51:55 --> URI Class Initialized
INFO - 2016-06-15 14:51:55 --> Router Class Initialized
INFO - 2016-06-15 14:51:55 --> Output Class Initialized
INFO - 2016-06-15 14:51:55 --> Security Class Initialized
DEBUG - 2016-06-15 14:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:51:55 --> Input Class Initialized
INFO - 2016-06-15 14:51:55 --> Language Class Initialized
INFO - 2016-06-15 14:51:55 --> Loader Class Initialized
INFO - 2016-06-15 14:51:55 --> Helper loaded: form_helper
INFO - 2016-06-15 14:51:55 --> Database Driver Class Initialized
INFO - 2016-06-15 14:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:51:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:51:55 --> Email Class Initialized
INFO - 2016-06-15 14:51:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:51:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:51:55 --> Helper loaded: language_helper
INFO - 2016-06-15 14:51:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:51:55 --> Model Class Initialized
INFO - 2016-06-15 14:51:55 --> Helper loaded: date_helper
INFO - 2016-06-15 14:51:55 --> Controller Class Initialized
INFO - 2016-06-15 14:51:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:51:55 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:51:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:51:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:51:55 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:51:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:51:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 14:51:55 --> Model Class Initialized
INFO - 2016-06-15 14:51:55 --> Final output sent to browser
DEBUG - 2016-06-15 14:51:55 --> Total execution time: 0.0135
INFO - 2016-06-15 14:53:56 --> Config Class Initialized
INFO - 2016-06-15 14:53:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:53:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:53:56 --> Utf8 Class Initialized
INFO - 2016-06-15 14:53:56 --> URI Class Initialized
INFO - 2016-06-15 14:53:56 --> Router Class Initialized
INFO - 2016-06-15 14:53:56 --> Output Class Initialized
INFO - 2016-06-15 14:53:56 --> Security Class Initialized
DEBUG - 2016-06-15 14:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:53:56 --> Input Class Initialized
INFO - 2016-06-15 14:53:56 --> Language Class Initialized
INFO - 2016-06-15 14:53:56 --> Loader Class Initialized
INFO - 2016-06-15 14:53:56 --> Helper loaded: form_helper
INFO - 2016-06-15 14:53:56 --> Database Driver Class Initialized
INFO - 2016-06-15 14:53:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:53:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:53:56 --> Email Class Initialized
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:53:56 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:53:56 --> Helper loaded: language_helper
INFO - 2016-06-15 14:53:56 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:53:56 --> Model Class Initialized
INFO - 2016-06-15 14:53:56 --> Helper loaded: date_helper
INFO - 2016-06-15 14:53:56 --> Controller Class Initialized
INFO - 2016-06-15 14:53:56 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 14:53:56 --> Config Class Initialized
INFO - 2016-06-15 14:53:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:53:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:53:56 --> Utf8 Class Initialized
INFO - 2016-06-15 14:53:56 --> URI Class Initialized
DEBUG - 2016-06-15 14:53:56 --> No URI present. Default controller set.
INFO - 2016-06-15 14:53:56 --> Router Class Initialized
INFO - 2016-06-15 14:53:56 --> Output Class Initialized
INFO - 2016-06-15 14:53:56 --> Security Class Initialized
DEBUG - 2016-06-15 14:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:53:56 --> Input Class Initialized
INFO - 2016-06-15 14:53:56 --> Language Class Initialized
INFO - 2016-06-15 14:53:56 --> Loader Class Initialized
INFO - 2016-06-15 14:53:56 --> Helper loaded: form_helper
INFO - 2016-06-15 14:53:56 --> Database Driver Class Initialized
INFO - 2016-06-15 14:53:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:53:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:53:56 --> Email Class Initialized
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:53:56 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:53:56 --> Helper loaded: language_helper
INFO - 2016-06-15 14:53:56 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:53:56 --> Model Class Initialized
INFO - 2016-06-15 14:53:56 --> Helper loaded: date_helper
INFO - 2016-06-15 14:53:56 --> Controller Class Initialized
INFO - 2016-06-15 14:53:56 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:53:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:53:56 --> Model Class Initialized
INFO - 2016-06-15 14:53:56 --> Form Validation Class Initialized
INFO - 2016-06-15 14:53:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 14:53:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 14:53:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 14:53:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 14:53:56 --> Final output sent to browser
DEBUG - 2016-06-15 14:53:56 --> Total execution time: 0.1058
INFO - 2016-06-15 14:53:58 --> Config Class Initialized
INFO - 2016-06-15 14:53:58 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:53:58 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:53:58 --> Utf8 Class Initialized
INFO - 2016-06-15 14:53:58 --> URI Class Initialized
INFO - 2016-06-15 14:53:58 --> Router Class Initialized
INFO - 2016-06-15 14:53:58 --> Output Class Initialized
INFO - 2016-06-15 14:53:58 --> Security Class Initialized
DEBUG - 2016-06-15 14:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:53:58 --> Input Class Initialized
INFO - 2016-06-15 14:53:58 --> Language Class Initialized
INFO - 2016-06-15 14:53:58 --> Loader Class Initialized
INFO - 2016-06-15 14:53:58 --> Helper loaded: form_helper
INFO - 2016-06-15 14:53:58 --> Database Driver Class Initialized
INFO - 2016-06-15 14:53:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:53:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:53:58 --> Email Class Initialized
INFO - 2016-06-15 14:53:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:53:58 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:53:58 --> Helper loaded: language_helper
INFO - 2016-06-15 14:53:58 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:53:58 --> Model Class Initialized
INFO - 2016-06-15 14:53:58 --> Helper loaded: date_helper
INFO - 2016-06-15 14:53:58 --> Controller Class Initialized
INFO - 2016-06-15 14:53:58 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:53:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:53:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:53:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:53:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:53:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:53:58 --> Model Class Initialized
INFO - 2016-06-15 14:53:58 --> Final output sent to browser
DEBUG - 2016-06-15 14:53:58 --> Total execution time: 0.0120
INFO - 2016-06-15 14:54:30 --> Config Class Initialized
INFO - 2016-06-15 14:54:30 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:54:30 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:54:30 --> Utf8 Class Initialized
INFO - 2016-06-15 14:54:31 --> URI Class Initialized
DEBUG - 2016-06-15 14:54:31 --> No URI present. Default controller set.
INFO - 2016-06-15 14:54:31 --> Router Class Initialized
INFO - 2016-06-15 14:54:31 --> Output Class Initialized
INFO - 2016-06-15 14:54:31 --> Security Class Initialized
DEBUG - 2016-06-15 14:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:54:31 --> Input Class Initialized
INFO - 2016-06-15 14:54:31 --> Language Class Initialized
INFO - 2016-06-15 14:54:31 --> Loader Class Initialized
INFO - 2016-06-15 14:54:31 --> Helper loaded: form_helper
INFO - 2016-06-15 14:54:31 --> Database Driver Class Initialized
INFO - 2016-06-15 14:54:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:54:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:54:31 --> Email Class Initialized
INFO - 2016-06-15 14:54:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:54:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:54:31 --> Helper loaded: language_helper
INFO - 2016-06-15 14:54:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:54:31 --> Model Class Initialized
INFO - 2016-06-15 14:54:31 --> Helper loaded: date_helper
INFO - 2016-06-15 14:54:31 --> Controller Class Initialized
INFO - 2016-06-15 14:54:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:54:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:54:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:54:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:54:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:54:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:54:31 --> Model Class Initialized
INFO - 2016-06-15 14:54:31 --> Form Validation Class Initialized
INFO - 2016-06-15 14:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 14:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 14:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 14:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 14:54:31 --> Final output sent to browser
DEBUG - 2016-06-15 14:54:31 --> Total execution time: 0.0586
INFO - 2016-06-15 14:54:32 --> Config Class Initialized
INFO - 2016-06-15 14:54:32 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:54:32 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:54:32 --> Utf8 Class Initialized
INFO - 2016-06-15 14:54:32 --> URI Class Initialized
INFO - 2016-06-15 14:54:32 --> Router Class Initialized
INFO - 2016-06-15 14:54:32 --> Output Class Initialized
INFO - 2016-06-15 14:54:32 --> Security Class Initialized
DEBUG - 2016-06-15 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:54:32 --> Input Class Initialized
INFO - 2016-06-15 14:54:32 --> Language Class Initialized
INFO - 2016-06-15 14:54:32 --> Loader Class Initialized
INFO - 2016-06-15 14:54:32 --> Helper loaded: form_helper
INFO - 2016-06-15 14:54:32 --> Database Driver Class Initialized
INFO - 2016-06-15 14:54:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:54:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:54:32 --> Email Class Initialized
INFO - 2016-06-15 14:54:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:54:32 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:54:32 --> Helper loaded: language_helper
INFO - 2016-06-15 14:54:32 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:54:32 --> Model Class Initialized
INFO - 2016-06-15 14:54:32 --> Helper loaded: date_helper
INFO - 2016-06-15 14:54:32 --> Controller Class Initialized
INFO - 2016-06-15 14:54:32 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:54:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:54:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:54:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:54:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:54:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:54:32 --> Model Class Initialized
INFO - 2016-06-15 14:54:32 --> Final output sent to browser
DEBUG - 2016-06-15 14:54:32 --> Total execution time: 0.0121
INFO - 2016-06-15 14:55:50 --> Config Class Initialized
INFO - 2016-06-15 14:55:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:55:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:55:50 --> Utf8 Class Initialized
INFO - 2016-06-15 14:55:50 --> URI Class Initialized
DEBUG - 2016-06-15 14:55:50 --> No URI present. Default controller set.
INFO - 2016-06-15 14:55:50 --> Router Class Initialized
INFO - 2016-06-15 14:55:50 --> Output Class Initialized
INFO - 2016-06-15 14:55:50 --> Security Class Initialized
DEBUG - 2016-06-15 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:55:50 --> Input Class Initialized
INFO - 2016-06-15 14:55:50 --> Language Class Initialized
INFO - 2016-06-15 14:55:50 --> Loader Class Initialized
INFO - 2016-06-15 14:55:50 --> Helper loaded: form_helper
INFO - 2016-06-15 14:55:50 --> Database Driver Class Initialized
INFO - 2016-06-15 14:55:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:55:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:55:50 --> Email Class Initialized
INFO - 2016-06-15 14:55:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:55:50 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:55:50 --> Helper loaded: language_helper
INFO - 2016-06-15 14:55:50 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:55:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:55:50 --> Model Class Initialized
INFO - 2016-06-15 14:55:50 --> Helper loaded: date_helper
INFO - 2016-06-15 14:55:50 --> Controller Class Initialized
INFO - 2016-06-15 14:55:50 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:55:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:55:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:55:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:55:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:55:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:55:50 --> Model Class Initialized
INFO - 2016-06-15 14:55:50 --> Form Validation Class Initialized
INFO - 2016-06-15 14:55:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 14:55:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 14:55:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 14:55:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 14:55:50 --> Final output sent to browser
DEBUG - 2016-06-15 14:55:50 --> Total execution time: 0.0136
INFO - 2016-06-15 14:55:52 --> Config Class Initialized
INFO - 2016-06-15 14:55:52 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:55:52 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:55:52 --> Utf8 Class Initialized
INFO - 2016-06-15 14:55:52 --> URI Class Initialized
INFO - 2016-06-15 14:55:52 --> Router Class Initialized
INFO - 2016-06-15 14:55:52 --> Output Class Initialized
INFO - 2016-06-15 14:55:52 --> Security Class Initialized
DEBUG - 2016-06-15 14:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:55:52 --> Input Class Initialized
INFO - 2016-06-15 14:55:52 --> Language Class Initialized
INFO - 2016-06-15 14:55:52 --> Loader Class Initialized
INFO - 2016-06-15 14:55:52 --> Helper loaded: form_helper
INFO - 2016-06-15 14:55:52 --> Database Driver Class Initialized
INFO - 2016-06-15 14:55:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:55:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:55:52 --> Email Class Initialized
INFO - 2016-06-15 14:55:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:55:52 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:55:52 --> Helper loaded: language_helper
INFO - 2016-06-15 14:55:52 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:55:52 --> Model Class Initialized
INFO - 2016-06-15 14:55:52 --> Helper loaded: date_helper
INFO - 2016-06-15 14:55:52 --> Controller Class Initialized
INFO - 2016-06-15 14:55:52 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:55:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:55:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:55:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:55:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:55:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:55:52 --> Model Class Initialized
INFO - 2016-06-15 14:55:52 --> Final output sent to browser
DEBUG - 2016-06-15 14:55:52 --> Total execution time: 0.0299
INFO - 2016-06-15 14:58:24 --> Config Class Initialized
INFO - 2016-06-15 14:58:24 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:58:24 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:58:24 --> Utf8 Class Initialized
INFO - 2016-06-15 14:58:24 --> URI Class Initialized
DEBUG - 2016-06-15 14:58:24 --> No URI present. Default controller set.
INFO - 2016-06-15 14:58:24 --> Router Class Initialized
INFO - 2016-06-15 14:58:24 --> Output Class Initialized
INFO - 2016-06-15 14:58:24 --> Security Class Initialized
DEBUG - 2016-06-15 14:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:58:24 --> Input Class Initialized
INFO - 2016-06-15 14:58:24 --> Language Class Initialized
INFO - 2016-06-15 14:58:24 --> Loader Class Initialized
INFO - 2016-06-15 14:58:24 --> Helper loaded: form_helper
INFO - 2016-06-15 14:58:24 --> Database Driver Class Initialized
INFO - 2016-06-15 14:58:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:58:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:58:24 --> Email Class Initialized
INFO - 2016-06-15 14:58:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:58:24 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:58:24 --> Helper loaded: language_helper
INFO - 2016-06-15 14:58:24 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:58:24 --> Model Class Initialized
INFO - 2016-06-15 14:58:24 --> Helper loaded: date_helper
INFO - 2016-06-15 14:58:24 --> Controller Class Initialized
INFO - 2016-06-15 14:58:24 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:58:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:58:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:58:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:58:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:58:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:58:24 --> Model Class Initialized
INFO - 2016-06-15 14:58:24 --> Form Validation Class Initialized
INFO - 2016-06-15 14:58:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 14:58:24 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 14:58:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 14:58:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 14:58:24 --> Final output sent to browser
DEBUG - 2016-06-15 14:58:24 --> Total execution time: 0.0132
INFO - 2016-06-15 14:58:26 --> Config Class Initialized
INFO - 2016-06-15 14:58:26 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:58:26 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:58:26 --> Utf8 Class Initialized
INFO - 2016-06-15 14:58:26 --> URI Class Initialized
INFO - 2016-06-15 14:58:26 --> Router Class Initialized
INFO - 2016-06-15 14:58:26 --> Output Class Initialized
INFO - 2016-06-15 14:58:26 --> Security Class Initialized
DEBUG - 2016-06-15 14:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:58:26 --> Input Class Initialized
INFO - 2016-06-15 14:58:26 --> Language Class Initialized
INFO - 2016-06-15 14:58:26 --> Loader Class Initialized
INFO - 2016-06-15 14:58:26 --> Helper loaded: form_helper
INFO - 2016-06-15 14:58:26 --> Database Driver Class Initialized
INFO - 2016-06-15 14:58:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:58:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 14:58:26 --> Email Class Initialized
INFO - 2016-06-15 14:58:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:58:26 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:58:26 --> Helper loaded: language_helper
INFO - 2016-06-15 14:58:26 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:58:26 --> Model Class Initialized
INFO - 2016-06-15 14:58:26 --> Helper loaded: date_helper
INFO - 2016-06-15 14:58:26 --> Controller Class Initialized
INFO - 2016-06-15 14:58:26 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:58:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:58:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:58:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:58:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:58:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:58:26 --> Model Class Initialized
INFO - 2016-06-15 14:58:26 --> Final output sent to browser
DEBUG - 2016-06-15 14:58:26 --> Total execution time: 0.0199
INFO - 2016-06-15 15:05:59 --> Config Class Initialized
INFO - 2016-06-15 15:05:59 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:05:59 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:05:59 --> Utf8 Class Initialized
INFO - 2016-06-15 15:05:59 --> URI Class Initialized
DEBUG - 2016-06-15 15:05:59 --> No URI present. Default controller set.
INFO - 2016-06-15 15:05:59 --> Router Class Initialized
INFO - 2016-06-15 15:05:59 --> Output Class Initialized
INFO - 2016-06-15 15:05:59 --> Security Class Initialized
DEBUG - 2016-06-15 15:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:05:59 --> Input Class Initialized
INFO - 2016-06-15 15:05:59 --> Language Class Initialized
INFO - 2016-06-15 15:05:59 --> Loader Class Initialized
INFO - 2016-06-15 15:05:59 --> Helper loaded: form_helper
INFO - 2016-06-15 15:05:59 --> Database Driver Class Initialized
INFO - 2016-06-15 15:05:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:05:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:05:59 --> Email Class Initialized
INFO - 2016-06-15 15:05:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:05:59 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:05:59 --> Helper loaded: language_helper
INFO - 2016-06-15 15:05:59 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:05:59 --> Model Class Initialized
INFO - 2016-06-15 15:05:59 --> Helper loaded: date_helper
INFO - 2016-06-15 15:05:59 --> Controller Class Initialized
INFO - 2016-06-15 15:05:59 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:05:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:05:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:05:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:05:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:05:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:05:59 --> Model Class Initialized
INFO - 2016-06-15 15:05:59 --> Form Validation Class Initialized
INFO - 2016-06-15 15:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:05:59 --> Final output sent to browser
DEBUG - 2016-06-15 15:05:59 --> Total execution time: 0.0139
INFO - 2016-06-15 15:06:01 --> Config Class Initialized
INFO - 2016-06-15 15:06:01 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:06:01 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:06:01 --> Utf8 Class Initialized
INFO - 2016-06-15 15:06:01 --> URI Class Initialized
INFO - 2016-06-15 15:06:01 --> Router Class Initialized
INFO - 2016-06-15 15:06:01 --> Output Class Initialized
INFO - 2016-06-15 15:06:01 --> Security Class Initialized
DEBUG - 2016-06-15 15:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:06:01 --> Input Class Initialized
INFO - 2016-06-15 15:06:01 --> Language Class Initialized
INFO - 2016-06-15 15:06:01 --> Loader Class Initialized
INFO - 2016-06-15 15:06:01 --> Helper loaded: form_helper
INFO - 2016-06-15 15:06:01 --> Database Driver Class Initialized
INFO - 2016-06-15 15:06:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:06:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:06:01 --> Email Class Initialized
INFO - 2016-06-15 15:06:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:06:01 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:06:01 --> Helper loaded: language_helper
INFO - 2016-06-15 15:06:01 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:06:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:06:01 --> Model Class Initialized
INFO - 2016-06-15 15:06:01 --> Helper loaded: date_helper
INFO - 2016-06-15 15:06:01 --> Controller Class Initialized
INFO - 2016-06-15 15:06:01 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:06:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:06:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:06:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:06:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:06:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:06:01 --> Model Class Initialized
INFO - 2016-06-15 15:06:01 --> Final output sent to browser
DEBUG - 2016-06-15 15:06:01 --> Total execution time: 0.0110
INFO - 2016-06-15 15:09:18 --> Config Class Initialized
INFO - 2016-06-15 15:09:18 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:09:18 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:09:18 --> Utf8 Class Initialized
INFO - 2016-06-15 15:09:18 --> URI Class Initialized
DEBUG - 2016-06-15 15:09:18 --> No URI present. Default controller set.
INFO - 2016-06-15 15:09:18 --> Router Class Initialized
INFO - 2016-06-15 15:09:18 --> Output Class Initialized
INFO - 2016-06-15 15:09:18 --> Security Class Initialized
DEBUG - 2016-06-15 15:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:09:18 --> Input Class Initialized
INFO - 2016-06-15 15:09:18 --> Language Class Initialized
INFO - 2016-06-15 15:09:18 --> Loader Class Initialized
INFO - 2016-06-15 15:09:18 --> Helper loaded: form_helper
INFO - 2016-06-15 15:09:18 --> Database Driver Class Initialized
INFO - 2016-06-15 15:09:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:09:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:09:18 --> Email Class Initialized
INFO - 2016-06-15 15:09:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:09:18 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:09:18 --> Helper loaded: language_helper
INFO - 2016-06-15 15:09:18 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:09:18 --> Model Class Initialized
INFO - 2016-06-15 15:09:18 --> Helper loaded: date_helper
INFO - 2016-06-15 15:09:18 --> Controller Class Initialized
INFO - 2016-06-15 15:09:18 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:09:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:09:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:09:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:09:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:09:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:09:18 --> Model Class Initialized
INFO - 2016-06-15 15:09:18 --> Form Validation Class Initialized
INFO - 2016-06-15 15:09:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:09:18 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:09:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:09:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:09:18 --> Final output sent to browser
DEBUG - 2016-06-15 15:09:18 --> Total execution time: 0.0248
INFO - 2016-06-15 15:09:20 --> Config Class Initialized
INFO - 2016-06-15 15:09:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:09:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:09:20 --> Utf8 Class Initialized
INFO - 2016-06-15 15:09:20 --> URI Class Initialized
INFO - 2016-06-15 15:09:20 --> Router Class Initialized
INFO - 2016-06-15 15:09:20 --> Output Class Initialized
INFO - 2016-06-15 15:09:20 --> Security Class Initialized
DEBUG - 2016-06-15 15:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:09:20 --> Input Class Initialized
INFO - 2016-06-15 15:09:20 --> Language Class Initialized
INFO - 2016-06-15 15:09:20 --> Loader Class Initialized
INFO - 2016-06-15 15:09:20 --> Helper loaded: form_helper
INFO - 2016-06-15 15:09:20 --> Database Driver Class Initialized
INFO - 2016-06-15 15:09:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:09:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:09:20 --> Email Class Initialized
INFO - 2016-06-15 15:09:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:09:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:09:20 --> Helper loaded: language_helper
INFO - 2016-06-15 15:09:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:09:20 --> Model Class Initialized
INFO - 2016-06-15 15:09:20 --> Helper loaded: date_helper
INFO - 2016-06-15 15:09:20 --> Controller Class Initialized
INFO - 2016-06-15 15:09:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:09:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:09:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:09:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:09:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:09:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:09:20 --> Model Class Initialized
INFO - 2016-06-15 15:09:20 --> Final output sent to browser
DEBUG - 2016-06-15 15:09:20 --> Total execution time: 0.0285
INFO - 2016-06-15 15:12:44 --> Config Class Initialized
INFO - 2016-06-15 15:12:44 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:12:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:12:44 --> Utf8 Class Initialized
INFO - 2016-06-15 15:12:44 --> URI Class Initialized
DEBUG - 2016-06-15 15:12:44 --> No URI present. Default controller set.
INFO - 2016-06-15 15:12:44 --> Router Class Initialized
INFO - 2016-06-15 15:12:44 --> Output Class Initialized
INFO - 2016-06-15 15:12:44 --> Security Class Initialized
DEBUG - 2016-06-15 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:12:44 --> Input Class Initialized
INFO - 2016-06-15 15:12:44 --> Language Class Initialized
INFO - 2016-06-15 15:12:44 --> Loader Class Initialized
INFO - 2016-06-15 15:12:44 --> Helper loaded: form_helper
INFO - 2016-06-15 15:12:44 --> Database Driver Class Initialized
INFO - 2016-06-15 15:12:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:12:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:12:44 --> Email Class Initialized
INFO - 2016-06-15 15:12:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:12:44 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:12:44 --> Helper loaded: language_helper
INFO - 2016-06-15 15:12:44 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:12:44 --> Model Class Initialized
INFO - 2016-06-15 15:12:44 --> Helper loaded: date_helper
INFO - 2016-06-15 15:12:44 --> Controller Class Initialized
INFO - 2016-06-15 15:12:44 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:12:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:12:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:12:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:12:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:12:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:12:44 --> Model Class Initialized
INFO - 2016-06-15 15:12:44 --> Form Validation Class Initialized
INFO - 2016-06-15 15:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:12:44 --> Final output sent to browser
DEBUG - 2016-06-15 15:12:44 --> Total execution time: 0.0587
INFO - 2016-06-15 15:12:46 --> Config Class Initialized
INFO - 2016-06-15 15:12:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:12:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:12:46 --> Utf8 Class Initialized
INFO - 2016-06-15 15:12:46 --> URI Class Initialized
INFO - 2016-06-15 15:12:46 --> Router Class Initialized
INFO - 2016-06-15 15:12:46 --> Output Class Initialized
INFO - 2016-06-15 15:12:46 --> Security Class Initialized
DEBUG - 2016-06-15 15:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:12:46 --> Input Class Initialized
INFO - 2016-06-15 15:12:46 --> Language Class Initialized
INFO - 2016-06-15 15:12:46 --> Loader Class Initialized
INFO - 2016-06-15 15:12:46 --> Helper loaded: form_helper
INFO - 2016-06-15 15:12:46 --> Database Driver Class Initialized
INFO - 2016-06-15 15:12:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:12:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:12:46 --> Email Class Initialized
INFO - 2016-06-15 15:12:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:12:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:12:46 --> Helper loaded: language_helper
INFO - 2016-06-15 15:12:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:12:46 --> Model Class Initialized
INFO - 2016-06-15 15:12:46 --> Helper loaded: date_helper
INFO - 2016-06-15 15:12:46 --> Controller Class Initialized
INFO - 2016-06-15 15:12:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:12:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:12:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:12:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:12:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:12:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:12:46 --> Model Class Initialized
INFO - 2016-06-15 15:12:46 --> Final output sent to browser
DEBUG - 2016-06-15 15:12:46 --> Total execution time: 0.0142
INFO - 2016-06-15 15:18:25 --> Config Class Initialized
INFO - 2016-06-15 15:18:25 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:18:25 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:18:25 --> Utf8 Class Initialized
INFO - 2016-06-15 15:18:25 --> URI Class Initialized
DEBUG - 2016-06-15 15:18:25 --> No URI present. Default controller set.
INFO - 2016-06-15 15:18:25 --> Router Class Initialized
INFO - 2016-06-15 15:18:25 --> Output Class Initialized
INFO - 2016-06-15 15:18:25 --> Security Class Initialized
DEBUG - 2016-06-15 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:18:25 --> Input Class Initialized
INFO - 2016-06-15 15:18:25 --> Language Class Initialized
INFO - 2016-06-15 15:18:25 --> Loader Class Initialized
INFO - 2016-06-15 15:18:25 --> Helper loaded: form_helper
INFO - 2016-06-15 15:18:25 --> Database Driver Class Initialized
INFO - 2016-06-15 15:18:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:18:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:18:25 --> Email Class Initialized
INFO - 2016-06-15 15:18:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:18:25 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:18:25 --> Helper loaded: language_helper
INFO - 2016-06-15 15:18:25 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:18:25 --> Model Class Initialized
INFO - 2016-06-15 15:18:25 --> Helper loaded: date_helper
INFO - 2016-06-15 15:18:25 --> Controller Class Initialized
INFO - 2016-06-15 15:18:25 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:18:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:18:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:18:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:18:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:18:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:18:25 --> Model Class Initialized
INFO - 2016-06-15 15:18:25 --> Form Validation Class Initialized
INFO - 2016-06-15 15:18:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:18:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:18:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:18:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:18:25 --> Final output sent to browser
DEBUG - 2016-06-15 15:18:25 --> Total execution time: 0.0498
INFO - 2016-06-15 15:18:27 --> Config Class Initialized
INFO - 2016-06-15 15:18:27 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:18:27 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:18:27 --> Utf8 Class Initialized
INFO - 2016-06-15 15:18:27 --> URI Class Initialized
INFO - 2016-06-15 15:18:27 --> Router Class Initialized
INFO - 2016-06-15 15:18:27 --> Output Class Initialized
INFO - 2016-06-15 15:18:27 --> Security Class Initialized
DEBUG - 2016-06-15 15:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:18:27 --> Input Class Initialized
INFO - 2016-06-15 15:18:27 --> Language Class Initialized
INFO - 2016-06-15 15:18:27 --> Loader Class Initialized
INFO - 2016-06-15 15:18:27 --> Helper loaded: form_helper
INFO - 2016-06-15 15:18:27 --> Database Driver Class Initialized
INFO - 2016-06-15 15:18:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:18:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:18:27 --> Email Class Initialized
INFO - 2016-06-15 15:18:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:18:27 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:18:27 --> Helper loaded: language_helper
INFO - 2016-06-15 15:18:27 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:18:27 --> Model Class Initialized
INFO - 2016-06-15 15:18:27 --> Helper loaded: date_helper
INFO - 2016-06-15 15:18:27 --> Controller Class Initialized
INFO - 2016-06-15 15:18:27 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:18:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:18:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:18:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:18:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:18:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:18:27 --> Model Class Initialized
INFO - 2016-06-15 15:18:27 --> Final output sent to browser
DEBUG - 2016-06-15 15:18:27 --> Total execution time: 0.0127
INFO - 2016-06-15 15:22:22 --> Config Class Initialized
INFO - 2016-06-15 15:22:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:22:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:22:22 --> Utf8 Class Initialized
INFO - 2016-06-15 15:22:22 --> URI Class Initialized
DEBUG - 2016-06-15 15:22:22 --> No URI present. Default controller set.
INFO - 2016-06-15 15:22:22 --> Router Class Initialized
INFO - 2016-06-15 15:22:22 --> Output Class Initialized
INFO - 2016-06-15 15:22:22 --> Security Class Initialized
DEBUG - 2016-06-15 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:22:22 --> Input Class Initialized
INFO - 2016-06-15 15:22:22 --> Language Class Initialized
INFO - 2016-06-15 15:22:22 --> Loader Class Initialized
INFO - 2016-06-15 15:22:22 --> Helper loaded: form_helper
INFO - 2016-06-15 15:22:22 --> Database Driver Class Initialized
INFO - 2016-06-15 15:22:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:22:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:22:22 --> Email Class Initialized
INFO - 2016-06-15 15:22:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:22:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:22:22 --> Helper loaded: language_helper
INFO - 2016-06-15 15:22:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:22:22 --> Model Class Initialized
INFO - 2016-06-15 15:22:22 --> Helper loaded: date_helper
INFO - 2016-06-15 15:22:22 --> Controller Class Initialized
INFO - 2016-06-15 15:22:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:22:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:22:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:22:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:22:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:22:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:22:22 --> Model Class Initialized
INFO - 2016-06-15 15:22:22 --> Form Validation Class Initialized
INFO - 2016-06-15 15:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:22:22 --> Final output sent to browser
DEBUG - 2016-06-15 15:22:22 --> Total execution time: 0.0750
INFO - 2016-06-15 15:22:24 --> Config Class Initialized
INFO - 2016-06-15 15:22:24 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:22:24 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:22:24 --> Utf8 Class Initialized
INFO - 2016-06-15 15:22:24 --> URI Class Initialized
INFO - 2016-06-15 15:22:24 --> Router Class Initialized
INFO - 2016-06-15 15:22:24 --> Output Class Initialized
INFO - 2016-06-15 15:22:24 --> Security Class Initialized
DEBUG - 2016-06-15 15:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:22:24 --> Input Class Initialized
INFO - 2016-06-15 15:22:24 --> Language Class Initialized
INFO - 2016-06-15 15:22:24 --> Loader Class Initialized
INFO - 2016-06-15 15:22:24 --> Helper loaded: form_helper
INFO - 2016-06-15 15:22:24 --> Database Driver Class Initialized
INFO - 2016-06-15 15:22:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:22:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:22:24 --> Email Class Initialized
INFO - 2016-06-15 15:22:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:22:24 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:22:24 --> Helper loaded: language_helper
INFO - 2016-06-15 15:22:24 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:22:24 --> Model Class Initialized
INFO - 2016-06-15 15:22:24 --> Helper loaded: date_helper
INFO - 2016-06-15 15:22:24 --> Controller Class Initialized
INFO - 2016-06-15 15:22:24 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:22:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:22:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:22:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:22:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:22:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:22:24 --> Model Class Initialized
INFO - 2016-06-15 15:22:24 --> Final output sent to browser
DEBUG - 2016-06-15 15:22:24 --> Total execution time: 0.0135
INFO - 2016-06-15 15:23:01 --> Config Class Initialized
INFO - 2016-06-15 15:23:01 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:23:01 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:23:01 --> Utf8 Class Initialized
INFO - 2016-06-15 15:23:01 --> URI Class Initialized
DEBUG - 2016-06-15 15:23:01 --> No URI present. Default controller set.
INFO - 2016-06-15 15:23:01 --> Router Class Initialized
INFO - 2016-06-15 15:23:01 --> Output Class Initialized
INFO - 2016-06-15 15:23:01 --> Security Class Initialized
DEBUG - 2016-06-15 15:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:23:01 --> Input Class Initialized
INFO - 2016-06-15 15:23:01 --> Language Class Initialized
INFO - 2016-06-15 15:23:01 --> Loader Class Initialized
INFO - 2016-06-15 15:23:01 --> Helper loaded: form_helper
INFO - 2016-06-15 15:23:01 --> Database Driver Class Initialized
INFO - 2016-06-15 15:23:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:23:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:23:01 --> Email Class Initialized
INFO - 2016-06-15 15:23:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:23:01 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:23:01 --> Helper loaded: language_helper
INFO - 2016-06-15 15:23:01 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:23:01 --> Model Class Initialized
INFO - 2016-06-15 15:23:01 --> Helper loaded: date_helper
INFO - 2016-06-15 15:23:01 --> Controller Class Initialized
INFO - 2016-06-15 15:23:01 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:23:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:23:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:23:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:23:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:23:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:23:01 --> Model Class Initialized
INFO - 2016-06-15 15:23:01 --> Form Validation Class Initialized
INFO - 2016-06-15 15:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:23:01 --> Final output sent to browser
DEBUG - 2016-06-15 15:23:01 --> Total execution time: 0.0280
INFO - 2016-06-15 15:23:04 --> Config Class Initialized
INFO - 2016-06-15 15:23:04 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:23:04 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:23:04 --> Utf8 Class Initialized
INFO - 2016-06-15 15:23:04 --> URI Class Initialized
INFO - 2016-06-15 15:23:04 --> Router Class Initialized
INFO - 2016-06-15 15:23:04 --> Output Class Initialized
INFO - 2016-06-15 15:23:04 --> Security Class Initialized
DEBUG - 2016-06-15 15:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:23:04 --> Input Class Initialized
INFO - 2016-06-15 15:23:04 --> Language Class Initialized
INFO - 2016-06-15 15:23:04 --> Loader Class Initialized
INFO - 2016-06-15 15:23:04 --> Helper loaded: form_helper
INFO - 2016-06-15 15:23:04 --> Database Driver Class Initialized
INFO - 2016-06-15 15:23:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:23:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:23:04 --> Email Class Initialized
INFO - 2016-06-15 15:23:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:23:04 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:23:04 --> Helper loaded: language_helper
INFO - 2016-06-15 15:23:04 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:23:04 --> Model Class Initialized
INFO - 2016-06-15 15:23:04 --> Helper loaded: date_helper
INFO - 2016-06-15 15:23:04 --> Controller Class Initialized
INFO - 2016-06-15 15:23:04 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:23:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:23:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:23:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:23:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:23:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:23:04 --> Model Class Initialized
INFO - 2016-06-15 15:23:04 --> Final output sent to browser
DEBUG - 2016-06-15 15:23:04 --> Total execution time: 0.0219
INFO - 2016-06-15 15:23:15 --> Config Class Initialized
INFO - 2016-06-15 15:23:15 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:23:15 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:23:15 --> Utf8 Class Initialized
INFO - 2016-06-15 15:23:15 --> URI Class Initialized
DEBUG - 2016-06-15 15:23:15 --> No URI present. Default controller set.
INFO - 2016-06-15 15:23:15 --> Router Class Initialized
INFO - 2016-06-15 15:23:15 --> Output Class Initialized
INFO - 2016-06-15 15:23:15 --> Security Class Initialized
DEBUG - 2016-06-15 15:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:23:15 --> Input Class Initialized
INFO - 2016-06-15 15:23:15 --> Language Class Initialized
INFO - 2016-06-15 15:23:15 --> Loader Class Initialized
INFO - 2016-06-15 15:23:15 --> Helper loaded: form_helper
INFO - 2016-06-15 15:23:15 --> Database Driver Class Initialized
INFO - 2016-06-15 15:23:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:23:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:23:15 --> Email Class Initialized
INFO - 2016-06-15 15:23:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:23:15 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:23:15 --> Helper loaded: language_helper
INFO - 2016-06-15 15:23:15 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:23:15 --> Model Class Initialized
INFO - 2016-06-15 15:23:15 --> Helper loaded: date_helper
INFO - 2016-06-15 15:23:15 --> Controller Class Initialized
INFO - 2016-06-15 15:23:15 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:23:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:23:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:23:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:23:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:23:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:23:15 --> Model Class Initialized
INFO - 2016-06-15 15:23:15 --> Form Validation Class Initialized
INFO - 2016-06-15 15:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:23:15 --> Final output sent to browser
DEBUG - 2016-06-15 15:23:15 --> Total execution time: 0.0468
INFO - 2016-06-15 15:23:18 --> Config Class Initialized
INFO - 2016-06-15 15:23:18 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:23:18 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:23:18 --> Utf8 Class Initialized
INFO - 2016-06-15 15:23:18 --> URI Class Initialized
INFO - 2016-06-15 15:23:18 --> Router Class Initialized
INFO - 2016-06-15 15:23:18 --> Output Class Initialized
INFO - 2016-06-15 15:23:18 --> Security Class Initialized
DEBUG - 2016-06-15 15:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:23:18 --> Input Class Initialized
INFO - 2016-06-15 15:23:18 --> Language Class Initialized
INFO - 2016-06-15 15:23:18 --> Loader Class Initialized
INFO - 2016-06-15 15:23:18 --> Helper loaded: form_helper
INFO - 2016-06-15 15:23:18 --> Database Driver Class Initialized
INFO - 2016-06-15 15:23:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:23:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:23:18 --> Email Class Initialized
INFO - 2016-06-15 15:23:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:23:18 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:23:18 --> Helper loaded: language_helper
INFO - 2016-06-15 15:23:18 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:23:18 --> Model Class Initialized
INFO - 2016-06-15 15:23:18 --> Helper loaded: date_helper
INFO - 2016-06-15 15:23:18 --> Controller Class Initialized
INFO - 2016-06-15 15:23:18 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:23:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:23:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:23:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:23:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:23:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:23:18 --> Model Class Initialized
INFO - 2016-06-15 15:23:18 --> Final output sent to browser
DEBUG - 2016-06-15 15:23:18 --> Total execution time: 0.0509
INFO - 2016-06-15 15:25:20 --> Config Class Initialized
INFO - 2016-06-15 15:25:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:25:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:25:20 --> Utf8 Class Initialized
INFO - 2016-06-15 15:25:20 --> URI Class Initialized
DEBUG - 2016-06-15 15:25:20 --> No URI present. Default controller set.
INFO - 2016-06-15 15:25:20 --> Router Class Initialized
INFO - 2016-06-15 15:25:20 --> Output Class Initialized
INFO - 2016-06-15 15:25:20 --> Security Class Initialized
DEBUG - 2016-06-15 15:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:25:20 --> Input Class Initialized
INFO - 2016-06-15 15:25:20 --> Language Class Initialized
INFO - 2016-06-15 15:25:20 --> Loader Class Initialized
INFO - 2016-06-15 15:25:20 --> Helper loaded: form_helper
INFO - 2016-06-15 15:25:20 --> Database Driver Class Initialized
INFO - 2016-06-15 15:25:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:25:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:25:20 --> Email Class Initialized
INFO - 2016-06-15 15:25:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:25:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:25:20 --> Helper loaded: language_helper
INFO - 2016-06-15 15:25:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:25:20 --> Model Class Initialized
INFO - 2016-06-15 15:25:20 --> Helper loaded: date_helper
INFO - 2016-06-15 15:25:20 --> Controller Class Initialized
INFO - 2016-06-15 15:25:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:25:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:25:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:25:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:25:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:25:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:25:20 --> Model Class Initialized
INFO - 2016-06-15 15:25:20 --> Form Validation Class Initialized
INFO - 2016-06-15 15:25:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:25:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:25:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:25:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:25:20 --> Final output sent to browser
DEBUG - 2016-06-15 15:25:20 --> Total execution time: 0.0320
INFO - 2016-06-15 15:25:21 --> Config Class Initialized
INFO - 2016-06-15 15:25:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:25:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:25:21 --> Utf8 Class Initialized
INFO - 2016-06-15 15:25:21 --> URI Class Initialized
INFO - 2016-06-15 15:25:21 --> Router Class Initialized
INFO - 2016-06-15 15:25:21 --> Output Class Initialized
INFO - 2016-06-15 15:25:21 --> Security Class Initialized
DEBUG - 2016-06-15 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:25:21 --> Input Class Initialized
INFO - 2016-06-15 15:25:21 --> Language Class Initialized
INFO - 2016-06-15 15:25:21 --> Loader Class Initialized
INFO - 2016-06-15 15:25:21 --> Helper loaded: form_helper
INFO - 2016-06-15 15:25:21 --> Database Driver Class Initialized
INFO - 2016-06-15 15:25:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:25:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:25:21 --> Email Class Initialized
INFO - 2016-06-15 15:25:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:25:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:25:21 --> Helper loaded: language_helper
INFO - 2016-06-15 15:25:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:25:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:25:21 --> Model Class Initialized
INFO - 2016-06-15 15:25:21 --> Helper loaded: date_helper
INFO - 2016-06-15 15:25:21 --> Controller Class Initialized
INFO - 2016-06-15 15:25:21 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:25:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:25:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:25:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:25:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:25:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:25:21 --> Model Class Initialized
INFO - 2016-06-15 15:25:21 --> Final output sent to browser
DEBUG - 2016-06-15 15:25:21 --> Total execution time: 0.0128
INFO - 2016-06-15 15:26:18 --> Config Class Initialized
INFO - 2016-06-15 15:26:18 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:26:18 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:26:18 --> Utf8 Class Initialized
INFO - 2016-06-15 15:26:18 --> URI Class Initialized
DEBUG - 2016-06-15 15:26:18 --> No URI present. Default controller set.
INFO - 2016-06-15 15:26:18 --> Router Class Initialized
INFO - 2016-06-15 15:26:18 --> Output Class Initialized
INFO - 2016-06-15 15:26:18 --> Security Class Initialized
DEBUG - 2016-06-15 15:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:26:18 --> Input Class Initialized
INFO - 2016-06-15 15:26:18 --> Language Class Initialized
INFO - 2016-06-15 15:26:18 --> Loader Class Initialized
INFO - 2016-06-15 15:26:18 --> Helper loaded: form_helper
INFO - 2016-06-15 15:26:18 --> Database Driver Class Initialized
INFO - 2016-06-15 15:26:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:26:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:26:18 --> Email Class Initialized
INFO - 2016-06-15 15:26:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:26:18 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:26:18 --> Helper loaded: language_helper
INFO - 2016-06-15 15:26:18 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:26:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:26:18 --> Model Class Initialized
INFO - 2016-06-15 15:26:18 --> Helper loaded: date_helper
INFO - 2016-06-15 15:26:18 --> Controller Class Initialized
INFO - 2016-06-15 15:26:18 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:26:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:26:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:26:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:26:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:26:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:26:18 --> Model Class Initialized
INFO - 2016-06-15 15:26:18 --> Form Validation Class Initialized
INFO - 2016-06-15 15:26:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:26:18 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:26:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:26:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:26:18 --> Final output sent to browser
DEBUG - 2016-06-15 15:26:18 --> Total execution time: 0.0186
INFO - 2016-06-15 15:26:20 --> Config Class Initialized
INFO - 2016-06-15 15:26:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:26:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:26:20 --> Utf8 Class Initialized
INFO - 2016-06-15 15:26:20 --> URI Class Initialized
INFO - 2016-06-15 15:26:20 --> Router Class Initialized
INFO - 2016-06-15 15:26:20 --> Output Class Initialized
INFO - 2016-06-15 15:26:20 --> Security Class Initialized
DEBUG - 2016-06-15 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:26:20 --> Input Class Initialized
INFO - 2016-06-15 15:26:20 --> Language Class Initialized
INFO - 2016-06-15 15:26:20 --> Loader Class Initialized
INFO - 2016-06-15 15:26:20 --> Helper loaded: form_helper
INFO - 2016-06-15 15:26:20 --> Database Driver Class Initialized
INFO - 2016-06-15 15:26:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:26:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:26:20 --> Email Class Initialized
INFO - 2016-06-15 15:26:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:26:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:26:20 --> Helper loaded: language_helper
INFO - 2016-06-15 15:26:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:26:20 --> Model Class Initialized
INFO - 2016-06-15 15:26:20 --> Helper loaded: date_helper
INFO - 2016-06-15 15:26:20 --> Controller Class Initialized
INFO - 2016-06-15 15:26:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:26:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:26:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:26:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:26:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:26:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:26:20 --> Model Class Initialized
INFO - 2016-06-15 15:26:20 --> Final output sent to browser
DEBUG - 2016-06-15 15:26:20 --> Total execution time: 0.0191
INFO - 2016-06-15 15:28:14 --> Config Class Initialized
INFO - 2016-06-15 15:28:14 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:14 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:14 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:14 --> URI Class Initialized
DEBUG - 2016-06-15 15:28:14 --> No URI present. Default controller set.
INFO - 2016-06-15 15:28:14 --> Router Class Initialized
INFO - 2016-06-15 15:28:14 --> Output Class Initialized
INFO - 2016-06-15 15:28:14 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:14 --> Input Class Initialized
INFO - 2016-06-15 15:28:14 --> Language Class Initialized
INFO - 2016-06-15 15:28:14 --> Loader Class Initialized
INFO - 2016-06-15 15:28:14 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:14 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:28:14 --> Email Class Initialized
INFO - 2016-06-15 15:28:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:14 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:14 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:14 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:14 --> Model Class Initialized
INFO - 2016-06-15 15:28:14 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:14 --> Controller Class Initialized
INFO - 2016-06-15 15:28:14 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:28:14 --> Model Class Initialized
INFO - 2016-06-15 15:28:14 --> Form Validation Class Initialized
INFO - 2016-06-15 15:28:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:28:14 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:28:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:28:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:28:14 --> Final output sent to browser
DEBUG - 2016-06-15 15:28:14 --> Total execution time: 0.0694
INFO - 2016-06-15 15:28:15 --> Config Class Initialized
INFO - 2016-06-15 15:28:15 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:15 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:15 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:15 --> URI Class Initialized
INFO - 2016-06-15 15:28:15 --> Router Class Initialized
INFO - 2016-06-15 15:28:15 --> Output Class Initialized
INFO - 2016-06-15 15:28:15 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:15 --> Input Class Initialized
INFO - 2016-06-15 15:28:15 --> Language Class Initialized
INFO - 2016-06-15 15:28:15 --> Loader Class Initialized
INFO - 2016-06-15 15:28:15 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:15 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:28:15 --> Email Class Initialized
INFO - 2016-06-15 15:28:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:15 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:15 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:15 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:15 --> Model Class Initialized
INFO - 2016-06-15 15:28:15 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:15 --> Controller Class Initialized
INFO - 2016-06-15 15:28:15 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:28:15 --> Model Class Initialized
INFO - 2016-06-15 15:28:15 --> Final output sent to browser
DEBUG - 2016-06-15 15:28:15 --> Total execution time: 0.0124
INFO - 2016-06-15 15:30:05 --> Config Class Initialized
INFO - 2016-06-15 15:30:05 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:30:05 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:30:05 --> Utf8 Class Initialized
INFO - 2016-06-15 15:30:05 --> URI Class Initialized
INFO - 2016-06-15 15:30:05 --> Router Class Initialized
INFO - 2016-06-15 15:30:05 --> Output Class Initialized
INFO - 2016-06-15 15:30:05 --> Security Class Initialized
DEBUG - 2016-06-15 15:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:30:05 --> Input Class Initialized
INFO - 2016-06-15 15:30:05 --> Language Class Initialized
INFO - 2016-06-15 15:30:05 --> Loader Class Initialized
INFO - 2016-06-15 15:30:05 --> Helper loaded: form_helper
INFO - 2016-06-15 15:30:05 --> Database Driver Class Initialized
INFO - 2016-06-15 15:30:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:30:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:30:05 --> Email Class Initialized
INFO - 2016-06-15 15:30:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:30:05 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:30:05 --> Helper loaded: language_helper
INFO - 2016-06-15 15:30:05 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:05 --> Model Class Initialized
INFO - 2016-06-15 15:30:05 --> Helper loaded: date_helper
INFO - 2016-06-15 15:30:05 --> Controller Class Initialized
INFO - 2016-06-15 15:30:05 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:30:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:30:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:30:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:30:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:30:05 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 15:30:05 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:05 --> Form Validation Class Initialized
DEBUG - 2016-06-15 15:30:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:30:05 --> Final output sent to browser
DEBUG - 2016-06-15 15:30:05 --> Total execution time: 0.0123
INFO - 2016-06-15 15:30:07 --> Config Class Initialized
INFO - 2016-06-15 15:30:07 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:30:07 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:30:07 --> Utf8 Class Initialized
INFO - 2016-06-15 15:30:07 --> URI Class Initialized
INFO - 2016-06-15 15:30:07 --> Router Class Initialized
INFO - 2016-06-15 15:30:07 --> Output Class Initialized
INFO - 2016-06-15 15:30:07 --> Security Class Initialized
DEBUG - 2016-06-15 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:30:07 --> Input Class Initialized
INFO - 2016-06-15 15:30:07 --> Language Class Initialized
INFO - 2016-06-15 15:30:07 --> Loader Class Initialized
INFO - 2016-06-15 15:30:07 --> Helper loaded: form_helper
INFO - 2016-06-15 15:30:07 --> Database Driver Class Initialized
INFO - 2016-06-15 15:30:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:30:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:30:07 --> Email Class Initialized
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:30:07 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:30:07 --> Helper loaded: language_helper
INFO - 2016-06-15 15:30:07 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:30:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:07 --> Model Class Initialized
INFO - 2016-06-15 15:30:07 --> Helper loaded: date_helper
INFO - 2016-06-15 15:30:07 --> Controller Class Initialized
INFO - 2016-06-15 15:30:07 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:30:07 --> Model Class Initialized
INFO - 2016-06-15 15:30:07 --> Final output sent to browser
DEBUG - 2016-06-15 15:30:07 --> Total execution time: 0.0176
INFO - 2016-06-15 15:30:07 --> Config Class Initialized
INFO - 2016-06-15 15:30:07 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:30:07 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:30:07 --> Utf8 Class Initialized
INFO - 2016-06-15 15:30:07 --> URI Class Initialized
INFO - 2016-06-15 15:30:07 --> Router Class Initialized
INFO - 2016-06-15 15:30:07 --> Output Class Initialized
INFO - 2016-06-15 15:30:07 --> Security Class Initialized
DEBUG - 2016-06-15 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:30:07 --> Input Class Initialized
INFO - 2016-06-15 15:30:07 --> Language Class Initialized
INFO - 2016-06-15 15:30:07 --> Loader Class Initialized
INFO - 2016-06-15 15:30:07 --> Helper loaded: form_helper
INFO - 2016-06-15 15:30:07 --> Database Driver Class Initialized
INFO - 2016-06-15 15:30:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:30:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:30:07 --> Email Class Initialized
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:30:07 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:30:07 --> Helper loaded: language_helper
INFO - 2016-06-15 15:30:07 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:30:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:07 --> Model Class Initialized
INFO - 2016-06-15 15:30:07 --> Helper loaded: date_helper
INFO - 2016-06-15 15:30:07 --> Controller Class Initialized
INFO - 2016-06-15 15:30:07 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:30:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 15:30:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:07 --> Form Validation Class Initialized
DEBUG - 2016-06-15 15:30:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:30:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:30:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:30:07 --> Final output sent to browser
DEBUG - 2016-06-15 15:30:07 --> Total execution time: 0.0154
INFO - 2016-06-15 15:30:45 --> Config Class Initialized
INFO - 2016-06-15 15:30:45 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:30:45 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:30:45 --> Utf8 Class Initialized
INFO - 2016-06-15 15:30:45 --> URI Class Initialized
DEBUG - 2016-06-15 15:30:45 --> No URI present. Default controller set.
INFO - 2016-06-15 15:30:45 --> Router Class Initialized
INFO - 2016-06-15 15:30:45 --> Output Class Initialized
INFO - 2016-06-15 15:30:45 --> Security Class Initialized
DEBUG - 2016-06-15 15:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:30:45 --> Input Class Initialized
INFO - 2016-06-15 15:30:45 --> Language Class Initialized
INFO - 2016-06-15 15:30:45 --> Loader Class Initialized
INFO - 2016-06-15 15:30:45 --> Helper loaded: form_helper
INFO - 2016-06-15 15:30:45 --> Database Driver Class Initialized
INFO - 2016-06-15 15:30:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:30:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:30:45 --> Email Class Initialized
INFO - 2016-06-15 15:30:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:30:45 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:30:45 --> Helper loaded: language_helper
INFO - 2016-06-15 15:30:45 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:45 --> Model Class Initialized
INFO - 2016-06-15 15:30:45 --> Helper loaded: date_helper
INFO - 2016-06-15 15:30:45 --> Controller Class Initialized
INFO - 2016-06-15 15:30:45 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:30:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:30:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:30:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:30:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:30:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:30:45 --> Model Class Initialized
INFO - 2016-06-15 15:30:45 --> Form Validation Class Initialized
INFO - 2016-06-15 15:30:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:30:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:30:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:30:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:30:45 --> Final output sent to browser
DEBUG - 2016-06-15 15:30:45 --> Total execution time: 0.0150
INFO - 2016-06-15 15:30:47 --> Config Class Initialized
INFO - 2016-06-15 15:30:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:30:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:30:47 --> Utf8 Class Initialized
INFO - 2016-06-15 15:30:47 --> URI Class Initialized
INFO - 2016-06-15 15:30:47 --> Router Class Initialized
INFO - 2016-06-15 15:30:47 --> Output Class Initialized
INFO - 2016-06-15 15:30:47 --> Security Class Initialized
DEBUG - 2016-06-15 15:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:30:47 --> Input Class Initialized
INFO - 2016-06-15 15:30:47 --> Language Class Initialized
INFO - 2016-06-15 15:30:47 --> Loader Class Initialized
INFO - 2016-06-15 15:30:47 --> Helper loaded: form_helper
INFO - 2016-06-15 15:30:47 --> Database Driver Class Initialized
INFO - 2016-06-15 15:30:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:30:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:30:47 --> Email Class Initialized
INFO - 2016-06-15 15:30:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:30:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:30:47 --> Helper loaded: language_helper
INFO - 2016-06-15 15:30:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:30:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:30:47 --> Model Class Initialized
INFO - 2016-06-15 15:30:47 --> Helper loaded: date_helper
INFO - 2016-06-15 15:30:47 --> Controller Class Initialized
INFO - 2016-06-15 15:30:47 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:30:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:30:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:30:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:30:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:30:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:30:47 --> Model Class Initialized
INFO - 2016-06-15 15:30:47 --> Final output sent to browser
DEBUG - 2016-06-15 15:30:47 --> Total execution time: 0.0168
INFO - 2016-06-15 15:31:42 --> Config Class Initialized
INFO - 2016-06-15 15:31:42 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:31:42 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:31:42 --> Utf8 Class Initialized
INFO - 2016-06-15 15:31:42 --> URI Class Initialized
DEBUG - 2016-06-15 15:31:42 --> No URI present. Default controller set.
INFO - 2016-06-15 15:31:42 --> Router Class Initialized
INFO - 2016-06-15 15:31:42 --> Output Class Initialized
INFO - 2016-06-15 15:31:42 --> Security Class Initialized
DEBUG - 2016-06-15 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:31:42 --> Input Class Initialized
INFO - 2016-06-15 15:31:42 --> Language Class Initialized
INFO - 2016-06-15 15:31:42 --> Loader Class Initialized
INFO - 2016-06-15 15:31:42 --> Helper loaded: form_helper
INFO - 2016-06-15 15:31:42 --> Database Driver Class Initialized
INFO - 2016-06-15 15:31:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:31:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:31:42 --> Email Class Initialized
INFO - 2016-06-15 15:31:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:31:42 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:31:42 --> Helper loaded: language_helper
INFO - 2016-06-15 15:31:42 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:31:42 --> Model Class Initialized
INFO - 2016-06-15 15:31:42 --> Helper loaded: date_helper
INFO - 2016-06-15 15:31:42 --> Controller Class Initialized
INFO - 2016-06-15 15:31:42 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:31:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:31:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:31:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:31:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:31:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:31:42 --> Model Class Initialized
INFO - 2016-06-15 15:31:42 --> Form Validation Class Initialized
INFO - 2016-06-15 15:31:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:31:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:31:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:31:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:31:42 --> Final output sent to browser
DEBUG - 2016-06-15 15:31:42 --> Total execution time: 0.0197
INFO - 2016-06-15 15:31:50 --> Config Class Initialized
INFO - 2016-06-15 15:31:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:31:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:31:50 --> Utf8 Class Initialized
INFO - 2016-06-15 15:31:50 --> URI Class Initialized
INFO - 2016-06-15 15:31:50 --> Router Class Initialized
INFO - 2016-06-15 15:31:50 --> Output Class Initialized
INFO - 2016-06-15 15:31:50 --> Security Class Initialized
DEBUG - 2016-06-15 15:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:31:50 --> Input Class Initialized
INFO - 2016-06-15 15:31:50 --> Language Class Initialized
INFO - 2016-06-15 15:31:50 --> Loader Class Initialized
INFO - 2016-06-15 15:31:50 --> Helper loaded: form_helper
INFO - 2016-06-15 15:31:50 --> Database Driver Class Initialized
INFO - 2016-06-15 15:31:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:31:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:31:50 --> Email Class Initialized
INFO - 2016-06-15 15:31:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:31:50 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:31:50 --> Helper loaded: language_helper
INFO - 2016-06-15 15:31:50 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:31:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:31:50 --> Model Class Initialized
INFO - 2016-06-15 15:31:50 --> Helper loaded: date_helper
INFO - 2016-06-15 15:31:50 --> Controller Class Initialized
INFO - 2016-06-15 15:31:50 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:31:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:31:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:31:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:31:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:31:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:31:50 --> Model Class Initialized
INFO - 2016-06-15 15:31:50 --> Final output sent to browser
DEBUG - 2016-06-15 15:31:50 --> Total execution time: 0.0422
INFO - 2016-06-15 15:32:18 --> Config Class Initialized
INFO - 2016-06-15 15:32:18 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:18 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:18 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:18 --> URI Class Initialized
DEBUG - 2016-06-15 15:32:18 --> No URI present. Default controller set.
INFO - 2016-06-15 15:32:18 --> Router Class Initialized
INFO - 2016-06-15 15:32:18 --> Output Class Initialized
INFO - 2016-06-15 15:32:18 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:18 --> Input Class Initialized
INFO - 2016-06-15 15:32:18 --> Language Class Initialized
INFO - 2016-06-15 15:32:18 --> Loader Class Initialized
INFO - 2016-06-15 15:32:18 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:18 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:18 --> Email Class Initialized
INFO - 2016-06-15 15:32:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:18 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:18 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:18 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:18 --> Model Class Initialized
INFO - 2016-06-15 15:32:18 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:18 --> Controller Class Initialized
INFO - 2016-06-15 15:32:18 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:18 --> Model Class Initialized
INFO - 2016-06-15 15:32:18 --> Form Validation Class Initialized
INFO - 2016-06-15 15:32:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:32:18 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:32:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:32:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:32:18 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:18 --> Total execution time: 0.0180
INFO - 2016-06-15 15:32:21 --> Config Class Initialized
INFO - 2016-06-15 15:32:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:21 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:21 --> URI Class Initialized
INFO - 2016-06-15 15:32:21 --> Router Class Initialized
INFO - 2016-06-15 15:32:21 --> Output Class Initialized
INFO - 2016-06-15 15:32:21 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:21 --> Input Class Initialized
INFO - 2016-06-15 15:32:21 --> Language Class Initialized
INFO - 2016-06-15 15:32:21 --> Loader Class Initialized
INFO - 2016-06-15 15:32:21 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:21 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:21 --> Email Class Initialized
INFO - 2016-06-15 15:32:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:21 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:21 --> Model Class Initialized
INFO - 2016-06-15 15:32:21 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:21 --> Controller Class Initialized
INFO - 2016-06-15 15:32:21 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:21 --> Model Class Initialized
INFO - 2016-06-15 15:32:21 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:21 --> Total execution time: 0.0174
INFO - 2016-06-15 15:32:34 --> Config Class Initialized
INFO - 2016-06-15 15:32:34 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:34 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:34 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:34 --> URI Class Initialized
DEBUG - 2016-06-15 15:32:34 --> No URI present. Default controller set.
INFO - 2016-06-15 15:32:34 --> Router Class Initialized
INFO - 2016-06-15 15:32:34 --> Output Class Initialized
INFO - 2016-06-15 15:32:34 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:34 --> Input Class Initialized
INFO - 2016-06-15 15:32:34 --> Language Class Initialized
INFO - 2016-06-15 15:32:34 --> Loader Class Initialized
INFO - 2016-06-15 15:32:34 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:34 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:34 --> Email Class Initialized
INFO - 2016-06-15 15:32:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:34 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:34 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:34 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:34 --> Model Class Initialized
INFO - 2016-06-15 15:32:34 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:34 --> Controller Class Initialized
INFO - 2016-06-15 15:32:34 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:34 --> Model Class Initialized
INFO - 2016-06-15 15:32:34 --> Form Validation Class Initialized
INFO - 2016-06-15 15:32:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:32:34 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:32:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:32:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:32:34 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:34 --> Total execution time: 0.0159
INFO - 2016-06-15 15:32:37 --> Config Class Initialized
INFO - 2016-06-15 15:32:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:37 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:37 --> URI Class Initialized
INFO - 2016-06-15 15:32:37 --> Router Class Initialized
INFO - 2016-06-15 15:32:37 --> Output Class Initialized
INFO - 2016-06-15 15:32:37 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:37 --> Input Class Initialized
INFO - 2016-06-15 15:32:37 --> Language Class Initialized
INFO - 2016-06-15 15:32:37 --> Loader Class Initialized
INFO - 2016-06-15 15:32:37 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:37 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:37 --> Email Class Initialized
INFO - 2016-06-15 15:32:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:37 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:37 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:37 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:37 --> Model Class Initialized
INFO - 2016-06-15 15:32:37 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:37 --> Controller Class Initialized
INFO - 2016-06-15 15:32:37 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:37 --> Model Class Initialized
INFO - 2016-06-15 15:32:37 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:37 --> Total execution time: 0.0322
INFO - 2016-06-15 15:32:42 --> Config Class Initialized
INFO - 2016-06-15 15:32:42 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:42 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:42 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:42 --> URI Class Initialized
DEBUG - 2016-06-15 15:32:42 --> No URI present. Default controller set.
INFO - 2016-06-15 15:32:42 --> Router Class Initialized
INFO - 2016-06-15 15:32:42 --> Output Class Initialized
INFO - 2016-06-15 15:32:42 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:42 --> Input Class Initialized
INFO - 2016-06-15 15:32:42 --> Language Class Initialized
INFO - 2016-06-15 15:32:42 --> Loader Class Initialized
INFO - 2016-06-15 15:32:42 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:42 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:42 --> Email Class Initialized
INFO - 2016-06-15 15:32:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:42 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:42 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:42 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:42 --> Model Class Initialized
INFO - 2016-06-15 15:32:42 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:42 --> Controller Class Initialized
INFO - 2016-06-15 15:32:42 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:42 --> Model Class Initialized
INFO - 2016-06-15 15:32:42 --> Form Validation Class Initialized
INFO - 2016-06-15 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:32:42 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:42 --> Total execution time: 0.1027
INFO - 2016-06-15 15:32:46 --> Config Class Initialized
INFO - 2016-06-15 15:32:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:46 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:46 --> URI Class Initialized
INFO - 2016-06-15 15:32:46 --> Router Class Initialized
INFO - 2016-06-15 15:32:46 --> Output Class Initialized
INFO - 2016-06-15 15:32:46 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:46 --> Input Class Initialized
INFO - 2016-06-15 15:32:46 --> Language Class Initialized
INFO - 2016-06-15 15:32:46 --> Loader Class Initialized
INFO - 2016-06-15 15:32:46 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:46 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:46 --> Email Class Initialized
INFO - 2016-06-15 15:32:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:46 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:46 --> Model Class Initialized
INFO - 2016-06-15 15:32:46 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:46 --> Controller Class Initialized
INFO - 2016-06-15 15:32:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:46 --> Model Class Initialized
INFO - 2016-06-15 15:32:46 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:46 --> Total execution time: 0.0400
INFO - 2016-06-15 15:32:54 --> Config Class Initialized
INFO - 2016-06-15 15:32:54 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:54 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:54 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:54 --> URI Class Initialized
INFO - 2016-06-15 15:32:54 --> Router Class Initialized
INFO - 2016-06-15 15:32:54 --> Output Class Initialized
INFO - 2016-06-15 15:32:54 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:54 --> Input Class Initialized
INFO - 2016-06-15 15:32:54 --> Language Class Initialized
INFO - 2016-06-15 15:32:54 --> Loader Class Initialized
INFO - 2016-06-15 15:32:54 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:54 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:54 --> Email Class Initialized
INFO - 2016-06-15 15:32:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:54 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:54 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:54 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:54 --> Model Class Initialized
INFO - 2016-06-15 15:32:54 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:54 --> Controller Class Initialized
INFO - 2016-06-15 15:32:54 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:54 --> Model Class Initialized
INFO - 2016-06-15 15:32:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:32:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 15:32:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:32:54 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:54 --> Total execution time: 0.0664
INFO - 2016-06-15 15:32:57 --> Config Class Initialized
INFO - 2016-06-15 15:32:57 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:57 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:57 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:57 --> URI Class Initialized
INFO - 2016-06-15 15:32:57 --> Router Class Initialized
INFO - 2016-06-15 15:32:57 --> Output Class Initialized
INFO - 2016-06-15 15:32:57 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:57 --> Input Class Initialized
INFO - 2016-06-15 15:32:57 --> Language Class Initialized
INFO - 2016-06-15 15:32:57 --> Loader Class Initialized
INFO - 2016-06-15 15:32:57 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:57 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:32:57 --> Email Class Initialized
INFO - 2016-06-15 15:32:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:57 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:57 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:57 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:57 --> Model Class Initialized
INFO - 2016-06-15 15:32:57 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:57 --> Controller Class Initialized
INFO - 2016-06-15 15:32:57 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:32:57 --> Model Class Initialized
INFO - 2016-06-15 15:32:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:32:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 15:32:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:32:57 --> Final output sent to browser
DEBUG - 2016-06-15 15:32:57 --> Total execution time: 0.0213
INFO - 2016-06-15 15:47:22 --> Config Class Initialized
INFO - 2016-06-15 15:47:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:47:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:47:22 --> Utf8 Class Initialized
INFO - 2016-06-15 15:47:22 --> URI Class Initialized
INFO - 2016-06-15 15:47:22 --> Router Class Initialized
INFO - 2016-06-15 15:47:22 --> Output Class Initialized
INFO - 2016-06-15 15:47:22 --> Security Class Initialized
DEBUG - 2016-06-15 15:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:47:22 --> Input Class Initialized
INFO - 2016-06-15 15:47:22 --> Language Class Initialized
INFO - 2016-06-15 15:47:22 --> Loader Class Initialized
INFO - 2016-06-15 15:47:22 --> Helper loaded: form_helper
INFO - 2016-06-15 15:47:22 --> Database Driver Class Initialized
INFO - 2016-06-15 15:47:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:47:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:47:22 --> Email Class Initialized
INFO - 2016-06-15 15:47:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:47:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:47:22 --> Helper loaded: language_helper
INFO - 2016-06-15 15:47:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:47:22 --> Model Class Initialized
INFO - 2016-06-15 15:47:22 --> Helper loaded: date_helper
INFO - 2016-06-15 15:47:22 --> Controller Class Initialized
INFO - 2016-06-15 15:47:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:47:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:47:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:47:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:47:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:47:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:47:22 --> Model Class Initialized
INFO - 2016-06-15 15:47:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:47:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 15:47:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:47:22 --> Final output sent to browser
DEBUG - 2016-06-15 15:47:22 --> Total execution time: 0.0362
INFO - 2016-06-15 15:51:35 --> Config Class Initialized
INFO - 2016-06-15 15:51:35 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:51:35 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:51:35 --> Utf8 Class Initialized
INFO - 2016-06-15 15:51:35 --> URI Class Initialized
INFO - 2016-06-15 15:51:35 --> Router Class Initialized
INFO - 2016-06-15 15:51:35 --> Output Class Initialized
INFO - 2016-06-15 15:51:35 --> Security Class Initialized
DEBUG - 2016-06-15 15:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:51:35 --> Input Class Initialized
INFO - 2016-06-15 15:51:35 --> Language Class Initialized
INFO - 2016-06-15 15:51:35 --> Loader Class Initialized
INFO - 2016-06-15 15:51:35 --> Helper loaded: form_helper
INFO - 2016-06-15 15:51:35 --> Database Driver Class Initialized
INFO - 2016-06-15 15:51:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:51:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:51:35 --> Email Class Initialized
INFO - 2016-06-15 15:51:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:51:35 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:51:35 --> Helper loaded: language_helper
INFO - 2016-06-15 15:51:35 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:51:35 --> Model Class Initialized
INFO - 2016-06-15 15:51:35 --> Helper loaded: date_helper
INFO - 2016-06-15 15:51:35 --> Controller Class Initialized
INFO - 2016-06-15 15:51:35 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:51:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:51:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:51:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:51:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:51:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:51:35 --> Model Class Initialized
INFO - 2016-06-15 15:51:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:51:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 15:51:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:51:35 --> Final output sent to browser
DEBUG - 2016-06-15 15:51:35 --> Total execution time: 0.0164
INFO - 2016-06-15 15:54:26 --> Config Class Initialized
INFO - 2016-06-15 15:54:26 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:54:26 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:54:26 --> Utf8 Class Initialized
INFO - 2016-06-15 15:54:26 --> URI Class Initialized
INFO - 2016-06-15 15:54:26 --> Router Class Initialized
INFO - 2016-06-15 15:54:26 --> Output Class Initialized
INFO - 2016-06-15 15:54:26 --> Security Class Initialized
DEBUG - 2016-06-15 15:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:54:26 --> Input Class Initialized
INFO - 2016-06-15 15:54:26 --> Language Class Initialized
INFO - 2016-06-15 15:54:26 --> Loader Class Initialized
INFO - 2016-06-15 15:54:26 --> Helper loaded: form_helper
INFO - 2016-06-15 15:54:26 --> Database Driver Class Initialized
INFO - 2016-06-15 15:54:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:54:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:54:26 --> Email Class Initialized
INFO - 2016-06-15 15:54:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:54:26 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:54:26 --> Helper loaded: language_helper
INFO - 2016-06-15 15:54:26 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:54:26 --> Model Class Initialized
INFO - 2016-06-15 15:54:26 --> Helper loaded: date_helper
INFO - 2016-06-15 15:54:26 --> Controller Class Initialized
INFO - 2016-06-15 15:54:26 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:54:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:54:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:54:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:54:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:54:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:54:26 --> Model Class Initialized
INFO - 2016-06-15 15:54:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:54:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 15:54:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:54:26 --> Final output sent to browser
DEBUG - 2016-06-15 15:54:26 --> Total execution time: 0.0162
INFO - 2016-06-15 15:55:38 --> Config Class Initialized
INFO - 2016-06-15 15:55:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:55:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:55:38 --> Utf8 Class Initialized
INFO - 2016-06-15 15:55:38 --> URI Class Initialized
INFO - 2016-06-15 15:55:38 --> Router Class Initialized
INFO - 2016-06-15 15:55:38 --> Output Class Initialized
INFO - 2016-06-15 15:55:38 --> Security Class Initialized
DEBUG - 2016-06-15 15:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:55:38 --> Input Class Initialized
INFO - 2016-06-15 15:55:38 --> Language Class Initialized
INFO - 2016-06-15 15:55:38 --> Loader Class Initialized
INFO - 2016-06-15 15:55:38 --> Helper loaded: form_helper
INFO - 2016-06-15 15:55:38 --> Database Driver Class Initialized
INFO - 2016-06-15 15:55:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:55:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:55:38 --> Email Class Initialized
INFO - 2016-06-15 15:55:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:55:38 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:55:38 --> Helper loaded: language_helper
INFO - 2016-06-15 15:55:38 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:55:38 --> Model Class Initialized
INFO - 2016-06-15 15:55:38 --> Helper loaded: date_helper
INFO - 2016-06-15 15:55:38 --> Controller Class Initialized
INFO - 2016-06-15 15:55:38 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:55:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:55:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:55:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:55:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:55:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:55:38 --> Model Class Initialized
INFO - 2016-06-15 15:55:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:55:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 15:55:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:55:38 --> Final output sent to browser
DEBUG - 2016-06-15 15:55:38 --> Total execution time: 0.0130
INFO - 2016-06-15 15:55:55 --> Config Class Initialized
INFO - 2016-06-15 15:55:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:55:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:55:55 --> Utf8 Class Initialized
INFO - 2016-06-15 15:55:55 --> URI Class Initialized
INFO - 2016-06-15 15:55:55 --> Router Class Initialized
INFO - 2016-06-15 15:55:55 --> Output Class Initialized
INFO - 2016-06-15 15:55:55 --> Security Class Initialized
DEBUG - 2016-06-15 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:55:55 --> Input Class Initialized
INFO - 2016-06-15 15:55:55 --> Language Class Initialized
INFO - 2016-06-15 15:55:55 --> Loader Class Initialized
INFO - 2016-06-15 15:55:55 --> Helper loaded: form_helper
INFO - 2016-06-15 15:55:55 --> Database Driver Class Initialized
INFO - 2016-06-15 15:55:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:55:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:55:55 --> Email Class Initialized
INFO - 2016-06-15 15:55:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:55:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:55:55 --> Helper loaded: language_helper
INFO - 2016-06-15 15:55:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:55:55 --> Model Class Initialized
INFO - 2016-06-15 15:55:55 --> Helper loaded: date_helper
INFO - 2016-06-15 15:55:55 --> Controller Class Initialized
INFO - 2016-06-15 15:55:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:55:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:55:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:55:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:55:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:55:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:55:55 --> Model Class Initialized
INFO - 2016-06-15 15:55:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:55:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 15:55:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:55:55 --> Final output sent to browser
DEBUG - 2016-06-15 15:55:55 --> Total execution time: 0.0437
INFO - 2016-06-15 15:58:29 --> Config Class Initialized
INFO - 2016-06-15 15:58:29 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:58:29 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:58:29 --> Utf8 Class Initialized
INFO - 2016-06-15 15:58:29 --> URI Class Initialized
DEBUG - 2016-06-15 15:58:29 --> No URI present. Default controller set.
INFO - 2016-06-15 15:58:29 --> Router Class Initialized
INFO - 2016-06-15 15:58:29 --> Output Class Initialized
INFO - 2016-06-15 15:58:29 --> Security Class Initialized
DEBUG - 2016-06-15 15:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:58:29 --> Input Class Initialized
INFO - 2016-06-15 15:58:29 --> Language Class Initialized
INFO - 2016-06-15 15:58:29 --> Loader Class Initialized
INFO - 2016-06-15 15:58:29 --> Helper loaded: form_helper
INFO - 2016-06-15 15:58:29 --> Database Driver Class Initialized
INFO - 2016-06-15 15:58:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:58:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:58:29 --> Email Class Initialized
INFO - 2016-06-15 15:58:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:58:29 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:58:29 --> Helper loaded: language_helper
INFO - 2016-06-15 15:58:29 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:58:29 --> Model Class Initialized
INFO - 2016-06-15 15:58:29 --> Helper loaded: date_helper
INFO - 2016-06-15 15:58:29 --> Controller Class Initialized
INFO - 2016-06-15 15:58:29 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:58:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:58:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:58:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:58:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:58:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:58:29 --> Model Class Initialized
INFO - 2016-06-15 15:58:29 --> Form Validation Class Initialized
INFO - 2016-06-15 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 15:58:29 --> Final output sent to browser
DEBUG - 2016-06-15 15:58:29 --> Total execution time: 0.0694
INFO - 2016-06-15 15:58:31 --> Config Class Initialized
INFO - 2016-06-15 15:58:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:58:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:58:31 --> Utf8 Class Initialized
INFO - 2016-06-15 15:58:31 --> URI Class Initialized
INFO - 2016-06-15 15:58:31 --> Router Class Initialized
INFO - 2016-06-15 15:58:31 --> Output Class Initialized
INFO - 2016-06-15 15:58:31 --> Security Class Initialized
DEBUG - 2016-06-15 15:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:58:31 --> Input Class Initialized
INFO - 2016-06-15 15:58:31 --> Language Class Initialized
INFO - 2016-06-15 15:58:31 --> Loader Class Initialized
INFO - 2016-06-15 15:58:31 --> Helper loaded: form_helper
INFO - 2016-06-15 15:58:31 --> Database Driver Class Initialized
INFO - 2016-06-15 15:58:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:58:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 15:58:31 --> Email Class Initialized
INFO - 2016-06-15 15:58:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:58:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:58:31 --> Helper loaded: language_helper
INFO - 2016-06-15 15:58:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:58:31 --> Model Class Initialized
INFO - 2016-06-15 15:58:31 --> Helper loaded: date_helper
INFO - 2016-06-15 15:58:31 --> Controller Class Initialized
INFO - 2016-06-15 15:58:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:58:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:58:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:58:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:58:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:58:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:58:31 --> Model Class Initialized
INFO - 2016-06-15 15:58:31 --> Final output sent to browser
DEBUG - 2016-06-15 15:58:31 --> Total execution time: 0.0111
INFO - 2016-06-15 15:59:56 --> Config Class Initialized
INFO - 2016-06-15 15:59:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:59:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:59:56 --> Utf8 Class Initialized
INFO - 2016-06-15 15:59:56 --> URI Class Initialized
INFO - 2016-06-15 15:59:56 --> Router Class Initialized
INFO - 2016-06-15 15:59:56 --> Output Class Initialized
INFO - 2016-06-15 15:59:56 --> Security Class Initialized
DEBUG - 2016-06-15 15:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:59:56 --> Input Class Initialized
INFO - 2016-06-15 15:59:56 --> Language Class Initialized
ERROR - 2016-06-15 15:59:56 --> 404 Page Not Found: Create_user/index
INFO - 2016-06-15 16:00:37 --> Config Class Initialized
INFO - 2016-06-15 16:00:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:00:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:00:37 --> Utf8 Class Initialized
INFO - 2016-06-15 16:00:37 --> URI Class Initialized
INFO - 2016-06-15 16:00:37 --> Router Class Initialized
INFO - 2016-06-15 16:00:37 --> Output Class Initialized
INFO - 2016-06-15 16:00:37 --> Security Class Initialized
DEBUG - 2016-06-15 16:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:00:37 --> Input Class Initialized
INFO - 2016-06-15 16:00:37 --> Language Class Initialized
ERROR - 2016-06-15 16:00:37 --> 404 Page Not Found: Auth/register
INFO - 2016-06-15 16:00:48 --> Config Class Initialized
INFO - 2016-06-15 16:00:48 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:00:48 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:00:48 --> Utf8 Class Initialized
INFO - 2016-06-15 16:00:48 --> URI Class Initialized
INFO - 2016-06-15 16:00:48 --> Router Class Initialized
INFO - 2016-06-15 16:00:48 --> Output Class Initialized
INFO - 2016-06-15 16:00:48 --> Security Class Initialized
DEBUG - 2016-06-15 16:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:00:48 --> Input Class Initialized
INFO - 2016-06-15 16:00:48 --> Language Class Initialized
INFO - 2016-06-15 16:00:48 --> Loader Class Initialized
INFO - 2016-06-15 16:00:48 --> Helper loaded: form_helper
INFO - 2016-06-15 16:00:48 --> Database Driver Class Initialized
INFO - 2016-06-15 16:00:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:00:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:00:48 --> Email Class Initialized
INFO - 2016-06-15 16:00:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:00:48 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:00:48 --> Helper loaded: language_helper
INFO - 2016-06-15 16:00:48 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:00:48 --> Model Class Initialized
INFO - 2016-06-15 16:00:48 --> Helper loaded: date_helper
INFO - 2016-06-15 16:00:48 --> Controller Class Initialized
INFO - 2016-06-15 16:00:48 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:00:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:00:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:00:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:00:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:00:48 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:00:48 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:00:48 --> Form Validation Class Initialized
INFO - 2016-06-15 16:00:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:00:48 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:00:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:00:48 --> Final output sent to browser
DEBUG - 2016-06-15 16:00:48 --> Total execution time: 0.0306
INFO - 2016-06-15 16:06:36 --> Config Class Initialized
INFO - 2016-06-15 16:06:36 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:06:36 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:06:36 --> Utf8 Class Initialized
INFO - 2016-06-15 16:06:36 --> URI Class Initialized
DEBUG - 2016-06-15 16:06:36 --> No URI present. Default controller set.
INFO - 2016-06-15 16:06:36 --> Router Class Initialized
INFO - 2016-06-15 16:06:36 --> Output Class Initialized
INFO - 2016-06-15 16:06:36 --> Security Class Initialized
DEBUG - 2016-06-15 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:06:36 --> Input Class Initialized
INFO - 2016-06-15 16:06:36 --> Language Class Initialized
INFO - 2016-06-15 16:06:36 --> Loader Class Initialized
INFO - 2016-06-15 16:06:36 --> Helper loaded: form_helper
INFO - 2016-06-15 16:06:36 --> Database Driver Class Initialized
INFO - 2016-06-15 16:06:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:06:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:06:36 --> Email Class Initialized
INFO - 2016-06-15 16:06:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:06:36 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:06:36 --> Helper loaded: language_helper
INFO - 2016-06-15 16:06:36 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:36 --> Model Class Initialized
INFO - 2016-06-15 16:06:36 --> Helper loaded: date_helper
INFO - 2016-06-15 16:06:36 --> Controller Class Initialized
INFO - 2016-06-15 16:06:36 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:06:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:06:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:06:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:06:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:06:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:06:36 --> Model Class Initialized
INFO - 2016-06-15 16:06:36 --> Form Validation Class Initialized
INFO - 2016-06-15 16:06:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:06:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:06:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:06:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:06:36 --> Final output sent to browser
DEBUG - 2016-06-15 16:06:36 --> Total execution time: 0.1052
INFO - 2016-06-15 16:06:38 --> Config Class Initialized
INFO - 2016-06-15 16:06:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:06:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:06:38 --> Utf8 Class Initialized
INFO - 2016-06-15 16:06:38 --> URI Class Initialized
INFO - 2016-06-15 16:06:38 --> Router Class Initialized
INFO - 2016-06-15 16:06:38 --> Output Class Initialized
INFO - 2016-06-15 16:06:38 --> Security Class Initialized
DEBUG - 2016-06-15 16:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:06:38 --> Input Class Initialized
INFO - 2016-06-15 16:06:38 --> Language Class Initialized
INFO - 2016-06-15 16:06:38 --> Loader Class Initialized
INFO - 2016-06-15 16:06:38 --> Helper loaded: form_helper
INFO - 2016-06-15 16:06:38 --> Database Driver Class Initialized
INFO - 2016-06-15 16:06:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:06:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:06:38 --> Email Class Initialized
INFO - 2016-06-15 16:06:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:06:38 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:06:38 --> Helper loaded: language_helper
INFO - 2016-06-15 16:06:38 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:38 --> Model Class Initialized
INFO - 2016-06-15 16:06:38 --> Helper loaded: date_helper
INFO - 2016-06-15 16:06:38 --> Controller Class Initialized
INFO - 2016-06-15 16:06:38 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:06:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:06:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:06:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:06:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:06:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:06:38 --> Model Class Initialized
INFO - 2016-06-15 16:06:38 --> Final output sent to browser
DEBUG - 2016-06-15 16:06:38 --> Total execution time: 0.0137
INFO - 2016-06-15 16:06:41 --> Config Class Initialized
INFO - 2016-06-15 16:06:41 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:06:41 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:06:41 --> Utf8 Class Initialized
INFO - 2016-06-15 16:06:41 --> URI Class Initialized
INFO - 2016-06-15 16:06:41 --> Router Class Initialized
INFO - 2016-06-15 16:06:41 --> Output Class Initialized
INFO - 2016-06-15 16:06:41 --> Security Class Initialized
DEBUG - 2016-06-15 16:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:06:41 --> Input Class Initialized
INFO - 2016-06-15 16:06:41 --> Language Class Initialized
INFO - 2016-06-15 16:06:41 --> Loader Class Initialized
INFO - 2016-06-15 16:06:41 --> Helper loaded: form_helper
INFO - 2016-06-15 16:06:41 --> Database Driver Class Initialized
INFO - 2016-06-15 16:06:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:06:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:06:41 --> Email Class Initialized
INFO - 2016-06-15 16:06:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:06:41 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:06:41 --> Helper loaded: language_helper
INFO - 2016-06-15 16:06:41 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:41 --> Model Class Initialized
INFO - 2016-06-15 16:06:41 --> Helper loaded: date_helper
INFO - 2016-06-15 16:06:41 --> Controller Class Initialized
INFO - 2016-06-15 16:06:41 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:06:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:06:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:06:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:06:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:06:41 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:06:41 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:41 --> Form Validation Class Initialized
INFO - 2016-06-15 16:06:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:06:41 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:06:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:06:41 --> Final output sent to browser
DEBUG - 2016-06-15 16:06:41 --> Total execution time: 0.0141
INFO - 2016-06-15 16:29:52 --> Config Class Initialized
INFO - 2016-06-15 16:29:52 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:29:52 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:29:52 --> Utf8 Class Initialized
INFO - 2016-06-15 16:29:52 --> URI Class Initialized
INFO - 2016-06-15 16:29:52 --> Router Class Initialized
INFO - 2016-06-15 16:29:52 --> Output Class Initialized
INFO - 2016-06-15 16:29:52 --> Security Class Initialized
DEBUG - 2016-06-15 16:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:29:52 --> Input Class Initialized
INFO - 2016-06-15 16:29:52 --> Language Class Initialized
INFO - 2016-06-15 16:29:52 --> Loader Class Initialized
INFO - 2016-06-15 16:29:52 --> Helper loaded: form_helper
INFO - 2016-06-15 16:29:52 --> Database Driver Class Initialized
INFO - 2016-06-15 16:29:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:29:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:29:52 --> Email Class Initialized
INFO - 2016-06-15 16:29:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:29:52 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:29:52 --> Helper loaded: language_helper
INFO - 2016-06-15 16:29:52 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:29:52 --> Model Class Initialized
INFO - 2016-06-15 16:29:52 --> Helper loaded: date_helper
INFO - 2016-06-15 16:29:52 --> Controller Class Initialized
INFO - 2016-06-15 16:29:52 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:29:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:29:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:29:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:29:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:29:52 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:29:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:29:52 --> Form Validation Class Initialized
INFO - 2016-06-15 16:29:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:29:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:29:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:29:52 --> Final output sent to browser
DEBUG - 2016-06-15 16:29:52 --> Total execution time: 0.0198
INFO - 2016-06-15 16:30:38 --> Config Class Initialized
INFO - 2016-06-15 16:30:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:30:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:30:38 --> Utf8 Class Initialized
INFO - 2016-06-15 16:30:38 --> URI Class Initialized
INFO - 2016-06-15 16:30:38 --> Router Class Initialized
INFO - 2016-06-15 16:30:38 --> Output Class Initialized
INFO - 2016-06-15 16:30:38 --> Security Class Initialized
DEBUG - 2016-06-15 16:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:30:38 --> Input Class Initialized
INFO - 2016-06-15 16:30:38 --> Language Class Initialized
INFO - 2016-06-15 16:30:38 --> Loader Class Initialized
INFO - 2016-06-15 16:30:38 --> Helper loaded: form_helper
INFO - 2016-06-15 16:30:38 --> Database Driver Class Initialized
INFO - 2016-06-15 16:30:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:30:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:30:38 --> Email Class Initialized
INFO - 2016-06-15 16:30:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:30:38 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:30:38 --> Helper loaded: language_helper
INFO - 2016-06-15 16:30:38 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:30:38 --> Model Class Initialized
INFO - 2016-06-15 16:30:38 --> Helper loaded: date_helper
INFO - 2016-06-15 16:30:38 --> Controller Class Initialized
INFO - 2016-06-15 16:30:38 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:30:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:30:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:30:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:30:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:30:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:30:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:30:38 --> Form Validation Class Initialized
INFO - 2016-06-15 16:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:30:38 --> Final output sent to browser
DEBUG - 2016-06-15 16:30:38 --> Total execution time: 0.0400
INFO - 2016-06-15 16:31:08 --> Config Class Initialized
INFO - 2016-06-15 16:31:08 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:31:08 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:31:08 --> Utf8 Class Initialized
INFO - 2016-06-15 16:31:08 --> URI Class Initialized
INFO - 2016-06-15 16:31:08 --> Router Class Initialized
INFO - 2016-06-15 16:31:08 --> Output Class Initialized
INFO - 2016-06-15 16:31:08 --> Security Class Initialized
DEBUG - 2016-06-15 16:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:31:08 --> Input Class Initialized
INFO - 2016-06-15 16:31:08 --> Language Class Initialized
INFO - 2016-06-15 16:31:08 --> Loader Class Initialized
INFO - 2016-06-15 16:31:08 --> Helper loaded: form_helper
INFO - 2016-06-15 16:31:08 --> Database Driver Class Initialized
INFO - 2016-06-15 16:31:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:31:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:31:08 --> Email Class Initialized
INFO - 2016-06-15 16:31:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:31:08 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:31:08 --> Helper loaded: language_helper
INFO - 2016-06-15 16:31:08 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:31:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:31:08 --> Model Class Initialized
INFO - 2016-06-15 16:31:08 --> Helper loaded: date_helper
INFO - 2016-06-15 16:31:08 --> Controller Class Initialized
INFO - 2016-06-15 16:31:08 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:31:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:31:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:31:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:31:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:31:08 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:31:08 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:31:08 --> Form Validation Class Initialized
INFO - 2016-06-15 16:31:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:31:08 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:31:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:31:08 --> Final output sent to browser
DEBUG - 2016-06-15 16:31:08 --> Total execution time: 0.0212
INFO - 2016-06-15 16:31:12 --> Config Class Initialized
INFO - 2016-06-15 16:31:12 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:31:12 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:31:12 --> Utf8 Class Initialized
INFO - 2016-06-15 16:31:12 --> URI Class Initialized
INFO - 2016-06-15 16:31:12 --> Router Class Initialized
INFO - 2016-06-15 16:31:12 --> Output Class Initialized
INFO - 2016-06-15 16:31:12 --> Security Class Initialized
DEBUG - 2016-06-15 16:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:31:12 --> Input Class Initialized
INFO - 2016-06-15 16:31:12 --> Language Class Initialized
INFO - 2016-06-15 16:31:12 --> Loader Class Initialized
INFO - 2016-06-15 16:31:12 --> Helper loaded: form_helper
INFO - 2016-06-15 16:31:12 --> Database Driver Class Initialized
INFO - 2016-06-15 16:31:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:31:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:31:12 --> Email Class Initialized
INFO - 2016-06-15 16:31:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:31:12 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:31:12 --> Helper loaded: language_helper
INFO - 2016-06-15 16:31:12 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:31:12 --> Model Class Initialized
INFO - 2016-06-15 16:31:12 --> Helper loaded: date_helper
INFO - 2016-06-15 16:31:12 --> Controller Class Initialized
INFO - 2016-06-15 16:31:12 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:31:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:31:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:31:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:31:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:31:12 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:31:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:31:12 --> Form Validation Class Initialized
INFO - 2016-06-15 16:31:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:31:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:31:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:31:12 --> Final output sent to browser
DEBUG - 2016-06-15 16:31:12 --> Total execution time: 0.0562
INFO - 2016-06-15 16:31:33 --> Config Class Initialized
INFO - 2016-06-15 16:31:33 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:31:33 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:31:33 --> Utf8 Class Initialized
INFO - 2016-06-15 16:31:33 --> URI Class Initialized
INFO - 2016-06-15 16:31:33 --> Router Class Initialized
INFO - 2016-06-15 16:31:33 --> Output Class Initialized
INFO - 2016-06-15 16:31:33 --> Security Class Initialized
DEBUG - 2016-06-15 16:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:31:33 --> Input Class Initialized
INFO - 2016-06-15 16:31:33 --> Language Class Initialized
INFO - 2016-06-15 16:31:33 --> Loader Class Initialized
INFO - 2016-06-15 16:31:33 --> Helper loaded: form_helper
INFO - 2016-06-15 16:31:33 --> Database Driver Class Initialized
INFO - 2016-06-15 16:31:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:31:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:31:33 --> Email Class Initialized
INFO - 2016-06-15 16:31:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:31:33 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:31:33 --> Helper loaded: language_helper
INFO - 2016-06-15 16:31:33 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:31:33 --> Model Class Initialized
INFO - 2016-06-15 16:31:33 --> Helper loaded: date_helper
INFO - 2016-06-15 16:31:33 --> Controller Class Initialized
INFO - 2016-06-15 16:31:33 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:31:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:31:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:31:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:31:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:31:33 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:31:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:31:33 --> Form Validation Class Initialized
INFO - 2016-06-15 16:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:31:33 --> Final output sent to browser
DEBUG - 2016-06-15 16:31:33 --> Total execution time: 0.0643
INFO - 2016-06-15 16:31:57 --> Config Class Initialized
INFO - 2016-06-15 16:31:57 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:31:57 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:31:57 --> Utf8 Class Initialized
INFO - 2016-06-15 16:31:57 --> URI Class Initialized
DEBUG - 2016-06-15 16:31:57 --> No URI present. Default controller set.
INFO - 2016-06-15 16:31:57 --> Router Class Initialized
INFO - 2016-06-15 16:31:57 --> Output Class Initialized
INFO - 2016-06-15 16:31:57 --> Security Class Initialized
DEBUG - 2016-06-15 16:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:31:57 --> Input Class Initialized
INFO - 2016-06-15 16:31:57 --> Language Class Initialized
INFO - 2016-06-15 16:31:57 --> Loader Class Initialized
INFO - 2016-06-15 16:31:57 --> Helper loaded: form_helper
INFO - 2016-06-15 16:31:57 --> Database Driver Class Initialized
INFO - 2016-06-15 16:31:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:31:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:31:57 --> Email Class Initialized
INFO - 2016-06-15 16:31:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:31:57 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:31:57 --> Helper loaded: language_helper
INFO - 2016-06-15 16:31:57 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:31:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:31:57 --> Model Class Initialized
INFO - 2016-06-15 16:31:57 --> Helper loaded: date_helper
INFO - 2016-06-15 16:31:57 --> Controller Class Initialized
INFO - 2016-06-15 16:31:57 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:31:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:31:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:31:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:31:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:31:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:31:57 --> Model Class Initialized
INFO - 2016-06-15 16:31:57 --> Form Validation Class Initialized
INFO - 2016-06-15 16:31:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:31:57 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:31:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:31:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:31:57 --> Final output sent to browser
DEBUG - 2016-06-15 16:31:57 --> Total execution time: 0.0599
INFO - 2016-06-15 16:32:00 --> Config Class Initialized
INFO - 2016-06-15 16:32:00 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:32:00 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:32:00 --> Utf8 Class Initialized
INFO - 2016-06-15 16:32:00 --> URI Class Initialized
INFO - 2016-06-15 16:32:00 --> Router Class Initialized
INFO - 2016-06-15 16:32:00 --> Output Class Initialized
INFO - 2016-06-15 16:32:00 --> Security Class Initialized
DEBUG - 2016-06-15 16:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:32:00 --> Input Class Initialized
INFO - 2016-06-15 16:32:00 --> Language Class Initialized
INFO - 2016-06-15 16:32:00 --> Loader Class Initialized
INFO - 2016-06-15 16:32:00 --> Helper loaded: form_helper
INFO - 2016-06-15 16:32:00 --> Database Driver Class Initialized
INFO - 2016-06-15 16:32:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:32:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:32:00 --> Email Class Initialized
INFO - 2016-06-15 16:32:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:32:00 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:32:00 --> Helper loaded: language_helper
INFO - 2016-06-15 16:32:00 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:32:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:32:00 --> Model Class Initialized
INFO - 2016-06-15 16:32:00 --> Helper loaded: date_helper
INFO - 2016-06-15 16:32:00 --> Controller Class Initialized
INFO - 2016-06-15 16:32:00 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:32:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:32:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:32:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:32:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:32:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:32:00 --> Model Class Initialized
INFO - 2016-06-15 16:32:00 --> Final output sent to browser
DEBUG - 2016-06-15 16:32:00 --> Total execution time: 0.0138
INFO - 2016-06-15 16:32:31 --> Config Class Initialized
INFO - 2016-06-15 16:32:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:32:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:32:31 --> Utf8 Class Initialized
INFO - 2016-06-15 16:32:31 --> URI Class Initialized
INFO - 2016-06-15 16:32:31 --> Router Class Initialized
INFO - 2016-06-15 16:32:31 --> Output Class Initialized
INFO - 2016-06-15 16:32:31 --> Security Class Initialized
DEBUG - 2016-06-15 16:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:32:31 --> Input Class Initialized
INFO - 2016-06-15 16:32:31 --> Language Class Initialized
INFO - 2016-06-15 16:32:31 --> Loader Class Initialized
INFO - 2016-06-15 16:32:31 --> Helper loaded: form_helper
INFO - 2016-06-15 16:32:31 --> Database Driver Class Initialized
INFO - 2016-06-15 16:32:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:32:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:32:31 --> Email Class Initialized
INFO - 2016-06-15 16:32:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:32:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:32:31 --> Helper loaded: language_helper
INFO - 2016-06-15 16:32:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:32:31 --> Model Class Initialized
INFO - 2016-06-15 16:32:31 --> Helper loaded: date_helper
INFO - 2016-06-15 16:32:31 --> Controller Class Initialized
INFO - 2016-06-15 16:32:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:32:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:32:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:32:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:32:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:32:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:32:31 --> Model Class Initialized
INFO - 2016-06-15 16:32:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:32:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-15 16:32:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:32:31 --> Final output sent to browser
DEBUG - 2016-06-15 16:32:31 --> Total execution time: 0.0247
INFO - 2016-06-15 16:33:56 --> Config Class Initialized
INFO - 2016-06-15 16:33:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:33:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:33:56 --> Utf8 Class Initialized
INFO - 2016-06-15 16:33:56 --> URI Class Initialized
DEBUG - 2016-06-15 16:33:56 --> No URI present. Default controller set.
INFO - 2016-06-15 16:33:56 --> Router Class Initialized
INFO - 2016-06-15 16:33:56 --> Output Class Initialized
INFO - 2016-06-15 16:33:56 --> Security Class Initialized
DEBUG - 2016-06-15 16:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:33:56 --> Input Class Initialized
INFO - 2016-06-15 16:33:56 --> Language Class Initialized
INFO - 2016-06-15 16:33:56 --> Loader Class Initialized
INFO - 2016-06-15 16:33:56 --> Helper loaded: form_helper
INFO - 2016-06-15 16:33:56 --> Database Driver Class Initialized
INFO - 2016-06-15 16:33:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:33:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:33:56 --> Email Class Initialized
INFO - 2016-06-15 16:33:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:33:56 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:33:56 --> Helper loaded: language_helper
INFO - 2016-06-15 16:33:56 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:33:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:33:56 --> Model Class Initialized
INFO - 2016-06-15 16:33:56 --> Helper loaded: date_helper
INFO - 2016-06-15 16:33:56 --> Controller Class Initialized
INFO - 2016-06-15 16:33:56 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:33:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:33:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:33:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:33:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:33:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:33:56 --> Model Class Initialized
INFO - 2016-06-15 16:33:56 --> Form Validation Class Initialized
INFO - 2016-06-15 16:33:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:33:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:33:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:33:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:33:56 --> Final output sent to browser
DEBUG - 2016-06-15 16:33:56 --> Total execution time: 0.0153
INFO - 2016-06-15 16:34:01 --> Config Class Initialized
INFO - 2016-06-15 16:34:01 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:34:01 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:34:01 --> Utf8 Class Initialized
INFO - 2016-06-15 16:34:01 --> URI Class Initialized
INFO - 2016-06-15 16:34:01 --> Router Class Initialized
INFO - 2016-06-15 16:34:01 --> Output Class Initialized
INFO - 2016-06-15 16:34:01 --> Security Class Initialized
DEBUG - 2016-06-15 16:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:34:01 --> Input Class Initialized
INFO - 2016-06-15 16:34:01 --> Language Class Initialized
INFO - 2016-06-15 16:34:01 --> Loader Class Initialized
INFO - 2016-06-15 16:34:01 --> Helper loaded: form_helper
INFO - 2016-06-15 16:34:01 --> Database Driver Class Initialized
INFO - 2016-06-15 16:34:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:34:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:34:01 --> Email Class Initialized
INFO - 2016-06-15 16:34:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:34:01 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:34:01 --> Helper loaded: language_helper
INFO - 2016-06-15 16:34:01 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:34:01 --> Model Class Initialized
INFO - 2016-06-15 16:34:01 --> Helper loaded: date_helper
INFO - 2016-06-15 16:34:01 --> Controller Class Initialized
INFO - 2016-06-15 16:34:01 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:34:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:34:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:34:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:34:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:34:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:34:01 --> Model Class Initialized
INFO - 2016-06-15 16:34:01 --> Final output sent to browser
DEBUG - 2016-06-15 16:34:01 --> Total execution time: 0.0293
INFO - 2016-06-15 16:34:05 --> Config Class Initialized
INFO - 2016-06-15 16:34:05 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:34:05 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:34:05 --> Utf8 Class Initialized
INFO - 2016-06-15 16:34:05 --> URI Class Initialized
INFO - 2016-06-15 16:34:05 --> Router Class Initialized
INFO - 2016-06-15 16:34:05 --> Output Class Initialized
INFO - 2016-06-15 16:34:05 --> Security Class Initialized
DEBUG - 2016-06-15 16:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:34:05 --> Input Class Initialized
INFO - 2016-06-15 16:34:05 --> Language Class Initialized
ERROR - 2016-06-15 16:34:05 --> 404 Page Not Found: Forgot_password/index
INFO - 2016-06-15 16:34:13 --> Config Class Initialized
INFO - 2016-06-15 16:34:13 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:34:13 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:34:13 --> Utf8 Class Initialized
INFO - 2016-06-15 16:34:13 --> URI Class Initialized
INFO - 2016-06-15 16:34:13 --> Router Class Initialized
INFO - 2016-06-15 16:34:13 --> Output Class Initialized
INFO - 2016-06-15 16:34:13 --> Security Class Initialized
DEBUG - 2016-06-15 16:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:34:13 --> Input Class Initialized
INFO - 2016-06-15 16:34:13 --> Language Class Initialized
INFO - 2016-06-15 16:34:13 --> Loader Class Initialized
INFO - 2016-06-15 16:34:13 --> Helper loaded: form_helper
INFO - 2016-06-15 16:34:13 --> Database Driver Class Initialized
INFO - 2016-06-15 16:34:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:34:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:34:13 --> Email Class Initialized
INFO - 2016-06-15 16:34:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:34:13 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:34:13 --> Helper loaded: language_helper
INFO - 2016-06-15 16:34:13 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:34:13 --> Model Class Initialized
INFO - 2016-06-15 16:34:13 --> Helper loaded: date_helper
INFO - 2016-06-15 16:34:13 --> Controller Class Initialized
INFO - 2016-06-15 16:34:13 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:34:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:34:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:34:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:34:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:34:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:34:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:34:13 --> Form Validation Class Initialized
INFO - 2016-06-15 16:34:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:34:13 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-06-15 16:34:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:34:13 --> Final output sent to browser
DEBUG - 2016-06-15 16:34:13 --> Total execution time: 0.0544
INFO - 2016-06-15 16:35:21 --> Config Class Initialized
INFO - 2016-06-15 16:35:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:35:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:35:21 --> Utf8 Class Initialized
INFO - 2016-06-15 16:35:21 --> URI Class Initialized
INFO - 2016-06-15 16:35:21 --> Router Class Initialized
INFO - 2016-06-15 16:35:21 --> Output Class Initialized
INFO - 2016-06-15 16:35:21 --> Security Class Initialized
DEBUG - 2016-06-15 16:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:35:21 --> Input Class Initialized
INFO - 2016-06-15 16:35:21 --> Language Class Initialized
INFO - 2016-06-15 16:35:21 --> Loader Class Initialized
INFO - 2016-06-15 16:35:21 --> Helper loaded: form_helper
INFO - 2016-06-15 16:35:21 --> Database Driver Class Initialized
INFO - 2016-06-15 16:35:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:35:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:35:21 --> Email Class Initialized
INFO - 2016-06-15 16:35:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:35:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:35:21 --> Helper loaded: language_helper
INFO - 2016-06-15 16:35:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:35:21 --> Model Class Initialized
INFO - 2016-06-15 16:35:21 --> Helper loaded: date_helper
INFO - 2016-06-15 16:35:21 --> Controller Class Initialized
INFO - 2016-06-15 16:35:21 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:35:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:35:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:35:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:35:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:35:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:35:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:35:21 --> Form Validation Class Initialized
INFO - 2016-06-15 16:35:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:35:21 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-06-15 16:35:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:35:21 --> Final output sent to browser
DEBUG - 2016-06-15 16:35:21 --> Total execution time: 0.0569
INFO - 2016-06-15 16:35:52 --> Config Class Initialized
INFO - 2016-06-15 16:35:52 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:35:52 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:35:52 --> Utf8 Class Initialized
INFO - 2016-06-15 16:35:52 --> URI Class Initialized
DEBUG - 2016-06-15 16:35:52 --> No URI present. Default controller set.
INFO - 2016-06-15 16:35:52 --> Router Class Initialized
INFO - 2016-06-15 16:35:52 --> Output Class Initialized
INFO - 2016-06-15 16:35:52 --> Security Class Initialized
DEBUG - 2016-06-15 16:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:35:52 --> Input Class Initialized
INFO - 2016-06-15 16:35:52 --> Language Class Initialized
INFO - 2016-06-15 16:35:52 --> Loader Class Initialized
INFO - 2016-06-15 16:35:52 --> Helper loaded: form_helper
INFO - 2016-06-15 16:35:52 --> Database Driver Class Initialized
INFO - 2016-06-15 16:35:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:35:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:35:52 --> Email Class Initialized
INFO - 2016-06-15 16:35:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:35:52 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:35:52 --> Helper loaded: language_helper
INFO - 2016-06-15 16:35:52 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:35:52 --> Model Class Initialized
INFO - 2016-06-15 16:35:52 --> Helper loaded: date_helper
INFO - 2016-06-15 16:35:52 --> Controller Class Initialized
INFO - 2016-06-15 16:35:52 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:35:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:35:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:35:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:35:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:35:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:35:52 --> Model Class Initialized
INFO - 2016-06-15 16:35:52 --> Form Validation Class Initialized
INFO - 2016-06-15 16:35:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:35:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:35:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:35:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:35:52 --> Final output sent to browser
DEBUG - 2016-06-15 16:35:52 --> Total execution time: 0.0614
INFO - 2016-06-15 16:35:56 --> Config Class Initialized
INFO - 2016-06-15 16:35:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:35:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:35:56 --> Utf8 Class Initialized
INFO - 2016-06-15 16:35:56 --> URI Class Initialized
INFO - 2016-06-15 16:35:56 --> Router Class Initialized
INFO - 2016-06-15 16:35:56 --> Output Class Initialized
INFO - 2016-06-15 16:35:56 --> Security Class Initialized
DEBUG - 2016-06-15 16:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:35:56 --> Input Class Initialized
INFO - 2016-06-15 16:35:56 --> Language Class Initialized
INFO - 2016-06-15 16:35:56 --> Loader Class Initialized
INFO - 2016-06-15 16:35:56 --> Helper loaded: form_helper
INFO - 2016-06-15 16:35:56 --> Database Driver Class Initialized
INFO - 2016-06-15 16:35:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:35:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:35:56 --> Email Class Initialized
INFO - 2016-06-15 16:35:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:35:56 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:35:56 --> Helper loaded: language_helper
INFO - 2016-06-15 16:35:56 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:35:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:35:56 --> Model Class Initialized
INFO - 2016-06-15 16:35:56 --> Helper loaded: date_helper
INFO - 2016-06-15 16:35:56 --> Controller Class Initialized
INFO - 2016-06-15 16:35:56 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:35:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:35:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:35:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:35:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:35:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:35:56 --> Model Class Initialized
INFO - 2016-06-15 16:35:56 --> Final output sent to browser
DEBUG - 2016-06-15 16:35:56 --> Total execution time: 0.0474
INFO - 2016-06-15 16:36:00 --> Config Class Initialized
INFO - 2016-06-15 16:36:00 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:36:00 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:36:00 --> Utf8 Class Initialized
INFO - 2016-06-15 16:36:00 --> URI Class Initialized
INFO - 2016-06-15 16:36:00 --> Router Class Initialized
INFO - 2016-06-15 16:36:00 --> Output Class Initialized
INFO - 2016-06-15 16:36:00 --> Security Class Initialized
DEBUG - 2016-06-15 16:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:36:00 --> Input Class Initialized
INFO - 2016-06-15 16:36:00 --> Language Class Initialized
INFO - 2016-06-15 16:36:00 --> Loader Class Initialized
INFO - 2016-06-15 16:36:00 --> Helper loaded: form_helper
INFO - 2016-06-15 16:36:00 --> Database Driver Class Initialized
INFO - 2016-06-15 16:36:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:36:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:36:00 --> Email Class Initialized
INFO - 2016-06-15 16:36:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:36:00 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:36:00 --> Helper loaded: language_helper
INFO - 2016-06-15 16:36:00 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:00 --> Model Class Initialized
INFO - 2016-06-15 16:36:00 --> Helper loaded: date_helper
INFO - 2016-06-15 16:36:00 --> Controller Class Initialized
INFO - 2016-06-15 16:36:00 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:36:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:36:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:36:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:36:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:36:00 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:36:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:00 --> Form Validation Class Initialized
INFO - 2016-06-15 16:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-06-15 16:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:36:00 --> Final output sent to browser
DEBUG - 2016-06-15 16:36:00 --> Total execution time: 0.0294
INFO - 2016-06-15 16:36:04 --> Config Class Initialized
INFO - 2016-06-15 16:36:04 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:36:04 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:36:04 --> Utf8 Class Initialized
INFO - 2016-06-15 16:36:04 --> URI Class Initialized
INFO - 2016-06-15 16:36:04 --> Router Class Initialized
INFO - 2016-06-15 16:36:04 --> Output Class Initialized
INFO - 2016-06-15 16:36:04 --> Security Class Initialized
DEBUG - 2016-06-15 16:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:36:04 --> Input Class Initialized
INFO - 2016-06-15 16:36:04 --> Language Class Initialized
INFO - 2016-06-15 16:36:04 --> Loader Class Initialized
INFO - 2016-06-15 16:36:04 --> Helper loaded: form_helper
INFO - 2016-06-15 16:36:04 --> Database Driver Class Initialized
INFO - 2016-06-15 16:36:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:36:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:36:04 --> Email Class Initialized
INFO - 2016-06-15 16:36:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:36:04 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:36:04 --> Helper loaded: language_helper
INFO - 2016-06-15 16:36:04 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:36:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:04 --> Model Class Initialized
INFO - 2016-06-15 16:36:04 --> Helper loaded: date_helper
INFO - 2016-06-15 16:36:04 --> Controller Class Initialized
INFO - 2016-06-15 16:36:04 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:36:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:36:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:36:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:36:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:36:04 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:36:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:04 --> Form Validation Class Initialized
INFO - 2016-06-15 16:36:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:36:04 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-06-15 16:36:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:36:04 --> Final output sent to browser
DEBUG - 2016-06-15 16:36:04 --> Total execution time: 0.0259
INFO - 2016-06-15 16:36:12 --> Config Class Initialized
INFO - 2016-06-15 16:36:12 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:36:12 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:36:12 --> Utf8 Class Initialized
INFO - 2016-06-15 16:36:12 --> URI Class Initialized
INFO - 2016-06-15 16:36:12 --> Router Class Initialized
INFO - 2016-06-15 16:36:12 --> Output Class Initialized
INFO - 2016-06-15 16:36:12 --> Security Class Initialized
DEBUG - 2016-06-15 16:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:36:12 --> Input Class Initialized
INFO - 2016-06-15 16:36:12 --> Language Class Initialized
INFO - 2016-06-15 16:36:12 --> Loader Class Initialized
INFO - 2016-06-15 16:36:12 --> Helper loaded: form_helper
INFO - 2016-06-15 16:36:12 --> Database Driver Class Initialized
INFO - 2016-06-15 16:36:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:36:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:36:12 --> Email Class Initialized
INFO - 2016-06-15 16:36:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:36:12 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:36:12 --> Helper loaded: language_helper
INFO - 2016-06-15 16:36:12 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:12 --> Model Class Initialized
INFO - 2016-06-15 16:36:12 --> Helper loaded: date_helper
INFO - 2016-06-15 16:36:12 --> Controller Class Initialized
INFO - 2016-06-15 16:36:12 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:36:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:36:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:36:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:36:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:36:12 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:36:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:12 --> Form Validation Class Initialized
DEBUG - 2016-06-15 16:36:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:36:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:36:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:36:12 --> Final output sent to browser
DEBUG - 2016-06-15 16:36:12 --> Total execution time: 0.0266
INFO - 2016-06-15 16:36:14 --> Config Class Initialized
INFO - 2016-06-15 16:36:14 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:36:14 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:36:14 --> Utf8 Class Initialized
INFO - 2016-06-15 16:36:14 --> URI Class Initialized
INFO - 2016-06-15 16:36:14 --> Router Class Initialized
INFO - 2016-06-15 16:36:14 --> Output Class Initialized
INFO - 2016-06-15 16:36:14 --> Security Class Initialized
DEBUG - 2016-06-15 16:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:36:14 --> Input Class Initialized
INFO - 2016-06-15 16:36:14 --> Language Class Initialized
INFO - 2016-06-15 16:36:14 --> Loader Class Initialized
INFO - 2016-06-15 16:36:14 --> Helper loaded: form_helper
INFO - 2016-06-15 16:36:14 --> Database Driver Class Initialized
INFO - 2016-06-15 16:36:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:36:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:36:14 --> Email Class Initialized
INFO - 2016-06-15 16:36:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:36:14 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:36:14 --> Helper loaded: language_helper
INFO - 2016-06-15 16:36:14 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:36:14 --> Model Class Initialized
INFO - 2016-06-15 16:36:14 --> Helper loaded: date_helper
INFO - 2016-06-15 16:36:14 --> Controller Class Initialized
INFO - 2016-06-15 16:36:14 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:36:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:36:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:36:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:36:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:36:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:36:14 --> Model Class Initialized
INFO - 2016-06-15 16:36:14 --> Final output sent to browser
DEBUG - 2016-06-15 16:36:14 --> Total execution time: 0.0121
INFO - 2016-06-15 16:37:51 --> Config Class Initialized
INFO - 2016-06-15 16:37:51 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:37:51 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:37:51 --> Utf8 Class Initialized
INFO - 2016-06-15 16:37:51 --> URI Class Initialized
INFO - 2016-06-15 16:37:51 --> Router Class Initialized
INFO - 2016-06-15 16:37:51 --> Output Class Initialized
INFO - 2016-06-15 16:37:51 --> Security Class Initialized
DEBUG - 2016-06-15 16:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:37:51 --> Input Class Initialized
INFO - 2016-06-15 16:37:51 --> Language Class Initialized
INFO - 2016-06-15 16:37:51 --> Loader Class Initialized
INFO - 2016-06-15 16:37:51 --> Helper loaded: form_helper
INFO - 2016-06-15 16:37:51 --> Database Driver Class Initialized
INFO - 2016-06-15 16:37:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:37:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:37:51 --> Email Class Initialized
INFO - 2016-06-15 16:37:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:37:51 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:37:51 --> Helper loaded: language_helper
INFO - 2016-06-15 16:37:51 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:37:51 --> Model Class Initialized
INFO - 2016-06-15 16:37:51 --> Helper loaded: date_helper
INFO - 2016-06-15 16:37:51 --> Controller Class Initialized
INFO - 2016-06-15 16:37:51 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:37:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:37:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:37:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:37:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:37:51 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:37:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:37:51 --> Form Validation Class Initialized
DEBUG - 2016-06-15 16:37:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:37:51 --> Final output sent to browser
DEBUG - 2016-06-15 16:37:51 --> Total execution time: 0.0326
INFO - 2016-06-15 16:37:53 --> Config Class Initialized
INFO - 2016-06-15 16:37:53 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:37:53 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:37:53 --> Utf8 Class Initialized
INFO - 2016-06-15 16:37:53 --> URI Class Initialized
INFO - 2016-06-15 16:37:53 --> Router Class Initialized
INFO - 2016-06-15 16:37:53 --> Output Class Initialized
INFO - 2016-06-15 16:37:53 --> Security Class Initialized
DEBUG - 2016-06-15 16:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:37:53 --> Input Class Initialized
INFO - 2016-06-15 16:37:53 --> Language Class Initialized
INFO - 2016-06-15 16:37:53 --> Loader Class Initialized
INFO - 2016-06-15 16:37:53 --> Helper loaded: form_helper
INFO - 2016-06-15 16:37:53 --> Database Driver Class Initialized
INFO - 2016-06-15 16:37:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:37:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:37:53 --> Email Class Initialized
INFO - 2016-06-15 16:37:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:37:53 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:37:53 --> Helper loaded: language_helper
INFO - 2016-06-15 16:37:53 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:37:53 --> Model Class Initialized
INFO - 2016-06-15 16:37:53 --> Helper loaded: date_helper
INFO - 2016-06-15 16:37:53 --> Controller Class Initialized
INFO - 2016-06-15 16:37:53 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:37:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:37:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:37:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:37:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:37:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:37:53 --> Model Class Initialized
INFO - 2016-06-15 16:37:53 --> Final output sent to browser
DEBUG - 2016-06-15 16:37:53 --> Total execution time: 0.0128
INFO - 2016-06-15 16:39:50 --> Config Class Initialized
INFO - 2016-06-15 16:39:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:39:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:39:50 --> Utf8 Class Initialized
INFO - 2016-06-15 16:39:50 --> URI Class Initialized
INFO - 2016-06-15 16:39:50 --> Router Class Initialized
INFO - 2016-06-15 16:39:50 --> Output Class Initialized
INFO - 2016-06-15 16:39:50 --> Security Class Initialized
DEBUG - 2016-06-15 16:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:39:50 --> Input Class Initialized
INFO - 2016-06-15 16:39:50 --> Language Class Initialized
INFO - 2016-06-15 16:39:50 --> Loader Class Initialized
INFO - 2016-06-15 16:39:50 --> Helper loaded: form_helper
INFO - 2016-06-15 16:39:50 --> Database Driver Class Initialized
INFO - 2016-06-15 16:39:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:39:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:39:50 --> Email Class Initialized
INFO - 2016-06-15 16:39:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:39:50 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:39:50 --> Helper loaded: language_helper
INFO - 2016-06-15 16:39:50 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:39:50 --> Model Class Initialized
INFO - 2016-06-15 16:39:50 --> Helper loaded: date_helper
INFO - 2016-06-15 16:39:50 --> Controller Class Initialized
INFO - 2016-06-15 16:39:50 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:39:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:39:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:39:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:39:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:39:50 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:39:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:39:50 --> Form Validation Class Initialized
DEBUG - 2016-06-15 16:39:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:39:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:39:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:39:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:39:50 --> Final output sent to browser
DEBUG - 2016-06-15 16:39:50 --> Total execution time: 0.0180
INFO - 2016-06-15 16:39:52 --> Config Class Initialized
INFO - 2016-06-15 16:39:52 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:39:52 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:39:52 --> Utf8 Class Initialized
INFO - 2016-06-15 16:39:52 --> URI Class Initialized
INFO - 2016-06-15 16:39:52 --> Router Class Initialized
INFO - 2016-06-15 16:39:52 --> Output Class Initialized
INFO - 2016-06-15 16:39:52 --> Security Class Initialized
DEBUG - 2016-06-15 16:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:39:52 --> Input Class Initialized
INFO - 2016-06-15 16:39:52 --> Language Class Initialized
INFO - 2016-06-15 16:39:52 --> Loader Class Initialized
INFO - 2016-06-15 16:39:52 --> Helper loaded: form_helper
INFO - 2016-06-15 16:39:52 --> Database Driver Class Initialized
INFO - 2016-06-15 16:39:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:39:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:39:52 --> Email Class Initialized
INFO - 2016-06-15 16:39:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:39:52 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:39:52 --> Helper loaded: language_helper
INFO - 2016-06-15 16:39:52 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:39:52 --> Model Class Initialized
INFO - 2016-06-15 16:39:52 --> Helper loaded: date_helper
INFO - 2016-06-15 16:39:52 --> Controller Class Initialized
INFO - 2016-06-15 16:39:52 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:39:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:39:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:39:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:39:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:39:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:39:52 --> Model Class Initialized
INFO - 2016-06-15 16:39:52 --> Final output sent to browser
DEBUG - 2016-06-15 16:39:52 --> Total execution time: 0.0232
INFO - 2016-06-15 16:40:45 --> Config Class Initialized
INFO - 2016-06-15 16:40:45 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:40:45 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:40:45 --> Utf8 Class Initialized
INFO - 2016-06-15 16:40:45 --> URI Class Initialized
INFO - 2016-06-15 16:40:45 --> Router Class Initialized
INFO - 2016-06-15 16:40:45 --> Output Class Initialized
INFO - 2016-06-15 16:40:45 --> Security Class Initialized
DEBUG - 2016-06-15 16:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:40:45 --> Input Class Initialized
INFO - 2016-06-15 16:40:45 --> Language Class Initialized
INFO - 2016-06-15 16:40:45 --> Loader Class Initialized
INFO - 2016-06-15 16:40:45 --> Helper loaded: form_helper
INFO - 2016-06-15 16:40:45 --> Database Driver Class Initialized
INFO - 2016-06-15 16:40:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:40:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:40:45 --> Email Class Initialized
INFO - 2016-06-15 16:40:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:40:45 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:40:45 --> Helper loaded: language_helper
INFO - 2016-06-15 16:40:45 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:40:45 --> Model Class Initialized
INFO - 2016-06-15 16:40:45 --> Helper loaded: date_helper
INFO - 2016-06-15 16:40:45 --> Controller Class Initialized
INFO - 2016-06-15 16:40:45 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:40:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:40:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:40:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:40:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:40:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:40:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:40:45 --> Form Validation Class Initialized
DEBUG - 2016-06-15 16:40:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:40:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:40:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:40:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:40:45 --> Final output sent to browser
DEBUG - 2016-06-15 16:40:45 --> Total execution time: 0.0167
INFO - 2016-06-15 16:40:47 --> Config Class Initialized
INFO - 2016-06-15 16:40:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:40:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:40:47 --> Utf8 Class Initialized
INFO - 2016-06-15 16:40:47 --> URI Class Initialized
INFO - 2016-06-15 16:40:47 --> Router Class Initialized
INFO - 2016-06-15 16:40:47 --> Output Class Initialized
INFO - 2016-06-15 16:40:47 --> Security Class Initialized
DEBUG - 2016-06-15 16:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:40:47 --> Input Class Initialized
INFO - 2016-06-15 16:40:47 --> Language Class Initialized
INFO - 2016-06-15 16:40:47 --> Loader Class Initialized
INFO - 2016-06-15 16:40:47 --> Helper loaded: form_helper
INFO - 2016-06-15 16:40:47 --> Database Driver Class Initialized
INFO - 2016-06-15 16:40:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:40:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:40:47 --> Email Class Initialized
INFO - 2016-06-15 16:40:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:40:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:40:47 --> Helper loaded: language_helper
INFO - 2016-06-15 16:40:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:40:47 --> Model Class Initialized
INFO - 2016-06-15 16:40:47 --> Helper loaded: date_helper
INFO - 2016-06-15 16:40:47 --> Controller Class Initialized
INFO - 2016-06-15 16:40:47 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:40:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:40:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:40:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:40:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:40:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:40:47 --> Model Class Initialized
INFO - 2016-06-15 16:40:47 --> Final output sent to browser
DEBUG - 2016-06-15 16:40:47 --> Total execution time: 0.0129
INFO - 2016-06-15 16:42:55 --> Config Class Initialized
INFO - 2016-06-15 16:42:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:42:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:42:55 --> Utf8 Class Initialized
INFO - 2016-06-15 16:42:55 --> URI Class Initialized
DEBUG - 2016-06-15 16:42:55 --> No URI present. Default controller set.
INFO - 2016-06-15 16:42:55 --> Router Class Initialized
INFO - 2016-06-15 16:42:55 --> Output Class Initialized
INFO - 2016-06-15 16:42:55 --> Security Class Initialized
DEBUG - 2016-06-15 16:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:42:55 --> Input Class Initialized
INFO - 2016-06-15 16:42:55 --> Language Class Initialized
INFO - 2016-06-15 16:42:55 --> Loader Class Initialized
INFO - 2016-06-15 16:42:55 --> Helper loaded: form_helper
INFO - 2016-06-15 16:42:55 --> Database Driver Class Initialized
INFO - 2016-06-15 16:42:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:42:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:42:55 --> Email Class Initialized
INFO - 2016-06-15 16:42:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:42:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:42:55 --> Helper loaded: language_helper
INFO - 2016-06-15 16:42:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:42:55 --> Model Class Initialized
INFO - 2016-06-15 16:42:55 --> Helper loaded: date_helper
INFO - 2016-06-15 16:42:55 --> Controller Class Initialized
INFO - 2016-06-15 16:42:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:42:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:42:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:42:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:42:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:42:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:42:55 --> Model Class Initialized
INFO - 2016-06-15 16:42:55 --> Form Validation Class Initialized
INFO - 2016-06-15 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:42:55 --> Final output sent to browser
DEBUG - 2016-06-15 16:42:55 --> Total execution time: 0.0205
INFO - 2016-06-15 16:42:57 --> Config Class Initialized
INFO - 2016-06-15 16:42:57 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:42:57 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:42:57 --> Utf8 Class Initialized
INFO - 2016-06-15 16:42:57 --> URI Class Initialized
INFO - 2016-06-15 16:42:57 --> Router Class Initialized
INFO - 2016-06-15 16:42:57 --> Output Class Initialized
INFO - 2016-06-15 16:42:57 --> Security Class Initialized
DEBUG - 2016-06-15 16:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:42:57 --> Input Class Initialized
INFO - 2016-06-15 16:42:57 --> Language Class Initialized
INFO - 2016-06-15 16:42:57 --> Loader Class Initialized
INFO - 2016-06-15 16:42:57 --> Helper loaded: form_helper
INFO - 2016-06-15 16:42:57 --> Database Driver Class Initialized
INFO - 2016-06-15 16:42:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:42:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:42:57 --> Email Class Initialized
INFO - 2016-06-15 16:42:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:42:57 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:42:57 --> Helper loaded: language_helper
INFO - 2016-06-15 16:42:57 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:42:57 --> Model Class Initialized
INFO - 2016-06-15 16:42:57 --> Helper loaded: date_helper
INFO - 2016-06-15 16:42:57 --> Controller Class Initialized
INFO - 2016-06-15 16:42:57 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:42:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:42:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:42:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:42:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:42:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:42:57 --> Model Class Initialized
INFO - 2016-06-15 16:42:57 --> Final output sent to browser
DEBUG - 2016-06-15 16:42:57 --> Total execution time: 0.0170
INFO - 2016-06-15 16:43:45 --> Config Class Initialized
INFO - 2016-06-15 16:43:45 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:43:45 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:43:45 --> Utf8 Class Initialized
INFO - 2016-06-15 16:43:45 --> URI Class Initialized
INFO - 2016-06-15 16:43:45 --> Router Class Initialized
INFO - 2016-06-15 16:43:45 --> Output Class Initialized
INFO - 2016-06-15 16:43:45 --> Security Class Initialized
DEBUG - 2016-06-15 16:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:43:45 --> Input Class Initialized
INFO - 2016-06-15 16:43:45 --> Language Class Initialized
INFO - 2016-06-15 16:43:45 --> Loader Class Initialized
INFO - 2016-06-15 16:43:45 --> Helper loaded: form_helper
INFO - 2016-06-15 16:43:45 --> Database Driver Class Initialized
INFO - 2016-06-15 16:43:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:43:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:43:45 --> Email Class Initialized
INFO - 2016-06-15 16:43:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:43:45 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:43:45 --> Helper loaded: language_helper
INFO - 2016-06-15 16:43:45 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:43:45 --> Model Class Initialized
INFO - 2016-06-15 16:43:45 --> Helper loaded: date_helper
INFO - 2016-06-15 16:43:45 --> Controller Class Initialized
INFO - 2016-06-15 16:43:45 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:43:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:43:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:43:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:43:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:43:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:43:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:43:45 --> Form Validation Class Initialized
DEBUG - 2016-06-15 16:43:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:43:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:43:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:43:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:43:45 --> Final output sent to browser
DEBUG - 2016-06-15 16:43:45 --> Total execution time: 0.0647
INFO - 2016-06-15 16:43:46 --> Config Class Initialized
INFO - 2016-06-15 16:43:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:43:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:43:46 --> Utf8 Class Initialized
INFO - 2016-06-15 16:43:46 --> URI Class Initialized
INFO - 2016-06-15 16:43:46 --> Router Class Initialized
INFO - 2016-06-15 16:43:46 --> Output Class Initialized
INFO - 2016-06-15 16:43:46 --> Security Class Initialized
DEBUG - 2016-06-15 16:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:43:46 --> Input Class Initialized
INFO - 2016-06-15 16:43:46 --> Language Class Initialized
INFO - 2016-06-15 16:43:46 --> Loader Class Initialized
INFO - 2016-06-15 16:43:46 --> Helper loaded: form_helper
INFO - 2016-06-15 16:43:46 --> Database Driver Class Initialized
INFO - 2016-06-15 16:43:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:43:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:43:46 --> Email Class Initialized
INFO - 2016-06-15 16:43:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:43:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:43:46 --> Helper loaded: language_helper
INFO - 2016-06-15 16:43:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:43:46 --> Model Class Initialized
INFO - 2016-06-15 16:43:46 --> Helper loaded: date_helper
INFO - 2016-06-15 16:43:46 --> Controller Class Initialized
INFO - 2016-06-15 16:43:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:43:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:43:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:43:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:43:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:43:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:43:46 --> Model Class Initialized
INFO - 2016-06-15 16:43:46 --> Final output sent to browser
DEBUG - 2016-06-15 16:43:46 --> Total execution time: 0.0139
INFO - 2016-06-15 16:44:11 --> Config Class Initialized
INFO - 2016-06-15 16:44:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:44:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:44:11 --> Utf8 Class Initialized
INFO - 2016-06-15 16:44:11 --> URI Class Initialized
INFO - 2016-06-15 16:44:11 --> Router Class Initialized
INFO - 2016-06-15 16:44:11 --> Output Class Initialized
INFO - 2016-06-15 16:44:11 --> Security Class Initialized
DEBUG - 2016-06-15 16:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:44:11 --> Input Class Initialized
INFO - 2016-06-15 16:44:11 --> Language Class Initialized
INFO - 2016-06-15 16:44:11 --> Loader Class Initialized
INFO - 2016-06-15 16:44:11 --> Helper loaded: form_helper
INFO - 2016-06-15 16:44:11 --> Database Driver Class Initialized
INFO - 2016-06-15 16:44:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:44:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:44:11 --> Email Class Initialized
INFO - 2016-06-15 16:44:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:44:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:44:11 --> Helper loaded: language_helper
INFO - 2016-06-15 16:44:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:44:11 --> Model Class Initialized
INFO - 2016-06-15 16:44:11 --> Helper loaded: date_helper
INFO - 2016-06-15 16:44:11 --> Controller Class Initialized
INFO - 2016-06-15 16:44:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:44:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:44:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:44:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:44:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:44:11 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:44:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:44:11 --> Form Validation Class Initialized
DEBUG - 2016-06-15 16:44:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:44:12 --> Config Class Initialized
INFO - 2016-06-15 16:44:12 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:44:12 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:44:12 --> Utf8 Class Initialized
INFO - 2016-06-15 16:44:12 --> URI Class Initialized
DEBUG - 2016-06-15 16:44:12 --> No URI present. Default controller set.
INFO - 2016-06-15 16:44:12 --> Router Class Initialized
INFO - 2016-06-15 16:44:12 --> Output Class Initialized
INFO - 2016-06-15 16:44:12 --> Security Class Initialized
DEBUG - 2016-06-15 16:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:44:12 --> Input Class Initialized
INFO - 2016-06-15 16:44:12 --> Language Class Initialized
INFO - 2016-06-15 16:44:12 --> Loader Class Initialized
INFO - 2016-06-15 16:44:12 --> Helper loaded: form_helper
INFO - 2016-06-15 16:44:12 --> Database Driver Class Initialized
INFO - 2016-06-15 16:44:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:44:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:44:12 --> Email Class Initialized
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:44:12 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:44:12 --> Helper loaded: language_helper
INFO - 2016-06-15 16:44:12 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:44:12 --> Model Class Initialized
INFO - 2016-06-15 16:44:12 --> Helper loaded: date_helper
INFO - 2016-06-15 16:44:12 --> Controller Class Initialized
INFO - 2016-06-15 16:44:12 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:44:12 --> Config Class Initialized
INFO - 2016-06-15 16:44:12 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:44:12 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:44:12 --> Utf8 Class Initialized
INFO - 2016-06-15 16:44:12 --> URI Class Initialized
INFO - 2016-06-15 16:44:12 --> Router Class Initialized
INFO - 2016-06-15 16:44:12 --> Output Class Initialized
INFO - 2016-06-15 16:44:12 --> Security Class Initialized
DEBUG - 2016-06-15 16:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:44:12 --> Input Class Initialized
INFO - 2016-06-15 16:44:12 --> Language Class Initialized
INFO - 2016-06-15 16:44:12 --> Loader Class Initialized
INFO - 2016-06-15 16:44:12 --> Helper loaded: form_helper
INFO - 2016-06-15 16:44:12 --> Database Driver Class Initialized
INFO - 2016-06-15 16:44:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:44:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:44:12 --> Email Class Initialized
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:44:12 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:44:12 --> Helper loaded: language_helper
INFO - 2016-06-15 16:44:12 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:44:12 --> Model Class Initialized
INFO - 2016-06-15 16:44:12 --> Helper loaded: date_helper
INFO - 2016-06-15 16:44:12 --> Controller Class Initialized
INFO - 2016-06-15 16:44:12 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:44:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:44:12 --> Model Class Initialized
INFO - 2016-06-15 16:44:12 --> Form Validation Class Initialized
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-15 16:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 16:44:12 --> Final output sent to browser
DEBUG - 2016-06-15 16:44:12 --> Total execution time: 0.1599
INFO - 2016-06-15 16:44:15 --> Config Class Initialized
INFO - 2016-06-15 16:44:15 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:44:15 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:44:15 --> Utf8 Class Initialized
INFO - 2016-06-15 16:44:15 --> URI Class Initialized
INFO - 2016-06-15 16:44:15 --> Router Class Initialized
INFO - 2016-06-15 16:44:15 --> Output Class Initialized
INFO - 2016-06-15 16:44:15 --> Security Class Initialized
DEBUG - 2016-06-15 16:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:44:15 --> Input Class Initialized
INFO - 2016-06-15 16:44:15 --> Language Class Initialized
INFO - 2016-06-15 16:44:15 --> Loader Class Initialized
INFO - 2016-06-15 16:44:15 --> Helper loaded: form_helper
INFO - 2016-06-15 16:44:15 --> Database Driver Class Initialized
INFO - 2016-06-15 16:44:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:44:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:44:15 --> Email Class Initialized
INFO - 2016-06-15 16:44:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:44:15 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:44:15 --> Helper loaded: language_helper
INFO - 2016-06-15 16:44:15 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:44:15 --> Model Class Initialized
INFO - 2016-06-15 16:44:15 --> Helper loaded: date_helper
INFO - 2016-06-15 16:44:15 --> Controller Class Initialized
INFO - 2016-06-15 16:44:15 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:44:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:44:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:44:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:44:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:44:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:44:15 --> Model Class Initialized
INFO - 2016-06-15 16:44:15 --> Form Validation Class Initialized
INFO - 2016-06-15 16:44:15 --> Final output sent to browser
DEBUG - 2016-06-15 16:44:15 --> Total execution time: 0.0411
INFO - 2016-06-15 16:55:55 --> Config Class Initialized
INFO - 2016-06-15 16:55:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:55:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:55:55 --> Utf8 Class Initialized
INFO - 2016-06-15 16:55:55 --> URI Class Initialized
INFO - 2016-06-15 16:55:55 --> Router Class Initialized
INFO - 2016-06-15 16:55:55 --> Output Class Initialized
INFO - 2016-06-15 16:55:55 --> Security Class Initialized
DEBUG - 2016-06-15 16:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:55:55 --> Input Class Initialized
INFO - 2016-06-15 16:55:55 --> Language Class Initialized
INFO - 2016-06-15 16:55:55 --> Loader Class Initialized
INFO - 2016-06-15 16:55:55 --> Helper loaded: form_helper
INFO - 2016-06-15 16:55:55 --> Database Driver Class Initialized
INFO - 2016-06-15 16:55:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:55:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:55:55 --> Email Class Initialized
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:55:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:55:55 --> Helper loaded: language_helper
INFO - 2016-06-15 16:55:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:55:55 --> Model Class Initialized
INFO - 2016-06-15 16:55:55 --> Helper loaded: date_helper
INFO - 2016-06-15 16:55:55 --> Controller Class Initialized
INFO - 2016-06-15 16:55:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:55:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:55:55 --> Form Validation Class Initialized
INFO - 2016-06-15 16:55:55 --> Config Class Initialized
INFO - 2016-06-15 16:55:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:55:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:55:55 --> Utf8 Class Initialized
INFO - 2016-06-15 16:55:55 --> URI Class Initialized
DEBUG - 2016-06-15 16:55:55 --> No URI present. Default controller set.
INFO - 2016-06-15 16:55:55 --> Router Class Initialized
INFO - 2016-06-15 16:55:55 --> Output Class Initialized
INFO - 2016-06-15 16:55:55 --> Security Class Initialized
DEBUG - 2016-06-15 16:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:55:55 --> Input Class Initialized
INFO - 2016-06-15 16:55:55 --> Language Class Initialized
INFO - 2016-06-15 16:55:55 --> Loader Class Initialized
INFO - 2016-06-15 16:55:55 --> Helper loaded: form_helper
INFO - 2016-06-15 16:55:55 --> Database Driver Class Initialized
INFO - 2016-06-15 16:55:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:55:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:55:55 --> Email Class Initialized
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:55:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:55:55 --> Helper loaded: language_helper
INFO - 2016-06-15 16:55:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:55:55 --> Model Class Initialized
INFO - 2016-06-15 16:55:55 --> Helper loaded: date_helper
INFO - 2016-06-15 16:55:55 --> Controller Class Initialized
INFO - 2016-06-15 16:55:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:55:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:55:55 --> Model Class Initialized
INFO - 2016-06-15 16:55:55 --> Form Validation Class Initialized
INFO - 2016-06-15 16:55:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:55:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:55:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:55:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:55:55 --> Final output sent to browser
DEBUG - 2016-06-15 16:55:55 --> Total execution time: 0.0583
INFO - 2016-06-15 16:55:57 --> Config Class Initialized
INFO - 2016-06-15 16:55:57 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:55:57 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:55:57 --> Utf8 Class Initialized
INFO - 2016-06-15 16:55:57 --> URI Class Initialized
INFO - 2016-06-15 16:55:57 --> Router Class Initialized
INFO - 2016-06-15 16:55:57 --> Output Class Initialized
INFO - 2016-06-15 16:55:57 --> Security Class Initialized
DEBUG - 2016-06-15 16:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:55:57 --> Input Class Initialized
INFO - 2016-06-15 16:55:57 --> Language Class Initialized
INFO - 2016-06-15 16:55:57 --> Loader Class Initialized
INFO - 2016-06-15 16:55:57 --> Helper loaded: form_helper
INFO - 2016-06-15 16:55:57 --> Database Driver Class Initialized
INFO - 2016-06-15 16:55:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:55:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:55:57 --> Email Class Initialized
INFO - 2016-06-15 16:55:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:55:57 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:55:57 --> Helper loaded: language_helper
INFO - 2016-06-15 16:55:57 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:55:57 --> Model Class Initialized
INFO - 2016-06-15 16:55:57 --> Helper loaded: date_helper
INFO - 2016-06-15 16:55:57 --> Controller Class Initialized
INFO - 2016-06-15 16:55:57 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:55:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:55:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:55:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:55:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:55:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:55:57 --> Model Class Initialized
INFO - 2016-06-15 16:55:57 --> Final output sent to browser
DEBUG - 2016-06-15 16:55:57 --> Total execution time: 0.0108
INFO - 2016-06-15 16:56:22 --> Config Class Initialized
INFO - 2016-06-15 16:56:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:56:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:56:22 --> Utf8 Class Initialized
INFO - 2016-06-15 16:56:22 --> URI Class Initialized
DEBUG - 2016-06-15 16:56:22 --> No URI present. Default controller set.
INFO - 2016-06-15 16:56:22 --> Router Class Initialized
INFO - 2016-06-15 16:56:22 --> Output Class Initialized
INFO - 2016-06-15 16:56:22 --> Security Class Initialized
DEBUG - 2016-06-15 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:56:22 --> Input Class Initialized
INFO - 2016-06-15 16:56:22 --> Language Class Initialized
INFO - 2016-06-15 16:56:22 --> Loader Class Initialized
INFO - 2016-06-15 16:56:22 --> Helper loaded: form_helper
INFO - 2016-06-15 16:56:22 --> Database Driver Class Initialized
INFO - 2016-06-15 16:56:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:56:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:56:22 --> Email Class Initialized
INFO - 2016-06-15 16:56:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:56:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:56:22 --> Helper loaded: language_helper
INFO - 2016-06-15 16:56:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:56:22 --> Model Class Initialized
INFO - 2016-06-15 16:56:22 --> Helper loaded: date_helper
INFO - 2016-06-15 16:56:22 --> Controller Class Initialized
INFO - 2016-06-15 16:56:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:56:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:56:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:56:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:56:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:56:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:56:22 --> Model Class Initialized
INFO - 2016-06-15 16:56:22 --> Form Validation Class Initialized
INFO - 2016-06-15 16:56:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:56:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:56:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:56:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:56:22 --> Final output sent to browser
DEBUG - 2016-06-15 16:56:22 --> Total execution time: 0.0405
INFO - 2016-06-15 16:56:23 --> Config Class Initialized
INFO - 2016-06-15 16:56:23 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:56:23 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:56:23 --> Utf8 Class Initialized
INFO - 2016-06-15 16:56:23 --> URI Class Initialized
INFO - 2016-06-15 16:56:23 --> Router Class Initialized
INFO - 2016-06-15 16:56:23 --> Output Class Initialized
INFO - 2016-06-15 16:56:23 --> Security Class Initialized
DEBUG - 2016-06-15 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:56:23 --> Input Class Initialized
INFO - 2016-06-15 16:56:23 --> Language Class Initialized
INFO - 2016-06-15 16:56:23 --> Loader Class Initialized
INFO - 2016-06-15 16:56:23 --> Helper loaded: form_helper
INFO - 2016-06-15 16:56:23 --> Database Driver Class Initialized
INFO - 2016-06-15 16:56:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:56:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:56:23 --> Email Class Initialized
INFO - 2016-06-15 16:56:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:56:23 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:56:23 --> Helper loaded: language_helper
INFO - 2016-06-15 16:56:23 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:56:23 --> Model Class Initialized
INFO - 2016-06-15 16:56:23 --> Helper loaded: date_helper
INFO - 2016-06-15 16:56:23 --> Controller Class Initialized
INFO - 2016-06-15 16:56:23 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:56:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:56:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:56:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:56:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:56:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:56:23 --> Model Class Initialized
INFO - 2016-06-15 16:56:23 --> Final output sent to browser
DEBUG - 2016-06-15 16:56:23 --> Total execution time: 0.0135
INFO - 2016-06-15 16:56:37 --> Config Class Initialized
INFO - 2016-06-15 16:56:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:56:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:56:37 --> Utf8 Class Initialized
INFO - 2016-06-15 16:56:37 --> URI Class Initialized
DEBUG - 2016-06-15 16:56:37 --> No URI present. Default controller set.
INFO - 2016-06-15 16:56:37 --> Router Class Initialized
INFO - 2016-06-15 16:56:37 --> Output Class Initialized
INFO - 2016-06-15 16:56:37 --> Security Class Initialized
DEBUG - 2016-06-15 16:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:56:37 --> Input Class Initialized
INFO - 2016-06-15 16:56:37 --> Language Class Initialized
INFO - 2016-06-15 16:56:37 --> Loader Class Initialized
INFO - 2016-06-15 16:56:37 --> Helper loaded: form_helper
INFO - 2016-06-15 16:56:37 --> Database Driver Class Initialized
INFO - 2016-06-15 16:56:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:56:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:56:37 --> Email Class Initialized
INFO - 2016-06-15 16:56:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:56:37 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:56:37 --> Helper loaded: language_helper
INFO - 2016-06-15 16:56:37 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:56:37 --> Model Class Initialized
INFO - 2016-06-15 16:56:37 --> Helper loaded: date_helper
INFO - 2016-06-15 16:56:37 --> Controller Class Initialized
INFO - 2016-06-15 16:56:37 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:56:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:56:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:56:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:56:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:56:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:56:37 --> Model Class Initialized
INFO - 2016-06-15 16:56:37 --> Form Validation Class Initialized
INFO - 2016-06-15 16:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 16:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 16:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 16:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 16:56:37 --> Final output sent to browser
DEBUG - 2016-06-15 16:56:37 --> Total execution time: 0.0837
INFO - 2016-06-15 16:56:40 --> Config Class Initialized
INFO - 2016-06-15 16:56:40 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:56:40 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:56:40 --> Utf8 Class Initialized
INFO - 2016-06-15 16:56:40 --> URI Class Initialized
INFO - 2016-06-15 16:56:40 --> Router Class Initialized
INFO - 2016-06-15 16:56:40 --> Output Class Initialized
INFO - 2016-06-15 16:56:40 --> Security Class Initialized
DEBUG - 2016-06-15 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:56:40 --> Input Class Initialized
INFO - 2016-06-15 16:56:40 --> Language Class Initialized
INFO - 2016-06-15 16:56:40 --> Loader Class Initialized
INFO - 2016-06-15 16:56:40 --> Helper loaded: form_helper
INFO - 2016-06-15 16:56:40 --> Database Driver Class Initialized
INFO - 2016-06-15 16:56:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:56:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:56:40 --> Email Class Initialized
INFO - 2016-06-15 16:56:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:56:40 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:56:40 --> Helper loaded: language_helper
INFO - 2016-06-15 16:56:40 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:56:40 --> Model Class Initialized
INFO - 2016-06-15 16:56:40 --> Helper loaded: date_helper
INFO - 2016-06-15 16:56:40 --> Controller Class Initialized
INFO - 2016-06-15 16:56:40 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:56:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:56:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:56:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:56:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:56:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:56:40 --> Model Class Initialized
INFO - 2016-06-15 16:56:40 --> Final output sent to browser
DEBUG - 2016-06-15 16:56:40 --> Total execution time: 0.0187
INFO - 2016-06-15 16:57:25 --> Config Class Initialized
INFO - 2016-06-15 16:57:25 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:57:25 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:57:25 --> Utf8 Class Initialized
INFO - 2016-06-15 16:57:25 --> URI Class Initialized
INFO - 2016-06-15 16:57:25 --> Router Class Initialized
INFO - 2016-06-15 16:57:25 --> Output Class Initialized
INFO - 2016-06-15 16:57:25 --> Security Class Initialized
DEBUG - 2016-06-15 16:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:57:25 --> Input Class Initialized
INFO - 2016-06-15 16:57:25 --> Language Class Initialized
INFO - 2016-06-15 16:57:25 --> Loader Class Initialized
INFO - 2016-06-15 16:57:25 --> Helper loaded: form_helper
INFO - 2016-06-15 16:57:25 --> Database Driver Class Initialized
INFO - 2016-06-15 16:57:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:57:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:57:25 --> Email Class Initialized
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:57:25 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:57:25 --> Helper loaded: language_helper
INFO - 2016-06-15 16:57:25 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:57:25 --> Model Class Initialized
INFO - 2016-06-15 16:57:25 --> Helper loaded: date_helper
INFO - 2016-06-15 16:57:25 --> Controller Class Initialized
INFO - 2016-06-15 16:57:25 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 16:57:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:57:25 --> Form Validation Class Initialized
DEBUG - 2016-06-15 16:57:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:57:25 --> Config Class Initialized
INFO - 2016-06-15 16:57:25 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:57:25 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:57:25 --> Utf8 Class Initialized
INFO - 2016-06-15 16:57:25 --> URI Class Initialized
DEBUG - 2016-06-15 16:57:25 --> No URI present. Default controller set.
INFO - 2016-06-15 16:57:25 --> Router Class Initialized
INFO - 2016-06-15 16:57:25 --> Output Class Initialized
INFO - 2016-06-15 16:57:25 --> Security Class Initialized
DEBUG - 2016-06-15 16:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:57:25 --> Input Class Initialized
INFO - 2016-06-15 16:57:25 --> Language Class Initialized
INFO - 2016-06-15 16:57:25 --> Loader Class Initialized
INFO - 2016-06-15 16:57:25 --> Helper loaded: form_helper
INFO - 2016-06-15 16:57:25 --> Database Driver Class Initialized
INFO - 2016-06-15 16:57:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:57:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:57:25 --> Email Class Initialized
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:57:25 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:57:25 --> Helper loaded: language_helper
INFO - 2016-06-15 16:57:25 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:57:25 --> Model Class Initialized
INFO - 2016-06-15 16:57:25 --> Helper loaded: date_helper
INFO - 2016-06-15 16:57:25 --> Controller Class Initialized
INFO - 2016-06-15 16:57:25 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:57:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:57:26 --> Config Class Initialized
INFO - 2016-06-15 16:57:26 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:57:26 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:57:26 --> Utf8 Class Initialized
INFO - 2016-06-15 16:57:26 --> URI Class Initialized
INFO - 2016-06-15 16:57:26 --> Router Class Initialized
INFO - 2016-06-15 16:57:26 --> Output Class Initialized
INFO - 2016-06-15 16:57:26 --> Security Class Initialized
DEBUG - 2016-06-15 16:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:57:26 --> Input Class Initialized
INFO - 2016-06-15 16:57:26 --> Language Class Initialized
INFO - 2016-06-15 16:57:26 --> Loader Class Initialized
INFO - 2016-06-15 16:57:26 --> Helper loaded: form_helper
INFO - 2016-06-15 16:57:26 --> Database Driver Class Initialized
INFO - 2016-06-15 16:57:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:57:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:57:26 --> Email Class Initialized
INFO - 2016-06-15 16:57:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:57:26 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:57:26 --> Helper loaded: language_helper
INFO - 2016-06-15 16:57:26 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:57:26 --> Model Class Initialized
INFO - 2016-06-15 16:57:26 --> Helper loaded: date_helper
INFO - 2016-06-15 16:57:26 --> Controller Class Initialized
INFO - 2016-06-15 16:57:26 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:57:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:57:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:57:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:57:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:57:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:57:26 --> Model Class Initialized
INFO - 2016-06-15 16:57:26 --> Form Validation Class Initialized
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-15 16:57:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 16:57:26 --> Final output sent to browser
DEBUG - 2016-06-15 16:57:26 --> Total execution time: 0.2884
INFO - 2016-06-15 16:57:36 --> Config Class Initialized
INFO - 2016-06-15 16:57:36 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:57:36 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:57:36 --> Utf8 Class Initialized
INFO - 2016-06-15 16:57:36 --> URI Class Initialized
DEBUG - 2016-06-15 16:57:36 --> No URI present. Default controller set.
INFO - 2016-06-15 16:57:36 --> Router Class Initialized
INFO - 2016-06-15 16:57:36 --> Output Class Initialized
INFO - 2016-06-15 16:57:36 --> Security Class Initialized
DEBUG - 2016-06-15 16:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:57:36 --> Input Class Initialized
INFO - 2016-06-15 16:57:36 --> Language Class Initialized
INFO - 2016-06-15 16:57:36 --> Loader Class Initialized
INFO - 2016-06-15 16:57:36 --> Helper loaded: form_helper
INFO - 2016-06-15 16:57:36 --> Database Driver Class Initialized
INFO - 2016-06-15 16:57:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:57:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:57:36 --> Email Class Initialized
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:57:36 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:57:36 --> Helper loaded: language_helper
INFO - 2016-06-15 16:57:36 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:57:36 --> Model Class Initialized
INFO - 2016-06-15 16:57:36 --> Helper loaded: date_helper
INFO - 2016-06-15 16:57:36 --> Controller Class Initialized
INFO - 2016-06-15 16:57:36 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:57:36 --> Config Class Initialized
INFO - 2016-06-15 16:57:36 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:57:36 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:57:36 --> Utf8 Class Initialized
INFO - 2016-06-15 16:57:36 --> URI Class Initialized
INFO - 2016-06-15 16:57:36 --> Router Class Initialized
INFO - 2016-06-15 16:57:36 --> Output Class Initialized
INFO - 2016-06-15 16:57:36 --> Security Class Initialized
DEBUG - 2016-06-15 16:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:57:36 --> Input Class Initialized
INFO - 2016-06-15 16:57:36 --> Language Class Initialized
INFO - 2016-06-15 16:57:36 --> Loader Class Initialized
INFO - 2016-06-15 16:57:36 --> Helper loaded: form_helper
INFO - 2016-06-15 16:57:36 --> Database Driver Class Initialized
INFO - 2016-06-15 16:57:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:57:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 16:57:36 --> Email Class Initialized
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:57:36 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:57:36 --> Helper loaded: language_helper
INFO - 2016-06-15 16:57:36 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:57:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:57:36 --> Model Class Initialized
INFO - 2016-06-15 16:57:36 --> Helper loaded: date_helper
INFO - 2016-06-15 16:57:36 --> Controller Class Initialized
INFO - 2016-06-15 16:57:36 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:57:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 16:57:36 --> Model Class Initialized
INFO - 2016-06-15 16:57:36 --> Form Validation Class Initialized
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-15 16:57:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 16:57:36 --> Final output sent to browser
DEBUG - 2016-06-15 16:57:36 --> Total execution time: 0.0738
INFO - 2016-06-15 16:57:39 --> Config Class Initialized
INFO - 2016-06-15 16:57:39 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:57:39 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:57:39 --> Utf8 Class Initialized
INFO - 2016-06-15 16:57:39 --> URI Class Initialized
INFO - 2016-06-15 16:57:39 --> Router Class Initialized
INFO - 2016-06-15 16:57:39 --> Output Class Initialized
INFO - 2016-06-15 16:57:39 --> Security Class Initialized
DEBUG - 2016-06-15 16:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:57:39 --> Input Class Initialized
INFO - 2016-06-15 16:57:39 --> Language Class Initialized
ERROR - 2016-06-15 16:57:39 --> 404 Page Not Found: Diabet/listPosts
INFO - 2016-06-15 16:57:50 --> Config Class Initialized
INFO - 2016-06-15 16:57:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:57:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:57:50 --> Utf8 Class Initialized
INFO - 2016-06-15 16:57:50 --> URI Class Initialized
INFO - 2016-06-15 16:57:50 --> Router Class Initialized
INFO - 2016-06-15 16:57:50 --> Output Class Initialized
INFO - 2016-06-15 16:57:50 --> Security Class Initialized
DEBUG - 2016-06-15 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:57:50 --> Input Class Initialized
INFO - 2016-06-15 16:57:50 --> Language Class Initialized
ERROR - 2016-06-15 16:57:50 --> 404 Page Not Found: Diabet/listPosts
INFO - 2016-06-15 17:00:19 --> Config Class Initialized
INFO - 2016-06-15 17:00:19 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:00:19 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:00:19 --> Utf8 Class Initialized
INFO - 2016-06-15 17:00:19 --> URI Class Initialized
INFO - 2016-06-15 17:00:19 --> Router Class Initialized
INFO - 2016-06-15 17:00:19 --> Output Class Initialized
INFO - 2016-06-15 17:00:19 --> Security Class Initialized
DEBUG - 2016-06-15 17:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:00:19 --> Input Class Initialized
INFO - 2016-06-15 17:00:19 --> Language Class Initialized
INFO - 2016-06-15 17:00:19 --> Loader Class Initialized
INFO - 2016-06-15 17:00:19 --> Helper loaded: form_helper
INFO - 2016-06-15 17:00:19 --> Database Driver Class Initialized
INFO - 2016-06-15 17:00:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:00:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:00:19 --> Email Class Initialized
INFO - 2016-06-15 17:00:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:00:19 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:00:19 --> Helper loaded: language_helper
INFO - 2016-06-15 17:00:19 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:00:19 --> Model Class Initialized
INFO - 2016-06-15 17:00:19 --> Helper loaded: date_helper
INFO - 2016-06-15 17:00:19 --> Controller Class Initialized
INFO - 2016-06-15 17:00:19 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:00:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:00:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:00:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:00:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:00:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:00:19 --> Model Class Initialized
INFO - 2016-06-15 17:00:19 --> Form Validation Class Initialized
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-15 17:00:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:00:19 --> Final output sent to browser
DEBUG - 2016-06-15 17:00:19 --> Total execution time: 0.1247
INFO - 2016-06-15 17:00:37 --> Config Class Initialized
INFO - 2016-06-15 17:00:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:00:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:00:37 --> Utf8 Class Initialized
INFO - 2016-06-15 17:00:37 --> URI Class Initialized
INFO - 2016-06-15 17:00:37 --> Router Class Initialized
INFO - 2016-06-15 17:00:37 --> Output Class Initialized
INFO - 2016-06-15 17:00:37 --> Security Class Initialized
DEBUG - 2016-06-15 17:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:00:37 --> Input Class Initialized
INFO - 2016-06-15 17:00:37 --> Language Class Initialized
INFO - 2016-06-15 17:00:37 --> Loader Class Initialized
INFO - 2016-06-15 17:00:37 --> Helper loaded: form_helper
INFO - 2016-06-15 17:00:37 --> Database Driver Class Initialized
INFO - 2016-06-15 17:00:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:00:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:00:37 --> Email Class Initialized
INFO - 2016-06-15 17:00:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:00:37 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:00:37 --> Helper loaded: language_helper
INFO - 2016-06-15 17:00:37 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:00:37 --> Model Class Initialized
INFO - 2016-06-15 17:00:37 --> Helper loaded: date_helper
INFO - 2016-06-15 17:00:37 --> Controller Class Initialized
INFO - 2016-06-15 17:00:37 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:00:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:00:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:00:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:00:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:00:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:00:37 --> Model Class Initialized
INFO - 2016-06-15 17:00:37 --> Form Validation Class Initialized
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-15 17:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:00:37 --> Final output sent to browser
DEBUG - 2016-06-15 17:00:37 --> Total execution time: 0.0868
INFO - 2016-06-15 17:02:11 --> Config Class Initialized
INFO - 2016-06-15 17:02:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:02:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:02:11 --> Utf8 Class Initialized
INFO - 2016-06-15 17:02:11 --> URI Class Initialized
INFO - 2016-06-15 17:02:11 --> Router Class Initialized
INFO - 2016-06-15 17:02:11 --> Output Class Initialized
INFO - 2016-06-15 17:02:11 --> Security Class Initialized
DEBUG - 2016-06-15 17:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:02:11 --> Input Class Initialized
INFO - 2016-06-15 17:02:11 --> Language Class Initialized
INFO - 2016-06-15 17:02:11 --> Loader Class Initialized
INFO - 2016-06-15 17:02:11 --> Helper loaded: form_helper
INFO - 2016-06-15 17:02:11 --> Database Driver Class Initialized
INFO - 2016-06-15 17:02:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:02:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:02:11 --> Email Class Initialized
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:02:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:02:11 --> Helper loaded: language_helper
INFO - 2016-06-15 17:02:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:11 --> Model Class Initialized
INFO - 2016-06-15 17:02:11 --> Helper loaded: date_helper
INFO - 2016-06-15 17:02:11 --> Controller Class Initialized
INFO - 2016-06-15 17:02:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:02:11 --> Model Class Initialized
INFO - 2016-06-15 17:02:11 --> Form Validation Class Initialized
INFO - 2016-06-15 17:02:11 --> Final output sent to browser
DEBUG - 2016-06-15 17:02:11 --> Total execution time: 0.1403
INFO - 2016-06-15 17:02:11 --> Config Class Initialized
INFO - 2016-06-15 17:02:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:02:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:02:11 --> Utf8 Class Initialized
INFO - 2016-06-15 17:02:11 --> URI Class Initialized
INFO - 2016-06-15 17:02:11 --> Router Class Initialized
INFO - 2016-06-15 17:02:11 --> Output Class Initialized
INFO - 2016-06-15 17:02:11 --> Security Class Initialized
DEBUG - 2016-06-15 17:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:02:11 --> Input Class Initialized
INFO - 2016-06-15 17:02:11 --> Language Class Initialized
INFO - 2016-06-15 17:02:11 --> Loader Class Initialized
INFO - 2016-06-15 17:02:11 --> Helper loaded: form_helper
INFO - 2016-06-15 17:02:11 --> Database Driver Class Initialized
INFO - 2016-06-15 17:02:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:02:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:02:11 --> Email Class Initialized
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:02:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:02:11 --> Helper loaded: language_helper
INFO - 2016-06-15 17:02:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:11 --> Model Class Initialized
INFO - 2016-06-15 17:02:11 --> Helper loaded: date_helper
INFO - 2016-06-15 17:02:11 --> Controller Class Initialized
INFO - 2016-06-15 17:02:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:02:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:02:11 --> Model Class Initialized
INFO - 2016-06-15 17:02:11 --> Form Validation Class Initialized
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-15 17:02:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:02:11 --> Final output sent to browser
DEBUG - 2016-06-15 17:02:11 --> Total execution time: 0.0470
INFO - 2016-06-15 17:02:27 --> Config Class Initialized
INFO - 2016-06-15 17:02:27 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:02:27 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:02:27 --> Utf8 Class Initialized
INFO - 2016-06-15 17:02:27 --> URI Class Initialized
DEBUG - 2016-06-15 17:02:27 --> No URI present. Default controller set.
INFO - 2016-06-15 17:02:27 --> Router Class Initialized
INFO - 2016-06-15 17:02:27 --> Output Class Initialized
INFO - 2016-06-15 17:02:27 --> Security Class Initialized
DEBUG - 2016-06-15 17:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:02:27 --> Input Class Initialized
INFO - 2016-06-15 17:02:27 --> Language Class Initialized
INFO - 2016-06-15 17:02:27 --> Loader Class Initialized
INFO - 2016-06-15 17:02:27 --> Helper loaded: form_helper
INFO - 2016-06-15 17:02:27 --> Database Driver Class Initialized
INFO - 2016-06-15 17:02:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:02:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:02:27 --> Email Class Initialized
INFO - 2016-06-15 17:02:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:02:27 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:02:27 --> Helper loaded: language_helper
INFO - 2016-06-15 17:02:27 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:27 --> Model Class Initialized
INFO - 2016-06-15 17:02:27 --> Helper loaded: date_helper
INFO - 2016-06-15 17:02:27 --> Controller Class Initialized
INFO - 2016-06-15 17:02:27 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:02:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:02:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:02:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:02:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:02:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:02:28 --> Config Class Initialized
INFO - 2016-06-15 17:02:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:02:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:02:28 --> Utf8 Class Initialized
INFO - 2016-06-15 17:02:28 --> URI Class Initialized
INFO - 2016-06-15 17:02:28 --> Router Class Initialized
INFO - 2016-06-15 17:02:28 --> Output Class Initialized
INFO - 2016-06-15 17:02:28 --> Security Class Initialized
DEBUG - 2016-06-15 17:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:02:28 --> Input Class Initialized
INFO - 2016-06-15 17:02:28 --> Language Class Initialized
INFO - 2016-06-15 17:02:28 --> Loader Class Initialized
INFO - 2016-06-15 17:02:28 --> Helper loaded: form_helper
INFO - 2016-06-15 17:02:28 --> Database Driver Class Initialized
INFO - 2016-06-15 17:02:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:02:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:02:28 --> Email Class Initialized
INFO - 2016-06-15 17:02:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:02:28 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:02:28 --> Helper loaded: language_helper
INFO - 2016-06-15 17:02:28 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:28 --> Model Class Initialized
INFO - 2016-06-15 17:02:28 --> Helper loaded: date_helper
INFO - 2016-06-15 17:02:28 --> Controller Class Initialized
INFO - 2016-06-15 17:02:28 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:02:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:02:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:02:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:02:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:02:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:02:28 --> Model Class Initialized
INFO - 2016-06-15 17:02:28 --> Form Validation Class Initialized
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-15 17:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:02:28 --> Final output sent to browser
DEBUG - 2016-06-15 17:02:28 --> Total execution time: 0.0272
INFO - 2016-06-15 17:02:31 --> Config Class Initialized
INFO - 2016-06-15 17:02:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:02:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:02:31 --> Utf8 Class Initialized
INFO - 2016-06-15 17:02:31 --> URI Class Initialized
INFO - 2016-06-15 17:02:31 --> Router Class Initialized
INFO - 2016-06-15 17:02:31 --> Output Class Initialized
INFO - 2016-06-15 17:02:31 --> Security Class Initialized
DEBUG - 2016-06-15 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:02:31 --> Input Class Initialized
INFO - 2016-06-15 17:02:31 --> Language Class Initialized
INFO - 2016-06-15 17:02:31 --> Loader Class Initialized
INFO - 2016-06-15 17:02:31 --> Helper loaded: form_helper
INFO - 2016-06-15 17:02:31 --> Database Driver Class Initialized
INFO - 2016-06-15 17:02:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:02:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:02:31 --> Email Class Initialized
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:02:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:02:31 --> Helper loaded: language_helper
INFO - 2016-06-15 17:02:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:31 --> Model Class Initialized
INFO - 2016-06-15 17:02:31 --> Helper loaded: date_helper
INFO - 2016-06-15 17:02:31 --> Controller Class Initialized
INFO - 2016-06-15 17:02:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 17:02:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:31 --> Form Validation Class Initialized
INFO - 2016-06-15 17:02:31 --> Config Class Initialized
INFO - 2016-06-15 17:02:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:02:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:02:31 --> Utf8 Class Initialized
INFO - 2016-06-15 17:02:31 --> URI Class Initialized
DEBUG - 2016-06-15 17:02:31 --> No URI present. Default controller set.
INFO - 2016-06-15 17:02:31 --> Router Class Initialized
INFO - 2016-06-15 17:02:31 --> Output Class Initialized
INFO - 2016-06-15 17:02:31 --> Security Class Initialized
DEBUG - 2016-06-15 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:02:31 --> Input Class Initialized
INFO - 2016-06-15 17:02:31 --> Language Class Initialized
INFO - 2016-06-15 17:02:31 --> Loader Class Initialized
INFO - 2016-06-15 17:02:31 --> Helper loaded: form_helper
INFO - 2016-06-15 17:02:31 --> Database Driver Class Initialized
INFO - 2016-06-15 17:02:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:02:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:02:31 --> Email Class Initialized
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:02:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:02:31 --> Helper loaded: language_helper
INFO - 2016-06-15 17:02:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:31 --> Model Class Initialized
INFO - 2016-06-15 17:02:31 --> Helper loaded: date_helper
INFO - 2016-06-15 17:02:31 --> Controller Class Initialized
INFO - 2016-06-15 17:02:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:02:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:02:31 --> Model Class Initialized
INFO - 2016-06-15 17:02:31 --> Form Validation Class Initialized
INFO - 2016-06-15 17:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-15 17:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-15 17:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-15 17:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-15 17:02:31 --> Final output sent to browser
DEBUG - 2016-06-15 17:02:31 --> Total execution time: 0.0174
INFO - 2016-06-15 17:02:37 --> Config Class Initialized
INFO - 2016-06-15 17:02:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:02:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:02:37 --> Utf8 Class Initialized
INFO - 2016-06-15 17:02:37 --> URI Class Initialized
INFO - 2016-06-15 17:02:37 --> Router Class Initialized
INFO - 2016-06-15 17:02:37 --> Output Class Initialized
INFO - 2016-06-15 17:02:37 --> Security Class Initialized
DEBUG - 2016-06-15 17:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:02:37 --> Input Class Initialized
INFO - 2016-06-15 17:02:37 --> Language Class Initialized
INFO - 2016-06-15 17:02:37 --> Loader Class Initialized
INFO - 2016-06-15 17:02:37 --> Helper loaded: form_helper
INFO - 2016-06-15 17:02:37 --> Database Driver Class Initialized
INFO - 2016-06-15 17:02:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:02:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-15 17:02:37 --> Email Class Initialized
INFO - 2016-06-15 17:02:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:02:37 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:02:37 --> Helper loaded: language_helper
INFO - 2016-06-15 17:02:37 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:02:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:02:37 --> Model Class Initialized
INFO - 2016-06-15 17:02:37 --> Helper loaded: date_helper
INFO - 2016-06-15 17:02:37 --> Controller Class Initialized
INFO - 2016-06-15 17:02:37 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:02:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:02:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:02:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:02:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:02:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:02:37 --> Model Class Initialized
INFO - 2016-06-15 17:02:37 --> Final output sent to browser
DEBUG - 2016-06-15 17:02:37 --> Total execution time: 0.0333
INFO - 2016-06-15 14:39:36 --> Config Class Initialized
INFO - 2016-06-15 14:39:36 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:39:36 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:39:36 --> Utf8 Class Initialized
INFO - 2016-06-15 14:39:36 --> URI Class Initialized
DEBUG - 2016-06-15 14:39:36 --> No URI present. Default controller set.
INFO - 2016-06-15 14:39:36 --> Router Class Initialized
INFO - 2016-06-15 14:39:36 --> Output Class Initialized
INFO - 2016-06-15 14:39:36 --> Security Class Initialized
DEBUG - 2016-06-15 14:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:39:36 --> Input Class Initialized
INFO - 2016-06-15 14:39:36 --> Language Class Initialized
INFO - 2016-06-15 14:39:36 --> Loader Class Initialized
INFO - 2016-06-15 14:39:36 --> Helper loaded: form_helper
INFO - 2016-06-15 14:39:36 --> Database Driver Class Initialized
INFO - 2016-06-15 14:39:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:39:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:39:36 --> Email Class Initialized
INFO - 2016-06-15 14:39:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:39:36 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:39:36 --> Helper loaded: language_helper
INFO - 2016-06-15 14:39:36 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:39:36 --> Model Class Initialized
INFO - 2016-06-15 14:39:36 --> Helper loaded: date_helper
INFO - 2016-06-15 14:39:36 --> Controller Class Initialized
INFO - 2016-06-15 14:39:36 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:39:36 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:39:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:39:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:39:36 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:39:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:39:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:39:36 --> Model Class Initialized
INFO - 2016-06-15 17:39:36 --> Form Validation Class Initialized
INFO - 2016-06-15 17:39:36 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:39:36 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:39:36 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 17:39:36 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:39:36 --> Final output sent to browser
DEBUG - 2016-06-15 17:39:36 --> Total execution time: 0.0879
INFO - 2016-06-15 14:39:38 --> Config Class Initialized
INFO - 2016-06-15 14:39:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:39:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:39:38 --> Utf8 Class Initialized
INFO - 2016-06-15 14:39:38 --> URI Class Initialized
INFO - 2016-06-15 14:39:38 --> Router Class Initialized
INFO - 2016-06-15 14:39:38 --> Output Class Initialized
INFO - 2016-06-15 14:39:38 --> Security Class Initialized
DEBUG - 2016-06-15 14:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:39:38 --> Input Class Initialized
INFO - 2016-06-15 14:39:38 --> Language Class Initialized
INFO - 2016-06-15 14:39:38 --> Loader Class Initialized
INFO - 2016-06-15 14:39:38 --> Helper loaded: form_helper
INFO - 2016-06-15 14:39:38 --> Database Driver Class Initialized
INFO - 2016-06-15 14:39:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:39:38 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:39:38 --> Email Class Initialized
INFO - 2016-06-15 14:39:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:39:38 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:39:38 --> Helper loaded: language_helper
INFO - 2016-06-15 14:39:38 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:39:38 --> Model Class Initialized
INFO - 2016-06-15 14:39:38 --> Helper loaded: date_helper
INFO - 2016-06-15 14:39:38 --> Controller Class Initialized
INFO - 2016-06-15 14:39:38 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:39:38 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:39:38 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:39:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:39:38 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:39:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:39:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:39:38 --> Model Class Initialized
INFO - 2016-06-15 17:39:38 --> Final output sent to browser
DEBUG - 2016-06-15 17:39:38 --> Total execution time: 0.0969
INFO - 2016-06-15 14:39:38 --> Config Class Initialized
INFO - 2016-06-15 14:39:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:39:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:39:38 --> Utf8 Class Initialized
INFO - 2016-06-15 14:39:38 --> URI Class Initialized
INFO - 2016-06-15 14:39:38 --> Router Class Initialized
INFO - 2016-06-15 14:39:38 --> Output Class Initialized
INFO - 2016-06-15 14:39:38 --> Security Class Initialized
DEBUG - 2016-06-15 14:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:39:38 --> Input Class Initialized
INFO - 2016-06-15 14:39:38 --> Language Class Initialized
ERROR - 2016-06-15 14:39:38 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 14:39:50 --> Config Class Initialized
INFO - 2016-06-15 14:39:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:39:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:39:50 --> Utf8 Class Initialized
INFO - 2016-06-15 14:39:50 --> URI Class Initialized
DEBUG - 2016-06-15 14:39:50 --> No URI present. Default controller set.
INFO - 2016-06-15 14:39:50 --> Router Class Initialized
INFO - 2016-06-15 14:39:50 --> Output Class Initialized
INFO - 2016-06-15 14:39:50 --> Security Class Initialized
DEBUG - 2016-06-15 14:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:39:50 --> Input Class Initialized
INFO - 2016-06-15 14:39:50 --> Language Class Initialized
INFO - 2016-06-15 14:39:50 --> Loader Class Initialized
INFO - 2016-06-15 14:39:50 --> Helper loaded: form_helper
INFO - 2016-06-15 14:39:50 --> Database Driver Class Initialized
INFO - 2016-06-15 14:39:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:39:50 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:39:50 --> Email Class Initialized
INFO - 2016-06-15 14:39:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:39:50 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:39:50 --> Helper loaded: language_helper
INFO - 2016-06-15 14:39:50 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:39:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:39:50 --> Model Class Initialized
INFO - 2016-06-15 14:39:50 --> Helper loaded: date_helper
INFO - 2016-06-15 14:39:50 --> Controller Class Initialized
INFO - 2016-06-15 14:39:50 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:39:50 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:39:50 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:39:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:39:50 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:39:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:39:50 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:39:50 --> Model Class Initialized
INFO - 2016-06-15 17:39:50 --> Form Validation Class Initialized
INFO - 2016-06-15 17:39:50 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:39:50 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:39:50 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 17:39:50 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:39:50 --> Final output sent to browser
DEBUG - 2016-06-15 17:39:50 --> Total execution time: 0.0940
INFO - 2016-06-15 14:39:52 --> Config Class Initialized
INFO - 2016-06-15 14:39:52 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:39:52 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:39:52 --> Utf8 Class Initialized
INFO - 2016-06-15 14:39:52 --> URI Class Initialized
INFO - 2016-06-15 14:39:52 --> Router Class Initialized
INFO - 2016-06-15 14:39:52 --> Output Class Initialized
INFO - 2016-06-15 14:39:52 --> Security Class Initialized
DEBUG - 2016-06-15 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:39:52 --> Input Class Initialized
INFO - 2016-06-15 14:39:52 --> Language Class Initialized
INFO - 2016-06-15 14:39:52 --> Loader Class Initialized
INFO - 2016-06-15 14:39:52 --> Helper loaded: form_helper
INFO - 2016-06-15 14:39:52 --> Database Driver Class Initialized
INFO - 2016-06-15 14:39:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:39:52 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:39:52 --> Email Class Initialized
INFO - 2016-06-15 14:39:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:39:52 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:39:52 --> Helper loaded: language_helper
INFO - 2016-06-15 14:39:52 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:39:52 --> Model Class Initialized
INFO - 2016-06-15 14:39:52 --> Helper loaded: date_helper
INFO - 2016-06-15 14:39:52 --> Controller Class Initialized
INFO - 2016-06-15 14:39:52 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:39:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:39:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:39:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:39:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:39:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:39:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:39:52 --> Model Class Initialized
INFO - 2016-06-15 17:39:52 --> Final output sent to browser
DEBUG - 2016-06-15 17:39:52 --> Total execution time: 0.0931
INFO - 2016-06-15 14:39:53 --> Config Class Initialized
INFO - 2016-06-15 14:39:53 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:39:53 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:39:53 --> Utf8 Class Initialized
INFO - 2016-06-15 14:39:53 --> URI Class Initialized
INFO - 2016-06-15 14:39:53 --> Router Class Initialized
INFO - 2016-06-15 14:39:53 --> Output Class Initialized
INFO - 2016-06-15 14:39:53 --> Security Class Initialized
DEBUG - 2016-06-15 14:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:39:53 --> Input Class Initialized
INFO - 2016-06-15 14:39:53 --> Language Class Initialized
ERROR - 2016-06-15 14:39:53 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 14:40:40 --> Config Class Initialized
INFO - 2016-06-15 14:40:40 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:40:40 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:40:40 --> Utf8 Class Initialized
INFO - 2016-06-15 14:40:40 --> URI Class Initialized
DEBUG - 2016-06-15 14:40:40 --> No URI present. Default controller set.
INFO - 2016-06-15 14:40:40 --> Router Class Initialized
INFO - 2016-06-15 14:40:40 --> Output Class Initialized
INFO - 2016-06-15 14:40:40 --> Security Class Initialized
DEBUG - 2016-06-15 14:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:40:40 --> Input Class Initialized
INFO - 2016-06-15 14:40:40 --> Language Class Initialized
INFO - 2016-06-15 14:40:40 --> Loader Class Initialized
INFO - 2016-06-15 14:40:40 --> Helper loaded: form_helper
INFO - 2016-06-15 14:40:40 --> Database Driver Class Initialized
INFO - 2016-06-15 14:40:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:40:40 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:40:40 --> Email Class Initialized
INFO - 2016-06-15 14:40:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:40:40 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:40:40 --> Helper loaded: language_helper
INFO - 2016-06-15 14:40:40 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:40:40 --> Model Class Initialized
INFO - 2016-06-15 14:40:40 --> Helper loaded: date_helper
INFO - 2016-06-15 14:40:40 --> Controller Class Initialized
INFO - 2016-06-15 14:40:40 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:40:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:40:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:40:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:40:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:40:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:40:40 --> Model Class Initialized
INFO - 2016-06-15 17:40:40 --> Form Validation Class Initialized
INFO - 2016-06-15 17:40:40 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:40:40 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:40:40 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 17:40:40 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:40:40 --> Final output sent to browser
DEBUG - 2016-06-15 17:40:40 --> Total execution time: 0.0799
INFO - 2016-06-15 14:40:42 --> Config Class Initialized
INFO - 2016-06-15 14:40:42 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:40:42 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:40:42 --> Utf8 Class Initialized
INFO - 2016-06-15 14:40:42 --> URI Class Initialized
INFO - 2016-06-15 14:40:42 --> Router Class Initialized
INFO - 2016-06-15 14:40:42 --> Output Class Initialized
INFO - 2016-06-15 14:40:42 --> Security Class Initialized
DEBUG - 2016-06-15 14:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:40:42 --> Input Class Initialized
INFO - 2016-06-15 14:40:42 --> Language Class Initialized
INFO - 2016-06-15 14:40:42 --> Loader Class Initialized
INFO - 2016-06-15 14:40:42 --> Helper loaded: form_helper
INFO - 2016-06-15 14:40:42 --> Database Driver Class Initialized
INFO - 2016-06-15 14:40:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:40:42 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:40:42 --> Email Class Initialized
INFO - 2016-06-15 14:40:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:40:42 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:40:42 --> Helper loaded: language_helper
INFO - 2016-06-15 14:40:42 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:40:42 --> Model Class Initialized
INFO - 2016-06-15 14:40:42 --> Helper loaded: date_helper
INFO - 2016-06-15 14:40:42 --> Controller Class Initialized
INFO - 2016-06-15 14:40:42 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:40:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:40:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:40:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:40:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:40:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:40:42 --> Model Class Initialized
INFO - 2016-06-15 17:40:42 --> Final output sent to browser
DEBUG - 2016-06-15 17:40:42 --> Total execution time: 0.0898
INFO - 2016-06-15 14:40:45 --> Config Class Initialized
INFO - 2016-06-15 14:40:45 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:40:45 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:40:45 --> Utf8 Class Initialized
INFO - 2016-06-15 14:40:45 --> URI Class Initialized
INFO - 2016-06-15 14:40:45 --> Router Class Initialized
INFO - 2016-06-15 14:40:45 --> Output Class Initialized
INFO - 2016-06-15 14:40:45 --> Security Class Initialized
DEBUG - 2016-06-15 14:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:40:45 --> Input Class Initialized
INFO - 2016-06-15 14:40:45 --> Language Class Initialized
ERROR - 2016-06-15 14:40:45 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 14:44:03 --> Config Class Initialized
INFO - 2016-06-15 14:44:03 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:44:03 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:44:03 --> Utf8 Class Initialized
INFO - 2016-06-15 14:44:03 --> URI Class Initialized
DEBUG - 2016-06-15 14:44:03 --> No URI present. Default controller set.
INFO - 2016-06-15 14:44:03 --> Router Class Initialized
INFO - 2016-06-15 14:44:03 --> Output Class Initialized
INFO - 2016-06-15 14:44:03 --> Security Class Initialized
DEBUG - 2016-06-15 14:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:44:03 --> Input Class Initialized
INFO - 2016-06-15 14:44:03 --> Language Class Initialized
INFO - 2016-06-15 14:44:03 --> Loader Class Initialized
INFO - 2016-06-15 14:44:03 --> Helper loaded: form_helper
INFO - 2016-06-15 14:44:03 --> Database Driver Class Initialized
INFO - 2016-06-15 14:44:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:44:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:44:03 --> Email Class Initialized
INFO - 2016-06-15 14:44:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:44:03 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:44:03 --> Helper loaded: language_helper
INFO - 2016-06-15 14:44:03 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:44:03 --> Model Class Initialized
INFO - 2016-06-15 14:44:03 --> Helper loaded: date_helper
INFO - 2016-06-15 14:44:03 --> Controller Class Initialized
INFO - 2016-06-15 14:44:03 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:44:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:44:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:44:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:44:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:44:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:44:03 --> Model Class Initialized
INFO - 2016-06-15 17:44:03 --> Form Validation Class Initialized
INFO - 2016-06-15 17:44:03 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:44:03 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:44:03 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 17:44:03 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:44:03 --> Final output sent to browser
DEBUG - 2016-06-15 17:44:03 --> Total execution time: 0.0845
INFO - 2016-06-15 14:44:05 --> Config Class Initialized
INFO - 2016-06-15 14:44:05 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:44:05 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:44:05 --> Utf8 Class Initialized
INFO - 2016-06-15 14:44:05 --> URI Class Initialized
INFO - 2016-06-15 14:44:05 --> Router Class Initialized
INFO - 2016-06-15 14:44:05 --> Output Class Initialized
INFO - 2016-06-15 14:44:05 --> Security Class Initialized
DEBUG - 2016-06-15 14:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:44:05 --> Input Class Initialized
INFO - 2016-06-15 14:44:05 --> Language Class Initialized
INFO - 2016-06-15 14:44:05 --> Loader Class Initialized
INFO - 2016-06-15 14:44:05 --> Helper loaded: form_helper
INFO - 2016-06-15 14:44:05 --> Database Driver Class Initialized
INFO - 2016-06-15 14:44:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:44:05 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:44:05 --> Email Class Initialized
INFO - 2016-06-15 14:44:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:44:05 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:44:05 --> Helper loaded: language_helper
INFO - 2016-06-15 14:44:05 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:44:05 --> Model Class Initialized
INFO - 2016-06-15 14:44:05 --> Helper loaded: date_helper
INFO - 2016-06-15 14:44:05 --> Controller Class Initialized
INFO - 2016-06-15 14:44:05 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:44:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:44:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:44:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:44:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:44:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:44:05 --> Model Class Initialized
INFO - 2016-06-15 17:44:05 --> Final output sent to browser
DEBUG - 2016-06-15 17:44:05 --> Total execution time: 0.0837
INFO - 2016-06-15 14:45:00 --> Config Class Initialized
INFO - 2016-06-15 14:45:00 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:45:00 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:45:00 --> Utf8 Class Initialized
INFO - 2016-06-15 14:45:00 --> URI Class Initialized
DEBUG - 2016-06-15 14:45:00 --> No URI present. Default controller set.
INFO - 2016-06-15 14:45:00 --> Router Class Initialized
INFO - 2016-06-15 14:45:00 --> Output Class Initialized
INFO - 2016-06-15 14:45:00 --> Security Class Initialized
DEBUG - 2016-06-15 14:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:45:00 --> Input Class Initialized
INFO - 2016-06-15 14:45:00 --> Language Class Initialized
INFO - 2016-06-15 14:45:00 --> Loader Class Initialized
INFO - 2016-06-15 14:45:00 --> Helper loaded: form_helper
INFO - 2016-06-15 14:45:00 --> Database Driver Class Initialized
INFO - 2016-06-15 14:45:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:45:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:45:00 --> Email Class Initialized
INFO - 2016-06-15 14:45:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:45:00 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:45:00 --> Helper loaded: language_helper
INFO - 2016-06-15 14:45:00 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:45:00 --> Model Class Initialized
INFO - 2016-06-15 14:45:00 --> Helper loaded: date_helper
INFO - 2016-06-15 14:45:00 --> Controller Class Initialized
INFO - 2016-06-15 14:45:00 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:45:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:45:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:45:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:45:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:45:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:45:00 --> Model Class Initialized
INFO - 2016-06-15 17:45:00 --> Form Validation Class Initialized
INFO - 2016-06-15 17:45:00 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:45:00 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:45:00 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 17:45:00 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:45:00 --> Final output sent to browser
DEBUG - 2016-06-15 17:45:00 --> Total execution time: 0.1016
INFO - 2016-06-15 14:45:02 --> Config Class Initialized
INFO - 2016-06-15 14:45:02 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:45:02 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:45:02 --> Utf8 Class Initialized
INFO - 2016-06-15 14:45:02 --> URI Class Initialized
INFO - 2016-06-15 14:45:02 --> Router Class Initialized
INFO - 2016-06-15 14:45:02 --> Output Class Initialized
INFO - 2016-06-15 14:45:02 --> Security Class Initialized
DEBUG - 2016-06-15 14:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:45:02 --> Input Class Initialized
INFO - 2016-06-15 14:45:02 --> Language Class Initialized
INFO - 2016-06-15 14:45:02 --> Loader Class Initialized
INFO - 2016-06-15 14:45:02 --> Helper loaded: form_helper
INFO - 2016-06-15 14:45:02 --> Database Driver Class Initialized
INFO - 2016-06-15 14:45:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:45:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:45:02 --> Email Class Initialized
INFO - 2016-06-15 14:45:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:45:02 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:45:02 --> Helper loaded: language_helper
INFO - 2016-06-15 14:45:02 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:45:02 --> Model Class Initialized
INFO - 2016-06-15 14:45:02 --> Helper loaded: date_helper
INFO - 2016-06-15 14:45:02 --> Controller Class Initialized
INFO - 2016-06-15 14:45:02 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:45:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:45:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:45:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:45:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:45:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:45:02 --> Model Class Initialized
INFO - 2016-06-15 17:45:02 --> Final output sent to browser
DEBUG - 2016-06-15 17:45:02 --> Total execution time: 0.1143
INFO - 2016-06-15 14:45:31 --> Config Class Initialized
INFO - 2016-06-15 14:45:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:45:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:45:31 --> Utf8 Class Initialized
INFO - 2016-06-15 14:45:31 --> URI Class Initialized
DEBUG - 2016-06-15 14:45:31 --> No URI present. Default controller set.
INFO - 2016-06-15 14:45:31 --> Router Class Initialized
INFO - 2016-06-15 14:45:31 --> Output Class Initialized
INFO - 2016-06-15 14:45:31 --> Security Class Initialized
DEBUG - 2016-06-15 14:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:45:31 --> Input Class Initialized
INFO - 2016-06-15 14:45:31 --> Language Class Initialized
INFO - 2016-06-15 14:45:31 --> Loader Class Initialized
INFO - 2016-06-15 14:45:31 --> Helper loaded: form_helper
INFO - 2016-06-15 14:45:31 --> Database Driver Class Initialized
INFO - 2016-06-15 14:45:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:45:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:45:31 --> Email Class Initialized
INFO - 2016-06-15 14:45:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:45:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:45:31 --> Helper loaded: language_helper
INFO - 2016-06-15 14:45:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:45:31 --> Model Class Initialized
INFO - 2016-06-15 14:45:31 --> Helper loaded: date_helper
INFO - 2016-06-15 14:45:31 --> Controller Class Initialized
INFO - 2016-06-15 14:45:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:45:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:45:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:45:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:45:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:45:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:45:31 --> Model Class Initialized
INFO - 2016-06-15 17:45:31 --> Form Validation Class Initialized
INFO - 2016-06-15 17:45:31 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:45:31 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:45:31 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 17:45:31 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:45:31 --> Final output sent to browser
DEBUG - 2016-06-15 17:45:31 --> Total execution time: 0.0936
INFO - 2016-06-15 14:45:33 --> Config Class Initialized
INFO - 2016-06-15 14:45:33 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:45:33 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:45:33 --> Utf8 Class Initialized
INFO - 2016-06-15 14:45:33 --> URI Class Initialized
INFO - 2016-06-15 14:45:33 --> Router Class Initialized
INFO - 2016-06-15 14:45:33 --> Output Class Initialized
INFO - 2016-06-15 14:45:33 --> Security Class Initialized
DEBUG - 2016-06-15 14:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:45:33 --> Input Class Initialized
INFO - 2016-06-15 14:45:33 --> Language Class Initialized
INFO - 2016-06-15 14:45:33 --> Loader Class Initialized
INFO - 2016-06-15 14:45:33 --> Helper loaded: form_helper
INFO - 2016-06-15 14:45:33 --> Database Driver Class Initialized
INFO - 2016-06-15 14:45:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:45:33 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:45:33 --> Email Class Initialized
INFO - 2016-06-15 14:45:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:45:33 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:45:33 --> Helper loaded: language_helper
INFO - 2016-06-15 14:45:33 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:45:33 --> Model Class Initialized
INFO - 2016-06-15 14:45:33 --> Helper loaded: date_helper
INFO - 2016-06-15 14:45:33 --> Controller Class Initialized
INFO - 2016-06-15 14:45:33 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:45:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:45:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:45:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:45:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:45:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:45:33 --> Model Class Initialized
INFO - 2016-06-15 17:45:33 --> Final output sent to browser
DEBUG - 2016-06-15 17:45:33 --> Total execution time: 0.1013
INFO - 2016-06-15 14:45:48 --> Config Class Initialized
INFO - 2016-06-15 14:45:48 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:45:48 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:45:48 --> Utf8 Class Initialized
INFO - 2016-06-15 14:45:48 --> URI Class Initialized
DEBUG - 2016-06-15 14:45:48 --> No URI present. Default controller set.
INFO - 2016-06-15 14:45:48 --> Router Class Initialized
INFO - 2016-06-15 14:45:48 --> Output Class Initialized
INFO - 2016-06-15 14:45:48 --> Security Class Initialized
DEBUG - 2016-06-15 14:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:45:48 --> Input Class Initialized
INFO - 2016-06-15 14:45:48 --> Language Class Initialized
INFO - 2016-06-15 14:45:48 --> Loader Class Initialized
INFO - 2016-06-15 14:45:48 --> Helper loaded: form_helper
INFO - 2016-06-15 14:45:48 --> Database Driver Class Initialized
INFO - 2016-06-15 14:45:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:45:48 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:45:48 --> Email Class Initialized
INFO - 2016-06-15 14:45:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:45:48 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:45:48 --> Helper loaded: language_helper
INFO - 2016-06-15 14:45:48 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:45:48 --> Model Class Initialized
INFO - 2016-06-15 14:45:48 --> Helper loaded: date_helper
INFO - 2016-06-15 14:45:48 --> Controller Class Initialized
INFO - 2016-06-15 14:45:48 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:45:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:45:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:45:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:45:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:45:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:45:48 --> Model Class Initialized
INFO - 2016-06-15 17:45:48 --> Form Validation Class Initialized
INFO - 2016-06-15 17:45:48 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:45:48 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:45:48 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 17:45:48 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:45:48 --> Final output sent to browser
DEBUG - 2016-06-15 17:45:48 --> Total execution time: 0.0950
INFO - 2016-06-15 14:45:50 --> Config Class Initialized
INFO - 2016-06-15 14:45:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:45:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:45:50 --> Utf8 Class Initialized
INFO - 2016-06-15 14:45:50 --> URI Class Initialized
INFO - 2016-06-15 14:45:50 --> Router Class Initialized
INFO - 2016-06-15 14:45:50 --> Output Class Initialized
INFO - 2016-06-15 14:45:50 --> Security Class Initialized
DEBUG - 2016-06-15 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:45:50 --> Input Class Initialized
INFO - 2016-06-15 14:45:50 --> Language Class Initialized
INFO - 2016-06-15 14:45:50 --> Loader Class Initialized
INFO - 2016-06-15 14:45:50 --> Helper loaded: form_helper
INFO - 2016-06-15 14:45:50 --> Database Driver Class Initialized
INFO - 2016-06-15 14:45:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:45:50 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:45:50 --> Email Class Initialized
INFO - 2016-06-15 14:45:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:45:50 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:45:50 --> Helper loaded: language_helper
INFO - 2016-06-15 14:45:50 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:45:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:45:50 --> Model Class Initialized
INFO - 2016-06-15 14:45:50 --> Helper loaded: date_helper
INFO - 2016-06-15 14:45:50 --> Controller Class Initialized
INFO - 2016-06-15 14:45:50 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:45:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:45:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:45:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:45:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:45:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:45:50 --> Model Class Initialized
INFO - 2016-06-15 17:45:50 --> Final output sent to browser
DEBUG - 2016-06-15 17:45:50 --> Total execution time: 0.0960
INFO - 2016-06-15 14:45:50 --> Config Class Initialized
INFO - 2016-06-15 14:45:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:45:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:45:50 --> Utf8 Class Initialized
INFO - 2016-06-15 14:45:50 --> URI Class Initialized
INFO - 2016-06-15 14:45:50 --> Router Class Initialized
INFO - 2016-06-15 14:45:50 --> Output Class Initialized
INFO - 2016-06-15 14:45:50 --> Security Class Initialized
DEBUG - 2016-06-15 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:45:50 --> Input Class Initialized
INFO - 2016-06-15 14:45:50 --> Language Class Initialized
ERROR - 2016-06-15 14:45:50 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 14:46:50 --> Config Class Initialized
INFO - 2016-06-15 14:46:50 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:46:50 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:46:50 --> Utf8 Class Initialized
INFO - 2016-06-15 14:46:50 --> URI Class Initialized
INFO - 2016-06-15 14:46:50 --> Router Class Initialized
INFO - 2016-06-15 14:46:50 --> Output Class Initialized
INFO - 2016-06-15 14:46:50 --> Security Class Initialized
DEBUG - 2016-06-15 14:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:46:50 --> Input Class Initialized
INFO - 2016-06-15 14:46:50 --> Language Class Initialized
INFO - 2016-06-15 14:46:50 --> Loader Class Initialized
INFO - 2016-06-15 14:46:50 --> Helper loaded: form_helper
INFO - 2016-06-15 14:46:50 --> Database Driver Class Initialized
INFO - 2016-06-15 14:46:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:46:50 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:46:50 --> Email Class Initialized
INFO - 2016-06-15 14:46:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:46:50 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:46:50 --> Helper loaded: language_helper
INFO - 2016-06-15 14:46:50 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:46:50 --> Model Class Initialized
INFO - 2016-06-15 14:46:50 --> Helper loaded: date_helper
INFO - 2016-06-15 14:46:50 --> Controller Class Initialized
INFO - 2016-06-15 14:46:50 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:46:50 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:46:50 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:46:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:46:50 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:46:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:46:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-15 17:46:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:46:50 --> Form Validation Class Initialized
DEBUG - 2016-06-15 17:46:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:46:50 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:46:50 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:46:50 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:46:50 --> Final output sent to browser
DEBUG - 2016-06-15 17:46:50 --> Total execution time: 0.0893
INFO - 2016-06-15 14:46:51 --> Config Class Initialized
INFO - 2016-06-15 14:46:51 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:46:51 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:46:51 --> Utf8 Class Initialized
INFO - 2016-06-15 14:46:51 --> URI Class Initialized
INFO - 2016-06-15 14:46:51 --> Router Class Initialized
INFO - 2016-06-15 14:46:51 --> Output Class Initialized
INFO - 2016-06-15 14:46:51 --> Security Class Initialized
DEBUG - 2016-06-15 14:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:46:51 --> Input Class Initialized
INFO - 2016-06-15 14:46:51 --> Language Class Initialized
INFO - 2016-06-15 14:46:51 --> Loader Class Initialized
INFO - 2016-06-15 14:46:51 --> Helper loaded: form_helper
INFO - 2016-06-15 14:46:51 --> Database Driver Class Initialized
INFO - 2016-06-15 14:46:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:46:51 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:46:51 --> Email Class Initialized
INFO - 2016-06-15 14:46:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:46:51 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:46:51 --> Helper loaded: language_helper
INFO - 2016-06-15 14:46:51 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:46:51 --> Model Class Initialized
INFO - 2016-06-15 14:46:51 --> Helper loaded: date_helper
INFO - 2016-06-15 14:46:51 --> Controller Class Initialized
INFO - 2016-06-15 14:46:51 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:46:51 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:46:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:46:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:46:51 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:46:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:46:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:46:51 --> Model Class Initialized
INFO - 2016-06-15 17:46:51 --> Final output sent to browser
DEBUG - 2016-06-15 17:46:51 --> Total execution time: 0.1999
INFO - 2016-06-15 14:47:13 --> Config Class Initialized
INFO - 2016-06-15 14:47:13 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:47:13 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:47:13 --> Utf8 Class Initialized
INFO - 2016-06-15 14:47:13 --> URI Class Initialized
INFO - 2016-06-15 14:47:13 --> Router Class Initialized
INFO - 2016-06-15 14:47:13 --> Output Class Initialized
INFO - 2016-06-15 14:47:13 --> Security Class Initialized
DEBUG - 2016-06-15 14:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:47:13 --> Input Class Initialized
INFO - 2016-06-15 14:47:13 --> Language Class Initialized
INFO - 2016-06-15 14:47:13 --> Loader Class Initialized
INFO - 2016-06-15 14:47:13 --> Helper loaded: form_helper
INFO - 2016-06-15 14:47:13 --> Database Driver Class Initialized
INFO - 2016-06-15 14:47:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:47:13 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:47:13 --> Email Class Initialized
INFO - 2016-06-15 14:47:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:47:13 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:47:13 --> Helper loaded: language_helper
INFO - 2016-06-15 14:47:13 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:13 --> Model Class Initialized
INFO - 2016-06-15 14:47:13 --> Helper loaded: date_helper
INFO - 2016-06-15 14:47:13 --> Controller Class Initialized
INFO - 2016-06-15 14:47:13 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:47:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:47:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:47:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:47:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:47:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 17:47:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:47:13 --> Form Validation Class Initialized
DEBUG - 2016-06-15 17:47:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:13 --> Config Class Initialized
INFO - 2016-06-15 14:47:13 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:47:13 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:47:13 --> Utf8 Class Initialized
INFO - 2016-06-15 14:47:13 --> URI Class Initialized
INFO - 2016-06-15 14:47:13 --> Router Class Initialized
INFO - 2016-06-15 14:47:14 --> Output Class Initialized
INFO - 2016-06-15 14:47:14 --> Security Class Initialized
DEBUG - 2016-06-15 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:47:14 --> Input Class Initialized
INFO - 2016-06-15 14:47:14 --> Language Class Initialized
INFO - 2016-06-15 14:47:14 --> Loader Class Initialized
INFO - 2016-06-15 14:47:14 --> Helper loaded: form_helper
INFO - 2016-06-15 14:47:14 --> Database Driver Class Initialized
INFO - 2016-06-15 14:47:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:47:14 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:47:14 --> Email Class Initialized
INFO - 2016-06-15 14:47:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:47:14 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:47:14 --> Helper loaded: language_helper
INFO - 2016-06-15 14:47:14 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:14 --> Model Class Initialized
INFO - 2016-06-15 14:47:14 --> Helper loaded: date_helper
INFO - 2016-06-15 14:47:14 --> Controller Class Initialized
INFO - 2016-06-15 14:47:14 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:47:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:47:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:47:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:47:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:47:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 17:47:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:47:14 --> Form Validation Class Initialized
DEBUG - 2016-06-15 17:47:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:47:14 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 17:47:14 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 17:47:14 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 17:47:14 --> Final output sent to browser
DEBUG - 2016-06-15 17:47:14 --> Total execution time: 0.0814
INFO - 2016-06-15 14:47:17 --> Config Class Initialized
INFO - 2016-06-15 14:47:17 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:47:17 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:47:17 --> Utf8 Class Initialized
INFO - 2016-06-15 14:47:17 --> URI Class Initialized
INFO - 2016-06-15 14:47:17 --> Router Class Initialized
INFO - 2016-06-15 14:47:17 --> Output Class Initialized
INFO - 2016-06-15 14:47:17 --> Security Class Initialized
DEBUG - 2016-06-15 14:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:47:17 --> Input Class Initialized
INFO - 2016-06-15 14:47:17 --> Language Class Initialized
INFO - 2016-06-15 14:47:17 --> Loader Class Initialized
INFO - 2016-06-15 14:47:17 --> Helper loaded: form_helper
INFO - 2016-06-15 14:47:17 --> Database Driver Class Initialized
INFO - 2016-06-15 14:47:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:47:17 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:47:17 --> Email Class Initialized
INFO - 2016-06-15 14:47:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:47:17 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:47:17 --> Helper loaded: language_helper
INFO - 2016-06-15 14:47:17 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:17 --> Model Class Initialized
INFO - 2016-06-15 14:47:17 --> Helper loaded: date_helper
INFO - 2016-06-15 14:47:17 --> Controller Class Initialized
INFO - 2016-06-15 14:47:17 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:47:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:47:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:47:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:47:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:47:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:47:17 --> Model Class Initialized
INFO - 2016-06-15 17:47:17 --> Final output sent to browser
DEBUG - 2016-06-15 17:47:17 --> Total execution time: 0.0753
INFO - 2016-06-15 14:47:37 --> Config Class Initialized
INFO - 2016-06-15 14:47:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:47:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:47:37 --> Utf8 Class Initialized
INFO - 2016-06-15 14:47:37 --> URI Class Initialized
INFO - 2016-06-15 14:47:37 --> Router Class Initialized
INFO - 2016-06-15 14:47:37 --> Output Class Initialized
INFO - 2016-06-15 14:47:37 --> Security Class Initialized
DEBUG - 2016-06-15 14:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:47:37 --> Input Class Initialized
INFO - 2016-06-15 14:47:37 --> Language Class Initialized
INFO - 2016-06-15 14:47:37 --> Loader Class Initialized
INFO - 2016-06-15 14:47:37 --> Helper loaded: form_helper
INFO - 2016-06-15 14:47:37 --> Database Driver Class Initialized
INFO - 2016-06-15 14:47:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:47:37 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:47:37 --> Email Class Initialized
INFO - 2016-06-15 14:47:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:47:37 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:47:37 --> Helper loaded: language_helper
INFO - 2016-06-15 14:47:37 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:37 --> Model Class Initialized
INFO - 2016-06-15 14:47:37 --> Helper loaded: date_helper
INFO - 2016-06-15 14:47:37 --> Controller Class Initialized
INFO - 2016-06-15 14:47:37 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:47:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:47:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:47:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:47:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:47:37 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 17:47:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:47:37 --> Form Validation Class Initialized
DEBUG - 2016-06-15 17:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:38 --> Config Class Initialized
INFO - 2016-06-15 14:47:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:47:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:47:38 --> Utf8 Class Initialized
INFO - 2016-06-15 14:47:38 --> URI Class Initialized
DEBUG - 2016-06-15 14:47:38 --> No URI present. Default controller set.
INFO - 2016-06-15 14:47:38 --> Router Class Initialized
INFO - 2016-06-15 14:47:38 --> Output Class Initialized
INFO - 2016-06-15 14:47:38 --> Security Class Initialized
DEBUG - 2016-06-15 14:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:47:38 --> Input Class Initialized
INFO - 2016-06-15 14:47:38 --> Language Class Initialized
INFO - 2016-06-15 14:47:38 --> Loader Class Initialized
INFO - 2016-06-15 14:47:38 --> Helper loaded: form_helper
INFO - 2016-06-15 14:47:38 --> Database Driver Class Initialized
INFO - 2016-06-15 14:47:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:47:38 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:47:38 --> Email Class Initialized
INFO - 2016-06-15 14:47:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:47:38 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:47:38 --> Helper loaded: language_helper
INFO - 2016-06-15 14:47:38 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:38 --> Model Class Initialized
INFO - 2016-06-15 14:47:38 --> Helper loaded: date_helper
INFO - 2016-06-15 14:47:38 --> Controller Class Initialized
INFO - 2016-06-15 14:47:38 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:47:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:47:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:47:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:47:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:47:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 14:47:41 --> Config Class Initialized
INFO - 2016-06-15 14:47:41 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:47:41 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:47:41 --> Utf8 Class Initialized
INFO - 2016-06-15 14:47:41 --> URI Class Initialized
INFO - 2016-06-15 14:47:41 --> Router Class Initialized
INFO - 2016-06-15 14:47:41 --> Output Class Initialized
INFO - 2016-06-15 14:47:41 --> Security Class Initialized
DEBUG - 2016-06-15 14:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:47:41 --> Input Class Initialized
INFO - 2016-06-15 14:47:41 --> Language Class Initialized
INFO - 2016-06-15 14:47:41 --> Loader Class Initialized
INFO - 2016-06-15 14:47:41 --> Helper loaded: form_helper
INFO - 2016-06-15 14:47:41 --> Database Driver Class Initialized
INFO - 2016-06-15 14:47:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:47:41 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:47:41 --> Email Class Initialized
INFO - 2016-06-15 14:47:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:47:41 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:47:41 --> Helper loaded: language_helper
INFO - 2016-06-15 14:47:41 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:41 --> Model Class Initialized
INFO - 2016-06-15 14:47:41 --> Helper loaded: date_helper
INFO - 2016-06-15 14:47:41 --> Controller Class Initialized
INFO - 2016-06-15 14:47:41 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:47:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:47:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:47:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:47:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:47:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:47:41 --> Model Class Initialized
INFO - 2016-06-15 17:47:41 --> Form Validation Class Initialized
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:47:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:47:41 --> Final output sent to browser
DEBUG - 2016-06-15 17:47:41 --> Total execution time: 0.1050
INFO - 2016-06-15 14:47:44 --> Config Class Initialized
INFO - 2016-06-15 14:47:44 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:47:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:47:44 --> Utf8 Class Initialized
INFO - 2016-06-15 14:47:44 --> URI Class Initialized
INFO - 2016-06-15 14:47:44 --> Router Class Initialized
INFO - 2016-06-15 14:47:44 --> Output Class Initialized
INFO - 2016-06-15 14:47:44 --> Security Class Initialized
DEBUG - 2016-06-15 14:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:47:44 --> Input Class Initialized
INFO - 2016-06-15 14:47:44 --> Language Class Initialized
INFO - 2016-06-15 14:47:44 --> Loader Class Initialized
INFO - 2016-06-15 14:47:44 --> Helper loaded: form_helper
INFO - 2016-06-15 14:47:44 --> Database Driver Class Initialized
INFO - 2016-06-15 14:47:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:47:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:47:44 --> Email Class Initialized
INFO - 2016-06-15 14:47:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:47:44 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:47:44 --> Helper loaded: language_helper
INFO - 2016-06-15 14:47:44 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:47:44 --> Model Class Initialized
INFO - 2016-06-15 14:47:44 --> Helper loaded: date_helper
INFO - 2016-06-15 14:47:44 --> Controller Class Initialized
INFO - 2016-06-15 14:47:44 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:47:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 14:47:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 14:47:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 14:47:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 14:47:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 17:47:44 --> Model Class Initialized
INFO - 2016-06-15 17:47:44 --> Form Validation Class Initialized
INFO - 2016-06-15 17:47:44 --> Final output sent to browser
DEBUG - 2016-06-15 17:47:44 --> Total execution time: 0.0809
INFO - 2016-06-15 14:49:21 --> Config Class Initialized
INFO - 2016-06-15 14:49:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:49:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:49:21 --> Utf8 Class Initialized
INFO - 2016-06-15 14:49:21 --> URI Class Initialized
INFO - 2016-06-15 14:49:21 --> Router Class Initialized
INFO - 2016-06-15 14:49:21 --> Output Class Initialized
INFO - 2016-06-15 14:49:21 --> Security Class Initialized
DEBUG - 2016-06-15 14:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:49:21 --> Input Class Initialized
INFO - 2016-06-15 14:49:21 --> Language Class Initialized
INFO - 2016-06-15 14:49:21 --> Loader Class Initialized
INFO - 2016-06-15 14:49:21 --> Helper loaded: form_helper
INFO - 2016-06-15 14:49:21 --> Database Driver Class Initialized
INFO - 2016-06-15 14:49:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:49:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:49:21 --> Email Class Initialized
INFO - 2016-06-15 14:49:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:49:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:49:21 --> Helper loaded: language_helper
INFO - 2016-06-15 14:49:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:49:22 --> Model Class Initialized
INFO - 2016-06-15 14:49:22 --> Helper loaded: date_helper
INFO - 2016-06-15 14:49:22 --> Controller Class Initialized
INFO - 2016-06-15 14:49:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:49:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:49:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:49:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:49:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:49:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:49:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-15 17:49:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:49:22 --> Form Validation Class Initialized
DEBUG - 2016-06-15 17:49:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:49:23 --> Config Class Initialized
INFO - 2016-06-15 14:49:23 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:49:23 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:49:23 --> Utf8 Class Initialized
INFO - 2016-06-15 14:49:23 --> URI Class Initialized
DEBUG - 2016-06-15 14:49:23 --> No URI present. Default controller set.
INFO - 2016-06-15 14:49:23 --> Router Class Initialized
INFO - 2016-06-15 14:49:23 --> Output Class Initialized
INFO - 2016-06-15 14:49:23 --> Security Class Initialized
DEBUG - 2016-06-15 14:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:49:23 --> Input Class Initialized
INFO - 2016-06-15 14:49:23 --> Language Class Initialized
INFO - 2016-06-15 14:49:23 --> Loader Class Initialized
INFO - 2016-06-15 14:49:23 --> Helper loaded: form_helper
INFO - 2016-06-15 14:49:23 --> Database Driver Class Initialized
INFO - 2016-06-15 14:49:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:49:23 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:49:23 --> Email Class Initialized
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:49:23 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:49:23 --> Helper loaded: language_helper
INFO - 2016-06-15 14:49:23 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:49:23 --> Model Class Initialized
INFO - 2016-06-15 14:49:23 --> Helper loaded: date_helper
INFO - 2016-06-15 14:49:23 --> Controller Class Initialized
INFO - 2016-06-15 14:49:23 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 14:49:23 --> Config Class Initialized
INFO - 2016-06-15 14:49:23 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:49:23 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:49:23 --> Utf8 Class Initialized
INFO - 2016-06-15 14:49:23 --> URI Class Initialized
INFO - 2016-06-15 14:49:23 --> Router Class Initialized
INFO - 2016-06-15 14:49:23 --> Output Class Initialized
INFO - 2016-06-15 14:49:23 --> Security Class Initialized
DEBUG - 2016-06-15 14:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:49:23 --> Input Class Initialized
INFO - 2016-06-15 14:49:23 --> Language Class Initialized
INFO - 2016-06-15 14:49:23 --> Loader Class Initialized
INFO - 2016-06-15 14:49:23 --> Helper loaded: form_helper
INFO - 2016-06-15 14:49:23 --> Database Driver Class Initialized
INFO - 2016-06-15 14:49:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:49:23 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:49:23 --> Email Class Initialized
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:49:23 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:49:23 --> Helper loaded: language_helper
INFO - 2016-06-15 14:49:23 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:49:23 --> Model Class Initialized
INFO - 2016-06-15 14:49:23 --> Helper loaded: date_helper
INFO - 2016-06-15 14:49:23 --> Controller Class Initialized
INFO - 2016-06-15 14:49:23 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:49:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:49:23 --> Model Class Initialized
INFO - 2016-06-15 17:49:23 --> Form Validation Class Initialized
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:49:23 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:49:23 --> Final output sent to browser
DEBUG - 2016-06-15 17:49:23 --> Total execution time: 0.1088
INFO - 2016-06-15 14:49:24 --> Config Class Initialized
INFO - 2016-06-15 14:49:24 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:49:24 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:49:24 --> Utf8 Class Initialized
INFO - 2016-06-15 14:49:24 --> URI Class Initialized
INFO - 2016-06-15 14:49:24 --> Router Class Initialized
INFO - 2016-06-15 14:49:24 --> Output Class Initialized
INFO - 2016-06-15 14:49:24 --> Security Class Initialized
DEBUG - 2016-06-15 14:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:49:24 --> Input Class Initialized
INFO - 2016-06-15 14:49:24 --> Language Class Initialized
INFO - 2016-06-15 14:49:24 --> Loader Class Initialized
INFO - 2016-06-15 14:49:24 --> Helper loaded: form_helper
INFO - 2016-06-15 14:49:24 --> Database Driver Class Initialized
INFO - 2016-06-15 14:49:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:49:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:49:24 --> Email Class Initialized
INFO - 2016-06-15 14:49:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:49:24 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:49:24 --> Helper loaded: language_helper
INFO - 2016-06-15 14:49:24 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:49:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:49:24 --> Model Class Initialized
INFO - 2016-06-15 14:49:24 --> Helper loaded: date_helper
INFO - 2016-06-15 14:49:24 --> Controller Class Initialized
INFO - 2016-06-15 14:49:24 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:49:24 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:49:24 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:49:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:49:24 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:49:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:49:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:49:24 --> Model Class Initialized
INFO - 2016-06-15 17:49:24 --> Form Validation Class Initialized
INFO - 2016-06-15 17:49:24 --> Final output sent to browser
DEBUG - 2016-06-15 17:49:24 --> Total execution time: 0.0965
INFO - 2016-06-15 14:53:00 --> Config Class Initialized
INFO - 2016-06-15 14:53:00 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:53:00 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:53:00 --> Utf8 Class Initialized
INFO - 2016-06-15 14:53:00 --> URI Class Initialized
INFO - 2016-06-15 14:53:00 --> Router Class Initialized
INFO - 2016-06-15 14:53:00 --> Output Class Initialized
INFO - 2016-06-15 14:53:00 --> Security Class Initialized
DEBUG - 2016-06-15 14:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:53:00 --> Input Class Initialized
INFO - 2016-06-15 14:53:00 --> Language Class Initialized
INFO - 2016-06-15 14:53:00 --> Loader Class Initialized
INFO - 2016-06-15 14:53:00 --> Helper loaded: form_helper
INFO - 2016-06-15 14:53:00 --> Database Driver Class Initialized
INFO - 2016-06-15 14:53:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:53:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:53:00 --> Email Class Initialized
INFO - 2016-06-15 14:53:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:53:00 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:53:00 --> Helper loaded: language_helper
INFO - 2016-06-15 14:53:00 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:53:00 --> Model Class Initialized
INFO - 2016-06-15 14:53:00 --> Helper loaded: date_helper
INFO - 2016-06-15 14:53:00 --> Controller Class Initialized
INFO - 2016-06-15 14:53:00 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:53:00 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:53:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:53:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:53:00 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:53:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:53:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:53:00 --> Model Class Initialized
INFO - 2016-06-15 17:53:00 --> Form Validation Class Initialized
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:53:00 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:53:00 --> Final output sent to browser
DEBUG - 2016-06-15 17:53:00 --> Total execution time: 0.1329
INFO - 2016-06-15 14:53:01 --> Config Class Initialized
INFO - 2016-06-15 14:53:01 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:53:01 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:53:01 --> Utf8 Class Initialized
INFO - 2016-06-15 14:53:01 --> URI Class Initialized
INFO - 2016-06-15 14:53:01 --> Router Class Initialized
INFO - 2016-06-15 14:53:01 --> Output Class Initialized
INFO - 2016-06-15 14:53:01 --> Security Class Initialized
DEBUG - 2016-06-15 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:53:01 --> Input Class Initialized
INFO - 2016-06-15 14:53:01 --> Language Class Initialized
INFO - 2016-06-15 14:53:01 --> Loader Class Initialized
INFO - 2016-06-15 14:53:01 --> Helper loaded: form_helper
INFO - 2016-06-15 14:53:01 --> Database Driver Class Initialized
INFO - 2016-06-15 14:53:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:53:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:53:01 --> Email Class Initialized
INFO - 2016-06-15 14:53:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:53:01 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:53:01 --> Helper loaded: language_helper
INFO - 2016-06-15 14:53:01 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:53:01 --> Model Class Initialized
INFO - 2016-06-15 14:53:01 --> Helper loaded: date_helper
INFO - 2016-06-15 14:53:01 --> Controller Class Initialized
INFO - 2016-06-15 14:53:01 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:53:01 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:53:01 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:53:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:53:01 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:53:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:53:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:53:01 --> Model Class Initialized
INFO - 2016-06-15 17:53:01 --> Form Validation Class Initialized
INFO - 2016-06-15 17:53:01 --> Final output sent to browser
DEBUG - 2016-06-15 17:53:01 --> Total execution time: 0.1001
INFO - 2016-06-15 14:55:20 --> Config Class Initialized
INFO - 2016-06-15 14:55:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:55:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:55:20 --> Utf8 Class Initialized
INFO - 2016-06-15 14:55:20 --> URI Class Initialized
INFO - 2016-06-15 14:55:20 --> Router Class Initialized
INFO - 2016-06-15 14:55:20 --> Output Class Initialized
INFO - 2016-06-15 14:55:20 --> Security Class Initialized
DEBUG - 2016-06-15 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:55:20 --> Input Class Initialized
INFO - 2016-06-15 14:55:20 --> Language Class Initialized
INFO - 2016-06-15 14:55:20 --> Loader Class Initialized
INFO - 2016-06-15 14:55:20 --> Helper loaded: form_helper
INFO - 2016-06-15 14:55:20 --> Database Driver Class Initialized
INFO - 2016-06-15 14:55:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:55:20 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:55:20 --> Email Class Initialized
INFO - 2016-06-15 14:55:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:55:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:55:20 --> Helper loaded: language_helper
INFO - 2016-06-15 14:55:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:55:20 --> Model Class Initialized
INFO - 2016-06-15 14:55:20 --> Helper loaded: date_helper
INFO - 2016-06-15 14:55:20 --> Controller Class Initialized
INFO - 2016-06-15 14:55:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:55:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:55:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:55:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:55:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:55:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:55:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:55:20 --> Model Class Initialized
INFO - 2016-06-15 17:55:20 --> Form Validation Class Initialized
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:55:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:55:20 --> Final output sent to browser
DEBUG - 2016-06-15 17:55:20 --> Total execution time: 0.1020
INFO - 2016-06-15 14:55:22 --> Config Class Initialized
INFO - 2016-06-15 14:55:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:55:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:55:22 --> Utf8 Class Initialized
INFO - 2016-06-15 14:55:22 --> URI Class Initialized
INFO - 2016-06-15 14:55:22 --> Router Class Initialized
INFO - 2016-06-15 14:55:22 --> Output Class Initialized
INFO - 2016-06-15 14:55:22 --> Security Class Initialized
DEBUG - 2016-06-15 14:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:55:22 --> Input Class Initialized
INFO - 2016-06-15 14:55:22 --> Language Class Initialized
INFO - 2016-06-15 14:55:22 --> Loader Class Initialized
INFO - 2016-06-15 14:55:22 --> Helper loaded: form_helper
INFO - 2016-06-15 14:55:22 --> Database Driver Class Initialized
INFO - 2016-06-15 14:55:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:55:22 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:55:22 --> Email Class Initialized
INFO - 2016-06-15 14:55:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:55:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:55:22 --> Helper loaded: language_helper
INFO - 2016-06-15 14:55:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:55:22 --> Model Class Initialized
INFO - 2016-06-15 14:55:22 --> Helper loaded: date_helper
INFO - 2016-06-15 14:55:22 --> Controller Class Initialized
INFO - 2016-06-15 14:55:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:55:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:55:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:55:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:55:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:55:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:55:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:55:22 --> Model Class Initialized
INFO - 2016-06-15 17:55:22 --> Form Validation Class Initialized
INFO - 2016-06-15 17:55:22 --> Final output sent to browser
DEBUG - 2016-06-15 17:55:22 --> Total execution time: 0.0780
INFO - 2016-06-15 14:55:40 --> Config Class Initialized
INFO - 2016-06-15 14:55:40 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:55:40 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:55:40 --> Utf8 Class Initialized
INFO - 2016-06-15 14:55:40 --> URI Class Initialized
INFO - 2016-06-15 14:55:40 --> Router Class Initialized
INFO - 2016-06-15 14:55:40 --> Output Class Initialized
INFO - 2016-06-15 14:55:40 --> Security Class Initialized
DEBUG - 2016-06-15 14:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:55:40 --> Input Class Initialized
INFO - 2016-06-15 14:55:40 --> Language Class Initialized
INFO - 2016-06-15 14:55:40 --> Loader Class Initialized
INFO - 2016-06-15 14:55:40 --> Helper loaded: form_helper
INFO - 2016-06-15 14:55:40 --> Database Driver Class Initialized
INFO - 2016-06-15 14:55:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:55:40 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:55:40 --> Email Class Initialized
INFO - 2016-06-15 14:55:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:55:40 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:55:40 --> Helper loaded: language_helper
INFO - 2016-06-15 14:55:40 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:55:40 --> Model Class Initialized
INFO - 2016-06-15 14:55:40 --> Helper loaded: date_helper
INFO - 2016-06-15 14:55:40 --> Controller Class Initialized
INFO - 2016-06-15 14:55:40 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:55:40 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:55:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:55:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:55:40 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:55:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:55:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:55:40 --> Model Class Initialized
INFO - 2016-06-15 17:55:40 --> Form Validation Class Initialized
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:55:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:55:40 --> Final output sent to browser
DEBUG - 2016-06-15 17:55:40 --> Total execution time: 0.1305
INFO - 2016-06-15 14:55:42 --> Config Class Initialized
INFO - 2016-06-15 14:55:42 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:55:42 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:55:42 --> Utf8 Class Initialized
INFO - 2016-06-15 14:55:42 --> URI Class Initialized
INFO - 2016-06-15 14:55:42 --> Router Class Initialized
INFO - 2016-06-15 14:55:42 --> Output Class Initialized
INFO - 2016-06-15 14:55:42 --> Security Class Initialized
DEBUG - 2016-06-15 14:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:55:42 --> Input Class Initialized
INFO - 2016-06-15 14:55:42 --> Language Class Initialized
INFO - 2016-06-15 14:55:42 --> Loader Class Initialized
INFO - 2016-06-15 14:55:42 --> Helper loaded: form_helper
INFO - 2016-06-15 14:55:42 --> Database Driver Class Initialized
INFO - 2016-06-15 14:55:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:55:42 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:55:42 --> Email Class Initialized
INFO - 2016-06-15 14:55:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:55:42 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:55:42 --> Helper loaded: language_helper
INFO - 2016-06-15 14:55:42 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:55:42 --> Model Class Initialized
INFO - 2016-06-15 14:55:42 --> Helper loaded: date_helper
INFO - 2016-06-15 14:55:42 --> Controller Class Initialized
INFO - 2016-06-15 14:55:42 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:55:42 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:55:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:55:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:55:42 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:55:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:55:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:55:42 --> Model Class Initialized
INFO - 2016-06-15 17:55:42 --> Form Validation Class Initialized
INFO - 2016-06-15 17:55:42 --> Final output sent to browser
DEBUG - 2016-06-15 17:55:42 --> Total execution time: 0.1064
INFO - 2016-06-15 14:57:26 --> Config Class Initialized
INFO - 2016-06-15 14:57:26 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:57:26 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:57:26 --> Utf8 Class Initialized
INFO - 2016-06-15 14:57:26 --> URI Class Initialized
INFO - 2016-06-15 14:57:26 --> Router Class Initialized
INFO - 2016-06-15 14:57:26 --> Output Class Initialized
INFO - 2016-06-15 14:57:26 --> Security Class Initialized
DEBUG - 2016-06-15 14:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:57:26 --> Input Class Initialized
INFO - 2016-06-15 14:57:26 --> Language Class Initialized
INFO - 2016-06-15 14:57:26 --> Loader Class Initialized
INFO - 2016-06-15 14:57:26 --> Helper loaded: form_helper
INFO - 2016-06-15 14:57:26 --> Database Driver Class Initialized
INFO - 2016-06-15 14:57:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:57:26 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:57:26 --> Email Class Initialized
INFO - 2016-06-15 14:57:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:57:26 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:57:26 --> Helper loaded: language_helper
INFO - 2016-06-15 14:57:26 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:57:26 --> Model Class Initialized
INFO - 2016-06-15 14:57:26 --> Helper loaded: date_helper
INFO - 2016-06-15 14:57:26 --> Controller Class Initialized
INFO - 2016-06-15 14:57:26 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:57:26 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:57:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:57:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:57:26 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:57:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:57:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:57:26 --> Model Class Initialized
INFO - 2016-06-15 17:57:26 --> Form Validation Class Initialized
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:57:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:57:26 --> Final output sent to browser
DEBUG - 2016-06-15 17:57:26 --> Total execution time: 0.1069
INFO - 2016-06-15 14:57:27 --> Config Class Initialized
INFO - 2016-06-15 14:57:27 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:57:27 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:57:27 --> Utf8 Class Initialized
INFO - 2016-06-15 14:57:27 --> URI Class Initialized
INFO - 2016-06-15 14:57:27 --> Router Class Initialized
INFO - 2016-06-15 14:57:27 --> Output Class Initialized
INFO - 2016-06-15 14:57:27 --> Security Class Initialized
DEBUG - 2016-06-15 14:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:57:27 --> Input Class Initialized
INFO - 2016-06-15 14:57:27 --> Language Class Initialized
INFO - 2016-06-15 14:57:27 --> Loader Class Initialized
INFO - 2016-06-15 14:57:27 --> Helper loaded: form_helper
INFO - 2016-06-15 14:57:27 --> Database Driver Class Initialized
INFO - 2016-06-15 14:57:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:57:27 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:57:27 --> Email Class Initialized
INFO - 2016-06-15 14:57:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:57:27 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:57:27 --> Helper loaded: language_helper
INFO - 2016-06-15 14:57:27 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:57:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:57:27 --> Model Class Initialized
INFO - 2016-06-15 14:57:27 --> Helper loaded: date_helper
INFO - 2016-06-15 14:57:27 --> Controller Class Initialized
INFO - 2016-06-15 14:57:27 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:57:27 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:57:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:57:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:57:27 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:57:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:57:27 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:57:27 --> Model Class Initialized
INFO - 2016-06-15 17:57:27 --> Form Validation Class Initialized
INFO - 2016-06-15 17:57:28 --> Final output sent to browser
DEBUG - 2016-06-15 17:57:28 --> Total execution time: 0.0820
INFO - 2016-06-15 14:58:44 --> Config Class Initialized
INFO - 2016-06-15 14:58:44 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:58:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:58:44 --> Utf8 Class Initialized
INFO - 2016-06-15 14:58:44 --> URI Class Initialized
INFO - 2016-06-15 14:58:44 --> Router Class Initialized
INFO - 2016-06-15 14:58:44 --> Output Class Initialized
INFO - 2016-06-15 14:58:44 --> Security Class Initialized
DEBUG - 2016-06-15 14:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:58:44 --> Input Class Initialized
INFO - 2016-06-15 14:58:44 --> Language Class Initialized
INFO - 2016-06-15 14:58:44 --> Loader Class Initialized
INFO - 2016-06-15 14:58:44 --> Helper loaded: form_helper
INFO - 2016-06-15 14:58:44 --> Database Driver Class Initialized
INFO - 2016-06-15 14:58:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:58:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:58:44 --> Email Class Initialized
INFO - 2016-06-15 14:58:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:58:44 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:58:44 --> Helper loaded: language_helper
INFO - 2016-06-15 14:58:44 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:58:44 --> Model Class Initialized
INFO - 2016-06-15 14:58:44 --> Helper loaded: date_helper
INFO - 2016-06-15 14:58:44 --> Controller Class Initialized
INFO - 2016-06-15 14:58:44 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:58:44 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:58:44 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:58:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:58:44 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:58:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:58:44 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:58:44 --> Model Class Initialized
INFO - 2016-06-15 17:58:44 --> Form Validation Class Initialized
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:58:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:58:44 --> Final output sent to browser
DEBUG - 2016-06-15 17:58:44 --> Total execution time: 0.1080
INFO - 2016-06-15 14:58:46 --> Config Class Initialized
INFO - 2016-06-15 14:58:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:58:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:58:46 --> Utf8 Class Initialized
INFO - 2016-06-15 14:58:46 --> URI Class Initialized
INFO - 2016-06-15 14:58:46 --> Router Class Initialized
INFO - 2016-06-15 14:58:46 --> Output Class Initialized
INFO - 2016-06-15 14:58:46 --> Security Class Initialized
DEBUG - 2016-06-15 14:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:58:46 --> Input Class Initialized
INFO - 2016-06-15 14:58:46 --> Language Class Initialized
INFO - 2016-06-15 14:58:46 --> Loader Class Initialized
INFO - 2016-06-15 14:58:46 --> Helper loaded: form_helper
INFO - 2016-06-15 14:58:46 --> Database Driver Class Initialized
INFO - 2016-06-15 14:58:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:58:46 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:58:46 --> Email Class Initialized
INFO - 2016-06-15 14:58:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:58:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:58:46 --> Helper loaded: language_helper
INFO - 2016-06-15 14:58:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:58:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:58:46 --> Model Class Initialized
INFO - 2016-06-15 14:58:46 --> Helper loaded: date_helper
INFO - 2016-06-15 14:58:46 --> Controller Class Initialized
INFO - 2016-06-15 14:58:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:58:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:58:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:58:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:58:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:58:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:58:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:58:46 --> Model Class Initialized
INFO - 2016-06-15 17:58:46 --> Form Validation Class Initialized
INFO - 2016-06-15 17:58:46 --> Final output sent to browser
DEBUG - 2016-06-15 17:58:46 --> Total execution time: 0.0932
INFO - 2016-06-15 14:59:11 --> Config Class Initialized
INFO - 2016-06-15 14:59:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:59:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:59:11 --> Utf8 Class Initialized
INFO - 2016-06-15 14:59:11 --> URI Class Initialized
INFO - 2016-06-15 14:59:11 --> Router Class Initialized
INFO - 2016-06-15 14:59:11 --> Output Class Initialized
INFO - 2016-06-15 14:59:11 --> Security Class Initialized
DEBUG - 2016-06-15 14:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:59:11 --> Input Class Initialized
INFO - 2016-06-15 14:59:11 --> Language Class Initialized
INFO - 2016-06-15 14:59:11 --> Loader Class Initialized
INFO - 2016-06-15 14:59:11 --> Helper loaded: form_helper
INFO - 2016-06-15 14:59:11 --> Database Driver Class Initialized
INFO - 2016-06-15 14:59:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:59:11 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:59:11 --> Email Class Initialized
INFO - 2016-06-15 14:59:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:59:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:59:11 --> Helper loaded: language_helper
INFO - 2016-06-15 14:59:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:59:11 --> Model Class Initialized
INFO - 2016-06-15 14:59:11 --> Helper loaded: date_helper
INFO - 2016-06-15 14:59:11 --> Controller Class Initialized
INFO - 2016-06-15 14:59:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:59:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:59:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:59:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:59:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:59:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:59:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:59:11 --> Model Class Initialized
INFO - 2016-06-15 17:59:11 --> Form Validation Class Initialized
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 17:59:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 17:59:12 --> Final output sent to browser
DEBUG - 2016-06-15 17:59:12 --> Total execution time: 0.1062
INFO - 2016-06-15 14:59:13 --> Config Class Initialized
INFO - 2016-06-15 14:59:13 --> Hooks Class Initialized
DEBUG - 2016-06-15 14:59:13 --> UTF-8 Support Enabled
INFO - 2016-06-15 14:59:13 --> Utf8 Class Initialized
INFO - 2016-06-15 14:59:13 --> URI Class Initialized
INFO - 2016-06-15 14:59:13 --> Router Class Initialized
INFO - 2016-06-15 14:59:13 --> Output Class Initialized
INFO - 2016-06-15 14:59:13 --> Security Class Initialized
DEBUG - 2016-06-15 14:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 14:59:13 --> Input Class Initialized
INFO - 2016-06-15 14:59:13 --> Language Class Initialized
INFO - 2016-06-15 14:59:13 --> Loader Class Initialized
INFO - 2016-06-15 14:59:13 --> Helper loaded: form_helper
INFO - 2016-06-15 14:59:13 --> Database Driver Class Initialized
INFO - 2016-06-15 14:59:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 14:59:13 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 14:59:13 --> Email Class Initialized
INFO - 2016-06-15 14:59:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 14:59:13 --> Helper loaded: cookie_helper
INFO - 2016-06-15 14:59:13 --> Helper loaded: language_helper
INFO - 2016-06-15 14:59:13 --> Helper loaded: url_helper
DEBUG - 2016-06-15 14:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 14:59:13 --> Model Class Initialized
INFO - 2016-06-15 14:59:13 --> Helper loaded: date_helper
INFO - 2016-06-15 14:59:13 --> Controller Class Initialized
INFO - 2016-06-15 14:59:13 --> Helper loaded: languages_helper
INFO - 2016-06-15 14:59:13 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 14:59:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 14:59:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 14:59:13 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 14:59:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 14:59:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 17:59:13 --> Model Class Initialized
INFO - 2016-06-15 17:59:13 --> Form Validation Class Initialized
INFO - 2016-06-15 17:59:13 --> Final output sent to browser
DEBUG - 2016-06-15 17:59:13 --> Total execution time: 0.0841
INFO - 2016-06-15 15:01:34 --> Config Class Initialized
INFO - 2016-06-15 15:01:34 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:01:34 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:01:34 --> Utf8 Class Initialized
INFO - 2016-06-15 15:01:34 --> URI Class Initialized
INFO - 2016-06-15 15:01:34 --> Router Class Initialized
INFO - 2016-06-15 15:01:34 --> Output Class Initialized
INFO - 2016-06-15 15:01:34 --> Security Class Initialized
DEBUG - 2016-06-15 15:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:01:34 --> Input Class Initialized
INFO - 2016-06-15 15:01:34 --> Language Class Initialized
INFO - 2016-06-15 15:01:34 --> Loader Class Initialized
INFO - 2016-06-15 15:01:34 --> Helper loaded: form_helper
INFO - 2016-06-15 15:01:34 --> Database Driver Class Initialized
INFO - 2016-06-15 15:01:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:01:34 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:01:34 --> Email Class Initialized
INFO - 2016-06-15 15:01:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:01:34 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:01:34 --> Helper loaded: language_helper
INFO - 2016-06-15 15:01:34 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:01:34 --> Model Class Initialized
INFO - 2016-06-15 15:01:34 --> Helper loaded: date_helper
INFO - 2016-06-15 15:01:34 --> Controller Class Initialized
INFO - 2016-06-15 15:01:34 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:01:34 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:01:34 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:01:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:01:34 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:01:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:01:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:01:34 --> Model Class Initialized
INFO - 2016-06-15 18:01:34 --> Form Validation Class Initialized
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:01:34 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:01:34 --> Final output sent to browser
DEBUG - 2016-06-15 18:01:34 --> Total execution time: 0.1233
INFO - 2016-06-15 15:01:36 --> Config Class Initialized
INFO - 2016-06-15 15:01:36 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:01:36 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:01:36 --> Utf8 Class Initialized
INFO - 2016-06-15 15:01:36 --> URI Class Initialized
INFO - 2016-06-15 15:01:36 --> Router Class Initialized
INFO - 2016-06-15 15:01:36 --> Output Class Initialized
INFO - 2016-06-15 15:01:36 --> Security Class Initialized
DEBUG - 2016-06-15 15:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:01:36 --> Input Class Initialized
INFO - 2016-06-15 15:01:36 --> Language Class Initialized
INFO - 2016-06-15 15:01:36 --> Loader Class Initialized
INFO - 2016-06-15 15:01:36 --> Helper loaded: form_helper
INFO - 2016-06-15 15:01:36 --> Database Driver Class Initialized
INFO - 2016-06-15 15:01:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:01:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:01:36 --> Email Class Initialized
INFO - 2016-06-15 15:01:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:01:36 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:01:36 --> Helper loaded: language_helper
INFO - 2016-06-15 15:01:36 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:01:36 --> Model Class Initialized
INFO - 2016-06-15 15:01:36 --> Helper loaded: date_helper
INFO - 2016-06-15 15:01:36 --> Controller Class Initialized
INFO - 2016-06-15 15:01:36 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:01:36 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:01:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:01:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:01:36 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:01:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:01:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:01:36 --> Model Class Initialized
INFO - 2016-06-15 18:01:36 --> Form Validation Class Initialized
INFO - 2016-06-15 18:01:36 --> Final output sent to browser
DEBUG - 2016-06-15 18:01:36 --> Total execution time: 0.0973
INFO - 2016-06-15 15:01:46 --> Config Class Initialized
INFO - 2016-06-15 15:01:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:01:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:01:46 --> Utf8 Class Initialized
INFO - 2016-06-15 15:01:46 --> URI Class Initialized
INFO - 2016-06-15 15:01:46 --> Router Class Initialized
INFO - 2016-06-15 15:01:46 --> Output Class Initialized
INFO - 2016-06-15 15:01:46 --> Security Class Initialized
DEBUG - 2016-06-15 15:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:01:46 --> Input Class Initialized
INFO - 2016-06-15 15:01:46 --> Language Class Initialized
INFO - 2016-06-15 15:01:46 --> Loader Class Initialized
INFO - 2016-06-15 15:01:46 --> Helper loaded: form_helper
INFO - 2016-06-15 15:01:46 --> Database Driver Class Initialized
INFO - 2016-06-15 15:01:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:01:46 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:01:46 --> Email Class Initialized
INFO - 2016-06-15 15:01:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:01:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:01:46 --> Helper loaded: language_helper
INFO - 2016-06-15 15:01:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:01:46 --> Model Class Initialized
INFO - 2016-06-15 15:01:46 --> Helper loaded: date_helper
INFO - 2016-06-15 15:01:46 --> Controller Class Initialized
INFO - 2016-06-15 15:01:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:01:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:01:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:01:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:01:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:01:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:01:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:01:46 --> Model Class Initialized
INFO - 2016-06-15 18:01:46 --> Form Validation Class Initialized
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:01:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:01:46 --> Final output sent to browser
DEBUG - 2016-06-15 18:01:46 --> Total execution time: 0.1044
INFO - 2016-06-15 15:01:47 --> Config Class Initialized
INFO - 2016-06-15 15:01:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:01:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:01:47 --> Utf8 Class Initialized
INFO - 2016-06-15 15:01:47 --> URI Class Initialized
INFO - 2016-06-15 15:01:47 --> Router Class Initialized
INFO - 2016-06-15 15:01:47 --> Output Class Initialized
INFO - 2016-06-15 15:01:47 --> Security Class Initialized
DEBUG - 2016-06-15 15:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:01:47 --> Input Class Initialized
INFO - 2016-06-15 15:01:47 --> Language Class Initialized
INFO - 2016-06-15 15:01:47 --> Loader Class Initialized
INFO - 2016-06-15 15:01:47 --> Helper loaded: form_helper
INFO - 2016-06-15 15:01:47 --> Database Driver Class Initialized
INFO - 2016-06-15 15:01:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:01:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:01:47 --> Email Class Initialized
INFO - 2016-06-15 15:01:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:01:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:01:47 --> Helper loaded: language_helper
INFO - 2016-06-15 15:01:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:01:47 --> Model Class Initialized
INFO - 2016-06-15 15:01:47 --> Helper loaded: date_helper
INFO - 2016-06-15 15:01:47 --> Controller Class Initialized
INFO - 2016-06-15 15:01:47 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:01:47 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:01:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:01:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:01:47 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:01:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:01:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:01:47 --> Model Class Initialized
INFO - 2016-06-15 18:01:47 --> Form Validation Class Initialized
INFO - 2016-06-15 18:01:47 --> Final output sent to browser
DEBUG - 2016-06-15 18:01:47 --> Total execution time: 0.1386
INFO - 2016-06-15 15:02:46 --> Config Class Initialized
INFO - 2016-06-15 15:02:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:02:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:02:46 --> Utf8 Class Initialized
INFO - 2016-06-15 15:02:46 --> URI Class Initialized
INFO - 2016-06-15 15:02:46 --> Router Class Initialized
INFO - 2016-06-15 15:02:46 --> Output Class Initialized
INFO - 2016-06-15 15:02:46 --> Security Class Initialized
DEBUG - 2016-06-15 15:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:02:46 --> Input Class Initialized
INFO - 2016-06-15 15:02:46 --> Language Class Initialized
INFO - 2016-06-15 15:02:46 --> Loader Class Initialized
INFO - 2016-06-15 15:02:46 --> Helper loaded: form_helper
INFO - 2016-06-15 15:02:46 --> Database Driver Class Initialized
INFO - 2016-06-15 15:02:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:02:46 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:02:46 --> Email Class Initialized
INFO - 2016-06-15 15:02:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:02:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:02:46 --> Helper loaded: language_helper
INFO - 2016-06-15 15:02:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:02:46 --> Model Class Initialized
INFO - 2016-06-15 15:02:46 --> Helper loaded: date_helper
INFO - 2016-06-15 15:02:46 --> Controller Class Initialized
INFO - 2016-06-15 15:02:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:02:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:02:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:02:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:02:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:02:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:02:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:02:46 --> Model Class Initialized
INFO - 2016-06-15 18:02:46 --> Form Validation Class Initialized
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:02:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:02:46 --> Final output sent to browser
DEBUG - 2016-06-15 18:02:46 --> Total execution time: 0.1164
INFO - 2016-06-15 15:02:47 --> Config Class Initialized
INFO - 2016-06-15 15:02:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:02:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:02:47 --> Utf8 Class Initialized
INFO - 2016-06-15 15:02:47 --> URI Class Initialized
INFO - 2016-06-15 15:02:47 --> Router Class Initialized
INFO - 2016-06-15 15:02:47 --> Output Class Initialized
INFO - 2016-06-15 15:02:47 --> Security Class Initialized
DEBUG - 2016-06-15 15:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:02:47 --> Input Class Initialized
INFO - 2016-06-15 15:02:47 --> Language Class Initialized
INFO - 2016-06-15 15:02:47 --> Loader Class Initialized
INFO - 2016-06-15 15:02:47 --> Helper loaded: form_helper
INFO - 2016-06-15 15:02:47 --> Database Driver Class Initialized
INFO - 2016-06-15 15:02:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:02:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:02:47 --> Email Class Initialized
INFO - 2016-06-15 15:02:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:02:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:02:47 --> Helper loaded: language_helper
INFO - 2016-06-15 15:02:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:02:47 --> Model Class Initialized
INFO - 2016-06-15 15:02:47 --> Helper loaded: date_helper
INFO - 2016-06-15 15:02:47 --> Controller Class Initialized
INFO - 2016-06-15 15:02:47 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:02:47 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:02:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:02:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:02:47 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:02:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:02:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:02:47 --> Model Class Initialized
INFO - 2016-06-15 18:02:47 --> Form Validation Class Initialized
INFO - 2016-06-15 18:02:47 --> Final output sent to browser
DEBUG - 2016-06-15 18:02:47 --> Total execution time: 0.0957
INFO - 2016-06-15 15:03:35 --> Config Class Initialized
INFO - 2016-06-15 15:03:35 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:03:35 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:03:35 --> Utf8 Class Initialized
INFO - 2016-06-15 15:03:35 --> URI Class Initialized
INFO - 2016-06-15 15:03:35 --> Router Class Initialized
INFO - 2016-06-15 15:03:35 --> Output Class Initialized
INFO - 2016-06-15 15:03:35 --> Security Class Initialized
DEBUG - 2016-06-15 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:03:35 --> Input Class Initialized
INFO - 2016-06-15 15:03:35 --> Language Class Initialized
INFO - 2016-06-15 15:03:35 --> Loader Class Initialized
INFO - 2016-06-15 15:03:35 --> Helper loaded: form_helper
INFO - 2016-06-15 15:03:35 --> Database Driver Class Initialized
INFO - 2016-06-15 15:03:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:03:35 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:03:35 --> Email Class Initialized
INFO - 2016-06-15 15:03:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:03:35 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:03:35 --> Helper loaded: language_helper
INFO - 2016-06-15 15:03:35 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:03:35 --> Model Class Initialized
INFO - 2016-06-15 15:03:35 --> Helper loaded: date_helper
INFO - 2016-06-15 15:03:35 --> Controller Class Initialized
INFO - 2016-06-15 15:03:35 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:03:35 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:03:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:03:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:03:35 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:03:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:03:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:03:35 --> Model Class Initialized
INFO - 2016-06-15 18:03:35 --> Form Validation Class Initialized
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:03:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:03:35 --> Final output sent to browser
DEBUG - 2016-06-15 18:03:35 --> Total execution time: 0.1345
INFO - 2016-06-15 15:03:37 --> Config Class Initialized
INFO - 2016-06-15 15:03:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:03:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:03:37 --> Utf8 Class Initialized
INFO - 2016-06-15 15:03:37 --> URI Class Initialized
INFO - 2016-06-15 15:03:37 --> Router Class Initialized
INFO - 2016-06-15 15:03:37 --> Output Class Initialized
INFO - 2016-06-15 15:03:37 --> Security Class Initialized
DEBUG - 2016-06-15 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:03:37 --> Input Class Initialized
INFO - 2016-06-15 15:03:37 --> Language Class Initialized
INFO - 2016-06-15 15:03:37 --> Loader Class Initialized
INFO - 2016-06-15 15:03:37 --> Helper loaded: form_helper
INFO - 2016-06-15 15:03:37 --> Database Driver Class Initialized
INFO - 2016-06-15 15:03:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:03:37 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:03:37 --> Email Class Initialized
INFO - 2016-06-15 15:03:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:03:37 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:03:37 --> Helper loaded: language_helper
INFO - 2016-06-15 15:03:37 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:03:37 --> Model Class Initialized
INFO - 2016-06-15 15:03:37 --> Helper loaded: date_helper
INFO - 2016-06-15 15:03:37 --> Controller Class Initialized
INFO - 2016-06-15 15:03:37 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:03:37 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:03:37 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:03:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:03:37 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:03:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:03:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:03:37 --> Model Class Initialized
INFO - 2016-06-15 18:03:37 --> Form Validation Class Initialized
INFO - 2016-06-15 18:03:37 --> Final output sent to browser
DEBUG - 2016-06-15 18:03:37 --> Total execution time: 0.0998
INFO - 2016-06-15 15:04:19 --> Config Class Initialized
INFO - 2016-06-15 15:04:19 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:04:19 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:04:19 --> Utf8 Class Initialized
INFO - 2016-06-15 15:04:19 --> URI Class Initialized
INFO - 2016-06-15 15:04:19 --> Router Class Initialized
INFO - 2016-06-15 15:04:19 --> Output Class Initialized
INFO - 2016-06-15 15:04:19 --> Security Class Initialized
DEBUG - 2016-06-15 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:04:19 --> Input Class Initialized
INFO - 2016-06-15 15:04:19 --> Language Class Initialized
INFO - 2016-06-15 15:04:19 --> Loader Class Initialized
INFO - 2016-06-15 15:04:19 --> Helper loaded: form_helper
INFO - 2016-06-15 15:04:19 --> Database Driver Class Initialized
INFO - 2016-06-15 15:04:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:04:19 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:04:19 --> Email Class Initialized
INFO - 2016-06-15 15:04:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:04:19 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:04:19 --> Helper loaded: language_helper
INFO - 2016-06-15 15:04:19 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:04:19 --> Model Class Initialized
INFO - 2016-06-15 15:04:19 --> Helper loaded: date_helper
INFO - 2016-06-15 15:04:19 --> Controller Class Initialized
INFO - 2016-06-15 15:04:19 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:04:19 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:04:19 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:04:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:04:19 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:04:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:04:19 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:04:19 --> Model Class Initialized
INFO - 2016-06-15 18:04:19 --> Form Validation Class Initialized
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:04:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:04:19 --> Final output sent to browser
DEBUG - 2016-06-15 18:04:19 --> Total execution time: 0.1074
INFO - 2016-06-15 15:04:21 --> Config Class Initialized
INFO - 2016-06-15 15:04:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:04:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:04:21 --> Utf8 Class Initialized
INFO - 2016-06-15 15:04:21 --> URI Class Initialized
INFO - 2016-06-15 15:04:21 --> Router Class Initialized
INFO - 2016-06-15 15:04:21 --> Output Class Initialized
INFO - 2016-06-15 15:04:21 --> Security Class Initialized
DEBUG - 2016-06-15 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:04:21 --> Input Class Initialized
INFO - 2016-06-15 15:04:21 --> Language Class Initialized
INFO - 2016-06-15 15:04:21 --> Loader Class Initialized
INFO - 2016-06-15 15:04:21 --> Helper loaded: form_helper
INFO - 2016-06-15 15:04:21 --> Database Driver Class Initialized
INFO - 2016-06-15 15:04:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:04:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:04:21 --> Email Class Initialized
INFO - 2016-06-15 15:04:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:04:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:04:21 --> Helper loaded: language_helper
INFO - 2016-06-15 15:04:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:04:21 --> Model Class Initialized
INFO - 2016-06-15 15:04:21 --> Helper loaded: date_helper
INFO - 2016-06-15 15:04:21 --> Controller Class Initialized
INFO - 2016-06-15 15:04:21 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:04:21 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:04:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:04:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:04:21 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:04:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:04:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:04:21 --> Model Class Initialized
INFO - 2016-06-15 18:04:21 --> Form Validation Class Initialized
INFO - 2016-06-15 18:04:21 --> Final output sent to browser
DEBUG - 2016-06-15 18:04:21 --> Total execution time: 0.0894
INFO - 2016-06-15 15:05:20 --> Config Class Initialized
INFO - 2016-06-15 15:05:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:05:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:05:20 --> Utf8 Class Initialized
INFO - 2016-06-15 15:05:20 --> URI Class Initialized
INFO - 2016-06-15 15:05:20 --> Router Class Initialized
INFO - 2016-06-15 15:05:20 --> Output Class Initialized
INFO - 2016-06-15 15:05:20 --> Security Class Initialized
DEBUG - 2016-06-15 15:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:05:20 --> Input Class Initialized
INFO - 2016-06-15 15:05:20 --> Language Class Initialized
INFO - 2016-06-15 15:05:20 --> Loader Class Initialized
INFO - 2016-06-15 15:05:20 --> Helper loaded: form_helper
INFO - 2016-06-15 15:05:20 --> Database Driver Class Initialized
INFO - 2016-06-15 15:05:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:05:20 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:05:20 --> Email Class Initialized
INFO - 2016-06-15 15:05:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:05:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:05:20 --> Helper loaded: language_helper
INFO - 2016-06-15 15:05:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:05:20 --> Model Class Initialized
INFO - 2016-06-15 15:05:20 --> Helper loaded: date_helper
INFO - 2016-06-15 15:05:20 --> Controller Class Initialized
INFO - 2016-06-15 15:05:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:05:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:05:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:05:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:05:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:05:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:05:20 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:05:20 --> Model Class Initialized
INFO - 2016-06-15 18:05:20 --> Form Validation Class Initialized
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:05:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:05:20 --> Final output sent to browser
DEBUG - 2016-06-15 18:05:20 --> Total execution time: 0.1229
INFO - 2016-06-15 15:05:22 --> Config Class Initialized
INFO - 2016-06-15 15:05:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:05:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:05:22 --> Utf8 Class Initialized
INFO - 2016-06-15 15:05:22 --> URI Class Initialized
INFO - 2016-06-15 15:05:22 --> Router Class Initialized
INFO - 2016-06-15 15:05:22 --> Output Class Initialized
INFO - 2016-06-15 15:05:22 --> Security Class Initialized
DEBUG - 2016-06-15 15:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:05:22 --> Input Class Initialized
INFO - 2016-06-15 15:05:22 --> Language Class Initialized
INFO - 2016-06-15 15:05:22 --> Loader Class Initialized
INFO - 2016-06-15 15:05:22 --> Helper loaded: form_helper
INFO - 2016-06-15 15:05:22 --> Database Driver Class Initialized
INFO - 2016-06-15 15:05:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:05:22 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:05:22 --> Email Class Initialized
INFO - 2016-06-15 15:05:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:05:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:05:22 --> Helper loaded: language_helper
INFO - 2016-06-15 15:05:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:05:22 --> Model Class Initialized
INFO - 2016-06-15 15:05:22 --> Helper loaded: date_helper
INFO - 2016-06-15 15:05:22 --> Controller Class Initialized
INFO - 2016-06-15 15:05:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:05:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:05:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:05:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:05:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:05:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:05:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:05:22 --> Model Class Initialized
INFO - 2016-06-15 18:05:22 --> Form Validation Class Initialized
INFO - 2016-06-15 18:05:22 --> Final output sent to browser
DEBUG - 2016-06-15 18:05:22 --> Total execution time: 0.0940
INFO - 2016-06-15 15:05:46 --> Config Class Initialized
INFO - 2016-06-15 15:05:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:05:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:05:46 --> Utf8 Class Initialized
INFO - 2016-06-15 15:05:46 --> URI Class Initialized
INFO - 2016-06-15 15:05:46 --> Router Class Initialized
INFO - 2016-06-15 15:05:46 --> Output Class Initialized
INFO - 2016-06-15 15:05:46 --> Security Class Initialized
DEBUG - 2016-06-15 15:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:05:46 --> Input Class Initialized
INFO - 2016-06-15 15:05:46 --> Language Class Initialized
INFO - 2016-06-15 15:05:46 --> Loader Class Initialized
INFO - 2016-06-15 15:05:46 --> Helper loaded: form_helper
INFO - 2016-06-15 15:05:46 --> Database Driver Class Initialized
INFO - 2016-06-15 15:05:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:05:46 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:05:46 --> Email Class Initialized
INFO - 2016-06-15 15:05:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:05:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:05:46 --> Helper loaded: language_helper
INFO - 2016-06-15 15:05:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:05:46 --> Model Class Initialized
INFO - 2016-06-15 15:05:46 --> Helper loaded: date_helper
INFO - 2016-06-15 15:05:46 --> Controller Class Initialized
INFO - 2016-06-15 15:05:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:05:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:05:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:05:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:05:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:05:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:05:46 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:05:46 --> Model Class Initialized
INFO - 2016-06-15 18:05:46 --> Form Validation Class Initialized
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:05:46 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:05:46 --> Final output sent to browser
DEBUG - 2016-06-15 18:05:46 --> Total execution time: 0.1263
INFO - 2016-06-15 15:05:48 --> Config Class Initialized
INFO - 2016-06-15 15:05:48 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:05:48 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:05:48 --> Utf8 Class Initialized
INFO - 2016-06-15 15:05:48 --> URI Class Initialized
INFO - 2016-06-15 15:05:48 --> Router Class Initialized
INFO - 2016-06-15 15:05:48 --> Output Class Initialized
INFO - 2016-06-15 15:05:48 --> Security Class Initialized
DEBUG - 2016-06-15 15:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:05:48 --> Input Class Initialized
INFO - 2016-06-15 15:05:48 --> Language Class Initialized
INFO - 2016-06-15 15:05:48 --> Loader Class Initialized
INFO - 2016-06-15 15:05:48 --> Helper loaded: form_helper
INFO - 2016-06-15 15:05:48 --> Database Driver Class Initialized
INFO - 2016-06-15 15:05:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:05:48 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:05:48 --> Email Class Initialized
INFO - 2016-06-15 15:05:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:05:48 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:05:48 --> Helper loaded: language_helper
INFO - 2016-06-15 15:05:48 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:05:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:05:48 --> Model Class Initialized
INFO - 2016-06-15 15:05:48 --> Helper loaded: date_helper
INFO - 2016-06-15 15:05:48 --> Controller Class Initialized
INFO - 2016-06-15 15:05:48 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:05:48 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:05:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:05:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:05:48 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:05:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:05:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:05:48 --> Model Class Initialized
INFO - 2016-06-15 18:05:48 --> Form Validation Class Initialized
INFO - 2016-06-15 18:05:48 --> Final output sent to browser
DEBUG - 2016-06-15 18:05:48 --> Total execution time: 0.0965
INFO - 2016-06-15 15:07:08 --> Config Class Initialized
INFO - 2016-06-15 15:07:08 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:07:08 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:07:08 --> Utf8 Class Initialized
INFO - 2016-06-15 15:07:08 --> URI Class Initialized
INFO - 2016-06-15 15:07:08 --> Router Class Initialized
INFO - 2016-06-15 15:07:08 --> Output Class Initialized
INFO - 2016-06-15 15:07:08 --> Security Class Initialized
DEBUG - 2016-06-15 15:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:07:08 --> Input Class Initialized
INFO - 2016-06-15 15:07:08 --> Language Class Initialized
INFO - 2016-06-15 15:07:08 --> Loader Class Initialized
INFO - 2016-06-15 15:07:08 --> Helper loaded: form_helper
INFO - 2016-06-15 15:07:08 --> Database Driver Class Initialized
INFO - 2016-06-15 15:07:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:07:08 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:07:08 --> Email Class Initialized
INFO - 2016-06-15 15:07:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:07:08 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:07:08 --> Helper loaded: language_helper
INFO - 2016-06-15 15:07:08 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:07:08 --> Model Class Initialized
INFO - 2016-06-15 15:07:08 --> Helper loaded: date_helper
INFO - 2016-06-15 15:07:08 --> Controller Class Initialized
INFO - 2016-06-15 15:07:08 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:07:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:07:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:07:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:07:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:07:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:07:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:07:08 --> Model Class Initialized
INFO - 2016-06-15 18:07:08 --> Form Validation Class Initialized
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:07:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:07:08 --> Final output sent to browser
DEBUG - 2016-06-15 18:07:08 --> Total execution time: 0.1216
INFO - 2016-06-15 15:07:09 --> Config Class Initialized
INFO - 2016-06-15 15:07:09 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:07:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:07:09 --> Utf8 Class Initialized
INFO - 2016-06-15 15:07:09 --> URI Class Initialized
INFO - 2016-06-15 15:07:09 --> Router Class Initialized
INFO - 2016-06-15 15:07:09 --> Output Class Initialized
INFO - 2016-06-15 15:07:09 --> Security Class Initialized
DEBUG - 2016-06-15 15:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:07:09 --> Input Class Initialized
INFO - 2016-06-15 15:07:09 --> Language Class Initialized
INFO - 2016-06-15 15:07:09 --> Loader Class Initialized
INFO - 2016-06-15 15:07:09 --> Helper loaded: form_helper
INFO - 2016-06-15 15:07:09 --> Database Driver Class Initialized
INFO - 2016-06-15 15:07:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:07:09 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:07:09 --> Email Class Initialized
INFO - 2016-06-15 15:07:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:07:09 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:07:09 --> Helper loaded: language_helper
INFO - 2016-06-15 15:07:09 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:07:09 --> Model Class Initialized
INFO - 2016-06-15 15:07:09 --> Helper loaded: date_helper
INFO - 2016-06-15 15:07:09 --> Controller Class Initialized
INFO - 2016-06-15 15:07:09 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:07:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:07:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:07:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:07:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:07:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:07:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:07:09 --> Model Class Initialized
INFO - 2016-06-15 18:07:09 --> Form Validation Class Initialized
INFO - 2016-06-15 18:07:09 --> Final output sent to browser
DEBUG - 2016-06-15 18:07:09 --> Total execution time: 0.0799
INFO - 2016-06-15 15:08:28 --> Config Class Initialized
INFO - 2016-06-15 15:08:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:08:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:08:28 --> Utf8 Class Initialized
INFO - 2016-06-15 15:08:28 --> URI Class Initialized
INFO - 2016-06-15 15:08:28 --> Router Class Initialized
INFO - 2016-06-15 15:08:28 --> Output Class Initialized
INFO - 2016-06-15 15:08:28 --> Security Class Initialized
DEBUG - 2016-06-15 15:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:08:28 --> Input Class Initialized
INFO - 2016-06-15 15:08:28 --> Language Class Initialized
INFO - 2016-06-15 15:08:28 --> Loader Class Initialized
INFO - 2016-06-15 15:08:28 --> Helper loaded: form_helper
INFO - 2016-06-15 15:08:28 --> Database Driver Class Initialized
INFO - 2016-06-15 15:08:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:08:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:08:28 --> Email Class Initialized
INFO - 2016-06-15 15:08:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:08:28 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:08:28 --> Helper loaded: language_helper
INFO - 2016-06-15 15:08:28 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:08:28 --> Model Class Initialized
INFO - 2016-06-15 15:08:28 --> Helper loaded: date_helper
INFO - 2016-06-15 15:08:28 --> Controller Class Initialized
INFO - 2016-06-15 15:08:28 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:08:28 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:08:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:08:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:08:28 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:08:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:08:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:08:28 --> Model Class Initialized
INFO - 2016-06-15 18:08:28 --> Form Validation Class Initialized
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:08:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:08:28 --> Final output sent to browser
DEBUG - 2016-06-15 18:08:28 --> Total execution time: 0.1098
INFO - 2016-06-15 15:08:30 --> Config Class Initialized
INFO - 2016-06-15 15:08:30 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:08:30 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:08:30 --> Utf8 Class Initialized
INFO - 2016-06-15 15:08:30 --> URI Class Initialized
INFO - 2016-06-15 15:08:30 --> Router Class Initialized
INFO - 2016-06-15 15:08:30 --> Output Class Initialized
INFO - 2016-06-15 15:08:30 --> Security Class Initialized
DEBUG - 2016-06-15 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:08:30 --> Input Class Initialized
INFO - 2016-06-15 15:08:30 --> Language Class Initialized
INFO - 2016-06-15 15:08:30 --> Loader Class Initialized
INFO - 2016-06-15 15:08:30 --> Helper loaded: form_helper
INFO - 2016-06-15 15:08:30 --> Database Driver Class Initialized
INFO - 2016-06-15 15:08:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:08:30 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:08:30 --> Email Class Initialized
INFO - 2016-06-15 15:08:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:08:30 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:08:30 --> Helper loaded: language_helper
INFO - 2016-06-15 15:08:30 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:08:30 --> Model Class Initialized
INFO - 2016-06-15 15:08:30 --> Helper loaded: date_helper
INFO - 2016-06-15 15:08:30 --> Controller Class Initialized
INFO - 2016-06-15 15:08:30 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:08:30 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:08:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:08:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:08:30 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:08:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:08:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:08:30 --> Model Class Initialized
INFO - 2016-06-15 18:08:30 --> Form Validation Class Initialized
INFO - 2016-06-15 18:08:30 --> Final output sent to browser
DEBUG - 2016-06-15 18:08:30 --> Total execution time: 0.0947
INFO - 2016-06-15 15:10:44 --> Config Class Initialized
INFO - 2016-06-15 15:10:44 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:10:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:10:44 --> Utf8 Class Initialized
INFO - 2016-06-15 15:10:44 --> URI Class Initialized
INFO - 2016-06-15 15:10:44 --> Router Class Initialized
INFO - 2016-06-15 15:10:44 --> Output Class Initialized
INFO - 2016-06-15 15:10:44 --> Security Class Initialized
DEBUG - 2016-06-15 15:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:10:44 --> Input Class Initialized
INFO - 2016-06-15 15:10:44 --> Language Class Initialized
INFO - 2016-06-15 15:10:44 --> Loader Class Initialized
INFO - 2016-06-15 15:10:44 --> Helper loaded: form_helper
INFO - 2016-06-15 15:10:44 --> Database Driver Class Initialized
INFO - 2016-06-15 15:10:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:10:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:10:44 --> Email Class Initialized
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:10:44 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:10:44 --> Helper loaded: language_helper
INFO - 2016-06-15 15:10:44 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:10:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:10:44 --> Model Class Initialized
INFO - 2016-06-15 15:10:44 --> Helper loaded: date_helper
INFO - 2016-06-15 15:10:44 --> Controller Class Initialized
INFO - 2016-06-15 15:10:44 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:10:44 --> Model Class Initialized
INFO - 2016-06-15 18:10:44 --> Form Validation Class Initialized
INFO - 2016-06-15 15:10:44 --> Config Class Initialized
INFO - 2016-06-15 15:10:44 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:10:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:10:44 --> Utf8 Class Initialized
INFO - 2016-06-15 15:10:44 --> URI Class Initialized
INFO - 2016-06-15 15:10:44 --> Router Class Initialized
INFO - 2016-06-15 15:10:44 --> Output Class Initialized
INFO - 2016-06-15 15:10:44 --> Security Class Initialized
DEBUG - 2016-06-15 15:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:10:44 --> Input Class Initialized
INFO - 2016-06-15 15:10:44 --> Language Class Initialized
INFO - 2016-06-15 15:10:44 --> Loader Class Initialized
INFO - 2016-06-15 15:10:44 --> Helper loaded: form_helper
INFO - 2016-06-15 15:10:44 --> Database Driver Class Initialized
INFO - 2016-06-15 15:10:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:10:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:10:44 --> Config Class Initialized
INFO - 2016-06-15 15:10:44 --> Hooks Class Initialized
INFO - 2016-06-15 15:10:44 --> Email Class Initialized
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:10:44 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:10:44 --> Helper loaded: language_helper
INFO - 2016-06-15 15:10:44 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:10:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-15 15:10:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:10:44 --> Utf8 Class Initialized
INFO - 2016-06-15 15:10:44 --> Model Class Initialized
INFO - 2016-06-15 15:10:44 --> URI Class Initialized
INFO - 2016-06-15 15:10:44 --> Helper loaded: date_helper
INFO - 2016-06-15 15:10:44 --> Router Class Initialized
INFO - 2016-06-15 15:10:44 --> Controller Class Initialized
INFO - 2016-06-15 15:10:44 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:10:44 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 18:10:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:10:44 --> Output Class Initialized
INFO - 2016-06-15 18:10:44 --> Form Validation Class Initialized
DEBUG - 2016-06-15 18:10:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 18:10:44 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 15:10:44 --> Security Class Initialized
INFO - 2016-06-15 18:10:44 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 18:10:44 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 18:10:44 --> Final output sent to browser
DEBUG - 2016-06-15 18:10:44 --> Total execution time: 0.1007
DEBUG - 2016-06-15 15:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:10:44 --> Input Class Initialized
INFO - 2016-06-15 15:10:44 --> Language Class Initialized
ERROR - 2016-06-15 15:10:44 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 15:10:46 --> Config Class Initialized
INFO - 2016-06-15 15:10:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:10:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:10:46 --> Utf8 Class Initialized
INFO - 2016-06-15 15:10:46 --> URI Class Initialized
INFO - 2016-06-15 15:10:46 --> Router Class Initialized
INFO - 2016-06-15 15:10:46 --> Output Class Initialized
INFO - 2016-06-15 15:10:46 --> Security Class Initialized
DEBUG - 2016-06-15 15:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:10:46 --> Input Class Initialized
INFO - 2016-06-15 15:10:46 --> Language Class Initialized
INFO - 2016-06-15 15:10:46 --> Loader Class Initialized
INFO - 2016-06-15 15:10:46 --> Helper loaded: form_helper
INFO - 2016-06-15 15:10:46 --> Database Driver Class Initialized
INFO - 2016-06-15 15:10:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:10:46 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:10:46 --> Email Class Initialized
INFO - 2016-06-15 15:10:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:10:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:10:46 --> Helper loaded: language_helper
INFO - 2016-06-15 15:10:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:10:46 --> Model Class Initialized
INFO - 2016-06-15 15:10:46 --> Helper loaded: date_helper
INFO - 2016-06-15 15:10:46 --> Controller Class Initialized
INFO - 2016-06-15 15:10:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:10:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:10:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:10:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:10:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:10:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:10:46 --> Model Class Initialized
INFO - 2016-06-15 18:10:46 --> Final output sent to browser
DEBUG - 2016-06-15 18:10:46 --> Total execution time: 0.0816
INFO - 2016-06-15 15:10:58 --> Config Class Initialized
INFO - 2016-06-15 15:10:58 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:10:58 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:10:58 --> Utf8 Class Initialized
INFO - 2016-06-15 15:10:58 --> URI Class Initialized
INFO - 2016-06-15 15:10:58 --> Router Class Initialized
INFO - 2016-06-15 15:10:58 --> Output Class Initialized
INFO - 2016-06-15 15:10:58 --> Security Class Initialized
DEBUG - 2016-06-15 15:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:10:58 --> Input Class Initialized
INFO - 2016-06-15 15:10:58 --> Language Class Initialized
INFO - 2016-06-15 15:10:58 --> Loader Class Initialized
INFO - 2016-06-15 15:10:58 --> Helper loaded: form_helper
INFO - 2016-06-15 15:10:58 --> Database Driver Class Initialized
INFO - 2016-06-15 15:10:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:10:58 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:10:58 --> Email Class Initialized
INFO - 2016-06-15 15:10:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:10:58 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:10:58 --> Helper loaded: language_helper
INFO - 2016-06-15 15:10:58 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:10:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:10:58 --> Model Class Initialized
INFO - 2016-06-15 15:10:58 --> Helper loaded: date_helper
INFO - 2016-06-15 15:10:58 --> Controller Class Initialized
INFO - 2016-06-15 15:10:58 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:10:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:10:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:10:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:10:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:10:58 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 18:10:58 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 18:10:58 --> Form Validation Class Initialized
DEBUG - 2016-06-15 18:10:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:10:58 --> Config Class Initialized
INFO - 2016-06-15 15:10:58 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:10:58 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:10:58 --> Utf8 Class Initialized
INFO - 2016-06-15 15:10:58 --> URI Class Initialized
DEBUG - 2016-06-15 15:10:58 --> No URI present. Default controller set.
INFO - 2016-06-15 15:10:58 --> Router Class Initialized
INFO - 2016-06-15 15:10:58 --> Output Class Initialized
INFO - 2016-06-15 15:10:58 --> Security Class Initialized
DEBUG - 2016-06-15 15:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:10:58 --> Input Class Initialized
INFO - 2016-06-15 15:10:58 --> Language Class Initialized
INFO - 2016-06-15 15:10:58 --> Loader Class Initialized
INFO - 2016-06-15 15:10:58 --> Helper loaded: form_helper
INFO - 2016-06-15 15:10:58 --> Database Driver Class Initialized
INFO - 2016-06-15 15:10:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:10:59 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:10:59 --> Email Class Initialized
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:10:59 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:10:59 --> Helper loaded: language_helper
INFO - 2016-06-15 15:10:59 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:10:59 --> Model Class Initialized
INFO - 2016-06-15 15:10:59 --> Helper loaded: date_helper
INFO - 2016-06-15 15:10:59 --> Controller Class Initialized
INFO - 2016-06-15 15:10:59 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:10:59 --> Config Class Initialized
INFO - 2016-06-15 15:10:59 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:10:59 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:10:59 --> Utf8 Class Initialized
INFO - 2016-06-15 15:10:59 --> URI Class Initialized
INFO - 2016-06-15 15:10:59 --> Router Class Initialized
INFO - 2016-06-15 15:10:59 --> Output Class Initialized
INFO - 2016-06-15 15:10:59 --> Security Class Initialized
DEBUG - 2016-06-15 15:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:10:59 --> Input Class Initialized
INFO - 2016-06-15 15:10:59 --> Language Class Initialized
INFO - 2016-06-15 15:10:59 --> Loader Class Initialized
INFO - 2016-06-15 15:10:59 --> Helper loaded: form_helper
INFO - 2016-06-15 15:10:59 --> Database Driver Class Initialized
INFO - 2016-06-15 15:10:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:10:59 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:10:59 --> Email Class Initialized
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:10:59 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:10:59 --> Helper loaded: language_helper
INFO - 2016-06-15 15:10:59 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:10:59 --> Model Class Initialized
INFO - 2016-06-15 15:10:59 --> Helper loaded: date_helper
INFO - 2016-06-15 15:10:59 --> Controller Class Initialized
INFO - 2016-06-15 15:10:59 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:10:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:10:59 --> Model Class Initialized
INFO - 2016-06-15 18:10:59 --> Form Validation Class Initialized
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:10:59 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:10:59 --> Final output sent to browser
DEBUG - 2016-06-15 18:10:59 --> Total execution time: 0.1132
INFO - 2016-06-15 15:11:00 --> Config Class Initialized
INFO - 2016-06-15 15:11:00 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:11:00 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:11:00 --> Utf8 Class Initialized
INFO - 2016-06-15 15:11:00 --> URI Class Initialized
INFO - 2016-06-15 15:11:00 --> Router Class Initialized
INFO - 2016-06-15 15:11:00 --> Output Class Initialized
INFO - 2016-06-15 15:11:00 --> Security Class Initialized
DEBUG - 2016-06-15 15:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:11:00 --> Input Class Initialized
INFO - 2016-06-15 15:11:00 --> Language Class Initialized
INFO - 2016-06-15 15:11:00 --> Loader Class Initialized
INFO - 2016-06-15 15:11:00 --> Helper loaded: form_helper
INFO - 2016-06-15 15:11:00 --> Database Driver Class Initialized
INFO - 2016-06-15 15:11:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:11:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:11:00 --> Email Class Initialized
INFO - 2016-06-15 15:11:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:11:00 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:11:00 --> Helper loaded: language_helper
INFO - 2016-06-15 15:11:00 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:11:00 --> Model Class Initialized
INFO - 2016-06-15 15:11:00 --> Helper loaded: date_helper
INFO - 2016-06-15 15:11:00 --> Controller Class Initialized
INFO - 2016-06-15 15:11:00 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:11:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:11:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:11:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:11:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:11:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:11:00 --> Model Class Initialized
INFO - 2016-06-15 18:11:00 --> Form Validation Class Initialized
INFO - 2016-06-15 18:11:00 --> Final output sent to browser
DEBUG - 2016-06-15 18:11:00 --> Total execution time: 0.0994
INFO - 2016-06-15 15:13:24 --> Config Class Initialized
INFO - 2016-06-15 15:13:24 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:13:24 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:13:24 --> Utf8 Class Initialized
INFO - 2016-06-15 15:13:24 --> URI Class Initialized
INFO - 2016-06-15 15:13:24 --> Router Class Initialized
INFO - 2016-06-15 15:13:24 --> Output Class Initialized
INFO - 2016-06-15 15:13:24 --> Security Class Initialized
DEBUG - 2016-06-15 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:13:24 --> Input Class Initialized
INFO - 2016-06-15 15:13:24 --> Language Class Initialized
INFO - 2016-06-15 15:13:24 --> Loader Class Initialized
INFO - 2016-06-15 15:13:24 --> Helper loaded: form_helper
INFO - 2016-06-15 15:13:24 --> Database Driver Class Initialized
INFO - 2016-06-15 15:13:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:13:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:13:24 --> Email Class Initialized
INFO - 2016-06-15 15:13:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:13:24 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:13:24 --> Helper loaded: language_helper
INFO - 2016-06-15 15:13:24 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:13:24 --> Model Class Initialized
INFO - 2016-06-15 15:13:24 --> Helper loaded: date_helper
INFO - 2016-06-15 15:13:24 --> Controller Class Initialized
INFO - 2016-06-15 15:13:24 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:13:24 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:13:24 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:13:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:13:24 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:13:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:13:24 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:13:24 --> Model Class Initialized
INFO - 2016-06-15 18:13:24 --> Form Validation Class Initialized
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:13:24 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:13:24 --> Final output sent to browser
DEBUG - 2016-06-15 18:13:24 --> Total execution time: 0.1097
INFO - 2016-06-15 15:13:25 --> Config Class Initialized
INFO - 2016-06-15 15:13:25 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:13:25 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:13:25 --> Utf8 Class Initialized
INFO - 2016-06-15 15:13:25 --> URI Class Initialized
INFO - 2016-06-15 15:13:25 --> Router Class Initialized
INFO - 2016-06-15 15:13:25 --> Output Class Initialized
INFO - 2016-06-15 15:13:25 --> Security Class Initialized
DEBUG - 2016-06-15 15:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:13:25 --> Input Class Initialized
INFO - 2016-06-15 15:13:25 --> Language Class Initialized
INFO - 2016-06-15 15:13:25 --> Loader Class Initialized
INFO - 2016-06-15 15:13:25 --> Helper loaded: form_helper
INFO - 2016-06-15 15:13:25 --> Database Driver Class Initialized
INFO - 2016-06-15 15:13:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:13:25 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:13:25 --> Email Class Initialized
INFO - 2016-06-15 15:13:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:13:25 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:13:25 --> Helper loaded: language_helper
INFO - 2016-06-15 15:13:26 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:13:26 --> Model Class Initialized
INFO - 2016-06-15 15:13:26 --> Helper loaded: date_helper
INFO - 2016-06-15 15:13:26 --> Controller Class Initialized
INFO - 2016-06-15 15:13:26 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:13:26 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-15 15:13:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-15 15:13:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-15 15:13:26 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-15 15:13:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-15 15:13:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-15 18:13:26 --> Model Class Initialized
INFO - 2016-06-15 18:13:26 --> Form Validation Class Initialized
INFO - 2016-06-15 18:13:26 --> Final output sent to browser
DEBUG - 2016-06-15 18:13:26 --> Total execution time: 0.1072
INFO - 2016-06-15 15:13:58 --> Config Class Initialized
INFO - 2016-06-15 15:13:58 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:13:58 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:13:58 --> Utf8 Class Initialized
INFO - 2016-06-15 15:13:58 --> URI Class Initialized
INFO - 2016-06-15 15:13:58 --> Router Class Initialized
INFO - 2016-06-15 15:13:58 --> Output Class Initialized
INFO - 2016-06-15 15:13:58 --> Security Class Initialized
DEBUG - 2016-06-15 15:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:13:58 --> Input Class Initialized
INFO - 2016-06-15 15:13:58 --> Language Class Initialized
INFO - 2016-06-15 15:13:58 --> Loader Class Initialized
INFO - 2016-06-15 15:13:58 --> Helper loaded: form_helper
INFO - 2016-06-15 15:13:58 --> Database Driver Class Initialized
INFO - 2016-06-15 15:13:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:13:58 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:13:58 --> Email Class Initialized
INFO - 2016-06-15 15:13:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:13:58 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:13:58 --> Helper loaded: language_helper
INFO - 2016-06-15 15:13:58 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:13:58 --> Model Class Initialized
INFO - 2016-06-15 15:13:58 --> Helper loaded: date_helper
INFO - 2016-06-15 15:13:58 --> Controller Class Initialized
INFO - 2016-06-15 15:13:58 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:13:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:13:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:13:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:13:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:13:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:13:58 --> Model Class Initialized
INFO - 2016-06-15 18:13:58 --> Form Validation Class Initialized
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:13:58 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:13:58 --> Final output sent to browser
DEBUG - 2016-06-15 18:13:58 --> Total execution time: 0.1127
INFO - 2016-06-15 15:14:00 --> Config Class Initialized
INFO - 2016-06-15 15:14:00 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:14:00 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:14:00 --> Utf8 Class Initialized
INFO - 2016-06-15 15:14:00 --> URI Class Initialized
INFO - 2016-06-15 15:14:00 --> Router Class Initialized
INFO - 2016-06-15 15:14:00 --> Output Class Initialized
INFO - 2016-06-15 15:14:00 --> Security Class Initialized
DEBUG - 2016-06-15 15:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:14:00 --> Input Class Initialized
INFO - 2016-06-15 15:14:00 --> Language Class Initialized
INFO - 2016-06-15 15:14:00 --> Loader Class Initialized
INFO - 2016-06-15 15:14:00 --> Helper loaded: form_helper
INFO - 2016-06-15 15:14:00 --> Database Driver Class Initialized
INFO - 2016-06-15 15:14:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:14:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:14:00 --> Email Class Initialized
INFO - 2016-06-15 15:14:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:14:00 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:14:00 --> Helper loaded: language_helper
INFO - 2016-06-15 15:14:00 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:14:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:14:00 --> Model Class Initialized
INFO - 2016-06-15 15:14:00 --> Helper loaded: date_helper
INFO - 2016-06-15 15:14:00 --> Controller Class Initialized
INFO - 2016-06-15 15:14:00 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:14:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:14:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:14:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:14:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:14:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:14:00 --> Model Class Initialized
INFO - 2016-06-15 18:14:00 --> Form Validation Class Initialized
INFO - 2016-06-15 18:14:00 --> Final output sent to browser
DEBUG - 2016-06-15 18:14:00 --> Total execution time: 0.0913
INFO - 2016-06-15 15:15:07 --> Config Class Initialized
INFO - 2016-06-15 15:15:07 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:15:07 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:15:07 --> Utf8 Class Initialized
INFO - 2016-06-15 15:15:07 --> URI Class Initialized
INFO - 2016-06-15 15:15:07 --> Router Class Initialized
INFO - 2016-06-15 15:15:07 --> Output Class Initialized
INFO - 2016-06-15 15:15:07 --> Security Class Initialized
DEBUG - 2016-06-15 15:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:15:07 --> Input Class Initialized
INFO - 2016-06-15 15:15:07 --> Language Class Initialized
INFO - 2016-06-15 15:15:07 --> Loader Class Initialized
INFO - 2016-06-15 15:15:07 --> Helper loaded: form_helper
INFO - 2016-06-15 15:15:07 --> Database Driver Class Initialized
INFO - 2016-06-15 15:15:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:15:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:15:07 --> Email Class Initialized
INFO - 2016-06-15 15:15:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:15:07 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:15:07 --> Helper loaded: language_helper
INFO - 2016-06-15 15:15:07 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:15:07 --> Model Class Initialized
INFO - 2016-06-15 15:15:07 --> Helper loaded: date_helper
INFO - 2016-06-15 15:15:07 --> Controller Class Initialized
INFO - 2016-06-15 15:15:07 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:15:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:15:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:15:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:15:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:15:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:15:07 --> Model Class Initialized
INFO - 2016-06-15 18:15:07 --> Form Validation Class Initialized
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:15:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:15:07 --> Final output sent to browser
DEBUG - 2016-06-15 18:15:07 --> Total execution time: 0.1522
INFO - 2016-06-15 15:15:09 --> Config Class Initialized
INFO - 2016-06-15 15:15:09 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:15:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:15:09 --> Utf8 Class Initialized
INFO - 2016-06-15 15:15:09 --> URI Class Initialized
INFO - 2016-06-15 15:15:09 --> Router Class Initialized
INFO - 2016-06-15 15:15:09 --> Output Class Initialized
INFO - 2016-06-15 15:15:09 --> Security Class Initialized
DEBUG - 2016-06-15 15:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:15:09 --> Input Class Initialized
INFO - 2016-06-15 15:15:09 --> Language Class Initialized
INFO - 2016-06-15 15:15:09 --> Loader Class Initialized
INFO - 2016-06-15 15:15:09 --> Helper loaded: form_helper
INFO - 2016-06-15 15:15:09 --> Database Driver Class Initialized
INFO - 2016-06-15 15:15:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:15:09 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:15:09 --> Email Class Initialized
INFO - 2016-06-15 15:15:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:15:09 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:15:09 --> Helper loaded: language_helper
INFO - 2016-06-15 15:15:09 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:15:09 --> Model Class Initialized
INFO - 2016-06-15 15:15:09 --> Helper loaded: date_helper
INFO - 2016-06-15 15:15:09 --> Controller Class Initialized
INFO - 2016-06-15 15:15:09 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:15:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:15:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:15:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:15:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:15:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:15:09 --> Model Class Initialized
INFO - 2016-06-15 18:15:09 --> Form Validation Class Initialized
INFO - 2016-06-15 18:15:09 --> Final output sent to browser
DEBUG - 2016-06-15 18:15:09 --> Total execution time: 0.1199
INFO - 2016-06-15 15:15:53 --> Config Class Initialized
INFO - 2016-06-15 15:15:53 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:15:53 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:15:53 --> Utf8 Class Initialized
INFO - 2016-06-15 15:15:53 --> URI Class Initialized
INFO - 2016-06-15 15:15:53 --> Router Class Initialized
INFO - 2016-06-15 15:15:53 --> Output Class Initialized
INFO - 2016-06-15 15:15:53 --> Security Class Initialized
DEBUG - 2016-06-15 15:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:15:53 --> Input Class Initialized
INFO - 2016-06-15 15:15:53 --> Language Class Initialized
INFO - 2016-06-15 15:15:53 --> Loader Class Initialized
INFO - 2016-06-15 15:15:53 --> Helper loaded: form_helper
INFO - 2016-06-15 15:15:54 --> Database Driver Class Initialized
INFO - 2016-06-15 15:15:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:15:54 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:15:54 --> Email Class Initialized
INFO - 2016-06-15 15:15:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:15:54 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:15:54 --> Helper loaded: language_helper
INFO - 2016-06-15 15:15:54 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:15:54 --> Model Class Initialized
INFO - 2016-06-15 15:15:54 --> Helper loaded: date_helper
INFO - 2016-06-15 15:15:54 --> Controller Class Initialized
INFO - 2016-06-15 15:15:54 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:15:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:15:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:15:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:15:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:15:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:15:54 --> Model Class Initialized
INFO - 2016-06-15 18:15:54 --> Form Validation Class Initialized
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:15:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:15:54 --> Final output sent to browser
DEBUG - 2016-06-15 18:15:54 --> Total execution time: 0.1208
INFO - 2016-06-15 15:15:56 --> Config Class Initialized
INFO - 2016-06-15 15:15:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:15:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:15:56 --> Utf8 Class Initialized
INFO - 2016-06-15 15:15:56 --> URI Class Initialized
INFO - 2016-06-15 15:15:56 --> Router Class Initialized
INFO - 2016-06-15 15:15:56 --> Output Class Initialized
INFO - 2016-06-15 15:15:56 --> Security Class Initialized
DEBUG - 2016-06-15 15:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:15:56 --> Input Class Initialized
INFO - 2016-06-15 15:15:56 --> Language Class Initialized
INFO - 2016-06-15 15:15:56 --> Loader Class Initialized
INFO - 2016-06-15 15:15:56 --> Helper loaded: form_helper
INFO - 2016-06-15 15:15:56 --> Database Driver Class Initialized
INFO - 2016-06-15 15:15:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:15:56 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:15:56 --> Email Class Initialized
INFO - 2016-06-15 15:15:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:15:56 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:15:56 --> Helper loaded: language_helper
INFO - 2016-06-15 15:15:56 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:15:56 --> Model Class Initialized
INFO - 2016-06-15 15:15:56 --> Helper loaded: date_helper
INFO - 2016-06-15 15:15:56 --> Controller Class Initialized
INFO - 2016-06-15 15:15:56 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:15:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:15:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:15:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:15:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:15:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:15:56 --> Model Class Initialized
INFO - 2016-06-15 18:15:56 --> Form Validation Class Initialized
INFO - 2016-06-15 18:15:56 --> Final output sent to browser
DEBUG - 2016-06-15 18:15:56 --> Total execution time: 0.0890
INFO - 2016-06-15 15:16:20 --> Config Class Initialized
INFO - 2016-06-15 15:16:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:16:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:16:20 --> Utf8 Class Initialized
INFO - 2016-06-15 15:16:20 --> URI Class Initialized
INFO - 2016-06-15 15:16:20 --> Router Class Initialized
INFO - 2016-06-15 15:16:20 --> Output Class Initialized
INFO - 2016-06-15 15:16:20 --> Security Class Initialized
DEBUG - 2016-06-15 15:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:16:20 --> Input Class Initialized
INFO - 2016-06-15 15:16:20 --> Language Class Initialized
INFO - 2016-06-15 15:16:20 --> Loader Class Initialized
INFO - 2016-06-15 15:16:20 --> Helper loaded: form_helper
INFO - 2016-06-15 15:16:20 --> Database Driver Class Initialized
INFO - 2016-06-15 15:16:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:16:20 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:16:20 --> Email Class Initialized
INFO - 2016-06-15 15:16:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:16:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:16:20 --> Helper loaded: language_helper
INFO - 2016-06-15 15:16:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:16:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:16:20 --> Model Class Initialized
INFO - 2016-06-15 15:16:20 --> Helper loaded: date_helper
INFO - 2016-06-15 15:16:20 --> Controller Class Initialized
INFO - 2016-06-15 15:16:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:16:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:16:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:16:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:16:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:16:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:16:20 --> Model Class Initialized
INFO - 2016-06-15 18:16:20 --> Form Validation Class Initialized
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:16:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:16:20 --> Final output sent to browser
DEBUG - 2016-06-15 18:16:20 --> Total execution time: 0.1203
INFO - 2016-06-15 15:16:22 --> Config Class Initialized
INFO - 2016-06-15 15:16:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:16:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:16:22 --> Utf8 Class Initialized
INFO - 2016-06-15 15:16:22 --> URI Class Initialized
INFO - 2016-06-15 15:16:22 --> Router Class Initialized
INFO - 2016-06-15 15:16:22 --> Output Class Initialized
INFO - 2016-06-15 15:16:22 --> Security Class Initialized
DEBUG - 2016-06-15 15:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:16:22 --> Input Class Initialized
INFO - 2016-06-15 15:16:22 --> Language Class Initialized
INFO - 2016-06-15 15:16:22 --> Loader Class Initialized
INFO - 2016-06-15 15:16:22 --> Helper loaded: form_helper
INFO - 2016-06-15 15:16:22 --> Database Driver Class Initialized
INFO - 2016-06-15 15:16:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:16:22 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:16:22 --> Email Class Initialized
INFO - 2016-06-15 15:16:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:16:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:16:22 --> Helper loaded: language_helper
INFO - 2016-06-15 15:16:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:16:22 --> Model Class Initialized
INFO - 2016-06-15 15:16:22 --> Helper loaded: date_helper
INFO - 2016-06-15 15:16:22 --> Controller Class Initialized
INFO - 2016-06-15 15:16:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:16:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:16:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:16:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:16:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:16:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:16:22 --> Model Class Initialized
INFO - 2016-06-15 18:16:22 --> Form Validation Class Initialized
INFO - 2016-06-15 18:16:22 --> Final output sent to browser
DEBUG - 2016-06-15 18:16:22 --> Total execution time: 0.0867
INFO - 2016-06-15 15:17:07 --> Config Class Initialized
INFO - 2016-06-15 15:17:07 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:17:07 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:17:07 --> Utf8 Class Initialized
INFO - 2016-06-15 15:17:07 --> URI Class Initialized
INFO - 2016-06-15 15:17:07 --> Router Class Initialized
INFO - 2016-06-15 15:17:07 --> Output Class Initialized
INFO - 2016-06-15 15:17:07 --> Security Class Initialized
DEBUG - 2016-06-15 15:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:17:07 --> Input Class Initialized
INFO - 2016-06-15 15:17:07 --> Language Class Initialized
INFO - 2016-06-15 15:17:07 --> Loader Class Initialized
INFO - 2016-06-15 15:17:07 --> Helper loaded: form_helper
INFO - 2016-06-15 15:17:07 --> Database Driver Class Initialized
INFO - 2016-06-15 15:17:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:17:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:17:07 --> Email Class Initialized
INFO - 2016-06-15 15:17:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:17:07 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:17:07 --> Helper loaded: language_helper
INFO - 2016-06-15 15:17:07 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:17:07 --> Model Class Initialized
INFO - 2016-06-15 15:17:07 --> Helper loaded: date_helper
INFO - 2016-06-15 15:17:07 --> Controller Class Initialized
INFO - 2016-06-15 15:17:07 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:17:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:17:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:17:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:17:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:17:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:17:07 --> Model Class Initialized
INFO - 2016-06-15 18:17:07 --> Form Validation Class Initialized
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:17:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:17:07 --> Final output sent to browser
DEBUG - 2016-06-15 18:17:07 --> Total execution time: 0.1068
INFO - 2016-06-15 15:17:09 --> Config Class Initialized
INFO - 2016-06-15 15:17:09 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:17:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:17:09 --> Utf8 Class Initialized
INFO - 2016-06-15 15:17:09 --> URI Class Initialized
INFO - 2016-06-15 15:17:09 --> Router Class Initialized
INFO - 2016-06-15 15:17:09 --> Output Class Initialized
INFO - 2016-06-15 15:17:09 --> Security Class Initialized
DEBUG - 2016-06-15 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:17:09 --> Input Class Initialized
INFO - 2016-06-15 15:17:09 --> Language Class Initialized
INFO - 2016-06-15 15:17:09 --> Loader Class Initialized
INFO - 2016-06-15 15:17:09 --> Helper loaded: form_helper
INFO - 2016-06-15 15:17:09 --> Database Driver Class Initialized
INFO - 2016-06-15 15:17:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:17:09 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:17:09 --> Email Class Initialized
INFO - 2016-06-15 15:17:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:17:09 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:17:09 --> Helper loaded: language_helper
INFO - 2016-06-15 15:17:09 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:17:09 --> Model Class Initialized
INFO - 2016-06-15 15:17:09 --> Helper loaded: date_helper
INFO - 2016-06-15 15:17:09 --> Controller Class Initialized
INFO - 2016-06-15 15:17:09 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:17:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:17:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:17:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:17:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:17:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:17:09 --> Model Class Initialized
INFO - 2016-06-15 18:17:09 --> Form Validation Class Initialized
INFO - 2016-06-15 18:17:09 --> Final output sent to browser
DEBUG - 2016-06-15 18:17:09 --> Total execution time: 0.0928
INFO - 2016-06-15 15:18:31 --> Config Class Initialized
INFO - 2016-06-15 15:18:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:18:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:18:31 --> Utf8 Class Initialized
INFO - 2016-06-15 15:18:31 --> URI Class Initialized
INFO - 2016-06-15 15:18:31 --> Router Class Initialized
INFO - 2016-06-15 15:18:31 --> Output Class Initialized
INFO - 2016-06-15 15:18:31 --> Security Class Initialized
DEBUG - 2016-06-15 15:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:18:31 --> Input Class Initialized
INFO - 2016-06-15 15:18:31 --> Language Class Initialized
INFO - 2016-06-15 15:18:31 --> Loader Class Initialized
INFO - 2016-06-15 15:18:31 --> Helper loaded: form_helper
INFO - 2016-06-15 15:18:31 --> Database Driver Class Initialized
INFO - 2016-06-15 15:18:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:18:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:18:31 --> Email Class Initialized
INFO - 2016-06-15 15:18:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:18:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:18:31 --> Helper loaded: language_helper
INFO - 2016-06-15 15:18:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:18:31 --> Model Class Initialized
INFO - 2016-06-15 15:18:31 --> Helper loaded: date_helper
INFO - 2016-06-15 15:18:31 --> Controller Class Initialized
INFO - 2016-06-15 15:18:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:18:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:18:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:18:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:18:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:18:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:18:31 --> Model Class Initialized
INFO - 2016-06-15 18:18:31 --> Form Validation Class Initialized
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:18:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:18:31 --> Final output sent to browser
DEBUG - 2016-06-15 18:18:31 --> Total execution time: 0.1298
INFO - 2016-06-15 15:18:34 --> Config Class Initialized
INFO - 2016-06-15 15:18:34 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:18:34 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:18:34 --> Utf8 Class Initialized
INFO - 2016-06-15 15:18:35 --> URI Class Initialized
INFO - 2016-06-15 15:18:35 --> Router Class Initialized
INFO - 2016-06-15 15:18:35 --> Output Class Initialized
INFO - 2016-06-15 15:18:35 --> Security Class Initialized
DEBUG - 2016-06-15 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:18:35 --> Input Class Initialized
INFO - 2016-06-15 15:18:35 --> Language Class Initialized
INFO - 2016-06-15 15:18:35 --> Loader Class Initialized
INFO - 2016-06-15 15:18:35 --> Helper loaded: form_helper
INFO - 2016-06-15 15:18:35 --> Database Driver Class Initialized
INFO - 2016-06-15 15:18:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:18:35 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:18:35 --> Email Class Initialized
INFO - 2016-06-15 15:18:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:18:35 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:18:35 --> Helper loaded: language_helper
INFO - 2016-06-15 15:18:35 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:18:35 --> Model Class Initialized
INFO - 2016-06-15 15:18:35 --> Helper loaded: date_helper
INFO - 2016-06-15 15:18:35 --> Controller Class Initialized
INFO - 2016-06-15 15:18:35 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:18:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:18:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:18:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:18:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:18:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:18:35 --> Model Class Initialized
INFO - 2016-06-15 18:18:35 --> Form Validation Class Initialized
INFO - 2016-06-15 18:18:35 --> Final output sent to browser
DEBUG - 2016-06-15 18:18:35 --> Total execution time: 0.0906
INFO - 2016-06-15 15:19:35 --> Config Class Initialized
INFO - 2016-06-15 15:19:35 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:19:35 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:19:35 --> Utf8 Class Initialized
INFO - 2016-06-15 15:19:35 --> URI Class Initialized
INFO - 2016-06-15 15:19:35 --> Router Class Initialized
INFO - 2016-06-15 15:19:35 --> Output Class Initialized
INFO - 2016-06-15 15:19:35 --> Security Class Initialized
DEBUG - 2016-06-15 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:19:35 --> Input Class Initialized
INFO - 2016-06-15 15:19:35 --> Language Class Initialized
INFO - 2016-06-15 15:19:35 --> Loader Class Initialized
INFO - 2016-06-15 15:19:35 --> Helper loaded: form_helper
INFO - 2016-06-15 15:19:35 --> Database Driver Class Initialized
INFO - 2016-06-15 15:19:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:19:35 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:19:35 --> Email Class Initialized
INFO - 2016-06-15 15:19:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:19:35 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:19:35 --> Helper loaded: language_helper
INFO - 2016-06-15 15:19:35 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:19:35 --> Model Class Initialized
INFO - 2016-06-15 15:19:35 --> Helper loaded: date_helper
INFO - 2016-06-15 15:19:35 --> Controller Class Initialized
INFO - 2016-06-15 15:19:35 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:19:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:19:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:19:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:19:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:19:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:19:35 --> Model Class Initialized
INFO - 2016-06-15 18:19:35 --> Form Validation Class Initialized
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:19:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:19:35 --> Final output sent to browser
DEBUG - 2016-06-15 18:19:35 --> Total execution time: 0.1101
INFO - 2016-06-15 15:19:37 --> Config Class Initialized
INFO - 2016-06-15 15:19:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:19:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:19:37 --> Utf8 Class Initialized
INFO - 2016-06-15 15:19:37 --> URI Class Initialized
INFO - 2016-06-15 15:19:37 --> Router Class Initialized
INFO - 2016-06-15 15:19:37 --> Output Class Initialized
INFO - 2016-06-15 15:19:37 --> Security Class Initialized
DEBUG - 2016-06-15 15:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:19:37 --> Input Class Initialized
INFO - 2016-06-15 15:19:37 --> Language Class Initialized
INFO - 2016-06-15 15:19:37 --> Loader Class Initialized
INFO - 2016-06-15 15:19:37 --> Helper loaded: form_helper
INFO - 2016-06-15 15:19:37 --> Database Driver Class Initialized
INFO - 2016-06-15 15:19:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:19:37 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:19:37 --> Email Class Initialized
INFO - 2016-06-15 15:19:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:19:37 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:19:37 --> Helper loaded: language_helper
INFO - 2016-06-15 15:19:37 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:19:37 --> Model Class Initialized
INFO - 2016-06-15 15:19:37 --> Helper loaded: date_helper
INFO - 2016-06-15 15:19:37 --> Controller Class Initialized
INFO - 2016-06-15 15:19:37 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:19:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:19:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:19:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:19:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:19:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:19:37 --> Model Class Initialized
INFO - 2016-06-15 18:19:37 --> Form Validation Class Initialized
INFO - 2016-06-15 18:19:37 --> Final output sent to browser
DEBUG - 2016-06-15 18:19:37 --> Total execution time: 0.1064
INFO - 2016-06-15 15:20:20 --> Config Class Initialized
INFO - 2016-06-15 15:20:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:20:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:20:20 --> Utf8 Class Initialized
INFO - 2016-06-15 15:20:20 --> URI Class Initialized
INFO - 2016-06-15 15:20:20 --> Router Class Initialized
INFO - 2016-06-15 15:20:20 --> Output Class Initialized
INFO - 2016-06-15 15:20:20 --> Security Class Initialized
DEBUG - 2016-06-15 15:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:20:20 --> Input Class Initialized
INFO - 2016-06-15 15:20:20 --> Language Class Initialized
INFO - 2016-06-15 15:20:20 --> Loader Class Initialized
INFO - 2016-06-15 15:20:20 --> Helper loaded: form_helper
INFO - 2016-06-15 15:20:20 --> Database Driver Class Initialized
INFO - 2016-06-15 15:20:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:20:20 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:20:20 --> Email Class Initialized
INFO - 2016-06-15 15:20:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:20:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:20:20 --> Helper loaded: language_helper
INFO - 2016-06-15 15:20:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:20:20 --> Model Class Initialized
INFO - 2016-06-15 15:20:20 --> Helper loaded: date_helper
INFO - 2016-06-15 15:20:20 --> Controller Class Initialized
INFO - 2016-06-15 15:20:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:20:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:20:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:20:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:20:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:20:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:20:20 --> Model Class Initialized
INFO - 2016-06-15 18:20:20 --> Form Validation Class Initialized
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:20:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:20:20 --> Final output sent to browser
DEBUG - 2016-06-15 18:20:20 --> Total execution time: 0.1169
INFO - 2016-06-15 15:20:22 --> Config Class Initialized
INFO - 2016-06-15 15:20:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:20:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:20:22 --> Utf8 Class Initialized
INFO - 2016-06-15 15:20:22 --> URI Class Initialized
INFO - 2016-06-15 15:20:22 --> Router Class Initialized
INFO - 2016-06-15 15:20:22 --> Output Class Initialized
INFO - 2016-06-15 15:20:22 --> Security Class Initialized
DEBUG - 2016-06-15 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:20:22 --> Input Class Initialized
INFO - 2016-06-15 15:20:22 --> Language Class Initialized
INFO - 2016-06-15 15:20:22 --> Loader Class Initialized
INFO - 2016-06-15 15:20:22 --> Helper loaded: form_helper
INFO - 2016-06-15 15:20:22 --> Database Driver Class Initialized
INFO - 2016-06-15 15:20:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:20:22 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:20:22 --> Email Class Initialized
INFO - 2016-06-15 15:20:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:20:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:20:22 --> Helper loaded: language_helper
INFO - 2016-06-15 15:20:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:20:22 --> Model Class Initialized
INFO - 2016-06-15 15:20:22 --> Helper loaded: date_helper
INFO - 2016-06-15 15:20:22 --> Controller Class Initialized
INFO - 2016-06-15 15:20:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:20:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:20:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:20:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:20:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:20:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:20:22 --> Model Class Initialized
INFO - 2016-06-15 18:20:22 --> Form Validation Class Initialized
INFO - 2016-06-15 18:20:22 --> Final output sent to browser
DEBUG - 2016-06-15 18:20:22 --> Total execution time: 0.1115
INFO - 2016-06-15 15:21:09 --> Config Class Initialized
INFO - 2016-06-15 15:21:09 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:21:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:09 --> Utf8 Class Initialized
INFO - 2016-06-15 15:21:09 --> URI Class Initialized
DEBUG - 2016-06-15 15:21:09 --> No URI present. Default controller set.
INFO - 2016-06-15 15:21:09 --> Router Class Initialized
INFO - 2016-06-15 15:21:09 --> Output Class Initialized
INFO - 2016-06-15 15:21:09 --> Security Class Initialized
DEBUG - 2016-06-15 15:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:09 --> Input Class Initialized
INFO - 2016-06-15 15:21:09 --> Language Class Initialized
INFO - 2016-06-15 15:21:09 --> Loader Class Initialized
INFO - 2016-06-15 15:21:09 --> Helper loaded: form_helper
INFO - 2016-06-15 15:21:09 --> Database Driver Class Initialized
INFO - 2016-06-15 15:21:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:21:09 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:21:09 --> Email Class Initialized
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:21:09 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:21:09 --> Helper loaded: language_helper
INFO - 2016-06-15 15:21:09 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:21:09 --> Model Class Initialized
INFO - 2016-06-15 15:21:09 --> Helper loaded: date_helper
INFO - 2016-06-15 15:21:09 --> Controller Class Initialized
INFO - 2016-06-15 15:21:09 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:21:09 --> Config Class Initialized
INFO - 2016-06-15 15:21:09 --> Hooks Class Initialized
INFO - 2016-06-15 15:21:09 --> Config Class Initialized
INFO - 2016-06-15 15:21:09 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:21:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:09 --> Utf8 Class Initialized
DEBUG - 2016-06-15 15:21:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:09 --> Utf8 Class Initialized
INFO - 2016-06-15 15:21:09 --> URI Class Initialized
INFO - 2016-06-15 15:21:09 --> URI Class Initialized
INFO - 2016-06-15 15:21:09 --> Router Class Initialized
INFO - 2016-06-15 15:21:09 --> Router Class Initialized
INFO - 2016-06-15 15:21:09 --> Output Class Initialized
INFO - 2016-06-15 15:21:09 --> Output Class Initialized
INFO - 2016-06-15 15:21:09 --> Security Class Initialized
INFO - 2016-06-15 15:21:09 --> Security Class Initialized
DEBUG - 2016-06-15 15:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:09 --> Input Class Initialized
DEBUG - 2016-06-15 15:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:09 --> Language Class Initialized
INFO - 2016-06-15 15:21:09 --> Input Class Initialized
INFO - 2016-06-15 15:21:09 --> Language Class Initialized
ERROR - 2016-06-15 15:21:09 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 15:21:09 --> Loader Class Initialized
INFO - 2016-06-15 15:21:09 --> Helper loaded: form_helper
INFO - 2016-06-15 15:21:09 --> Database Driver Class Initialized
INFO - 2016-06-15 15:21:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:21:09 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:21:09 --> Email Class Initialized
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:21:09 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:21:09 --> Helper loaded: language_helper
INFO - 2016-06-15 15:21:09 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:21:09 --> Model Class Initialized
INFO - 2016-06-15 15:21:09 --> Helper loaded: date_helper
INFO - 2016-06-15 15:21:09 --> Controller Class Initialized
INFO - 2016-06-15 15:21:09 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:21:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:21:09 --> Model Class Initialized
INFO - 2016-06-15 18:21:09 --> Form Validation Class Initialized
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:21:09 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:21:09 --> Final output sent to browser
DEBUG - 2016-06-15 18:21:09 --> Total execution time: 0.0999
INFO - 2016-06-15 15:21:10 --> Config Class Initialized
INFO - 2016-06-15 15:21:10 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:21:10 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:10 --> Utf8 Class Initialized
INFO - 2016-06-15 15:21:10 --> URI Class Initialized
INFO - 2016-06-15 15:21:10 --> Router Class Initialized
INFO - 2016-06-15 15:21:10 --> Output Class Initialized
INFO - 2016-06-15 15:21:10 --> Security Class Initialized
DEBUG - 2016-06-15 15:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:10 --> Input Class Initialized
INFO - 2016-06-15 15:21:10 --> Language Class Initialized
INFO - 2016-06-15 15:21:10 --> Loader Class Initialized
INFO - 2016-06-15 15:21:10 --> Helper loaded: form_helper
INFO - 2016-06-15 15:21:10 --> Database Driver Class Initialized
INFO - 2016-06-15 15:21:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:21:10 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:21:10 --> Email Class Initialized
INFO - 2016-06-15 15:21:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:21:10 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:21:10 --> Helper loaded: language_helper
INFO - 2016-06-15 15:21:10 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:21:10 --> Model Class Initialized
INFO - 2016-06-15 15:21:10 --> Helper loaded: date_helper
INFO - 2016-06-15 15:21:10 --> Controller Class Initialized
INFO - 2016-06-15 15:21:10 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:21:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:21:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:21:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:21:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:21:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:21:10 --> Model Class Initialized
INFO - 2016-06-15 18:21:10 --> Form Validation Class Initialized
INFO - 2016-06-15 18:21:10 --> Final output sent to browser
DEBUG - 2016-06-15 18:21:10 --> Total execution time: 0.0984
INFO - 2016-06-15 15:21:19 --> Config Class Initialized
INFO - 2016-06-15 15:21:19 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:21:19 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:19 --> Utf8 Class Initialized
INFO - 2016-06-15 15:21:19 --> URI Class Initialized
INFO - 2016-06-15 15:21:19 --> Router Class Initialized
INFO - 2016-06-15 15:21:19 --> Output Class Initialized
INFO - 2016-06-15 15:21:19 --> Security Class Initialized
DEBUG - 2016-06-15 15:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:19 --> Input Class Initialized
INFO - 2016-06-15 15:21:19 --> Language Class Initialized
INFO - 2016-06-15 15:21:19 --> Loader Class Initialized
INFO - 2016-06-15 15:21:19 --> Helper loaded: form_helper
INFO - 2016-06-15 15:21:19 --> Database Driver Class Initialized
INFO - 2016-06-15 15:21:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:21:19 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:21:19 --> Email Class Initialized
INFO - 2016-06-15 15:21:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:21:19 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:21:19 --> Helper loaded: language_helper
INFO - 2016-06-15 15:21:19 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:21:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:21:19 --> Model Class Initialized
INFO - 2016-06-15 15:21:19 --> Helper loaded: date_helper
INFO - 2016-06-15 15:21:19 --> Controller Class Initialized
INFO - 2016-06-15 15:21:19 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:21:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:21:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:21:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:21:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:21:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:21:19 --> Model Class Initialized
INFO - 2016-06-15 18:21:19 --> Form Validation Class Initialized
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:21:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:21:19 --> Final output sent to browser
DEBUG - 2016-06-15 18:21:19 --> Total execution time: 0.1388
INFO - 2016-06-15 15:21:21 --> Config Class Initialized
INFO - 2016-06-15 15:21:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:21:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:21 --> Utf8 Class Initialized
INFO - 2016-06-15 15:21:21 --> URI Class Initialized
INFO - 2016-06-15 15:21:21 --> Router Class Initialized
INFO - 2016-06-15 15:21:21 --> Output Class Initialized
INFO - 2016-06-15 15:21:21 --> Security Class Initialized
DEBUG - 2016-06-15 15:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:21 --> Input Class Initialized
INFO - 2016-06-15 15:21:21 --> Language Class Initialized
INFO - 2016-06-15 15:21:21 --> Loader Class Initialized
INFO - 2016-06-15 15:21:21 --> Helper loaded: form_helper
INFO - 2016-06-15 15:21:21 --> Database Driver Class Initialized
INFO - 2016-06-15 15:21:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:21:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:21:21 --> Email Class Initialized
INFO - 2016-06-15 15:21:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:21:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:21:21 --> Helper loaded: language_helper
INFO - 2016-06-15 15:21:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:21:21 --> Model Class Initialized
INFO - 2016-06-15 15:21:21 --> Helper loaded: date_helper
INFO - 2016-06-15 15:21:21 --> Controller Class Initialized
INFO - 2016-06-15 15:21:21 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:21:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:21:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:21:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:21:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:21:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:21:21 --> Model Class Initialized
INFO - 2016-06-15 18:21:21 --> Form Validation Class Initialized
INFO - 2016-06-15 18:21:21 --> Final output sent to browser
DEBUG - 2016-06-15 18:21:21 --> Total execution time: 0.1001
INFO - 2016-06-15 15:21:49 --> Config Class Initialized
INFO - 2016-06-15 15:21:49 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:21:49 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:49 --> Utf8 Class Initialized
INFO - 2016-06-15 15:21:49 --> URI Class Initialized
INFO - 2016-06-15 15:21:49 --> Router Class Initialized
INFO - 2016-06-15 15:21:49 --> Output Class Initialized
INFO - 2016-06-15 15:21:49 --> Security Class Initialized
DEBUG - 2016-06-15 15:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:49 --> Input Class Initialized
INFO - 2016-06-15 15:21:49 --> Language Class Initialized
INFO - 2016-06-15 15:21:49 --> Loader Class Initialized
INFO - 2016-06-15 15:21:49 --> Helper loaded: form_helper
INFO - 2016-06-15 15:21:49 --> Database Driver Class Initialized
INFO - 2016-06-15 15:21:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:21:49 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:21:49 --> Email Class Initialized
INFO - 2016-06-15 15:21:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:21:49 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:21:49 --> Helper loaded: language_helper
INFO - 2016-06-15 15:21:49 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:21:49 --> Model Class Initialized
INFO - 2016-06-15 15:21:49 --> Helper loaded: date_helper
INFO - 2016-06-15 15:21:49 --> Controller Class Initialized
INFO - 2016-06-15 15:21:49 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:21:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:21:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:21:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:21:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:21:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:21:49 --> Model Class Initialized
INFO - 2016-06-15 18:21:49 --> Form Validation Class Initialized
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:21:49 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:21:49 --> Final output sent to browser
DEBUG - 2016-06-15 18:21:49 --> Total execution time: 0.1146
INFO - 2016-06-15 15:21:51 --> Config Class Initialized
INFO - 2016-06-15 15:21:51 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:21:51 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:21:51 --> Utf8 Class Initialized
INFO - 2016-06-15 15:21:51 --> URI Class Initialized
INFO - 2016-06-15 15:21:51 --> Router Class Initialized
INFO - 2016-06-15 15:21:51 --> Output Class Initialized
INFO - 2016-06-15 15:21:51 --> Security Class Initialized
DEBUG - 2016-06-15 15:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:21:51 --> Input Class Initialized
INFO - 2016-06-15 15:21:51 --> Language Class Initialized
INFO - 2016-06-15 15:21:51 --> Loader Class Initialized
INFO - 2016-06-15 15:21:51 --> Helper loaded: form_helper
INFO - 2016-06-15 15:21:51 --> Database Driver Class Initialized
INFO - 2016-06-15 15:21:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:21:51 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:21:51 --> Email Class Initialized
INFO - 2016-06-15 15:21:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:21:51 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:21:51 --> Helper loaded: language_helper
INFO - 2016-06-15 15:21:51 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:21:51 --> Model Class Initialized
INFO - 2016-06-15 15:21:51 --> Helper loaded: date_helper
INFO - 2016-06-15 15:21:51 --> Controller Class Initialized
INFO - 2016-06-15 15:21:51 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:21:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:21:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:21:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:21:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:21:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:21:51 --> Model Class Initialized
INFO - 2016-06-15 18:21:51 --> Form Validation Class Initialized
INFO - 2016-06-15 18:21:51 --> Final output sent to browser
DEBUG - 2016-06-15 18:21:51 --> Total execution time: 0.0852
INFO - 2016-06-15 15:22:14 --> Config Class Initialized
INFO - 2016-06-15 15:22:14 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:22:14 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:22:14 --> Utf8 Class Initialized
INFO - 2016-06-15 15:22:14 --> URI Class Initialized
INFO - 2016-06-15 15:22:14 --> Router Class Initialized
INFO - 2016-06-15 15:22:14 --> Output Class Initialized
INFO - 2016-06-15 15:22:14 --> Security Class Initialized
DEBUG - 2016-06-15 15:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:22:14 --> Input Class Initialized
INFO - 2016-06-15 15:22:14 --> Language Class Initialized
INFO - 2016-06-15 15:22:14 --> Loader Class Initialized
INFO - 2016-06-15 15:22:14 --> Helper loaded: form_helper
INFO - 2016-06-15 15:22:14 --> Database Driver Class Initialized
INFO - 2016-06-15 15:22:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:22:14 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:22:14 --> Email Class Initialized
INFO - 2016-06-15 15:22:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:22:14 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:22:14 --> Helper loaded: language_helper
INFO - 2016-06-15 15:22:14 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:22:14 --> Model Class Initialized
INFO - 2016-06-15 15:22:14 --> Helper loaded: date_helper
INFO - 2016-06-15 15:22:14 --> Controller Class Initialized
INFO - 2016-06-15 15:22:14 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:22:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:22:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:22:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:22:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:22:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:22:14 --> Model Class Initialized
INFO - 2016-06-15 18:22:14 --> Form Validation Class Initialized
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:22:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:22:14 --> Final output sent to browser
DEBUG - 2016-06-15 18:22:14 --> Total execution time: 0.1070
INFO - 2016-06-15 15:22:16 --> Config Class Initialized
INFO - 2016-06-15 15:22:16 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:22:16 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:22:16 --> Utf8 Class Initialized
INFO - 2016-06-15 15:22:16 --> URI Class Initialized
INFO - 2016-06-15 15:22:16 --> Router Class Initialized
INFO - 2016-06-15 15:22:16 --> Output Class Initialized
INFO - 2016-06-15 15:22:16 --> Security Class Initialized
DEBUG - 2016-06-15 15:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:22:16 --> Input Class Initialized
INFO - 2016-06-15 15:22:16 --> Language Class Initialized
INFO - 2016-06-15 15:22:16 --> Loader Class Initialized
INFO - 2016-06-15 15:22:16 --> Helper loaded: form_helper
INFO - 2016-06-15 15:22:16 --> Database Driver Class Initialized
INFO - 2016-06-15 15:22:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:22:16 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:22:16 --> Email Class Initialized
INFO - 2016-06-15 15:22:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:22:16 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:22:16 --> Helper loaded: language_helper
INFO - 2016-06-15 15:22:16 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:22:16 --> Model Class Initialized
INFO - 2016-06-15 15:22:16 --> Helper loaded: date_helper
INFO - 2016-06-15 15:22:16 --> Controller Class Initialized
INFO - 2016-06-15 15:22:16 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:22:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:22:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:22:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:22:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:22:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:22:16 --> Model Class Initialized
INFO - 2016-06-15 18:22:16 --> Form Validation Class Initialized
INFO - 2016-06-15 18:22:16 --> Final output sent to browser
DEBUG - 2016-06-15 18:22:16 --> Total execution time: 0.0812
INFO - 2016-06-15 15:23:07 --> Config Class Initialized
INFO - 2016-06-15 15:23:07 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:23:07 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:23:07 --> Utf8 Class Initialized
INFO - 2016-06-15 15:23:07 --> URI Class Initialized
INFO - 2016-06-15 15:23:07 --> Router Class Initialized
INFO - 2016-06-15 15:23:07 --> Output Class Initialized
INFO - 2016-06-15 15:23:07 --> Security Class Initialized
DEBUG - 2016-06-15 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:23:07 --> Input Class Initialized
INFO - 2016-06-15 15:23:07 --> Language Class Initialized
INFO - 2016-06-15 15:23:07 --> Loader Class Initialized
INFO - 2016-06-15 15:23:07 --> Helper loaded: form_helper
INFO - 2016-06-15 15:23:07 --> Database Driver Class Initialized
INFO - 2016-06-15 15:23:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:23:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:23:07 --> Email Class Initialized
INFO - 2016-06-15 15:23:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:23:07 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:23:07 --> Helper loaded: language_helper
INFO - 2016-06-15 15:23:07 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:23:07 --> Model Class Initialized
INFO - 2016-06-15 15:23:07 --> Helper loaded: date_helper
INFO - 2016-06-15 15:23:07 --> Controller Class Initialized
INFO - 2016-06-15 15:23:07 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:23:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:23:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:23:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:23:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:23:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:23:07 --> Model Class Initialized
INFO - 2016-06-15 18:23:07 --> Form Validation Class Initialized
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:23:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:23:07 --> Final output sent to browser
DEBUG - 2016-06-15 18:23:07 --> Total execution time: 0.1103
INFO - 2016-06-15 15:23:09 --> Config Class Initialized
INFO - 2016-06-15 15:23:09 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:23:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:23:09 --> Utf8 Class Initialized
INFO - 2016-06-15 15:23:09 --> URI Class Initialized
INFO - 2016-06-15 15:23:09 --> Router Class Initialized
INFO - 2016-06-15 15:23:09 --> Output Class Initialized
INFO - 2016-06-15 15:23:09 --> Security Class Initialized
DEBUG - 2016-06-15 15:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:23:09 --> Input Class Initialized
INFO - 2016-06-15 15:23:09 --> Language Class Initialized
INFO - 2016-06-15 15:23:09 --> Loader Class Initialized
INFO - 2016-06-15 15:23:09 --> Helper loaded: form_helper
INFO - 2016-06-15 15:23:09 --> Database Driver Class Initialized
INFO - 2016-06-15 15:23:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:23:09 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:23:09 --> Email Class Initialized
INFO - 2016-06-15 15:23:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:23:09 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:23:09 --> Helper loaded: language_helper
INFO - 2016-06-15 15:23:09 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:23:09 --> Model Class Initialized
INFO - 2016-06-15 15:23:09 --> Helper loaded: date_helper
INFO - 2016-06-15 15:23:09 --> Controller Class Initialized
INFO - 2016-06-15 15:23:09 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:23:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:23:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:23:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:23:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:23:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:23:09 --> Model Class Initialized
INFO - 2016-06-15 18:23:09 --> Form Validation Class Initialized
INFO - 2016-06-15 18:23:09 --> Final output sent to browser
DEBUG - 2016-06-15 18:23:09 --> Total execution time: 0.1224
INFO - 2016-06-15 15:27:28 --> Config Class Initialized
INFO - 2016-06-15 15:27:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:27:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:27:28 --> Utf8 Class Initialized
INFO - 2016-06-15 15:27:28 --> URI Class Initialized
INFO - 2016-06-15 15:27:28 --> Router Class Initialized
INFO - 2016-06-15 15:27:28 --> Output Class Initialized
INFO - 2016-06-15 15:27:28 --> Security Class Initialized
DEBUG - 2016-06-15 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:27:28 --> Input Class Initialized
INFO - 2016-06-15 15:27:28 --> Language Class Initialized
INFO - 2016-06-15 15:27:28 --> Loader Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: form_helper
INFO - 2016-06-15 15:27:28 --> Database Driver Class Initialized
INFO - 2016-06-15 15:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:27:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:27:28 --> Email Class Initialized
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:27:28 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:27:28 --> Helper loaded: language_helper
INFO - 2016-06-15 15:27:28 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:27:28 --> Model Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: date_helper
INFO - 2016-06-15 15:27:28 --> Controller Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 18:27:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 18:27:28 --> Form Validation Class Initialized
DEBUG - 2016-06-15 18:27:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:27:28 --> Config Class Initialized
INFO - 2016-06-15 15:27:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:27:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:27:28 --> Utf8 Class Initialized
INFO - 2016-06-15 15:27:28 --> URI Class Initialized
DEBUG - 2016-06-15 15:27:28 --> No URI present. Default controller set.
INFO - 2016-06-15 15:27:28 --> Router Class Initialized
INFO - 2016-06-15 15:27:28 --> Output Class Initialized
INFO - 2016-06-15 15:27:28 --> Security Class Initialized
DEBUG - 2016-06-15 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:27:28 --> Input Class Initialized
INFO - 2016-06-15 15:27:28 --> Language Class Initialized
INFO - 2016-06-15 15:27:28 --> Loader Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: form_helper
INFO - 2016-06-15 15:27:28 --> Database Driver Class Initialized
INFO - 2016-06-15 15:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:27:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:27:28 --> Email Class Initialized
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:27:28 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:27:28 --> Helper loaded: language_helper
INFO - 2016-06-15 15:27:28 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:27:28 --> Model Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: date_helper
INFO - 2016-06-15 15:27:28 --> Controller Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:27:28 --> Config Class Initialized
INFO - 2016-06-15 15:27:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:27:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:27:28 --> Utf8 Class Initialized
INFO - 2016-06-15 15:27:28 --> URI Class Initialized
INFO - 2016-06-15 15:27:28 --> Router Class Initialized
INFO - 2016-06-15 15:27:28 --> Output Class Initialized
INFO - 2016-06-15 15:27:28 --> Security Class Initialized
DEBUG - 2016-06-15 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:27:28 --> Input Class Initialized
INFO - 2016-06-15 15:27:28 --> Language Class Initialized
INFO - 2016-06-15 15:27:28 --> Loader Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: form_helper
INFO - 2016-06-15 15:27:28 --> Database Driver Class Initialized
INFO - 2016-06-15 15:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:27:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:27:28 --> Email Class Initialized
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:27:28 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:27:28 --> Helper loaded: language_helper
INFO - 2016-06-15 15:27:28 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:27:28 --> Model Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: date_helper
INFO - 2016-06-15 15:27:28 --> Controller Class Initialized
INFO - 2016-06-15 15:27:28 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:27:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:27:28 --> Model Class Initialized
INFO - 2016-06-15 18:27:28 --> Form Validation Class Initialized
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:27:28 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:27:28 --> Final output sent to browser
DEBUG - 2016-06-15 18:27:28 --> Total execution time: 0.0910
INFO - 2016-06-15 15:27:31 --> Config Class Initialized
INFO - 2016-06-15 15:27:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:27:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:27:31 --> Utf8 Class Initialized
INFO - 2016-06-15 15:27:31 --> URI Class Initialized
INFO - 2016-06-15 15:27:31 --> Router Class Initialized
INFO - 2016-06-15 15:27:31 --> Output Class Initialized
INFO - 2016-06-15 15:27:31 --> Security Class Initialized
DEBUG - 2016-06-15 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:27:31 --> Input Class Initialized
INFO - 2016-06-15 15:27:31 --> Language Class Initialized
INFO - 2016-06-15 15:27:31 --> Loader Class Initialized
INFO - 2016-06-15 15:27:31 --> Helper loaded: form_helper
INFO - 2016-06-15 15:27:31 --> Database Driver Class Initialized
INFO - 2016-06-15 15:27:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:27:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:27:31 --> Email Class Initialized
INFO - 2016-06-15 15:27:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:27:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:27:31 --> Helper loaded: language_helper
INFO - 2016-06-15 15:27:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:27:31 --> Model Class Initialized
INFO - 2016-06-15 15:27:31 --> Helper loaded: date_helper
INFO - 2016-06-15 15:27:31 --> Controller Class Initialized
INFO - 2016-06-15 15:27:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:27:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:27:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:27:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:27:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:27:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:27:31 --> Model Class Initialized
INFO - 2016-06-15 18:27:31 --> Form Validation Class Initialized
INFO - 2016-06-15 18:27:31 --> Final output sent to browser
DEBUG - 2016-06-15 18:27:31 --> Total execution time: 0.0854
INFO - 2016-06-15 15:27:47 --> Config Class Initialized
INFO - 2016-06-15 15:27:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:27:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:27:47 --> Utf8 Class Initialized
INFO - 2016-06-15 15:27:47 --> URI Class Initialized
DEBUG - 2016-06-15 15:27:47 --> No URI present. Default controller set.
INFO - 2016-06-15 15:27:47 --> Router Class Initialized
INFO - 2016-06-15 15:27:47 --> Output Class Initialized
INFO - 2016-06-15 15:27:47 --> Security Class Initialized
DEBUG - 2016-06-15 15:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:27:47 --> Input Class Initialized
INFO - 2016-06-15 15:27:47 --> Language Class Initialized
INFO - 2016-06-15 15:27:47 --> Loader Class Initialized
INFO - 2016-06-15 15:27:47 --> Helper loaded: form_helper
INFO - 2016-06-15 15:27:47 --> Database Driver Class Initialized
INFO - 2016-06-15 15:27:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:27:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:27:47 --> Email Class Initialized
INFO - 2016-06-15 15:27:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:27:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:27:47 --> Helper loaded: language_helper
INFO - 2016-06-15 15:27:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:27:48 --> Model Class Initialized
INFO - 2016-06-15 15:27:48 --> Helper loaded: date_helper
INFO - 2016-06-15 15:27:48 --> Controller Class Initialized
INFO - 2016-06-15 15:27:48 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:27:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:27:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:27:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:27:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:27:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:27:48 --> Model Class Initialized
INFO - 2016-06-15 18:27:48 --> Form Validation Class Initialized
INFO - 2016-06-15 18:27:48 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 18:27:48 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 18:27:48 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 18:27:48 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 18:27:48 --> Final output sent to browser
DEBUG - 2016-06-15 18:27:48 --> Total execution time: 0.0909
INFO - 2016-06-15 15:27:49 --> Config Class Initialized
INFO - 2016-06-15 15:27:49 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:27:49 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:27:49 --> Utf8 Class Initialized
INFO - 2016-06-15 15:27:49 --> URI Class Initialized
INFO - 2016-06-15 15:27:49 --> Router Class Initialized
INFO - 2016-06-15 15:27:49 --> Output Class Initialized
INFO - 2016-06-15 15:27:49 --> Security Class Initialized
DEBUG - 2016-06-15 15:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:27:49 --> Input Class Initialized
INFO - 2016-06-15 15:27:49 --> Language Class Initialized
INFO - 2016-06-15 15:27:49 --> Loader Class Initialized
INFO - 2016-06-15 15:27:49 --> Helper loaded: form_helper
INFO - 2016-06-15 15:27:49 --> Database Driver Class Initialized
INFO - 2016-06-15 15:27:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:27:49 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:27:49 --> Email Class Initialized
INFO - 2016-06-15 15:27:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:27:49 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:27:49 --> Helper loaded: language_helper
INFO - 2016-06-15 15:27:49 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:27:49 --> Model Class Initialized
INFO - 2016-06-15 15:27:49 --> Helper loaded: date_helper
INFO - 2016-06-15 15:27:49 --> Controller Class Initialized
INFO - 2016-06-15 15:27:49 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:27:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:27:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:27:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:27:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:27:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:27:49 --> Model Class Initialized
INFO - 2016-06-15 18:27:49 --> Final output sent to browser
DEBUG - 2016-06-15 18:27:49 --> Total execution time: 0.0891
INFO - 2016-06-15 15:28:24 --> Config Class Initialized
INFO - 2016-06-15 15:28:24 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:24 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:24 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:24 --> URI Class Initialized
INFO - 2016-06-15 15:28:24 --> Router Class Initialized
INFO - 2016-06-15 15:28:24 --> Output Class Initialized
INFO - 2016-06-15 15:28:24 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:24 --> Input Class Initialized
INFO - 2016-06-15 15:28:24 --> Language Class Initialized
INFO - 2016-06-15 15:28:24 --> Loader Class Initialized
INFO - 2016-06-15 15:28:24 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:24 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:28:24 --> Email Class Initialized
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:24 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:24 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:24 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:24 --> Model Class Initialized
INFO - 2016-06-15 15:28:24 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:24 --> Controller Class Initialized
INFO - 2016-06-15 15:28:24 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-15 18:28:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-15 18:28:24 --> Form Validation Class Initialized
DEBUG - 2016-06-15 18:28:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:24 --> Config Class Initialized
INFO - 2016-06-15 15:28:24 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:24 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:24 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:24 --> URI Class Initialized
DEBUG - 2016-06-15 15:28:24 --> No URI present. Default controller set.
INFO - 2016-06-15 15:28:24 --> Router Class Initialized
INFO - 2016-06-15 15:28:24 --> Output Class Initialized
INFO - 2016-06-15 15:28:24 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:24 --> Input Class Initialized
INFO - 2016-06-15 15:28:24 --> Language Class Initialized
INFO - 2016-06-15 15:28:24 --> Loader Class Initialized
INFO - 2016-06-15 15:28:24 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:24 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:28:24 --> Email Class Initialized
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:24 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:24 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:24 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:24 --> Model Class Initialized
INFO - 2016-06-15 15:28:24 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:24 --> Controller Class Initialized
INFO - 2016-06-15 15:28:24 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 15:28:25 --> Config Class Initialized
INFO - 2016-06-15 15:28:25 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:25 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:25 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:25 --> URI Class Initialized
INFO - 2016-06-15 15:28:25 --> Router Class Initialized
INFO - 2016-06-15 15:28:25 --> Output Class Initialized
INFO - 2016-06-15 15:28:25 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:25 --> Input Class Initialized
INFO - 2016-06-15 15:28:25 --> Language Class Initialized
INFO - 2016-06-15 15:28:25 --> Loader Class Initialized
INFO - 2016-06-15 15:28:25 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:25 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:25 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:28:25 --> Email Class Initialized
INFO - 2016-06-15 15:28:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:25 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:25 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:25 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:25 --> Model Class Initialized
INFO - 2016-06-15 15:28:25 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:25 --> Controller Class Initialized
INFO - 2016-06-15 15:28:25 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:28:25 --> Model Class Initialized
INFO - 2016-06-15 18:28:25 --> Form Validation Class Initialized
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:28:25 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:28:25 --> Final output sent to browser
DEBUG - 2016-06-15 18:28:25 --> Total execution time: 0.1063
INFO - 2016-06-15 15:28:26 --> Config Class Initialized
INFO - 2016-06-15 15:28:26 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:26 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:26 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:26 --> URI Class Initialized
DEBUG - 2016-06-15 15:28:26 --> No URI present. Default controller set.
INFO - 2016-06-15 15:28:26 --> Router Class Initialized
INFO - 2016-06-15 15:28:26 --> Output Class Initialized
INFO - 2016-06-15 15:28:26 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:26 --> Input Class Initialized
INFO - 2016-06-15 15:28:26 --> Language Class Initialized
INFO - 2016-06-15 15:28:26 --> Loader Class Initialized
INFO - 2016-06-15 15:28:26 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:26 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:27 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:28:27 --> Email Class Initialized
INFO - 2016-06-15 15:28:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:27 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:27 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:27 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:27 --> Model Class Initialized
INFO - 2016-06-15 15:28:27 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:27 --> Controller Class Initialized
INFO - 2016-06-15 15:28:27 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:28:27 --> Model Class Initialized
INFO - 2016-06-15 18:28:27 --> Form Validation Class Initialized
INFO - 2016-06-15 18:28:27 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 18:28:27 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 18:28:27 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 18:28:27 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 18:28:27 --> Final output sent to browser
DEBUG - 2016-06-15 18:28:27 --> Total execution time: 0.1000
INFO - 2016-06-15 15:28:28 --> Config Class Initialized
INFO - 2016-06-15 15:28:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:28 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:28 --> URI Class Initialized
INFO - 2016-06-15 15:28:28 --> Router Class Initialized
INFO - 2016-06-15 15:28:28 --> Output Class Initialized
INFO - 2016-06-15 15:28:28 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:28 --> Input Class Initialized
INFO - 2016-06-15 15:28:28 --> Language Class Initialized
INFO - 2016-06-15 15:28:28 --> Loader Class Initialized
INFO - 2016-06-15 15:28:28 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:28 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:28:28 --> Email Class Initialized
INFO - 2016-06-15 15:28:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:28 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:28 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:28 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:28 --> Model Class Initialized
INFO - 2016-06-15 15:28:28 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:28 --> Controller Class Initialized
INFO - 2016-06-15 15:28:28 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:28:28 --> Model Class Initialized
INFO - 2016-06-15 18:28:28 --> Final output sent to browser
DEBUG - 2016-06-15 18:28:28 --> Total execution time: 0.0948
INFO - 2016-06-15 15:28:29 --> Config Class Initialized
INFO - 2016-06-15 15:28:29 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:29 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:29 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:29 --> URI Class Initialized
INFO - 2016-06-15 15:28:29 --> Router Class Initialized
INFO - 2016-06-15 15:28:29 --> Output Class Initialized
INFO - 2016-06-15 15:28:29 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:29 --> Input Class Initialized
INFO - 2016-06-15 15:28:29 --> Language Class Initialized
ERROR - 2016-06-15 15:28:29 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-15 15:28:31 --> Config Class Initialized
INFO - 2016-06-15 15:28:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:28:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:28:31 --> Utf8 Class Initialized
INFO - 2016-06-15 15:28:31 --> URI Class Initialized
INFO - 2016-06-15 15:28:31 --> Router Class Initialized
INFO - 2016-06-15 15:28:31 --> Output Class Initialized
INFO - 2016-06-15 15:28:31 --> Security Class Initialized
DEBUG - 2016-06-15 15:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:28:31 --> Input Class Initialized
INFO - 2016-06-15 15:28:31 --> Language Class Initialized
INFO - 2016-06-15 15:28:31 --> Loader Class Initialized
INFO - 2016-06-15 15:28:31 --> Helper loaded: form_helper
INFO - 2016-06-15 15:28:31 --> Database Driver Class Initialized
INFO - 2016-06-15 15:28:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:28:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:28:31 --> Email Class Initialized
INFO - 2016-06-15 15:28:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:28:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:28:31 --> Helper loaded: language_helper
INFO - 2016-06-15 15:28:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:28:31 --> Model Class Initialized
INFO - 2016-06-15 15:28:31 --> Helper loaded: date_helper
INFO - 2016-06-15 15:28:31 --> Controller Class Initialized
INFO - 2016-06-15 15:28:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:28:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:28:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:28:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:28:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:28:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:28:31 --> Model Class Initialized
INFO - 2016-06-15 18:28:31 --> Form Validation Class Initialized
INFO - 2016-06-15 18:28:31 --> Final output sent to browser
DEBUG - 2016-06-15 18:28:31 --> Total execution time: 0.0833
INFO - 2016-06-15 15:29:08 --> Config Class Initialized
INFO - 2016-06-15 15:29:08 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:29:08 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:29:08 --> Utf8 Class Initialized
INFO - 2016-06-15 15:29:08 --> URI Class Initialized
INFO - 2016-06-15 15:29:08 --> Router Class Initialized
INFO - 2016-06-15 15:29:08 --> Output Class Initialized
INFO - 2016-06-15 15:29:08 --> Security Class Initialized
DEBUG - 2016-06-15 15:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:29:08 --> Input Class Initialized
INFO - 2016-06-15 15:29:08 --> Language Class Initialized
INFO - 2016-06-15 15:29:08 --> Loader Class Initialized
INFO - 2016-06-15 15:29:08 --> Helper loaded: form_helper
INFO - 2016-06-15 15:29:08 --> Database Driver Class Initialized
INFO - 2016-06-15 15:29:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:29:08 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:29:08 --> Email Class Initialized
INFO - 2016-06-15 15:29:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:29:08 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:29:08 --> Helper loaded: language_helper
INFO - 2016-06-15 15:29:08 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:29:08 --> Model Class Initialized
INFO - 2016-06-15 15:29:08 --> Helper loaded: date_helper
INFO - 2016-06-15 15:29:08 --> Controller Class Initialized
INFO - 2016-06-15 15:29:08 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:29:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:29:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:29:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:29:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:29:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:29:08 --> Model Class Initialized
INFO - 2016-06-15 18:29:08 --> Form Validation Class Initialized
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:29:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:29:08 --> Final output sent to browser
DEBUG - 2016-06-15 18:29:08 --> Total execution time: 0.1178
INFO - 2016-06-15 15:29:13 --> Config Class Initialized
INFO - 2016-06-15 15:29:13 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:29:13 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:29:13 --> Utf8 Class Initialized
INFO - 2016-06-15 15:29:13 --> URI Class Initialized
INFO - 2016-06-15 15:29:13 --> Router Class Initialized
INFO - 2016-06-15 15:29:13 --> Output Class Initialized
INFO - 2016-06-15 15:29:13 --> Security Class Initialized
DEBUG - 2016-06-15 15:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:29:13 --> Input Class Initialized
INFO - 2016-06-15 15:29:13 --> Language Class Initialized
INFO - 2016-06-15 15:29:13 --> Loader Class Initialized
INFO - 2016-06-15 15:29:13 --> Helper loaded: form_helper
INFO - 2016-06-15 15:29:13 --> Database Driver Class Initialized
INFO - 2016-06-15 15:29:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:29:13 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:29:13 --> Email Class Initialized
INFO - 2016-06-15 15:29:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:29:13 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:29:13 --> Helper loaded: language_helper
INFO - 2016-06-15 15:29:13 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:29:13 --> Model Class Initialized
INFO - 2016-06-15 15:29:13 --> Helper loaded: date_helper
INFO - 2016-06-15 15:29:13 --> Controller Class Initialized
INFO - 2016-06-15 15:29:13 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:29:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:29:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:29:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:29:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:29:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:29:13 --> Model Class Initialized
INFO - 2016-06-15 18:29:13 --> Form Validation Class Initialized
INFO - 2016-06-15 18:29:13 --> Final output sent to browser
DEBUG - 2016-06-15 18:29:13 --> Total execution time: 0.0987
INFO - 2016-06-15 15:31:30 --> Config Class Initialized
INFO - 2016-06-15 15:31:30 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:31:30 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:31:30 --> Utf8 Class Initialized
INFO - 2016-06-15 15:31:30 --> URI Class Initialized
INFO - 2016-06-15 15:31:30 --> Router Class Initialized
INFO - 2016-06-15 15:31:30 --> Output Class Initialized
INFO - 2016-06-15 15:31:30 --> Security Class Initialized
DEBUG - 2016-06-15 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:31:30 --> Input Class Initialized
INFO - 2016-06-15 15:31:30 --> Language Class Initialized
INFO - 2016-06-15 15:31:30 --> Loader Class Initialized
INFO - 2016-06-15 15:31:30 --> Helper loaded: form_helper
INFO - 2016-06-15 15:31:30 --> Database Driver Class Initialized
INFO - 2016-06-15 15:31:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:31:30 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:31:30 --> Email Class Initialized
INFO - 2016-06-15 15:31:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:31:30 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:31:30 --> Helper loaded: language_helper
INFO - 2016-06-15 15:31:30 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:31:30 --> Model Class Initialized
INFO - 2016-06-15 15:31:30 --> Helper loaded: date_helper
INFO - 2016-06-15 15:31:30 --> Controller Class Initialized
INFO - 2016-06-15 15:31:30 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:31:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:31:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:31:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:31:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:31:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:31:30 --> Model Class Initialized
INFO - 2016-06-15 18:31:30 --> Form Validation Class Initialized
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:31:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:31:30 --> Final output sent to browser
DEBUG - 2016-06-15 18:31:30 --> Total execution time: 0.1026
INFO - 2016-06-15 15:31:33 --> Config Class Initialized
INFO - 2016-06-15 15:31:33 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:31:33 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:31:33 --> Utf8 Class Initialized
INFO - 2016-06-15 15:31:33 --> URI Class Initialized
INFO - 2016-06-15 15:31:33 --> Router Class Initialized
INFO - 2016-06-15 15:31:33 --> Output Class Initialized
INFO - 2016-06-15 15:31:33 --> Security Class Initialized
DEBUG - 2016-06-15 15:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:31:33 --> Input Class Initialized
INFO - 2016-06-15 15:31:33 --> Language Class Initialized
INFO - 2016-06-15 15:31:33 --> Loader Class Initialized
INFO - 2016-06-15 15:31:33 --> Helper loaded: form_helper
INFO - 2016-06-15 15:31:33 --> Database Driver Class Initialized
INFO - 2016-06-15 15:31:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:31:33 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:31:33 --> Email Class Initialized
INFO - 2016-06-15 15:31:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:31:33 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:31:33 --> Helper loaded: language_helper
INFO - 2016-06-15 15:31:33 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:31:33 --> Model Class Initialized
INFO - 2016-06-15 15:31:33 --> Helper loaded: date_helper
INFO - 2016-06-15 15:31:33 --> Controller Class Initialized
INFO - 2016-06-15 15:31:33 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:31:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:31:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:31:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:31:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:31:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:31:33 --> Model Class Initialized
INFO - 2016-06-15 18:31:33 --> Form Validation Class Initialized
INFO - 2016-06-15 18:31:33 --> Final output sent to browser
DEBUG - 2016-06-15 18:31:33 --> Total execution time: 0.0814
INFO - 2016-06-15 15:31:53 --> Config Class Initialized
INFO - 2016-06-15 15:31:53 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:31:53 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:31:53 --> Utf8 Class Initialized
INFO - 2016-06-15 15:31:53 --> URI Class Initialized
INFO - 2016-06-15 15:31:53 --> Router Class Initialized
INFO - 2016-06-15 15:31:53 --> Output Class Initialized
INFO - 2016-06-15 15:31:53 --> Security Class Initialized
DEBUG - 2016-06-15 15:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:31:53 --> Input Class Initialized
INFO - 2016-06-15 15:31:53 --> Language Class Initialized
INFO - 2016-06-15 15:31:53 --> Loader Class Initialized
INFO - 2016-06-15 15:31:53 --> Helper loaded: form_helper
INFO - 2016-06-15 15:31:53 --> Database Driver Class Initialized
INFO - 2016-06-15 15:31:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:31:53 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:31:53 --> Email Class Initialized
INFO - 2016-06-15 15:31:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:31:53 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:31:53 --> Helper loaded: language_helper
INFO - 2016-06-15 15:31:53 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:31:53 --> Model Class Initialized
INFO - 2016-06-15 15:31:53 --> Helper loaded: date_helper
INFO - 2016-06-15 15:31:53 --> Controller Class Initialized
INFO - 2016-06-15 15:31:53 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:31:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:31:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:31:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:31:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:31:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:31:53 --> Model Class Initialized
INFO - 2016-06-15 18:31:53 --> Form Validation Class Initialized
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:31:53 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:31:53 --> Final output sent to browser
DEBUG - 2016-06-15 18:31:53 --> Total execution time: 0.1108
INFO - 2016-06-15 15:31:55 --> Config Class Initialized
INFO - 2016-06-15 15:31:55 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:31:55 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:31:55 --> Utf8 Class Initialized
INFO - 2016-06-15 15:31:55 --> URI Class Initialized
INFO - 2016-06-15 15:31:55 --> Router Class Initialized
INFO - 2016-06-15 15:31:55 --> Output Class Initialized
INFO - 2016-06-15 15:31:55 --> Security Class Initialized
DEBUG - 2016-06-15 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:31:55 --> Input Class Initialized
INFO - 2016-06-15 15:31:55 --> Language Class Initialized
INFO - 2016-06-15 15:31:55 --> Loader Class Initialized
INFO - 2016-06-15 15:31:55 --> Helper loaded: form_helper
INFO - 2016-06-15 15:31:55 --> Database Driver Class Initialized
INFO - 2016-06-15 15:31:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:31:55 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:31:55 --> Email Class Initialized
INFO - 2016-06-15 15:31:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:31:55 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:31:55 --> Helper loaded: language_helper
INFO - 2016-06-15 15:31:55 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:31:55 --> Model Class Initialized
INFO - 2016-06-15 15:31:55 --> Helper loaded: date_helper
INFO - 2016-06-15 15:31:55 --> Controller Class Initialized
INFO - 2016-06-15 15:31:55 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:31:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:31:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:31:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:31:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:31:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:31:55 --> Model Class Initialized
INFO - 2016-06-15 18:31:55 --> Form Validation Class Initialized
INFO - 2016-06-15 18:31:55 --> Final output sent to browser
DEBUG - 2016-06-15 18:31:55 --> Total execution time: 0.0897
INFO - 2016-06-15 15:32:31 --> Config Class Initialized
INFO - 2016-06-15 15:32:31 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:31 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:31 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:31 --> URI Class Initialized
INFO - 2016-06-15 15:32:31 --> Router Class Initialized
INFO - 2016-06-15 15:32:31 --> Output Class Initialized
INFO - 2016-06-15 15:32:31 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:31 --> Input Class Initialized
INFO - 2016-06-15 15:32:31 --> Language Class Initialized
INFO - 2016-06-15 15:32:31 --> Loader Class Initialized
INFO - 2016-06-15 15:32:31 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:31 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:32:31 --> Email Class Initialized
INFO - 2016-06-15 15:32:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:31 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:31 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:31 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:31 --> Model Class Initialized
INFO - 2016-06-15 15:32:31 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:31 --> Controller Class Initialized
INFO - 2016-06-15 15:32:31 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:32:31 --> Model Class Initialized
INFO - 2016-06-15 18:32:31 --> Form Validation Class Initialized
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:32:31 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:32:31 --> Final output sent to browser
DEBUG - 2016-06-15 18:32:31 --> Total execution time: 0.1312
INFO - 2016-06-15 15:32:33 --> Config Class Initialized
INFO - 2016-06-15 15:32:33 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:32:33 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:32:33 --> Utf8 Class Initialized
INFO - 2016-06-15 15:32:33 --> URI Class Initialized
INFO - 2016-06-15 15:32:33 --> Router Class Initialized
INFO - 2016-06-15 15:32:33 --> Output Class Initialized
INFO - 2016-06-15 15:32:33 --> Security Class Initialized
DEBUG - 2016-06-15 15:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:32:33 --> Input Class Initialized
INFO - 2016-06-15 15:32:33 --> Language Class Initialized
INFO - 2016-06-15 15:32:33 --> Loader Class Initialized
INFO - 2016-06-15 15:32:33 --> Helper loaded: form_helper
INFO - 2016-06-15 15:32:33 --> Database Driver Class Initialized
INFO - 2016-06-15 15:32:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:32:33 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:32:33 --> Email Class Initialized
INFO - 2016-06-15 15:32:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:32:33 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:32:33 --> Helper loaded: language_helper
INFO - 2016-06-15 15:32:33 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:32:33 --> Model Class Initialized
INFO - 2016-06-15 15:32:33 --> Helper loaded: date_helper
INFO - 2016-06-15 15:32:33 --> Controller Class Initialized
INFO - 2016-06-15 15:32:33 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:32:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:32:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:32:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:32:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:32:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:32:33 --> Model Class Initialized
INFO - 2016-06-15 18:32:33 --> Form Validation Class Initialized
INFO - 2016-06-15 18:32:33 --> Final output sent to browser
DEBUG - 2016-06-15 18:32:33 --> Total execution time: 0.0825
INFO - 2016-06-15 15:34:02 --> Config Class Initialized
INFO - 2016-06-15 15:34:02 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:34:02 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:34:02 --> Utf8 Class Initialized
INFO - 2016-06-15 15:34:02 --> URI Class Initialized
INFO - 2016-06-15 15:34:02 --> Router Class Initialized
INFO - 2016-06-15 15:34:02 --> Output Class Initialized
INFO - 2016-06-15 15:34:02 --> Security Class Initialized
DEBUG - 2016-06-15 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:34:02 --> Input Class Initialized
INFO - 2016-06-15 15:34:02 --> Language Class Initialized
INFO - 2016-06-15 15:34:02 --> Loader Class Initialized
INFO - 2016-06-15 15:34:02 --> Helper loaded: form_helper
INFO - 2016-06-15 15:34:02 --> Database Driver Class Initialized
INFO - 2016-06-15 15:34:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:34:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:34:02 --> Email Class Initialized
INFO - 2016-06-15 15:34:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:34:02 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:34:02 --> Helper loaded: language_helper
INFO - 2016-06-15 15:34:02 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:34:02 --> Model Class Initialized
INFO - 2016-06-15 15:34:02 --> Helper loaded: date_helper
INFO - 2016-06-15 15:34:02 --> Controller Class Initialized
INFO - 2016-06-15 15:34:02 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:34:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:34:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:34:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:34:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:34:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:34:02 --> Model Class Initialized
INFO - 2016-06-15 18:34:02 --> Form Validation Class Initialized
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:34:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:34:02 --> Final output sent to browser
DEBUG - 2016-06-15 18:34:02 --> Total execution time: 0.2250
INFO - 2016-06-15 15:34:05 --> Config Class Initialized
INFO - 2016-06-15 15:34:05 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:34:05 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:34:05 --> Utf8 Class Initialized
INFO - 2016-06-15 15:34:05 --> URI Class Initialized
INFO - 2016-06-15 15:34:05 --> Router Class Initialized
INFO - 2016-06-15 15:34:05 --> Output Class Initialized
INFO - 2016-06-15 15:34:05 --> Security Class Initialized
DEBUG - 2016-06-15 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:34:05 --> Input Class Initialized
INFO - 2016-06-15 15:34:05 --> Language Class Initialized
INFO - 2016-06-15 15:34:05 --> Loader Class Initialized
INFO - 2016-06-15 15:34:05 --> Helper loaded: form_helper
INFO - 2016-06-15 15:34:05 --> Database Driver Class Initialized
INFO - 2016-06-15 15:34:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:34:05 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:34:05 --> Email Class Initialized
INFO - 2016-06-15 15:34:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:34:05 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:34:05 --> Helper loaded: language_helper
INFO - 2016-06-15 15:34:05 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:34:05 --> Model Class Initialized
INFO - 2016-06-15 15:34:05 --> Helper loaded: date_helper
INFO - 2016-06-15 15:34:05 --> Controller Class Initialized
INFO - 2016-06-15 15:34:05 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:34:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:34:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:34:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:34:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:34:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:34:05 --> Model Class Initialized
INFO - 2016-06-15 18:34:05 --> Form Validation Class Initialized
INFO - 2016-06-15 18:34:05 --> Final output sent to browser
DEBUG - 2016-06-15 18:34:05 --> Total execution time: 0.0850
INFO - 2016-06-15 15:35:35 --> Config Class Initialized
INFO - 2016-06-15 15:35:35 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:35:35 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:35:35 --> Utf8 Class Initialized
INFO - 2016-06-15 15:35:35 --> URI Class Initialized
INFO - 2016-06-15 15:35:35 --> Router Class Initialized
INFO - 2016-06-15 15:35:35 --> Output Class Initialized
INFO - 2016-06-15 15:35:35 --> Security Class Initialized
DEBUG - 2016-06-15 15:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:35:35 --> Input Class Initialized
INFO - 2016-06-15 15:35:35 --> Language Class Initialized
INFO - 2016-06-15 15:35:35 --> Loader Class Initialized
INFO - 2016-06-15 15:35:35 --> Helper loaded: form_helper
INFO - 2016-06-15 15:35:35 --> Database Driver Class Initialized
INFO - 2016-06-15 15:35:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:35:35 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:35:35 --> Email Class Initialized
INFO - 2016-06-15 15:35:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:35:35 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:35:35 --> Helper loaded: language_helper
INFO - 2016-06-15 15:35:35 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:35:35 --> Model Class Initialized
INFO - 2016-06-15 15:35:35 --> Helper loaded: date_helper
INFO - 2016-06-15 15:35:35 --> Controller Class Initialized
INFO - 2016-06-15 15:35:35 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:35:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:35:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:35:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:35:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:35:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:35:35 --> Model Class Initialized
INFO - 2016-06-15 18:35:35 --> Form Validation Class Initialized
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:35:35 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:35:35 --> Final output sent to browser
DEBUG - 2016-06-15 18:35:35 --> Total execution time: 0.1010
INFO - 2016-06-15 15:35:37 --> Config Class Initialized
INFO - 2016-06-15 15:35:37 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:35:37 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:35:37 --> Utf8 Class Initialized
INFO - 2016-06-15 15:35:37 --> URI Class Initialized
INFO - 2016-06-15 15:35:37 --> Router Class Initialized
INFO - 2016-06-15 15:35:37 --> Output Class Initialized
INFO - 2016-06-15 15:35:37 --> Security Class Initialized
DEBUG - 2016-06-15 15:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:35:38 --> Input Class Initialized
INFO - 2016-06-15 15:35:38 --> Language Class Initialized
INFO - 2016-06-15 15:35:38 --> Loader Class Initialized
INFO - 2016-06-15 15:35:38 --> Helper loaded: form_helper
INFO - 2016-06-15 15:35:38 --> Database Driver Class Initialized
INFO - 2016-06-15 15:35:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:35:38 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:35:38 --> Email Class Initialized
INFO - 2016-06-15 15:35:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:35:38 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:35:38 --> Helper loaded: language_helper
INFO - 2016-06-15 15:35:38 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:35:38 --> Model Class Initialized
INFO - 2016-06-15 15:35:38 --> Helper loaded: date_helper
INFO - 2016-06-15 15:35:38 --> Controller Class Initialized
INFO - 2016-06-15 15:35:38 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:35:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:35:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:35:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:35:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:35:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:35:38 --> Model Class Initialized
INFO - 2016-06-15 18:35:38 --> Form Validation Class Initialized
INFO - 2016-06-15 18:35:38 --> Final output sent to browser
DEBUG - 2016-06-15 18:35:38 --> Total execution time: 0.0989
INFO - 2016-06-15 15:36:21 --> Config Class Initialized
INFO - 2016-06-15 15:36:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:36:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:36:21 --> Utf8 Class Initialized
INFO - 2016-06-15 15:36:21 --> URI Class Initialized
INFO - 2016-06-15 15:36:21 --> Router Class Initialized
INFO - 2016-06-15 15:36:21 --> Output Class Initialized
INFO - 2016-06-15 15:36:21 --> Security Class Initialized
DEBUG - 2016-06-15 15:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:36:21 --> Input Class Initialized
INFO - 2016-06-15 15:36:21 --> Language Class Initialized
INFO - 2016-06-15 15:36:21 --> Loader Class Initialized
INFO - 2016-06-15 15:36:21 --> Helper loaded: form_helper
INFO - 2016-06-15 15:36:21 --> Database Driver Class Initialized
INFO - 2016-06-15 15:36:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:36:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:36:21 --> Email Class Initialized
INFO - 2016-06-15 15:36:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:36:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:36:21 --> Helper loaded: language_helper
INFO - 2016-06-15 15:36:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:36:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:36:21 --> Model Class Initialized
INFO - 2016-06-15 15:36:21 --> Helper loaded: date_helper
INFO - 2016-06-15 15:36:21 --> Controller Class Initialized
INFO - 2016-06-15 15:36:21 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:36:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:36:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:36:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:36:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:36:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:36:21 --> Model Class Initialized
INFO - 2016-06-15 18:36:21 --> Form Validation Class Initialized
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:36:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:36:21 --> Final output sent to browser
DEBUG - 2016-06-15 18:36:21 --> Total execution time: 0.1017
INFO - 2016-06-15 15:36:23 --> Config Class Initialized
INFO - 2016-06-15 15:36:23 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:36:23 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:36:23 --> Utf8 Class Initialized
INFO - 2016-06-15 15:36:23 --> URI Class Initialized
INFO - 2016-06-15 15:36:23 --> Router Class Initialized
INFO - 2016-06-15 15:36:23 --> Output Class Initialized
INFO - 2016-06-15 15:36:23 --> Security Class Initialized
DEBUG - 2016-06-15 15:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:36:23 --> Input Class Initialized
INFO - 2016-06-15 15:36:23 --> Language Class Initialized
INFO - 2016-06-15 15:36:23 --> Loader Class Initialized
INFO - 2016-06-15 15:36:23 --> Helper loaded: form_helper
INFO - 2016-06-15 15:36:23 --> Database Driver Class Initialized
INFO - 2016-06-15 15:36:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:36:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:36:24 --> Email Class Initialized
INFO - 2016-06-15 15:36:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:36:24 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:36:24 --> Helper loaded: language_helper
INFO - 2016-06-15 15:36:24 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:36:24 --> Model Class Initialized
INFO - 2016-06-15 15:36:24 --> Helper loaded: date_helper
INFO - 2016-06-15 15:36:24 --> Controller Class Initialized
INFO - 2016-06-15 15:36:24 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:36:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:36:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:36:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:36:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:36:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:36:24 --> Model Class Initialized
INFO - 2016-06-15 18:36:24 --> Form Validation Class Initialized
INFO - 2016-06-15 18:36:24 --> Final output sent to browser
DEBUG - 2016-06-15 18:36:24 --> Total execution time: 0.0935
INFO - 2016-06-15 15:37:15 --> Config Class Initialized
INFO - 2016-06-15 15:37:15 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:37:15 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:37:15 --> Utf8 Class Initialized
INFO - 2016-06-15 15:37:15 --> URI Class Initialized
INFO - 2016-06-15 15:37:15 --> Router Class Initialized
INFO - 2016-06-15 15:37:15 --> Output Class Initialized
INFO - 2016-06-15 15:37:15 --> Security Class Initialized
DEBUG - 2016-06-15 15:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:37:15 --> Input Class Initialized
INFO - 2016-06-15 15:37:15 --> Language Class Initialized
INFO - 2016-06-15 15:37:15 --> Loader Class Initialized
INFO - 2016-06-15 15:37:15 --> Helper loaded: form_helper
INFO - 2016-06-15 15:37:15 --> Database Driver Class Initialized
INFO - 2016-06-15 15:37:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:37:15 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:37:15 --> Email Class Initialized
INFO - 2016-06-15 15:37:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:37:15 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:37:15 --> Helper loaded: language_helper
INFO - 2016-06-15 15:37:15 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:37:15 --> Model Class Initialized
INFO - 2016-06-15 15:37:15 --> Helper loaded: date_helper
INFO - 2016-06-15 15:37:15 --> Controller Class Initialized
INFO - 2016-06-15 15:37:15 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:37:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:37:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:37:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:37:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:37:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:37:15 --> Model Class Initialized
INFO - 2016-06-15 18:37:15 --> Form Validation Class Initialized
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:37:15 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:37:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:37:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:37:16 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:37:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:37:16 --> Final output sent to browser
DEBUG - 2016-06-15 18:37:16 --> Total execution time: 0.1068
INFO - 2016-06-15 15:37:18 --> Config Class Initialized
INFO - 2016-06-15 15:37:18 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:37:18 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:37:18 --> Utf8 Class Initialized
INFO - 2016-06-15 15:37:18 --> URI Class Initialized
INFO - 2016-06-15 15:37:18 --> Router Class Initialized
INFO - 2016-06-15 15:37:18 --> Output Class Initialized
INFO - 2016-06-15 15:37:18 --> Security Class Initialized
DEBUG - 2016-06-15 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:37:18 --> Input Class Initialized
INFO - 2016-06-15 15:37:18 --> Language Class Initialized
INFO - 2016-06-15 15:37:18 --> Loader Class Initialized
INFO - 2016-06-15 15:37:18 --> Helper loaded: form_helper
INFO - 2016-06-15 15:37:18 --> Database Driver Class Initialized
INFO - 2016-06-15 15:37:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:37:18 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:37:18 --> Email Class Initialized
INFO - 2016-06-15 15:37:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:37:18 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:37:18 --> Helper loaded: language_helper
INFO - 2016-06-15 15:37:18 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:37:18 --> Model Class Initialized
INFO - 2016-06-15 15:37:18 --> Helper loaded: date_helper
INFO - 2016-06-15 15:37:18 --> Controller Class Initialized
INFO - 2016-06-15 15:37:18 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:37:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:37:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:37:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:37:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:37:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:37:18 --> Model Class Initialized
INFO - 2016-06-15 18:37:18 --> Form Validation Class Initialized
INFO - 2016-06-15 18:37:18 --> Final output sent to browser
DEBUG - 2016-06-15 18:37:18 --> Total execution time: 0.1045
INFO - 2016-06-15 15:57:44 --> Config Class Initialized
INFO - 2016-06-15 15:57:44 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:57:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:57:44 --> Utf8 Class Initialized
INFO - 2016-06-15 15:57:44 --> URI Class Initialized
INFO - 2016-06-15 15:57:44 --> Router Class Initialized
INFO - 2016-06-15 15:57:44 --> Output Class Initialized
INFO - 2016-06-15 15:57:44 --> Security Class Initialized
DEBUG - 2016-06-15 15:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:57:44 --> Input Class Initialized
INFO - 2016-06-15 15:57:44 --> Language Class Initialized
INFO - 2016-06-15 15:57:44 --> Loader Class Initialized
INFO - 2016-06-15 15:57:44 --> Helper loaded: form_helper
INFO - 2016-06-15 15:57:44 --> Database Driver Class Initialized
INFO - 2016-06-15 15:57:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:57:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:57:44 --> Email Class Initialized
INFO - 2016-06-15 15:57:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:57:44 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:57:44 --> Helper loaded: language_helper
INFO - 2016-06-15 15:57:44 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:57:44 --> Model Class Initialized
INFO - 2016-06-15 15:57:44 --> Helper loaded: date_helper
INFO - 2016-06-15 15:57:44 --> Controller Class Initialized
INFO - 2016-06-15 15:57:44 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:57:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:57:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:57:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:57:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:57:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:57:44 --> Model Class Initialized
INFO - 2016-06-15 18:57:44 --> Form Validation Class Initialized
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:57:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:57:44 --> Final output sent to browser
DEBUG - 2016-06-15 18:57:44 --> Total execution time: 0.1261
INFO - 2016-06-15 15:57:47 --> Config Class Initialized
INFO - 2016-06-15 15:57:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:57:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:57:47 --> Utf8 Class Initialized
INFO - 2016-06-15 15:57:47 --> URI Class Initialized
INFO - 2016-06-15 15:57:47 --> Router Class Initialized
INFO - 2016-06-15 15:57:47 --> Output Class Initialized
INFO - 2016-06-15 15:57:47 --> Security Class Initialized
DEBUG - 2016-06-15 15:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:57:47 --> Input Class Initialized
INFO - 2016-06-15 15:57:47 --> Language Class Initialized
INFO - 2016-06-15 15:57:47 --> Loader Class Initialized
INFO - 2016-06-15 15:57:47 --> Helper loaded: form_helper
INFO - 2016-06-15 15:57:47 --> Database Driver Class Initialized
INFO - 2016-06-15 15:57:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:57:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:57:47 --> Email Class Initialized
INFO - 2016-06-15 15:57:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:57:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:57:47 --> Helper loaded: language_helper
INFO - 2016-06-15 15:57:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:57:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:57:47 --> Model Class Initialized
INFO - 2016-06-15 15:57:47 --> Helper loaded: date_helper
INFO - 2016-06-15 15:57:47 --> Controller Class Initialized
INFO - 2016-06-15 15:57:47 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:57:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:57:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:57:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:57:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:57:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:57:47 --> Model Class Initialized
INFO - 2016-06-15 18:57:47 --> Form Validation Class Initialized
INFO - 2016-06-15 18:57:47 --> Final output sent to browser
DEBUG - 2016-06-15 18:57:47 --> Total execution time: 0.0827
INFO - 2016-06-15 15:58:16 --> Config Class Initialized
INFO - 2016-06-15 15:58:16 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:58:16 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:58:16 --> Utf8 Class Initialized
INFO - 2016-06-15 15:58:16 --> URI Class Initialized
INFO - 2016-06-15 15:58:16 --> Router Class Initialized
INFO - 2016-06-15 15:58:16 --> Output Class Initialized
INFO - 2016-06-15 15:58:16 --> Security Class Initialized
DEBUG - 2016-06-15 15:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:58:16 --> Input Class Initialized
INFO - 2016-06-15 15:58:16 --> Language Class Initialized
INFO - 2016-06-15 15:58:16 --> Loader Class Initialized
INFO - 2016-06-15 15:58:16 --> Helper loaded: form_helper
INFO - 2016-06-15 15:58:16 --> Database Driver Class Initialized
INFO - 2016-06-15 15:58:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:58:16 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:58:16 --> Email Class Initialized
INFO - 2016-06-15 15:58:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:58:16 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:58:16 --> Helper loaded: language_helper
INFO - 2016-06-15 15:58:16 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:58:16 --> Model Class Initialized
INFO - 2016-06-15 15:58:16 --> Helper loaded: date_helper
INFO - 2016-06-15 15:58:16 --> Controller Class Initialized
INFO - 2016-06-15 15:58:16 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:58:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:58:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:58:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:58:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:58:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:58:16 --> Model Class Initialized
INFO - 2016-06-15 18:58:16 --> Form Validation Class Initialized
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:58:16 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:58:16 --> Final output sent to browser
DEBUG - 2016-06-15 18:58:16 --> Total execution time: 0.1019
INFO - 2016-06-15 15:58:18 --> Config Class Initialized
INFO - 2016-06-15 15:58:18 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:58:18 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:58:18 --> Utf8 Class Initialized
INFO - 2016-06-15 15:58:18 --> URI Class Initialized
INFO - 2016-06-15 15:58:18 --> Router Class Initialized
INFO - 2016-06-15 15:58:18 --> Output Class Initialized
INFO - 2016-06-15 15:58:18 --> Security Class Initialized
DEBUG - 2016-06-15 15:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:58:18 --> Input Class Initialized
INFO - 2016-06-15 15:58:18 --> Language Class Initialized
INFO - 2016-06-15 15:58:18 --> Loader Class Initialized
INFO - 2016-06-15 15:58:18 --> Helper loaded: form_helper
INFO - 2016-06-15 15:58:18 --> Database Driver Class Initialized
INFO - 2016-06-15 15:58:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:58:18 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:58:18 --> Email Class Initialized
INFO - 2016-06-15 15:58:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:58:18 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:58:18 --> Helper loaded: language_helper
INFO - 2016-06-15 15:58:18 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:58:18 --> Model Class Initialized
INFO - 2016-06-15 15:58:18 --> Helper loaded: date_helper
INFO - 2016-06-15 15:58:18 --> Controller Class Initialized
INFO - 2016-06-15 15:58:18 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:58:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:58:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:58:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:58:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:58:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:58:18 --> Model Class Initialized
INFO - 2016-06-15 18:58:18 --> Form Validation Class Initialized
INFO - 2016-06-15 18:58:18 --> Final output sent to browser
DEBUG - 2016-06-15 18:58:18 --> Total execution time: 0.0974
INFO - 2016-06-15 15:58:41 --> Config Class Initialized
INFO - 2016-06-15 15:58:41 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:58:41 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:58:41 --> Utf8 Class Initialized
INFO - 2016-06-15 15:58:41 --> URI Class Initialized
INFO - 2016-06-15 15:58:41 --> Router Class Initialized
INFO - 2016-06-15 15:58:41 --> Output Class Initialized
INFO - 2016-06-15 15:58:41 --> Security Class Initialized
DEBUG - 2016-06-15 15:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:58:41 --> Input Class Initialized
INFO - 2016-06-15 15:58:41 --> Language Class Initialized
INFO - 2016-06-15 15:58:41 --> Loader Class Initialized
INFO - 2016-06-15 15:58:41 --> Helper loaded: form_helper
INFO - 2016-06-15 15:58:41 --> Database Driver Class Initialized
INFO - 2016-06-15 15:58:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:58:41 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:58:41 --> Email Class Initialized
INFO - 2016-06-15 15:58:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:58:41 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:58:41 --> Helper loaded: language_helper
INFO - 2016-06-15 15:58:41 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:58:41 --> Model Class Initialized
INFO - 2016-06-15 15:58:41 --> Helper loaded: date_helper
INFO - 2016-06-15 15:58:41 --> Controller Class Initialized
INFO - 2016-06-15 15:58:41 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:58:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:58:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:58:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:58:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:58:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:58:41 --> Model Class Initialized
INFO - 2016-06-15 18:58:41 --> Form Validation Class Initialized
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:58:41 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:58:41 --> Final output sent to browser
DEBUG - 2016-06-15 18:58:41 --> Total execution time: 0.1042
INFO - 2016-06-15 15:58:42 --> Config Class Initialized
INFO - 2016-06-15 15:58:42 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:58:42 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:58:42 --> Utf8 Class Initialized
INFO - 2016-06-15 15:58:42 --> URI Class Initialized
INFO - 2016-06-15 15:58:42 --> Router Class Initialized
INFO - 2016-06-15 15:58:42 --> Output Class Initialized
INFO - 2016-06-15 15:58:42 --> Security Class Initialized
DEBUG - 2016-06-15 15:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:58:42 --> Input Class Initialized
INFO - 2016-06-15 15:58:42 --> Language Class Initialized
INFO - 2016-06-15 15:58:42 --> Loader Class Initialized
INFO - 2016-06-15 15:58:42 --> Helper loaded: form_helper
INFO - 2016-06-15 15:58:42 --> Database Driver Class Initialized
INFO - 2016-06-15 15:58:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:58:42 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:58:42 --> Email Class Initialized
INFO - 2016-06-15 15:58:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:58:42 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:58:42 --> Helper loaded: language_helper
INFO - 2016-06-15 15:58:42 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:58:42 --> Model Class Initialized
INFO - 2016-06-15 15:58:42 --> Helper loaded: date_helper
INFO - 2016-06-15 15:58:42 --> Controller Class Initialized
INFO - 2016-06-15 15:58:42 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:58:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:58:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:58:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:58:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:58:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:58:42 --> Model Class Initialized
INFO - 2016-06-15 18:58:42 --> Form Validation Class Initialized
INFO - 2016-06-15 18:58:42 --> Final output sent to browser
DEBUG - 2016-06-15 18:58:42 --> Total execution time: 0.0945
INFO - 2016-06-15 15:59:21 --> Config Class Initialized
INFO - 2016-06-15 15:59:21 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:59:21 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:59:21 --> Utf8 Class Initialized
INFO - 2016-06-15 15:59:21 --> URI Class Initialized
INFO - 2016-06-15 15:59:21 --> Router Class Initialized
INFO - 2016-06-15 15:59:21 --> Output Class Initialized
INFO - 2016-06-15 15:59:21 --> Security Class Initialized
DEBUG - 2016-06-15 15:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:59:21 --> Input Class Initialized
INFO - 2016-06-15 15:59:21 --> Language Class Initialized
INFO - 2016-06-15 15:59:21 --> Loader Class Initialized
INFO - 2016-06-15 15:59:21 --> Helper loaded: form_helper
INFO - 2016-06-15 15:59:21 --> Database Driver Class Initialized
INFO - 2016-06-15 15:59:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:59:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:59:21 --> Email Class Initialized
INFO - 2016-06-15 15:59:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:59:21 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:59:21 --> Helper loaded: language_helper
INFO - 2016-06-15 15:59:21 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:59:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:59:21 --> Model Class Initialized
INFO - 2016-06-15 15:59:21 --> Helper loaded: date_helper
INFO - 2016-06-15 15:59:21 --> Controller Class Initialized
INFO - 2016-06-15 15:59:21 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:59:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:59:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:59:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:59:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:59:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:59:21 --> Model Class Initialized
INFO - 2016-06-15 18:59:21 --> Form Validation Class Initialized
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 18:59:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 18:59:21 --> Final output sent to browser
DEBUG - 2016-06-15 18:59:21 --> Total execution time: 0.1276
INFO - 2016-06-15 15:59:23 --> Config Class Initialized
INFO - 2016-06-15 15:59:23 --> Hooks Class Initialized
DEBUG - 2016-06-15 15:59:23 --> UTF-8 Support Enabled
INFO - 2016-06-15 15:59:23 --> Utf8 Class Initialized
INFO - 2016-06-15 15:59:23 --> URI Class Initialized
INFO - 2016-06-15 15:59:23 --> Router Class Initialized
INFO - 2016-06-15 15:59:23 --> Output Class Initialized
INFO - 2016-06-15 15:59:23 --> Security Class Initialized
DEBUG - 2016-06-15 15:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 15:59:23 --> Input Class Initialized
INFO - 2016-06-15 15:59:23 --> Language Class Initialized
INFO - 2016-06-15 15:59:23 --> Loader Class Initialized
INFO - 2016-06-15 15:59:23 --> Helper loaded: form_helper
INFO - 2016-06-15 15:59:23 --> Database Driver Class Initialized
INFO - 2016-06-15 15:59:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 15:59:23 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 15:59:23 --> Email Class Initialized
INFO - 2016-06-15 15:59:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 15:59:23 --> Helper loaded: cookie_helper
INFO - 2016-06-15 15:59:23 --> Helper loaded: language_helper
INFO - 2016-06-15 15:59:23 --> Helper loaded: url_helper
DEBUG - 2016-06-15 15:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 15:59:23 --> Model Class Initialized
INFO - 2016-06-15 15:59:23 --> Helper loaded: date_helper
INFO - 2016-06-15 15:59:23 --> Controller Class Initialized
INFO - 2016-06-15 15:59:23 --> Helper loaded: languages_helper
INFO - 2016-06-15 15:59:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 15:59:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 15:59:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 15:59:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 15:59:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 18:59:23 --> Model Class Initialized
INFO - 2016-06-15 18:59:23 --> Form Validation Class Initialized
INFO - 2016-06-15 18:59:23 --> Final output sent to browser
DEBUG - 2016-06-15 18:59:23 --> Total execution time: 0.1080
INFO - 2016-06-15 16:00:12 --> Config Class Initialized
INFO - 2016-06-15 16:00:12 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:00:12 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:00:12 --> Utf8 Class Initialized
INFO - 2016-06-15 16:00:12 --> URI Class Initialized
INFO - 2016-06-15 16:00:12 --> Router Class Initialized
INFO - 2016-06-15 16:00:12 --> Output Class Initialized
INFO - 2016-06-15 16:00:12 --> Security Class Initialized
DEBUG - 2016-06-15 16:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:00:12 --> Input Class Initialized
INFO - 2016-06-15 16:00:12 --> Language Class Initialized
INFO - 2016-06-15 16:00:12 --> Loader Class Initialized
INFO - 2016-06-15 16:00:12 --> Helper loaded: form_helper
INFO - 2016-06-15 16:00:12 --> Database Driver Class Initialized
INFO - 2016-06-15 16:00:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:00:12 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:00:12 --> Email Class Initialized
INFO - 2016-06-15 16:00:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:00:12 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:00:12 --> Helper loaded: language_helper
INFO - 2016-06-15 16:00:12 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:00:12 --> Model Class Initialized
INFO - 2016-06-15 16:00:12 --> Helper loaded: date_helper
INFO - 2016-06-15 16:00:12 --> Controller Class Initialized
INFO - 2016-06-15 16:00:12 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:00:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:00:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:00:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:00:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:00:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:00:12 --> Model Class Initialized
INFO - 2016-06-15 19:00:12 --> Form Validation Class Initialized
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:00:12 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:00:12 --> Final output sent to browser
DEBUG - 2016-06-15 19:00:12 --> Total execution time: 0.1084
INFO - 2016-06-15 16:00:14 --> Config Class Initialized
INFO - 2016-06-15 16:00:14 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:00:14 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:00:14 --> Utf8 Class Initialized
INFO - 2016-06-15 16:00:14 --> URI Class Initialized
INFO - 2016-06-15 16:00:14 --> Router Class Initialized
INFO - 2016-06-15 16:00:14 --> Output Class Initialized
INFO - 2016-06-15 16:00:14 --> Security Class Initialized
DEBUG - 2016-06-15 16:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:00:14 --> Input Class Initialized
INFO - 2016-06-15 16:00:14 --> Language Class Initialized
INFO - 2016-06-15 16:00:14 --> Loader Class Initialized
INFO - 2016-06-15 16:00:14 --> Helper loaded: form_helper
INFO - 2016-06-15 16:00:14 --> Database Driver Class Initialized
INFO - 2016-06-15 16:00:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:00:14 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:00:14 --> Email Class Initialized
INFO - 2016-06-15 16:00:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:00:14 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:00:14 --> Helper loaded: language_helper
INFO - 2016-06-15 16:00:14 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:00:14 --> Model Class Initialized
INFO - 2016-06-15 16:00:14 --> Helper loaded: date_helper
INFO - 2016-06-15 16:00:14 --> Controller Class Initialized
INFO - 2016-06-15 16:00:14 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:00:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:00:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:00:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:00:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:00:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:00:14 --> Model Class Initialized
INFO - 2016-06-15 19:00:14 --> Form Validation Class Initialized
INFO - 2016-06-15 19:00:14 --> Final output sent to browser
DEBUG - 2016-06-15 19:00:14 --> Total execution time: 0.1160
INFO - 2016-06-15 16:01:20 --> Config Class Initialized
INFO - 2016-06-15 16:01:20 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:01:20 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:01:20 --> Utf8 Class Initialized
INFO - 2016-06-15 16:01:20 --> URI Class Initialized
INFO - 2016-06-15 16:01:20 --> Router Class Initialized
INFO - 2016-06-15 16:01:20 --> Output Class Initialized
INFO - 2016-06-15 16:01:20 --> Security Class Initialized
DEBUG - 2016-06-15 16:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:01:20 --> Input Class Initialized
INFO - 2016-06-15 16:01:20 --> Language Class Initialized
INFO - 2016-06-15 16:01:20 --> Loader Class Initialized
INFO - 2016-06-15 16:01:20 --> Helper loaded: form_helper
INFO - 2016-06-15 16:01:20 --> Database Driver Class Initialized
INFO - 2016-06-15 16:01:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:01:20 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:01:20 --> Email Class Initialized
INFO - 2016-06-15 16:01:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:01:20 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:01:20 --> Helper loaded: language_helper
INFO - 2016-06-15 16:01:20 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:01:20 --> Model Class Initialized
INFO - 2016-06-15 16:01:20 --> Helper loaded: date_helper
INFO - 2016-06-15 16:01:20 --> Controller Class Initialized
INFO - 2016-06-15 16:01:20 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:01:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:01:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:01:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:01:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:01:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:01:20 --> Model Class Initialized
INFO - 2016-06-15 19:01:20 --> Form Validation Class Initialized
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:01:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:01:20 --> Final output sent to browser
DEBUG - 2016-06-15 19:01:20 --> Total execution time: 0.1378
INFO - 2016-06-15 16:01:22 --> Config Class Initialized
INFO - 2016-06-15 16:01:22 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:01:22 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:01:22 --> Utf8 Class Initialized
INFO - 2016-06-15 16:01:22 --> URI Class Initialized
INFO - 2016-06-15 16:01:22 --> Router Class Initialized
INFO - 2016-06-15 16:01:22 --> Output Class Initialized
INFO - 2016-06-15 16:01:22 --> Security Class Initialized
DEBUG - 2016-06-15 16:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:01:22 --> Input Class Initialized
INFO - 2016-06-15 16:01:22 --> Language Class Initialized
INFO - 2016-06-15 16:01:22 --> Loader Class Initialized
INFO - 2016-06-15 16:01:22 --> Helper loaded: form_helper
INFO - 2016-06-15 16:01:22 --> Database Driver Class Initialized
INFO - 2016-06-15 16:01:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:01:22 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:01:22 --> Email Class Initialized
INFO - 2016-06-15 16:01:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:01:22 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:01:22 --> Helper loaded: language_helper
INFO - 2016-06-15 16:01:22 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:01:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:01:22 --> Model Class Initialized
INFO - 2016-06-15 16:01:22 --> Helper loaded: date_helper
INFO - 2016-06-15 16:01:22 --> Controller Class Initialized
INFO - 2016-06-15 16:01:22 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:01:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:01:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:01:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:01:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:01:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:01:22 --> Model Class Initialized
INFO - 2016-06-15 19:01:22 --> Form Validation Class Initialized
INFO - 2016-06-15 19:01:22 --> Final output sent to browser
DEBUG - 2016-06-15 19:01:22 --> Total execution time: 0.0854
INFO - 2016-06-15 16:02:43 --> Config Class Initialized
INFO - 2016-06-15 16:02:43 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:02:43 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:02:43 --> Utf8 Class Initialized
INFO - 2016-06-15 16:02:43 --> URI Class Initialized
INFO - 2016-06-15 16:02:43 --> Router Class Initialized
INFO - 2016-06-15 16:02:43 --> Output Class Initialized
INFO - 2016-06-15 16:02:43 --> Security Class Initialized
DEBUG - 2016-06-15 16:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:02:43 --> Input Class Initialized
INFO - 2016-06-15 16:02:43 --> Language Class Initialized
INFO - 2016-06-15 16:02:43 --> Loader Class Initialized
INFO - 2016-06-15 16:02:43 --> Helper loaded: form_helper
INFO - 2016-06-15 16:02:43 --> Database Driver Class Initialized
INFO - 2016-06-15 16:02:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:02:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:02:43 --> Email Class Initialized
INFO - 2016-06-15 16:02:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:02:43 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:02:43 --> Helper loaded: language_helper
INFO - 2016-06-15 16:02:43 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:02:43 --> Model Class Initialized
INFO - 2016-06-15 16:02:43 --> Helper loaded: date_helper
INFO - 2016-06-15 16:02:43 --> Controller Class Initialized
INFO - 2016-06-15 16:02:43 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:02:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:02:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:02:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:02:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:02:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:02:43 --> Model Class Initialized
INFO - 2016-06-15 19:02:43 --> Form Validation Class Initialized
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:02:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:02:43 --> Final output sent to browser
DEBUG - 2016-06-15 19:02:43 --> Total execution time: 0.1151
INFO - 2016-06-15 16:02:45 --> Config Class Initialized
INFO - 2016-06-15 16:02:45 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:02:45 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:02:45 --> Utf8 Class Initialized
INFO - 2016-06-15 16:02:45 --> URI Class Initialized
INFO - 2016-06-15 16:02:45 --> Router Class Initialized
INFO - 2016-06-15 16:02:45 --> Output Class Initialized
INFO - 2016-06-15 16:02:45 --> Security Class Initialized
DEBUG - 2016-06-15 16:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:02:45 --> Input Class Initialized
INFO - 2016-06-15 16:02:45 --> Language Class Initialized
INFO - 2016-06-15 16:02:45 --> Loader Class Initialized
INFO - 2016-06-15 16:02:45 --> Helper loaded: form_helper
INFO - 2016-06-15 16:02:45 --> Database Driver Class Initialized
INFO - 2016-06-15 16:02:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:02:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:02:45 --> Email Class Initialized
INFO - 2016-06-15 16:02:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:02:45 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:02:45 --> Helper loaded: language_helper
INFO - 2016-06-15 16:02:45 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:02:45 --> Model Class Initialized
INFO - 2016-06-15 16:02:45 --> Helper loaded: date_helper
INFO - 2016-06-15 16:02:45 --> Controller Class Initialized
INFO - 2016-06-15 16:02:45 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:02:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:02:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:02:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:02:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:02:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:02:45 --> Model Class Initialized
INFO - 2016-06-15 19:02:45 --> Form Validation Class Initialized
INFO - 2016-06-15 19:02:45 --> Final output sent to browser
DEBUG - 2016-06-15 19:02:45 --> Total execution time: 0.0978
INFO - 2016-06-15 16:06:02 --> Config Class Initialized
INFO - 2016-06-15 16:06:02 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:06:02 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:06:02 --> Utf8 Class Initialized
INFO - 2016-06-15 16:06:02 --> URI Class Initialized
INFO - 2016-06-15 16:06:02 --> Router Class Initialized
INFO - 2016-06-15 16:06:02 --> Output Class Initialized
INFO - 2016-06-15 16:06:02 --> Security Class Initialized
DEBUG - 2016-06-15 16:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:06:02 --> Input Class Initialized
INFO - 2016-06-15 16:06:02 --> Language Class Initialized
INFO - 2016-06-15 16:06:02 --> Loader Class Initialized
INFO - 2016-06-15 16:06:02 --> Helper loaded: form_helper
INFO - 2016-06-15 16:06:02 --> Database Driver Class Initialized
INFO - 2016-06-15 16:06:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:06:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:06:02 --> Email Class Initialized
INFO - 2016-06-15 16:06:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:06:02 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:06:02 --> Helper loaded: language_helper
INFO - 2016-06-15 16:06:02 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:02 --> Model Class Initialized
INFO - 2016-06-15 16:06:02 --> Helper loaded: date_helper
INFO - 2016-06-15 16:06:02 --> Controller Class Initialized
INFO - 2016-06-15 16:06:02 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:06:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:06:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:06:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:06:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:06:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:06:02 --> Model Class Initialized
INFO - 2016-06-15 19:06:02 --> Form Validation Class Initialized
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:06:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:06:02 --> Final output sent to browser
DEBUG - 2016-06-15 19:06:02 --> Total execution time: 0.1313
INFO - 2016-06-15 16:06:04 --> Config Class Initialized
INFO - 2016-06-15 16:06:04 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:06:04 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:06:04 --> Utf8 Class Initialized
INFO - 2016-06-15 16:06:04 --> URI Class Initialized
INFO - 2016-06-15 16:06:04 --> Router Class Initialized
INFO - 2016-06-15 16:06:04 --> Output Class Initialized
INFO - 2016-06-15 16:06:04 --> Security Class Initialized
DEBUG - 2016-06-15 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:06:04 --> Input Class Initialized
INFO - 2016-06-15 16:06:04 --> Language Class Initialized
INFO - 2016-06-15 16:06:05 --> Loader Class Initialized
INFO - 2016-06-15 16:06:05 --> Helper loaded: form_helper
INFO - 2016-06-15 16:06:05 --> Database Driver Class Initialized
INFO - 2016-06-15 16:06:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:06:05 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:06:05 --> Email Class Initialized
INFO - 2016-06-15 16:06:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:06:05 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:06:05 --> Helper loaded: language_helper
INFO - 2016-06-15 16:06:05 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:05 --> Model Class Initialized
INFO - 2016-06-15 16:06:05 --> Helper loaded: date_helper
INFO - 2016-06-15 16:06:05 --> Controller Class Initialized
INFO - 2016-06-15 16:06:05 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:06:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:06:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:06:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:06:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:06:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:06:05 --> Model Class Initialized
INFO - 2016-06-15 19:06:05 --> Form Validation Class Initialized
INFO - 2016-06-15 19:06:05 --> Final output sent to browser
DEBUG - 2016-06-15 19:06:05 --> Total execution time: 0.0973
INFO - 2016-06-15 16:06:30 --> Config Class Initialized
INFO - 2016-06-15 16:06:30 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:06:30 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:06:30 --> Utf8 Class Initialized
INFO - 2016-06-15 16:06:30 --> URI Class Initialized
INFO - 2016-06-15 16:06:30 --> Router Class Initialized
INFO - 2016-06-15 16:06:30 --> Output Class Initialized
INFO - 2016-06-15 16:06:30 --> Security Class Initialized
DEBUG - 2016-06-15 16:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:06:30 --> Input Class Initialized
INFO - 2016-06-15 16:06:30 --> Language Class Initialized
INFO - 2016-06-15 16:06:30 --> Loader Class Initialized
INFO - 2016-06-15 16:06:30 --> Helper loaded: form_helper
INFO - 2016-06-15 16:06:30 --> Database Driver Class Initialized
INFO - 2016-06-15 16:06:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:06:30 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:06:30 --> Email Class Initialized
INFO - 2016-06-15 16:06:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:06:30 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:06:30 --> Helper loaded: language_helper
INFO - 2016-06-15 16:06:30 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:06:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:30 --> Model Class Initialized
INFO - 2016-06-15 16:06:30 --> Helper loaded: date_helper
INFO - 2016-06-15 16:06:30 --> Controller Class Initialized
INFO - 2016-06-15 16:06:30 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:06:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:06:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:06:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:06:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:06:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:06:30 --> Model Class Initialized
INFO - 2016-06-15 19:06:30 --> Form Validation Class Initialized
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:06:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:06:30 --> Final output sent to browser
DEBUG - 2016-06-15 19:06:30 --> Total execution time: 0.1117
INFO - 2016-06-15 16:06:32 --> Config Class Initialized
INFO - 2016-06-15 16:06:32 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:06:32 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:06:32 --> Utf8 Class Initialized
INFO - 2016-06-15 16:06:32 --> URI Class Initialized
INFO - 2016-06-15 16:06:32 --> Router Class Initialized
INFO - 2016-06-15 16:06:32 --> Output Class Initialized
INFO - 2016-06-15 16:06:32 --> Security Class Initialized
DEBUG - 2016-06-15 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:06:32 --> Input Class Initialized
INFO - 2016-06-15 16:06:32 --> Language Class Initialized
INFO - 2016-06-15 16:06:32 --> Loader Class Initialized
INFO - 2016-06-15 16:06:32 --> Helper loaded: form_helper
INFO - 2016-06-15 16:06:32 --> Database Driver Class Initialized
INFO - 2016-06-15 16:06:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:06:32 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:06:32 --> Email Class Initialized
INFO - 2016-06-15 16:06:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:06:32 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:06:32 --> Helper loaded: language_helper
INFO - 2016-06-15 16:06:32 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:06:32 --> Model Class Initialized
INFO - 2016-06-15 16:06:32 --> Helper loaded: date_helper
INFO - 2016-06-15 16:06:32 --> Controller Class Initialized
INFO - 2016-06-15 16:06:32 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:06:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:06:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:06:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:06:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:06:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:06:32 --> Model Class Initialized
INFO - 2016-06-15 19:06:32 --> Form Validation Class Initialized
INFO - 2016-06-15 19:06:32 --> Final output sent to browser
DEBUG - 2016-06-15 19:06:32 --> Total execution time: 0.1141
INFO - 2016-06-15 16:07:02 --> Config Class Initialized
INFO - 2016-06-15 16:07:02 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:07:02 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:07:02 --> Utf8 Class Initialized
INFO - 2016-06-15 16:07:02 --> URI Class Initialized
INFO - 2016-06-15 16:07:02 --> Router Class Initialized
INFO - 2016-06-15 16:07:02 --> Output Class Initialized
INFO - 2016-06-15 16:07:02 --> Security Class Initialized
DEBUG - 2016-06-15 16:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:07:02 --> Input Class Initialized
INFO - 2016-06-15 16:07:02 --> Language Class Initialized
INFO - 2016-06-15 16:07:02 --> Loader Class Initialized
INFO - 2016-06-15 16:07:02 --> Helper loaded: form_helper
INFO - 2016-06-15 16:07:02 --> Database Driver Class Initialized
INFO - 2016-06-15 16:07:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:07:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:07:02 --> Email Class Initialized
INFO - 2016-06-15 16:07:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:07:02 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:07:02 --> Helper loaded: language_helper
INFO - 2016-06-15 16:07:02 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:07:02 --> Model Class Initialized
INFO - 2016-06-15 16:07:02 --> Helper loaded: date_helper
INFO - 2016-06-15 16:07:02 --> Controller Class Initialized
INFO - 2016-06-15 16:07:02 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:07:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:07:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:07:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:07:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:07:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:07:03 --> Model Class Initialized
INFO - 2016-06-15 19:07:03 --> Form Validation Class Initialized
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:07:03 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:07:03 --> Final output sent to browser
DEBUG - 2016-06-15 19:07:03 --> Total execution time: 0.1290
INFO - 2016-06-15 16:07:05 --> Config Class Initialized
INFO - 2016-06-15 16:07:05 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:07:05 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:07:05 --> Utf8 Class Initialized
INFO - 2016-06-15 16:07:05 --> URI Class Initialized
INFO - 2016-06-15 16:07:05 --> Router Class Initialized
INFO - 2016-06-15 16:07:05 --> Output Class Initialized
INFO - 2016-06-15 16:07:05 --> Security Class Initialized
DEBUG - 2016-06-15 16:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:07:05 --> Input Class Initialized
INFO - 2016-06-15 16:07:05 --> Language Class Initialized
INFO - 2016-06-15 16:07:05 --> Loader Class Initialized
INFO - 2016-06-15 16:07:05 --> Helper loaded: form_helper
INFO - 2016-06-15 16:07:05 --> Database Driver Class Initialized
INFO - 2016-06-15 16:07:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:07:05 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:07:05 --> Email Class Initialized
INFO - 2016-06-15 16:07:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:07:05 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:07:05 --> Helper loaded: language_helper
INFO - 2016-06-15 16:07:05 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:07:05 --> Model Class Initialized
INFO - 2016-06-15 16:07:05 --> Helper loaded: date_helper
INFO - 2016-06-15 16:07:05 --> Controller Class Initialized
INFO - 2016-06-15 16:07:05 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:07:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:07:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:07:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:07:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:07:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:07:05 --> Model Class Initialized
INFO - 2016-06-15 19:07:05 --> Form Validation Class Initialized
INFO - 2016-06-15 19:07:05 --> Final output sent to browser
DEBUG - 2016-06-15 19:07:05 --> Total execution time: 0.0905
INFO - 2016-06-15 16:08:07 --> Config Class Initialized
INFO - 2016-06-15 16:08:07 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:08:07 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:08:07 --> Utf8 Class Initialized
INFO - 2016-06-15 16:08:07 --> URI Class Initialized
INFO - 2016-06-15 16:08:07 --> Router Class Initialized
INFO - 2016-06-15 16:08:07 --> Output Class Initialized
INFO - 2016-06-15 16:08:07 --> Security Class Initialized
DEBUG - 2016-06-15 16:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:08:07 --> Input Class Initialized
INFO - 2016-06-15 16:08:07 --> Language Class Initialized
INFO - 2016-06-15 16:08:07 --> Loader Class Initialized
INFO - 2016-06-15 16:08:07 --> Helper loaded: form_helper
INFO - 2016-06-15 16:08:07 --> Database Driver Class Initialized
INFO - 2016-06-15 16:08:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:08:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:08:07 --> Email Class Initialized
INFO - 2016-06-15 16:08:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:08:07 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:08:07 --> Helper loaded: language_helper
INFO - 2016-06-15 16:08:07 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:08:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:08:07 --> Model Class Initialized
INFO - 2016-06-15 16:08:07 --> Helper loaded: date_helper
INFO - 2016-06-15 16:08:07 --> Controller Class Initialized
INFO - 2016-06-15 16:08:07 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:08:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:08:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:08:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:08:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:08:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:08:07 --> Model Class Initialized
INFO - 2016-06-15 19:08:07 --> Form Validation Class Initialized
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:08:07 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:08:07 --> Final output sent to browser
DEBUG - 2016-06-15 19:08:07 --> Total execution time: 0.1116
INFO - 2016-06-15 16:08:09 --> Config Class Initialized
INFO - 2016-06-15 16:08:09 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:08:09 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:08:09 --> Utf8 Class Initialized
INFO - 2016-06-15 16:08:09 --> URI Class Initialized
INFO - 2016-06-15 16:08:09 --> Router Class Initialized
INFO - 2016-06-15 16:08:09 --> Output Class Initialized
INFO - 2016-06-15 16:08:09 --> Security Class Initialized
DEBUG - 2016-06-15 16:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:08:09 --> Input Class Initialized
INFO - 2016-06-15 16:08:09 --> Language Class Initialized
INFO - 2016-06-15 16:08:09 --> Loader Class Initialized
INFO - 2016-06-15 16:08:09 --> Helper loaded: form_helper
INFO - 2016-06-15 16:08:09 --> Database Driver Class Initialized
INFO - 2016-06-15 16:08:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:08:09 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:08:09 --> Email Class Initialized
INFO - 2016-06-15 16:08:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:08:09 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:08:09 --> Helper loaded: language_helper
INFO - 2016-06-15 16:08:09 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:08:09 --> Model Class Initialized
INFO - 2016-06-15 16:08:09 --> Helper loaded: date_helper
INFO - 2016-06-15 16:08:09 --> Controller Class Initialized
INFO - 2016-06-15 16:08:09 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:08:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:08:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:08:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:08:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:08:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:08:09 --> Model Class Initialized
INFO - 2016-06-15 19:08:09 --> Form Validation Class Initialized
INFO - 2016-06-15 19:08:09 --> Final output sent to browser
DEBUG - 2016-06-15 19:08:09 --> Total execution time: 0.0982
INFO - 2016-06-15 16:10:36 --> Config Class Initialized
INFO - 2016-06-15 16:10:36 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:10:36 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:10:36 --> Utf8 Class Initialized
INFO - 2016-06-15 16:10:36 --> URI Class Initialized
INFO - 2016-06-15 16:10:36 --> Router Class Initialized
INFO - 2016-06-15 16:10:36 --> Output Class Initialized
INFO - 2016-06-15 16:10:36 --> Security Class Initialized
DEBUG - 2016-06-15 16:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:10:36 --> Input Class Initialized
INFO - 2016-06-15 16:10:36 --> Language Class Initialized
INFO - 2016-06-15 16:10:36 --> Loader Class Initialized
INFO - 2016-06-15 16:10:36 --> Helper loaded: form_helper
INFO - 2016-06-15 16:10:36 --> Database Driver Class Initialized
INFO - 2016-06-15 16:10:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:10:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:10:36 --> Email Class Initialized
INFO - 2016-06-15 16:10:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:10:36 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:10:36 --> Helper loaded: language_helper
INFO - 2016-06-15 16:10:36 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:10:36 --> Model Class Initialized
INFO - 2016-06-15 16:10:36 --> Helper loaded: date_helper
INFO - 2016-06-15 16:10:36 --> Controller Class Initialized
INFO - 2016-06-15 16:10:36 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:10:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:10:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:10:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:10:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:10:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:10:36 --> Model Class Initialized
INFO - 2016-06-15 19:10:36 --> Form Validation Class Initialized
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:10:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:10:36 --> Final output sent to browser
DEBUG - 2016-06-15 19:10:36 --> Total execution time: 0.1369
INFO - 2016-06-15 16:10:38 --> Config Class Initialized
INFO - 2016-06-15 16:10:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:10:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:10:38 --> Utf8 Class Initialized
INFO - 2016-06-15 16:10:38 --> URI Class Initialized
INFO - 2016-06-15 16:10:38 --> Router Class Initialized
INFO - 2016-06-15 16:10:38 --> Output Class Initialized
INFO - 2016-06-15 16:10:38 --> Security Class Initialized
DEBUG - 2016-06-15 16:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:10:38 --> Input Class Initialized
INFO - 2016-06-15 16:10:38 --> Language Class Initialized
INFO - 2016-06-15 16:10:38 --> Loader Class Initialized
INFO - 2016-06-15 16:10:38 --> Helper loaded: form_helper
INFO - 2016-06-15 16:10:38 --> Database Driver Class Initialized
INFO - 2016-06-15 16:10:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:10:39 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:10:39 --> Email Class Initialized
INFO - 2016-06-15 16:10:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:10:39 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:10:39 --> Helper loaded: language_helper
INFO - 2016-06-15 16:10:39 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:10:39 --> Model Class Initialized
INFO - 2016-06-15 16:10:39 --> Helper loaded: date_helper
INFO - 2016-06-15 16:10:39 --> Controller Class Initialized
INFO - 2016-06-15 16:10:39 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:10:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:10:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:10:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:10:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:10:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:10:39 --> Model Class Initialized
INFO - 2016-06-15 19:10:39 --> Form Validation Class Initialized
INFO - 2016-06-15 19:10:39 --> Final output sent to browser
DEBUG - 2016-06-15 19:10:39 --> Total execution time: 0.0854
INFO - 2016-06-15 16:11:56 --> Config Class Initialized
INFO - 2016-06-15 16:11:56 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:11:56 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:11:56 --> Utf8 Class Initialized
INFO - 2016-06-15 16:11:56 --> URI Class Initialized
INFO - 2016-06-15 16:11:56 --> Router Class Initialized
INFO - 2016-06-15 16:11:56 --> Output Class Initialized
INFO - 2016-06-15 16:11:56 --> Security Class Initialized
DEBUG - 2016-06-15 16:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:11:56 --> Input Class Initialized
INFO - 2016-06-15 16:11:56 --> Language Class Initialized
INFO - 2016-06-15 16:11:56 --> Loader Class Initialized
INFO - 2016-06-15 16:11:56 --> Helper loaded: form_helper
INFO - 2016-06-15 16:11:56 --> Database Driver Class Initialized
INFO - 2016-06-15 16:11:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:11:56 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:11:56 --> Email Class Initialized
INFO - 2016-06-15 16:11:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:11:56 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:11:56 --> Helper loaded: language_helper
INFO - 2016-06-15 16:11:56 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:11:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:11:56 --> Model Class Initialized
INFO - 2016-06-15 16:11:56 --> Helper loaded: date_helper
INFO - 2016-06-15 16:11:56 --> Controller Class Initialized
INFO - 2016-06-15 16:11:56 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:11:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:11:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:11:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:11:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:11:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:11:56 --> Model Class Initialized
INFO - 2016-06-15 19:11:56 --> Form Validation Class Initialized
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:11:56 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:11:56 --> Final output sent to browser
DEBUG - 2016-06-15 19:11:56 --> Total execution time: 0.1199
INFO - 2016-06-15 16:11:58 --> Config Class Initialized
INFO - 2016-06-15 16:11:58 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:11:58 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:11:58 --> Utf8 Class Initialized
INFO - 2016-06-15 16:11:58 --> URI Class Initialized
INFO - 2016-06-15 16:11:58 --> Router Class Initialized
INFO - 2016-06-15 16:11:58 --> Output Class Initialized
INFO - 2016-06-15 16:11:58 --> Security Class Initialized
DEBUG - 2016-06-15 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:11:58 --> Input Class Initialized
INFO - 2016-06-15 16:11:58 --> Language Class Initialized
INFO - 2016-06-15 16:11:58 --> Loader Class Initialized
INFO - 2016-06-15 16:11:58 --> Helper loaded: form_helper
INFO - 2016-06-15 16:11:58 --> Database Driver Class Initialized
INFO - 2016-06-15 16:11:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:11:58 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:11:58 --> Email Class Initialized
INFO - 2016-06-15 16:11:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:11:58 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:11:58 --> Helper loaded: language_helper
INFO - 2016-06-15 16:11:58 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:11:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:11:58 --> Model Class Initialized
INFO - 2016-06-15 16:11:58 --> Helper loaded: date_helper
INFO - 2016-06-15 16:11:58 --> Controller Class Initialized
INFO - 2016-06-15 16:11:58 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:11:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:11:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:11:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:11:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:11:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:11:58 --> Model Class Initialized
INFO - 2016-06-15 19:11:58 --> Form Validation Class Initialized
INFO - 2016-06-15 19:11:58 --> Final output sent to browser
DEBUG - 2016-06-15 19:11:58 --> Total execution time: 0.0853
INFO - 2016-06-15 16:13:40 --> Config Class Initialized
INFO - 2016-06-15 16:13:40 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:13:40 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:13:40 --> Utf8 Class Initialized
INFO - 2016-06-15 16:13:40 --> URI Class Initialized
INFO - 2016-06-15 16:13:40 --> Router Class Initialized
INFO - 2016-06-15 16:13:40 --> Output Class Initialized
INFO - 2016-06-15 16:13:40 --> Security Class Initialized
DEBUG - 2016-06-15 16:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:13:40 --> Input Class Initialized
INFO - 2016-06-15 16:13:40 --> Language Class Initialized
INFO - 2016-06-15 16:13:40 --> Loader Class Initialized
INFO - 2016-06-15 16:13:40 --> Helper loaded: form_helper
INFO - 2016-06-15 16:13:40 --> Database Driver Class Initialized
INFO - 2016-06-15 16:13:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:13:40 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:13:40 --> Email Class Initialized
INFO - 2016-06-15 16:13:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:13:40 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:13:40 --> Helper loaded: language_helper
INFO - 2016-06-15 16:13:40 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:13:40 --> Model Class Initialized
INFO - 2016-06-15 16:13:40 --> Helper loaded: date_helper
INFO - 2016-06-15 16:13:40 --> Controller Class Initialized
INFO - 2016-06-15 16:13:40 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:13:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:13:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:13:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:13:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:13:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:13:40 --> Model Class Initialized
INFO - 2016-06-15 19:13:40 --> Form Validation Class Initialized
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:13:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:13:40 --> Final output sent to browser
DEBUG - 2016-06-15 19:13:40 --> Total execution time: 0.1218
INFO - 2016-06-15 16:13:48 --> Config Class Initialized
INFO - 2016-06-15 16:13:48 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:13:48 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:13:48 --> Utf8 Class Initialized
INFO - 2016-06-15 16:13:48 --> URI Class Initialized
INFO - 2016-06-15 16:13:48 --> Router Class Initialized
INFO - 2016-06-15 16:13:48 --> Output Class Initialized
INFO - 2016-06-15 16:13:48 --> Security Class Initialized
DEBUG - 2016-06-15 16:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:13:48 --> Input Class Initialized
INFO - 2016-06-15 16:13:48 --> Language Class Initialized
INFO - 2016-06-15 16:13:48 --> Loader Class Initialized
INFO - 2016-06-15 16:13:48 --> Helper loaded: form_helper
INFO - 2016-06-15 16:13:48 --> Database Driver Class Initialized
INFO - 2016-06-15 16:13:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:13:48 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:13:48 --> Email Class Initialized
INFO - 2016-06-15 16:13:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:13:48 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:13:48 --> Helper loaded: language_helper
INFO - 2016-06-15 16:13:48 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:13:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:13:48 --> Model Class Initialized
INFO - 2016-06-15 16:13:48 --> Helper loaded: date_helper
INFO - 2016-06-15 16:13:48 --> Controller Class Initialized
INFO - 2016-06-15 16:13:48 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:13:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:13:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:13:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:13:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:13:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:13:48 --> Model Class Initialized
INFO - 2016-06-15 19:13:48 --> Form Validation Class Initialized
INFO - 2016-06-15 19:13:49 --> Final output sent to browser
DEBUG - 2016-06-15 19:13:49 --> Total execution time: 0.0967
INFO - 2016-06-15 16:14:01 --> Config Class Initialized
INFO - 2016-06-15 16:14:01 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:14:01 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:14:01 --> Utf8 Class Initialized
INFO - 2016-06-15 16:14:01 --> URI Class Initialized
INFO - 2016-06-15 16:14:01 --> Router Class Initialized
INFO - 2016-06-15 16:14:01 --> Output Class Initialized
INFO - 2016-06-15 16:14:01 --> Security Class Initialized
DEBUG - 2016-06-15 16:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:14:01 --> Input Class Initialized
INFO - 2016-06-15 16:14:01 --> Language Class Initialized
INFO - 2016-06-15 16:14:01 --> Loader Class Initialized
INFO - 2016-06-15 16:14:01 --> Helper loaded: form_helper
INFO - 2016-06-15 16:14:01 --> Database Driver Class Initialized
INFO - 2016-06-15 16:14:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:14:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:14:01 --> Email Class Initialized
INFO - 2016-06-15 16:14:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:14:01 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:14:01 --> Helper loaded: language_helper
INFO - 2016-06-15 16:14:01 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:14:01 --> Model Class Initialized
INFO - 2016-06-15 16:14:01 --> Helper loaded: date_helper
INFO - 2016-06-15 16:14:01 --> Controller Class Initialized
INFO - 2016-06-15 16:14:01 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:14:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:14:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:14:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:14:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:14:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:14:01 --> Model Class Initialized
INFO - 2016-06-15 19:14:01 --> Form Validation Class Initialized
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:14:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:14:01 --> Final output sent to browser
DEBUG - 2016-06-15 19:14:01 --> Total execution time: 0.1206
INFO - 2016-06-15 16:14:03 --> Config Class Initialized
INFO - 2016-06-15 16:14:03 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:14:03 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:14:03 --> Utf8 Class Initialized
INFO - 2016-06-15 16:14:03 --> URI Class Initialized
INFO - 2016-06-15 16:14:03 --> Router Class Initialized
INFO - 2016-06-15 16:14:03 --> Output Class Initialized
INFO - 2016-06-15 16:14:03 --> Security Class Initialized
DEBUG - 2016-06-15 16:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:14:03 --> Input Class Initialized
INFO - 2016-06-15 16:14:03 --> Language Class Initialized
INFO - 2016-06-15 16:14:03 --> Loader Class Initialized
INFO - 2016-06-15 16:14:03 --> Helper loaded: form_helper
INFO - 2016-06-15 16:14:03 --> Database Driver Class Initialized
INFO - 2016-06-15 16:14:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:14:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:14:03 --> Email Class Initialized
INFO - 2016-06-15 16:14:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:14:03 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:14:03 --> Helper loaded: language_helper
INFO - 2016-06-15 16:14:03 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:14:03 --> Model Class Initialized
INFO - 2016-06-15 16:14:03 --> Helper loaded: date_helper
INFO - 2016-06-15 16:14:03 --> Controller Class Initialized
INFO - 2016-06-15 16:14:03 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:14:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:14:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:14:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:14:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:14:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:14:03 --> Model Class Initialized
INFO - 2016-06-15 19:14:03 --> Form Validation Class Initialized
INFO - 2016-06-15 19:14:03 --> Final output sent to browser
DEBUG - 2016-06-15 19:14:03 --> Total execution time: 0.0853
INFO - 2016-06-15 16:14:44 --> Config Class Initialized
INFO - 2016-06-15 16:14:44 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:14:44 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:14:44 --> Utf8 Class Initialized
INFO - 2016-06-15 16:14:44 --> URI Class Initialized
INFO - 2016-06-15 16:14:44 --> Router Class Initialized
INFO - 2016-06-15 16:14:44 --> Output Class Initialized
INFO - 2016-06-15 16:14:44 --> Security Class Initialized
DEBUG - 2016-06-15 16:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:14:44 --> Input Class Initialized
INFO - 2016-06-15 16:14:44 --> Language Class Initialized
INFO - 2016-06-15 16:14:44 --> Loader Class Initialized
INFO - 2016-06-15 16:14:44 --> Helper loaded: form_helper
INFO - 2016-06-15 16:14:44 --> Database Driver Class Initialized
INFO - 2016-06-15 16:14:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:14:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:14:44 --> Email Class Initialized
INFO - 2016-06-15 16:14:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:14:44 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:14:44 --> Helper loaded: language_helper
INFO - 2016-06-15 16:14:44 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:14:44 --> Model Class Initialized
INFO - 2016-06-15 16:14:44 --> Helper loaded: date_helper
INFO - 2016-06-15 16:14:44 --> Controller Class Initialized
INFO - 2016-06-15 16:14:44 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:14:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:14:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:14:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:14:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:14:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:14:44 --> Model Class Initialized
INFO - 2016-06-15 19:14:44 --> Form Validation Class Initialized
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:14:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:14:44 --> Final output sent to browser
DEBUG - 2016-06-15 19:14:44 --> Total execution time: 0.1095
INFO - 2016-06-15 16:14:46 --> Config Class Initialized
INFO - 2016-06-15 16:14:46 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:14:46 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:14:46 --> Utf8 Class Initialized
INFO - 2016-06-15 16:14:46 --> URI Class Initialized
INFO - 2016-06-15 16:14:46 --> Router Class Initialized
INFO - 2016-06-15 16:14:46 --> Output Class Initialized
INFO - 2016-06-15 16:14:46 --> Security Class Initialized
DEBUG - 2016-06-15 16:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:14:46 --> Input Class Initialized
INFO - 2016-06-15 16:14:46 --> Language Class Initialized
INFO - 2016-06-15 16:14:46 --> Loader Class Initialized
INFO - 2016-06-15 16:14:46 --> Helper loaded: form_helper
INFO - 2016-06-15 16:14:46 --> Database Driver Class Initialized
INFO - 2016-06-15 16:14:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:14:46 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:14:46 --> Email Class Initialized
INFO - 2016-06-15 16:14:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:14:46 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:14:46 --> Helper loaded: language_helper
INFO - 2016-06-15 16:14:46 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:14:46 --> Model Class Initialized
INFO - 2016-06-15 16:14:46 --> Helper loaded: date_helper
INFO - 2016-06-15 16:14:46 --> Controller Class Initialized
INFO - 2016-06-15 16:14:46 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:14:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:14:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:14:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:14:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:14:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:14:46 --> Model Class Initialized
INFO - 2016-06-15 19:14:46 --> Form Validation Class Initialized
INFO - 2016-06-15 19:14:46 --> Final output sent to browser
DEBUG - 2016-06-15 19:14:46 --> Total execution time: 0.0855
INFO - 2016-06-15 16:15:36 --> Config Class Initialized
INFO - 2016-06-15 16:15:36 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:15:36 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:15:36 --> Utf8 Class Initialized
INFO - 2016-06-15 16:15:36 --> URI Class Initialized
INFO - 2016-06-15 16:15:36 --> Router Class Initialized
INFO - 2016-06-15 16:15:36 --> Output Class Initialized
INFO - 2016-06-15 16:15:36 --> Security Class Initialized
DEBUG - 2016-06-15 16:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:15:36 --> Input Class Initialized
INFO - 2016-06-15 16:15:36 --> Language Class Initialized
INFO - 2016-06-15 16:15:36 --> Loader Class Initialized
INFO - 2016-06-15 16:15:36 --> Helper loaded: form_helper
INFO - 2016-06-15 16:15:36 --> Database Driver Class Initialized
INFO - 2016-06-15 16:15:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:15:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:15:36 --> Email Class Initialized
INFO - 2016-06-15 16:15:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:15:36 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:15:36 --> Helper loaded: language_helper
INFO - 2016-06-15 16:15:36 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:15:36 --> Model Class Initialized
INFO - 2016-06-15 16:15:36 --> Helper loaded: date_helper
INFO - 2016-06-15 16:15:36 --> Controller Class Initialized
INFO - 2016-06-15 16:15:36 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:15:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:15:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:15:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:15:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:15:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:15:36 --> Model Class Initialized
INFO - 2016-06-15 19:15:36 --> Form Validation Class Initialized
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:15:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:15:36 --> Final output sent to browser
DEBUG - 2016-06-15 19:15:36 --> Total execution time: 0.1452
INFO - 2016-06-15 16:15:38 --> Config Class Initialized
INFO - 2016-06-15 16:15:38 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:15:38 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:15:38 --> Utf8 Class Initialized
INFO - 2016-06-15 16:15:38 --> URI Class Initialized
INFO - 2016-06-15 16:15:38 --> Router Class Initialized
INFO - 2016-06-15 16:15:38 --> Output Class Initialized
INFO - 2016-06-15 16:15:38 --> Security Class Initialized
DEBUG - 2016-06-15 16:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:15:38 --> Input Class Initialized
INFO - 2016-06-15 16:15:38 --> Language Class Initialized
INFO - 2016-06-15 16:15:38 --> Loader Class Initialized
INFO - 2016-06-15 16:15:38 --> Helper loaded: form_helper
INFO - 2016-06-15 16:15:38 --> Database Driver Class Initialized
INFO - 2016-06-15 16:15:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:15:38 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:15:38 --> Email Class Initialized
INFO - 2016-06-15 16:15:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:15:38 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:15:38 --> Helper loaded: language_helper
INFO - 2016-06-15 16:15:38 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:15:38 --> Model Class Initialized
INFO - 2016-06-15 16:15:38 --> Helper loaded: date_helper
INFO - 2016-06-15 16:15:38 --> Controller Class Initialized
INFO - 2016-06-15 16:15:38 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:15:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:15:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:15:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:15:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:15:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:15:38 --> Model Class Initialized
INFO - 2016-06-15 19:15:38 --> Form Validation Class Initialized
INFO - 2016-06-15 19:15:38 --> Final output sent to browser
DEBUG - 2016-06-15 19:15:38 --> Total execution time: 0.1310
INFO - 2016-06-15 16:20:47 --> Config Class Initialized
INFO - 2016-06-15 16:20:47 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:20:47 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:20:47 --> Utf8 Class Initialized
INFO - 2016-06-15 16:20:47 --> URI Class Initialized
INFO - 2016-06-15 16:20:47 --> Router Class Initialized
INFO - 2016-06-15 16:20:47 --> Output Class Initialized
INFO - 2016-06-15 16:20:47 --> Security Class Initialized
DEBUG - 2016-06-15 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:20:47 --> Input Class Initialized
INFO - 2016-06-15 16:20:47 --> Language Class Initialized
INFO - 2016-06-15 16:20:47 --> Loader Class Initialized
INFO - 2016-06-15 16:20:47 --> Helper loaded: form_helper
INFO - 2016-06-15 16:20:47 --> Database Driver Class Initialized
INFO - 2016-06-15 16:20:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:20:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:20:47 --> Email Class Initialized
INFO - 2016-06-15 16:20:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:20:47 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:20:47 --> Helper loaded: language_helper
INFO - 2016-06-15 16:20:47 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:20:47 --> Model Class Initialized
INFO - 2016-06-15 16:20:47 --> Helper loaded: date_helper
INFO - 2016-06-15 16:20:47 --> Controller Class Initialized
INFO - 2016-06-15 16:20:47 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:20:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:20:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:20:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:20:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:20:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:20:47 --> Model Class Initialized
INFO - 2016-06-15 19:20:47 --> Form Validation Class Initialized
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-15 19:20:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-15 19:20:47 --> Final output sent to browser
DEBUG - 2016-06-15 19:20:47 --> Total execution time: 0.1322
INFO - 2016-06-15 16:20:49 --> Config Class Initialized
INFO - 2016-06-15 16:20:49 --> Hooks Class Initialized
DEBUG - 2016-06-15 16:20:49 --> UTF-8 Support Enabled
INFO - 2016-06-15 16:20:49 --> Utf8 Class Initialized
INFO - 2016-06-15 16:20:49 --> URI Class Initialized
INFO - 2016-06-15 16:20:49 --> Router Class Initialized
INFO - 2016-06-15 16:20:49 --> Output Class Initialized
INFO - 2016-06-15 16:20:49 --> Security Class Initialized
DEBUG - 2016-06-15 16:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 16:20:49 --> Input Class Initialized
INFO - 2016-06-15 16:20:49 --> Language Class Initialized
INFO - 2016-06-15 16:20:49 --> Loader Class Initialized
INFO - 2016-06-15 16:20:49 --> Helper loaded: form_helper
INFO - 2016-06-15 16:20:49 --> Database Driver Class Initialized
INFO - 2016-06-15 16:20:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 16:20:49 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 16:20:49 --> Email Class Initialized
INFO - 2016-06-15 16:20:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 16:20:49 --> Helper loaded: cookie_helper
INFO - 2016-06-15 16:20:49 --> Helper loaded: language_helper
INFO - 2016-06-15 16:20:49 --> Helper loaded: url_helper
DEBUG - 2016-06-15 16:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 16:20:49 --> Model Class Initialized
INFO - 2016-06-15 16:20:49 --> Helper loaded: date_helper
INFO - 2016-06-15 16:20:49 --> Controller Class Initialized
INFO - 2016-06-15 16:20:49 --> Helper loaded: languages_helper
INFO - 2016-06-15 16:20:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 16:20:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 16:20:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 16:20:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 16:20:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 19:20:49 --> Model Class Initialized
INFO - 2016-06-15 19:20:49 --> Form Validation Class Initialized
INFO - 2016-06-15 19:20:49 --> Final output sent to browser
DEBUG - 2016-06-15 19:20:49 --> Total execution time: 0.0867
INFO - 2016-06-15 17:58:27 --> Config Class Initialized
INFO - 2016-06-15 17:58:27 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:58:27 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:58:27 --> Utf8 Class Initialized
INFO - 2016-06-15 17:58:27 --> URI Class Initialized
DEBUG - 2016-06-15 17:58:27 --> No URI present. Default controller set.
INFO - 2016-06-15 17:58:27 --> Router Class Initialized
INFO - 2016-06-15 17:58:27 --> Output Class Initialized
INFO - 2016-06-15 17:58:27 --> Security Class Initialized
DEBUG - 2016-06-15 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:58:27 --> Input Class Initialized
INFO - 2016-06-15 17:58:27 --> Language Class Initialized
INFO - 2016-06-15 17:58:27 --> Loader Class Initialized
INFO - 2016-06-15 17:58:27 --> Helper loaded: form_helper
INFO - 2016-06-15 17:58:27 --> Database Driver Class Initialized
INFO - 2016-06-15 17:58:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:58:27 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 17:58:27 --> Email Class Initialized
INFO - 2016-06-15 17:58:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:58:27 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:58:27 --> Helper loaded: language_helper
INFO - 2016-06-15 17:58:27 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:58:27 --> Model Class Initialized
INFO - 2016-06-15 17:58:27 --> Helper loaded: date_helper
INFO - 2016-06-15 17:58:27 --> Controller Class Initialized
INFO - 2016-06-15 17:58:27 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:58:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:58:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:58:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:58:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:58:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 20:58:27 --> Model Class Initialized
INFO - 2016-06-15 20:58:27 --> Form Validation Class Initialized
INFO - 2016-06-15 20:58:27 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 20:58:27 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 20:58:27 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 20:58:27 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 20:58:27 --> Final output sent to browser
DEBUG - 2016-06-15 20:58:27 --> Total execution time: 0.1040
INFO - 2016-06-15 17:58:30 --> Config Class Initialized
INFO - 2016-06-15 17:58:30 --> Hooks Class Initialized
DEBUG - 2016-06-15 17:58:30 --> UTF-8 Support Enabled
INFO - 2016-06-15 17:58:30 --> Utf8 Class Initialized
INFO - 2016-06-15 17:58:30 --> URI Class Initialized
INFO - 2016-06-15 17:58:30 --> Router Class Initialized
INFO - 2016-06-15 17:58:30 --> Output Class Initialized
INFO - 2016-06-15 17:58:30 --> Security Class Initialized
DEBUG - 2016-06-15 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 17:58:30 --> Input Class Initialized
INFO - 2016-06-15 17:58:30 --> Language Class Initialized
INFO - 2016-06-15 17:58:30 --> Loader Class Initialized
INFO - 2016-06-15 17:58:30 --> Helper loaded: form_helper
INFO - 2016-06-15 17:58:30 --> Database Driver Class Initialized
INFO - 2016-06-15 17:58:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 17:58:30 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 17:58:30 --> Email Class Initialized
INFO - 2016-06-15 17:58:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 17:58:30 --> Helper loaded: cookie_helper
INFO - 2016-06-15 17:58:30 --> Helper loaded: language_helper
INFO - 2016-06-15 17:58:30 --> Helper loaded: url_helper
DEBUG - 2016-06-15 17:58:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 17:58:30 --> Model Class Initialized
INFO - 2016-06-15 17:58:30 --> Helper loaded: date_helper
INFO - 2016-06-15 17:58:30 --> Controller Class Initialized
INFO - 2016-06-15 17:58:30 --> Helper loaded: languages_helper
INFO - 2016-06-15 17:58:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 17:58:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 17:58:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 17:58:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 17:58:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 20:58:30 --> Model Class Initialized
INFO - 2016-06-15 20:58:30 --> Final output sent to browser
DEBUG - 2016-06-15 20:58:30 --> Total execution time: 0.0968
INFO - 2016-06-15 18:23:07 --> Config Class Initialized
INFO - 2016-06-15 18:23:07 --> Hooks Class Initialized
DEBUG - 2016-06-15 18:23:07 --> UTF-8 Support Enabled
INFO - 2016-06-15 18:23:07 --> Utf8 Class Initialized
INFO - 2016-06-15 18:23:07 --> URI Class Initialized
INFO - 2016-06-15 18:23:07 --> Router Class Initialized
INFO - 2016-06-15 18:23:07 --> Output Class Initialized
INFO - 2016-06-15 18:23:07 --> Security Class Initialized
DEBUG - 2016-06-15 18:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 18:23:07 --> Input Class Initialized
INFO - 2016-06-15 18:23:07 --> Language Class Initialized
ERROR - 2016-06-15 18:23:07 --> 404 Page Not Found: Create_user/index
INFO - 2016-06-15 18:23:11 --> Config Class Initialized
INFO - 2016-06-15 18:23:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 18:23:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 18:23:11 --> Utf8 Class Initialized
INFO - 2016-06-15 18:23:11 --> URI Class Initialized
DEBUG - 2016-06-15 18:23:11 --> No URI present. Default controller set.
INFO - 2016-06-15 18:23:11 --> Router Class Initialized
INFO - 2016-06-15 18:23:11 --> Output Class Initialized
INFO - 2016-06-15 18:23:11 --> Security Class Initialized
DEBUG - 2016-06-15 18:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 18:23:11 --> Input Class Initialized
INFO - 2016-06-15 18:23:11 --> Language Class Initialized
INFO - 2016-06-15 18:23:11 --> Loader Class Initialized
INFO - 2016-06-15 18:23:11 --> Helper loaded: form_helper
INFO - 2016-06-15 18:23:11 --> Database Driver Class Initialized
INFO - 2016-06-15 18:23:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 18:23:11 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 18:23:11 --> Email Class Initialized
INFO - 2016-06-15 18:23:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 18:23:11 --> Helper loaded: cookie_helper
INFO - 2016-06-15 18:23:11 --> Helper loaded: language_helper
INFO - 2016-06-15 18:23:11 --> Helper loaded: url_helper
DEBUG - 2016-06-15 18:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 18:23:11 --> Model Class Initialized
INFO - 2016-06-15 18:23:11 --> Helper loaded: date_helper
INFO - 2016-06-15 18:23:11 --> Controller Class Initialized
INFO - 2016-06-15 18:23:11 --> Helper loaded: languages_helper
INFO - 2016-06-15 18:23:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 18:23:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 18:23:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 18:23:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 18:23:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 21:23:11 --> Model Class Initialized
INFO - 2016-06-15 21:23:11 --> Form Validation Class Initialized
INFO - 2016-06-15 21:23:11 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 21:23:11 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 21:23:11 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 21:23:11 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 21:23:11 --> Final output sent to browser
DEBUG - 2016-06-15 21:23:11 --> Total execution time: 0.1039
INFO - 2016-06-15 18:23:11 --> Config Class Initialized
INFO - 2016-06-15 18:23:11 --> Hooks Class Initialized
DEBUG - 2016-06-15 18:23:11 --> UTF-8 Support Enabled
INFO - 2016-06-15 18:23:11 --> Utf8 Class Initialized
INFO - 2016-06-15 18:23:11 --> URI Class Initialized
INFO - 2016-06-15 18:23:11 --> Router Class Initialized
INFO - 2016-06-15 18:23:11 --> Output Class Initialized
INFO - 2016-06-15 18:23:11 --> Security Class Initialized
DEBUG - 2016-06-15 18:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 18:23:11 --> Input Class Initialized
INFO - 2016-06-15 18:23:11 --> Language Class Initialized
INFO - 2016-06-15 18:23:11 --> Loader Class Initialized
INFO - 2016-06-15 18:23:11 --> Helper loaded: form_helper
INFO - 2016-06-15 18:23:11 --> Database Driver Class Initialized
INFO - 2016-06-15 18:23:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 18:23:12 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 18:23:12 --> Email Class Initialized
INFO - 2016-06-15 18:23:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 18:23:12 --> Helper loaded: cookie_helper
INFO - 2016-06-15 18:23:12 --> Helper loaded: language_helper
INFO - 2016-06-15 18:23:12 --> Helper loaded: url_helper
DEBUG - 2016-06-15 18:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 18:23:12 --> Model Class Initialized
INFO - 2016-06-15 18:23:12 --> Helper loaded: date_helper
INFO - 2016-06-15 18:23:12 --> Controller Class Initialized
INFO - 2016-06-15 18:23:12 --> Helper loaded: languages_helper
INFO - 2016-06-15 18:23:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 18:23:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 18:23:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 18:23:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 18:23:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 21:23:12 --> Model Class Initialized
INFO - 2016-06-15 21:23:12 --> Final output sent to browser
DEBUG - 2016-06-15 21:23:12 --> Total execution time: 0.0817
INFO - 2016-06-15 19:15:27 --> Config Class Initialized
INFO - 2016-06-15 19:15:27 --> Hooks Class Initialized
DEBUG - 2016-06-15 19:15:27 --> UTF-8 Support Enabled
INFO - 2016-06-15 19:15:27 --> Utf8 Class Initialized
INFO - 2016-06-15 19:15:27 --> URI Class Initialized
DEBUG - 2016-06-15 19:15:27 --> No URI present. Default controller set.
INFO - 2016-06-15 19:15:27 --> Router Class Initialized
INFO - 2016-06-15 19:15:27 --> Output Class Initialized
INFO - 2016-06-15 19:15:27 --> Security Class Initialized
DEBUG - 2016-06-15 19:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 19:15:27 --> Input Class Initialized
INFO - 2016-06-15 19:15:27 --> Language Class Initialized
INFO - 2016-06-15 19:15:27 --> Loader Class Initialized
INFO - 2016-06-15 19:15:27 --> Helper loaded: form_helper
INFO - 2016-06-15 19:15:27 --> Database Driver Class Initialized
INFO - 2016-06-15 19:15:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 19:15:27 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 19:15:27 --> Email Class Initialized
INFO - 2016-06-15 19:15:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 19:15:27 --> Helper loaded: cookie_helper
INFO - 2016-06-15 19:15:27 --> Helper loaded: language_helper
INFO - 2016-06-15 19:15:27 --> Helper loaded: url_helper
DEBUG - 2016-06-15 19:15:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 19:15:27 --> Model Class Initialized
INFO - 2016-06-15 19:15:27 --> Helper loaded: date_helper
INFO - 2016-06-15 19:15:27 --> Controller Class Initialized
INFO - 2016-06-15 19:15:27 --> Helper loaded: languages_helper
INFO - 2016-06-15 19:15:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 19:15:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 19:15:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 19:15:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 19:15:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 22:15:27 --> Model Class Initialized
INFO - 2016-06-15 22:15:27 --> Form Validation Class Initialized
INFO - 2016-06-15 22:15:27 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-15 22:15:27 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-15 22:15:27 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-15 22:15:27 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-15 22:15:27 --> Final output sent to browser
DEBUG - 2016-06-15 22:15:27 --> Total execution time: 0.0786
INFO - 2016-06-15 19:15:28 --> Config Class Initialized
INFO - 2016-06-15 19:15:28 --> Hooks Class Initialized
DEBUG - 2016-06-15 19:15:28 --> UTF-8 Support Enabled
INFO - 2016-06-15 19:15:28 --> Utf8 Class Initialized
INFO - 2016-06-15 19:15:28 --> URI Class Initialized
INFO - 2016-06-15 19:15:28 --> Router Class Initialized
INFO - 2016-06-15 19:15:28 --> Output Class Initialized
INFO - 2016-06-15 19:15:28 --> Security Class Initialized
DEBUG - 2016-06-15 19:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 19:15:28 --> Input Class Initialized
INFO - 2016-06-15 19:15:28 --> Language Class Initialized
INFO - 2016-06-15 19:15:28 --> Loader Class Initialized
INFO - 2016-06-15 19:15:28 --> Helper loaded: form_helper
INFO - 2016-06-15 19:15:29 --> Database Driver Class Initialized
INFO - 2016-06-15 19:15:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-15 19:15:29 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-15 19:15:29 --> Email Class Initialized
INFO - 2016-06-15 19:15:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-15 19:15:29 --> Helper loaded: cookie_helper
INFO - 2016-06-15 19:15:29 --> Helper loaded: language_helper
INFO - 2016-06-15 19:15:29 --> Helper loaded: url_helper
DEBUG - 2016-06-15 19:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-15 19:15:29 --> Model Class Initialized
INFO - 2016-06-15 19:15:29 --> Helper loaded: date_helper
INFO - 2016-06-15 19:15:29 --> Controller Class Initialized
INFO - 2016-06-15 19:15:29 --> Helper loaded: languages_helper
INFO - 2016-06-15 19:15:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-15 19:15:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-15 19:15:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-15 19:15:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-15 19:15:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-15 22:15:29 --> Model Class Initialized
INFO - 2016-06-15 22:15:29 --> Final output sent to browser
DEBUG - 2016-06-15 22:15:29 --> Total execution time: 0.0804
INFO - 2016-06-15 19:15:29 --> Config Class Initialized
INFO - 2016-06-15 19:15:29 --> Hooks Class Initialized
DEBUG - 2016-06-15 19:15:29 --> UTF-8 Support Enabled
INFO - 2016-06-15 19:15:29 --> Utf8 Class Initialized
INFO - 2016-06-15 19:15:29 --> URI Class Initialized
INFO - 2016-06-15 19:15:29 --> Router Class Initialized
INFO - 2016-06-15 19:15:29 --> Output Class Initialized
INFO - 2016-06-15 19:15:29 --> Security Class Initialized
DEBUG - 2016-06-15 19:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-15 19:15:29 --> Input Class Initialized
INFO - 2016-06-15 19:15:29 --> Language Class Initialized
ERROR - 2016-06-15 19:15:29 --> 404 Page Not Found: Faviconico/index
