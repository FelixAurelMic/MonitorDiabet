<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-30 02:00:40 --> Severity: Notice --> Undefined index: HTTP_HOST /home/diabet/public_html/application/config/config.php 26
INFO - 2016-06-30 02:00:40 --> Config Class Initialized
INFO - 2016-06-30 02:00:40 --> Hooks Class Initialized
DEBUG - 2016-06-30 02:00:40 --> UTF-8 Support Enabled
INFO - 2016-06-30 02:00:40 --> Utf8 Class Initialized
INFO - 2016-06-30 02:00:40 --> URI Class Initialized
DEBUG - 2016-06-30 02:00:40 --> No URI present. Default controller set.
INFO - 2016-06-30 02:00:40 --> Router Class Initialized
INFO - 2016-06-30 02:00:40 --> Output Class Initialized
INFO - 2016-06-30 02:00:40 --> Security Class Initialized
DEBUG - 2016-06-30 02:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-30 02:00:40 --> Input Class Initialized
INFO - 2016-06-30 02:00:40 --> Language Class Initialized
INFO - 2016-06-30 02:00:40 --> Loader Class Initialized
INFO - 2016-06-30 02:00:40 --> Helper loaded: form_helper
INFO - 2016-06-30 02:00:40 --> Database Driver Class Initialized
ERROR - 2016-06-30 02:00:40 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/application/config/config.php:26) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-30 02:00:40 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/application/config/config.php:26) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-30 02:00:40 --> Session: Class initialized using 'files' driver.
ERROR - 2016-06-30 02:00:40 --> Severity: Notice --> Undefined index: HTTP_HOST /home/diabet/public_html/application/config/ion_auth.php 85
ERROR - 2016-06-30 02:00:40 --> Severity: Notice --> Undefined index: HTTP_HOST /home/diabet/public_html/application/config/ion_auth.php 85
DEBUG - 2016-06-30 02:00:40 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-30 02:00:40 --> Email Class Initialized
INFO - 2016-06-30 02:00:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-30 02:00:40 --> Helper loaded: cookie_helper
INFO - 2016-06-30 02:00:40 --> Helper loaded: language_helper
INFO - 2016-06-30 02:00:40 --> Helper loaded: url_helper
DEBUG - 2016-06-30 02:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-30 02:00:40 --> Model Class Initialized
INFO - 2016-06-30 02:00:40 --> Helper loaded: date_helper
INFO - 2016-06-30 02:00:40 --> Controller Class Initialized
INFO - 2016-06-30 02:00:40 --> Helper loaded: languages_helper
INFO - 2016-06-30 02:00:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-30 02:00:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-30 02:00:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-30 02:00:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-30 02:00:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-30 05:00:40 --> Model Class Initialized
INFO - 2016-06-30 05:00:40 --> Form Validation Class Initialized
INFO - 2016-06-30 05:00:40 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-30 05:00:40 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-30 05:00:40 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-30 05:00:40 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-30 05:00:40 --> Final output sent to browser
DEBUG - 2016-06-30 05:00:40 --> Total execution time: 0.1132
INFO - 2016-06-30 04:52:13 --> Config Class Initialized
INFO - 2016-06-30 04:52:13 --> Hooks Class Initialized
DEBUG - 2016-06-30 04:52:13 --> UTF-8 Support Enabled
INFO - 2016-06-30 04:52:13 --> Utf8 Class Initialized
INFO - 2016-06-30 04:52:13 --> URI Class Initialized
INFO - 2016-06-30 04:52:13 --> Router Class Initialized
INFO - 2016-06-30 04:52:13 --> Output Class Initialized
INFO - 2016-06-30 04:52:13 --> Security Class Initialized
DEBUG - 2016-06-30 04:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-30 04:52:13 --> Input Class Initialized
INFO - 2016-06-30 04:52:13 --> Language Class Initialized
ERROR - 2016-06-30 04:52:13 --> 404 Page Not Found: Zcqqcom/cgi-bin
ERROR - 2016-06-30 09:41:02 --> Severity: Notice --> Undefined index: HTTP_HOST /home/diabet/public_html/application/config/config.php 26
INFO - 2016-06-30 09:41:02 --> Config Class Initialized
INFO - 2016-06-30 09:41:02 --> Hooks Class Initialized
DEBUG - 2016-06-30 09:41:02 --> UTF-8 Support Enabled
INFO - 2016-06-30 09:41:02 --> Utf8 Class Initialized
INFO - 2016-06-30 09:41:02 --> URI Class Initialized
DEBUG - 2016-06-30 09:41:02 --> No URI present. Default controller set.
INFO - 2016-06-30 09:41:02 --> Router Class Initialized
INFO - 2016-06-30 09:41:02 --> Output Class Initialized
INFO - 2016-06-30 09:41:02 --> Security Class Initialized
DEBUG - 2016-06-30 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-30 09:41:02 --> Input Class Initialized
INFO - 2016-06-30 09:41:02 --> Language Class Initialized
INFO - 2016-06-30 09:41:02 --> Loader Class Initialized
INFO - 2016-06-30 09:41:02 --> Helper loaded: form_helper
INFO - 2016-06-30 09:41:02 --> Database Driver Class Initialized
ERROR - 2016-06-30 09:41:02 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/application/config/config.php:26) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-30 09:41:02 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/application/config/config.php:26) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-30 09:41:02 --> Session: Class initialized using 'files' driver.
ERROR - 2016-06-30 09:41:02 --> Severity: Notice --> Undefined index: HTTP_HOST /home/diabet/public_html/application/config/ion_auth.php 85
ERROR - 2016-06-30 09:41:02 --> Severity: Notice --> Undefined index: HTTP_HOST /home/diabet/public_html/application/config/ion_auth.php 85
DEBUG - 2016-06-30 09:41:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-30 09:41:02 --> Email Class Initialized
INFO - 2016-06-30 09:41:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-30 09:41:02 --> Helper loaded: cookie_helper
INFO - 2016-06-30 09:41:02 --> Helper loaded: language_helper
INFO - 2016-06-30 09:41:02 --> Helper loaded: url_helper
DEBUG - 2016-06-30 09:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-30 09:41:02 --> Model Class Initialized
INFO - 2016-06-30 09:41:02 --> Helper loaded: date_helper
INFO - 2016-06-30 09:41:02 --> Controller Class Initialized
INFO - 2016-06-30 09:41:02 --> Helper loaded: languages_helper
INFO - 2016-06-30 09:41:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-30 09:41:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-30 09:41:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-30 09:41:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-30 09:41:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-30 12:41:02 --> Model Class Initialized
INFO - 2016-06-30 12:41:02 --> Form Validation Class Initialized
INFO - 2016-06-30 12:41:02 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-30 12:41:02 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-30 12:41:02 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-30 12:41:02 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-30 12:41:02 --> Final output sent to browser
DEBUG - 2016-06-30 12:41:02 --> Total execution time: 0.1026
INFO - 2016-06-30 15:39:06 --> Config Class Initialized
INFO - 2016-06-30 15:39:06 --> Hooks Class Initialized
DEBUG - 2016-06-30 15:39:06 --> UTF-8 Support Enabled
INFO - 2016-06-30 15:39:06 --> Utf8 Class Initialized
INFO - 2016-06-30 15:39:06 --> URI Class Initialized
INFO - 2016-06-30 15:39:06 --> Router Class Initialized
INFO - 2016-06-30 15:39:06 --> Output Class Initialized
INFO - 2016-06-30 15:39:06 --> Security Class Initialized
DEBUG - 2016-06-30 15:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-30 15:39:06 --> Input Class Initialized
INFO - 2016-06-30 15:39:06 --> Language Class Initialized
ERROR - 2016-06-30 15:39:06 --> 404 Page Not Found: 198278147/check.php
