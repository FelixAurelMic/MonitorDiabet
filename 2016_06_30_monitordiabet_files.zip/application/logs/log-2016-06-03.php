<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-03 10:41:17 --> Config Class Initialized
INFO - 2016-06-03 10:41:17 --> Hooks Class Initialized
DEBUG - 2016-06-03 10:41:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 10:41:18 --> Utf8 Class Initialized
INFO - 2016-06-03 10:41:18 --> URI Class Initialized
INFO - 2016-06-03 10:41:18 --> Router Class Initialized
INFO - 2016-06-03 10:41:18 --> Output Class Initialized
INFO - 2016-06-03 10:41:18 --> Security Class Initialized
DEBUG - 2016-06-03 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 10:41:18 --> CSRF cookie sent
INFO - 2016-06-03 10:41:18 --> Input Class Initialized
INFO - 2016-06-03 10:41:18 --> Language Class Initialized
ERROR - 2016-06-03 10:41:18 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-03 10:54:37 --> Config Class Initialized
INFO - 2016-06-03 10:54:37 --> Hooks Class Initialized
DEBUG - 2016-06-03 10:54:37 --> UTF-8 Support Enabled
INFO - 2016-06-03 10:54:37 --> Utf8 Class Initialized
INFO - 2016-06-03 10:54:37 --> URI Class Initialized
INFO - 2016-06-03 10:54:37 --> Router Class Initialized
INFO - 2016-06-03 10:54:37 --> Output Class Initialized
INFO - 2016-06-03 10:54:37 --> Security Class Initialized
DEBUG - 2016-06-03 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 10:54:37 --> CSRF cookie sent
INFO - 2016-06-03 10:54:37 --> Input Class Initialized
INFO - 2016-06-03 10:54:37 --> Language Class Initialized
INFO - 2016-06-03 10:54:37 --> Loader Class Initialized
INFO - 2016-06-03 10:54:37 --> Helper loaded: form_helper
INFO - 2016-06-03 10:54:37 --> Database Driver Class Initialized
INFO - 2016-06-03 10:54:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 10:54:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 10:54:37 --> Email Class Initialized
INFO - 2016-06-03 10:54:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 10:54:37 --> Helper loaded: cookie_helper
INFO - 2016-06-03 10:54:37 --> Helper loaded: language_helper
INFO - 2016-06-03 10:54:37 --> Helper loaded: url_helper
DEBUG - 2016-06-03 10:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 10:54:38 --> Model Class Initialized
INFO - 2016-06-03 10:54:38 --> Helper loaded: date_helper
INFO - 2016-06-03 10:54:38 --> Controller Class Initialized
INFO - 2016-06-03 10:54:38 --> Helper loaded: languages_helper
INFO - 2016-06-03 10:54:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 10:54:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 10:54:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 10:54:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 10:54:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 10:54:38 --> Model Class Initialized
INFO - 2016-06-03 10:54:38 --> Form Validation Class Initialized
INFO - 2016-06-03 10:54:39 --> Config Class Initialized
INFO - 2016-06-03 10:54:39 --> Hooks Class Initialized
DEBUG - 2016-06-03 10:54:39 --> UTF-8 Support Enabled
INFO - 2016-06-03 10:54:39 --> Utf8 Class Initialized
INFO - 2016-06-03 10:54:39 --> URI Class Initialized
INFO - 2016-06-03 10:54:39 --> Router Class Initialized
INFO - 2016-06-03 10:54:39 --> Output Class Initialized
INFO - 2016-06-03 10:54:39 --> Security Class Initialized
DEBUG - 2016-06-03 10:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 10:54:39 --> CSRF cookie sent
INFO - 2016-06-03 10:54:39 --> Input Class Initialized
INFO - 2016-06-03 10:54:39 --> Language Class Initialized
INFO - 2016-06-03 10:54:39 --> Loader Class Initialized
INFO - 2016-06-03 10:54:39 --> Helper loaded: form_helper
INFO - 2016-06-03 10:54:39 --> Database Driver Class Initialized
INFO - 2016-06-03 10:54:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 10:54:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 10:54:39 --> Email Class Initialized
INFO - 2016-06-03 10:54:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 10:54:39 --> Helper loaded: cookie_helper
INFO - 2016-06-03 10:54:39 --> Helper loaded: language_helper
INFO - 2016-06-03 10:54:39 --> Helper loaded: url_helper
DEBUG - 2016-06-03 10:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 10:54:39 --> Model Class Initialized
INFO - 2016-06-03 10:54:39 --> Helper loaded: date_helper
INFO - 2016-06-03 10:54:39 --> Controller Class Initialized
INFO - 2016-06-03 10:54:39 --> Helper loaded: languages_helper
INFO - 2016-06-03 10:54:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 10:54:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 10:54:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 10:54:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 10:54:39 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 10:54:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 10:54:39 --> Form Validation Class Initialized
INFO - 2016-06-03 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 10:54:39 --> Final output sent to browser
DEBUG - 2016-06-03 10:54:39 --> Total execution time: 0.1013
INFO - 2016-06-03 11:04:29 --> Config Class Initialized
INFO - 2016-06-03 11:04:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:04:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:04:29 --> Utf8 Class Initialized
INFO - 2016-06-03 11:04:29 --> URI Class Initialized
INFO - 2016-06-03 11:04:29 --> Router Class Initialized
INFO - 2016-06-03 11:04:29 --> Output Class Initialized
INFO - 2016-06-03 11:04:29 --> Security Class Initialized
DEBUG - 2016-06-03 11:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:04:29 --> CSRF cookie sent
INFO - 2016-06-03 11:04:29 --> CSRF token verified
INFO - 2016-06-03 11:04:29 --> Input Class Initialized
INFO - 2016-06-03 11:04:29 --> Language Class Initialized
INFO - 2016-06-03 11:04:29 --> Loader Class Initialized
INFO - 2016-06-03 11:04:29 --> Helper loaded: form_helper
INFO - 2016-06-03 11:04:29 --> Database Driver Class Initialized
INFO - 2016-06-03 11:04:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:04:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:04:29 --> Email Class Initialized
INFO - 2016-06-03 11:04:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:04:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:04:29 --> Helper loaded: language_helper
INFO - 2016-06-03 11:04:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:04:29 --> Model Class Initialized
INFO - 2016-06-03 11:04:29 --> Helper loaded: date_helper
INFO - 2016-06-03 11:04:29 --> Controller Class Initialized
INFO - 2016-06-03 11:04:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:04:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:04:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:04:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:04:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:04:29 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 11:04:29 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:04:29 --> Form Validation Class Initialized
INFO - 2016-06-03 11:04:30 --> Config Class Initialized
INFO - 2016-06-03 11:04:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:04:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:04:30 --> Utf8 Class Initialized
INFO - 2016-06-03 11:04:30 --> URI Class Initialized
DEBUG - 2016-06-03 11:04:30 --> No URI present. Default controller set.
INFO - 2016-06-03 11:04:30 --> Router Class Initialized
INFO - 2016-06-03 11:04:30 --> Output Class Initialized
INFO - 2016-06-03 11:04:30 --> Security Class Initialized
DEBUG - 2016-06-03 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:04:30 --> CSRF cookie sent
INFO - 2016-06-03 11:04:30 --> Input Class Initialized
INFO - 2016-06-03 11:04:30 --> Language Class Initialized
INFO - 2016-06-03 11:04:30 --> Loader Class Initialized
INFO - 2016-06-03 11:04:30 --> Helper loaded: form_helper
INFO - 2016-06-03 11:04:30 --> Database Driver Class Initialized
INFO - 2016-06-03 11:04:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:04:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:04:30 --> Email Class Initialized
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:04:30 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:04:30 --> Helper loaded: language_helper
INFO - 2016-06-03 11:04:30 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:04:30 --> Model Class Initialized
INFO - 2016-06-03 11:04:30 --> Helper loaded: date_helper
INFO - 2016-06-03 11:04:30 --> Controller Class Initialized
INFO - 2016-06-03 11:04:30 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:04:30 --> Config Class Initialized
INFO - 2016-06-03 11:04:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:04:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:04:30 --> Utf8 Class Initialized
INFO - 2016-06-03 11:04:30 --> URI Class Initialized
INFO - 2016-06-03 11:04:30 --> Router Class Initialized
INFO - 2016-06-03 11:04:30 --> Output Class Initialized
INFO - 2016-06-03 11:04:30 --> Security Class Initialized
DEBUG - 2016-06-03 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:04:30 --> CSRF cookie sent
INFO - 2016-06-03 11:04:30 --> Input Class Initialized
INFO - 2016-06-03 11:04:30 --> Language Class Initialized
INFO - 2016-06-03 11:04:30 --> Loader Class Initialized
INFO - 2016-06-03 11:04:30 --> Helper loaded: form_helper
INFO - 2016-06-03 11:04:30 --> Database Driver Class Initialized
INFO - 2016-06-03 11:04:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:04:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:04:30 --> Email Class Initialized
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:04:30 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:04:30 --> Helper loaded: language_helper
INFO - 2016-06-03 11:04:30 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:04:30 --> Model Class Initialized
INFO - 2016-06-03 11:04:30 --> Helper loaded: date_helper
INFO - 2016-06-03 11:04:30 --> Controller Class Initialized
INFO - 2016-06-03 11:04:30 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:04:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:04:30 --> Model Class Initialized
INFO - 2016-06-03 11:04:30 --> Form Validation Class Initialized
INFO - 2016-06-03 11:04:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 11:04:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 11:04:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 11:04:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 11:04:31 --> Final output sent to browser
DEBUG - 2016-06-03 11:04:31 --> Total execution time: 0.2080
INFO - 2016-06-03 11:04:33 --> Config Class Initialized
INFO - 2016-06-03 11:04:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:04:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:04:33 --> Utf8 Class Initialized
INFO - 2016-06-03 11:04:33 --> URI Class Initialized
INFO - 2016-06-03 11:04:33 --> Router Class Initialized
INFO - 2016-06-03 11:04:33 --> Output Class Initialized
INFO - 2016-06-03 11:04:33 --> Security Class Initialized
DEBUG - 2016-06-03 11:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:04:33 --> CSRF cookie sent
INFO - 2016-06-03 11:04:33 --> CSRF token verified
INFO - 2016-06-03 11:04:33 --> Input Class Initialized
INFO - 2016-06-03 11:04:33 --> Language Class Initialized
INFO - 2016-06-03 11:04:33 --> Loader Class Initialized
INFO - 2016-06-03 11:04:33 --> Helper loaded: form_helper
INFO - 2016-06-03 11:04:33 --> Database Driver Class Initialized
INFO - 2016-06-03 11:04:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:04:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:04:33 --> Email Class Initialized
INFO - 2016-06-03 11:04:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:04:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:04:33 --> Helper loaded: language_helper
INFO - 2016-06-03 11:04:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:04:33 --> Model Class Initialized
INFO - 2016-06-03 11:04:33 --> Helper loaded: date_helper
INFO - 2016-06-03 11:04:33 --> Controller Class Initialized
INFO - 2016-06-03 11:04:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:04:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:04:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:04:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:04:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:04:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:04:33 --> Model Class Initialized
INFO - 2016-06-03 11:04:33 --> Form Validation Class Initialized
INFO - 2016-06-03 11:04:33 --> Final output sent to browser
DEBUG - 2016-06-03 11:04:33 --> Total execution time: 0.0244
INFO - 2016-06-03 11:04:46 --> Config Class Initialized
INFO - 2016-06-03 11:04:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:04:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:04:46 --> Utf8 Class Initialized
INFO - 2016-06-03 11:04:46 --> URI Class Initialized
INFO - 2016-06-03 11:04:46 --> Router Class Initialized
INFO - 2016-06-03 11:04:46 --> Output Class Initialized
INFO - 2016-06-03 11:04:46 --> Security Class Initialized
DEBUG - 2016-06-03 11:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:04:46 --> CSRF cookie sent
INFO - 2016-06-03 11:04:46 --> CSRF token verified
INFO - 2016-06-03 11:04:46 --> Input Class Initialized
INFO - 2016-06-03 11:04:46 --> Language Class Initialized
INFO - 2016-06-03 11:04:46 --> Loader Class Initialized
INFO - 2016-06-03 11:04:46 --> Helper loaded: form_helper
INFO - 2016-06-03 11:04:46 --> Database Driver Class Initialized
INFO - 2016-06-03 11:04:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:04:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:04:46 --> Email Class Initialized
INFO - 2016-06-03 11:04:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:04:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:04:46 --> Helper loaded: language_helper
INFO - 2016-06-03 11:04:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:04:46 --> Model Class Initialized
INFO - 2016-06-03 11:04:46 --> Helper loaded: date_helper
INFO - 2016-06-03 11:04:46 --> Controller Class Initialized
INFO - 2016-06-03 11:04:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:04:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:04:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:04:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:04:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:04:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:04:46 --> Model Class Initialized
INFO - 2016-06-03 11:04:46 --> Form Validation Class Initialized
INFO - 2016-06-03 11:04:46 --> Final output sent to browser
DEBUG - 2016-06-03 11:04:46 --> Total execution time: 0.0862
INFO - 2016-06-03 11:04:58 --> Config Class Initialized
INFO - 2016-06-03 11:04:58 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:04:58 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:04:58 --> Utf8 Class Initialized
INFO - 2016-06-03 11:04:58 --> URI Class Initialized
INFO - 2016-06-03 11:04:58 --> Router Class Initialized
INFO - 2016-06-03 11:04:58 --> Output Class Initialized
INFO - 2016-06-03 11:04:58 --> Security Class Initialized
DEBUG - 2016-06-03 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:04:58 --> CSRF cookie sent
INFO - 2016-06-03 11:04:58 --> CSRF token verified
INFO - 2016-06-03 11:04:58 --> Input Class Initialized
INFO - 2016-06-03 11:04:58 --> Language Class Initialized
INFO - 2016-06-03 11:04:58 --> Loader Class Initialized
INFO - 2016-06-03 11:04:58 --> Helper loaded: form_helper
INFO - 2016-06-03 11:04:58 --> Database Driver Class Initialized
INFO - 2016-06-03 11:04:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:04:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:04:58 --> Email Class Initialized
INFO - 2016-06-03 11:04:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:04:58 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:04:58 --> Helper loaded: language_helper
INFO - 2016-06-03 11:04:58 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:04:58 --> Model Class Initialized
INFO - 2016-06-03 11:04:58 --> Helper loaded: date_helper
INFO - 2016-06-03 11:04:58 --> Controller Class Initialized
INFO - 2016-06-03 11:04:58 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:04:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:04:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:04:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:04:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:04:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:04:58 --> Model Class Initialized
INFO - 2016-06-03 11:04:58 --> Form Validation Class Initialized
INFO - 2016-06-03 11:04:58 --> Final output sent to browser
DEBUG - 2016-06-03 11:04:58 --> Total execution time: 0.0988
INFO - 2016-06-03 11:16:30 --> Config Class Initialized
INFO - 2016-06-03 11:16:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:16:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:16:30 --> Utf8 Class Initialized
INFO - 2016-06-03 11:16:30 --> URI Class Initialized
INFO - 2016-06-03 11:16:30 --> Router Class Initialized
INFO - 2016-06-03 11:16:30 --> Output Class Initialized
INFO - 2016-06-03 11:16:30 --> Security Class Initialized
DEBUG - 2016-06-03 11:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:16:30 --> CSRF cookie sent
INFO - 2016-06-03 11:16:30 --> Input Class Initialized
INFO - 2016-06-03 11:16:30 --> Language Class Initialized
INFO - 2016-06-03 11:16:30 --> Loader Class Initialized
INFO - 2016-06-03 11:16:30 --> Helper loaded: form_helper
INFO - 2016-06-03 11:16:31 --> Database Driver Class Initialized
INFO - 2016-06-03 11:16:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:16:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:16:34 --> Email Class Initialized
INFO - 2016-06-03 11:16:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:16:34 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:16:34 --> Helper loaded: language_helper
INFO - 2016-06-03 11:16:34 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:16:34 --> Model Class Initialized
INFO - 2016-06-03 11:16:34 --> Helper loaded: date_helper
INFO - 2016-06-03 11:16:34 --> Controller Class Initialized
INFO - 2016-06-03 11:16:34 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:16:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:16:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:16:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:16:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:16:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:16:34 --> Model Class Initialized
INFO - 2016-06-03 11:16:34 --> Form Validation Class Initialized
INFO - 2016-06-03 11:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 11:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 11:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 11:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 11:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 11:16:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 11:16:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 11:16:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 11:16:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 11:16:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 11:16:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 11:16:36 --> Final output sent to browser
DEBUG - 2016-06-03 11:16:36 --> Total execution time: 6.4201
INFO - 2016-06-03 11:16:38 --> Config Class Initialized
INFO - 2016-06-03 11:16:38 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:16:38 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:16:38 --> Utf8 Class Initialized
INFO - 2016-06-03 11:16:38 --> URI Class Initialized
INFO - 2016-06-03 11:16:38 --> Router Class Initialized
INFO - 2016-06-03 11:16:38 --> Output Class Initialized
INFO - 2016-06-03 11:16:38 --> Security Class Initialized
DEBUG - 2016-06-03 11:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:16:38 --> CSRF cookie sent
INFO - 2016-06-03 11:16:38 --> CSRF token verified
INFO - 2016-06-03 11:16:38 --> Input Class Initialized
INFO - 2016-06-03 11:16:38 --> Language Class Initialized
INFO - 2016-06-03 11:16:38 --> Loader Class Initialized
INFO - 2016-06-03 11:16:38 --> Helper loaded: form_helper
INFO - 2016-06-03 11:16:38 --> Database Driver Class Initialized
INFO - 2016-06-03 11:16:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:16:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:16:39 --> Email Class Initialized
INFO - 2016-06-03 11:16:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:16:39 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:16:39 --> Helper loaded: language_helper
INFO - 2016-06-03 11:16:39 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:16:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:16:39 --> Model Class Initialized
INFO - 2016-06-03 11:16:39 --> Helper loaded: date_helper
INFO - 2016-06-03 11:16:39 --> Controller Class Initialized
INFO - 2016-06-03 11:16:39 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:16:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:16:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:16:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:16:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:16:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:16:39 --> Model Class Initialized
INFO - 2016-06-03 11:16:39 --> Form Validation Class Initialized
INFO - 2016-06-03 11:16:39 --> Final output sent to browser
DEBUG - 2016-06-03 11:16:39 --> Total execution time: 0.3892
INFO - 2016-06-03 11:16:50 --> Config Class Initialized
INFO - 2016-06-03 11:16:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:16:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:16:50 --> Utf8 Class Initialized
INFO - 2016-06-03 11:16:50 --> URI Class Initialized
INFO - 2016-06-03 11:16:50 --> Router Class Initialized
INFO - 2016-06-03 11:16:50 --> Output Class Initialized
INFO - 2016-06-03 11:16:50 --> Security Class Initialized
DEBUG - 2016-06-03 11:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:16:50 --> CSRF cookie sent
INFO - 2016-06-03 11:16:50 --> CSRF token verified
INFO - 2016-06-03 11:16:50 --> Input Class Initialized
INFO - 2016-06-03 11:16:50 --> Language Class Initialized
INFO - 2016-06-03 11:16:50 --> Loader Class Initialized
INFO - 2016-06-03 11:16:50 --> Helper loaded: form_helper
INFO - 2016-06-03 11:16:50 --> Database Driver Class Initialized
INFO - 2016-06-03 11:16:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:16:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:16:50 --> Email Class Initialized
INFO - 2016-06-03 11:16:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:16:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:16:50 --> Helper loaded: language_helper
INFO - 2016-06-03 11:16:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:16:50 --> Model Class Initialized
INFO - 2016-06-03 11:16:50 --> Helper loaded: date_helper
INFO - 2016-06-03 11:16:50 --> Controller Class Initialized
INFO - 2016-06-03 11:16:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:16:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:16:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:16:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:16:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:16:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:16:50 --> Model Class Initialized
INFO - 2016-06-03 11:16:50 --> Form Validation Class Initialized
INFO - 2016-06-03 11:16:50 --> Final output sent to browser
DEBUG - 2016-06-03 11:16:50 --> Total execution time: 0.1165
INFO - 2016-06-03 11:16:58 --> Config Class Initialized
INFO - 2016-06-03 11:16:58 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:16:58 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:16:58 --> Utf8 Class Initialized
INFO - 2016-06-03 11:16:58 --> URI Class Initialized
INFO - 2016-06-03 11:16:58 --> Router Class Initialized
INFO - 2016-06-03 11:16:58 --> Output Class Initialized
INFO - 2016-06-03 11:16:58 --> Security Class Initialized
DEBUG - 2016-06-03 11:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:16:58 --> CSRF cookie sent
INFO - 2016-06-03 11:16:58 --> CSRF token verified
INFO - 2016-06-03 11:16:58 --> Input Class Initialized
INFO - 2016-06-03 11:16:58 --> Language Class Initialized
INFO - 2016-06-03 11:16:58 --> Loader Class Initialized
INFO - 2016-06-03 11:16:58 --> Helper loaded: form_helper
INFO - 2016-06-03 11:16:58 --> Database Driver Class Initialized
INFO - 2016-06-03 11:16:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:16:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:16:58 --> Email Class Initialized
INFO - 2016-06-03 11:16:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:16:58 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:16:58 --> Helper loaded: language_helper
INFO - 2016-06-03 11:16:58 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:16:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:16:58 --> Model Class Initialized
INFO - 2016-06-03 11:16:58 --> Helper loaded: date_helper
INFO - 2016-06-03 11:16:58 --> Controller Class Initialized
INFO - 2016-06-03 11:16:58 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:16:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:16:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:16:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:16:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:16:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:16:58 --> Model Class Initialized
INFO - 2016-06-03 11:16:58 --> Form Validation Class Initialized
INFO - 2016-06-03 11:16:58 --> Final output sent to browser
DEBUG - 2016-06-03 11:16:58 --> Total execution time: 0.0998
INFO - 2016-06-03 11:44:13 --> Config Class Initialized
INFO - 2016-06-03 11:44:13 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:44:13 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:44:13 --> Utf8 Class Initialized
INFO - 2016-06-03 11:44:13 --> URI Class Initialized
INFO - 2016-06-03 11:44:13 --> Router Class Initialized
INFO - 2016-06-03 11:44:13 --> Output Class Initialized
INFO - 2016-06-03 11:44:13 --> Security Class Initialized
DEBUG - 2016-06-03 11:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:44:13 --> CSRF cookie sent
INFO - 2016-06-03 11:44:13 --> Input Class Initialized
INFO - 2016-06-03 11:44:13 --> Language Class Initialized
INFO - 2016-06-03 11:44:13 --> Loader Class Initialized
INFO - 2016-06-03 11:44:13 --> Helper loaded: form_helper
INFO - 2016-06-03 11:44:13 --> Database Driver Class Initialized
INFO - 2016-06-03 11:44:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:44:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:44:13 --> Email Class Initialized
INFO - 2016-06-03 11:44:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:44:13 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:44:13 --> Helper loaded: language_helper
INFO - 2016-06-03 11:44:13 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:44:13 --> Model Class Initialized
INFO - 2016-06-03 11:44:13 --> Helper loaded: date_helper
INFO - 2016-06-03 11:44:13 --> Controller Class Initialized
INFO - 2016-06-03 11:44:13 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:44:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:44:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:44:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:44:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:44:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:44:13 --> Model Class Initialized
INFO - 2016-06-03 11:44:13 --> Form Validation Class Initialized
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 11:44:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 11:44:13 --> Final output sent to browser
DEBUG - 2016-06-03 11:44:13 --> Total execution time: 0.3571
INFO - 2016-06-03 11:44:16 --> Config Class Initialized
INFO - 2016-06-03 11:44:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:44:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:44:16 --> Utf8 Class Initialized
INFO - 2016-06-03 11:44:16 --> URI Class Initialized
INFO - 2016-06-03 11:44:16 --> Router Class Initialized
INFO - 2016-06-03 11:44:16 --> Output Class Initialized
INFO - 2016-06-03 11:44:16 --> Security Class Initialized
DEBUG - 2016-06-03 11:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:44:16 --> CSRF cookie sent
INFO - 2016-06-03 11:44:16 --> CSRF token verified
INFO - 2016-06-03 11:44:16 --> Input Class Initialized
INFO - 2016-06-03 11:44:16 --> Language Class Initialized
INFO - 2016-06-03 11:44:16 --> Loader Class Initialized
INFO - 2016-06-03 11:44:16 --> Helper loaded: form_helper
INFO - 2016-06-03 11:44:16 --> Database Driver Class Initialized
INFO - 2016-06-03 11:44:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:44:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:44:16 --> Email Class Initialized
INFO - 2016-06-03 11:44:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:44:16 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:44:16 --> Helper loaded: language_helper
INFO - 2016-06-03 11:44:16 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:44:16 --> Model Class Initialized
INFO - 2016-06-03 11:44:16 --> Helper loaded: date_helper
INFO - 2016-06-03 11:44:16 --> Controller Class Initialized
INFO - 2016-06-03 11:44:16 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:44:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:44:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:44:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:44:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:44:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:44:16 --> Model Class Initialized
INFO - 2016-06-03 11:44:16 --> Form Validation Class Initialized
INFO - 2016-06-03 11:44:16 --> Final output sent to browser
DEBUG - 2016-06-03 11:44:16 --> Total execution time: 0.0486
INFO - 2016-06-03 11:45:04 --> Config Class Initialized
INFO - 2016-06-03 11:45:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:45:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:45:04 --> Utf8 Class Initialized
INFO - 2016-06-03 11:45:04 --> URI Class Initialized
INFO - 2016-06-03 11:45:04 --> Router Class Initialized
INFO - 2016-06-03 11:45:04 --> Output Class Initialized
INFO - 2016-06-03 11:45:04 --> Security Class Initialized
DEBUG - 2016-06-03 11:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:45:04 --> CSRF cookie sent
INFO - 2016-06-03 11:45:04 --> Input Class Initialized
INFO - 2016-06-03 11:45:04 --> Language Class Initialized
INFO - 2016-06-03 11:45:04 --> Loader Class Initialized
INFO - 2016-06-03 11:45:04 --> Helper loaded: form_helper
INFO - 2016-06-03 11:45:04 --> Database Driver Class Initialized
INFO - 2016-06-03 11:45:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:45:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:45:04 --> Email Class Initialized
INFO - 2016-06-03 11:45:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:45:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:45:04 --> Helper loaded: language_helper
INFO - 2016-06-03 11:45:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:45:04 --> Model Class Initialized
INFO - 2016-06-03 11:45:04 --> Helper loaded: date_helper
INFO - 2016-06-03 11:45:04 --> Controller Class Initialized
INFO - 2016-06-03 11:45:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:45:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:45:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:45:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:45:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:45:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:45:04 --> Model Class Initialized
INFO - 2016-06-03 11:45:04 --> Form Validation Class Initialized
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 11:45:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 11:45:04 --> Final output sent to browser
DEBUG - 2016-06-03 11:45:04 --> Total execution time: 0.1153
INFO - 2016-06-03 11:45:05 --> Config Class Initialized
INFO - 2016-06-03 11:45:05 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:45:05 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:45:05 --> Utf8 Class Initialized
INFO - 2016-06-03 11:45:05 --> URI Class Initialized
INFO - 2016-06-03 11:45:05 --> Router Class Initialized
INFO - 2016-06-03 11:45:05 --> Output Class Initialized
INFO - 2016-06-03 11:45:05 --> Security Class Initialized
DEBUG - 2016-06-03 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:45:05 --> CSRF cookie sent
INFO - 2016-06-03 11:45:05 --> CSRF token verified
INFO - 2016-06-03 11:45:05 --> Input Class Initialized
INFO - 2016-06-03 11:45:05 --> Language Class Initialized
INFO - 2016-06-03 11:45:05 --> Loader Class Initialized
INFO - 2016-06-03 11:45:05 --> Helper loaded: form_helper
INFO - 2016-06-03 11:45:05 --> Database Driver Class Initialized
INFO - 2016-06-03 11:45:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:45:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:45:05 --> Email Class Initialized
INFO - 2016-06-03 11:45:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:45:05 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:45:05 --> Helper loaded: language_helper
INFO - 2016-06-03 11:45:05 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:45:05 --> Model Class Initialized
INFO - 2016-06-03 11:45:05 --> Helper loaded: date_helper
INFO - 2016-06-03 11:45:05 --> Controller Class Initialized
INFO - 2016-06-03 11:45:05 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:45:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:45:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:45:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:45:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:45:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:45:05 --> Model Class Initialized
INFO - 2016-06-03 11:45:05 --> Form Validation Class Initialized
INFO - 2016-06-03 11:45:05 --> Final output sent to browser
DEBUG - 2016-06-03 11:45:05 --> Total execution time: 0.0135
INFO - 2016-06-03 11:45:19 --> Config Class Initialized
INFO - 2016-06-03 11:45:19 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:45:19 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:45:19 --> Utf8 Class Initialized
INFO - 2016-06-03 11:45:19 --> URI Class Initialized
INFO - 2016-06-03 11:45:19 --> Router Class Initialized
INFO - 2016-06-03 11:45:19 --> Output Class Initialized
INFO - 2016-06-03 11:45:19 --> Security Class Initialized
DEBUG - 2016-06-03 11:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:45:19 --> CSRF cookie sent
INFO - 2016-06-03 11:45:19 --> Input Class Initialized
INFO - 2016-06-03 11:45:19 --> Language Class Initialized
INFO - 2016-06-03 11:45:19 --> Loader Class Initialized
INFO - 2016-06-03 11:45:19 --> Helper loaded: form_helper
INFO - 2016-06-03 11:45:19 --> Database Driver Class Initialized
INFO - 2016-06-03 11:45:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:45:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:45:19 --> Email Class Initialized
INFO - 2016-06-03 11:45:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:45:19 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:45:19 --> Helper loaded: language_helper
INFO - 2016-06-03 11:45:19 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:45:19 --> Model Class Initialized
INFO - 2016-06-03 11:45:19 --> Helper loaded: date_helper
INFO - 2016-06-03 11:45:19 --> Controller Class Initialized
INFO - 2016-06-03 11:45:19 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:45:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:45:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:45:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:45:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:45:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:45:19 --> Model Class Initialized
INFO - 2016-06-03 11:45:19 --> Form Validation Class Initialized
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 11:45:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 11:45:19 --> Final output sent to browser
DEBUG - 2016-06-03 11:45:19 --> Total execution time: 0.0229
INFO - 2016-06-03 11:45:20 --> Config Class Initialized
INFO - 2016-06-03 11:45:20 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:45:20 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:45:20 --> Utf8 Class Initialized
INFO - 2016-06-03 11:45:20 --> URI Class Initialized
INFO - 2016-06-03 11:45:20 --> Router Class Initialized
INFO - 2016-06-03 11:45:20 --> Output Class Initialized
INFO - 2016-06-03 11:45:20 --> Security Class Initialized
DEBUG - 2016-06-03 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:45:20 --> CSRF cookie sent
INFO - 2016-06-03 11:45:20 --> CSRF token verified
INFO - 2016-06-03 11:45:20 --> Input Class Initialized
INFO - 2016-06-03 11:45:20 --> Language Class Initialized
INFO - 2016-06-03 11:45:20 --> Loader Class Initialized
INFO - 2016-06-03 11:45:20 --> Helper loaded: form_helper
INFO - 2016-06-03 11:45:20 --> Database Driver Class Initialized
INFO - 2016-06-03 11:45:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:45:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:45:20 --> Email Class Initialized
INFO - 2016-06-03 11:45:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:45:20 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:45:20 --> Helper loaded: language_helper
INFO - 2016-06-03 11:45:20 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:45:20 --> Model Class Initialized
INFO - 2016-06-03 11:45:20 --> Helper loaded: date_helper
INFO - 2016-06-03 11:45:20 --> Controller Class Initialized
INFO - 2016-06-03 11:45:20 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:45:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:45:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:45:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:45:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:45:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:45:20 --> Model Class Initialized
INFO - 2016-06-03 11:45:20 --> Form Validation Class Initialized
INFO - 2016-06-03 11:45:20 --> Final output sent to browser
DEBUG - 2016-06-03 11:45:20 --> Total execution time: 0.0164
INFO - 2016-06-03 11:46:07 --> Config Class Initialized
INFO - 2016-06-03 11:46:07 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:46:07 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:46:07 --> Utf8 Class Initialized
INFO - 2016-06-03 11:46:07 --> URI Class Initialized
INFO - 2016-06-03 11:46:07 --> Router Class Initialized
INFO - 2016-06-03 11:46:07 --> Output Class Initialized
INFO - 2016-06-03 11:46:07 --> Security Class Initialized
DEBUG - 2016-06-03 11:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:46:07 --> CSRF cookie sent
INFO - 2016-06-03 11:46:07 --> Input Class Initialized
INFO - 2016-06-03 11:46:07 --> Language Class Initialized
INFO - 2016-06-03 11:46:07 --> Loader Class Initialized
INFO - 2016-06-03 11:46:07 --> Helper loaded: form_helper
INFO - 2016-06-03 11:46:07 --> Database Driver Class Initialized
INFO - 2016-06-03 11:46:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:46:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:46:07 --> Email Class Initialized
INFO - 2016-06-03 11:46:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:46:07 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:46:07 --> Helper loaded: language_helper
INFO - 2016-06-03 11:46:07 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:46:07 --> Model Class Initialized
INFO - 2016-06-03 11:46:07 --> Helper loaded: date_helper
INFO - 2016-06-03 11:46:07 --> Controller Class Initialized
INFO - 2016-06-03 11:46:07 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:46:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:46:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:46:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:46:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:46:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:46:07 --> Model Class Initialized
INFO - 2016-06-03 11:46:07 --> Form Validation Class Initialized
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 11:46:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 11:46:07 --> Final output sent to browser
DEBUG - 2016-06-03 11:46:07 --> Total execution time: 0.0515
INFO - 2016-06-03 11:46:15 --> Config Class Initialized
INFO - 2016-06-03 11:46:15 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:46:15 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:46:15 --> Utf8 Class Initialized
INFO - 2016-06-03 11:46:15 --> URI Class Initialized
INFO - 2016-06-03 11:46:15 --> Router Class Initialized
INFO - 2016-06-03 11:46:15 --> Output Class Initialized
INFO - 2016-06-03 11:46:15 --> Security Class Initialized
DEBUG - 2016-06-03 11:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:46:15 --> CSRF cookie sent
INFO - 2016-06-03 11:46:15 --> CSRF token verified
INFO - 2016-06-03 11:46:15 --> Input Class Initialized
INFO - 2016-06-03 11:46:15 --> Language Class Initialized
INFO - 2016-06-03 11:46:15 --> Loader Class Initialized
INFO - 2016-06-03 11:46:15 --> Helper loaded: form_helper
INFO - 2016-06-03 11:46:15 --> Database Driver Class Initialized
INFO - 2016-06-03 11:46:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:46:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:46:15 --> Email Class Initialized
INFO - 2016-06-03 11:46:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:46:15 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:46:15 --> Helper loaded: language_helper
INFO - 2016-06-03 11:46:15 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:46:15 --> Model Class Initialized
INFO - 2016-06-03 11:46:15 --> Helper loaded: date_helper
INFO - 2016-06-03 11:46:15 --> Controller Class Initialized
INFO - 2016-06-03 11:46:15 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:46:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:46:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:46:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:46:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:46:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:46:15 --> Model Class Initialized
INFO - 2016-06-03 11:46:15 --> Form Validation Class Initialized
INFO - 2016-06-03 11:46:15 --> Final output sent to browser
DEBUG - 2016-06-03 11:46:15 --> Total execution time: 0.0511
INFO - 2016-06-03 11:46:52 --> Config Class Initialized
INFO - 2016-06-03 11:46:52 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:46:52 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:46:52 --> Utf8 Class Initialized
INFO - 2016-06-03 11:46:52 --> URI Class Initialized
INFO - 2016-06-03 11:46:52 --> Router Class Initialized
INFO - 2016-06-03 11:46:52 --> Output Class Initialized
INFO - 2016-06-03 11:46:52 --> Security Class Initialized
DEBUG - 2016-06-03 11:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:46:52 --> CSRF cookie sent
INFO - 2016-06-03 11:46:52 --> Input Class Initialized
INFO - 2016-06-03 11:46:52 --> Language Class Initialized
INFO - 2016-06-03 11:46:52 --> Loader Class Initialized
INFO - 2016-06-03 11:46:52 --> Helper loaded: form_helper
INFO - 2016-06-03 11:46:52 --> Database Driver Class Initialized
INFO - 2016-06-03 11:46:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:46:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:46:52 --> Email Class Initialized
INFO - 2016-06-03 11:46:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:46:52 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:46:52 --> Helper loaded: language_helper
INFO - 2016-06-03 11:46:52 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:46:52 --> Model Class Initialized
INFO - 2016-06-03 11:46:52 --> Helper loaded: date_helper
INFO - 2016-06-03 11:46:52 --> Controller Class Initialized
INFO - 2016-06-03 11:46:52 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:46:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:46:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:46:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:46:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:46:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:46:52 --> Model Class Initialized
INFO - 2016-06-03 11:46:52 --> Form Validation Class Initialized
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 11:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 11:46:52 --> Final output sent to browser
DEBUG - 2016-06-03 11:46:52 --> Total execution time: 0.0639
INFO - 2016-06-03 11:46:54 --> Config Class Initialized
INFO - 2016-06-03 11:46:54 --> Hooks Class Initialized
DEBUG - 2016-06-03 11:46:54 --> UTF-8 Support Enabled
INFO - 2016-06-03 11:46:54 --> Utf8 Class Initialized
INFO - 2016-06-03 11:46:54 --> URI Class Initialized
INFO - 2016-06-03 11:46:54 --> Router Class Initialized
INFO - 2016-06-03 11:46:54 --> Output Class Initialized
INFO - 2016-06-03 11:46:54 --> Security Class Initialized
DEBUG - 2016-06-03 11:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 11:46:54 --> CSRF cookie sent
INFO - 2016-06-03 11:46:54 --> CSRF token verified
INFO - 2016-06-03 11:46:54 --> Input Class Initialized
INFO - 2016-06-03 11:46:54 --> Language Class Initialized
INFO - 2016-06-03 11:46:54 --> Loader Class Initialized
INFO - 2016-06-03 11:46:54 --> Helper loaded: form_helper
INFO - 2016-06-03 11:46:54 --> Database Driver Class Initialized
INFO - 2016-06-03 11:46:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 11:46:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 11:46:54 --> Email Class Initialized
INFO - 2016-06-03 11:46:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 11:46:54 --> Helper loaded: cookie_helper
INFO - 2016-06-03 11:46:54 --> Helper loaded: language_helper
INFO - 2016-06-03 11:46:54 --> Helper loaded: url_helper
DEBUG - 2016-06-03 11:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 11:46:54 --> Model Class Initialized
INFO - 2016-06-03 11:46:54 --> Helper loaded: date_helper
INFO - 2016-06-03 11:46:54 --> Controller Class Initialized
INFO - 2016-06-03 11:46:54 --> Helper loaded: languages_helper
INFO - 2016-06-03 11:46:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 11:46:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 11:46:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 11:46:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 11:46:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 11:46:54 --> Model Class Initialized
INFO - 2016-06-03 11:46:54 --> Form Validation Class Initialized
INFO - 2016-06-03 11:46:54 --> Final output sent to browser
DEBUG - 2016-06-03 11:46:54 --> Total execution time: 0.0161
INFO - 2016-06-03 12:14:57 --> Config Class Initialized
INFO - 2016-06-03 12:14:57 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:14:57 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:14:57 --> Utf8 Class Initialized
INFO - 2016-06-03 12:14:57 --> URI Class Initialized
INFO - 2016-06-03 12:14:57 --> Router Class Initialized
INFO - 2016-06-03 12:14:57 --> Output Class Initialized
INFO - 2016-06-03 12:14:57 --> Security Class Initialized
DEBUG - 2016-06-03 12:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:14:57 --> CSRF cookie sent
INFO - 2016-06-03 12:14:57 --> Input Class Initialized
INFO - 2016-06-03 12:14:57 --> Language Class Initialized
INFO - 2016-06-03 12:14:57 --> Loader Class Initialized
INFO - 2016-06-03 12:14:57 --> Helper loaded: form_helper
INFO - 2016-06-03 12:14:57 --> Database Driver Class Initialized
INFO - 2016-06-03 12:14:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:14:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:14:57 --> Email Class Initialized
INFO - 2016-06-03 12:14:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:14:57 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:14:57 --> Helper loaded: language_helper
INFO - 2016-06-03 12:14:57 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:14:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:14:57 --> Model Class Initialized
INFO - 2016-06-03 12:14:57 --> Helper loaded: date_helper
INFO - 2016-06-03 12:14:57 --> Controller Class Initialized
INFO - 2016-06-03 12:14:57 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:14:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:14:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:14:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:14:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:14:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:14:57 --> Model Class Initialized
INFO - 2016-06-03 12:14:57 --> Form Validation Class Initialized
ERROR - 2016-06-03 12:14:57 --> Severity: Error --> Call to a member function result_array() on string /home/demis/www/platformadiabet/application/models/Diabet_model.php 354
INFO - 2016-06-03 12:15:35 --> Config Class Initialized
INFO - 2016-06-03 12:15:35 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:15:35 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:15:35 --> Utf8 Class Initialized
INFO - 2016-06-03 12:15:35 --> URI Class Initialized
INFO - 2016-06-03 12:15:35 --> Router Class Initialized
INFO - 2016-06-03 12:15:35 --> Output Class Initialized
INFO - 2016-06-03 12:15:35 --> Security Class Initialized
DEBUG - 2016-06-03 12:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:15:35 --> CSRF cookie sent
INFO - 2016-06-03 12:15:35 --> Input Class Initialized
INFO - 2016-06-03 12:15:35 --> Language Class Initialized
INFO - 2016-06-03 12:15:35 --> Loader Class Initialized
INFO - 2016-06-03 12:15:35 --> Helper loaded: form_helper
INFO - 2016-06-03 12:15:35 --> Database Driver Class Initialized
INFO - 2016-06-03 12:15:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:15:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:15:35 --> Email Class Initialized
INFO - 2016-06-03 12:15:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:15:35 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:15:35 --> Helper loaded: language_helper
INFO - 2016-06-03 12:15:35 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:15:35 --> Model Class Initialized
INFO - 2016-06-03 12:15:35 --> Helper loaded: date_helper
INFO - 2016-06-03 12:15:35 --> Controller Class Initialized
INFO - 2016-06-03 12:15:35 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:15:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:15:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:15:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:15:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:15:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:15:35 --> Model Class Initialized
INFO - 2016-06-03 12:15:35 --> Form Validation Class Initialized
INFO - 2016-06-03 12:19:14 --> Config Class Initialized
INFO - 2016-06-03 12:19:14 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:19:14 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:19:14 --> Utf8 Class Initialized
INFO - 2016-06-03 12:19:14 --> URI Class Initialized
INFO - 2016-06-03 12:19:14 --> Router Class Initialized
INFO - 2016-06-03 12:19:14 --> Output Class Initialized
INFO - 2016-06-03 12:19:14 --> Security Class Initialized
DEBUG - 2016-06-03 12:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:19:14 --> CSRF cookie sent
INFO - 2016-06-03 12:19:14 --> Input Class Initialized
INFO - 2016-06-03 12:19:14 --> Language Class Initialized
INFO - 2016-06-03 12:19:14 --> Loader Class Initialized
INFO - 2016-06-03 12:19:14 --> Helper loaded: form_helper
INFO - 2016-06-03 12:19:14 --> Database Driver Class Initialized
INFO - 2016-06-03 12:19:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:19:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:19:14 --> Email Class Initialized
INFO - 2016-06-03 12:19:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:19:14 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:19:14 --> Helper loaded: language_helper
INFO - 2016-06-03 12:19:14 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:19:14 --> Model Class Initialized
INFO - 2016-06-03 12:19:14 --> Helper loaded: date_helper
INFO - 2016-06-03 12:19:14 --> Controller Class Initialized
INFO - 2016-06-03 12:19:14 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:19:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:19:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:19:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:19:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:19:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:19:14 --> Model Class Initialized
INFO - 2016-06-03 12:19:14 --> Form Validation Class Initialized
INFO - 2016-06-03 12:19:53 --> Config Class Initialized
INFO - 2016-06-03 12:19:53 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:19:53 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:19:53 --> Utf8 Class Initialized
INFO - 2016-06-03 12:19:53 --> URI Class Initialized
INFO - 2016-06-03 12:19:53 --> Router Class Initialized
INFO - 2016-06-03 12:19:53 --> Output Class Initialized
INFO - 2016-06-03 12:19:53 --> Security Class Initialized
DEBUG - 2016-06-03 12:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:19:53 --> CSRF cookie sent
INFO - 2016-06-03 12:19:53 --> Input Class Initialized
INFO - 2016-06-03 12:19:53 --> Language Class Initialized
INFO - 2016-06-03 12:19:53 --> Loader Class Initialized
INFO - 2016-06-03 12:19:53 --> Helper loaded: form_helper
INFO - 2016-06-03 12:19:53 --> Database Driver Class Initialized
INFO - 2016-06-03 12:19:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:19:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:19:53 --> Email Class Initialized
INFO - 2016-06-03 12:19:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:19:53 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:19:53 --> Helper loaded: language_helper
INFO - 2016-06-03 12:19:53 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:19:53 --> Model Class Initialized
INFO - 2016-06-03 12:19:53 --> Helper loaded: date_helper
INFO - 2016-06-03 12:19:53 --> Controller Class Initialized
INFO - 2016-06-03 12:19:53 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:19:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:19:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:19:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:19:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:19:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:19:53 --> Model Class Initialized
INFO - 2016-06-03 12:19:53 --> Form Validation Class Initialized
INFO - 2016-06-03 12:20:12 --> Config Class Initialized
INFO - 2016-06-03 12:20:12 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:20:12 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:20:12 --> Utf8 Class Initialized
INFO - 2016-06-03 12:20:12 --> URI Class Initialized
INFO - 2016-06-03 12:20:12 --> Router Class Initialized
INFO - 2016-06-03 12:20:12 --> Output Class Initialized
INFO - 2016-06-03 12:20:12 --> Security Class Initialized
DEBUG - 2016-06-03 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:20:12 --> CSRF cookie sent
INFO - 2016-06-03 12:20:12 --> Input Class Initialized
INFO - 2016-06-03 12:20:12 --> Language Class Initialized
INFO - 2016-06-03 12:20:12 --> Loader Class Initialized
INFO - 2016-06-03 12:20:12 --> Helper loaded: form_helper
INFO - 2016-06-03 12:20:12 --> Database Driver Class Initialized
INFO - 2016-06-03 12:20:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:20:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:20:12 --> Email Class Initialized
INFO - 2016-06-03 12:20:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:20:12 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:20:12 --> Helper loaded: language_helper
INFO - 2016-06-03 12:20:12 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:20:12 --> Model Class Initialized
INFO - 2016-06-03 12:20:12 --> Helper loaded: date_helper
INFO - 2016-06-03 12:20:12 --> Controller Class Initialized
INFO - 2016-06-03 12:20:12 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:20:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:20:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:20:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:20:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:20:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:20:12 --> Model Class Initialized
INFO - 2016-06-03 12:20:12 --> Form Validation Class Initialized
INFO - 2016-06-03 12:23:52 --> Config Class Initialized
INFO - 2016-06-03 12:23:52 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:23:52 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:23:52 --> Utf8 Class Initialized
INFO - 2016-06-03 12:23:52 --> URI Class Initialized
INFO - 2016-06-03 12:23:52 --> Router Class Initialized
INFO - 2016-06-03 12:23:52 --> Output Class Initialized
INFO - 2016-06-03 12:23:52 --> Security Class Initialized
DEBUG - 2016-06-03 12:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:23:52 --> CSRF cookie sent
INFO - 2016-06-03 12:23:52 --> Input Class Initialized
INFO - 2016-06-03 12:23:52 --> Language Class Initialized
INFO - 2016-06-03 12:23:52 --> Loader Class Initialized
INFO - 2016-06-03 12:23:52 --> Helper loaded: form_helper
INFO - 2016-06-03 12:23:52 --> Database Driver Class Initialized
INFO - 2016-06-03 12:23:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:23:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:23:52 --> Email Class Initialized
INFO - 2016-06-03 12:23:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:23:52 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:23:52 --> Helper loaded: language_helper
INFO - 2016-06-03 12:23:52 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:23:52 --> Model Class Initialized
INFO - 2016-06-03 12:23:52 --> Helper loaded: date_helper
INFO - 2016-06-03 12:23:52 --> Controller Class Initialized
INFO - 2016-06-03 12:23:52 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:23:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:23:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:23:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:23:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:23:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:23:52 --> Model Class Initialized
INFO - 2016-06-03 12:23:52 --> Form Validation Class Initialized
INFO - 2016-06-03 12:32:31 --> Config Class Initialized
INFO - 2016-06-03 12:32:31 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:32:31 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:32:31 --> Utf8 Class Initialized
INFO - 2016-06-03 12:32:31 --> URI Class Initialized
INFO - 2016-06-03 12:32:31 --> Router Class Initialized
INFO - 2016-06-03 12:32:31 --> Output Class Initialized
INFO - 2016-06-03 12:32:31 --> Security Class Initialized
DEBUG - 2016-06-03 12:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:32:31 --> CSRF cookie sent
INFO - 2016-06-03 12:32:31 --> Input Class Initialized
INFO - 2016-06-03 12:32:31 --> Language Class Initialized
INFO - 2016-06-03 12:32:31 --> Loader Class Initialized
INFO - 2016-06-03 12:32:31 --> Helper loaded: form_helper
INFO - 2016-06-03 12:32:31 --> Database Driver Class Initialized
INFO - 2016-06-03 12:32:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:32:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:32:31 --> Email Class Initialized
INFO - 2016-06-03 12:32:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:32:31 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:32:31 --> Helper loaded: language_helper
INFO - 2016-06-03 12:32:31 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:32:31 --> Model Class Initialized
INFO - 2016-06-03 12:32:31 --> Helper loaded: date_helper
INFO - 2016-06-03 12:32:31 --> Controller Class Initialized
INFO - 2016-06-03 12:32:31 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:32:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:32:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:32:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:32:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:32:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:32:31 --> Model Class Initialized
INFO - 2016-06-03 12:32:31 --> Form Validation Class Initialized
INFO - 2016-06-03 12:32:45 --> Config Class Initialized
INFO - 2016-06-03 12:32:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:32:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:32:45 --> Utf8 Class Initialized
INFO - 2016-06-03 12:32:45 --> URI Class Initialized
INFO - 2016-06-03 12:32:45 --> Router Class Initialized
INFO - 2016-06-03 12:32:45 --> Output Class Initialized
INFO - 2016-06-03 12:32:45 --> Security Class Initialized
DEBUG - 2016-06-03 12:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:32:45 --> CSRF cookie sent
INFO - 2016-06-03 12:32:45 --> Input Class Initialized
INFO - 2016-06-03 12:32:45 --> Language Class Initialized
INFO - 2016-06-03 12:32:45 --> Loader Class Initialized
INFO - 2016-06-03 12:32:45 --> Helper loaded: form_helper
INFO - 2016-06-03 12:32:45 --> Database Driver Class Initialized
INFO - 2016-06-03 12:32:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:32:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:32:45 --> Email Class Initialized
INFO - 2016-06-03 12:32:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:32:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:32:45 --> Helper loaded: language_helper
INFO - 2016-06-03 12:32:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:32:45 --> Model Class Initialized
INFO - 2016-06-03 12:32:45 --> Helper loaded: date_helper
INFO - 2016-06-03 12:32:45 --> Controller Class Initialized
INFO - 2016-06-03 12:32:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:32:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:32:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:32:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:32:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:32:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:32:45 --> Model Class Initialized
INFO - 2016-06-03 12:32:45 --> Form Validation Class Initialized
INFO - 2016-06-03 12:33:40 --> Config Class Initialized
INFO - 2016-06-03 12:33:40 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:33:40 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:33:40 --> Utf8 Class Initialized
INFO - 2016-06-03 12:33:40 --> URI Class Initialized
INFO - 2016-06-03 12:33:40 --> Router Class Initialized
INFO - 2016-06-03 12:33:40 --> Output Class Initialized
INFO - 2016-06-03 12:33:40 --> Security Class Initialized
DEBUG - 2016-06-03 12:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:33:40 --> CSRF cookie sent
INFO - 2016-06-03 12:33:40 --> Input Class Initialized
INFO - 2016-06-03 12:33:40 --> Language Class Initialized
INFO - 2016-06-03 12:33:40 --> Loader Class Initialized
INFO - 2016-06-03 12:33:40 --> Helper loaded: form_helper
INFO - 2016-06-03 12:33:40 --> Database Driver Class Initialized
INFO - 2016-06-03 12:33:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:33:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:33:40 --> Email Class Initialized
INFO - 2016-06-03 12:33:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:33:40 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:33:40 --> Helper loaded: language_helper
INFO - 2016-06-03 12:33:40 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:33:40 --> Model Class Initialized
INFO - 2016-06-03 12:33:40 --> Helper loaded: date_helper
INFO - 2016-06-03 12:33:40 --> Controller Class Initialized
INFO - 2016-06-03 12:33:40 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:33:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:33:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:33:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:33:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:33:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:33:40 --> Model Class Initialized
INFO - 2016-06-03 12:33:40 --> Form Validation Class Initialized
INFO - 2016-06-03 12:34:04 --> Config Class Initialized
INFO - 2016-06-03 12:34:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:34:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:34:04 --> Utf8 Class Initialized
INFO - 2016-06-03 12:34:04 --> URI Class Initialized
INFO - 2016-06-03 12:34:04 --> Router Class Initialized
INFO - 2016-06-03 12:34:04 --> Output Class Initialized
INFO - 2016-06-03 12:34:04 --> Security Class Initialized
DEBUG - 2016-06-03 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:34:04 --> CSRF cookie sent
INFO - 2016-06-03 12:34:04 --> Input Class Initialized
INFO - 2016-06-03 12:34:04 --> Language Class Initialized
INFO - 2016-06-03 12:34:04 --> Loader Class Initialized
INFO - 2016-06-03 12:34:04 --> Helper loaded: form_helper
INFO - 2016-06-03 12:34:04 --> Database Driver Class Initialized
INFO - 2016-06-03 12:34:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:34:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:34:04 --> Email Class Initialized
INFO - 2016-06-03 12:34:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:34:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:34:04 --> Helper loaded: language_helper
INFO - 2016-06-03 12:34:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:34:04 --> Model Class Initialized
INFO - 2016-06-03 12:34:04 --> Helper loaded: date_helper
INFO - 2016-06-03 12:34:04 --> Controller Class Initialized
INFO - 2016-06-03 12:34:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:34:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:34:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:34:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:34:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:34:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:34:04 --> Model Class Initialized
INFO - 2016-06-03 12:34:04 --> Form Validation Class Initialized
INFO - 2016-06-03 12:35:15 --> Config Class Initialized
INFO - 2016-06-03 12:35:15 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:35:15 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:35:15 --> Utf8 Class Initialized
INFO - 2016-06-03 12:35:15 --> URI Class Initialized
INFO - 2016-06-03 12:35:15 --> Router Class Initialized
INFO - 2016-06-03 12:35:15 --> Output Class Initialized
INFO - 2016-06-03 12:35:15 --> Security Class Initialized
DEBUG - 2016-06-03 12:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:35:15 --> CSRF cookie sent
INFO - 2016-06-03 12:35:15 --> Input Class Initialized
INFO - 2016-06-03 12:35:15 --> Language Class Initialized
INFO - 2016-06-03 12:35:15 --> Loader Class Initialized
INFO - 2016-06-03 12:35:15 --> Helper loaded: form_helper
INFO - 2016-06-03 12:35:15 --> Database Driver Class Initialized
INFO - 2016-06-03 12:35:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:35:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:35:15 --> Email Class Initialized
INFO - 2016-06-03 12:35:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:35:15 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:35:15 --> Helper loaded: language_helper
INFO - 2016-06-03 12:35:15 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:35:15 --> Model Class Initialized
INFO - 2016-06-03 12:35:15 --> Helper loaded: date_helper
INFO - 2016-06-03 12:35:15 --> Controller Class Initialized
INFO - 2016-06-03 12:35:15 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:35:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:35:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:35:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:35:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:35:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:35:15 --> Model Class Initialized
INFO - 2016-06-03 12:35:15 --> Form Validation Class Initialized
INFO - 2016-06-03 12:36:17 --> Config Class Initialized
INFO - 2016-06-03 12:36:17 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:36:17 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:36:17 --> Utf8 Class Initialized
INFO - 2016-06-03 12:36:17 --> URI Class Initialized
INFO - 2016-06-03 12:36:17 --> Router Class Initialized
INFO - 2016-06-03 12:36:17 --> Output Class Initialized
INFO - 2016-06-03 12:36:17 --> Security Class Initialized
DEBUG - 2016-06-03 12:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:36:17 --> CSRF cookie sent
INFO - 2016-06-03 12:36:17 --> Input Class Initialized
INFO - 2016-06-03 12:36:17 --> Language Class Initialized
INFO - 2016-06-03 12:36:17 --> Loader Class Initialized
INFO - 2016-06-03 12:36:17 --> Helper loaded: form_helper
INFO - 2016-06-03 12:36:17 --> Database Driver Class Initialized
INFO - 2016-06-03 12:36:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:36:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:36:17 --> Email Class Initialized
INFO - 2016-06-03 12:36:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:36:17 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:36:17 --> Helper loaded: language_helper
INFO - 2016-06-03 12:36:17 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:36:17 --> Model Class Initialized
INFO - 2016-06-03 12:36:17 --> Helper loaded: date_helper
INFO - 2016-06-03 12:36:17 --> Controller Class Initialized
INFO - 2016-06-03 12:36:17 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:36:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:36:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:36:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:36:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:36:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:36:17 --> Model Class Initialized
INFO - 2016-06-03 12:36:17 --> Form Validation Class Initialized
INFO - 2016-06-03 12:36:32 --> Config Class Initialized
INFO - 2016-06-03 12:36:32 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:36:32 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:36:32 --> Utf8 Class Initialized
INFO - 2016-06-03 12:36:32 --> URI Class Initialized
INFO - 2016-06-03 12:36:32 --> Router Class Initialized
INFO - 2016-06-03 12:36:32 --> Output Class Initialized
INFO - 2016-06-03 12:36:32 --> Security Class Initialized
DEBUG - 2016-06-03 12:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:36:32 --> CSRF cookie sent
INFO - 2016-06-03 12:36:32 --> Input Class Initialized
INFO - 2016-06-03 12:36:32 --> Language Class Initialized
INFO - 2016-06-03 12:36:32 --> Loader Class Initialized
INFO - 2016-06-03 12:36:32 --> Helper loaded: form_helper
INFO - 2016-06-03 12:36:32 --> Database Driver Class Initialized
INFO - 2016-06-03 12:36:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:36:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:36:32 --> Email Class Initialized
INFO - 2016-06-03 12:36:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:36:32 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:36:32 --> Helper loaded: language_helper
INFO - 2016-06-03 12:36:32 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:36:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:36:32 --> Model Class Initialized
INFO - 2016-06-03 12:36:32 --> Helper loaded: date_helper
INFO - 2016-06-03 12:36:32 --> Controller Class Initialized
INFO - 2016-06-03 12:36:32 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:36:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:36:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:36:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:36:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:36:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:36:32 --> Model Class Initialized
INFO - 2016-06-03 12:36:32 --> Form Validation Class Initialized
INFO - 2016-06-03 12:37:48 --> Config Class Initialized
INFO - 2016-06-03 12:37:48 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:37:48 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:37:48 --> Utf8 Class Initialized
INFO - 2016-06-03 12:37:48 --> URI Class Initialized
INFO - 2016-06-03 12:37:48 --> Router Class Initialized
INFO - 2016-06-03 12:37:48 --> Output Class Initialized
INFO - 2016-06-03 12:37:48 --> Security Class Initialized
DEBUG - 2016-06-03 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:37:48 --> CSRF cookie sent
INFO - 2016-06-03 12:37:48 --> Input Class Initialized
INFO - 2016-06-03 12:37:48 --> Language Class Initialized
INFO - 2016-06-03 12:37:48 --> Loader Class Initialized
INFO - 2016-06-03 12:37:48 --> Helper loaded: form_helper
INFO - 2016-06-03 12:37:48 --> Database Driver Class Initialized
INFO - 2016-06-03 12:37:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:37:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:37:48 --> Email Class Initialized
INFO - 2016-06-03 12:37:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:37:48 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:37:48 --> Helper loaded: language_helper
INFO - 2016-06-03 12:37:48 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:37:48 --> Model Class Initialized
INFO - 2016-06-03 12:37:48 --> Helper loaded: date_helper
INFO - 2016-06-03 12:37:48 --> Controller Class Initialized
INFO - 2016-06-03 12:37:48 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:37:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:37:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:37:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:37:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:37:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:37:48 --> Model Class Initialized
INFO - 2016-06-03 12:37:48 --> Form Validation Class Initialized
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 12:37:48 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:37:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
INFO - 2016-06-03 12:38:16 --> Config Class Initialized
INFO - 2016-06-03 12:38:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:38:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:38:16 --> Utf8 Class Initialized
INFO - 2016-06-03 12:38:16 --> URI Class Initialized
INFO - 2016-06-03 12:38:16 --> Router Class Initialized
INFO - 2016-06-03 12:38:16 --> Output Class Initialized
INFO - 2016-06-03 12:38:16 --> Security Class Initialized
DEBUG - 2016-06-03 12:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:38:16 --> CSRF cookie sent
INFO - 2016-06-03 12:38:16 --> Input Class Initialized
INFO - 2016-06-03 12:38:16 --> Language Class Initialized
INFO - 2016-06-03 12:38:16 --> Loader Class Initialized
INFO - 2016-06-03 12:38:16 --> Helper loaded: form_helper
INFO - 2016-06-03 12:38:16 --> Database Driver Class Initialized
INFO - 2016-06-03 12:38:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:38:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:38:16 --> Email Class Initialized
INFO - 2016-06-03 12:38:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:38:16 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:38:16 --> Helper loaded: language_helper
INFO - 2016-06-03 12:38:16 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:38:16 --> Model Class Initialized
INFO - 2016-06-03 12:38:16 --> Helper loaded: date_helper
INFO - 2016-06-03 12:38:16 --> Controller Class Initialized
INFO - 2016-06-03 12:38:16 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:38:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:38:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:38:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:38:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:38:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:38:16 --> Model Class Initialized
INFO - 2016-06-03 12:38:16 --> Form Validation Class Initialized
ERROR - 2016-06-03 12:38:16 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Notice --> Undefined index: AVG(interval_10) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
ERROR - 2016-06-03 12:38:16 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
INFO - 2016-06-03 12:38:30 --> Config Class Initialized
INFO - 2016-06-03 12:38:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:38:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:38:30 --> Utf8 Class Initialized
INFO - 2016-06-03 12:38:30 --> URI Class Initialized
INFO - 2016-06-03 12:38:30 --> Router Class Initialized
INFO - 2016-06-03 12:38:30 --> Output Class Initialized
INFO - 2016-06-03 12:38:30 --> Security Class Initialized
DEBUG - 2016-06-03 12:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:38:30 --> CSRF cookie sent
INFO - 2016-06-03 12:38:30 --> Input Class Initialized
INFO - 2016-06-03 12:38:30 --> Language Class Initialized
INFO - 2016-06-03 12:38:30 --> Loader Class Initialized
INFO - 2016-06-03 12:38:30 --> Helper loaded: form_helper
INFO - 2016-06-03 12:38:30 --> Database Driver Class Initialized
INFO - 2016-06-03 12:38:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:38:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:38:30 --> Email Class Initialized
INFO - 2016-06-03 12:38:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:38:30 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:38:30 --> Helper loaded: language_helper
INFO - 2016-06-03 12:38:30 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:38:30 --> Model Class Initialized
INFO - 2016-06-03 12:38:30 --> Helper loaded: date_helper
INFO - 2016-06-03 12:38:30 --> Controller Class Initialized
INFO - 2016-06-03 12:38:30 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:38:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:38:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:38:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:38:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:38:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:38:30 --> Model Class Initialized
INFO - 2016-06-03 12:38:30 --> Form Validation Class Initialized
INFO - 2016-06-03 12:40:44 --> Config Class Initialized
INFO - 2016-06-03 12:40:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:40:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:40:44 --> Utf8 Class Initialized
INFO - 2016-06-03 12:40:44 --> URI Class Initialized
INFO - 2016-06-03 12:40:44 --> Router Class Initialized
INFO - 2016-06-03 12:40:44 --> Output Class Initialized
INFO - 2016-06-03 12:40:44 --> Security Class Initialized
DEBUG - 2016-06-03 12:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:40:44 --> CSRF cookie sent
INFO - 2016-06-03 12:40:44 --> Input Class Initialized
INFO - 2016-06-03 12:40:44 --> Language Class Initialized
INFO - 2016-06-03 12:40:44 --> Loader Class Initialized
INFO - 2016-06-03 12:40:44 --> Helper loaded: form_helper
INFO - 2016-06-03 12:40:44 --> Database Driver Class Initialized
INFO - 2016-06-03 12:40:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:40:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:40:44 --> Email Class Initialized
INFO - 2016-06-03 12:40:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:40:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:40:44 --> Helper loaded: language_helper
INFO - 2016-06-03 12:40:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:40:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:40:44 --> Model Class Initialized
INFO - 2016-06-03 12:40:44 --> Helper loaded: date_helper
INFO - 2016-06-03 12:40:44 --> Controller Class Initialized
INFO - 2016-06-03 12:40:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:40:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:40:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:40:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:40:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:40:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:40:44 --> Model Class Initialized
INFO - 2016-06-03 12:40:44 --> Form Validation Class Initialized
INFO - 2016-06-03 12:43:20 --> Config Class Initialized
INFO - 2016-06-03 12:43:20 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:43:20 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:43:20 --> Utf8 Class Initialized
INFO - 2016-06-03 12:43:20 --> URI Class Initialized
INFO - 2016-06-03 12:43:20 --> Router Class Initialized
INFO - 2016-06-03 12:43:20 --> Output Class Initialized
INFO - 2016-06-03 12:43:20 --> Security Class Initialized
DEBUG - 2016-06-03 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:43:20 --> CSRF cookie sent
INFO - 2016-06-03 12:43:20 --> Input Class Initialized
INFO - 2016-06-03 12:43:20 --> Language Class Initialized
INFO - 2016-06-03 12:43:20 --> Loader Class Initialized
INFO - 2016-06-03 12:43:20 --> Helper loaded: form_helper
INFO - 2016-06-03 12:43:20 --> Database Driver Class Initialized
INFO - 2016-06-03 12:43:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:43:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:43:20 --> Email Class Initialized
INFO - 2016-06-03 12:43:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:43:20 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:43:20 --> Helper loaded: language_helper
INFO - 2016-06-03 12:43:20 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:43:20 --> Model Class Initialized
INFO - 2016-06-03 12:43:20 --> Helper loaded: date_helper
INFO - 2016-06-03 12:43:20 --> Controller Class Initialized
INFO - 2016-06-03 12:43:20 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:43:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:43:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:43:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:43:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:43:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:43:20 --> Model Class Initialized
INFO - 2016-06-03 12:43:20 --> Form Validation Class Initialized
INFO - 2016-06-03 12:43:59 --> Config Class Initialized
INFO - 2016-06-03 12:43:59 --> Hooks Class Initialized
DEBUG - 2016-06-03 12:43:59 --> UTF-8 Support Enabled
INFO - 2016-06-03 12:43:59 --> Utf8 Class Initialized
INFO - 2016-06-03 12:43:59 --> URI Class Initialized
INFO - 2016-06-03 12:43:59 --> Router Class Initialized
INFO - 2016-06-03 12:43:59 --> Output Class Initialized
INFO - 2016-06-03 12:43:59 --> Security Class Initialized
DEBUG - 2016-06-03 12:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 12:43:59 --> CSRF cookie sent
INFO - 2016-06-03 12:43:59 --> Input Class Initialized
INFO - 2016-06-03 12:43:59 --> Language Class Initialized
INFO - 2016-06-03 12:43:59 --> Loader Class Initialized
INFO - 2016-06-03 12:43:59 --> Helper loaded: form_helper
INFO - 2016-06-03 12:43:59 --> Database Driver Class Initialized
INFO - 2016-06-03 12:43:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 12:43:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 12:43:59 --> Email Class Initialized
INFO - 2016-06-03 12:43:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 12:43:59 --> Helper loaded: cookie_helper
INFO - 2016-06-03 12:43:59 --> Helper loaded: language_helper
INFO - 2016-06-03 12:43:59 --> Helper loaded: url_helper
DEBUG - 2016-06-03 12:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 12:43:59 --> Model Class Initialized
INFO - 2016-06-03 12:43:59 --> Helper loaded: date_helper
INFO - 2016-06-03 12:43:59 --> Controller Class Initialized
INFO - 2016-06-03 12:43:59 --> Helper loaded: languages_helper
INFO - 2016-06-03 12:43:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 12:43:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 12:43:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 12:43:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 12:43:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 12:43:59 --> Model Class Initialized
INFO - 2016-06-03 12:43:59 --> Form Validation Class Initialized
INFO - 2016-06-03 13:00:13 --> Config Class Initialized
INFO - 2016-06-03 13:00:13 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:00:13 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:00:13 --> Utf8 Class Initialized
INFO - 2016-06-03 13:00:13 --> URI Class Initialized
INFO - 2016-06-03 13:00:13 --> Router Class Initialized
INFO - 2016-06-03 13:00:13 --> Output Class Initialized
INFO - 2016-06-03 13:00:13 --> Security Class Initialized
DEBUG - 2016-06-03 13:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:00:13 --> CSRF cookie sent
INFO - 2016-06-03 13:00:13 --> Input Class Initialized
INFO - 2016-06-03 13:00:13 --> Language Class Initialized
INFO - 2016-06-03 13:00:13 --> Loader Class Initialized
INFO - 2016-06-03 13:00:13 --> Helper loaded: form_helper
INFO - 2016-06-03 13:00:13 --> Database Driver Class Initialized
INFO - 2016-06-03 13:00:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:00:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:00:13 --> Email Class Initialized
INFO - 2016-06-03 13:00:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:00:13 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:00:13 --> Helper loaded: language_helper
INFO - 2016-06-03 13:00:13 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:00:13 --> Model Class Initialized
INFO - 2016-06-03 13:00:13 --> Helper loaded: date_helper
INFO - 2016-06-03 13:00:13 --> Controller Class Initialized
INFO - 2016-06-03 13:00:13 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:00:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:00:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:00:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:00:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:00:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:00:13 --> Model Class Initialized
INFO - 2016-06-03 13:00:13 --> Form Validation Class Initialized
INFO - 2016-06-03 13:00:21 --> Config Class Initialized
INFO - 2016-06-03 13:00:21 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:00:21 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:00:21 --> Utf8 Class Initialized
INFO - 2016-06-03 13:00:21 --> URI Class Initialized
INFO - 2016-06-03 13:00:21 --> Router Class Initialized
INFO - 2016-06-03 13:00:21 --> Output Class Initialized
INFO - 2016-06-03 13:00:21 --> Security Class Initialized
DEBUG - 2016-06-03 13:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:00:21 --> CSRF cookie sent
INFO - 2016-06-03 13:00:21 --> Input Class Initialized
INFO - 2016-06-03 13:00:21 --> Language Class Initialized
INFO - 2016-06-03 13:00:21 --> Loader Class Initialized
INFO - 2016-06-03 13:00:21 --> Helper loaded: form_helper
INFO - 2016-06-03 13:00:21 --> Database Driver Class Initialized
INFO - 2016-06-03 13:00:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:00:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:00:21 --> Email Class Initialized
INFO - 2016-06-03 13:00:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:00:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:00:21 --> Helper loaded: language_helper
INFO - 2016-06-03 13:00:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:00:21 --> Model Class Initialized
INFO - 2016-06-03 13:00:21 --> Helper loaded: date_helper
INFO - 2016-06-03 13:00:21 --> Controller Class Initialized
INFO - 2016-06-03 13:00:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:00:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:00:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:00:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:00:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:00:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:00:21 --> Model Class Initialized
INFO - 2016-06-03 13:00:21 --> Form Validation Class Initialized
INFO - 2016-06-03 13:02:44 --> Config Class Initialized
INFO - 2016-06-03 13:02:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:02:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:02:44 --> Utf8 Class Initialized
INFO - 2016-06-03 13:02:44 --> URI Class Initialized
INFO - 2016-06-03 13:02:44 --> Router Class Initialized
INFO - 2016-06-03 13:02:44 --> Output Class Initialized
INFO - 2016-06-03 13:02:44 --> Security Class Initialized
DEBUG - 2016-06-03 13:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:02:44 --> CSRF cookie sent
INFO - 2016-06-03 13:02:44 --> Input Class Initialized
INFO - 2016-06-03 13:02:44 --> Language Class Initialized
INFO - 2016-06-03 13:02:44 --> Loader Class Initialized
INFO - 2016-06-03 13:02:44 --> Helper loaded: form_helper
INFO - 2016-06-03 13:02:44 --> Database Driver Class Initialized
INFO - 2016-06-03 13:02:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:02:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:02:44 --> Email Class Initialized
INFO - 2016-06-03 13:02:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:02:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:02:44 --> Helper loaded: language_helper
INFO - 2016-06-03 13:02:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:02:44 --> Model Class Initialized
INFO - 2016-06-03 13:02:44 --> Helper loaded: date_helper
INFO - 2016-06-03 13:02:44 --> Controller Class Initialized
INFO - 2016-06-03 13:02:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:02:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:02:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:02:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:02:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:02:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:02:44 --> Model Class Initialized
INFO - 2016-06-03 13:02:44 --> Form Validation Class Initialized
INFO - 2016-06-03 13:04:01 --> Config Class Initialized
INFO - 2016-06-03 13:04:01 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:04:01 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:04:01 --> Utf8 Class Initialized
INFO - 2016-06-03 13:04:01 --> URI Class Initialized
INFO - 2016-06-03 13:04:01 --> Router Class Initialized
INFO - 2016-06-03 13:04:01 --> Output Class Initialized
INFO - 2016-06-03 13:04:01 --> Security Class Initialized
DEBUG - 2016-06-03 13:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:04:01 --> CSRF cookie sent
INFO - 2016-06-03 13:04:01 --> Input Class Initialized
INFO - 2016-06-03 13:04:01 --> Language Class Initialized
INFO - 2016-06-03 13:04:01 --> Loader Class Initialized
INFO - 2016-06-03 13:04:01 --> Helper loaded: form_helper
INFO - 2016-06-03 13:04:01 --> Database Driver Class Initialized
INFO - 2016-06-03 13:04:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:04:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:04:01 --> Email Class Initialized
INFO - 2016-06-03 13:04:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:04:01 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:04:01 --> Helper loaded: language_helper
INFO - 2016-06-03 13:04:01 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:04:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:04:01 --> Model Class Initialized
INFO - 2016-06-03 13:04:01 --> Helper loaded: date_helper
INFO - 2016-06-03 13:04:01 --> Controller Class Initialized
INFO - 2016-06-03 13:04:01 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:04:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:04:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:04:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:04:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:04:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:04:01 --> Model Class Initialized
INFO - 2016-06-03 13:04:01 --> Form Validation Class Initialized
INFO - 2016-06-03 13:08:25 --> Config Class Initialized
INFO - 2016-06-03 13:08:25 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:08:25 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:08:25 --> Utf8 Class Initialized
INFO - 2016-06-03 13:08:25 --> URI Class Initialized
INFO - 2016-06-03 13:08:25 --> Router Class Initialized
INFO - 2016-06-03 13:08:25 --> Output Class Initialized
INFO - 2016-06-03 13:08:25 --> Security Class Initialized
DEBUG - 2016-06-03 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:08:25 --> CSRF cookie sent
INFO - 2016-06-03 13:08:25 --> Input Class Initialized
INFO - 2016-06-03 13:08:25 --> Language Class Initialized
INFO - 2016-06-03 13:08:25 --> Loader Class Initialized
INFO - 2016-06-03 13:08:25 --> Helper loaded: form_helper
INFO - 2016-06-03 13:08:25 --> Database Driver Class Initialized
INFO - 2016-06-03 13:08:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:08:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:08:25 --> Email Class Initialized
INFO - 2016-06-03 13:08:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:08:25 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:08:25 --> Helper loaded: language_helper
INFO - 2016-06-03 13:08:25 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:08:25 --> Model Class Initialized
INFO - 2016-06-03 13:08:25 --> Helper loaded: date_helper
INFO - 2016-06-03 13:08:25 --> Controller Class Initialized
INFO - 2016-06-03 13:08:25 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:08:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:08:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:08:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:08:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:08:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:08:25 --> Model Class Initialized
INFO - 2016-06-03 13:08:25 --> Form Validation Class Initialized
INFO - 2016-06-03 13:08:50 --> Config Class Initialized
INFO - 2016-06-03 13:08:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:08:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:08:50 --> Utf8 Class Initialized
INFO - 2016-06-03 13:08:50 --> URI Class Initialized
INFO - 2016-06-03 13:08:50 --> Router Class Initialized
INFO - 2016-06-03 13:08:50 --> Output Class Initialized
INFO - 2016-06-03 13:08:50 --> Security Class Initialized
DEBUG - 2016-06-03 13:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:08:50 --> CSRF cookie sent
INFO - 2016-06-03 13:08:50 --> Input Class Initialized
INFO - 2016-06-03 13:08:50 --> Language Class Initialized
INFO - 2016-06-03 13:08:50 --> Loader Class Initialized
INFO - 2016-06-03 13:08:50 --> Helper loaded: form_helper
INFO - 2016-06-03 13:08:50 --> Database Driver Class Initialized
INFO - 2016-06-03 13:08:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:08:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:08:50 --> Email Class Initialized
INFO - 2016-06-03 13:08:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:08:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:08:50 --> Helper loaded: language_helper
INFO - 2016-06-03 13:08:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:08:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:08:50 --> Model Class Initialized
INFO - 2016-06-03 13:08:50 --> Helper loaded: date_helper
INFO - 2016-06-03 13:08:50 --> Controller Class Initialized
INFO - 2016-06-03 13:08:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:08:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:08:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:08:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:08:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:08:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:08:50 --> Model Class Initialized
INFO - 2016-06-03 13:08:50 --> Form Validation Class Initialized
INFO - 2016-06-03 13:12:01 --> Config Class Initialized
INFO - 2016-06-03 13:12:01 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:12:01 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:12:01 --> Utf8 Class Initialized
INFO - 2016-06-03 13:12:01 --> URI Class Initialized
INFO - 2016-06-03 13:12:01 --> Router Class Initialized
INFO - 2016-06-03 13:12:01 --> Output Class Initialized
INFO - 2016-06-03 13:12:01 --> Security Class Initialized
DEBUG - 2016-06-03 13:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:12:01 --> CSRF cookie sent
INFO - 2016-06-03 13:12:01 --> Input Class Initialized
INFO - 2016-06-03 13:12:01 --> Language Class Initialized
INFO - 2016-06-03 13:12:01 --> Loader Class Initialized
INFO - 2016-06-03 13:12:01 --> Helper loaded: form_helper
INFO - 2016-06-03 13:12:01 --> Database Driver Class Initialized
INFO - 2016-06-03 13:12:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:12:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:12:01 --> Email Class Initialized
INFO - 2016-06-03 13:12:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:12:01 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:12:01 --> Helper loaded: language_helper
INFO - 2016-06-03 13:12:01 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:12:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:12:01 --> Model Class Initialized
INFO - 2016-06-03 13:12:01 --> Helper loaded: date_helper
INFO - 2016-06-03 13:12:01 --> Controller Class Initialized
INFO - 2016-06-03 13:12:01 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:12:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:12:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:12:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:12:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:12:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:12:01 --> Model Class Initialized
INFO - 2016-06-03 13:12:01 --> Form Validation Class Initialized
INFO - 2016-06-03 13:12:29 --> Config Class Initialized
INFO - 2016-06-03 13:12:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:12:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:12:29 --> Utf8 Class Initialized
INFO - 2016-06-03 13:12:29 --> URI Class Initialized
INFO - 2016-06-03 13:12:29 --> Router Class Initialized
INFO - 2016-06-03 13:12:29 --> Output Class Initialized
INFO - 2016-06-03 13:12:29 --> Security Class Initialized
DEBUG - 2016-06-03 13:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:12:29 --> CSRF cookie sent
INFO - 2016-06-03 13:12:29 --> Input Class Initialized
INFO - 2016-06-03 13:12:29 --> Language Class Initialized
INFO - 2016-06-03 13:12:29 --> Loader Class Initialized
INFO - 2016-06-03 13:12:29 --> Helper loaded: form_helper
INFO - 2016-06-03 13:12:29 --> Database Driver Class Initialized
INFO - 2016-06-03 13:12:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:12:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:12:29 --> Email Class Initialized
INFO - 2016-06-03 13:12:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:12:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:12:29 --> Helper loaded: language_helper
INFO - 2016-06-03 13:12:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:12:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:12:29 --> Model Class Initialized
INFO - 2016-06-03 13:12:29 --> Helper loaded: date_helper
INFO - 2016-06-03 13:12:29 --> Controller Class Initialized
INFO - 2016-06-03 13:12:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:12:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:12:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:12:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:12:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:12:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:12:29 --> Model Class Initialized
INFO - 2016-06-03 13:12:29 --> Form Validation Class Initialized
INFO - 2016-06-03 13:19:40 --> Config Class Initialized
INFO - 2016-06-03 13:19:40 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:19:40 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:19:40 --> Utf8 Class Initialized
INFO - 2016-06-03 13:19:40 --> URI Class Initialized
INFO - 2016-06-03 13:19:40 --> Router Class Initialized
INFO - 2016-06-03 13:19:40 --> Output Class Initialized
INFO - 2016-06-03 13:19:40 --> Security Class Initialized
DEBUG - 2016-06-03 13:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:19:40 --> CSRF cookie sent
INFO - 2016-06-03 13:19:40 --> Input Class Initialized
INFO - 2016-06-03 13:19:40 --> Language Class Initialized
INFO - 2016-06-03 13:19:40 --> Loader Class Initialized
INFO - 2016-06-03 13:19:40 --> Helper loaded: form_helper
INFO - 2016-06-03 13:19:40 --> Database Driver Class Initialized
INFO - 2016-06-03 13:19:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:19:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:19:40 --> Email Class Initialized
INFO - 2016-06-03 13:19:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:19:40 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:19:40 --> Helper loaded: language_helper
INFO - 2016-06-03 13:19:40 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:19:40 --> Model Class Initialized
INFO - 2016-06-03 13:19:40 --> Helper loaded: date_helper
INFO - 2016-06-03 13:19:40 --> Controller Class Initialized
INFO - 2016-06-03 13:19:40 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:19:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:19:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:19:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:19:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:19:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:19:40 --> Model Class Initialized
INFO - 2016-06-03 13:19:40 --> Form Validation Class Initialized
INFO - 2016-06-03 13:19:53 --> Config Class Initialized
INFO - 2016-06-03 13:19:53 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:19:53 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:19:53 --> Utf8 Class Initialized
INFO - 2016-06-03 13:19:53 --> URI Class Initialized
INFO - 2016-06-03 13:19:53 --> Router Class Initialized
INFO - 2016-06-03 13:19:53 --> Output Class Initialized
INFO - 2016-06-03 13:19:53 --> Security Class Initialized
DEBUG - 2016-06-03 13:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:19:53 --> CSRF cookie sent
INFO - 2016-06-03 13:19:53 --> Input Class Initialized
INFO - 2016-06-03 13:19:53 --> Language Class Initialized
INFO - 2016-06-03 13:19:53 --> Loader Class Initialized
INFO - 2016-06-03 13:19:53 --> Helper loaded: form_helper
INFO - 2016-06-03 13:19:53 --> Database Driver Class Initialized
INFO - 2016-06-03 13:19:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:19:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:19:53 --> Email Class Initialized
INFO - 2016-06-03 13:19:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:19:53 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:19:53 --> Helper loaded: language_helper
INFO - 2016-06-03 13:19:53 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:19:53 --> Model Class Initialized
INFO - 2016-06-03 13:19:53 --> Helper loaded: date_helper
INFO - 2016-06-03 13:19:53 --> Controller Class Initialized
INFO - 2016-06-03 13:19:53 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:19:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:19:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:19:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:19:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:19:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:19:53 --> Model Class Initialized
INFO - 2016-06-03 13:19:53 --> Form Validation Class Initialized
INFO - 2016-06-03 13:20:32 --> Config Class Initialized
INFO - 2016-06-03 13:20:32 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:20:32 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:20:32 --> Utf8 Class Initialized
INFO - 2016-06-03 13:20:32 --> URI Class Initialized
INFO - 2016-06-03 13:20:32 --> Router Class Initialized
INFO - 2016-06-03 13:20:32 --> Output Class Initialized
INFO - 2016-06-03 13:20:32 --> Security Class Initialized
DEBUG - 2016-06-03 13:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:20:32 --> CSRF cookie sent
INFO - 2016-06-03 13:20:32 --> Input Class Initialized
INFO - 2016-06-03 13:20:32 --> Language Class Initialized
INFO - 2016-06-03 13:20:32 --> Loader Class Initialized
INFO - 2016-06-03 13:20:32 --> Helper loaded: form_helper
INFO - 2016-06-03 13:20:32 --> Database Driver Class Initialized
INFO - 2016-06-03 13:20:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:20:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:20:32 --> Email Class Initialized
INFO - 2016-06-03 13:20:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:20:32 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:20:32 --> Helper loaded: language_helper
INFO - 2016-06-03 13:20:32 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:20:32 --> Model Class Initialized
INFO - 2016-06-03 13:20:32 --> Helper loaded: date_helper
INFO - 2016-06-03 13:20:32 --> Controller Class Initialized
INFO - 2016-06-03 13:20:32 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:20:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:20:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:20:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:20:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:20:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:20:32 --> Model Class Initialized
INFO - 2016-06-03 13:20:32 --> Form Validation Class Initialized
INFO - 2016-06-03 13:22:13 --> Config Class Initialized
INFO - 2016-06-03 13:22:13 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:22:13 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:22:13 --> Utf8 Class Initialized
INFO - 2016-06-03 13:22:13 --> URI Class Initialized
INFO - 2016-06-03 13:22:13 --> Router Class Initialized
INFO - 2016-06-03 13:22:13 --> Output Class Initialized
INFO - 2016-06-03 13:22:13 --> Security Class Initialized
DEBUG - 2016-06-03 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:22:13 --> CSRF cookie sent
INFO - 2016-06-03 13:22:13 --> Input Class Initialized
INFO - 2016-06-03 13:22:13 --> Language Class Initialized
INFO - 2016-06-03 13:22:13 --> Loader Class Initialized
INFO - 2016-06-03 13:22:13 --> Helper loaded: form_helper
INFO - 2016-06-03 13:22:13 --> Database Driver Class Initialized
INFO - 2016-06-03 13:22:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:22:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:22:13 --> Email Class Initialized
INFO - 2016-06-03 13:22:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:22:13 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:22:13 --> Helper loaded: language_helper
INFO - 2016-06-03 13:22:13 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:22:13 --> Model Class Initialized
INFO - 2016-06-03 13:22:13 --> Helper loaded: date_helper
INFO - 2016-06-03 13:22:13 --> Controller Class Initialized
INFO - 2016-06-03 13:22:13 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:22:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:22:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:22:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:22:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:22:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:22:13 --> Model Class Initialized
INFO - 2016-06-03 13:22:13 --> Form Validation Class Initialized
INFO - 2016-06-03 13:22:20 --> Config Class Initialized
INFO - 2016-06-03 13:22:20 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:22:20 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:22:20 --> Utf8 Class Initialized
INFO - 2016-06-03 13:22:20 --> URI Class Initialized
INFO - 2016-06-03 13:22:20 --> Router Class Initialized
INFO - 2016-06-03 13:22:20 --> Output Class Initialized
INFO - 2016-06-03 13:22:21 --> Security Class Initialized
DEBUG - 2016-06-03 13:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:22:21 --> CSRF cookie sent
INFO - 2016-06-03 13:22:21 --> Input Class Initialized
INFO - 2016-06-03 13:22:21 --> Language Class Initialized
INFO - 2016-06-03 13:22:21 --> Loader Class Initialized
INFO - 2016-06-03 13:22:21 --> Helper loaded: form_helper
INFO - 2016-06-03 13:22:21 --> Database Driver Class Initialized
INFO - 2016-06-03 13:22:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:22:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:22:21 --> Email Class Initialized
INFO - 2016-06-03 13:22:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:22:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:22:21 --> Helper loaded: language_helper
INFO - 2016-06-03 13:22:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:22:21 --> Model Class Initialized
INFO - 2016-06-03 13:22:21 --> Helper loaded: date_helper
INFO - 2016-06-03 13:22:21 --> Controller Class Initialized
INFO - 2016-06-03 13:22:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:22:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:22:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:22:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:22:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:22:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:22:21 --> Model Class Initialized
INFO - 2016-06-03 13:22:21 --> Form Validation Class Initialized
INFO - 2016-06-03 13:22:39 --> Config Class Initialized
INFO - 2016-06-03 13:22:39 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:22:39 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:22:39 --> Utf8 Class Initialized
INFO - 2016-06-03 13:22:39 --> URI Class Initialized
INFO - 2016-06-03 13:22:39 --> Router Class Initialized
INFO - 2016-06-03 13:22:39 --> Output Class Initialized
INFO - 2016-06-03 13:22:39 --> Security Class Initialized
DEBUG - 2016-06-03 13:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:22:39 --> CSRF cookie sent
INFO - 2016-06-03 13:22:39 --> Input Class Initialized
INFO - 2016-06-03 13:22:39 --> Language Class Initialized
INFO - 2016-06-03 13:22:39 --> Loader Class Initialized
INFO - 2016-06-03 13:22:39 --> Helper loaded: form_helper
INFO - 2016-06-03 13:22:39 --> Database Driver Class Initialized
INFO - 2016-06-03 13:22:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:22:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:22:39 --> Email Class Initialized
INFO - 2016-06-03 13:22:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:22:39 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:22:39 --> Helper loaded: language_helper
INFO - 2016-06-03 13:22:39 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:22:39 --> Model Class Initialized
INFO - 2016-06-03 13:22:39 --> Helper loaded: date_helper
INFO - 2016-06-03 13:22:39 --> Controller Class Initialized
INFO - 2016-06-03 13:22:39 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:22:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:22:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:22:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:22:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:22:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:22:39 --> Model Class Initialized
INFO - 2016-06-03 13:22:39 --> Form Validation Class Initialized
INFO - 2016-06-03 13:23:04 --> Config Class Initialized
INFO - 2016-06-03 13:23:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:23:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:23:04 --> Utf8 Class Initialized
INFO - 2016-06-03 13:23:04 --> URI Class Initialized
INFO - 2016-06-03 13:23:04 --> Router Class Initialized
INFO - 2016-06-03 13:23:04 --> Output Class Initialized
INFO - 2016-06-03 13:23:04 --> Security Class Initialized
DEBUG - 2016-06-03 13:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:23:04 --> CSRF cookie sent
INFO - 2016-06-03 13:23:04 --> Input Class Initialized
INFO - 2016-06-03 13:23:04 --> Language Class Initialized
INFO - 2016-06-03 13:23:04 --> Loader Class Initialized
INFO - 2016-06-03 13:23:04 --> Helper loaded: form_helper
INFO - 2016-06-03 13:23:04 --> Database Driver Class Initialized
INFO - 2016-06-03 13:23:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:23:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:23:04 --> Email Class Initialized
INFO - 2016-06-03 13:23:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:23:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:23:04 --> Helper loaded: language_helper
INFO - 2016-06-03 13:23:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:23:04 --> Model Class Initialized
INFO - 2016-06-03 13:23:04 --> Helper loaded: date_helper
INFO - 2016-06-03 13:23:04 --> Controller Class Initialized
INFO - 2016-06-03 13:23:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:23:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:23:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:23:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:23:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:23:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:23:04 --> Model Class Initialized
INFO - 2016-06-03 13:23:04 --> Form Validation Class Initialized
INFO - 2016-06-03 13:23:21 --> Config Class Initialized
INFO - 2016-06-03 13:23:21 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:23:21 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:23:21 --> Utf8 Class Initialized
INFO - 2016-06-03 13:23:21 --> URI Class Initialized
INFO - 2016-06-03 13:23:21 --> Router Class Initialized
INFO - 2016-06-03 13:23:21 --> Output Class Initialized
INFO - 2016-06-03 13:23:21 --> Security Class Initialized
DEBUG - 2016-06-03 13:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:23:21 --> CSRF cookie sent
INFO - 2016-06-03 13:23:21 --> Input Class Initialized
INFO - 2016-06-03 13:23:21 --> Language Class Initialized
INFO - 2016-06-03 13:23:21 --> Loader Class Initialized
INFO - 2016-06-03 13:23:21 --> Helper loaded: form_helper
INFO - 2016-06-03 13:23:21 --> Database Driver Class Initialized
INFO - 2016-06-03 13:23:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:23:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:23:21 --> Email Class Initialized
INFO - 2016-06-03 13:23:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:23:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:23:21 --> Helper loaded: language_helper
INFO - 2016-06-03 13:23:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:23:21 --> Model Class Initialized
INFO - 2016-06-03 13:23:21 --> Helper loaded: date_helper
INFO - 2016-06-03 13:23:21 --> Controller Class Initialized
INFO - 2016-06-03 13:23:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:23:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:23:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:23:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:23:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:23:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:23:21 --> Model Class Initialized
INFO - 2016-06-03 13:23:21 --> Form Validation Class Initialized
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:21 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
INFO - 2016-06-03 13:23:48 --> Config Class Initialized
INFO - 2016-06-03 13:23:48 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:23:48 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:23:48 --> Utf8 Class Initialized
INFO - 2016-06-03 13:23:48 --> URI Class Initialized
INFO - 2016-06-03 13:23:48 --> Router Class Initialized
INFO - 2016-06-03 13:23:48 --> Output Class Initialized
INFO - 2016-06-03 13:23:48 --> Security Class Initialized
DEBUG - 2016-06-03 13:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:23:48 --> CSRF cookie sent
INFO - 2016-06-03 13:23:48 --> Input Class Initialized
INFO - 2016-06-03 13:23:48 --> Language Class Initialized
INFO - 2016-06-03 13:23:48 --> Loader Class Initialized
INFO - 2016-06-03 13:23:48 --> Helper loaded: form_helper
INFO - 2016-06-03 13:23:48 --> Database Driver Class Initialized
INFO - 2016-06-03 13:23:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:23:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:23:48 --> Email Class Initialized
INFO - 2016-06-03 13:23:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:23:48 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:23:48 --> Helper loaded: language_helper
INFO - 2016-06-03 13:23:48 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:23:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:23:48 --> Model Class Initialized
INFO - 2016-06-03 13:23:48 --> Helper loaded: date_helper
INFO - 2016-06-03 13:23:48 --> Controller Class Initialized
INFO - 2016-06-03 13:23:48 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:23:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:23:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:23:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:23:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:23:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:23:48 --> Model Class Initialized
INFO - 2016-06-03 13:23:48 --> Form Validation Class Initialized
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
ERROR - 2016-06-03 13:23:48 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
INFO - 2016-06-03 13:24:08 --> Config Class Initialized
INFO - 2016-06-03 13:24:08 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:24:08 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:24:08 --> Utf8 Class Initialized
INFO - 2016-06-03 13:24:08 --> URI Class Initialized
INFO - 2016-06-03 13:24:08 --> Router Class Initialized
INFO - 2016-06-03 13:24:08 --> Output Class Initialized
INFO - 2016-06-03 13:24:08 --> Security Class Initialized
DEBUG - 2016-06-03 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:24:08 --> CSRF cookie sent
INFO - 2016-06-03 13:24:08 --> Input Class Initialized
INFO - 2016-06-03 13:24:08 --> Language Class Initialized
INFO - 2016-06-03 13:24:08 --> Loader Class Initialized
INFO - 2016-06-03 13:24:08 --> Helper loaded: form_helper
INFO - 2016-06-03 13:24:08 --> Database Driver Class Initialized
INFO - 2016-06-03 13:24:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:24:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:24:08 --> Email Class Initialized
INFO - 2016-06-03 13:24:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:24:08 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:24:08 --> Helper loaded: language_helper
INFO - 2016-06-03 13:24:08 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:24:08 --> Model Class Initialized
INFO - 2016-06-03 13:24:08 --> Helper loaded: date_helper
INFO - 2016-06-03 13:24:08 --> Controller Class Initialized
INFO - 2016-06-03 13:24:08 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:24:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:24:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:24:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:24:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:24:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:24:08 --> Model Class Initialized
INFO - 2016-06-03 13:24:08 --> Form Validation Class Initialized
INFO - 2016-06-03 13:25:07 --> Config Class Initialized
INFO - 2016-06-03 13:25:07 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:25:07 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:25:07 --> Utf8 Class Initialized
INFO - 2016-06-03 13:25:07 --> URI Class Initialized
INFO - 2016-06-03 13:25:07 --> Router Class Initialized
INFO - 2016-06-03 13:25:07 --> Output Class Initialized
INFO - 2016-06-03 13:25:07 --> Security Class Initialized
DEBUG - 2016-06-03 13:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:25:07 --> CSRF cookie sent
INFO - 2016-06-03 13:25:07 --> Input Class Initialized
INFO - 2016-06-03 13:25:07 --> Language Class Initialized
INFO - 2016-06-03 13:25:07 --> Loader Class Initialized
INFO - 2016-06-03 13:25:07 --> Helper loaded: form_helper
INFO - 2016-06-03 13:25:07 --> Database Driver Class Initialized
INFO - 2016-06-03 13:25:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:25:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:25:07 --> Email Class Initialized
INFO - 2016-06-03 13:25:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:25:07 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:25:07 --> Helper loaded: language_helper
INFO - 2016-06-03 13:25:07 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:25:07 --> Model Class Initialized
INFO - 2016-06-03 13:25:07 --> Helper loaded: date_helper
INFO - 2016-06-03 13:25:07 --> Controller Class Initialized
INFO - 2016-06-03 13:25:07 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:25:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:25:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:25:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:25:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:25:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:25:07 --> Model Class Initialized
INFO - 2016-06-03 13:25:07 --> Form Validation Class Initialized
INFO - 2016-06-03 13:25:38 --> Config Class Initialized
INFO - 2016-06-03 13:25:38 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:25:38 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:25:38 --> Utf8 Class Initialized
INFO - 2016-06-03 13:25:38 --> URI Class Initialized
INFO - 2016-06-03 13:25:38 --> Router Class Initialized
INFO - 2016-06-03 13:25:38 --> Output Class Initialized
INFO - 2016-06-03 13:25:38 --> Security Class Initialized
DEBUG - 2016-06-03 13:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:25:38 --> CSRF cookie sent
INFO - 2016-06-03 13:25:38 --> Input Class Initialized
INFO - 2016-06-03 13:25:38 --> Language Class Initialized
INFO - 2016-06-03 13:25:38 --> Loader Class Initialized
INFO - 2016-06-03 13:25:38 --> Helper loaded: form_helper
INFO - 2016-06-03 13:25:38 --> Database Driver Class Initialized
INFO - 2016-06-03 13:25:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:25:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:25:38 --> Email Class Initialized
INFO - 2016-06-03 13:25:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:25:38 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:25:38 --> Helper loaded: language_helper
INFO - 2016-06-03 13:25:38 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:25:38 --> Model Class Initialized
INFO - 2016-06-03 13:25:38 --> Helper loaded: date_helper
INFO - 2016-06-03 13:25:38 --> Controller Class Initialized
INFO - 2016-06-03 13:25:38 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:25:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:25:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:25:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:25:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:25:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:25:38 --> Model Class Initialized
INFO - 2016-06-03 13:25:38 --> Form Validation Class Initialized
INFO - 2016-06-03 13:25:57 --> Config Class Initialized
INFO - 2016-06-03 13:25:57 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:25:57 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:25:57 --> Utf8 Class Initialized
INFO - 2016-06-03 13:25:57 --> URI Class Initialized
INFO - 2016-06-03 13:25:57 --> Router Class Initialized
INFO - 2016-06-03 13:25:57 --> Output Class Initialized
INFO - 2016-06-03 13:25:57 --> Security Class Initialized
DEBUG - 2016-06-03 13:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:25:57 --> CSRF cookie sent
INFO - 2016-06-03 13:25:57 --> Input Class Initialized
INFO - 2016-06-03 13:25:57 --> Language Class Initialized
INFO - 2016-06-03 13:25:57 --> Loader Class Initialized
INFO - 2016-06-03 13:25:57 --> Helper loaded: form_helper
INFO - 2016-06-03 13:25:57 --> Database Driver Class Initialized
INFO - 2016-06-03 13:25:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:25:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:25:57 --> Email Class Initialized
INFO - 2016-06-03 13:25:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:25:57 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:25:57 --> Helper loaded: language_helper
INFO - 2016-06-03 13:25:57 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:25:57 --> Model Class Initialized
INFO - 2016-06-03 13:25:57 --> Helper loaded: date_helper
INFO - 2016-06-03 13:25:57 --> Controller Class Initialized
INFO - 2016-06-03 13:25:57 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:25:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:25:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:25:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:25:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:25:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:25:57 --> Model Class Initialized
INFO - 2016-06-03 13:25:57 --> Form Validation Class Initialized
INFO - 2016-06-03 13:26:42 --> Config Class Initialized
INFO - 2016-06-03 13:26:42 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:26:42 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:26:42 --> Utf8 Class Initialized
INFO - 2016-06-03 13:26:42 --> URI Class Initialized
INFO - 2016-06-03 13:26:42 --> Router Class Initialized
INFO - 2016-06-03 13:26:42 --> Output Class Initialized
INFO - 2016-06-03 13:26:42 --> Security Class Initialized
DEBUG - 2016-06-03 13:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:26:42 --> CSRF cookie sent
INFO - 2016-06-03 13:26:42 --> Input Class Initialized
INFO - 2016-06-03 13:26:42 --> Language Class Initialized
INFO - 2016-06-03 13:26:42 --> Loader Class Initialized
INFO - 2016-06-03 13:26:42 --> Helper loaded: form_helper
INFO - 2016-06-03 13:26:42 --> Database Driver Class Initialized
INFO - 2016-06-03 13:26:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:26:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:26:42 --> Email Class Initialized
INFO - 2016-06-03 13:26:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:26:42 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:26:42 --> Helper loaded: language_helper
INFO - 2016-06-03 13:26:42 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:26:42 --> Model Class Initialized
INFO - 2016-06-03 13:26:42 --> Helper loaded: date_helper
INFO - 2016-06-03 13:26:42 --> Controller Class Initialized
INFO - 2016-06-03 13:26:42 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:26:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:26:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:26:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:26:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:26:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:26:42 --> Model Class Initialized
INFO - 2016-06-03 13:26:42 --> Form Validation Class Initialized
INFO - 2016-06-03 13:28:20 --> Config Class Initialized
INFO - 2016-06-03 13:28:20 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:28:20 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:28:20 --> Utf8 Class Initialized
INFO - 2016-06-03 13:28:20 --> URI Class Initialized
INFO - 2016-06-03 13:28:20 --> Router Class Initialized
INFO - 2016-06-03 13:28:20 --> Output Class Initialized
INFO - 2016-06-03 13:28:20 --> Security Class Initialized
DEBUG - 2016-06-03 13:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:28:20 --> CSRF cookie sent
INFO - 2016-06-03 13:28:20 --> Input Class Initialized
INFO - 2016-06-03 13:28:20 --> Language Class Initialized
INFO - 2016-06-03 13:28:20 --> Loader Class Initialized
INFO - 2016-06-03 13:28:20 --> Helper loaded: form_helper
INFO - 2016-06-03 13:28:20 --> Database Driver Class Initialized
INFO - 2016-06-03 13:28:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:28:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:28:20 --> Email Class Initialized
INFO - 2016-06-03 13:28:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:28:20 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:28:20 --> Helper loaded: language_helper
INFO - 2016-06-03 13:28:20 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:28:20 --> Model Class Initialized
INFO - 2016-06-03 13:28:20 --> Helper loaded: date_helper
INFO - 2016-06-03 13:28:20 --> Controller Class Initialized
INFO - 2016-06-03 13:28:20 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:28:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:28:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:28:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:28:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:28:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:28:20 --> Model Class Initialized
INFO - 2016-06-03 13:28:20 --> Form Validation Class Initialized
INFO - 2016-06-03 13:28:53 --> Config Class Initialized
INFO - 2016-06-03 13:28:53 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:28:53 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:28:53 --> Utf8 Class Initialized
INFO - 2016-06-03 13:28:53 --> URI Class Initialized
INFO - 2016-06-03 13:28:53 --> Router Class Initialized
INFO - 2016-06-03 13:28:53 --> Output Class Initialized
INFO - 2016-06-03 13:28:53 --> Security Class Initialized
DEBUG - 2016-06-03 13:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:28:53 --> CSRF cookie sent
INFO - 2016-06-03 13:28:53 --> Input Class Initialized
INFO - 2016-06-03 13:28:53 --> Language Class Initialized
INFO - 2016-06-03 13:28:53 --> Loader Class Initialized
INFO - 2016-06-03 13:28:53 --> Helper loaded: form_helper
INFO - 2016-06-03 13:28:53 --> Database Driver Class Initialized
INFO - 2016-06-03 13:28:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:28:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:28:53 --> Email Class Initialized
INFO - 2016-06-03 13:28:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:28:53 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:28:53 --> Helper loaded: language_helper
INFO - 2016-06-03 13:28:53 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:28:53 --> Model Class Initialized
INFO - 2016-06-03 13:28:53 --> Helper loaded: date_helper
INFO - 2016-06-03 13:28:53 --> Controller Class Initialized
INFO - 2016-06-03 13:28:53 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:28:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:28:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:28:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:28:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:28:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:28:53 --> Model Class Initialized
INFO - 2016-06-03 13:28:53 --> Form Validation Class Initialized
INFO - 2016-06-03 13:31:16 --> Config Class Initialized
INFO - 2016-06-03 13:31:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:31:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:31:16 --> Utf8 Class Initialized
INFO - 2016-06-03 13:31:16 --> URI Class Initialized
INFO - 2016-06-03 13:31:16 --> Router Class Initialized
INFO - 2016-06-03 13:31:16 --> Output Class Initialized
INFO - 2016-06-03 13:31:16 --> Security Class Initialized
DEBUG - 2016-06-03 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:31:16 --> CSRF cookie sent
INFO - 2016-06-03 13:31:16 --> Input Class Initialized
INFO - 2016-06-03 13:31:16 --> Language Class Initialized
INFO - 2016-06-03 13:31:16 --> Loader Class Initialized
INFO - 2016-06-03 13:31:16 --> Helper loaded: form_helper
INFO - 2016-06-03 13:31:16 --> Database Driver Class Initialized
INFO - 2016-06-03 13:31:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:31:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:31:16 --> Email Class Initialized
INFO - 2016-06-03 13:31:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:31:16 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:31:16 --> Helper loaded: language_helper
INFO - 2016-06-03 13:31:16 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:31:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:31:16 --> Model Class Initialized
INFO - 2016-06-03 13:31:16 --> Helper loaded: date_helper
INFO - 2016-06-03 13:31:16 --> Controller Class Initialized
INFO - 2016-06-03 13:31:16 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:31:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:31:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:31:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:31:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:31:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:31:16 --> Model Class Initialized
INFO - 2016-06-03 13:31:16 --> Form Validation Class Initialized
INFO - 2016-06-03 13:31:41 --> Config Class Initialized
INFO - 2016-06-03 13:31:41 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:31:41 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:31:41 --> Utf8 Class Initialized
INFO - 2016-06-03 13:31:41 --> URI Class Initialized
INFO - 2016-06-03 13:31:41 --> Router Class Initialized
INFO - 2016-06-03 13:31:41 --> Output Class Initialized
INFO - 2016-06-03 13:31:41 --> Security Class Initialized
DEBUG - 2016-06-03 13:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:31:41 --> CSRF cookie sent
INFO - 2016-06-03 13:31:41 --> Input Class Initialized
INFO - 2016-06-03 13:31:41 --> Language Class Initialized
INFO - 2016-06-03 13:31:41 --> Loader Class Initialized
INFO - 2016-06-03 13:31:41 --> Helper loaded: form_helper
INFO - 2016-06-03 13:31:41 --> Database Driver Class Initialized
INFO - 2016-06-03 13:31:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:31:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:31:41 --> Email Class Initialized
INFO - 2016-06-03 13:31:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:31:41 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:31:41 --> Helper loaded: language_helper
INFO - 2016-06-03 13:31:41 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:31:41 --> Model Class Initialized
INFO - 2016-06-03 13:31:41 --> Helper loaded: date_helper
INFO - 2016-06-03 13:31:41 --> Controller Class Initialized
INFO - 2016-06-03 13:31:41 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:31:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:31:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:31:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:31:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:31:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:31:41 --> Model Class Initialized
INFO - 2016-06-03 13:31:41 --> Form Validation Class Initialized
INFO - 2016-06-03 13:40:56 --> Config Class Initialized
INFO - 2016-06-03 13:40:56 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:40:56 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:40:56 --> Utf8 Class Initialized
INFO - 2016-06-03 13:40:56 --> URI Class Initialized
INFO - 2016-06-03 13:40:56 --> Router Class Initialized
INFO - 2016-06-03 13:40:56 --> Output Class Initialized
INFO - 2016-06-03 13:40:56 --> Security Class Initialized
DEBUG - 2016-06-03 13:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:40:56 --> CSRF cookie sent
INFO - 2016-06-03 13:40:56 --> Input Class Initialized
INFO - 2016-06-03 13:40:56 --> Language Class Initialized
INFO - 2016-06-03 13:40:56 --> Loader Class Initialized
INFO - 2016-06-03 13:40:56 --> Helper loaded: form_helper
INFO - 2016-06-03 13:40:56 --> Database Driver Class Initialized
INFO - 2016-06-03 13:40:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:40:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:40:56 --> Email Class Initialized
INFO - 2016-06-03 13:40:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:40:56 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:40:56 --> Helper loaded: language_helper
INFO - 2016-06-03 13:40:56 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:40:56 --> Model Class Initialized
INFO - 2016-06-03 13:40:56 --> Helper loaded: date_helper
INFO - 2016-06-03 13:40:56 --> Controller Class Initialized
INFO - 2016-06-03 13:40:56 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:40:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:40:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:40:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:40:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:40:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:40:56 --> Model Class Initialized
INFO - 2016-06-03 13:40:56 --> Form Validation Class Initialized
INFO - 2016-06-03 13:41:50 --> Config Class Initialized
INFO - 2016-06-03 13:41:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:41:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:41:50 --> Utf8 Class Initialized
INFO - 2016-06-03 13:41:50 --> URI Class Initialized
INFO - 2016-06-03 13:41:50 --> Router Class Initialized
INFO - 2016-06-03 13:41:50 --> Output Class Initialized
INFO - 2016-06-03 13:41:50 --> Security Class Initialized
DEBUG - 2016-06-03 13:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:41:50 --> CSRF cookie sent
INFO - 2016-06-03 13:41:50 --> Input Class Initialized
INFO - 2016-06-03 13:41:50 --> Language Class Initialized
INFO - 2016-06-03 13:41:50 --> Loader Class Initialized
INFO - 2016-06-03 13:41:50 --> Helper loaded: form_helper
INFO - 2016-06-03 13:41:50 --> Database Driver Class Initialized
INFO - 2016-06-03 13:41:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:41:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:41:50 --> Email Class Initialized
INFO - 2016-06-03 13:41:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:41:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:41:50 --> Helper loaded: language_helper
INFO - 2016-06-03 13:41:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:41:50 --> Model Class Initialized
INFO - 2016-06-03 13:41:50 --> Helper loaded: date_helper
INFO - 2016-06-03 13:41:50 --> Controller Class Initialized
INFO - 2016-06-03 13:41:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:41:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:41:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:41:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:41:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:41:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:41:50 --> Model Class Initialized
INFO - 2016-06-03 13:41:50 --> Form Validation Class Initialized
INFO - 2016-06-03 13:46:33 --> Config Class Initialized
INFO - 2016-06-03 13:46:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 13:46:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 13:46:33 --> Utf8 Class Initialized
INFO - 2016-06-03 13:46:33 --> URI Class Initialized
INFO - 2016-06-03 13:46:33 --> Router Class Initialized
INFO - 2016-06-03 13:46:33 --> Output Class Initialized
INFO - 2016-06-03 13:46:33 --> Security Class Initialized
DEBUG - 2016-06-03 13:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 13:46:33 --> CSRF cookie sent
INFO - 2016-06-03 13:46:33 --> Input Class Initialized
INFO - 2016-06-03 13:46:33 --> Language Class Initialized
INFO - 2016-06-03 13:46:33 --> Loader Class Initialized
INFO - 2016-06-03 13:46:33 --> Helper loaded: form_helper
INFO - 2016-06-03 13:46:33 --> Database Driver Class Initialized
INFO - 2016-06-03 13:46:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 13:46:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 13:46:33 --> Email Class Initialized
INFO - 2016-06-03 13:46:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 13:46:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 13:46:33 --> Helper loaded: language_helper
INFO - 2016-06-03 13:46:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 13:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 13:46:33 --> Model Class Initialized
INFO - 2016-06-03 13:46:33 --> Helper loaded: date_helper
INFO - 2016-06-03 13:46:33 --> Controller Class Initialized
INFO - 2016-06-03 13:46:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 13:46:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 13:46:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 13:46:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 13:46:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 13:46:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 13:46:33 --> Model Class Initialized
INFO - 2016-06-03 13:46:33 --> Form Validation Class Initialized
INFO - 2016-06-03 14:10:49 --> Config Class Initialized
INFO - 2016-06-03 14:10:49 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:10:49 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:10:49 --> Utf8 Class Initialized
INFO - 2016-06-03 14:10:49 --> URI Class Initialized
INFO - 2016-06-03 14:10:49 --> Router Class Initialized
INFO - 2016-06-03 14:10:49 --> Output Class Initialized
INFO - 2016-06-03 14:10:49 --> Security Class Initialized
DEBUG - 2016-06-03 14:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:10:49 --> CSRF cookie sent
INFO - 2016-06-03 14:10:49 --> Input Class Initialized
INFO - 2016-06-03 14:10:49 --> Language Class Initialized
INFO - 2016-06-03 14:10:49 --> Loader Class Initialized
INFO - 2016-06-03 14:10:49 --> Helper loaded: form_helper
INFO - 2016-06-03 14:10:49 --> Database Driver Class Initialized
INFO - 2016-06-03 14:10:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:10:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:10:49 --> Email Class Initialized
INFO - 2016-06-03 14:10:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:10:49 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:10:49 --> Helper loaded: language_helper
INFO - 2016-06-03 14:10:49 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:10:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:10:49 --> Model Class Initialized
INFO - 2016-06-03 14:10:49 --> Helper loaded: date_helper
INFO - 2016-06-03 14:10:49 --> Controller Class Initialized
INFO - 2016-06-03 14:10:49 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:10:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:10:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:10:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:10:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:10:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:10:49 --> Model Class Initialized
INFO - 2016-06-03 14:10:49 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:10:49 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
INFO - 2016-06-03 14:13:08 --> Config Class Initialized
INFO - 2016-06-03 14:13:08 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:13:08 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:13:08 --> Utf8 Class Initialized
INFO - 2016-06-03 14:13:08 --> URI Class Initialized
INFO - 2016-06-03 14:13:08 --> Router Class Initialized
INFO - 2016-06-03 14:13:08 --> Output Class Initialized
INFO - 2016-06-03 14:13:08 --> Security Class Initialized
DEBUG - 2016-06-03 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:13:08 --> CSRF cookie sent
INFO - 2016-06-03 14:13:08 --> Input Class Initialized
INFO - 2016-06-03 14:13:08 --> Language Class Initialized
ERROR - 2016-06-03 14:13:08 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:13:33 --> Config Class Initialized
INFO - 2016-06-03 14:13:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:13:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:13:33 --> Utf8 Class Initialized
INFO - 2016-06-03 14:13:33 --> URI Class Initialized
INFO - 2016-06-03 14:13:33 --> Router Class Initialized
INFO - 2016-06-03 14:13:33 --> Output Class Initialized
INFO - 2016-06-03 14:13:33 --> Security Class Initialized
DEBUG - 2016-06-03 14:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:13:33 --> CSRF cookie sent
INFO - 2016-06-03 14:13:33 --> Input Class Initialized
INFO - 2016-06-03 14:13:33 --> Language Class Initialized
INFO - 2016-06-03 14:13:33 --> Loader Class Initialized
INFO - 2016-06-03 14:13:33 --> Helper loaded: form_helper
INFO - 2016-06-03 14:13:33 --> Database Driver Class Initialized
INFO - 2016-06-03 14:13:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:13:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:13:33 --> Email Class Initialized
INFO - 2016-06-03 14:13:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:13:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:13:33 --> Helper loaded: language_helper
INFO - 2016-06-03 14:13:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:13:33 --> Model Class Initialized
INFO - 2016-06-03 14:13:33 --> Helper loaded: date_helper
INFO - 2016-06-03 14:13:33 --> Controller Class Initialized
INFO - 2016-06-03 14:13:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:13:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:13:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:13:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:13:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:13:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:13:33 --> Model Class Initialized
INFO - 2016-06-03 14:13:33 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:13:33 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
INFO - 2016-06-03 14:14:33 --> Config Class Initialized
INFO - 2016-06-03 14:14:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:14:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:14:33 --> Utf8 Class Initialized
INFO - 2016-06-03 14:14:33 --> URI Class Initialized
INFO - 2016-06-03 14:14:33 --> Router Class Initialized
INFO - 2016-06-03 14:14:33 --> Output Class Initialized
INFO - 2016-06-03 14:14:33 --> Security Class Initialized
DEBUG - 2016-06-03 14:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:14:33 --> CSRF cookie sent
INFO - 2016-06-03 14:14:33 --> Input Class Initialized
INFO - 2016-06-03 14:14:33 --> Language Class Initialized
INFO - 2016-06-03 14:14:33 --> Loader Class Initialized
INFO - 2016-06-03 14:14:33 --> Helper loaded: form_helper
INFO - 2016-06-03 14:14:33 --> Database Driver Class Initialized
INFO - 2016-06-03 14:14:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:14:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:14:33 --> Email Class Initialized
INFO - 2016-06-03 14:14:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:14:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:14:33 --> Helper loaded: language_helper
INFO - 2016-06-03 14:14:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:14:33 --> Model Class Initialized
INFO - 2016-06-03 14:14:33 --> Helper loaded: date_helper
INFO - 2016-06-03 14:14:33 --> Controller Class Initialized
INFO - 2016-06-03 14:14:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:14:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:14:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:14:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:14:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:14:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:14:33 --> Model Class Initialized
INFO - 2016-06-03 14:14:33 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:14:33 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
INFO - 2016-06-03 14:17:57 --> Config Class Initialized
INFO - 2016-06-03 14:17:57 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:17:57 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:17:57 --> Utf8 Class Initialized
INFO - 2016-06-03 14:17:57 --> URI Class Initialized
INFO - 2016-06-03 14:17:57 --> Router Class Initialized
INFO - 2016-06-03 14:17:57 --> Output Class Initialized
INFO - 2016-06-03 14:17:57 --> Security Class Initialized
DEBUG - 2016-06-03 14:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:17:57 --> CSRF cookie sent
INFO - 2016-06-03 14:17:57 --> Input Class Initialized
INFO - 2016-06-03 14:17:57 --> Language Class Initialized
INFO - 2016-06-03 14:17:57 --> Loader Class Initialized
INFO - 2016-06-03 14:17:57 --> Helper loaded: form_helper
INFO - 2016-06-03 14:17:57 --> Database Driver Class Initialized
INFO - 2016-06-03 14:17:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:17:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:17:57 --> Email Class Initialized
INFO - 2016-06-03 14:17:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:17:57 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:17:57 --> Helper loaded: language_helper
INFO - 2016-06-03 14:17:57 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:17:57 --> Model Class Initialized
INFO - 2016-06-03 14:17:57 --> Helper loaded: date_helper
INFO - 2016-06-03 14:17:57 --> Controller Class Initialized
INFO - 2016-06-03 14:17:57 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:17:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:17:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:17:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:17:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:17:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:17:57 --> Model Class Initialized
INFO - 2016-06-03 14:17:57 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:17:57 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:17:59 --> Config Class Initialized
INFO - 2016-06-03 14:17:59 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:17:59 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:17:59 --> Utf8 Class Initialized
INFO - 2016-06-03 14:17:59 --> URI Class Initialized
INFO - 2016-06-03 14:17:59 --> Router Class Initialized
INFO - 2016-06-03 14:17:59 --> Output Class Initialized
INFO - 2016-06-03 14:17:59 --> Security Class Initialized
DEBUG - 2016-06-03 14:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:17:59 --> CSRF cookie sent
INFO - 2016-06-03 14:17:59 --> Input Class Initialized
INFO - 2016-06-03 14:17:59 --> Language Class Initialized
INFO - 2016-06-03 14:17:59 --> Loader Class Initialized
INFO - 2016-06-03 14:17:59 --> Helper loaded: form_helper
INFO - 2016-06-03 14:17:59 --> Database Driver Class Initialized
INFO - 2016-06-03 14:17:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:17:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:17:59 --> Email Class Initialized
INFO - 2016-06-03 14:17:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:17:59 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:17:59 --> Helper loaded: language_helper
INFO - 2016-06-03 14:17:59 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:17:59 --> Model Class Initialized
INFO - 2016-06-03 14:17:59 --> Helper loaded: date_helper
INFO - 2016-06-03 14:17:59 --> Controller Class Initialized
INFO - 2016-06-03 14:17:59 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:17:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:17:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:17:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:17:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:17:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:17:59 --> Model Class Initialized
INFO - 2016-06-03 14:17:59 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:17:59 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:18:49 --> Config Class Initialized
INFO - 2016-06-03 14:18:49 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:18:49 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:18:49 --> Utf8 Class Initialized
INFO - 2016-06-03 14:18:49 --> URI Class Initialized
INFO - 2016-06-03 14:18:49 --> Router Class Initialized
INFO - 2016-06-03 14:18:49 --> Output Class Initialized
INFO - 2016-06-03 14:18:49 --> Security Class Initialized
DEBUG - 2016-06-03 14:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:18:49 --> CSRF cookie sent
INFO - 2016-06-03 14:18:49 --> Input Class Initialized
INFO - 2016-06-03 14:18:49 --> Language Class Initialized
INFO - 2016-06-03 14:18:49 --> Loader Class Initialized
INFO - 2016-06-03 14:18:49 --> Helper loaded: form_helper
INFO - 2016-06-03 14:18:49 --> Database Driver Class Initialized
INFO - 2016-06-03 14:18:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:18:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:18:49 --> Email Class Initialized
INFO - 2016-06-03 14:18:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:18:49 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:18:49 --> Helper loaded: language_helper
INFO - 2016-06-03 14:18:49 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:18:49 --> Model Class Initialized
INFO - 2016-06-03 14:18:49 --> Helper loaded: date_helper
INFO - 2016-06-03 14:18:49 --> Controller Class Initialized
INFO - 2016-06-03 14:18:49 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:18:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:18:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:18:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:18:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:18:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:18:49 --> Model Class Initialized
INFO - 2016-06-03 14:18:49 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:18:49 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:16 --> Config Class Initialized
INFO - 2016-06-03 14:19:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:16 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:16 --> URI Class Initialized
INFO - 2016-06-03 14:19:16 --> Router Class Initialized
INFO - 2016-06-03 14:19:16 --> Output Class Initialized
INFO - 2016-06-03 14:19:16 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:16 --> CSRF cookie sent
INFO - 2016-06-03 14:19:16 --> Input Class Initialized
INFO - 2016-06-03 14:19:16 --> Language Class Initialized
INFO - 2016-06-03 14:19:16 --> Loader Class Initialized
INFO - 2016-06-03 14:19:16 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:16 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:17 --> Email Class Initialized
INFO - 2016-06-03 14:19:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:17 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:17 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:17 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:17 --> Model Class Initialized
INFO - 2016-06-03 14:19:17 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:17 --> Controller Class Initialized
INFO - 2016-06-03 14:19:17 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:17 --> Model Class Initialized
INFO - 2016-06-03 14:19:17 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:17 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:18 --> Config Class Initialized
INFO - 2016-06-03 14:19:18 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:18 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:18 --> URI Class Initialized
INFO - 2016-06-03 14:19:18 --> Router Class Initialized
INFO - 2016-06-03 14:19:18 --> Output Class Initialized
INFO - 2016-06-03 14:19:18 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:18 --> CSRF cookie sent
INFO - 2016-06-03 14:19:18 --> Input Class Initialized
INFO - 2016-06-03 14:19:18 --> Language Class Initialized
INFO - 2016-06-03 14:19:18 --> Loader Class Initialized
INFO - 2016-06-03 14:19:18 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:18 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:18 --> Email Class Initialized
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:18 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:18 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:18 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:18 --> Model Class Initialized
INFO - 2016-06-03 14:19:18 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:18 --> Controller Class Initialized
INFO - 2016-06-03 14:19:18 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:18 --> Model Class Initialized
INFO - 2016-06-03 14:19:18 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:18 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:18 --> Config Class Initialized
INFO - 2016-06-03 14:19:18 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:18 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:18 --> URI Class Initialized
INFO - 2016-06-03 14:19:18 --> Router Class Initialized
INFO - 2016-06-03 14:19:18 --> Output Class Initialized
INFO - 2016-06-03 14:19:18 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:18 --> CSRF cookie sent
INFO - 2016-06-03 14:19:18 --> Input Class Initialized
INFO - 2016-06-03 14:19:18 --> Language Class Initialized
INFO - 2016-06-03 14:19:18 --> Loader Class Initialized
INFO - 2016-06-03 14:19:18 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:18 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:18 --> Email Class Initialized
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:18 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:18 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:18 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:18 --> Model Class Initialized
INFO - 2016-06-03 14:19:18 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:18 --> Controller Class Initialized
INFO - 2016-06-03 14:19:18 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:18 --> Model Class Initialized
INFO - 2016-06-03 14:19:18 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:18 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:19 --> Config Class Initialized
INFO - 2016-06-03 14:19:19 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:19 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:19 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:19 --> URI Class Initialized
INFO - 2016-06-03 14:19:19 --> Router Class Initialized
INFO - 2016-06-03 14:19:19 --> Output Class Initialized
INFO - 2016-06-03 14:19:19 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:19 --> CSRF cookie sent
INFO - 2016-06-03 14:19:19 --> Input Class Initialized
INFO - 2016-06-03 14:19:19 --> Language Class Initialized
INFO - 2016-06-03 14:19:19 --> Loader Class Initialized
INFO - 2016-06-03 14:19:19 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:19 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:19 --> Email Class Initialized
INFO - 2016-06-03 14:19:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:19 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:19 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:19 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:19 --> Model Class Initialized
INFO - 2016-06-03 14:19:19 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:19 --> Controller Class Initialized
INFO - 2016-06-03 14:19:19 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:19 --> Model Class Initialized
INFO - 2016-06-03 14:19:19 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:19 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:43 --> Config Class Initialized
INFO - 2016-06-03 14:19:43 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:43 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:43 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:43 --> URI Class Initialized
INFO - 2016-06-03 14:19:43 --> Router Class Initialized
INFO - 2016-06-03 14:19:43 --> Output Class Initialized
INFO - 2016-06-03 14:19:43 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:43 --> CSRF cookie sent
INFO - 2016-06-03 14:19:43 --> Input Class Initialized
INFO - 2016-06-03 14:19:43 --> Language Class Initialized
INFO - 2016-06-03 14:19:43 --> Loader Class Initialized
INFO - 2016-06-03 14:19:43 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:43 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:43 --> Email Class Initialized
INFO - 2016-06-03 14:19:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:43 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:43 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:43 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:43 --> Model Class Initialized
INFO - 2016-06-03 14:19:43 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:43 --> Controller Class Initialized
INFO - 2016-06-03 14:19:43 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:43 --> Model Class Initialized
INFO - 2016-06-03 14:19:43 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:43 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:45 --> Config Class Initialized
INFO - 2016-06-03 14:19:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:45 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:45 --> URI Class Initialized
INFO - 2016-06-03 14:19:45 --> Router Class Initialized
INFO - 2016-06-03 14:19:45 --> Output Class Initialized
INFO - 2016-06-03 14:19:45 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:45 --> CSRF cookie sent
INFO - 2016-06-03 14:19:45 --> Input Class Initialized
INFO - 2016-06-03 14:19:45 --> Language Class Initialized
INFO - 2016-06-03 14:19:45 --> Loader Class Initialized
INFO - 2016-06-03 14:19:45 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:45 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:45 --> Email Class Initialized
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:45 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:45 --> Model Class Initialized
INFO - 2016-06-03 14:19:45 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:45 --> Controller Class Initialized
INFO - 2016-06-03 14:19:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:45 --> Model Class Initialized
INFO - 2016-06-03 14:19:45 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:45 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:45 --> Config Class Initialized
INFO - 2016-06-03 14:19:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:45 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:45 --> URI Class Initialized
INFO - 2016-06-03 14:19:45 --> Router Class Initialized
INFO - 2016-06-03 14:19:45 --> Output Class Initialized
INFO - 2016-06-03 14:19:45 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:45 --> CSRF cookie sent
INFO - 2016-06-03 14:19:45 --> Input Class Initialized
INFO - 2016-06-03 14:19:45 --> Language Class Initialized
INFO - 2016-06-03 14:19:45 --> Loader Class Initialized
INFO - 2016-06-03 14:19:45 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:45 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:45 --> Email Class Initialized
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:45 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:45 --> Model Class Initialized
INFO - 2016-06-03 14:19:45 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:45 --> Controller Class Initialized
INFO - 2016-06-03 14:19:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:45 --> Model Class Initialized
INFO - 2016-06-03 14:19:45 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:45 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:46 --> Config Class Initialized
INFO - 2016-06-03 14:19:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:46 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:46 --> URI Class Initialized
INFO - 2016-06-03 14:19:46 --> Router Class Initialized
INFO - 2016-06-03 14:19:46 --> Output Class Initialized
INFO - 2016-06-03 14:19:46 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:46 --> CSRF cookie sent
INFO - 2016-06-03 14:19:46 --> Input Class Initialized
INFO - 2016-06-03 14:19:46 --> Language Class Initialized
INFO - 2016-06-03 14:19:46 --> Loader Class Initialized
INFO - 2016-06-03 14:19:46 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:46 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:46 --> Email Class Initialized
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:46 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:46 --> Model Class Initialized
INFO - 2016-06-03 14:19:46 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:46 --> Controller Class Initialized
INFO - 2016-06-03 14:19:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:46 --> Model Class Initialized
INFO - 2016-06-03 14:19:46 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:46 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:46 --> Config Class Initialized
INFO - 2016-06-03 14:19:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:46 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:46 --> URI Class Initialized
INFO - 2016-06-03 14:19:46 --> Router Class Initialized
INFO - 2016-06-03 14:19:46 --> Output Class Initialized
INFO - 2016-06-03 14:19:46 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:46 --> CSRF cookie sent
INFO - 2016-06-03 14:19:46 --> Input Class Initialized
INFO - 2016-06-03 14:19:46 --> Language Class Initialized
INFO - 2016-06-03 14:19:46 --> Loader Class Initialized
INFO - 2016-06-03 14:19:46 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:46 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:46 --> Email Class Initialized
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:46 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:46 --> Model Class Initialized
INFO - 2016-06-03 14:19:46 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:46 --> Controller Class Initialized
INFO - 2016-06-03 14:19:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:46 --> Model Class Initialized
INFO - 2016-06-03 14:19:46 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:46 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:46 --> Config Class Initialized
INFO - 2016-06-03 14:19:47 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:47 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:47 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:47 --> URI Class Initialized
INFO - 2016-06-03 14:19:47 --> Router Class Initialized
INFO - 2016-06-03 14:19:47 --> Output Class Initialized
INFO - 2016-06-03 14:19:47 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:47 --> CSRF cookie sent
INFO - 2016-06-03 14:19:47 --> Input Class Initialized
INFO - 2016-06-03 14:19:47 --> Language Class Initialized
INFO - 2016-06-03 14:19:47 --> Loader Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:47 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:47 --> Email Class Initialized
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:47 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:47 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:47 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:47 --> Model Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:47 --> Controller Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:47 --> Model Class Initialized
INFO - 2016-06-03 14:19:47 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:47 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:47 --> Config Class Initialized
INFO - 2016-06-03 14:19:47 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:47 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:47 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:47 --> URI Class Initialized
INFO - 2016-06-03 14:19:47 --> Router Class Initialized
INFO - 2016-06-03 14:19:47 --> Output Class Initialized
INFO - 2016-06-03 14:19:47 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:47 --> CSRF cookie sent
INFO - 2016-06-03 14:19:47 --> Input Class Initialized
INFO - 2016-06-03 14:19:47 --> Language Class Initialized
INFO - 2016-06-03 14:19:47 --> Loader Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:47 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:47 --> Email Class Initialized
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:47 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:47 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:47 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:47 --> Model Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:47 --> Controller Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:47 --> Model Class Initialized
INFO - 2016-06-03 14:19:47 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:47 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:19:47 --> Config Class Initialized
INFO - 2016-06-03 14:19:47 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:19:47 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:19:47 --> Utf8 Class Initialized
INFO - 2016-06-03 14:19:47 --> URI Class Initialized
INFO - 2016-06-03 14:19:47 --> Router Class Initialized
INFO - 2016-06-03 14:19:47 --> Output Class Initialized
INFO - 2016-06-03 14:19:47 --> Security Class Initialized
DEBUG - 2016-06-03 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:19:47 --> CSRF cookie sent
INFO - 2016-06-03 14:19:47 --> Input Class Initialized
INFO - 2016-06-03 14:19:47 --> Language Class Initialized
INFO - 2016-06-03 14:19:47 --> Loader Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: form_helper
INFO - 2016-06-03 14:19:47 --> Database Driver Class Initialized
INFO - 2016-06-03 14:19:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:19:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:19:47 --> Email Class Initialized
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:19:47 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:19:47 --> Helper loaded: language_helper
INFO - 2016-06-03 14:19:47 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:19:47 --> Model Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: date_helper
INFO - 2016-06-03 14:19:47 --> Controller Class Initialized
INFO - 2016-06-03 14:19:47 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:19:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:19:47 --> Model Class Initialized
INFO - 2016-06-03 14:19:47 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:19:47 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 14:20:13 --> Config Class Initialized
INFO - 2016-06-03 14:20:13 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:20:13 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:20:13 --> Utf8 Class Initialized
INFO - 2016-06-03 14:20:13 --> URI Class Initialized
INFO - 2016-06-03 14:20:13 --> Router Class Initialized
INFO - 2016-06-03 14:20:13 --> Output Class Initialized
INFO - 2016-06-03 14:20:13 --> Security Class Initialized
DEBUG - 2016-06-03 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:20:13 --> CSRF cookie sent
INFO - 2016-06-03 14:20:13 --> Input Class Initialized
INFO - 2016-06-03 14:20:13 --> Language Class Initialized
INFO - 2016-06-03 14:20:13 --> Loader Class Initialized
INFO - 2016-06-03 14:20:13 --> Helper loaded: form_helper
INFO - 2016-06-03 14:20:13 --> Database Driver Class Initialized
INFO - 2016-06-03 14:20:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:20:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:20:13 --> Email Class Initialized
INFO - 2016-06-03 14:20:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:20:13 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:20:13 --> Helper loaded: language_helper
INFO - 2016-06-03 14:20:13 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:20:13 --> Model Class Initialized
INFO - 2016-06-03 14:20:13 --> Helper loaded: date_helper
INFO - 2016-06-03 14:20:13 --> Controller Class Initialized
INFO - 2016-06-03 14:20:13 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:20:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:20:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:20:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:20:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:20:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:20:13 --> Model Class Initialized
INFO - 2016-06-03 14:20:13 --> Form Validation Class Initialized
INFO - 2016-06-03 14:23:09 --> Config Class Initialized
INFO - 2016-06-03 14:23:09 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:23:09 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:23:09 --> Utf8 Class Initialized
INFO - 2016-06-03 14:23:09 --> URI Class Initialized
INFO - 2016-06-03 14:23:09 --> Router Class Initialized
INFO - 2016-06-03 14:23:09 --> Output Class Initialized
INFO - 2016-06-03 14:23:09 --> Security Class Initialized
DEBUG - 2016-06-03 14:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:23:09 --> CSRF cookie sent
INFO - 2016-06-03 14:23:09 --> Input Class Initialized
INFO - 2016-06-03 14:23:09 --> Language Class Initialized
INFO - 2016-06-03 14:23:09 --> Loader Class Initialized
INFO - 2016-06-03 14:23:09 --> Helper loaded: form_helper
INFO - 2016-06-03 14:23:09 --> Database Driver Class Initialized
INFO - 2016-06-03 14:23:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:23:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:23:09 --> Email Class Initialized
INFO - 2016-06-03 14:23:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:23:09 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:23:09 --> Helper loaded: language_helper
INFO - 2016-06-03 14:23:09 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:23:09 --> Model Class Initialized
INFO - 2016-06-03 14:23:09 --> Helper loaded: date_helper
INFO - 2016-06-03 14:23:09 --> Controller Class Initialized
INFO - 2016-06-03 14:23:09 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:23:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:23:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:23:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:23:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:23:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:23:10 --> Model Class Initialized
INFO - 2016-06-03 14:23:10 --> Form Validation Class Initialized
INFO - 2016-06-03 14:38:22 --> Config Class Initialized
INFO - 2016-06-03 14:38:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:38:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:38:22 --> Utf8 Class Initialized
INFO - 2016-06-03 14:38:22 --> URI Class Initialized
INFO - 2016-06-03 14:38:22 --> Router Class Initialized
INFO - 2016-06-03 14:38:22 --> Output Class Initialized
INFO - 2016-06-03 14:38:22 --> Security Class Initialized
DEBUG - 2016-06-03 14:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:38:22 --> CSRF cookie sent
INFO - 2016-06-03 14:38:22 --> Input Class Initialized
INFO - 2016-06-03 14:38:22 --> Language Class Initialized
ERROR - 2016-06-03 14:38:22 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/demis/www/platformadiabet/application/controllers/Diabet.php 122
INFO - 2016-06-03 14:38:37 --> Config Class Initialized
INFO - 2016-06-03 14:38:37 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:38:37 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:38:37 --> Utf8 Class Initialized
INFO - 2016-06-03 14:38:37 --> URI Class Initialized
INFO - 2016-06-03 14:38:37 --> Router Class Initialized
INFO - 2016-06-03 14:38:37 --> Output Class Initialized
INFO - 2016-06-03 14:38:37 --> Security Class Initialized
DEBUG - 2016-06-03 14:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:38:37 --> CSRF cookie sent
INFO - 2016-06-03 14:38:37 --> Input Class Initialized
INFO - 2016-06-03 14:38:37 --> Language Class Initialized
INFO - 2016-06-03 14:38:37 --> Loader Class Initialized
INFO - 2016-06-03 14:38:37 --> Helper loaded: form_helper
INFO - 2016-06-03 14:38:37 --> Database Driver Class Initialized
INFO - 2016-06-03 14:38:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:38:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:38:37 --> Email Class Initialized
INFO - 2016-06-03 14:38:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:38:37 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:38:37 --> Helper loaded: language_helper
INFO - 2016-06-03 14:38:37 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:38:37 --> Model Class Initialized
INFO - 2016-06-03 14:38:37 --> Helper loaded: date_helper
INFO - 2016-06-03 14:38:37 --> Controller Class Initialized
INFO - 2016-06-03 14:38:37 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:38:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:38:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:38:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:38:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:38:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:38:37 --> Model Class Initialized
INFO - 2016-06-03 14:38:37 --> Form Validation Class Initialized
INFO - 2016-06-03 14:40:14 --> Config Class Initialized
INFO - 2016-06-03 14:40:14 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:40:14 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:40:14 --> Utf8 Class Initialized
INFO - 2016-06-03 14:40:14 --> URI Class Initialized
INFO - 2016-06-03 14:40:14 --> Router Class Initialized
INFO - 2016-06-03 14:40:14 --> Output Class Initialized
INFO - 2016-06-03 14:40:14 --> Security Class Initialized
DEBUG - 2016-06-03 14:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:40:14 --> CSRF cookie sent
INFO - 2016-06-03 14:40:14 --> Input Class Initialized
INFO - 2016-06-03 14:40:14 --> Language Class Initialized
INFO - 2016-06-03 14:40:14 --> Loader Class Initialized
INFO - 2016-06-03 14:40:14 --> Helper loaded: form_helper
INFO - 2016-06-03 14:40:14 --> Database Driver Class Initialized
INFO - 2016-06-03 14:40:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:40:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:40:14 --> Email Class Initialized
INFO - 2016-06-03 14:40:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:40:14 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:40:14 --> Helper loaded: language_helper
INFO - 2016-06-03 14:40:14 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:40:14 --> Model Class Initialized
INFO - 2016-06-03 14:40:14 --> Helper loaded: date_helper
INFO - 2016-06-03 14:40:14 --> Controller Class Initialized
INFO - 2016-06-03 14:40:14 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:40:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:40:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:40:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:40:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:40:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:40:14 --> Model Class Initialized
INFO - 2016-06-03 14:40:14 --> Form Validation Class Initialized
INFO - 2016-06-03 14:40:44 --> Config Class Initialized
INFO - 2016-06-03 14:40:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:40:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:40:44 --> Utf8 Class Initialized
INFO - 2016-06-03 14:40:44 --> URI Class Initialized
INFO - 2016-06-03 14:40:44 --> Router Class Initialized
INFO - 2016-06-03 14:40:44 --> Output Class Initialized
INFO - 2016-06-03 14:40:44 --> Security Class Initialized
DEBUG - 2016-06-03 14:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:40:44 --> CSRF cookie sent
INFO - 2016-06-03 14:40:44 --> Input Class Initialized
INFO - 2016-06-03 14:40:44 --> Language Class Initialized
INFO - 2016-06-03 14:40:44 --> Loader Class Initialized
INFO - 2016-06-03 14:40:44 --> Helper loaded: form_helper
INFO - 2016-06-03 14:40:44 --> Database Driver Class Initialized
INFO - 2016-06-03 14:40:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:40:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:40:44 --> Email Class Initialized
INFO - 2016-06-03 14:40:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:40:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:40:44 --> Helper loaded: language_helper
INFO - 2016-06-03 14:40:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:40:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:40:44 --> Model Class Initialized
INFO - 2016-06-03 14:40:44 --> Helper loaded: date_helper
INFO - 2016-06-03 14:40:44 --> Controller Class Initialized
INFO - 2016-06-03 14:40:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:40:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:40:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:40:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:40:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:40:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:40:44 --> Model Class Initialized
INFO - 2016-06-03 14:40:44 --> Form Validation Class Initialized
INFO - 2016-06-03 14:40:52 --> Config Class Initialized
INFO - 2016-06-03 14:40:52 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:40:52 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:40:52 --> Utf8 Class Initialized
INFO - 2016-06-03 14:40:52 --> URI Class Initialized
INFO - 2016-06-03 14:40:52 --> Router Class Initialized
INFO - 2016-06-03 14:40:52 --> Output Class Initialized
INFO - 2016-06-03 14:40:52 --> Security Class Initialized
DEBUG - 2016-06-03 14:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:40:52 --> CSRF cookie sent
INFO - 2016-06-03 14:40:52 --> Input Class Initialized
INFO - 2016-06-03 14:40:52 --> Language Class Initialized
INFO - 2016-06-03 14:40:52 --> Loader Class Initialized
INFO - 2016-06-03 14:40:52 --> Helper loaded: form_helper
INFO - 2016-06-03 14:40:52 --> Database Driver Class Initialized
INFO - 2016-06-03 14:40:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:40:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:40:52 --> Email Class Initialized
INFO - 2016-06-03 14:40:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:40:52 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:40:52 --> Helper loaded: language_helper
INFO - 2016-06-03 14:40:52 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:40:52 --> Model Class Initialized
INFO - 2016-06-03 14:40:52 --> Helper loaded: date_helper
INFO - 2016-06-03 14:40:52 --> Controller Class Initialized
INFO - 2016-06-03 14:40:52 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:40:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:40:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:40:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:40:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:40:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:40:52 --> Model Class Initialized
INFO - 2016-06-03 14:40:52 --> Form Validation Class Initialized
INFO - 2016-06-03 14:42:26 --> Config Class Initialized
INFO - 2016-06-03 14:42:26 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:42:26 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:42:26 --> Utf8 Class Initialized
INFO - 2016-06-03 14:42:26 --> URI Class Initialized
INFO - 2016-06-03 14:42:26 --> Router Class Initialized
INFO - 2016-06-03 14:42:26 --> Output Class Initialized
INFO - 2016-06-03 14:42:26 --> Security Class Initialized
DEBUG - 2016-06-03 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:42:26 --> CSRF cookie sent
INFO - 2016-06-03 14:42:26 --> Input Class Initialized
INFO - 2016-06-03 14:42:26 --> Language Class Initialized
INFO - 2016-06-03 14:42:26 --> Loader Class Initialized
INFO - 2016-06-03 14:42:26 --> Helper loaded: form_helper
INFO - 2016-06-03 14:42:26 --> Database Driver Class Initialized
INFO - 2016-06-03 14:42:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:42:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:42:26 --> Email Class Initialized
INFO - 2016-06-03 14:42:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:42:26 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:42:26 --> Helper loaded: language_helper
INFO - 2016-06-03 14:42:26 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:42:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:42:26 --> Model Class Initialized
INFO - 2016-06-03 14:42:26 --> Helper loaded: date_helper
INFO - 2016-06-03 14:42:26 --> Controller Class Initialized
INFO - 2016-06-03 14:42:26 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:42:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:42:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:42:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:42:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:42:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:42:26 --> Model Class Initialized
INFO - 2016-06-03 14:42:26 --> Form Validation Class Initialized
INFO - 2016-06-03 14:42:56 --> Config Class Initialized
INFO - 2016-06-03 14:42:56 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:42:56 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:42:56 --> Utf8 Class Initialized
INFO - 2016-06-03 14:42:56 --> URI Class Initialized
INFO - 2016-06-03 14:42:56 --> Router Class Initialized
INFO - 2016-06-03 14:42:56 --> Output Class Initialized
INFO - 2016-06-03 14:42:56 --> Security Class Initialized
DEBUG - 2016-06-03 14:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:42:56 --> CSRF cookie sent
INFO - 2016-06-03 14:42:56 --> Input Class Initialized
INFO - 2016-06-03 14:42:56 --> Language Class Initialized
INFO - 2016-06-03 14:42:56 --> Loader Class Initialized
INFO - 2016-06-03 14:42:56 --> Helper loaded: form_helper
INFO - 2016-06-03 14:42:56 --> Database Driver Class Initialized
INFO - 2016-06-03 14:42:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:42:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:42:56 --> Email Class Initialized
INFO - 2016-06-03 14:42:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:42:56 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:42:56 --> Helper loaded: language_helper
INFO - 2016-06-03 14:42:56 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:42:56 --> Model Class Initialized
INFO - 2016-06-03 14:42:56 --> Helper loaded: date_helper
INFO - 2016-06-03 14:42:56 --> Controller Class Initialized
INFO - 2016-06-03 14:42:56 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:42:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:42:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:42:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:42:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:42:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:42:56 --> Model Class Initialized
INFO - 2016-06-03 14:42:56 --> Form Validation Class Initialized
INFO - 2016-06-03 14:43:19 --> Config Class Initialized
INFO - 2016-06-03 14:43:19 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:43:19 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:43:19 --> Utf8 Class Initialized
INFO - 2016-06-03 14:43:19 --> URI Class Initialized
INFO - 2016-06-03 14:43:19 --> Router Class Initialized
INFO - 2016-06-03 14:43:19 --> Output Class Initialized
INFO - 2016-06-03 14:43:19 --> Security Class Initialized
DEBUG - 2016-06-03 14:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:43:19 --> CSRF cookie sent
INFO - 2016-06-03 14:43:19 --> Input Class Initialized
INFO - 2016-06-03 14:43:19 --> Language Class Initialized
INFO - 2016-06-03 14:43:19 --> Loader Class Initialized
INFO - 2016-06-03 14:43:19 --> Helper loaded: form_helper
INFO - 2016-06-03 14:43:19 --> Database Driver Class Initialized
INFO - 2016-06-03 14:43:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:43:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:43:19 --> Email Class Initialized
INFO - 2016-06-03 14:43:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:43:19 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:43:19 --> Helper loaded: language_helper
INFO - 2016-06-03 14:43:19 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:43:19 --> Model Class Initialized
INFO - 2016-06-03 14:43:19 --> Helper loaded: date_helper
INFO - 2016-06-03 14:43:19 --> Controller Class Initialized
INFO - 2016-06-03 14:43:19 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:43:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:43:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:43:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:43:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:43:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:43:19 --> Model Class Initialized
INFO - 2016-06-03 14:43:19 --> Form Validation Class Initialized
INFO - 2016-06-03 14:43:42 --> Config Class Initialized
INFO - 2016-06-03 14:43:42 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:43:42 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:43:42 --> Utf8 Class Initialized
INFO - 2016-06-03 14:43:42 --> URI Class Initialized
INFO - 2016-06-03 14:43:42 --> Router Class Initialized
INFO - 2016-06-03 14:43:42 --> Output Class Initialized
INFO - 2016-06-03 14:43:42 --> Security Class Initialized
DEBUG - 2016-06-03 14:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:43:42 --> CSRF cookie sent
INFO - 2016-06-03 14:43:42 --> Input Class Initialized
INFO - 2016-06-03 14:43:42 --> Language Class Initialized
INFO - 2016-06-03 14:43:42 --> Loader Class Initialized
INFO - 2016-06-03 14:43:42 --> Helper loaded: form_helper
INFO - 2016-06-03 14:43:42 --> Database Driver Class Initialized
INFO - 2016-06-03 14:43:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:43:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:43:42 --> Email Class Initialized
INFO - 2016-06-03 14:43:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:43:42 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:43:42 --> Helper loaded: language_helper
INFO - 2016-06-03 14:43:42 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:43:42 --> Model Class Initialized
INFO - 2016-06-03 14:43:42 --> Helper loaded: date_helper
INFO - 2016-06-03 14:43:42 --> Controller Class Initialized
INFO - 2016-06-03 14:43:42 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:43:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:43:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:43:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:43:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:43:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:43:42 --> Model Class Initialized
INFO - 2016-06-03 14:43:42 --> Form Validation Class Initialized
INFO - 2016-06-03 14:44:22 --> Config Class Initialized
INFO - 2016-06-03 14:44:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:44:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:44:22 --> Utf8 Class Initialized
INFO - 2016-06-03 14:44:22 --> URI Class Initialized
INFO - 2016-06-03 14:44:22 --> Router Class Initialized
INFO - 2016-06-03 14:44:22 --> Output Class Initialized
INFO - 2016-06-03 14:44:22 --> Security Class Initialized
DEBUG - 2016-06-03 14:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:44:22 --> CSRF cookie sent
INFO - 2016-06-03 14:44:22 --> Input Class Initialized
INFO - 2016-06-03 14:44:22 --> Language Class Initialized
INFO - 2016-06-03 14:44:22 --> Loader Class Initialized
INFO - 2016-06-03 14:44:22 --> Helper loaded: form_helper
INFO - 2016-06-03 14:44:22 --> Database Driver Class Initialized
INFO - 2016-06-03 14:44:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:44:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:44:22 --> Email Class Initialized
INFO - 2016-06-03 14:44:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:44:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:44:22 --> Helper loaded: language_helper
INFO - 2016-06-03 14:44:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:44:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:44:22 --> Model Class Initialized
INFO - 2016-06-03 14:44:22 --> Helper loaded: date_helper
INFO - 2016-06-03 14:44:22 --> Controller Class Initialized
INFO - 2016-06-03 14:44:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:44:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:44:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:44:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:44:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:44:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:44:22 --> Model Class Initialized
INFO - 2016-06-03 14:44:22 --> Form Validation Class Initialized
INFO - 2016-06-03 14:45:29 --> Config Class Initialized
INFO - 2016-06-03 14:45:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:45:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:45:29 --> Utf8 Class Initialized
INFO - 2016-06-03 14:45:29 --> URI Class Initialized
INFO - 2016-06-03 14:45:29 --> Router Class Initialized
INFO - 2016-06-03 14:45:29 --> Output Class Initialized
INFO - 2016-06-03 14:45:29 --> Security Class Initialized
DEBUG - 2016-06-03 14:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:45:29 --> CSRF cookie sent
INFO - 2016-06-03 14:45:29 --> Input Class Initialized
INFO - 2016-06-03 14:45:29 --> Language Class Initialized
INFO - 2016-06-03 14:45:29 --> Loader Class Initialized
INFO - 2016-06-03 14:45:29 --> Helper loaded: form_helper
INFO - 2016-06-03 14:45:29 --> Database Driver Class Initialized
INFO - 2016-06-03 14:45:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:45:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:45:29 --> Email Class Initialized
INFO - 2016-06-03 14:45:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:45:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:45:29 --> Helper loaded: language_helper
INFO - 2016-06-03 14:45:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:45:29 --> Model Class Initialized
INFO - 2016-06-03 14:45:29 --> Helper loaded: date_helper
INFO - 2016-06-03 14:45:29 --> Controller Class Initialized
INFO - 2016-06-03 14:45:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:45:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:45:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:45:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:45:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:45:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:45:30 --> Model Class Initialized
INFO - 2016-06-03 14:45:30 --> Form Validation Class Initialized
INFO - 2016-06-03 14:46:16 --> Config Class Initialized
INFO - 2016-06-03 14:46:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:46:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:46:16 --> Utf8 Class Initialized
INFO - 2016-06-03 14:46:16 --> URI Class Initialized
INFO - 2016-06-03 14:46:16 --> Router Class Initialized
INFO - 2016-06-03 14:46:16 --> Output Class Initialized
INFO - 2016-06-03 14:46:16 --> Security Class Initialized
DEBUG - 2016-06-03 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:46:16 --> CSRF cookie sent
INFO - 2016-06-03 14:46:16 --> Input Class Initialized
INFO - 2016-06-03 14:46:16 --> Language Class Initialized
INFO - 2016-06-03 14:46:16 --> Loader Class Initialized
INFO - 2016-06-03 14:46:16 --> Helper loaded: form_helper
INFO - 2016-06-03 14:46:16 --> Database Driver Class Initialized
INFO - 2016-06-03 14:46:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:46:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:46:16 --> Email Class Initialized
INFO - 2016-06-03 14:46:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:46:16 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:46:16 --> Helper loaded: language_helper
INFO - 2016-06-03 14:46:16 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:46:16 --> Model Class Initialized
INFO - 2016-06-03 14:46:16 --> Helper loaded: date_helper
INFO - 2016-06-03 14:46:16 --> Controller Class Initialized
INFO - 2016-06-03 14:46:16 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:46:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:46:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:46:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:46:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:46:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:46:16 --> Model Class Initialized
INFO - 2016-06-03 14:46:16 --> Form Validation Class Initialized
INFO - 2016-06-03 14:47:19 --> Config Class Initialized
INFO - 2016-06-03 14:47:19 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:47:19 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:47:19 --> Utf8 Class Initialized
INFO - 2016-06-03 14:47:19 --> URI Class Initialized
INFO - 2016-06-03 14:47:19 --> Router Class Initialized
INFO - 2016-06-03 14:47:19 --> Output Class Initialized
INFO - 2016-06-03 14:47:19 --> Security Class Initialized
DEBUG - 2016-06-03 14:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:47:19 --> CSRF cookie sent
INFO - 2016-06-03 14:47:19 --> Input Class Initialized
INFO - 2016-06-03 14:47:19 --> Language Class Initialized
INFO - 2016-06-03 14:47:19 --> Loader Class Initialized
INFO - 2016-06-03 14:47:19 --> Helper loaded: form_helper
INFO - 2016-06-03 14:47:19 --> Database Driver Class Initialized
INFO - 2016-06-03 14:47:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:47:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:47:19 --> Email Class Initialized
INFO - 2016-06-03 14:47:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:47:19 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:47:19 --> Helper loaded: language_helper
INFO - 2016-06-03 14:47:19 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:47:19 --> Model Class Initialized
INFO - 2016-06-03 14:47:19 --> Helper loaded: date_helper
INFO - 2016-06-03 14:47:19 --> Controller Class Initialized
INFO - 2016-06-03 14:47:19 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:47:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:47:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:47:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:47:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:47:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:47:19 --> Model Class Initialized
INFO - 2016-06-03 14:47:19 --> Form Validation Class Initialized
INFO - 2016-06-03 14:47:50 --> Config Class Initialized
INFO - 2016-06-03 14:47:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:47:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:47:50 --> Utf8 Class Initialized
INFO - 2016-06-03 14:47:50 --> URI Class Initialized
INFO - 2016-06-03 14:47:50 --> Router Class Initialized
INFO - 2016-06-03 14:47:50 --> Output Class Initialized
INFO - 2016-06-03 14:47:50 --> Security Class Initialized
DEBUG - 2016-06-03 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:47:50 --> CSRF cookie sent
INFO - 2016-06-03 14:47:50 --> Input Class Initialized
INFO - 2016-06-03 14:47:50 --> Language Class Initialized
INFO - 2016-06-03 14:47:50 --> Loader Class Initialized
INFO - 2016-06-03 14:47:50 --> Helper loaded: form_helper
INFO - 2016-06-03 14:47:50 --> Database Driver Class Initialized
INFO - 2016-06-03 14:47:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:47:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:47:50 --> Email Class Initialized
INFO - 2016-06-03 14:47:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:47:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:47:50 --> Helper loaded: language_helper
INFO - 2016-06-03 14:47:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:47:50 --> Model Class Initialized
INFO - 2016-06-03 14:47:50 --> Helper loaded: date_helper
INFO - 2016-06-03 14:47:50 --> Controller Class Initialized
INFO - 2016-06-03 14:47:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:47:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:47:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:47:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:47:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:47:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:47:50 --> Model Class Initialized
INFO - 2016-06-03 14:47:50 --> Form Validation Class Initialized
INFO - 2016-06-03 14:48:46 --> Config Class Initialized
INFO - 2016-06-03 14:48:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:48:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:48:46 --> Utf8 Class Initialized
INFO - 2016-06-03 14:48:46 --> URI Class Initialized
INFO - 2016-06-03 14:48:46 --> Router Class Initialized
INFO - 2016-06-03 14:48:46 --> Output Class Initialized
INFO - 2016-06-03 14:48:46 --> Security Class Initialized
DEBUG - 2016-06-03 14:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:48:46 --> CSRF cookie sent
INFO - 2016-06-03 14:48:46 --> Input Class Initialized
INFO - 2016-06-03 14:48:46 --> Language Class Initialized
INFO - 2016-06-03 14:48:46 --> Loader Class Initialized
INFO - 2016-06-03 14:48:46 --> Helper loaded: form_helper
INFO - 2016-06-03 14:48:46 --> Database Driver Class Initialized
INFO - 2016-06-03 14:48:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:48:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:48:46 --> Email Class Initialized
INFO - 2016-06-03 14:48:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:48:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:48:46 --> Helper loaded: language_helper
INFO - 2016-06-03 14:48:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:48:46 --> Model Class Initialized
INFO - 2016-06-03 14:48:46 --> Helper loaded: date_helper
INFO - 2016-06-03 14:48:46 --> Controller Class Initialized
INFO - 2016-06-03 14:48:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:48:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:48:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:48:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:48:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:48:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:48:46 --> Model Class Initialized
INFO - 2016-06-03 14:48:46 --> Form Validation Class Initialized
INFO - 2016-06-03 14:49:21 --> Config Class Initialized
INFO - 2016-06-03 14:49:21 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:49:21 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:49:21 --> Utf8 Class Initialized
INFO - 2016-06-03 14:49:21 --> URI Class Initialized
INFO - 2016-06-03 14:49:21 --> Router Class Initialized
INFO - 2016-06-03 14:49:21 --> Output Class Initialized
INFO - 2016-06-03 14:49:21 --> Security Class Initialized
DEBUG - 2016-06-03 14:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:49:21 --> CSRF cookie sent
INFO - 2016-06-03 14:49:21 --> Input Class Initialized
INFO - 2016-06-03 14:49:21 --> Language Class Initialized
INFO - 2016-06-03 14:49:21 --> Loader Class Initialized
INFO - 2016-06-03 14:49:21 --> Helper loaded: form_helper
INFO - 2016-06-03 14:49:21 --> Database Driver Class Initialized
INFO - 2016-06-03 14:49:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:49:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:49:21 --> Email Class Initialized
INFO - 2016-06-03 14:49:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:49:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:49:21 --> Helper loaded: language_helper
INFO - 2016-06-03 14:49:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:49:21 --> Model Class Initialized
INFO - 2016-06-03 14:49:21 --> Helper loaded: date_helper
INFO - 2016-06-03 14:49:21 --> Controller Class Initialized
INFO - 2016-06-03 14:49:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:49:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:49:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:49:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:49:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:49:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:49:21 --> Model Class Initialized
INFO - 2016-06-03 14:49:21 --> Form Validation Class Initialized
INFO - 2016-06-03 14:49:33 --> Config Class Initialized
INFO - 2016-06-03 14:49:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:49:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:49:33 --> Utf8 Class Initialized
INFO - 2016-06-03 14:49:33 --> URI Class Initialized
INFO - 2016-06-03 14:49:33 --> Router Class Initialized
INFO - 2016-06-03 14:49:33 --> Output Class Initialized
INFO - 2016-06-03 14:49:33 --> Security Class Initialized
DEBUG - 2016-06-03 14:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:49:33 --> CSRF cookie sent
INFO - 2016-06-03 14:49:33 --> Input Class Initialized
INFO - 2016-06-03 14:49:33 --> Language Class Initialized
INFO - 2016-06-03 14:49:33 --> Loader Class Initialized
INFO - 2016-06-03 14:49:33 --> Helper loaded: form_helper
INFO - 2016-06-03 14:49:33 --> Database Driver Class Initialized
INFO - 2016-06-03 14:49:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:49:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:49:33 --> Email Class Initialized
INFO - 2016-06-03 14:49:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:49:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:49:33 --> Helper loaded: language_helper
INFO - 2016-06-03 14:49:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:49:33 --> Model Class Initialized
INFO - 2016-06-03 14:49:33 --> Helper loaded: date_helper
INFO - 2016-06-03 14:49:33 --> Controller Class Initialized
INFO - 2016-06-03 14:49:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:49:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:49:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:49:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:49:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:49:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:49:33 --> Model Class Initialized
INFO - 2016-06-03 14:49:33 --> Form Validation Class Initialized
INFO - 2016-06-03 14:50:34 --> Config Class Initialized
INFO - 2016-06-03 14:50:34 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:50:34 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:50:34 --> Utf8 Class Initialized
INFO - 2016-06-03 14:50:34 --> URI Class Initialized
INFO - 2016-06-03 14:50:34 --> Router Class Initialized
INFO - 2016-06-03 14:50:34 --> Output Class Initialized
INFO - 2016-06-03 14:50:34 --> Security Class Initialized
DEBUG - 2016-06-03 14:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:50:34 --> CSRF cookie sent
INFO - 2016-06-03 14:50:34 --> Input Class Initialized
INFO - 2016-06-03 14:50:34 --> Language Class Initialized
ERROR - 2016-06-03 14:50:34 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ']' /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
INFO - 2016-06-03 14:50:50 --> Config Class Initialized
INFO - 2016-06-03 14:50:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:50:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:50:50 --> Utf8 Class Initialized
INFO - 2016-06-03 14:50:50 --> URI Class Initialized
INFO - 2016-06-03 14:50:50 --> Router Class Initialized
INFO - 2016-06-03 14:50:50 --> Output Class Initialized
INFO - 2016-06-03 14:50:50 --> Security Class Initialized
DEBUG - 2016-06-03 14:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:50:50 --> CSRF cookie sent
INFO - 2016-06-03 14:50:50 --> Input Class Initialized
INFO - 2016-06-03 14:50:50 --> Language Class Initialized
INFO - 2016-06-03 14:50:50 --> Loader Class Initialized
INFO - 2016-06-03 14:50:50 --> Helper loaded: form_helper
INFO - 2016-06-03 14:50:50 --> Database Driver Class Initialized
INFO - 2016-06-03 14:50:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:50:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:50:50 --> Email Class Initialized
INFO - 2016-06-03 14:50:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:50:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:50:50 --> Helper loaded: language_helper
INFO - 2016-06-03 14:50:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:50:50 --> Model Class Initialized
INFO - 2016-06-03 14:50:50 --> Helper loaded: date_helper
INFO - 2016-06-03 14:50:50 --> Controller Class Initialized
INFO - 2016-06-03 14:50:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:50:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:50:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:50:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:50:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:50:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:50:50 --> Model Class Initialized
INFO - 2016-06-03 14:50:50 --> Form Validation Class Initialized
INFO - 2016-06-03 14:51:33 --> Config Class Initialized
INFO - 2016-06-03 14:51:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:51:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:51:33 --> Utf8 Class Initialized
INFO - 2016-06-03 14:51:33 --> URI Class Initialized
INFO - 2016-06-03 14:51:33 --> Router Class Initialized
INFO - 2016-06-03 14:51:33 --> Output Class Initialized
INFO - 2016-06-03 14:51:33 --> Security Class Initialized
DEBUG - 2016-06-03 14:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:51:33 --> CSRF cookie sent
INFO - 2016-06-03 14:51:33 --> Input Class Initialized
INFO - 2016-06-03 14:51:33 --> Language Class Initialized
INFO - 2016-06-03 14:51:33 --> Loader Class Initialized
INFO - 2016-06-03 14:51:33 --> Helper loaded: form_helper
INFO - 2016-06-03 14:51:33 --> Database Driver Class Initialized
INFO - 2016-06-03 14:51:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:51:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:51:33 --> Email Class Initialized
INFO - 2016-06-03 14:51:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:51:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:51:33 --> Helper loaded: language_helper
INFO - 2016-06-03 14:51:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:51:33 --> Model Class Initialized
INFO - 2016-06-03 14:51:33 --> Helper loaded: date_helper
INFO - 2016-06-03 14:51:33 --> Controller Class Initialized
INFO - 2016-06-03 14:51:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:51:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:51:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:51:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:51:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:51:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:51:33 --> Model Class Initialized
INFO - 2016-06-03 14:51:33 --> Form Validation Class Initialized
INFO - 2016-06-03 14:52:23 --> Config Class Initialized
INFO - 2016-06-03 14:52:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:52:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:52:23 --> Utf8 Class Initialized
INFO - 2016-06-03 14:52:23 --> URI Class Initialized
INFO - 2016-06-03 14:52:23 --> Router Class Initialized
INFO - 2016-06-03 14:52:23 --> Output Class Initialized
INFO - 2016-06-03 14:52:23 --> Security Class Initialized
DEBUG - 2016-06-03 14:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:52:23 --> CSRF cookie sent
INFO - 2016-06-03 14:52:23 --> Input Class Initialized
INFO - 2016-06-03 14:52:23 --> Language Class Initialized
INFO - 2016-06-03 14:52:23 --> Loader Class Initialized
INFO - 2016-06-03 14:52:23 --> Helper loaded: form_helper
INFO - 2016-06-03 14:52:23 --> Database Driver Class Initialized
INFO - 2016-06-03 14:52:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:52:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:52:23 --> Email Class Initialized
INFO - 2016-06-03 14:52:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:52:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:52:23 --> Helper loaded: language_helper
INFO - 2016-06-03 14:52:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:52:23 --> Model Class Initialized
INFO - 2016-06-03 14:52:23 --> Helper loaded: date_helper
INFO - 2016-06-03 14:52:23 --> Controller Class Initialized
INFO - 2016-06-03 14:52:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:52:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:52:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:52:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:52:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:52:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:52:23 --> Model Class Initialized
INFO - 2016-06-03 14:52:23 --> Form Validation Class Initialized
INFO - 2016-06-03 14:53:16 --> Config Class Initialized
INFO - 2016-06-03 14:53:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:53:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:53:16 --> Utf8 Class Initialized
INFO - 2016-06-03 14:53:16 --> URI Class Initialized
INFO - 2016-06-03 14:53:16 --> Router Class Initialized
INFO - 2016-06-03 14:53:16 --> Output Class Initialized
INFO - 2016-06-03 14:53:16 --> Security Class Initialized
DEBUG - 2016-06-03 14:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:53:16 --> CSRF cookie sent
INFO - 2016-06-03 14:53:16 --> Input Class Initialized
INFO - 2016-06-03 14:53:16 --> Language Class Initialized
ERROR - 2016-06-03 14:53:16 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
INFO - 2016-06-03 14:53:34 --> Config Class Initialized
INFO - 2016-06-03 14:53:34 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:53:34 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:53:34 --> Utf8 Class Initialized
INFO - 2016-06-03 14:53:34 --> URI Class Initialized
INFO - 2016-06-03 14:53:34 --> Router Class Initialized
INFO - 2016-06-03 14:53:34 --> Output Class Initialized
INFO - 2016-06-03 14:53:34 --> Security Class Initialized
DEBUG - 2016-06-03 14:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:53:34 --> CSRF cookie sent
INFO - 2016-06-03 14:53:34 --> Input Class Initialized
INFO - 2016-06-03 14:53:34 --> Language Class Initialized
INFO - 2016-06-03 14:53:34 --> Loader Class Initialized
INFO - 2016-06-03 14:53:34 --> Helper loaded: form_helper
INFO - 2016-06-03 14:53:34 --> Database Driver Class Initialized
INFO - 2016-06-03 14:53:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:53:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:53:34 --> Email Class Initialized
INFO - 2016-06-03 14:53:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:53:34 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:53:34 --> Helper loaded: language_helper
INFO - 2016-06-03 14:53:34 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:53:34 --> Model Class Initialized
INFO - 2016-06-03 14:53:34 --> Helper loaded: date_helper
INFO - 2016-06-03 14:53:34 --> Controller Class Initialized
INFO - 2016-06-03 14:53:34 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:53:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:53:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:53:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:53:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:53:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:53:34 --> Model Class Initialized
INFO - 2016-06-03 14:53:34 --> Form Validation Class Initialized
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
ERROR - 2016-06-03 14:53:34 --> Severity: Warning --> array_sum() expects parameter 1 to be array, integer given /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
INFO - 2016-06-03 14:53:54 --> Config Class Initialized
INFO - 2016-06-03 14:53:54 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:53:54 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:53:54 --> Utf8 Class Initialized
INFO - 2016-06-03 14:53:54 --> URI Class Initialized
INFO - 2016-06-03 14:53:54 --> Router Class Initialized
INFO - 2016-06-03 14:53:54 --> Output Class Initialized
INFO - 2016-06-03 14:53:54 --> Security Class Initialized
DEBUG - 2016-06-03 14:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:53:54 --> CSRF cookie sent
INFO - 2016-06-03 14:53:54 --> Input Class Initialized
INFO - 2016-06-03 14:53:54 --> Language Class Initialized
INFO - 2016-06-03 14:53:54 --> Loader Class Initialized
INFO - 2016-06-03 14:53:54 --> Helper loaded: form_helper
INFO - 2016-06-03 14:53:54 --> Database Driver Class Initialized
INFO - 2016-06-03 14:53:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:53:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:53:54 --> Email Class Initialized
INFO - 2016-06-03 14:53:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:53:54 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:53:54 --> Helper loaded: language_helper
INFO - 2016-06-03 14:53:54 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:53:54 --> Model Class Initialized
INFO - 2016-06-03 14:53:54 --> Helper loaded: date_helper
INFO - 2016-06-03 14:53:54 --> Controller Class Initialized
INFO - 2016-06-03 14:53:54 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:53:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:53:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:53:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:53:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:53:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:53:54 --> Model Class Initialized
INFO - 2016-06-03 14:53:54 --> Form Validation Class Initialized
INFO - 2016-06-03 14:55:18 --> Config Class Initialized
INFO - 2016-06-03 14:55:18 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:55:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:55:18 --> Utf8 Class Initialized
INFO - 2016-06-03 14:55:18 --> URI Class Initialized
INFO - 2016-06-03 14:55:18 --> Router Class Initialized
INFO - 2016-06-03 14:55:18 --> Output Class Initialized
INFO - 2016-06-03 14:55:18 --> Security Class Initialized
DEBUG - 2016-06-03 14:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:55:18 --> CSRF cookie sent
INFO - 2016-06-03 14:55:18 --> Input Class Initialized
INFO - 2016-06-03 14:55:18 --> Language Class Initialized
INFO - 2016-06-03 14:55:18 --> Loader Class Initialized
INFO - 2016-06-03 14:55:18 --> Helper loaded: form_helper
INFO - 2016-06-03 14:55:18 --> Database Driver Class Initialized
INFO - 2016-06-03 14:55:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:55:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:55:18 --> Email Class Initialized
INFO - 2016-06-03 14:55:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:55:18 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:55:18 --> Helper loaded: language_helper
INFO - 2016-06-03 14:55:18 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:55:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:55:18 --> Model Class Initialized
INFO - 2016-06-03 14:55:18 --> Helper loaded: date_helper
INFO - 2016-06-03 14:55:18 --> Controller Class Initialized
INFO - 2016-06-03 14:55:18 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:55:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:55:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:55:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:55:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:55:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:55:18 --> Model Class Initialized
INFO - 2016-06-03 14:55:18 --> Form Validation Class Initialized
INFO - 2016-06-03 14:56:36 --> Config Class Initialized
INFO - 2016-06-03 14:56:36 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:56:36 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:56:36 --> Utf8 Class Initialized
INFO - 2016-06-03 14:56:36 --> URI Class Initialized
INFO - 2016-06-03 14:56:36 --> Router Class Initialized
INFO - 2016-06-03 14:56:36 --> Output Class Initialized
INFO - 2016-06-03 14:56:36 --> Security Class Initialized
DEBUG - 2016-06-03 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:56:36 --> CSRF cookie sent
INFO - 2016-06-03 14:56:36 --> Input Class Initialized
INFO - 2016-06-03 14:56:36 --> Language Class Initialized
INFO - 2016-06-03 14:56:36 --> Loader Class Initialized
INFO - 2016-06-03 14:56:36 --> Helper loaded: form_helper
INFO - 2016-06-03 14:56:36 --> Database Driver Class Initialized
INFO - 2016-06-03 14:56:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:56:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:56:36 --> Email Class Initialized
INFO - 2016-06-03 14:56:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:56:36 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:56:36 --> Helper loaded: language_helper
INFO - 2016-06-03 14:56:36 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:56:36 --> Model Class Initialized
INFO - 2016-06-03 14:56:36 --> Helper loaded: date_helper
INFO - 2016-06-03 14:56:36 --> Controller Class Initialized
INFO - 2016-06-03 14:56:36 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:56:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:56:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:56:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:56:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:56:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:56:36 --> Model Class Initialized
INFO - 2016-06-03 14:56:36 --> Form Validation Class Initialized
INFO - 2016-06-03 14:56:44 --> Config Class Initialized
INFO - 2016-06-03 14:56:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 14:56:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 14:56:44 --> Utf8 Class Initialized
INFO - 2016-06-03 14:56:44 --> URI Class Initialized
INFO - 2016-06-03 14:56:44 --> Router Class Initialized
INFO - 2016-06-03 14:56:44 --> Output Class Initialized
INFO - 2016-06-03 14:56:44 --> Security Class Initialized
DEBUG - 2016-06-03 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 14:56:44 --> CSRF cookie sent
INFO - 2016-06-03 14:56:44 --> Input Class Initialized
INFO - 2016-06-03 14:56:44 --> Language Class Initialized
INFO - 2016-06-03 14:56:44 --> Loader Class Initialized
INFO - 2016-06-03 14:56:44 --> Helper loaded: form_helper
INFO - 2016-06-03 14:56:44 --> Database Driver Class Initialized
INFO - 2016-06-03 14:56:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 14:56:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 14:56:44 --> Email Class Initialized
INFO - 2016-06-03 14:56:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 14:56:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 14:56:44 --> Helper loaded: language_helper
INFO - 2016-06-03 14:56:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 14:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 14:56:44 --> Model Class Initialized
INFO - 2016-06-03 14:56:44 --> Helper loaded: date_helper
INFO - 2016-06-03 14:56:44 --> Controller Class Initialized
INFO - 2016-06-03 14:56:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 14:56:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 14:56:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 14:56:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 14:56:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 14:56:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 14:56:44 --> Model Class Initialized
INFO - 2016-06-03 14:56:44 --> Form Validation Class Initialized
INFO - 2016-06-03 15:00:24 --> Config Class Initialized
INFO - 2016-06-03 15:00:24 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:00:24 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:00:24 --> Utf8 Class Initialized
INFO - 2016-06-03 15:00:24 --> URI Class Initialized
INFO - 2016-06-03 15:00:24 --> Router Class Initialized
INFO - 2016-06-03 15:00:24 --> Output Class Initialized
INFO - 2016-06-03 15:00:24 --> Security Class Initialized
DEBUG - 2016-06-03 15:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:00:24 --> CSRF cookie sent
INFO - 2016-06-03 15:00:24 --> Input Class Initialized
INFO - 2016-06-03 15:00:24 --> Language Class Initialized
INFO - 2016-06-03 15:00:24 --> Loader Class Initialized
INFO - 2016-06-03 15:00:24 --> Helper loaded: form_helper
INFO - 2016-06-03 15:00:24 --> Database Driver Class Initialized
INFO - 2016-06-03 15:00:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:00:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:00:24 --> Email Class Initialized
INFO - 2016-06-03 15:00:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:00:24 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:00:24 --> Helper loaded: language_helper
INFO - 2016-06-03 15:00:24 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:00:24 --> Model Class Initialized
INFO - 2016-06-03 15:00:24 --> Helper loaded: date_helper
INFO - 2016-06-03 15:00:24 --> Controller Class Initialized
INFO - 2016-06-03 15:00:24 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:00:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:00:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:00:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:00:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:00:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:00:24 --> Model Class Initialized
INFO - 2016-06-03 15:00:24 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:00:25 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 117
INFO - 2016-06-03 15:01:27 --> Config Class Initialized
INFO - 2016-06-03 15:01:27 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:01:27 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:01:27 --> Utf8 Class Initialized
INFO - 2016-06-03 15:01:27 --> URI Class Initialized
INFO - 2016-06-03 15:01:27 --> Router Class Initialized
INFO - 2016-06-03 15:01:27 --> Output Class Initialized
INFO - 2016-06-03 15:01:27 --> Security Class Initialized
DEBUG - 2016-06-03 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:01:27 --> CSRF cookie sent
INFO - 2016-06-03 15:01:27 --> Input Class Initialized
INFO - 2016-06-03 15:01:27 --> Language Class Initialized
INFO - 2016-06-03 15:01:27 --> Loader Class Initialized
INFO - 2016-06-03 15:01:27 --> Helper loaded: form_helper
INFO - 2016-06-03 15:01:27 --> Database Driver Class Initialized
INFO - 2016-06-03 15:01:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:01:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:01:27 --> Email Class Initialized
INFO - 2016-06-03 15:01:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:01:27 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:01:27 --> Helper loaded: language_helper
INFO - 2016-06-03 15:01:27 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:01:27 --> Model Class Initialized
INFO - 2016-06-03 15:01:27 --> Helper loaded: date_helper
INFO - 2016-06-03 15:01:27 --> Controller Class Initialized
INFO - 2016-06-03 15:01:27 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:01:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:01:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:01:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:01:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:01:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:01:27 --> Model Class Initialized
INFO - 2016-06-03 15:01:27 --> Form Validation Class Initialized
INFO - 2016-06-03 15:01:27 --> Final output sent to browser
DEBUG - 2016-06-03 15:01:27 --> Total execution time: 0.0508
INFO - 2016-06-03 15:01:52 --> Config Class Initialized
INFO - 2016-06-03 15:01:52 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:01:52 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:01:52 --> Utf8 Class Initialized
INFO - 2016-06-03 15:01:52 --> URI Class Initialized
INFO - 2016-06-03 15:01:52 --> Router Class Initialized
INFO - 2016-06-03 15:01:52 --> Output Class Initialized
INFO - 2016-06-03 15:01:52 --> Security Class Initialized
DEBUG - 2016-06-03 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:01:52 --> CSRF cookie sent
INFO - 2016-06-03 15:01:52 --> Input Class Initialized
INFO - 2016-06-03 15:01:52 --> Language Class Initialized
ERROR - 2016-06-03 15:01:52 --> Severity: Parsing Error --> syntax error, unexpected 'continue' (T_CONTINUE) /home/demis/www/platformadiabet/application/controllers/Diabet.php 118
INFO - 2016-06-03 15:04:23 --> Config Class Initialized
INFO - 2016-06-03 15:04:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:04:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:04:23 --> Utf8 Class Initialized
INFO - 2016-06-03 15:04:23 --> URI Class Initialized
INFO - 2016-06-03 15:04:23 --> Router Class Initialized
INFO - 2016-06-03 15:04:23 --> Output Class Initialized
INFO - 2016-06-03 15:04:23 --> Security Class Initialized
DEBUG - 2016-06-03 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:04:23 --> CSRF cookie sent
INFO - 2016-06-03 15:04:23 --> Input Class Initialized
INFO - 2016-06-03 15:04:23 --> Language Class Initialized
INFO - 2016-06-03 15:04:23 --> Loader Class Initialized
INFO - 2016-06-03 15:04:23 --> Helper loaded: form_helper
INFO - 2016-06-03 15:04:23 --> Database Driver Class Initialized
INFO - 2016-06-03 15:04:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:04:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:04:23 --> Email Class Initialized
INFO - 2016-06-03 15:04:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:04:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:04:23 --> Helper loaded: language_helper
INFO - 2016-06-03 15:04:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:04:23 --> Model Class Initialized
INFO - 2016-06-03 15:04:23 --> Helper loaded: date_helper
INFO - 2016-06-03 15:04:23 --> Controller Class Initialized
INFO - 2016-06-03 15:04:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:04:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:04:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:04:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:04:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:04:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:04:23 --> Model Class Initialized
INFO - 2016-06-03 15:04:23 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:04:23 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 15:05:22 --> Config Class Initialized
INFO - 2016-06-03 15:05:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:05:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:05:22 --> Utf8 Class Initialized
INFO - 2016-06-03 15:05:22 --> URI Class Initialized
INFO - 2016-06-03 15:05:22 --> Router Class Initialized
INFO - 2016-06-03 15:05:22 --> Output Class Initialized
INFO - 2016-06-03 15:05:22 --> Security Class Initialized
DEBUG - 2016-06-03 15:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:05:22 --> CSRF cookie sent
INFO - 2016-06-03 15:05:22 --> Input Class Initialized
INFO - 2016-06-03 15:05:22 --> Language Class Initialized
INFO - 2016-06-03 15:05:22 --> Loader Class Initialized
INFO - 2016-06-03 15:05:22 --> Helper loaded: form_helper
INFO - 2016-06-03 15:05:22 --> Database Driver Class Initialized
INFO - 2016-06-03 15:05:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:05:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:05:22 --> Email Class Initialized
INFO - 2016-06-03 15:05:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:05:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:05:22 --> Helper loaded: language_helper
INFO - 2016-06-03 15:05:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:05:22 --> Model Class Initialized
INFO - 2016-06-03 15:05:22 --> Helper loaded: date_helper
INFO - 2016-06-03 15:05:22 --> Controller Class Initialized
INFO - 2016-06-03 15:05:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:05:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:05:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:05:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:05:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:05:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:05:22 --> Model Class Initialized
INFO - 2016-06-03 15:05:22 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:05:22 --> Severity: Notice --> Undefined index: averages /home/demis/www/platformadiabet/application/controllers/Diabet.php 126
INFO - 2016-06-03 15:05:32 --> Config Class Initialized
INFO - 2016-06-03 15:05:32 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:05:32 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:05:32 --> Utf8 Class Initialized
INFO - 2016-06-03 15:05:32 --> URI Class Initialized
INFO - 2016-06-03 15:05:32 --> Router Class Initialized
INFO - 2016-06-03 15:05:32 --> Output Class Initialized
INFO - 2016-06-03 15:05:32 --> Security Class Initialized
DEBUG - 2016-06-03 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:05:32 --> CSRF cookie sent
INFO - 2016-06-03 15:05:32 --> Input Class Initialized
INFO - 2016-06-03 15:05:32 --> Language Class Initialized
INFO - 2016-06-03 15:05:32 --> Loader Class Initialized
INFO - 2016-06-03 15:05:32 --> Helper loaded: form_helper
INFO - 2016-06-03 15:05:32 --> Database Driver Class Initialized
INFO - 2016-06-03 15:05:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:05:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:05:32 --> Email Class Initialized
INFO - 2016-06-03 15:05:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:05:32 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:05:32 --> Helper loaded: language_helper
INFO - 2016-06-03 15:05:32 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:05:32 --> Model Class Initialized
INFO - 2016-06-03 15:05:32 --> Helper loaded: date_helper
INFO - 2016-06-03 15:05:32 --> Controller Class Initialized
INFO - 2016-06-03 15:05:32 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:05:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:05:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:05:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:05:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:05:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:05:32 --> Model Class Initialized
INFO - 2016-06-03 15:05:32 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:05:32 --> Severity: Notice --> Undefined index: averages /home/demis/www/platformadiabet/application/controllers/Diabet.php 123
INFO - 2016-06-03 15:06:04 --> Config Class Initialized
INFO - 2016-06-03 15:06:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:06:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:06:04 --> Utf8 Class Initialized
INFO - 2016-06-03 15:06:04 --> URI Class Initialized
INFO - 2016-06-03 15:06:04 --> Router Class Initialized
INFO - 2016-06-03 15:06:04 --> Output Class Initialized
INFO - 2016-06-03 15:06:04 --> Security Class Initialized
DEBUG - 2016-06-03 15:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:06:04 --> CSRF cookie sent
INFO - 2016-06-03 15:06:04 --> Input Class Initialized
INFO - 2016-06-03 15:06:04 --> Language Class Initialized
INFO - 2016-06-03 15:06:04 --> Loader Class Initialized
INFO - 2016-06-03 15:06:04 --> Helper loaded: form_helper
INFO - 2016-06-03 15:06:04 --> Database Driver Class Initialized
INFO - 2016-06-03 15:06:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:06:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:06:04 --> Email Class Initialized
INFO - 2016-06-03 15:06:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:06:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:06:04 --> Helper loaded: language_helper
INFO - 2016-06-03 15:06:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:06:04 --> Model Class Initialized
INFO - 2016-06-03 15:06:04 --> Helper loaded: date_helper
INFO - 2016-06-03 15:06:04 --> Controller Class Initialized
INFO - 2016-06-03 15:06:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:06:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:06:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:06:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:06:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:06:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:06:04 --> Model Class Initialized
INFO - 2016-06-03 15:06:04 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:06:04 --> Severity: Notice --> Undefined index: averages /home/demis/www/platformadiabet/application/controllers/Diabet.php 123
INFO - 2016-06-03 15:06:42 --> Config Class Initialized
INFO - 2016-06-03 15:06:42 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:06:42 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:06:42 --> Utf8 Class Initialized
INFO - 2016-06-03 15:06:42 --> URI Class Initialized
INFO - 2016-06-03 15:06:42 --> Router Class Initialized
INFO - 2016-06-03 15:06:42 --> Output Class Initialized
INFO - 2016-06-03 15:06:42 --> Security Class Initialized
DEBUG - 2016-06-03 15:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:06:42 --> CSRF cookie sent
INFO - 2016-06-03 15:06:42 --> Input Class Initialized
INFO - 2016-06-03 15:06:42 --> Language Class Initialized
INFO - 2016-06-03 15:06:42 --> Loader Class Initialized
INFO - 2016-06-03 15:06:42 --> Helper loaded: form_helper
INFO - 2016-06-03 15:06:42 --> Database Driver Class Initialized
INFO - 2016-06-03 15:06:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:06:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:06:42 --> Email Class Initialized
INFO - 2016-06-03 15:06:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:06:42 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:06:42 --> Helper loaded: language_helper
INFO - 2016-06-03 15:06:42 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:06:42 --> Model Class Initialized
INFO - 2016-06-03 15:06:42 --> Helper loaded: date_helper
INFO - 2016-06-03 15:06:42 --> Controller Class Initialized
INFO - 2016-06-03 15:06:42 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:06:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:06:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:06:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:06:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:06:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:06:42 --> Model Class Initialized
INFO - 2016-06-03 15:06:42 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:06:42 --> Severity: Notice --> Undefined index: averages /home/demis/www/platformadiabet/application/controllers/Diabet.php 124
INFO - 2016-06-03 15:07:35 --> Config Class Initialized
INFO - 2016-06-03 15:07:35 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:07:35 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:07:35 --> Utf8 Class Initialized
INFO - 2016-06-03 15:07:35 --> URI Class Initialized
INFO - 2016-06-03 15:07:35 --> Router Class Initialized
INFO - 2016-06-03 15:07:35 --> Output Class Initialized
INFO - 2016-06-03 15:07:35 --> Security Class Initialized
DEBUG - 2016-06-03 15:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:07:35 --> CSRF cookie sent
INFO - 2016-06-03 15:07:35 --> Input Class Initialized
INFO - 2016-06-03 15:07:35 --> Language Class Initialized
INFO - 2016-06-03 15:07:35 --> Loader Class Initialized
INFO - 2016-06-03 15:07:35 --> Helper loaded: form_helper
INFO - 2016-06-03 15:07:35 --> Database Driver Class Initialized
INFO - 2016-06-03 15:07:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:07:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:07:35 --> Email Class Initialized
INFO - 2016-06-03 15:07:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:07:35 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:07:35 --> Helper loaded: language_helper
INFO - 2016-06-03 15:07:35 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:07:35 --> Model Class Initialized
INFO - 2016-06-03 15:07:35 --> Helper loaded: date_helper
INFO - 2016-06-03 15:07:35 --> Controller Class Initialized
INFO - 2016-06-03 15:07:35 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:07:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:07:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:07:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:07:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:07:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:07:35 --> Model Class Initialized
INFO - 2016-06-03 15:07:35 --> Form Validation Class Initialized
INFO - 2016-06-03 15:08:10 --> Config Class Initialized
INFO - 2016-06-03 15:08:10 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:08:10 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:08:10 --> Utf8 Class Initialized
INFO - 2016-06-03 15:08:10 --> URI Class Initialized
INFO - 2016-06-03 15:08:10 --> Router Class Initialized
INFO - 2016-06-03 15:08:10 --> Output Class Initialized
INFO - 2016-06-03 15:08:10 --> Security Class Initialized
DEBUG - 2016-06-03 15:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:08:10 --> CSRF cookie sent
INFO - 2016-06-03 15:08:10 --> Input Class Initialized
INFO - 2016-06-03 15:08:10 --> Language Class Initialized
INFO - 2016-06-03 15:08:10 --> Loader Class Initialized
INFO - 2016-06-03 15:08:10 --> Helper loaded: form_helper
INFO - 2016-06-03 15:08:10 --> Database Driver Class Initialized
INFO - 2016-06-03 15:08:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:08:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:08:10 --> Email Class Initialized
INFO - 2016-06-03 15:08:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:08:10 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:08:10 --> Helper loaded: language_helper
INFO - 2016-06-03 15:08:10 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:08:10 --> Model Class Initialized
INFO - 2016-06-03 15:08:10 --> Helper loaded: date_helper
INFO - 2016-06-03 15:08:10 --> Controller Class Initialized
INFO - 2016-06-03 15:08:10 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:08:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:08:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:08:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:08:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:08:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:08:10 --> Model Class Initialized
INFO - 2016-06-03 15:08:10 --> Form Validation Class Initialized
INFO - 2016-06-03 15:08:21 --> Config Class Initialized
INFO - 2016-06-03 15:08:21 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:08:21 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:08:21 --> Utf8 Class Initialized
INFO - 2016-06-03 15:08:21 --> URI Class Initialized
INFO - 2016-06-03 15:08:21 --> Router Class Initialized
INFO - 2016-06-03 15:08:21 --> Output Class Initialized
INFO - 2016-06-03 15:08:21 --> Security Class Initialized
DEBUG - 2016-06-03 15:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:08:21 --> CSRF cookie sent
INFO - 2016-06-03 15:08:21 --> Input Class Initialized
INFO - 2016-06-03 15:08:21 --> Language Class Initialized
INFO - 2016-06-03 15:08:21 --> Loader Class Initialized
INFO - 2016-06-03 15:08:21 --> Helper loaded: form_helper
INFO - 2016-06-03 15:08:21 --> Database Driver Class Initialized
INFO - 2016-06-03 15:08:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:08:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:08:21 --> Email Class Initialized
INFO - 2016-06-03 15:08:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:08:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:08:21 --> Helper loaded: language_helper
INFO - 2016-06-03 15:08:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:08:21 --> Model Class Initialized
INFO - 2016-06-03 15:08:21 --> Helper loaded: date_helper
INFO - 2016-06-03 15:08:21 --> Controller Class Initialized
INFO - 2016-06-03 15:08:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:08:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:08:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:08:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:08:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:08:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:08:21 --> Model Class Initialized
INFO - 2016-06-03 15:08:21 --> Form Validation Class Initialized
INFO - 2016-06-03 15:08:55 --> Config Class Initialized
INFO - 2016-06-03 15:08:55 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:08:55 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:08:55 --> Utf8 Class Initialized
INFO - 2016-06-03 15:08:55 --> URI Class Initialized
INFO - 2016-06-03 15:08:55 --> Router Class Initialized
INFO - 2016-06-03 15:08:55 --> Output Class Initialized
INFO - 2016-06-03 15:08:55 --> Security Class Initialized
DEBUG - 2016-06-03 15:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:08:55 --> CSRF cookie sent
INFO - 2016-06-03 15:08:55 --> Input Class Initialized
INFO - 2016-06-03 15:08:55 --> Language Class Initialized
INFO - 2016-06-03 15:08:55 --> Loader Class Initialized
INFO - 2016-06-03 15:08:55 --> Helper loaded: form_helper
INFO - 2016-06-03 15:08:55 --> Database Driver Class Initialized
INFO - 2016-06-03 15:08:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:08:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:08:55 --> Email Class Initialized
INFO - 2016-06-03 15:08:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:08:55 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:08:55 --> Helper loaded: language_helper
INFO - 2016-06-03 15:08:55 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:08:55 --> Model Class Initialized
INFO - 2016-06-03 15:08:55 --> Helper loaded: date_helper
INFO - 2016-06-03 15:08:55 --> Controller Class Initialized
INFO - 2016-06-03 15:08:55 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:08:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:08:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:08:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:08:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:08:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:08:55 --> Model Class Initialized
INFO - 2016-06-03 15:08:55 --> Form Validation Class Initialized
INFO - 2016-06-03 15:09:27 --> Config Class Initialized
INFO - 2016-06-03 15:09:27 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:09:27 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:09:27 --> Utf8 Class Initialized
INFO - 2016-06-03 15:09:27 --> URI Class Initialized
INFO - 2016-06-03 15:09:27 --> Router Class Initialized
INFO - 2016-06-03 15:09:27 --> Output Class Initialized
INFO - 2016-06-03 15:09:27 --> Security Class Initialized
DEBUG - 2016-06-03 15:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:09:27 --> CSRF cookie sent
INFO - 2016-06-03 15:09:27 --> Input Class Initialized
INFO - 2016-06-03 15:09:27 --> Language Class Initialized
INFO - 2016-06-03 15:09:27 --> Loader Class Initialized
INFO - 2016-06-03 15:09:27 --> Helper loaded: form_helper
INFO - 2016-06-03 15:09:27 --> Database Driver Class Initialized
INFO - 2016-06-03 15:09:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:09:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:09:27 --> Email Class Initialized
INFO - 2016-06-03 15:09:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:09:27 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:09:27 --> Helper loaded: language_helper
INFO - 2016-06-03 15:09:27 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:09:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:09:27 --> Model Class Initialized
INFO - 2016-06-03 15:09:27 --> Helper loaded: date_helper
INFO - 2016-06-03 15:09:27 --> Controller Class Initialized
INFO - 2016-06-03 15:09:27 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:09:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:09:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:09:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:09:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:09:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:09:27 --> Model Class Initialized
INFO - 2016-06-03 15:09:27 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 119
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 120
ERROR - 2016-06-03 15:09:27 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 119
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 120
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 119
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 120
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 119
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 120
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 119
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 120
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 119
ERROR - 2016-06-03 15:09:27 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 120
INFO - 2016-06-03 15:10:02 --> Config Class Initialized
INFO - 2016-06-03 15:10:02 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:10:02 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:10:02 --> Utf8 Class Initialized
INFO - 2016-06-03 15:10:02 --> URI Class Initialized
INFO - 2016-06-03 15:10:02 --> Router Class Initialized
INFO - 2016-06-03 15:10:02 --> Output Class Initialized
INFO - 2016-06-03 15:10:02 --> Security Class Initialized
DEBUG - 2016-06-03 15:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:10:02 --> CSRF cookie sent
INFO - 2016-06-03 15:10:02 --> Input Class Initialized
INFO - 2016-06-03 15:10:02 --> Language Class Initialized
INFO - 2016-06-03 15:10:02 --> Loader Class Initialized
INFO - 2016-06-03 15:10:02 --> Helper loaded: form_helper
INFO - 2016-06-03 15:10:02 --> Database Driver Class Initialized
INFO - 2016-06-03 15:10:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:10:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:10:02 --> Email Class Initialized
INFO - 2016-06-03 15:10:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:10:02 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:10:02 --> Helper loaded: language_helper
INFO - 2016-06-03 15:10:02 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:10:02 --> Model Class Initialized
INFO - 2016-06-03 15:10:02 --> Helper loaded: date_helper
INFO - 2016-06-03 15:10:02 --> Controller Class Initialized
INFO - 2016-06-03 15:10:02 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:10:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:10:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:10:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:10:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:10:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:10:02 --> Model Class Initialized
INFO - 2016-06-03 15:10:02 --> Form Validation Class Initialized
INFO - 2016-06-03 15:10:46 --> Config Class Initialized
INFO - 2016-06-03 15:10:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:10:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:10:46 --> Utf8 Class Initialized
INFO - 2016-06-03 15:10:46 --> URI Class Initialized
INFO - 2016-06-03 15:10:46 --> Router Class Initialized
INFO - 2016-06-03 15:10:46 --> Output Class Initialized
INFO - 2016-06-03 15:10:46 --> Security Class Initialized
DEBUG - 2016-06-03 15:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:10:46 --> CSRF cookie sent
INFO - 2016-06-03 15:10:46 --> Input Class Initialized
INFO - 2016-06-03 15:10:46 --> Language Class Initialized
INFO - 2016-06-03 15:10:46 --> Loader Class Initialized
INFO - 2016-06-03 15:10:46 --> Helper loaded: form_helper
INFO - 2016-06-03 15:10:46 --> Database Driver Class Initialized
INFO - 2016-06-03 15:10:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:10:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:10:46 --> Email Class Initialized
INFO - 2016-06-03 15:10:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:10:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:10:46 --> Helper loaded: language_helper
INFO - 2016-06-03 15:10:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:10:46 --> Model Class Initialized
INFO - 2016-06-03 15:10:46 --> Helper loaded: date_helper
INFO - 2016-06-03 15:10:46 --> Controller Class Initialized
INFO - 2016-06-03 15:10:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:10:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:10:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:10:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:10:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:10:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:10:46 --> Model Class Initialized
INFO - 2016-06-03 15:10:46 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:10:46 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 121
INFO - 2016-06-03 15:12:04 --> Config Class Initialized
INFO - 2016-06-03 15:12:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:12:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:12:04 --> Utf8 Class Initialized
INFO - 2016-06-03 15:12:04 --> URI Class Initialized
INFO - 2016-06-03 15:12:04 --> Router Class Initialized
INFO - 2016-06-03 15:12:04 --> Output Class Initialized
INFO - 2016-06-03 15:12:04 --> Security Class Initialized
DEBUG - 2016-06-03 15:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:12:04 --> CSRF cookie sent
INFO - 2016-06-03 15:12:04 --> Input Class Initialized
INFO - 2016-06-03 15:12:04 --> Language Class Initialized
INFO - 2016-06-03 15:12:04 --> Loader Class Initialized
INFO - 2016-06-03 15:12:04 --> Helper loaded: form_helper
INFO - 2016-06-03 15:12:04 --> Database Driver Class Initialized
INFO - 2016-06-03 15:12:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:12:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:12:04 --> Email Class Initialized
INFO - 2016-06-03 15:12:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:12:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:12:04 --> Helper loaded: language_helper
INFO - 2016-06-03 15:12:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:12:04 --> Model Class Initialized
INFO - 2016-06-03 15:12:04 --> Helper loaded: date_helper
INFO - 2016-06-03 15:12:04 --> Controller Class Initialized
INFO - 2016-06-03 15:12:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:12:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:12:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:12:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:12:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:12:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:12:04 --> Model Class Initialized
INFO - 2016-06-03 15:12:04 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:12:04 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 15:12:04 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 15:12:04 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 15:12:04 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 15:12:04 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
ERROR - 2016-06-03 15:12:04 --> Severity: Notice --> Undefined variable: skip /home/demis/www/platformadiabet/application/controllers/Diabet.php 114
INFO - 2016-06-03 15:12:23 --> Config Class Initialized
INFO - 2016-06-03 15:12:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:12:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:12:23 --> Utf8 Class Initialized
INFO - 2016-06-03 15:12:23 --> URI Class Initialized
INFO - 2016-06-03 15:12:23 --> Router Class Initialized
INFO - 2016-06-03 15:12:23 --> Output Class Initialized
INFO - 2016-06-03 15:12:23 --> Security Class Initialized
DEBUG - 2016-06-03 15:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:12:23 --> CSRF cookie sent
INFO - 2016-06-03 15:12:23 --> Input Class Initialized
INFO - 2016-06-03 15:12:23 --> Language Class Initialized
INFO - 2016-06-03 15:12:23 --> Loader Class Initialized
INFO - 2016-06-03 15:12:23 --> Helper loaded: form_helper
INFO - 2016-06-03 15:12:23 --> Database Driver Class Initialized
INFO - 2016-06-03 15:12:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:12:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:12:23 --> Email Class Initialized
INFO - 2016-06-03 15:12:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:12:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:12:23 --> Helper loaded: language_helper
INFO - 2016-06-03 15:12:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:12:23 --> Model Class Initialized
INFO - 2016-06-03 15:12:23 --> Helper loaded: date_helper
INFO - 2016-06-03 15:12:23 --> Controller Class Initialized
INFO - 2016-06-03 15:12:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:12:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:12:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:12:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:12:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:12:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:12:23 --> Model Class Initialized
INFO - 2016-06-03 15:12:23 --> Form Validation Class Initialized
ERROR - 2016-06-03 15:12:23 --> Severity: Warning --> Division by zero /home/demis/www/platformadiabet/application/controllers/Diabet.php 115
INFO - 2016-06-03 15:16:07 --> Config Class Initialized
INFO - 2016-06-03 15:16:07 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:16:07 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:16:07 --> Utf8 Class Initialized
INFO - 2016-06-03 15:16:07 --> URI Class Initialized
INFO - 2016-06-03 15:16:07 --> Router Class Initialized
INFO - 2016-06-03 15:16:07 --> Output Class Initialized
INFO - 2016-06-03 15:16:07 --> Security Class Initialized
DEBUG - 2016-06-03 15:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:16:07 --> CSRF cookie sent
INFO - 2016-06-03 15:16:07 --> Input Class Initialized
INFO - 2016-06-03 15:16:07 --> Language Class Initialized
INFO - 2016-06-03 15:16:07 --> Loader Class Initialized
INFO - 2016-06-03 15:16:07 --> Helper loaded: form_helper
INFO - 2016-06-03 15:16:07 --> Database Driver Class Initialized
INFO - 2016-06-03 15:16:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:16:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:16:07 --> Email Class Initialized
INFO - 2016-06-03 15:16:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:16:07 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:16:07 --> Helper loaded: language_helper
INFO - 2016-06-03 15:16:07 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:16:07 --> Model Class Initialized
INFO - 2016-06-03 15:16:07 --> Helper loaded: date_helper
INFO - 2016-06-03 15:16:07 --> Controller Class Initialized
INFO - 2016-06-03 15:16:07 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:16:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:16:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:16:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:16:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:16:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:16:07 --> Model Class Initialized
INFO - 2016-06-03 15:16:07 --> Form Validation Class Initialized
INFO - 2016-06-03 15:16:38 --> Config Class Initialized
INFO - 2016-06-03 15:16:38 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:16:38 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:16:38 --> Utf8 Class Initialized
INFO - 2016-06-03 15:16:38 --> URI Class Initialized
INFO - 2016-06-03 15:16:38 --> Router Class Initialized
INFO - 2016-06-03 15:16:38 --> Output Class Initialized
INFO - 2016-06-03 15:16:38 --> Security Class Initialized
DEBUG - 2016-06-03 15:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:16:38 --> CSRF cookie sent
INFO - 2016-06-03 15:16:38 --> Input Class Initialized
INFO - 2016-06-03 15:16:38 --> Language Class Initialized
INFO - 2016-06-03 15:16:38 --> Loader Class Initialized
INFO - 2016-06-03 15:16:38 --> Helper loaded: form_helper
INFO - 2016-06-03 15:16:38 --> Database Driver Class Initialized
INFO - 2016-06-03 15:16:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:16:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:16:38 --> Email Class Initialized
INFO - 2016-06-03 15:16:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:16:38 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:16:38 --> Helper loaded: language_helper
INFO - 2016-06-03 15:16:38 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:16:38 --> Model Class Initialized
INFO - 2016-06-03 15:16:38 --> Helper loaded: date_helper
INFO - 2016-06-03 15:16:38 --> Controller Class Initialized
INFO - 2016-06-03 15:16:38 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:16:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:16:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:16:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:16:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:16:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:16:38 --> Model Class Initialized
INFO - 2016-06-03 15:16:38 --> Form Validation Class Initialized
INFO - 2016-06-03 15:47:42 --> Config Class Initialized
INFO - 2016-06-03 15:47:42 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:47:42 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:47:42 --> Utf8 Class Initialized
INFO - 2016-06-03 15:47:42 --> URI Class Initialized
INFO - 2016-06-03 15:47:42 --> Router Class Initialized
INFO - 2016-06-03 15:47:42 --> Output Class Initialized
INFO - 2016-06-03 15:47:42 --> Security Class Initialized
DEBUG - 2016-06-03 15:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:47:42 --> CSRF cookie sent
INFO - 2016-06-03 15:47:42 --> Input Class Initialized
INFO - 2016-06-03 15:47:42 --> Language Class Initialized
INFO - 2016-06-03 15:47:42 --> Loader Class Initialized
INFO - 2016-06-03 15:47:42 --> Helper loaded: form_helper
INFO - 2016-06-03 15:47:42 --> Database Driver Class Initialized
INFO - 2016-06-03 15:47:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:47:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:47:42 --> Email Class Initialized
INFO - 2016-06-03 15:47:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:47:42 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:47:42 --> Helper loaded: language_helper
INFO - 2016-06-03 15:47:42 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:47:42 --> Model Class Initialized
INFO - 2016-06-03 15:47:42 --> Helper loaded: date_helper
INFO - 2016-06-03 15:47:42 --> Controller Class Initialized
INFO - 2016-06-03 15:47:42 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:47:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:47:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:47:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:47:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:47:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:47:57 --> Config Class Initialized
INFO - 2016-06-03 15:47:57 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:47:57 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:47:57 --> Utf8 Class Initialized
INFO - 2016-06-03 15:47:57 --> URI Class Initialized
INFO - 2016-06-03 15:47:57 --> Router Class Initialized
INFO - 2016-06-03 15:47:57 --> Output Class Initialized
INFO - 2016-06-03 15:47:57 --> Security Class Initialized
DEBUG - 2016-06-03 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:47:57 --> CSRF cookie sent
INFO - 2016-06-03 15:47:57 --> Input Class Initialized
INFO - 2016-06-03 15:47:57 --> Language Class Initialized
INFO - 2016-06-03 15:47:57 --> Loader Class Initialized
INFO - 2016-06-03 15:47:57 --> Helper loaded: form_helper
INFO - 2016-06-03 15:47:57 --> Database Driver Class Initialized
INFO - 2016-06-03 15:47:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:47:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:47:57 --> Email Class Initialized
INFO - 2016-06-03 15:47:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:47:57 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:47:57 --> Helper loaded: language_helper
INFO - 2016-06-03 15:47:57 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:47:57 --> Model Class Initialized
INFO - 2016-06-03 15:47:57 --> Helper loaded: date_helper
INFO - 2016-06-03 15:47:57 --> Controller Class Initialized
INFO - 2016-06-03 15:47:57 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:47:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:47:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:47:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:47:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:47:57 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-06-03 15:47:57 --> Severity: Notice --> date_default_timezone_set(): Timezone ID 'GMT+2' is invalid /home/demis/www/platformadiabet/application/core/SVS_Controller.php 18
INFO - 2016-06-03 15:48:59 --> Config Class Initialized
INFO - 2016-06-03 15:48:59 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:48:59 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:48:59 --> Utf8 Class Initialized
INFO - 2016-06-03 15:48:59 --> URI Class Initialized
INFO - 2016-06-03 15:48:59 --> Router Class Initialized
INFO - 2016-06-03 15:48:59 --> Output Class Initialized
INFO - 2016-06-03 15:48:59 --> Security Class Initialized
DEBUG - 2016-06-03 15:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:48:59 --> CSRF cookie sent
INFO - 2016-06-03 15:48:59 --> Input Class Initialized
INFO - 2016-06-03 15:48:59 --> Language Class Initialized
INFO - 2016-06-03 15:48:59 --> Loader Class Initialized
INFO - 2016-06-03 15:48:59 --> Helper loaded: form_helper
INFO - 2016-06-03 15:48:59 --> Database Driver Class Initialized
INFO - 2016-06-03 15:48:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:48:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:48:59 --> Email Class Initialized
INFO - 2016-06-03 15:48:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:48:59 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:48:59 --> Helper loaded: language_helper
INFO - 2016-06-03 15:48:59 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:48:59 --> Model Class Initialized
INFO - 2016-06-03 15:48:59 --> Helper loaded: date_helper
INFO - 2016-06-03 15:48:59 --> Controller Class Initialized
INFO - 2016-06-03 15:48:59 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:48:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:48:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:48:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:48:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:48:59 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-06-03 15:48:59 --> Severity: Notice --> Use of undefined constant GMT - assumed 'GMT' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 18
ERROR - 2016-06-03 15:48:59 --> Severity: Notice --> date_default_timezone_set(): Timezone ID '2' is invalid /home/demis/www/platformadiabet/application/core/SVS_Controller.php 18
INFO - 2016-06-03 15:49:52 --> Config Class Initialized
INFO - 2016-06-03 15:49:52 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:49:52 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:49:52 --> Utf8 Class Initialized
INFO - 2016-06-03 15:49:52 --> URI Class Initialized
INFO - 2016-06-03 15:49:52 --> Router Class Initialized
INFO - 2016-06-03 15:49:52 --> Output Class Initialized
INFO - 2016-06-03 15:49:52 --> Security Class Initialized
DEBUG - 2016-06-03 15:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:49:52 --> CSRF cookie sent
INFO - 2016-06-03 15:49:52 --> Input Class Initialized
INFO - 2016-06-03 15:49:52 --> Language Class Initialized
INFO - 2016-06-03 15:49:52 --> Loader Class Initialized
INFO - 2016-06-03 15:49:52 --> Helper loaded: form_helper
INFO - 2016-06-03 15:49:52 --> Database Driver Class Initialized
INFO - 2016-06-03 15:49:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:49:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:49:52 --> Email Class Initialized
INFO - 2016-06-03 15:49:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:49:52 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:49:52 --> Helper loaded: language_helper
INFO - 2016-06-03 15:49:52 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:49:52 --> Model Class Initialized
INFO - 2016-06-03 15:49:52 --> Helper loaded: date_helper
INFO - 2016-06-03 15:49:52 --> Controller Class Initialized
INFO - 2016-06-03 15:49:52 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:49:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:49:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:49:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:49:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:49:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:51:06 --> Config Class Initialized
INFO - 2016-06-03 15:51:06 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:51:06 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:51:06 --> Utf8 Class Initialized
INFO - 2016-06-03 15:51:06 --> URI Class Initialized
INFO - 2016-06-03 15:51:06 --> Router Class Initialized
INFO - 2016-06-03 15:51:06 --> Output Class Initialized
INFO - 2016-06-03 15:51:06 --> Security Class Initialized
DEBUG - 2016-06-03 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:51:06 --> CSRF cookie sent
INFO - 2016-06-03 15:51:06 --> Input Class Initialized
INFO - 2016-06-03 15:51:06 --> Language Class Initialized
ERROR - 2016-06-03 15:51:06 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 19
INFO - 2016-06-03 15:51:12 --> Config Class Initialized
INFO - 2016-06-03 15:51:12 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:51:12 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:51:12 --> Utf8 Class Initialized
INFO - 2016-06-03 15:51:12 --> URI Class Initialized
INFO - 2016-06-03 15:51:12 --> Router Class Initialized
INFO - 2016-06-03 15:51:12 --> Output Class Initialized
INFO - 2016-06-03 15:51:12 --> Security Class Initialized
DEBUG - 2016-06-03 15:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:51:12 --> CSRF cookie sent
INFO - 2016-06-03 15:51:12 --> Input Class Initialized
INFO - 2016-06-03 15:51:12 --> Language Class Initialized
INFO - 2016-06-03 15:51:12 --> Loader Class Initialized
INFO - 2016-06-03 15:51:12 --> Helper loaded: form_helper
INFO - 2016-06-03 15:51:12 --> Database Driver Class Initialized
INFO - 2016-06-03 15:51:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:51:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:51:12 --> Email Class Initialized
INFO - 2016-06-03 15:51:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:51:12 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:51:12 --> Helper loaded: language_helper
INFO - 2016-06-03 15:51:12 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:51:12 --> Model Class Initialized
INFO - 2016-06-03 15:51:12 --> Helper loaded: date_helper
INFO - 2016-06-03 15:51:12 --> Controller Class Initialized
INFO - 2016-06-03 15:51:12 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:51:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:51:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:51:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:51:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:51:12 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-06-03 15:51:12 --> Severity: Notice --> Use of undefined constant date - assumed 'date' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 19
ERROR - 2016-06-03 15:51:12 --> Severity: Notice --> Use of undefined constant timezone - assumed 'timezone' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 19
INFO - 2016-06-03 15:51:28 --> Config Class Initialized
INFO - 2016-06-03 15:51:28 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:51:28 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:51:28 --> Utf8 Class Initialized
INFO - 2016-06-03 15:51:28 --> URI Class Initialized
INFO - 2016-06-03 15:51:28 --> Router Class Initialized
INFO - 2016-06-03 15:51:28 --> Output Class Initialized
INFO - 2016-06-03 15:51:28 --> Security Class Initialized
DEBUG - 2016-06-03 15:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:51:28 --> CSRF cookie sent
INFO - 2016-06-03 15:51:28 --> Input Class Initialized
INFO - 2016-06-03 15:51:28 --> Language Class Initialized
INFO - 2016-06-03 15:51:28 --> Loader Class Initialized
INFO - 2016-06-03 15:51:28 --> Helper loaded: form_helper
INFO - 2016-06-03 15:51:28 --> Database Driver Class Initialized
INFO - 2016-06-03 15:51:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:51:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:51:28 --> Email Class Initialized
INFO - 2016-06-03 15:51:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:51:28 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:51:28 --> Helper loaded: language_helper
INFO - 2016-06-03 15:51:28 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:51:28 --> Model Class Initialized
INFO - 2016-06-03 15:51:28 --> Helper loaded: date_helper
INFO - 2016-06-03 15:51:28 --> Controller Class Initialized
INFO - 2016-06-03 15:51:28 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:51:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:51:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:51:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:51:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:51:28 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-06-03 15:51:28 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/core/SVS_Controller.php 19
INFO - 2016-06-03 15:51:46 --> Config Class Initialized
INFO - 2016-06-03 15:51:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:51:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:51:46 --> Utf8 Class Initialized
INFO - 2016-06-03 15:51:46 --> URI Class Initialized
INFO - 2016-06-03 15:51:46 --> Router Class Initialized
INFO - 2016-06-03 15:51:46 --> Output Class Initialized
INFO - 2016-06-03 15:51:46 --> Security Class Initialized
DEBUG - 2016-06-03 15:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:51:46 --> CSRF cookie sent
INFO - 2016-06-03 15:51:46 --> Input Class Initialized
INFO - 2016-06-03 15:51:46 --> Language Class Initialized
INFO - 2016-06-03 15:51:46 --> Loader Class Initialized
INFO - 2016-06-03 15:51:46 --> Helper loaded: form_helper
INFO - 2016-06-03 15:51:46 --> Database Driver Class Initialized
INFO - 2016-06-03 15:51:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:51:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:51:46 --> Email Class Initialized
INFO - 2016-06-03 15:51:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:51:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:51:46 --> Helper loaded: language_helper
INFO - 2016-06-03 15:51:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:51:46 --> Model Class Initialized
INFO - 2016-06-03 15:51:46 --> Helper loaded: date_helper
INFO - 2016-06-03 15:51:46 --> Controller Class Initialized
INFO - 2016-06-03 15:51:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:51:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:51:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:51:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:51:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:51:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:52:29 --> Config Class Initialized
INFO - 2016-06-03 15:52:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 15:52:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 15:52:29 --> Utf8 Class Initialized
INFO - 2016-06-03 15:52:29 --> URI Class Initialized
INFO - 2016-06-03 15:52:29 --> Router Class Initialized
INFO - 2016-06-03 15:52:29 --> Output Class Initialized
INFO - 2016-06-03 15:52:29 --> Security Class Initialized
DEBUG - 2016-06-03 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 15:52:29 --> CSRF cookie sent
INFO - 2016-06-03 15:52:29 --> Input Class Initialized
INFO - 2016-06-03 15:52:29 --> Language Class Initialized
INFO - 2016-06-03 15:52:29 --> Loader Class Initialized
INFO - 2016-06-03 15:52:29 --> Helper loaded: form_helper
INFO - 2016-06-03 15:52:29 --> Database Driver Class Initialized
INFO - 2016-06-03 15:52:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 15:52:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 15:52:29 --> Email Class Initialized
INFO - 2016-06-03 15:52:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 15:52:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 15:52:29 --> Helper loaded: language_helper
INFO - 2016-06-03 15:52:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 15:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 15:52:29 --> Model Class Initialized
INFO - 2016-06-03 15:52:29 --> Helper loaded: date_helper
INFO - 2016-06-03 15:52:29 --> Controller Class Initialized
INFO - 2016-06-03 15:52:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 15:52:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 15:52:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 15:52:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 15:52:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 15:52:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 15:52:29 --> Model Class Initialized
INFO - 2016-06-03 15:52:29 --> Form Validation Class Initialized
INFO - 2016-06-03 16:00:18 --> Config Class Initialized
INFO - 2016-06-03 16:00:18 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:00:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:00:18 --> Utf8 Class Initialized
INFO - 2016-06-03 16:00:18 --> URI Class Initialized
INFO - 2016-06-03 16:00:18 --> Router Class Initialized
INFO - 2016-06-03 16:00:18 --> Output Class Initialized
INFO - 2016-06-03 16:00:18 --> Security Class Initialized
DEBUG - 2016-06-03 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:00:18 --> CSRF cookie sent
INFO - 2016-06-03 16:00:18 --> Input Class Initialized
INFO - 2016-06-03 16:00:18 --> Language Class Initialized
INFO - 2016-06-03 16:00:18 --> Loader Class Initialized
INFO - 2016-06-03 16:00:18 --> Helper loaded: form_helper
INFO - 2016-06-03 16:00:18 --> Database Driver Class Initialized
INFO - 2016-06-03 16:00:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:00:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:00:18 --> Email Class Initialized
INFO - 2016-06-03 16:00:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:00:18 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:00:18 --> Helper loaded: language_helper
INFO - 2016-06-03 16:00:18 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:00:18 --> Model Class Initialized
INFO - 2016-06-03 16:00:18 --> Helper loaded: date_helper
INFO - 2016-06-03 16:00:18 --> Controller Class Initialized
INFO - 2016-06-03 16:00:18 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:00:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:00:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:00:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:00:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:00:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:00:18 --> Model Class Initialized
INFO - 2016-06-03 16:00:18 --> Form Validation Class Initialized
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:00:18 --> Final output sent to browser
DEBUG - 2016-06-03 16:00:18 --> Total execution time: 0.0667
INFO - 2016-06-03 16:00:23 --> Config Class Initialized
INFO - 2016-06-03 16:00:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:00:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:00:23 --> Utf8 Class Initialized
INFO - 2016-06-03 16:00:23 --> URI Class Initialized
INFO - 2016-06-03 16:00:23 --> Router Class Initialized
INFO - 2016-06-03 16:00:23 --> Output Class Initialized
INFO - 2016-06-03 16:00:23 --> Security Class Initialized
DEBUG - 2016-06-03 16:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:00:23 --> CSRF cookie sent
INFO - 2016-06-03 16:00:23 --> CSRF token verified
INFO - 2016-06-03 16:00:23 --> Input Class Initialized
INFO - 2016-06-03 16:00:23 --> Language Class Initialized
INFO - 2016-06-03 16:00:23 --> Loader Class Initialized
INFO - 2016-06-03 16:00:23 --> Helper loaded: form_helper
INFO - 2016-06-03 16:00:23 --> Database Driver Class Initialized
INFO - 2016-06-03 16:00:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:00:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:00:23 --> Email Class Initialized
INFO - 2016-06-03 16:00:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:00:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:00:23 --> Helper loaded: language_helper
INFO - 2016-06-03 16:00:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:00:23 --> Model Class Initialized
INFO - 2016-06-03 16:00:23 --> Helper loaded: date_helper
INFO - 2016-06-03 16:00:23 --> Controller Class Initialized
INFO - 2016-06-03 16:00:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:00:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:00:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:00:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:00:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:00:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:00:23 --> Model Class Initialized
INFO - 2016-06-03 16:00:23 --> Form Validation Class Initialized
INFO - 2016-06-03 16:00:23 --> Final output sent to browser
DEBUG - 2016-06-03 16:00:23 --> Total execution time: 0.0520
INFO - 2016-06-03 16:02:25 --> Config Class Initialized
INFO - 2016-06-03 16:02:25 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:02:25 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:02:25 --> Utf8 Class Initialized
INFO - 2016-06-03 16:02:25 --> URI Class Initialized
INFO - 2016-06-03 16:02:25 --> Router Class Initialized
INFO - 2016-06-03 16:02:25 --> Output Class Initialized
INFO - 2016-06-03 16:02:25 --> Security Class Initialized
DEBUG - 2016-06-03 16:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:02:25 --> CSRF cookie sent
INFO - 2016-06-03 16:02:25 --> Input Class Initialized
INFO - 2016-06-03 16:02:25 --> Language Class Initialized
INFO - 2016-06-03 16:02:25 --> Loader Class Initialized
INFO - 2016-06-03 16:02:25 --> Helper loaded: form_helper
INFO - 2016-06-03 16:02:25 --> Database Driver Class Initialized
INFO - 2016-06-03 16:02:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:02:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:02:25 --> Email Class Initialized
INFO - 2016-06-03 16:02:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:02:25 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:02:25 --> Helper loaded: language_helper
INFO - 2016-06-03 16:02:25 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:02:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:02:25 --> Model Class Initialized
INFO - 2016-06-03 16:02:25 --> Helper loaded: date_helper
INFO - 2016-06-03 16:02:25 --> Controller Class Initialized
INFO - 2016-06-03 16:02:25 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:02:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:02:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:02:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:02:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:02:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:02:25 --> Model Class Initialized
INFO - 2016-06-03 16:02:25 --> Form Validation Class Initialized
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:02:25 --> Final output sent to browser
DEBUG - 2016-06-03 16:02:25 --> Total execution time: 0.0281
INFO - 2016-06-03 16:02:30 --> Config Class Initialized
INFO - 2016-06-03 16:02:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:02:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:02:30 --> Utf8 Class Initialized
INFO - 2016-06-03 16:02:30 --> URI Class Initialized
INFO - 2016-06-03 16:02:30 --> Router Class Initialized
INFO - 2016-06-03 16:02:30 --> Output Class Initialized
INFO - 2016-06-03 16:02:30 --> Security Class Initialized
DEBUG - 2016-06-03 16:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:02:30 --> CSRF cookie sent
INFO - 2016-06-03 16:02:30 --> CSRF token verified
INFO - 2016-06-03 16:02:30 --> Input Class Initialized
INFO - 2016-06-03 16:02:30 --> Language Class Initialized
INFO - 2016-06-03 16:02:30 --> Loader Class Initialized
INFO - 2016-06-03 16:02:30 --> Helper loaded: form_helper
INFO - 2016-06-03 16:02:30 --> Database Driver Class Initialized
INFO - 2016-06-03 16:02:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:02:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:02:30 --> Email Class Initialized
INFO - 2016-06-03 16:02:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:02:30 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:02:30 --> Helper loaded: language_helper
INFO - 2016-06-03 16:02:30 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:02:30 --> Model Class Initialized
INFO - 2016-06-03 16:02:30 --> Helper loaded: date_helper
INFO - 2016-06-03 16:02:30 --> Controller Class Initialized
INFO - 2016-06-03 16:02:30 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:02:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:02:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:02:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:02:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:02:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:02:30 --> Model Class Initialized
INFO - 2016-06-03 16:02:30 --> Form Validation Class Initialized
INFO - 2016-06-03 16:02:30 --> Final output sent to browser
DEBUG - 2016-06-03 16:02:30 --> Total execution time: 0.0429
INFO - 2016-06-03 16:03:04 --> Config Class Initialized
INFO - 2016-06-03 16:03:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:03:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:03:04 --> Utf8 Class Initialized
INFO - 2016-06-03 16:03:04 --> URI Class Initialized
INFO - 2016-06-03 16:03:04 --> Router Class Initialized
INFO - 2016-06-03 16:03:04 --> Output Class Initialized
INFO - 2016-06-03 16:03:04 --> Security Class Initialized
DEBUG - 2016-06-03 16:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:03:04 --> CSRF cookie sent
INFO - 2016-06-03 16:03:04 --> Input Class Initialized
INFO - 2016-06-03 16:03:04 --> Language Class Initialized
INFO - 2016-06-03 16:03:04 --> Loader Class Initialized
INFO - 2016-06-03 16:03:04 --> Helper loaded: form_helper
INFO - 2016-06-03 16:03:04 --> Database Driver Class Initialized
INFO - 2016-06-03 16:03:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:03:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:03:04 --> Email Class Initialized
INFO - 2016-06-03 16:03:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:03:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:03:04 --> Helper loaded: language_helper
INFO - 2016-06-03 16:03:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:03:04 --> Model Class Initialized
INFO - 2016-06-03 16:03:04 --> Helper loaded: date_helper
INFO - 2016-06-03 16:03:04 --> Controller Class Initialized
INFO - 2016-06-03 16:03:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:03:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:03:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:03:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:03:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:03:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:03:04 --> Model Class Initialized
INFO - 2016-06-03 16:03:04 --> Form Validation Class Initialized
INFO - 2016-06-03 16:03:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:03:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:03:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:03:05 --> Final output sent to browser
DEBUG - 2016-06-03 16:03:05 --> Total execution time: 0.0575
INFO - 2016-06-03 16:03:08 --> Config Class Initialized
INFO - 2016-06-03 16:03:08 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:03:08 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:03:08 --> Utf8 Class Initialized
INFO - 2016-06-03 16:03:08 --> URI Class Initialized
INFO - 2016-06-03 16:03:08 --> Router Class Initialized
INFO - 2016-06-03 16:03:08 --> Output Class Initialized
INFO - 2016-06-03 16:03:08 --> Security Class Initialized
DEBUG - 2016-06-03 16:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:03:08 --> CSRF cookie sent
INFO - 2016-06-03 16:03:08 --> CSRF token verified
INFO - 2016-06-03 16:03:08 --> Input Class Initialized
INFO - 2016-06-03 16:03:08 --> Language Class Initialized
INFO - 2016-06-03 16:03:08 --> Loader Class Initialized
INFO - 2016-06-03 16:03:08 --> Helper loaded: form_helper
INFO - 2016-06-03 16:03:08 --> Database Driver Class Initialized
INFO - 2016-06-03 16:03:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:03:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:03:08 --> Email Class Initialized
INFO - 2016-06-03 16:03:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:03:08 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:03:08 --> Helper loaded: language_helper
INFO - 2016-06-03 16:03:08 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:03:08 --> Model Class Initialized
INFO - 2016-06-03 16:03:08 --> Helper loaded: date_helper
INFO - 2016-06-03 16:03:08 --> Controller Class Initialized
INFO - 2016-06-03 16:03:08 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:03:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:03:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:03:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:03:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:03:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:03:08 --> Model Class Initialized
INFO - 2016-06-03 16:03:08 --> Form Validation Class Initialized
INFO - 2016-06-03 16:03:08 --> Final output sent to browser
DEBUG - 2016-06-03 16:03:08 --> Total execution time: 0.0586
INFO - 2016-06-03 16:03:50 --> Config Class Initialized
INFO - 2016-06-03 16:03:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:03:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:03:50 --> Utf8 Class Initialized
INFO - 2016-06-03 16:03:50 --> URI Class Initialized
INFO - 2016-06-03 16:03:50 --> Router Class Initialized
INFO - 2016-06-03 16:03:50 --> Output Class Initialized
INFO - 2016-06-03 16:03:50 --> Security Class Initialized
DEBUG - 2016-06-03 16:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:03:50 --> CSRF cookie sent
INFO - 2016-06-03 16:03:50 --> Input Class Initialized
INFO - 2016-06-03 16:03:50 --> Language Class Initialized
INFO - 2016-06-03 16:03:50 --> Loader Class Initialized
INFO - 2016-06-03 16:03:50 --> Helper loaded: form_helper
INFO - 2016-06-03 16:03:50 --> Database Driver Class Initialized
INFO - 2016-06-03 16:03:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:03:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:03:50 --> Email Class Initialized
INFO - 2016-06-03 16:03:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:03:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:03:50 --> Helper loaded: language_helper
INFO - 2016-06-03 16:03:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:03:50 --> Model Class Initialized
INFO - 2016-06-03 16:03:50 --> Helper loaded: date_helper
INFO - 2016-06-03 16:03:50 --> Controller Class Initialized
INFO - 2016-06-03 16:03:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:03:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:03:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:03:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:03:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:03:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:03:50 --> Model Class Initialized
INFO - 2016-06-03 16:03:50 --> Form Validation Class Initialized
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:03:50 --> Final output sent to browser
DEBUG - 2016-06-03 16:03:50 --> Total execution time: 0.0574
INFO - 2016-06-03 16:03:55 --> Config Class Initialized
INFO - 2016-06-03 16:03:55 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:03:55 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:03:55 --> Utf8 Class Initialized
INFO - 2016-06-03 16:03:55 --> URI Class Initialized
INFO - 2016-06-03 16:03:55 --> Router Class Initialized
INFO - 2016-06-03 16:03:55 --> Output Class Initialized
INFO - 2016-06-03 16:03:55 --> Security Class Initialized
DEBUG - 2016-06-03 16:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:03:55 --> CSRF cookie sent
INFO - 2016-06-03 16:03:55 --> CSRF token verified
INFO - 2016-06-03 16:03:55 --> Input Class Initialized
INFO - 2016-06-03 16:03:55 --> Language Class Initialized
INFO - 2016-06-03 16:03:55 --> Loader Class Initialized
INFO - 2016-06-03 16:03:55 --> Helper loaded: form_helper
INFO - 2016-06-03 16:03:55 --> Database Driver Class Initialized
INFO - 2016-06-03 16:03:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:03:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:03:55 --> Email Class Initialized
INFO - 2016-06-03 16:03:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:03:55 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:03:55 --> Helper loaded: language_helper
INFO - 2016-06-03 16:03:55 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:03:55 --> Model Class Initialized
INFO - 2016-06-03 16:03:55 --> Helper loaded: date_helper
INFO - 2016-06-03 16:03:55 --> Controller Class Initialized
INFO - 2016-06-03 16:03:55 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:03:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:03:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:03:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:03:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:03:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:03:55 --> Model Class Initialized
INFO - 2016-06-03 16:03:55 --> Form Validation Class Initialized
INFO - 2016-06-03 16:03:55 --> Final output sent to browser
DEBUG - 2016-06-03 16:03:55 --> Total execution time: 0.0167
INFO - 2016-06-03 16:06:05 --> Config Class Initialized
INFO - 2016-06-03 16:06:05 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:06:05 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:06:05 --> Utf8 Class Initialized
INFO - 2016-06-03 16:06:05 --> URI Class Initialized
INFO - 2016-06-03 16:06:05 --> Router Class Initialized
INFO - 2016-06-03 16:06:05 --> Output Class Initialized
INFO - 2016-06-03 16:06:05 --> Security Class Initialized
DEBUG - 2016-06-03 16:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:06:05 --> CSRF cookie sent
INFO - 2016-06-03 16:06:05 --> Input Class Initialized
INFO - 2016-06-03 16:06:05 --> Language Class Initialized
INFO - 2016-06-03 16:06:05 --> Loader Class Initialized
INFO - 2016-06-03 16:06:05 --> Helper loaded: form_helper
INFO - 2016-06-03 16:06:05 --> Database Driver Class Initialized
INFO - 2016-06-03 16:06:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:06:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:06:05 --> Email Class Initialized
INFO - 2016-06-03 16:06:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:06:05 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:06:05 --> Helper loaded: language_helper
INFO - 2016-06-03 16:06:05 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:06:05 --> Model Class Initialized
INFO - 2016-06-03 16:06:05 --> Helper loaded: date_helper
INFO - 2016-06-03 16:06:05 --> Controller Class Initialized
INFO - 2016-06-03 16:06:05 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:06:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:06:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:06:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:06:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:06:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:06:05 --> Model Class Initialized
INFO - 2016-06-03 16:06:05 --> Form Validation Class Initialized
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:06:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:06:05 --> Final output sent to browser
DEBUG - 2016-06-03 16:06:05 --> Total execution time: 0.0531
INFO - 2016-06-03 16:06:11 --> Config Class Initialized
INFO - 2016-06-03 16:06:11 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:06:11 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:06:11 --> Utf8 Class Initialized
INFO - 2016-06-03 16:06:11 --> URI Class Initialized
INFO - 2016-06-03 16:06:11 --> Router Class Initialized
INFO - 2016-06-03 16:06:11 --> Output Class Initialized
INFO - 2016-06-03 16:06:11 --> Security Class Initialized
DEBUG - 2016-06-03 16:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:06:11 --> CSRF cookie sent
INFO - 2016-06-03 16:06:11 --> CSRF token verified
INFO - 2016-06-03 16:06:11 --> Input Class Initialized
INFO - 2016-06-03 16:06:11 --> Language Class Initialized
INFO - 2016-06-03 16:06:11 --> Loader Class Initialized
INFO - 2016-06-03 16:06:11 --> Helper loaded: form_helper
INFO - 2016-06-03 16:06:11 --> Database Driver Class Initialized
INFO - 2016-06-03 16:06:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:06:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:06:11 --> Email Class Initialized
INFO - 2016-06-03 16:06:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:06:11 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:06:11 --> Helper loaded: language_helper
INFO - 2016-06-03 16:06:11 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:06:11 --> Model Class Initialized
INFO - 2016-06-03 16:06:11 --> Helper loaded: date_helper
INFO - 2016-06-03 16:06:11 --> Controller Class Initialized
INFO - 2016-06-03 16:06:11 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:06:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:06:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:06:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:06:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:06:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:06:11 --> Model Class Initialized
INFO - 2016-06-03 16:06:11 --> Form Validation Class Initialized
INFO - 2016-06-03 16:06:11 --> Final output sent to browser
DEBUG - 2016-06-03 16:06:11 --> Total execution time: 0.0735
INFO - 2016-06-03 16:06:17 --> Config Class Initialized
INFO - 2016-06-03 16:06:17 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:06:17 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:06:17 --> Utf8 Class Initialized
INFO - 2016-06-03 16:06:17 --> URI Class Initialized
INFO - 2016-06-03 16:06:17 --> Router Class Initialized
INFO - 2016-06-03 16:06:17 --> Output Class Initialized
INFO - 2016-06-03 16:06:17 --> Security Class Initialized
DEBUG - 2016-06-03 16:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:06:17 --> CSRF cookie sent
INFO - 2016-06-03 16:06:17 --> Input Class Initialized
INFO - 2016-06-03 16:06:17 --> Language Class Initialized
INFO - 2016-06-03 16:06:17 --> Loader Class Initialized
INFO - 2016-06-03 16:06:17 --> Helper loaded: form_helper
INFO - 2016-06-03 16:06:17 --> Database Driver Class Initialized
INFO - 2016-06-03 16:06:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:06:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:06:17 --> Email Class Initialized
INFO - 2016-06-03 16:06:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:06:17 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:06:17 --> Helper loaded: language_helper
INFO - 2016-06-03 16:06:17 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:06:17 --> Model Class Initialized
INFO - 2016-06-03 16:06:17 --> Helper loaded: date_helper
INFO - 2016-06-03 16:06:17 --> Controller Class Initialized
INFO - 2016-06-03 16:06:17 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:06:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:06:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:06:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:06:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:06:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:06:17 --> Model Class Initialized
INFO - 2016-06-03 16:06:17 --> Form Validation Class Initialized
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:06:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:06:17 --> Final output sent to browser
DEBUG - 2016-06-03 16:06:17 --> Total execution time: 0.0468
INFO - 2016-06-03 16:06:24 --> Config Class Initialized
INFO - 2016-06-03 16:06:24 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:06:24 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:06:24 --> Utf8 Class Initialized
INFO - 2016-06-03 16:06:24 --> URI Class Initialized
INFO - 2016-06-03 16:06:24 --> Router Class Initialized
INFO - 2016-06-03 16:06:24 --> Output Class Initialized
INFO - 2016-06-03 16:06:24 --> Security Class Initialized
DEBUG - 2016-06-03 16:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:06:24 --> CSRF cookie sent
INFO - 2016-06-03 16:06:24 --> CSRF token verified
INFO - 2016-06-03 16:06:24 --> Input Class Initialized
INFO - 2016-06-03 16:06:24 --> Language Class Initialized
INFO - 2016-06-03 16:06:24 --> Loader Class Initialized
INFO - 2016-06-03 16:06:24 --> Helper loaded: form_helper
INFO - 2016-06-03 16:06:24 --> Database Driver Class Initialized
INFO - 2016-06-03 16:06:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:06:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:06:24 --> Email Class Initialized
INFO - 2016-06-03 16:06:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:06:24 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:06:24 --> Helper loaded: language_helper
INFO - 2016-06-03 16:06:24 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:06:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:06:24 --> Model Class Initialized
INFO - 2016-06-03 16:06:24 --> Helper loaded: date_helper
INFO - 2016-06-03 16:06:24 --> Controller Class Initialized
INFO - 2016-06-03 16:06:24 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:06:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:06:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:06:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:06:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:06:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:06:24 --> Model Class Initialized
INFO - 2016-06-03 16:06:24 --> Form Validation Class Initialized
INFO - 2016-06-03 16:06:24 --> Final output sent to browser
DEBUG - 2016-06-03 16:06:24 --> Total execution time: 0.0517
INFO - 2016-06-03 16:07:02 --> Config Class Initialized
INFO - 2016-06-03 16:07:02 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:07:02 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:07:02 --> Utf8 Class Initialized
INFO - 2016-06-03 16:07:02 --> URI Class Initialized
INFO - 2016-06-03 16:07:02 --> Router Class Initialized
INFO - 2016-06-03 16:07:02 --> Output Class Initialized
INFO - 2016-06-03 16:07:02 --> Security Class Initialized
DEBUG - 2016-06-03 16:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:07:02 --> CSRF cookie sent
INFO - 2016-06-03 16:07:02 --> Input Class Initialized
INFO - 2016-06-03 16:07:02 --> Language Class Initialized
INFO - 2016-06-03 16:07:02 --> Loader Class Initialized
INFO - 2016-06-03 16:07:02 --> Helper loaded: form_helper
INFO - 2016-06-03 16:07:02 --> Database Driver Class Initialized
INFO - 2016-06-03 16:07:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:07:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:07:02 --> Email Class Initialized
INFO - 2016-06-03 16:07:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:07:02 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:07:02 --> Helper loaded: language_helper
INFO - 2016-06-03 16:07:02 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:07:02 --> Model Class Initialized
INFO - 2016-06-03 16:07:02 --> Helper loaded: date_helper
INFO - 2016-06-03 16:07:02 --> Controller Class Initialized
INFO - 2016-06-03 16:07:02 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:07:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:07:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:07:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:07:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:07:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:07:02 --> Model Class Initialized
INFO - 2016-06-03 16:07:02 --> Form Validation Class Initialized
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:07:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:07:02 --> Final output sent to browser
DEBUG - 2016-06-03 16:07:02 --> Total execution time: 0.0687
INFO - 2016-06-03 16:07:08 --> Config Class Initialized
INFO - 2016-06-03 16:07:08 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:07:08 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:07:08 --> Utf8 Class Initialized
INFO - 2016-06-03 16:07:08 --> URI Class Initialized
INFO - 2016-06-03 16:07:08 --> Router Class Initialized
INFO - 2016-06-03 16:07:08 --> Output Class Initialized
INFO - 2016-06-03 16:07:08 --> Security Class Initialized
DEBUG - 2016-06-03 16:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:07:08 --> CSRF cookie sent
INFO - 2016-06-03 16:07:08 --> CSRF token verified
INFO - 2016-06-03 16:07:08 --> Input Class Initialized
INFO - 2016-06-03 16:07:08 --> Language Class Initialized
INFO - 2016-06-03 16:07:08 --> Loader Class Initialized
INFO - 2016-06-03 16:07:08 --> Helper loaded: form_helper
INFO - 2016-06-03 16:07:08 --> Database Driver Class Initialized
INFO - 2016-06-03 16:07:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:07:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:07:08 --> Email Class Initialized
INFO - 2016-06-03 16:07:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:07:08 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:07:08 --> Helper loaded: language_helper
INFO - 2016-06-03 16:07:08 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:07:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:07:08 --> Model Class Initialized
INFO - 2016-06-03 16:07:08 --> Helper loaded: date_helper
INFO - 2016-06-03 16:07:08 --> Controller Class Initialized
INFO - 2016-06-03 16:07:08 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:07:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:07:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:07:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:07:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:07:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:07:08 --> Model Class Initialized
INFO - 2016-06-03 16:07:08 --> Form Validation Class Initialized
INFO - 2016-06-03 16:07:08 --> Final output sent to browser
DEBUG - 2016-06-03 16:07:08 --> Total execution time: 0.0219
INFO - 2016-06-03 16:09:30 --> Config Class Initialized
INFO - 2016-06-03 16:09:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:09:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:09:30 --> Utf8 Class Initialized
INFO - 2016-06-03 16:09:30 --> URI Class Initialized
INFO - 2016-06-03 16:09:30 --> Router Class Initialized
INFO - 2016-06-03 16:09:30 --> Output Class Initialized
INFO - 2016-06-03 16:09:30 --> Security Class Initialized
DEBUG - 2016-06-03 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:09:30 --> CSRF cookie sent
INFO - 2016-06-03 16:09:30 --> Input Class Initialized
INFO - 2016-06-03 16:09:30 --> Language Class Initialized
INFO - 2016-06-03 16:09:30 --> Loader Class Initialized
INFO - 2016-06-03 16:09:30 --> Helper loaded: form_helper
INFO - 2016-06-03 16:09:30 --> Database Driver Class Initialized
INFO - 2016-06-03 16:09:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:09:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:09:30 --> Email Class Initialized
INFO - 2016-06-03 16:09:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:09:30 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:09:30 --> Helper loaded: language_helper
INFO - 2016-06-03 16:09:30 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:09:30 --> Model Class Initialized
INFO - 2016-06-03 16:09:30 --> Helper loaded: date_helper
INFO - 2016-06-03 16:09:30 --> Controller Class Initialized
INFO - 2016-06-03 16:09:30 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:09:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:09:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:09:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:09:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:09:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:09:30 --> Model Class Initialized
INFO - 2016-06-03 16:09:30 --> Form Validation Class Initialized
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:09:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:09:30 --> Final output sent to browser
DEBUG - 2016-06-03 16:09:30 --> Total execution time: 0.0708
INFO - 2016-06-03 16:09:36 --> Config Class Initialized
INFO - 2016-06-03 16:09:36 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:09:36 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:09:36 --> Utf8 Class Initialized
INFO - 2016-06-03 16:09:36 --> URI Class Initialized
INFO - 2016-06-03 16:09:36 --> Router Class Initialized
INFO - 2016-06-03 16:09:36 --> Output Class Initialized
INFO - 2016-06-03 16:09:36 --> Security Class Initialized
DEBUG - 2016-06-03 16:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:09:36 --> CSRF cookie sent
INFO - 2016-06-03 16:09:36 --> CSRF token verified
INFO - 2016-06-03 16:09:36 --> Input Class Initialized
INFO - 2016-06-03 16:09:36 --> Language Class Initialized
INFO - 2016-06-03 16:09:36 --> Loader Class Initialized
INFO - 2016-06-03 16:09:36 --> Helper loaded: form_helper
INFO - 2016-06-03 16:09:36 --> Database Driver Class Initialized
INFO - 2016-06-03 16:09:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:09:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:09:36 --> Email Class Initialized
INFO - 2016-06-03 16:09:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:09:36 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:09:36 --> Helper loaded: language_helper
INFO - 2016-06-03 16:09:36 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:09:36 --> Model Class Initialized
INFO - 2016-06-03 16:09:36 --> Helper loaded: date_helper
INFO - 2016-06-03 16:09:36 --> Controller Class Initialized
INFO - 2016-06-03 16:09:36 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:09:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:09:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:09:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:09:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:09:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:09:36 --> Model Class Initialized
INFO - 2016-06-03 16:09:36 --> Form Validation Class Initialized
INFO - 2016-06-03 16:09:36 --> Final output sent to browser
DEBUG - 2016-06-03 16:09:36 --> Total execution time: 0.0457
INFO - 2016-06-03 16:12:44 --> Config Class Initialized
INFO - 2016-06-03 16:12:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:12:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:12:44 --> Utf8 Class Initialized
INFO - 2016-06-03 16:12:44 --> URI Class Initialized
INFO - 2016-06-03 16:12:44 --> Router Class Initialized
INFO - 2016-06-03 16:12:44 --> Output Class Initialized
INFO - 2016-06-03 16:12:44 --> Security Class Initialized
DEBUG - 2016-06-03 16:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:12:44 --> CSRF cookie sent
INFO - 2016-06-03 16:12:44 --> Input Class Initialized
INFO - 2016-06-03 16:12:44 --> Language Class Initialized
INFO - 2016-06-03 16:12:44 --> Loader Class Initialized
INFO - 2016-06-03 16:12:44 --> Helper loaded: form_helper
INFO - 2016-06-03 16:12:44 --> Database Driver Class Initialized
INFO - 2016-06-03 16:12:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:12:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:12:44 --> Email Class Initialized
INFO - 2016-06-03 16:12:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:12:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:12:44 --> Helper loaded: language_helper
INFO - 2016-06-03 16:12:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:12:44 --> Model Class Initialized
INFO - 2016-06-03 16:12:44 --> Helper loaded: date_helper
INFO - 2016-06-03 16:12:44 --> Controller Class Initialized
INFO - 2016-06-03 16:12:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:12:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:12:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:12:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:12:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:12:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:12:44 --> Model Class Initialized
INFO - 2016-06-03 16:12:44 --> Form Validation Class Initialized
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:12:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:12:44 --> Final output sent to browser
DEBUG - 2016-06-03 16:12:44 --> Total execution time: 0.0979
INFO - 2016-06-03 16:12:49 --> Config Class Initialized
INFO - 2016-06-03 16:12:49 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:12:49 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:12:49 --> Utf8 Class Initialized
INFO - 2016-06-03 16:12:49 --> URI Class Initialized
INFO - 2016-06-03 16:12:49 --> Router Class Initialized
INFO - 2016-06-03 16:12:49 --> Output Class Initialized
INFO - 2016-06-03 16:12:49 --> Security Class Initialized
DEBUG - 2016-06-03 16:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:12:49 --> CSRF cookie sent
INFO - 2016-06-03 16:12:49 --> CSRF token verified
INFO - 2016-06-03 16:12:49 --> Input Class Initialized
INFO - 2016-06-03 16:12:49 --> Language Class Initialized
INFO - 2016-06-03 16:12:49 --> Loader Class Initialized
INFO - 2016-06-03 16:12:49 --> Helper loaded: form_helper
INFO - 2016-06-03 16:12:49 --> Database Driver Class Initialized
INFO - 2016-06-03 16:12:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:12:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:12:49 --> Email Class Initialized
INFO - 2016-06-03 16:12:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:12:49 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:12:49 --> Helper loaded: language_helper
INFO - 2016-06-03 16:12:49 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:12:49 --> Model Class Initialized
INFO - 2016-06-03 16:12:49 --> Helper loaded: date_helper
INFO - 2016-06-03 16:12:49 --> Controller Class Initialized
INFO - 2016-06-03 16:12:49 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:12:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:12:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:12:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:12:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:12:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:12:49 --> Model Class Initialized
INFO - 2016-06-03 16:12:49 --> Form Validation Class Initialized
INFO - 2016-06-03 16:12:49 --> Final output sent to browser
DEBUG - 2016-06-03 16:12:49 --> Total execution time: 0.0582
INFO - 2016-06-03 16:16:16 --> Config Class Initialized
INFO - 2016-06-03 16:16:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:16:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:16:16 --> Utf8 Class Initialized
INFO - 2016-06-03 16:16:16 --> URI Class Initialized
INFO - 2016-06-03 16:16:16 --> Router Class Initialized
INFO - 2016-06-03 16:16:16 --> Output Class Initialized
INFO - 2016-06-03 16:16:16 --> Security Class Initialized
DEBUG - 2016-06-03 16:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:16:16 --> CSRF cookie sent
INFO - 2016-06-03 16:16:16 --> Input Class Initialized
INFO - 2016-06-03 16:16:16 --> Language Class Initialized
INFO - 2016-06-03 16:16:16 --> Loader Class Initialized
INFO - 2016-06-03 16:16:16 --> Helper loaded: form_helper
INFO - 2016-06-03 16:16:16 --> Database Driver Class Initialized
INFO - 2016-06-03 16:16:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:16:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:16:16 --> Email Class Initialized
INFO - 2016-06-03 16:16:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:16:16 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:16:16 --> Helper loaded: language_helper
INFO - 2016-06-03 16:16:16 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:16:16 --> Model Class Initialized
INFO - 2016-06-03 16:16:16 --> Helper loaded: date_helper
INFO - 2016-06-03 16:16:16 --> Controller Class Initialized
INFO - 2016-06-03 16:16:16 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:16:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:16:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:16:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:16:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:16:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:16:16 --> Model Class Initialized
INFO - 2016-06-03 16:16:16 --> Form Validation Class Initialized
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:16:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:16:16 --> Final output sent to browser
DEBUG - 2016-06-03 16:16:16 --> Total execution time: 0.0590
INFO - 2016-06-03 16:16:22 --> Config Class Initialized
INFO - 2016-06-03 16:16:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:16:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:16:22 --> Utf8 Class Initialized
INFO - 2016-06-03 16:16:22 --> URI Class Initialized
INFO - 2016-06-03 16:16:22 --> Router Class Initialized
INFO - 2016-06-03 16:16:22 --> Output Class Initialized
INFO - 2016-06-03 16:16:22 --> Security Class Initialized
DEBUG - 2016-06-03 16:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:16:22 --> CSRF cookie sent
INFO - 2016-06-03 16:16:22 --> CSRF token verified
INFO - 2016-06-03 16:16:22 --> Input Class Initialized
INFO - 2016-06-03 16:16:22 --> Language Class Initialized
INFO - 2016-06-03 16:16:22 --> Loader Class Initialized
INFO - 2016-06-03 16:16:22 --> Helper loaded: form_helper
INFO - 2016-06-03 16:16:22 --> Database Driver Class Initialized
INFO - 2016-06-03 16:16:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:16:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:16:22 --> Email Class Initialized
INFO - 2016-06-03 16:16:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:16:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:16:22 --> Helper loaded: language_helper
INFO - 2016-06-03 16:16:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:16:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:16:22 --> Model Class Initialized
INFO - 2016-06-03 16:16:22 --> Helper loaded: date_helper
INFO - 2016-06-03 16:16:22 --> Controller Class Initialized
INFO - 2016-06-03 16:16:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:16:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:16:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:16:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:16:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:16:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:16:22 --> Model Class Initialized
INFO - 2016-06-03 16:16:22 --> Form Validation Class Initialized
INFO - 2016-06-03 16:16:22 --> Final output sent to browser
DEBUG - 2016-06-03 16:16:22 --> Total execution time: 0.0338
INFO - 2016-06-03 16:18:23 --> Config Class Initialized
INFO - 2016-06-03 16:18:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:18:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:18:23 --> Utf8 Class Initialized
INFO - 2016-06-03 16:18:23 --> URI Class Initialized
INFO - 2016-06-03 16:18:23 --> Router Class Initialized
INFO - 2016-06-03 16:18:23 --> Output Class Initialized
INFO - 2016-06-03 16:18:23 --> Security Class Initialized
DEBUG - 2016-06-03 16:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:18:23 --> CSRF cookie sent
INFO - 2016-06-03 16:18:23 --> Input Class Initialized
INFO - 2016-06-03 16:18:23 --> Language Class Initialized
INFO - 2016-06-03 16:18:23 --> Loader Class Initialized
INFO - 2016-06-03 16:18:23 --> Helper loaded: form_helper
INFO - 2016-06-03 16:18:23 --> Database Driver Class Initialized
INFO - 2016-06-03 16:18:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:18:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:18:23 --> Email Class Initialized
INFO - 2016-06-03 16:18:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:18:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:18:23 --> Helper loaded: language_helper
INFO - 2016-06-03 16:18:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:18:23 --> Model Class Initialized
INFO - 2016-06-03 16:18:23 --> Helper loaded: date_helper
INFO - 2016-06-03 16:18:23 --> Controller Class Initialized
INFO - 2016-06-03 16:18:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:18:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:18:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:18:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:18:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:18:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:18:23 --> Model Class Initialized
INFO - 2016-06-03 16:18:23 --> Form Validation Class Initialized
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:18:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:18:23 --> Final output sent to browser
DEBUG - 2016-06-03 16:18:23 --> Total execution time: 0.0900
INFO - 2016-06-03 16:18:28 --> Config Class Initialized
INFO - 2016-06-03 16:18:28 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:18:28 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:18:28 --> Utf8 Class Initialized
INFO - 2016-06-03 16:18:28 --> URI Class Initialized
INFO - 2016-06-03 16:18:28 --> Router Class Initialized
INFO - 2016-06-03 16:18:28 --> Output Class Initialized
INFO - 2016-06-03 16:18:28 --> Security Class Initialized
DEBUG - 2016-06-03 16:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:18:28 --> CSRF cookie sent
INFO - 2016-06-03 16:18:28 --> CSRF token verified
INFO - 2016-06-03 16:18:28 --> Input Class Initialized
INFO - 2016-06-03 16:18:28 --> Language Class Initialized
INFO - 2016-06-03 16:18:28 --> Loader Class Initialized
INFO - 2016-06-03 16:18:28 --> Helper loaded: form_helper
INFO - 2016-06-03 16:18:28 --> Database Driver Class Initialized
INFO - 2016-06-03 16:18:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:18:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:18:28 --> Email Class Initialized
INFO - 2016-06-03 16:18:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:18:28 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:18:28 --> Helper loaded: language_helper
INFO - 2016-06-03 16:18:28 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:18:28 --> Model Class Initialized
INFO - 2016-06-03 16:18:28 --> Helper loaded: date_helper
INFO - 2016-06-03 16:18:28 --> Controller Class Initialized
INFO - 2016-06-03 16:18:28 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:18:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:18:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:18:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:18:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:18:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:18:28 --> Model Class Initialized
INFO - 2016-06-03 16:18:28 --> Form Validation Class Initialized
INFO - 2016-06-03 16:18:28 --> Final output sent to browser
DEBUG - 2016-06-03 16:18:28 --> Total execution time: 0.0695
INFO - 2016-06-03 16:18:37 --> Config Class Initialized
INFO - 2016-06-03 16:18:37 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:18:37 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:18:37 --> Utf8 Class Initialized
INFO - 2016-06-03 16:18:37 --> URI Class Initialized
INFO - 2016-06-03 16:18:37 --> Router Class Initialized
INFO - 2016-06-03 16:18:37 --> Output Class Initialized
INFO - 2016-06-03 16:18:37 --> Security Class Initialized
DEBUG - 2016-06-03 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:18:37 --> CSRF cookie sent
INFO - 2016-06-03 16:18:37 --> Input Class Initialized
INFO - 2016-06-03 16:18:37 --> Language Class Initialized
INFO - 2016-06-03 16:18:37 --> Loader Class Initialized
INFO - 2016-06-03 16:18:37 --> Helper loaded: form_helper
INFO - 2016-06-03 16:18:37 --> Database Driver Class Initialized
INFO - 2016-06-03 16:18:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:18:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:18:37 --> Email Class Initialized
INFO - 2016-06-03 16:18:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:18:37 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:18:37 --> Helper loaded: language_helper
INFO - 2016-06-03 16:18:37 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:18:37 --> Model Class Initialized
INFO - 2016-06-03 16:18:37 --> Helper loaded: date_helper
INFO - 2016-06-03 16:18:37 --> Controller Class Initialized
INFO - 2016-06-03 16:18:37 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:18:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:18:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:18:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:18:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:18:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:18:37 --> Model Class Initialized
INFO - 2016-06-03 16:18:37 --> Form Validation Class Initialized
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:18:38 --> Final output sent to browser
DEBUG - 2016-06-03 16:18:38 --> Total execution time: 0.0993
INFO - 2016-06-03 16:18:45 --> Config Class Initialized
INFO - 2016-06-03 16:18:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:18:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:18:45 --> Utf8 Class Initialized
INFO - 2016-06-03 16:18:45 --> URI Class Initialized
INFO - 2016-06-03 16:18:45 --> Router Class Initialized
INFO - 2016-06-03 16:18:45 --> Output Class Initialized
INFO - 2016-06-03 16:18:45 --> Security Class Initialized
DEBUG - 2016-06-03 16:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:18:45 --> CSRF cookie sent
INFO - 2016-06-03 16:18:45 --> CSRF token verified
INFO - 2016-06-03 16:18:45 --> Input Class Initialized
INFO - 2016-06-03 16:18:45 --> Language Class Initialized
INFO - 2016-06-03 16:18:45 --> Loader Class Initialized
INFO - 2016-06-03 16:18:45 --> Helper loaded: form_helper
INFO - 2016-06-03 16:18:45 --> Database Driver Class Initialized
INFO - 2016-06-03 16:18:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:18:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:18:45 --> Email Class Initialized
INFO - 2016-06-03 16:18:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:18:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:18:45 --> Helper loaded: language_helper
INFO - 2016-06-03 16:18:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:18:45 --> Model Class Initialized
INFO - 2016-06-03 16:18:45 --> Helper loaded: date_helper
INFO - 2016-06-03 16:18:45 --> Controller Class Initialized
INFO - 2016-06-03 16:18:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:18:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:18:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:18:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:18:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:18:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:18:45 --> Model Class Initialized
INFO - 2016-06-03 16:18:45 --> Form Validation Class Initialized
INFO - 2016-06-03 16:18:45 --> Final output sent to browser
DEBUG - 2016-06-03 16:18:45 --> Total execution time: 0.0557
INFO - 2016-06-03 16:22:37 --> Config Class Initialized
INFO - 2016-06-03 16:22:37 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:22:37 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:22:37 --> Utf8 Class Initialized
INFO - 2016-06-03 16:22:37 --> URI Class Initialized
INFO - 2016-06-03 16:22:37 --> Router Class Initialized
INFO - 2016-06-03 16:22:37 --> Output Class Initialized
INFO - 2016-06-03 16:22:37 --> Security Class Initialized
DEBUG - 2016-06-03 16:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:22:37 --> CSRF cookie sent
INFO - 2016-06-03 16:22:37 --> CSRF token verified
INFO - 2016-06-03 16:22:37 --> Input Class Initialized
INFO - 2016-06-03 16:22:37 --> Language Class Initialized
INFO - 2016-06-03 16:22:37 --> Loader Class Initialized
INFO - 2016-06-03 16:22:37 --> Helper loaded: form_helper
INFO - 2016-06-03 16:22:37 --> Database Driver Class Initialized
INFO - 2016-06-03 16:22:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:22:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:22:37 --> Email Class Initialized
INFO - 2016-06-03 16:22:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:22:37 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:22:37 --> Helper loaded: language_helper
INFO - 2016-06-03 16:22:37 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:22:37 --> Model Class Initialized
INFO - 2016-06-03 16:22:37 --> Helper loaded: date_helper
INFO - 2016-06-03 16:22:37 --> Controller Class Initialized
INFO - 2016-06-03 16:22:37 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:22:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:22:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:22:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:22:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:22:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:22:37 --> Model Class Initialized
INFO - 2016-06-03 16:22:37 --> Form Validation Class Initialized
INFO - 2016-06-03 16:22:37 --> Final output sent to browser
DEBUG - 2016-06-03 16:22:37 --> Total execution time: 0.0497
INFO - 2016-06-03 16:22:42 --> Config Class Initialized
INFO - 2016-06-03 16:22:42 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:22:42 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:22:42 --> Utf8 Class Initialized
INFO - 2016-06-03 16:22:42 --> URI Class Initialized
INFO - 2016-06-03 16:22:42 --> Router Class Initialized
INFO - 2016-06-03 16:22:42 --> Output Class Initialized
INFO - 2016-06-03 16:22:42 --> Security Class Initialized
DEBUG - 2016-06-03 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:22:42 --> CSRF cookie sent
INFO - 2016-06-03 16:22:42 --> CSRF token verified
INFO - 2016-06-03 16:22:42 --> Input Class Initialized
INFO - 2016-06-03 16:22:42 --> Language Class Initialized
INFO - 2016-06-03 16:22:42 --> Loader Class Initialized
INFO - 2016-06-03 16:22:42 --> Helper loaded: form_helper
INFO - 2016-06-03 16:22:42 --> Database Driver Class Initialized
INFO - 2016-06-03 16:22:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:22:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:22:42 --> Email Class Initialized
INFO - 2016-06-03 16:22:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:22:42 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:22:42 --> Helper loaded: language_helper
INFO - 2016-06-03 16:22:42 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:22:42 --> Model Class Initialized
INFO - 2016-06-03 16:22:42 --> Helper loaded: date_helper
INFO - 2016-06-03 16:22:42 --> Controller Class Initialized
INFO - 2016-06-03 16:22:42 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:22:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:22:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:22:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:22:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:22:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:22:42 --> Model Class Initialized
INFO - 2016-06-03 16:22:42 --> Form Validation Class Initialized
INFO - 2016-06-03 16:22:42 --> Final output sent to browser
DEBUG - 2016-06-03 16:22:42 --> Total execution time: 0.0290
INFO - 2016-06-03 16:22:45 --> Config Class Initialized
INFO - 2016-06-03 16:22:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:22:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:22:45 --> Utf8 Class Initialized
INFO - 2016-06-03 16:22:45 --> URI Class Initialized
INFO - 2016-06-03 16:22:45 --> Router Class Initialized
INFO - 2016-06-03 16:22:45 --> Output Class Initialized
INFO - 2016-06-03 16:22:45 --> Security Class Initialized
DEBUG - 2016-06-03 16:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:22:45 --> CSRF cookie sent
INFO - 2016-06-03 16:22:45 --> CSRF token verified
INFO - 2016-06-03 16:22:45 --> Input Class Initialized
INFO - 2016-06-03 16:22:45 --> Language Class Initialized
INFO - 2016-06-03 16:22:45 --> Loader Class Initialized
INFO - 2016-06-03 16:22:45 --> Helper loaded: form_helper
INFO - 2016-06-03 16:22:45 --> Database Driver Class Initialized
INFO - 2016-06-03 16:22:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:22:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:22:45 --> Email Class Initialized
INFO - 2016-06-03 16:22:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:22:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:22:45 --> Helper loaded: language_helper
INFO - 2016-06-03 16:22:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:22:45 --> Model Class Initialized
INFO - 2016-06-03 16:22:45 --> Helper loaded: date_helper
INFO - 2016-06-03 16:22:45 --> Controller Class Initialized
INFO - 2016-06-03 16:22:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:22:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:22:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:22:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:22:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:22:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:22:45 --> Model Class Initialized
INFO - 2016-06-03 16:22:45 --> Form Validation Class Initialized
INFO - 2016-06-03 16:22:45 --> Final output sent to browser
DEBUG - 2016-06-03 16:22:45 --> Total execution time: 0.0627
INFO - 2016-06-03 16:25:47 --> Config Class Initialized
INFO - 2016-06-03 16:25:47 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:25:47 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:25:47 --> Utf8 Class Initialized
INFO - 2016-06-03 16:25:47 --> URI Class Initialized
INFO - 2016-06-03 16:25:47 --> Router Class Initialized
INFO - 2016-06-03 16:25:47 --> Output Class Initialized
INFO - 2016-06-03 16:25:47 --> Security Class Initialized
DEBUG - 2016-06-03 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:25:47 --> CSRF cookie sent
INFO - 2016-06-03 16:25:47 --> Input Class Initialized
INFO - 2016-06-03 16:25:47 --> Language Class Initialized
INFO - 2016-06-03 16:25:47 --> Loader Class Initialized
INFO - 2016-06-03 16:25:47 --> Helper loaded: form_helper
INFO - 2016-06-03 16:25:47 --> Database Driver Class Initialized
INFO - 2016-06-03 16:25:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:25:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:25:47 --> Email Class Initialized
INFO - 2016-06-03 16:25:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:25:47 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:25:47 --> Helper loaded: language_helper
INFO - 2016-06-03 16:25:47 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:25:47 --> Model Class Initialized
INFO - 2016-06-03 16:25:47 --> Helper loaded: date_helper
INFO - 2016-06-03 16:25:47 --> Controller Class Initialized
INFO - 2016-06-03 16:25:47 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:25:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:25:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:25:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:25:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:25:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:25:47 --> Model Class Initialized
INFO - 2016-06-03 16:25:47 --> Form Validation Class Initialized
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:25:47 --> Final output sent to browser
DEBUG - 2016-06-03 16:25:47 --> Total execution time: 0.0672
INFO - 2016-06-03 16:25:54 --> Config Class Initialized
INFO - 2016-06-03 16:25:54 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:25:54 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:25:54 --> Utf8 Class Initialized
INFO - 2016-06-03 16:25:54 --> URI Class Initialized
INFO - 2016-06-03 16:25:54 --> Router Class Initialized
INFO - 2016-06-03 16:25:54 --> Output Class Initialized
INFO - 2016-06-03 16:25:54 --> Security Class Initialized
DEBUG - 2016-06-03 16:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:25:54 --> CSRF cookie sent
INFO - 2016-06-03 16:25:54 --> CSRF token verified
INFO - 2016-06-03 16:25:54 --> Input Class Initialized
INFO - 2016-06-03 16:25:54 --> Language Class Initialized
INFO - 2016-06-03 16:25:54 --> Loader Class Initialized
INFO - 2016-06-03 16:25:54 --> Helper loaded: form_helper
INFO - 2016-06-03 16:25:54 --> Database Driver Class Initialized
INFO - 2016-06-03 16:25:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:25:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:25:54 --> Email Class Initialized
INFO - 2016-06-03 16:25:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:25:54 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:25:54 --> Helper loaded: language_helper
INFO - 2016-06-03 16:25:54 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:25:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:25:54 --> Model Class Initialized
INFO - 2016-06-03 16:25:54 --> Helper loaded: date_helper
INFO - 2016-06-03 16:25:54 --> Controller Class Initialized
INFO - 2016-06-03 16:25:54 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:25:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:25:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:25:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:25:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:25:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:25:54 --> Model Class Initialized
INFO - 2016-06-03 16:25:54 --> Form Validation Class Initialized
INFO - 2016-06-03 16:25:54 --> Final output sent to browser
DEBUG - 2016-06-03 16:25:54 --> Total execution time: 0.0607
INFO - 2016-06-03 16:28:22 --> Config Class Initialized
INFO - 2016-06-03 16:28:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:28:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:28:22 --> Utf8 Class Initialized
INFO - 2016-06-03 16:28:22 --> URI Class Initialized
INFO - 2016-06-03 16:28:22 --> Router Class Initialized
INFO - 2016-06-03 16:28:22 --> Output Class Initialized
INFO - 2016-06-03 16:28:22 --> Security Class Initialized
DEBUG - 2016-06-03 16:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:28:22 --> CSRF cookie sent
INFO - 2016-06-03 16:28:22 --> Input Class Initialized
INFO - 2016-06-03 16:28:22 --> Language Class Initialized
INFO - 2016-06-03 16:28:22 --> Loader Class Initialized
INFO - 2016-06-03 16:28:22 --> Helper loaded: form_helper
INFO - 2016-06-03 16:28:22 --> Database Driver Class Initialized
INFO - 2016-06-03 16:28:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:28:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:28:22 --> Email Class Initialized
INFO - 2016-06-03 16:28:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:28:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:28:22 --> Helper loaded: language_helper
INFO - 2016-06-03 16:28:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:28:22 --> Model Class Initialized
INFO - 2016-06-03 16:28:22 --> Helper loaded: date_helper
INFO - 2016-06-03 16:28:22 --> Controller Class Initialized
INFO - 2016-06-03 16:28:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:28:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:28:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:28:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:28:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:28:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:28:22 --> Model Class Initialized
INFO - 2016-06-03 16:28:22 --> Form Validation Class Initialized
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:28:22 --> Final output sent to browser
DEBUG - 2016-06-03 16:28:22 --> Total execution time: 0.0511
INFO - 2016-06-03 16:28:27 --> Config Class Initialized
INFO - 2016-06-03 16:28:27 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:28:27 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:28:27 --> Utf8 Class Initialized
INFO - 2016-06-03 16:28:27 --> URI Class Initialized
INFO - 2016-06-03 16:28:27 --> Router Class Initialized
INFO - 2016-06-03 16:28:27 --> Output Class Initialized
INFO - 2016-06-03 16:28:27 --> Security Class Initialized
DEBUG - 2016-06-03 16:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:28:27 --> CSRF cookie sent
INFO - 2016-06-03 16:28:27 --> CSRF token verified
INFO - 2016-06-03 16:28:27 --> Input Class Initialized
INFO - 2016-06-03 16:28:27 --> Language Class Initialized
INFO - 2016-06-03 16:28:27 --> Loader Class Initialized
INFO - 2016-06-03 16:28:27 --> Helper loaded: form_helper
INFO - 2016-06-03 16:28:27 --> Database Driver Class Initialized
INFO - 2016-06-03 16:28:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:28:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:28:27 --> Email Class Initialized
INFO - 2016-06-03 16:28:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:28:27 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:28:27 --> Helper loaded: language_helper
INFO - 2016-06-03 16:28:27 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:28:27 --> Model Class Initialized
INFO - 2016-06-03 16:28:27 --> Helper loaded: date_helper
INFO - 2016-06-03 16:28:27 --> Controller Class Initialized
INFO - 2016-06-03 16:28:27 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:28:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:28:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:28:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:28:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:28:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:28:27 --> Model Class Initialized
INFO - 2016-06-03 16:28:27 --> Form Validation Class Initialized
INFO - 2016-06-03 16:28:27 --> Final output sent to browser
DEBUG - 2016-06-03 16:28:27 --> Total execution time: 0.0749
INFO - 2016-06-03 16:37:35 --> Config Class Initialized
INFO - 2016-06-03 16:37:35 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:37:35 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:37:35 --> Utf8 Class Initialized
INFO - 2016-06-03 16:37:35 --> URI Class Initialized
INFO - 2016-06-03 16:37:35 --> Router Class Initialized
INFO - 2016-06-03 16:37:35 --> Output Class Initialized
INFO - 2016-06-03 16:37:35 --> Security Class Initialized
DEBUG - 2016-06-03 16:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:37:35 --> CSRF cookie sent
INFO - 2016-06-03 16:37:35 --> Input Class Initialized
INFO - 2016-06-03 16:37:35 --> Language Class Initialized
INFO - 2016-06-03 16:37:35 --> Loader Class Initialized
INFO - 2016-06-03 16:37:35 --> Helper loaded: form_helper
INFO - 2016-06-03 16:37:35 --> Database Driver Class Initialized
INFO - 2016-06-03 16:37:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:37:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:37:35 --> Email Class Initialized
INFO - 2016-06-03 16:37:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:37:35 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:37:35 --> Helper loaded: language_helper
INFO - 2016-06-03 16:37:35 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:37:35 --> Model Class Initialized
INFO - 2016-06-03 16:37:35 --> Helper loaded: date_helper
INFO - 2016-06-03 16:37:35 --> Controller Class Initialized
INFO - 2016-06-03 16:37:35 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:37:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:37:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:37:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:37:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:37:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:37:35 --> Model Class Initialized
INFO - 2016-06-03 16:37:35 --> Form Validation Class Initialized
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:37:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:37:35 --> Final output sent to browser
DEBUG - 2016-06-03 16:37:35 --> Total execution time: 0.0497
INFO - 2016-06-03 16:37:41 --> Config Class Initialized
INFO - 2016-06-03 16:37:41 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:37:41 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:37:41 --> Utf8 Class Initialized
INFO - 2016-06-03 16:37:41 --> URI Class Initialized
INFO - 2016-06-03 16:37:41 --> Router Class Initialized
INFO - 2016-06-03 16:37:41 --> Output Class Initialized
INFO - 2016-06-03 16:37:41 --> Security Class Initialized
DEBUG - 2016-06-03 16:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:37:41 --> CSRF cookie sent
INFO - 2016-06-03 16:37:41 --> CSRF token verified
INFO - 2016-06-03 16:37:41 --> Input Class Initialized
INFO - 2016-06-03 16:37:41 --> Language Class Initialized
INFO - 2016-06-03 16:37:41 --> Loader Class Initialized
INFO - 2016-06-03 16:37:41 --> Helper loaded: form_helper
INFO - 2016-06-03 16:37:41 --> Database Driver Class Initialized
INFO - 2016-06-03 16:37:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:37:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:37:41 --> Email Class Initialized
INFO - 2016-06-03 16:37:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:37:41 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:37:41 --> Helper loaded: language_helper
INFO - 2016-06-03 16:37:41 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:37:41 --> Model Class Initialized
INFO - 2016-06-03 16:37:41 --> Helper loaded: date_helper
INFO - 2016-06-03 16:37:41 --> Controller Class Initialized
INFO - 2016-06-03 16:37:41 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:37:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:37:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:37:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:37:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:37:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:37:41 --> Model Class Initialized
INFO - 2016-06-03 16:37:41 --> Form Validation Class Initialized
INFO - 2016-06-03 16:37:41 --> Final output sent to browser
DEBUG - 2016-06-03 16:37:41 --> Total execution time: 0.1947
INFO - 2016-06-03 16:38:23 --> Config Class Initialized
INFO - 2016-06-03 16:38:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:38:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:38:23 --> Utf8 Class Initialized
INFO - 2016-06-03 16:38:23 --> URI Class Initialized
INFO - 2016-06-03 16:38:23 --> Router Class Initialized
INFO - 2016-06-03 16:38:23 --> Output Class Initialized
INFO - 2016-06-03 16:38:23 --> Security Class Initialized
DEBUG - 2016-06-03 16:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:38:23 --> CSRF cookie sent
INFO - 2016-06-03 16:38:23 --> Input Class Initialized
INFO - 2016-06-03 16:38:23 --> Language Class Initialized
INFO - 2016-06-03 16:38:23 --> Loader Class Initialized
INFO - 2016-06-03 16:38:23 --> Helper loaded: form_helper
INFO - 2016-06-03 16:38:23 --> Database Driver Class Initialized
INFO - 2016-06-03 16:38:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:38:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:38:23 --> Email Class Initialized
INFO - 2016-06-03 16:38:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:38:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:38:23 --> Helper loaded: language_helper
INFO - 2016-06-03 16:38:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:38:23 --> Model Class Initialized
INFO - 2016-06-03 16:38:23 --> Helper loaded: date_helper
INFO - 2016-06-03 16:38:23 --> Controller Class Initialized
INFO - 2016-06-03 16:38:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:38:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:38:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:38:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:38:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:38:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:38:23 --> Model Class Initialized
INFO - 2016-06-03 16:38:23 --> Form Validation Class Initialized
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:38:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:38:23 --> Final output sent to browser
DEBUG - 2016-06-03 16:38:23 --> Total execution time: 0.0614
INFO - 2016-06-03 16:38:28 --> Config Class Initialized
INFO - 2016-06-03 16:38:28 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:38:28 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:38:28 --> Utf8 Class Initialized
INFO - 2016-06-03 16:38:28 --> URI Class Initialized
INFO - 2016-06-03 16:38:28 --> Router Class Initialized
INFO - 2016-06-03 16:38:28 --> Output Class Initialized
INFO - 2016-06-03 16:38:28 --> Security Class Initialized
DEBUG - 2016-06-03 16:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:38:28 --> CSRF cookie sent
INFO - 2016-06-03 16:38:28 --> CSRF token verified
INFO - 2016-06-03 16:38:28 --> Input Class Initialized
INFO - 2016-06-03 16:38:28 --> Language Class Initialized
INFO - 2016-06-03 16:38:28 --> Loader Class Initialized
INFO - 2016-06-03 16:38:28 --> Helper loaded: form_helper
INFO - 2016-06-03 16:38:28 --> Database Driver Class Initialized
INFO - 2016-06-03 16:38:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:38:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:38:28 --> Email Class Initialized
INFO - 2016-06-03 16:38:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:38:28 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:38:28 --> Helper loaded: language_helper
INFO - 2016-06-03 16:38:28 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:38:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:38:28 --> Model Class Initialized
INFO - 2016-06-03 16:38:28 --> Helper loaded: date_helper
INFO - 2016-06-03 16:38:28 --> Controller Class Initialized
INFO - 2016-06-03 16:38:28 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:38:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:38:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:38:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:38:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:38:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:38:28 --> Model Class Initialized
INFO - 2016-06-03 16:38:28 --> Form Validation Class Initialized
INFO - 2016-06-03 16:38:28 --> Final output sent to browser
DEBUG - 2016-06-03 16:38:28 --> Total execution time: 0.0598
INFO - 2016-06-03 16:38:50 --> Config Class Initialized
INFO - 2016-06-03 16:38:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:38:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:38:50 --> Utf8 Class Initialized
INFO - 2016-06-03 16:38:50 --> URI Class Initialized
INFO - 2016-06-03 16:38:50 --> Router Class Initialized
INFO - 2016-06-03 16:38:50 --> Output Class Initialized
INFO - 2016-06-03 16:38:50 --> Security Class Initialized
DEBUG - 2016-06-03 16:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:38:50 --> CSRF cookie sent
INFO - 2016-06-03 16:38:50 --> Input Class Initialized
INFO - 2016-06-03 16:38:50 --> Language Class Initialized
INFO - 2016-06-03 16:38:50 --> Loader Class Initialized
INFO - 2016-06-03 16:38:50 --> Helper loaded: form_helper
INFO - 2016-06-03 16:38:50 --> Database Driver Class Initialized
INFO - 2016-06-03 16:38:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:38:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:38:50 --> Email Class Initialized
INFO - 2016-06-03 16:38:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:38:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:38:50 --> Helper loaded: language_helper
INFO - 2016-06-03 16:38:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:38:50 --> Model Class Initialized
INFO - 2016-06-03 16:38:50 --> Helper loaded: date_helper
INFO - 2016-06-03 16:38:50 --> Controller Class Initialized
INFO - 2016-06-03 16:38:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:38:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:38:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:38:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:38:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:38:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:38:50 --> Model Class Initialized
INFO - 2016-06-03 16:38:50 --> Form Validation Class Initialized
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:38:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:38:50 --> Final output sent to browser
DEBUG - 2016-06-03 16:38:50 --> Total execution time: 0.0996
INFO - 2016-06-03 16:38:54 --> Config Class Initialized
INFO - 2016-06-03 16:38:54 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:38:54 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:38:54 --> Utf8 Class Initialized
INFO - 2016-06-03 16:38:54 --> URI Class Initialized
INFO - 2016-06-03 16:38:54 --> Router Class Initialized
INFO - 2016-06-03 16:38:54 --> Output Class Initialized
INFO - 2016-06-03 16:38:54 --> Security Class Initialized
DEBUG - 2016-06-03 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:38:54 --> CSRF cookie sent
INFO - 2016-06-03 16:38:54 --> CSRF token verified
INFO - 2016-06-03 16:38:54 --> Input Class Initialized
INFO - 2016-06-03 16:38:54 --> Language Class Initialized
INFO - 2016-06-03 16:38:54 --> Loader Class Initialized
INFO - 2016-06-03 16:38:54 --> Helper loaded: form_helper
INFO - 2016-06-03 16:38:54 --> Database Driver Class Initialized
INFO - 2016-06-03 16:38:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:38:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:38:54 --> Email Class Initialized
INFO - 2016-06-03 16:38:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:38:54 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:38:54 --> Helper loaded: language_helper
INFO - 2016-06-03 16:38:54 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:38:54 --> Model Class Initialized
INFO - 2016-06-03 16:38:54 --> Helper loaded: date_helper
INFO - 2016-06-03 16:38:54 --> Controller Class Initialized
INFO - 2016-06-03 16:38:54 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:38:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:38:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:38:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:38:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:38:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:38:54 --> Model Class Initialized
INFO - 2016-06-03 16:38:54 --> Form Validation Class Initialized
INFO - 2016-06-03 16:38:54 --> Final output sent to browser
DEBUG - 2016-06-03 16:38:54 --> Total execution time: 0.0693
INFO - 2016-06-03 16:41:36 --> Config Class Initialized
INFO - 2016-06-03 16:41:36 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:41:36 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:41:36 --> Utf8 Class Initialized
INFO - 2016-06-03 16:41:36 --> URI Class Initialized
INFO - 2016-06-03 16:41:36 --> Router Class Initialized
INFO - 2016-06-03 16:41:36 --> Output Class Initialized
INFO - 2016-06-03 16:41:36 --> Security Class Initialized
DEBUG - 2016-06-03 16:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:41:36 --> CSRF cookie sent
INFO - 2016-06-03 16:41:36 --> Input Class Initialized
INFO - 2016-06-03 16:41:36 --> Language Class Initialized
INFO - 2016-06-03 16:41:36 --> Loader Class Initialized
INFO - 2016-06-03 16:41:36 --> Helper loaded: form_helper
INFO - 2016-06-03 16:41:36 --> Database Driver Class Initialized
INFO - 2016-06-03 16:41:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:41:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:41:36 --> Email Class Initialized
INFO - 2016-06-03 16:41:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:41:36 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:41:36 --> Helper loaded: language_helper
INFO - 2016-06-03 16:41:36 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:41:36 --> Model Class Initialized
INFO - 2016-06-03 16:41:36 --> Helper loaded: date_helper
INFO - 2016-06-03 16:41:36 --> Controller Class Initialized
INFO - 2016-06-03 16:41:36 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:41:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:41:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:41:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:41:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:41:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:41:36 --> Model Class Initialized
INFO - 2016-06-03 16:41:36 --> Form Validation Class Initialized
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:41:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:41:36 --> Final output sent to browser
DEBUG - 2016-06-03 16:41:36 --> Total execution time: 0.0462
INFO - 2016-06-03 16:41:40 --> Config Class Initialized
INFO - 2016-06-03 16:41:40 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:41:40 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:41:40 --> Utf8 Class Initialized
INFO - 2016-06-03 16:41:40 --> URI Class Initialized
INFO - 2016-06-03 16:41:40 --> Router Class Initialized
INFO - 2016-06-03 16:41:40 --> Output Class Initialized
INFO - 2016-06-03 16:41:40 --> Security Class Initialized
DEBUG - 2016-06-03 16:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:41:40 --> CSRF cookie sent
INFO - 2016-06-03 16:41:40 --> CSRF token verified
INFO - 2016-06-03 16:41:40 --> Input Class Initialized
INFO - 2016-06-03 16:41:40 --> Language Class Initialized
INFO - 2016-06-03 16:41:40 --> Loader Class Initialized
INFO - 2016-06-03 16:41:40 --> Helper loaded: form_helper
INFO - 2016-06-03 16:41:40 --> Database Driver Class Initialized
INFO - 2016-06-03 16:41:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:41:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:41:40 --> Email Class Initialized
INFO - 2016-06-03 16:41:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:41:40 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:41:40 --> Helper loaded: language_helper
INFO - 2016-06-03 16:41:40 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:41:40 --> Model Class Initialized
INFO - 2016-06-03 16:41:40 --> Helper loaded: date_helper
INFO - 2016-06-03 16:41:40 --> Controller Class Initialized
INFO - 2016-06-03 16:41:40 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:41:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:41:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:41:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:41:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:41:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:41:40 --> Model Class Initialized
INFO - 2016-06-03 16:41:40 --> Form Validation Class Initialized
INFO - 2016-06-03 16:41:40 --> Final output sent to browser
DEBUG - 2016-06-03 16:41:40 --> Total execution time: 0.0377
INFO - 2016-06-03 16:43:18 --> Config Class Initialized
INFO - 2016-06-03 16:43:18 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:43:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:43:18 --> Utf8 Class Initialized
INFO - 2016-06-03 16:43:18 --> URI Class Initialized
INFO - 2016-06-03 16:43:18 --> Router Class Initialized
INFO - 2016-06-03 16:43:18 --> Output Class Initialized
INFO - 2016-06-03 16:43:18 --> Security Class Initialized
DEBUG - 2016-06-03 16:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:43:18 --> CSRF cookie sent
INFO - 2016-06-03 16:43:18 --> Input Class Initialized
INFO - 2016-06-03 16:43:18 --> Language Class Initialized
INFO - 2016-06-03 16:43:18 --> Loader Class Initialized
INFO - 2016-06-03 16:43:18 --> Helper loaded: form_helper
INFO - 2016-06-03 16:43:18 --> Database Driver Class Initialized
INFO - 2016-06-03 16:43:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:43:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:43:18 --> Email Class Initialized
INFO - 2016-06-03 16:43:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:43:18 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:43:18 --> Helper loaded: language_helper
INFO - 2016-06-03 16:43:18 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:43:18 --> Model Class Initialized
INFO - 2016-06-03 16:43:18 --> Helper loaded: date_helper
INFO - 2016-06-03 16:43:18 --> Controller Class Initialized
INFO - 2016-06-03 16:43:18 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:43:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:43:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:43:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:43:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:43:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:43:18 --> Model Class Initialized
INFO - 2016-06-03 16:43:18 --> Form Validation Class Initialized
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:43:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:43:18 --> Final output sent to browser
DEBUG - 2016-06-03 16:43:18 --> Total execution time: 0.0815
INFO - 2016-06-03 16:43:22 --> Config Class Initialized
INFO - 2016-06-03 16:43:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:43:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:43:22 --> Utf8 Class Initialized
INFO - 2016-06-03 16:43:22 --> URI Class Initialized
INFO - 2016-06-03 16:43:22 --> Router Class Initialized
INFO - 2016-06-03 16:43:22 --> Output Class Initialized
INFO - 2016-06-03 16:43:22 --> Security Class Initialized
DEBUG - 2016-06-03 16:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:43:22 --> CSRF cookie sent
INFO - 2016-06-03 16:43:22 --> CSRF token verified
INFO - 2016-06-03 16:43:22 --> Input Class Initialized
INFO - 2016-06-03 16:43:22 --> Language Class Initialized
INFO - 2016-06-03 16:43:22 --> Loader Class Initialized
INFO - 2016-06-03 16:43:22 --> Helper loaded: form_helper
INFO - 2016-06-03 16:43:22 --> Database Driver Class Initialized
INFO - 2016-06-03 16:43:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:43:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:43:22 --> Email Class Initialized
INFO - 2016-06-03 16:43:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:43:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:43:22 --> Helper loaded: language_helper
INFO - 2016-06-03 16:43:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:43:22 --> Model Class Initialized
INFO - 2016-06-03 16:43:22 --> Helper loaded: date_helper
INFO - 2016-06-03 16:43:22 --> Controller Class Initialized
INFO - 2016-06-03 16:43:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:43:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:43:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:43:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:43:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:43:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:43:22 --> Model Class Initialized
INFO - 2016-06-03 16:43:22 --> Form Validation Class Initialized
INFO - 2016-06-03 16:43:22 --> Final output sent to browser
DEBUG - 2016-06-03 16:43:22 --> Total execution time: 0.0390
INFO - 2016-06-03 16:48:32 --> Config Class Initialized
INFO - 2016-06-03 16:48:32 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:48:32 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:48:32 --> Utf8 Class Initialized
INFO - 2016-06-03 16:48:32 --> URI Class Initialized
INFO - 2016-06-03 16:48:32 --> Router Class Initialized
INFO - 2016-06-03 16:48:32 --> Output Class Initialized
INFO - 2016-06-03 16:48:32 --> Security Class Initialized
DEBUG - 2016-06-03 16:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:48:32 --> CSRF cookie sent
INFO - 2016-06-03 16:48:32 --> Input Class Initialized
INFO - 2016-06-03 16:48:32 --> Language Class Initialized
INFO - 2016-06-03 16:48:32 --> Loader Class Initialized
INFO - 2016-06-03 16:48:32 --> Helper loaded: form_helper
INFO - 2016-06-03 16:48:32 --> Database Driver Class Initialized
INFO - 2016-06-03 16:48:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:48:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:48:32 --> Email Class Initialized
INFO - 2016-06-03 16:48:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:48:32 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:48:32 --> Helper loaded: language_helper
INFO - 2016-06-03 16:48:32 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:48:32 --> Model Class Initialized
INFO - 2016-06-03 16:48:32 --> Helper loaded: date_helper
INFO - 2016-06-03 16:48:32 --> Controller Class Initialized
INFO - 2016-06-03 16:48:32 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:48:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:48:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:48:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:48:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:48:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:48:32 --> Model Class Initialized
INFO - 2016-06-03 16:48:32 --> Form Validation Class Initialized
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:48:32 --> Final output sent to browser
DEBUG - 2016-06-03 16:48:32 --> Total execution time: 0.0576
INFO - 2016-06-03 16:48:36 --> Config Class Initialized
INFO - 2016-06-03 16:48:36 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:48:36 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:48:36 --> Utf8 Class Initialized
INFO - 2016-06-03 16:48:36 --> URI Class Initialized
INFO - 2016-06-03 16:48:36 --> Router Class Initialized
INFO - 2016-06-03 16:48:36 --> Output Class Initialized
INFO - 2016-06-03 16:48:36 --> Security Class Initialized
DEBUG - 2016-06-03 16:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:48:36 --> CSRF cookie sent
INFO - 2016-06-03 16:48:36 --> CSRF token verified
INFO - 2016-06-03 16:48:36 --> Input Class Initialized
INFO - 2016-06-03 16:48:36 --> Language Class Initialized
INFO - 2016-06-03 16:48:36 --> Loader Class Initialized
INFO - 2016-06-03 16:48:36 --> Helper loaded: form_helper
INFO - 2016-06-03 16:48:36 --> Database Driver Class Initialized
INFO - 2016-06-03 16:48:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:48:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:48:36 --> Email Class Initialized
INFO - 2016-06-03 16:48:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:48:36 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:48:36 --> Helper loaded: language_helper
INFO - 2016-06-03 16:48:36 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:48:36 --> Model Class Initialized
INFO - 2016-06-03 16:48:36 --> Helper loaded: date_helper
INFO - 2016-06-03 16:48:36 --> Controller Class Initialized
INFO - 2016-06-03 16:48:36 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:48:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:48:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:48:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:48:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:48:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:48:36 --> Model Class Initialized
INFO - 2016-06-03 16:48:36 --> Form Validation Class Initialized
INFO - 2016-06-03 16:48:36 --> Final output sent to browser
DEBUG - 2016-06-03 16:48:36 --> Total execution time: 0.0351
INFO - 2016-06-03 16:55:29 --> Config Class Initialized
INFO - 2016-06-03 16:55:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:55:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:55:29 --> Utf8 Class Initialized
INFO - 2016-06-03 16:55:29 --> URI Class Initialized
INFO - 2016-06-03 16:55:29 --> Router Class Initialized
INFO - 2016-06-03 16:55:29 --> Output Class Initialized
INFO - 2016-06-03 16:55:29 --> Security Class Initialized
DEBUG - 2016-06-03 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:55:29 --> CSRF cookie sent
INFO - 2016-06-03 16:55:29 --> Input Class Initialized
INFO - 2016-06-03 16:55:29 --> Language Class Initialized
INFO - 2016-06-03 16:55:29 --> Loader Class Initialized
INFO - 2016-06-03 16:55:29 --> Helper loaded: form_helper
INFO - 2016-06-03 16:55:29 --> Database Driver Class Initialized
INFO - 2016-06-03 16:55:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:55:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:55:29 --> Email Class Initialized
INFO - 2016-06-03 16:55:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:55:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:55:29 --> Helper loaded: language_helper
INFO - 2016-06-03 16:55:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:55:29 --> Model Class Initialized
INFO - 2016-06-03 16:55:29 --> Helper loaded: date_helper
INFO - 2016-06-03 16:55:29 --> Controller Class Initialized
INFO - 2016-06-03 16:55:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:55:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:55:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:55:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:55:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:55:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:55:29 --> Model Class Initialized
INFO - 2016-06-03 16:55:29 --> Form Validation Class Initialized
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:55:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:55:29 --> Final output sent to browser
DEBUG - 2016-06-03 16:55:29 --> Total execution time: 0.0523
INFO - 2016-06-03 16:57:14 --> Config Class Initialized
INFO - 2016-06-03 16:57:14 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:57:14 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:57:14 --> Utf8 Class Initialized
INFO - 2016-06-03 16:57:14 --> URI Class Initialized
INFO - 2016-06-03 16:57:14 --> Router Class Initialized
INFO - 2016-06-03 16:57:14 --> Output Class Initialized
INFO - 2016-06-03 16:57:14 --> Security Class Initialized
DEBUG - 2016-06-03 16:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:57:14 --> CSRF cookie sent
INFO - 2016-06-03 16:57:14 --> Input Class Initialized
INFO - 2016-06-03 16:57:14 --> Language Class Initialized
INFO - 2016-06-03 16:57:14 --> Loader Class Initialized
INFO - 2016-06-03 16:57:14 --> Helper loaded: form_helper
INFO - 2016-06-03 16:57:14 --> Database Driver Class Initialized
INFO - 2016-06-03 16:57:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:57:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:57:14 --> Email Class Initialized
INFO - 2016-06-03 16:57:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:57:14 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:57:14 --> Helper loaded: language_helper
INFO - 2016-06-03 16:57:14 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:57:14 --> Model Class Initialized
INFO - 2016-06-03 16:57:14 --> Helper loaded: date_helper
INFO - 2016-06-03 16:57:14 --> Controller Class Initialized
INFO - 2016-06-03 16:57:14 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:57:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:57:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:57:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:57:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:57:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:57:14 --> Model Class Initialized
INFO - 2016-06-03 16:57:14 --> Form Validation Class Initialized
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:57:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:57:14 --> Final output sent to browser
DEBUG - 2016-06-03 16:57:14 --> Total execution time: 0.0517
INFO - 2016-06-03 16:57:46 --> Config Class Initialized
INFO - 2016-06-03 16:57:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:57:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:57:46 --> Utf8 Class Initialized
INFO - 2016-06-03 16:57:46 --> URI Class Initialized
INFO - 2016-06-03 16:57:46 --> Router Class Initialized
INFO - 2016-06-03 16:57:46 --> Output Class Initialized
INFO - 2016-06-03 16:57:46 --> Security Class Initialized
DEBUG - 2016-06-03 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:57:46 --> CSRF cookie sent
INFO - 2016-06-03 16:57:46 --> Input Class Initialized
INFO - 2016-06-03 16:57:46 --> Language Class Initialized
INFO - 2016-06-03 16:57:46 --> Loader Class Initialized
INFO - 2016-06-03 16:57:46 --> Helper loaded: form_helper
INFO - 2016-06-03 16:57:46 --> Database Driver Class Initialized
INFO - 2016-06-03 16:57:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:57:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:57:46 --> Email Class Initialized
INFO - 2016-06-03 16:57:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:57:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:57:46 --> Helper loaded: language_helper
INFO - 2016-06-03 16:57:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:57:46 --> Model Class Initialized
INFO - 2016-06-03 16:57:46 --> Helper loaded: date_helper
INFO - 2016-06-03 16:57:46 --> Controller Class Initialized
INFO - 2016-06-03 16:57:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:57:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:57:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:57:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:57:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:57:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:57:46 --> Model Class Initialized
INFO - 2016-06-03 16:57:46 --> Form Validation Class Initialized
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:57:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:57:46 --> Final output sent to browser
DEBUG - 2016-06-03 16:57:46 --> Total execution time: 0.0824
INFO - 2016-06-03 16:57:51 --> Config Class Initialized
INFO - 2016-06-03 16:57:51 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:57:51 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:57:51 --> Utf8 Class Initialized
INFO - 2016-06-03 16:57:51 --> URI Class Initialized
INFO - 2016-06-03 16:57:51 --> Router Class Initialized
INFO - 2016-06-03 16:57:51 --> Output Class Initialized
INFO - 2016-06-03 16:57:51 --> Security Class Initialized
DEBUG - 2016-06-03 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:57:51 --> CSRF cookie sent
INFO - 2016-06-03 16:57:51 --> CSRF token verified
INFO - 2016-06-03 16:57:51 --> Input Class Initialized
INFO - 2016-06-03 16:57:51 --> Language Class Initialized
INFO - 2016-06-03 16:57:51 --> Loader Class Initialized
INFO - 2016-06-03 16:57:51 --> Helper loaded: form_helper
INFO - 2016-06-03 16:57:51 --> Database Driver Class Initialized
INFO - 2016-06-03 16:57:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:57:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:57:51 --> Email Class Initialized
INFO - 2016-06-03 16:57:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:57:51 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:57:51 --> Helper loaded: language_helper
INFO - 2016-06-03 16:57:51 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:57:51 --> Model Class Initialized
INFO - 2016-06-03 16:57:51 --> Helper loaded: date_helper
INFO - 2016-06-03 16:57:51 --> Controller Class Initialized
INFO - 2016-06-03 16:57:51 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:57:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:57:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:57:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:57:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:57:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:57:51 --> Model Class Initialized
INFO - 2016-06-03 16:57:51 --> Form Validation Class Initialized
INFO - 2016-06-03 16:57:51 --> Final output sent to browser
DEBUG - 2016-06-03 16:57:51 --> Total execution time: 0.0315
INFO - 2016-06-03 16:58:22 --> Config Class Initialized
INFO - 2016-06-03 16:58:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:58:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:58:22 --> Utf8 Class Initialized
INFO - 2016-06-03 16:58:22 --> URI Class Initialized
INFO - 2016-06-03 16:58:22 --> Router Class Initialized
INFO - 2016-06-03 16:58:22 --> Output Class Initialized
INFO - 2016-06-03 16:58:22 --> Security Class Initialized
DEBUG - 2016-06-03 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:58:22 --> CSRF cookie sent
INFO - 2016-06-03 16:58:22 --> Input Class Initialized
INFO - 2016-06-03 16:58:22 --> Language Class Initialized
INFO - 2016-06-03 16:58:22 --> Loader Class Initialized
INFO - 2016-06-03 16:58:22 --> Helper loaded: form_helper
INFO - 2016-06-03 16:58:22 --> Database Driver Class Initialized
INFO - 2016-06-03 16:58:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:58:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:58:22 --> Email Class Initialized
INFO - 2016-06-03 16:58:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:58:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:58:22 --> Helper loaded: language_helper
INFO - 2016-06-03 16:58:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:58:22 --> Model Class Initialized
INFO - 2016-06-03 16:58:22 --> Helper loaded: date_helper
INFO - 2016-06-03 16:58:22 --> Controller Class Initialized
INFO - 2016-06-03 16:58:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:58:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:58:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:58:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:58:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:58:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:58:22 --> Model Class Initialized
INFO - 2016-06-03 16:58:22 --> Form Validation Class Initialized
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:58:22 --> Final output sent to browser
DEBUG - 2016-06-03 16:58:22 --> Total execution time: 0.0555
INFO - 2016-06-03 16:58:26 --> Config Class Initialized
INFO - 2016-06-03 16:58:26 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:58:26 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:58:26 --> Utf8 Class Initialized
INFO - 2016-06-03 16:58:26 --> URI Class Initialized
INFO - 2016-06-03 16:58:26 --> Router Class Initialized
INFO - 2016-06-03 16:58:26 --> Output Class Initialized
INFO - 2016-06-03 16:58:26 --> Security Class Initialized
DEBUG - 2016-06-03 16:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:58:26 --> CSRF cookie sent
INFO - 2016-06-03 16:58:26 --> CSRF token verified
INFO - 2016-06-03 16:58:26 --> Input Class Initialized
INFO - 2016-06-03 16:58:26 --> Language Class Initialized
INFO - 2016-06-03 16:58:26 --> Loader Class Initialized
INFO - 2016-06-03 16:58:26 --> Helper loaded: form_helper
INFO - 2016-06-03 16:58:26 --> Database Driver Class Initialized
INFO - 2016-06-03 16:58:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:58:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:58:26 --> Email Class Initialized
INFO - 2016-06-03 16:58:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:58:26 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:58:26 --> Helper loaded: language_helper
INFO - 2016-06-03 16:58:26 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:58:26 --> Model Class Initialized
INFO - 2016-06-03 16:58:26 --> Helper loaded: date_helper
INFO - 2016-06-03 16:58:26 --> Controller Class Initialized
INFO - 2016-06-03 16:58:26 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:58:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:58:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:58:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:58:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:58:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:58:26 --> Model Class Initialized
INFO - 2016-06-03 16:58:26 --> Form Validation Class Initialized
INFO - 2016-06-03 16:58:26 --> Final output sent to browser
DEBUG - 2016-06-03 16:58:26 --> Total execution time: 0.0496
INFO - 2016-06-03 16:59:29 --> Config Class Initialized
INFO - 2016-06-03 16:59:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:59:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:59:29 --> Utf8 Class Initialized
INFO - 2016-06-03 16:59:29 --> URI Class Initialized
INFO - 2016-06-03 16:59:29 --> Router Class Initialized
INFO - 2016-06-03 16:59:29 --> Output Class Initialized
INFO - 2016-06-03 16:59:29 --> Security Class Initialized
DEBUG - 2016-06-03 16:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:59:29 --> CSRF cookie sent
INFO - 2016-06-03 16:59:29 --> Input Class Initialized
INFO - 2016-06-03 16:59:29 --> Language Class Initialized
INFO - 2016-06-03 16:59:29 --> Loader Class Initialized
INFO - 2016-06-03 16:59:29 --> Helper loaded: form_helper
INFO - 2016-06-03 16:59:29 --> Database Driver Class Initialized
INFO - 2016-06-03 16:59:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:59:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:59:29 --> Email Class Initialized
INFO - 2016-06-03 16:59:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:59:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:59:29 --> Helper loaded: language_helper
INFO - 2016-06-03 16:59:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:59:29 --> Model Class Initialized
INFO - 2016-06-03 16:59:29 --> Helper loaded: date_helper
INFO - 2016-06-03 16:59:29 --> Controller Class Initialized
INFO - 2016-06-03 16:59:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:59:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:59:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:59:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:59:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:59:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:59:29 --> Model Class Initialized
INFO - 2016-06-03 16:59:29 --> Form Validation Class Initialized
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 16:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 16:59:29 --> Final output sent to browser
DEBUG - 2016-06-03 16:59:29 --> Total execution time: 0.0587
INFO - 2016-06-03 16:59:34 --> Config Class Initialized
INFO - 2016-06-03 16:59:34 --> Hooks Class Initialized
DEBUG - 2016-06-03 16:59:34 --> UTF-8 Support Enabled
INFO - 2016-06-03 16:59:34 --> Utf8 Class Initialized
INFO - 2016-06-03 16:59:34 --> URI Class Initialized
INFO - 2016-06-03 16:59:34 --> Router Class Initialized
INFO - 2016-06-03 16:59:34 --> Output Class Initialized
INFO - 2016-06-03 16:59:34 --> Security Class Initialized
DEBUG - 2016-06-03 16:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 16:59:34 --> CSRF cookie sent
INFO - 2016-06-03 16:59:34 --> CSRF token verified
INFO - 2016-06-03 16:59:34 --> Input Class Initialized
INFO - 2016-06-03 16:59:34 --> Language Class Initialized
INFO - 2016-06-03 16:59:34 --> Loader Class Initialized
INFO - 2016-06-03 16:59:34 --> Helper loaded: form_helper
INFO - 2016-06-03 16:59:34 --> Database Driver Class Initialized
INFO - 2016-06-03 16:59:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 16:59:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 16:59:34 --> Email Class Initialized
INFO - 2016-06-03 16:59:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 16:59:34 --> Helper loaded: cookie_helper
INFO - 2016-06-03 16:59:34 --> Helper loaded: language_helper
INFO - 2016-06-03 16:59:34 --> Helper loaded: url_helper
DEBUG - 2016-06-03 16:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 16:59:34 --> Model Class Initialized
INFO - 2016-06-03 16:59:34 --> Helper loaded: date_helper
INFO - 2016-06-03 16:59:34 --> Controller Class Initialized
INFO - 2016-06-03 16:59:34 --> Helper loaded: languages_helper
INFO - 2016-06-03 16:59:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 16:59:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 16:59:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 16:59:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 16:59:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 16:59:34 --> Model Class Initialized
INFO - 2016-06-03 16:59:34 --> Form Validation Class Initialized
INFO - 2016-06-03 16:59:34 --> Final output sent to browser
DEBUG - 2016-06-03 16:59:34 --> Total execution time: 0.0645
INFO - 2016-06-03 17:00:07 --> Config Class Initialized
INFO - 2016-06-03 17:00:07 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:00:07 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:00:07 --> Utf8 Class Initialized
INFO - 2016-06-03 17:00:07 --> URI Class Initialized
INFO - 2016-06-03 17:00:07 --> Router Class Initialized
INFO - 2016-06-03 17:00:07 --> Output Class Initialized
INFO - 2016-06-03 17:00:07 --> Security Class Initialized
DEBUG - 2016-06-03 17:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:00:07 --> CSRF cookie sent
INFO - 2016-06-03 17:00:07 --> Input Class Initialized
INFO - 2016-06-03 17:00:07 --> Language Class Initialized
INFO - 2016-06-03 17:00:07 --> Loader Class Initialized
INFO - 2016-06-03 17:00:07 --> Helper loaded: form_helper
INFO - 2016-06-03 17:00:07 --> Database Driver Class Initialized
INFO - 2016-06-03 17:00:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:00:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:00:07 --> Email Class Initialized
INFO - 2016-06-03 17:00:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:00:07 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:00:07 --> Helper loaded: language_helper
INFO - 2016-06-03 17:00:07 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:00:07 --> Model Class Initialized
INFO - 2016-06-03 17:00:07 --> Helper loaded: date_helper
INFO - 2016-06-03 17:00:07 --> Controller Class Initialized
INFO - 2016-06-03 17:00:07 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:00:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:00:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:00:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:00:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:00:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:00:07 --> Model Class Initialized
INFO - 2016-06-03 17:00:07 --> Form Validation Class Initialized
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:00:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:00:07 --> Final output sent to browser
DEBUG - 2016-06-03 17:00:07 --> Total execution time: 0.0479
INFO - 2016-06-03 17:00:13 --> Config Class Initialized
INFO - 2016-06-03 17:00:13 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:00:13 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:00:13 --> Utf8 Class Initialized
INFO - 2016-06-03 17:00:13 --> URI Class Initialized
INFO - 2016-06-03 17:00:13 --> Router Class Initialized
INFO - 2016-06-03 17:00:13 --> Output Class Initialized
INFO - 2016-06-03 17:00:13 --> Security Class Initialized
DEBUG - 2016-06-03 17:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:00:13 --> CSRF cookie sent
INFO - 2016-06-03 17:00:13 --> CSRF token verified
INFO - 2016-06-03 17:00:13 --> Input Class Initialized
INFO - 2016-06-03 17:00:13 --> Language Class Initialized
INFO - 2016-06-03 17:00:13 --> Loader Class Initialized
INFO - 2016-06-03 17:00:13 --> Helper loaded: form_helper
INFO - 2016-06-03 17:00:13 --> Database Driver Class Initialized
INFO - 2016-06-03 17:00:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:00:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:00:13 --> Email Class Initialized
INFO - 2016-06-03 17:00:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:00:13 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:00:13 --> Helper loaded: language_helper
INFO - 2016-06-03 17:00:13 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:00:13 --> Model Class Initialized
INFO - 2016-06-03 17:00:13 --> Helper loaded: date_helper
INFO - 2016-06-03 17:00:13 --> Controller Class Initialized
INFO - 2016-06-03 17:00:13 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:00:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:00:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:00:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:00:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:00:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:00:13 --> Model Class Initialized
INFO - 2016-06-03 17:00:13 --> Form Validation Class Initialized
INFO - 2016-06-03 17:00:13 --> Final output sent to browser
DEBUG - 2016-06-03 17:00:13 --> Total execution time: 0.0669
INFO - 2016-06-03 17:00:30 --> Config Class Initialized
INFO - 2016-06-03 17:00:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:00:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:00:30 --> Utf8 Class Initialized
INFO - 2016-06-03 17:00:30 --> URI Class Initialized
INFO - 2016-06-03 17:00:30 --> Router Class Initialized
INFO - 2016-06-03 17:00:30 --> Output Class Initialized
INFO - 2016-06-03 17:00:30 --> Security Class Initialized
DEBUG - 2016-06-03 17:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:00:30 --> CSRF cookie sent
INFO - 2016-06-03 17:00:30 --> Input Class Initialized
INFO - 2016-06-03 17:00:30 --> Language Class Initialized
INFO - 2016-06-03 17:00:30 --> Loader Class Initialized
INFO - 2016-06-03 17:00:30 --> Helper loaded: form_helper
INFO - 2016-06-03 17:00:30 --> Database Driver Class Initialized
INFO - 2016-06-03 17:00:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:00:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:00:30 --> Email Class Initialized
INFO - 2016-06-03 17:00:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:00:30 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:00:30 --> Helper loaded: language_helper
INFO - 2016-06-03 17:00:30 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:00:30 --> Model Class Initialized
INFO - 2016-06-03 17:00:30 --> Helper loaded: date_helper
INFO - 2016-06-03 17:00:30 --> Controller Class Initialized
INFO - 2016-06-03 17:00:30 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:00:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:00:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:00:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:00:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:00:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:00:30 --> Model Class Initialized
INFO - 2016-06-03 17:00:30 --> Form Validation Class Initialized
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:00:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:00:30 --> Final output sent to browser
DEBUG - 2016-06-03 17:00:30 --> Total execution time: 0.0541
INFO - 2016-06-03 17:00:34 --> Config Class Initialized
INFO - 2016-06-03 17:00:34 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:00:34 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:00:34 --> Utf8 Class Initialized
INFO - 2016-06-03 17:00:34 --> URI Class Initialized
INFO - 2016-06-03 17:00:34 --> Router Class Initialized
INFO - 2016-06-03 17:00:34 --> Output Class Initialized
INFO - 2016-06-03 17:00:34 --> Security Class Initialized
DEBUG - 2016-06-03 17:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:00:34 --> CSRF cookie sent
INFO - 2016-06-03 17:00:34 --> CSRF token verified
INFO - 2016-06-03 17:00:34 --> Input Class Initialized
INFO - 2016-06-03 17:00:34 --> Language Class Initialized
INFO - 2016-06-03 17:00:34 --> Loader Class Initialized
INFO - 2016-06-03 17:00:34 --> Helper loaded: form_helper
INFO - 2016-06-03 17:00:34 --> Database Driver Class Initialized
INFO - 2016-06-03 17:00:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:00:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:00:34 --> Email Class Initialized
INFO - 2016-06-03 17:00:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:00:34 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:00:34 --> Helper loaded: language_helper
INFO - 2016-06-03 17:00:34 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:00:34 --> Model Class Initialized
INFO - 2016-06-03 17:00:34 --> Helper loaded: date_helper
INFO - 2016-06-03 17:00:34 --> Controller Class Initialized
INFO - 2016-06-03 17:00:34 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:00:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:00:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:00:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:00:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:00:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:00:34 --> Model Class Initialized
INFO - 2016-06-03 17:00:34 --> Form Validation Class Initialized
INFO - 2016-06-03 17:00:34 --> Final output sent to browser
DEBUG - 2016-06-03 17:00:34 --> Total execution time: 0.0571
INFO - 2016-06-03 17:01:25 --> Config Class Initialized
INFO - 2016-06-03 17:01:25 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:01:25 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:01:25 --> Utf8 Class Initialized
INFO - 2016-06-03 17:01:25 --> URI Class Initialized
INFO - 2016-06-03 17:01:25 --> Router Class Initialized
INFO - 2016-06-03 17:01:25 --> Output Class Initialized
INFO - 2016-06-03 17:01:25 --> Security Class Initialized
DEBUG - 2016-06-03 17:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:01:25 --> CSRF cookie sent
INFO - 2016-06-03 17:01:25 --> CSRF token verified
INFO - 2016-06-03 17:01:25 --> Input Class Initialized
INFO - 2016-06-03 17:01:25 --> Language Class Initialized
INFO - 2016-06-03 17:01:25 --> Loader Class Initialized
INFO - 2016-06-03 17:01:25 --> Helper loaded: form_helper
INFO - 2016-06-03 17:01:25 --> Database Driver Class Initialized
INFO - 2016-06-03 17:01:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:01:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:01:25 --> Email Class Initialized
INFO - 2016-06-03 17:01:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:01:25 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:01:25 --> Helper loaded: language_helper
INFO - 2016-06-03 17:01:25 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:01:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:01:25 --> Model Class Initialized
INFO - 2016-06-03 17:01:25 --> Helper loaded: date_helper
INFO - 2016-06-03 17:01:25 --> Controller Class Initialized
INFO - 2016-06-03 17:01:25 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:01:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:01:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:01:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:01:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:01:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:01:25 --> Model Class Initialized
INFO - 2016-06-03 17:01:25 --> Form Validation Class Initialized
INFO - 2016-06-03 17:01:25 --> Final output sent to browser
DEBUG - 2016-06-03 17:01:25 --> Total execution time: 0.0601
INFO - 2016-06-03 17:02:27 --> Config Class Initialized
INFO - 2016-06-03 17:02:27 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:02:27 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:02:27 --> Utf8 Class Initialized
INFO - 2016-06-03 17:02:27 --> URI Class Initialized
INFO - 2016-06-03 17:02:27 --> Router Class Initialized
INFO - 2016-06-03 17:02:27 --> Output Class Initialized
INFO - 2016-06-03 17:02:27 --> Security Class Initialized
DEBUG - 2016-06-03 17:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:02:27 --> CSRF cookie sent
INFO - 2016-06-03 17:02:27 --> Input Class Initialized
INFO - 2016-06-03 17:02:27 --> Language Class Initialized
INFO - 2016-06-03 17:02:27 --> Loader Class Initialized
INFO - 2016-06-03 17:02:27 --> Helper loaded: form_helper
INFO - 2016-06-03 17:02:27 --> Database Driver Class Initialized
INFO - 2016-06-03 17:02:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:02:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:02:27 --> Email Class Initialized
INFO - 2016-06-03 17:02:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:02:27 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:02:27 --> Helper loaded: language_helper
INFO - 2016-06-03 17:02:27 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:02:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:02:27 --> Model Class Initialized
INFO - 2016-06-03 17:02:27 --> Helper loaded: date_helper
INFO - 2016-06-03 17:02:27 --> Controller Class Initialized
INFO - 2016-06-03 17:02:27 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:02:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:02:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:02:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:02:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:02:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:02:27 --> Model Class Initialized
INFO - 2016-06-03 17:02:27 --> Form Validation Class Initialized
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:02:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:02:27 --> Final output sent to browser
DEBUG - 2016-06-03 17:02:27 --> Total execution time: 0.0501
INFO - 2016-06-03 17:02:33 --> Config Class Initialized
INFO - 2016-06-03 17:02:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:02:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:02:33 --> Utf8 Class Initialized
INFO - 2016-06-03 17:02:33 --> URI Class Initialized
INFO - 2016-06-03 17:02:33 --> Router Class Initialized
INFO - 2016-06-03 17:02:33 --> Output Class Initialized
INFO - 2016-06-03 17:02:33 --> Security Class Initialized
DEBUG - 2016-06-03 17:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:02:33 --> CSRF cookie sent
INFO - 2016-06-03 17:02:33 --> CSRF token verified
INFO - 2016-06-03 17:02:33 --> Input Class Initialized
INFO - 2016-06-03 17:02:33 --> Language Class Initialized
INFO - 2016-06-03 17:02:33 --> Loader Class Initialized
INFO - 2016-06-03 17:02:33 --> Helper loaded: form_helper
INFO - 2016-06-03 17:02:33 --> Database Driver Class Initialized
INFO - 2016-06-03 17:02:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:02:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:02:33 --> Email Class Initialized
INFO - 2016-06-03 17:02:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:02:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:02:33 --> Helper loaded: language_helper
INFO - 2016-06-03 17:02:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:02:33 --> Model Class Initialized
INFO - 2016-06-03 17:02:33 --> Helper loaded: date_helper
INFO - 2016-06-03 17:02:33 --> Controller Class Initialized
INFO - 2016-06-03 17:02:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:02:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:02:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:02:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:02:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:02:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:02:33 --> Model Class Initialized
INFO - 2016-06-03 17:02:33 --> Form Validation Class Initialized
INFO - 2016-06-03 17:02:33 --> Final output sent to browser
DEBUG - 2016-06-03 17:02:33 --> Total execution time: 0.0416
INFO - 2016-06-03 17:02:40 --> Config Class Initialized
INFO - 2016-06-03 17:02:40 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:02:40 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:02:40 --> Utf8 Class Initialized
INFO - 2016-06-03 17:02:40 --> URI Class Initialized
INFO - 2016-06-03 17:02:40 --> Router Class Initialized
INFO - 2016-06-03 17:02:40 --> Output Class Initialized
INFO - 2016-06-03 17:02:40 --> Security Class Initialized
DEBUG - 2016-06-03 17:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:02:40 --> CSRF cookie sent
INFO - 2016-06-03 17:02:40 --> CSRF token verified
INFO - 2016-06-03 17:02:40 --> Input Class Initialized
INFO - 2016-06-03 17:02:40 --> Language Class Initialized
INFO - 2016-06-03 17:02:40 --> Loader Class Initialized
INFO - 2016-06-03 17:02:40 --> Helper loaded: form_helper
INFO - 2016-06-03 17:02:40 --> Database Driver Class Initialized
INFO - 2016-06-03 17:02:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:02:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:02:40 --> Email Class Initialized
INFO - 2016-06-03 17:02:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:02:40 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:02:40 --> Helper loaded: language_helper
INFO - 2016-06-03 17:02:40 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:02:40 --> Model Class Initialized
INFO - 2016-06-03 17:02:40 --> Helper loaded: date_helper
INFO - 2016-06-03 17:02:40 --> Controller Class Initialized
INFO - 2016-06-03 17:02:40 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:02:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:02:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:02:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:02:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:02:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:02:40 --> Model Class Initialized
INFO - 2016-06-03 17:02:40 --> Form Validation Class Initialized
INFO - 2016-06-03 17:02:40 --> Final output sent to browser
DEBUG - 2016-06-03 17:02:40 --> Total execution time: 0.0238
INFO - 2016-06-03 17:02:46 --> Config Class Initialized
INFO - 2016-06-03 17:02:46 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:02:46 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:02:46 --> Utf8 Class Initialized
INFO - 2016-06-03 17:02:46 --> URI Class Initialized
INFO - 2016-06-03 17:02:46 --> Router Class Initialized
INFO - 2016-06-03 17:02:46 --> Output Class Initialized
INFO - 2016-06-03 17:02:46 --> Security Class Initialized
DEBUG - 2016-06-03 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:02:46 --> CSRF cookie sent
INFO - 2016-06-03 17:02:46 --> CSRF token verified
INFO - 2016-06-03 17:02:46 --> Input Class Initialized
INFO - 2016-06-03 17:02:46 --> Language Class Initialized
INFO - 2016-06-03 17:02:46 --> Loader Class Initialized
INFO - 2016-06-03 17:02:46 --> Helper loaded: form_helper
INFO - 2016-06-03 17:02:46 --> Database Driver Class Initialized
INFO - 2016-06-03 17:02:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:02:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:02:46 --> Email Class Initialized
INFO - 2016-06-03 17:02:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:02:46 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:02:46 --> Helper loaded: language_helper
INFO - 2016-06-03 17:02:46 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:02:46 --> Model Class Initialized
INFO - 2016-06-03 17:02:46 --> Helper loaded: date_helper
INFO - 2016-06-03 17:02:46 --> Controller Class Initialized
INFO - 2016-06-03 17:02:46 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:02:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:02:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:02:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:02:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:02:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:02:46 --> Model Class Initialized
INFO - 2016-06-03 17:02:46 --> Form Validation Class Initialized
INFO - 2016-06-03 17:02:46 --> Final output sent to browser
DEBUG - 2016-06-03 17:02:46 --> Total execution time: 0.0482
INFO - 2016-06-03 17:02:55 --> Config Class Initialized
INFO - 2016-06-03 17:02:55 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:02:55 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:02:55 --> Utf8 Class Initialized
INFO - 2016-06-03 17:02:55 --> URI Class Initialized
INFO - 2016-06-03 17:02:55 --> Router Class Initialized
INFO - 2016-06-03 17:02:55 --> Output Class Initialized
INFO - 2016-06-03 17:02:55 --> Security Class Initialized
DEBUG - 2016-06-03 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:02:55 --> CSRF cookie sent
INFO - 2016-06-03 17:02:55 --> Input Class Initialized
INFO - 2016-06-03 17:02:55 --> Language Class Initialized
INFO - 2016-06-03 17:02:55 --> Loader Class Initialized
INFO - 2016-06-03 17:02:55 --> Helper loaded: form_helper
INFO - 2016-06-03 17:02:55 --> Database Driver Class Initialized
INFO - 2016-06-03 17:02:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:02:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:02:55 --> Email Class Initialized
INFO - 2016-06-03 17:02:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:02:55 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:02:55 --> Helper loaded: language_helper
INFO - 2016-06-03 17:02:55 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:02:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:02:55 --> Model Class Initialized
INFO - 2016-06-03 17:02:55 --> Helper loaded: date_helper
INFO - 2016-06-03 17:02:55 --> Controller Class Initialized
INFO - 2016-06-03 17:02:55 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:02:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:02:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:02:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:02:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:02:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:02:55 --> Model Class Initialized
INFO - 2016-06-03 17:02:55 --> Form Validation Class Initialized
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:02:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:02:55 --> Final output sent to browser
DEBUG - 2016-06-03 17:02:55 --> Total execution time: 0.0284
INFO - 2016-06-03 17:03:01 --> Config Class Initialized
INFO - 2016-06-03 17:03:01 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:03:01 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:03:01 --> Utf8 Class Initialized
INFO - 2016-06-03 17:03:01 --> URI Class Initialized
INFO - 2016-06-03 17:03:01 --> Router Class Initialized
INFO - 2016-06-03 17:03:01 --> Output Class Initialized
INFO - 2016-06-03 17:03:01 --> Security Class Initialized
DEBUG - 2016-06-03 17:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:03:01 --> CSRF cookie sent
INFO - 2016-06-03 17:03:01 --> CSRF token verified
INFO - 2016-06-03 17:03:01 --> Input Class Initialized
INFO - 2016-06-03 17:03:01 --> Language Class Initialized
INFO - 2016-06-03 17:03:01 --> Loader Class Initialized
INFO - 2016-06-03 17:03:01 --> Helper loaded: form_helper
INFO - 2016-06-03 17:03:01 --> Database Driver Class Initialized
INFO - 2016-06-03 17:03:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:03:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:03:01 --> Email Class Initialized
INFO - 2016-06-03 17:03:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:03:01 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:03:01 --> Helper loaded: language_helper
INFO - 2016-06-03 17:03:01 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:03:01 --> Model Class Initialized
INFO - 2016-06-03 17:03:01 --> Helper loaded: date_helper
INFO - 2016-06-03 17:03:01 --> Controller Class Initialized
INFO - 2016-06-03 17:03:01 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:03:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:03:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:03:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:03:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:03:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:03:01 --> Model Class Initialized
INFO - 2016-06-03 17:03:01 --> Form Validation Class Initialized
INFO - 2016-06-03 17:03:01 --> Final output sent to browser
DEBUG - 2016-06-03 17:03:01 --> Total execution time: 0.0155
INFO - 2016-06-03 17:04:23 --> Config Class Initialized
INFO - 2016-06-03 17:04:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:04:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:04:23 --> Utf8 Class Initialized
INFO - 2016-06-03 17:04:23 --> URI Class Initialized
INFO - 2016-06-03 17:04:23 --> Router Class Initialized
INFO - 2016-06-03 17:04:23 --> Output Class Initialized
INFO - 2016-06-03 17:04:23 --> Security Class Initialized
DEBUG - 2016-06-03 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:04:23 --> CSRF cookie sent
INFO - 2016-06-03 17:04:23 --> Input Class Initialized
INFO - 2016-06-03 17:04:23 --> Language Class Initialized
INFO - 2016-06-03 17:04:23 --> Loader Class Initialized
INFO - 2016-06-03 17:04:23 --> Helper loaded: form_helper
INFO - 2016-06-03 17:04:23 --> Database Driver Class Initialized
INFO - 2016-06-03 17:04:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:04:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:04:23 --> Email Class Initialized
INFO - 2016-06-03 17:04:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:04:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:04:23 --> Helper loaded: language_helper
INFO - 2016-06-03 17:04:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:04:23 --> Model Class Initialized
INFO - 2016-06-03 17:04:23 --> Helper loaded: date_helper
INFO - 2016-06-03 17:04:23 --> Controller Class Initialized
INFO - 2016-06-03 17:04:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:04:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:04:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:04:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:04:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:04:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:04:23 --> Model Class Initialized
INFO - 2016-06-03 17:04:23 --> Form Validation Class Initialized
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:04:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:04:23 --> Final output sent to browser
DEBUG - 2016-06-03 17:04:23 --> Total execution time: 0.0608
INFO - 2016-06-03 17:04:29 --> Config Class Initialized
INFO - 2016-06-03 17:04:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:04:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:04:29 --> Utf8 Class Initialized
INFO - 2016-06-03 17:04:29 --> URI Class Initialized
INFO - 2016-06-03 17:04:29 --> Router Class Initialized
INFO - 2016-06-03 17:04:29 --> Output Class Initialized
INFO - 2016-06-03 17:04:29 --> Security Class Initialized
DEBUG - 2016-06-03 17:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:04:29 --> CSRF cookie sent
INFO - 2016-06-03 17:04:29 --> CSRF token verified
INFO - 2016-06-03 17:04:29 --> Input Class Initialized
INFO - 2016-06-03 17:04:29 --> Language Class Initialized
INFO - 2016-06-03 17:04:29 --> Loader Class Initialized
INFO - 2016-06-03 17:04:29 --> Helper loaded: form_helper
INFO - 2016-06-03 17:04:29 --> Database Driver Class Initialized
INFO - 2016-06-03 17:04:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:04:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:04:29 --> Email Class Initialized
INFO - 2016-06-03 17:04:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:04:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:04:29 --> Helper loaded: language_helper
INFO - 2016-06-03 17:04:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:04:29 --> Model Class Initialized
INFO - 2016-06-03 17:04:29 --> Helper loaded: date_helper
INFO - 2016-06-03 17:04:29 --> Controller Class Initialized
INFO - 2016-06-03 17:04:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:04:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:04:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:04:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:04:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:04:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:04:29 --> Model Class Initialized
INFO - 2016-06-03 17:04:29 --> Form Validation Class Initialized
INFO - 2016-06-03 17:04:29 --> Final output sent to browser
DEBUG - 2016-06-03 17:04:29 --> Total execution time: 0.0747
INFO - 2016-06-03 17:04:44 --> Config Class Initialized
INFO - 2016-06-03 17:04:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:04:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:04:44 --> Utf8 Class Initialized
INFO - 2016-06-03 17:04:44 --> URI Class Initialized
INFO - 2016-06-03 17:04:44 --> Router Class Initialized
INFO - 2016-06-03 17:04:44 --> Output Class Initialized
INFO - 2016-06-03 17:04:44 --> Security Class Initialized
DEBUG - 2016-06-03 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:04:44 --> CSRF cookie sent
INFO - 2016-06-03 17:04:44 --> Input Class Initialized
INFO - 2016-06-03 17:04:44 --> Language Class Initialized
INFO - 2016-06-03 17:04:44 --> Loader Class Initialized
INFO - 2016-06-03 17:04:44 --> Helper loaded: form_helper
INFO - 2016-06-03 17:04:44 --> Database Driver Class Initialized
INFO - 2016-06-03 17:04:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:04:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:04:44 --> Email Class Initialized
INFO - 2016-06-03 17:04:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:04:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:04:44 --> Helper loaded: language_helper
INFO - 2016-06-03 17:04:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:04:44 --> Model Class Initialized
INFO - 2016-06-03 17:04:44 --> Helper loaded: date_helper
INFO - 2016-06-03 17:04:44 --> Controller Class Initialized
INFO - 2016-06-03 17:04:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:04:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:04:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:04:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:04:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:04:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:04:44 --> Model Class Initialized
INFO - 2016-06-03 17:04:44 --> Form Validation Class Initialized
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:04:44 --> Final output sent to browser
DEBUG - 2016-06-03 17:04:44 --> Total execution time: 0.0929
INFO - 2016-06-03 17:04:52 --> Config Class Initialized
INFO - 2016-06-03 17:04:52 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:04:52 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:04:52 --> Utf8 Class Initialized
INFO - 2016-06-03 17:04:52 --> URI Class Initialized
INFO - 2016-06-03 17:04:52 --> Router Class Initialized
INFO - 2016-06-03 17:04:52 --> Output Class Initialized
INFO - 2016-06-03 17:04:52 --> Security Class Initialized
DEBUG - 2016-06-03 17:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:04:52 --> CSRF cookie sent
INFO - 2016-06-03 17:04:52 --> CSRF token verified
INFO - 2016-06-03 17:04:52 --> Input Class Initialized
INFO - 2016-06-03 17:04:52 --> Language Class Initialized
INFO - 2016-06-03 17:04:52 --> Loader Class Initialized
INFO - 2016-06-03 17:04:52 --> Helper loaded: form_helper
INFO - 2016-06-03 17:04:52 --> Database Driver Class Initialized
INFO - 2016-06-03 17:04:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:04:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:04:52 --> Email Class Initialized
INFO - 2016-06-03 17:04:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:04:52 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:04:52 --> Helper loaded: language_helper
INFO - 2016-06-03 17:04:52 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:04:52 --> Model Class Initialized
INFO - 2016-06-03 17:04:52 --> Helper loaded: date_helper
INFO - 2016-06-03 17:04:52 --> Controller Class Initialized
INFO - 2016-06-03 17:04:52 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:04:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:04:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:04:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:04:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:04:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:04:52 --> Model Class Initialized
INFO - 2016-06-03 17:04:52 --> Form Validation Class Initialized
INFO - 2016-06-03 17:04:52 --> Final output sent to browser
DEBUG - 2016-06-03 17:04:52 --> Total execution time: 0.0572
INFO - 2016-06-03 17:05:29 --> Config Class Initialized
INFO - 2016-06-03 17:05:29 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:05:29 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:05:29 --> Utf8 Class Initialized
INFO - 2016-06-03 17:05:29 --> URI Class Initialized
INFO - 2016-06-03 17:05:29 --> Router Class Initialized
INFO - 2016-06-03 17:05:29 --> Output Class Initialized
INFO - 2016-06-03 17:05:29 --> Security Class Initialized
DEBUG - 2016-06-03 17:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:05:29 --> CSRF cookie sent
INFO - 2016-06-03 17:05:29 --> Input Class Initialized
INFO - 2016-06-03 17:05:29 --> Language Class Initialized
INFO - 2016-06-03 17:05:29 --> Loader Class Initialized
INFO - 2016-06-03 17:05:29 --> Helper loaded: form_helper
INFO - 2016-06-03 17:05:29 --> Database Driver Class Initialized
INFO - 2016-06-03 17:05:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:05:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:05:29 --> Email Class Initialized
INFO - 2016-06-03 17:05:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:05:29 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:05:29 --> Helper loaded: language_helper
INFO - 2016-06-03 17:05:29 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:05:29 --> Model Class Initialized
INFO - 2016-06-03 17:05:29 --> Helper loaded: date_helper
INFO - 2016-06-03 17:05:29 --> Controller Class Initialized
INFO - 2016-06-03 17:05:29 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:05:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:05:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:05:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:05:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:05:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:05:29 --> Model Class Initialized
INFO - 2016-06-03 17:05:29 --> Form Validation Class Initialized
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:05:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:05:29 --> Final output sent to browser
DEBUG - 2016-06-03 17:05:29 --> Total execution time: 0.0684
INFO - 2016-06-03 17:05:34 --> Config Class Initialized
INFO - 2016-06-03 17:05:34 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:05:34 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:05:34 --> Utf8 Class Initialized
INFO - 2016-06-03 17:05:34 --> URI Class Initialized
INFO - 2016-06-03 17:05:34 --> Router Class Initialized
INFO - 2016-06-03 17:05:34 --> Output Class Initialized
INFO - 2016-06-03 17:05:34 --> Security Class Initialized
DEBUG - 2016-06-03 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:05:34 --> CSRF cookie sent
INFO - 2016-06-03 17:05:34 --> CSRF token verified
INFO - 2016-06-03 17:05:34 --> Input Class Initialized
INFO - 2016-06-03 17:05:34 --> Language Class Initialized
INFO - 2016-06-03 17:05:34 --> Loader Class Initialized
INFO - 2016-06-03 17:05:34 --> Helper loaded: form_helper
INFO - 2016-06-03 17:05:34 --> Database Driver Class Initialized
INFO - 2016-06-03 17:05:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:05:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:05:34 --> Email Class Initialized
INFO - 2016-06-03 17:05:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:05:34 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:05:34 --> Helper loaded: language_helper
INFO - 2016-06-03 17:05:34 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:05:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:05:34 --> Model Class Initialized
INFO - 2016-06-03 17:05:34 --> Helper loaded: date_helper
INFO - 2016-06-03 17:05:34 --> Controller Class Initialized
INFO - 2016-06-03 17:05:34 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:05:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:05:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:05:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:05:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:05:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:05:34 --> Model Class Initialized
INFO - 2016-06-03 17:05:34 --> Form Validation Class Initialized
INFO - 2016-06-03 17:05:34 --> Final output sent to browser
DEBUG - 2016-06-03 17:05:34 --> Total execution time: 0.0576
INFO - 2016-06-03 17:08:41 --> Config Class Initialized
INFO - 2016-06-03 17:08:41 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:08:41 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:08:41 --> Utf8 Class Initialized
INFO - 2016-06-03 17:08:41 --> URI Class Initialized
INFO - 2016-06-03 17:08:41 --> Router Class Initialized
INFO - 2016-06-03 17:08:41 --> Output Class Initialized
INFO - 2016-06-03 17:08:41 --> Security Class Initialized
DEBUG - 2016-06-03 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:08:41 --> CSRF cookie sent
INFO - 2016-06-03 17:08:41 --> Input Class Initialized
INFO - 2016-06-03 17:08:41 --> Language Class Initialized
INFO - 2016-06-03 17:08:41 --> Loader Class Initialized
INFO - 2016-06-03 17:08:41 --> Helper loaded: form_helper
INFO - 2016-06-03 17:08:41 --> Database Driver Class Initialized
INFO - 2016-06-03 17:08:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:08:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:08:41 --> Email Class Initialized
INFO - 2016-06-03 17:08:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:08:41 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:08:41 --> Helper loaded: language_helper
INFO - 2016-06-03 17:08:41 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:08:41 --> Model Class Initialized
INFO - 2016-06-03 17:08:41 --> Helper loaded: date_helper
INFO - 2016-06-03 17:08:41 --> Controller Class Initialized
INFO - 2016-06-03 17:08:41 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:08:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:08:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:08:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:08:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:08:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:08:41 --> Model Class Initialized
INFO - 2016-06-03 17:08:41 --> Form Validation Class Initialized
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:08:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:08:41 --> Final output sent to browser
DEBUG - 2016-06-03 17:08:41 --> Total execution time: 0.0527
INFO - 2016-06-03 17:08:47 --> Config Class Initialized
INFO - 2016-06-03 17:08:47 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:08:47 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:08:47 --> Utf8 Class Initialized
INFO - 2016-06-03 17:08:47 --> URI Class Initialized
INFO - 2016-06-03 17:08:47 --> Router Class Initialized
INFO - 2016-06-03 17:08:47 --> Output Class Initialized
INFO - 2016-06-03 17:08:47 --> Security Class Initialized
DEBUG - 2016-06-03 17:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:08:47 --> CSRF cookie sent
INFO - 2016-06-03 17:08:47 --> CSRF token verified
INFO - 2016-06-03 17:08:47 --> Input Class Initialized
INFO - 2016-06-03 17:08:47 --> Language Class Initialized
INFO - 2016-06-03 17:08:47 --> Loader Class Initialized
INFO - 2016-06-03 17:08:47 --> Helper loaded: form_helper
INFO - 2016-06-03 17:08:47 --> Database Driver Class Initialized
INFO - 2016-06-03 17:08:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:08:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:08:47 --> Email Class Initialized
INFO - 2016-06-03 17:08:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:08:47 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:08:47 --> Helper loaded: language_helper
INFO - 2016-06-03 17:08:47 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:08:47 --> Model Class Initialized
INFO - 2016-06-03 17:08:47 --> Helper loaded: date_helper
INFO - 2016-06-03 17:08:47 --> Controller Class Initialized
INFO - 2016-06-03 17:08:47 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:08:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:08:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:08:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:08:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:08:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:08:47 --> Model Class Initialized
INFO - 2016-06-03 17:08:47 --> Form Validation Class Initialized
INFO - 2016-06-03 17:08:47 --> Final output sent to browser
DEBUG - 2016-06-03 17:08:47 --> Total execution time: 0.0169
INFO - 2016-06-03 17:10:04 --> Config Class Initialized
INFO - 2016-06-03 17:10:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:10:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:10:04 --> Utf8 Class Initialized
INFO - 2016-06-03 17:10:04 --> URI Class Initialized
INFO - 2016-06-03 17:10:04 --> Router Class Initialized
INFO - 2016-06-03 17:10:04 --> Output Class Initialized
INFO - 2016-06-03 17:10:04 --> Security Class Initialized
DEBUG - 2016-06-03 17:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:10:04 --> CSRF cookie sent
INFO - 2016-06-03 17:10:04 --> Input Class Initialized
INFO - 2016-06-03 17:10:04 --> Language Class Initialized
INFO - 2016-06-03 17:10:04 --> Loader Class Initialized
INFO - 2016-06-03 17:10:04 --> Helper loaded: form_helper
INFO - 2016-06-03 17:10:04 --> Database Driver Class Initialized
INFO - 2016-06-03 17:10:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:10:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:10:04 --> Email Class Initialized
INFO - 2016-06-03 17:10:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:10:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:10:04 --> Helper loaded: language_helper
INFO - 2016-06-03 17:10:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:10:04 --> Model Class Initialized
INFO - 2016-06-03 17:10:04 --> Helper loaded: date_helper
INFO - 2016-06-03 17:10:04 --> Controller Class Initialized
INFO - 2016-06-03 17:10:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:10:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:10:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:10:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:10:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:10:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:10:04 --> Model Class Initialized
INFO - 2016-06-03 17:10:04 --> Form Validation Class Initialized
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:10:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:10:04 --> Final output sent to browser
DEBUG - 2016-06-03 17:10:04 --> Total execution time: 0.0707
INFO - 2016-06-03 17:10:08 --> Config Class Initialized
INFO - 2016-06-03 17:10:08 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:10:08 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:10:08 --> Utf8 Class Initialized
INFO - 2016-06-03 17:10:08 --> URI Class Initialized
INFO - 2016-06-03 17:10:08 --> Router Class Initialized
INFO - 2016-06-03 17:10:08 --> Output Class Initialized
INFO - 2016-06-03 17:10:08 --> Security Class Initialized
DEBUG - 2016-06-03 17:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:10:08 --> CSRF cookie sent
INFO - 2016-06-03 17:10:08 --> CSRF token verified
INFO - 2016-06-03 17:10:08 --> Input Class Initialized
INFO - 2016-06-03 17:10:08 --> Language Class Initialized
INFO - 2016-06-03 17:10:08 --> Loader Class Initialized
INFO - 2016-06-03 17:10:08 --> Helper loaded: form_helper
INFO - 2016-06-03 17:10:09 --> Database Driver Class Initialized
INFO - 2016-06-03 17:10:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:10:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:10:09 --> Email Class Initialized
INFO - 2016-06-03 17:10:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:10:09 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:10:09 --> Helper loaded: language_helper
INFO - 2016-06-03 17:10:09 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:10:09 --> Model Class Initialized
INFO - 2016-06-03 17:10:09 --> Helper loaded: date_helper
INFO - 2016-06-03 17:10:09 --> Controller Class Initialized
INFO - 2016-06-03 17:10:09 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:10:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:10:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:10:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:10:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:10:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:10:09 --> Model Class Initialized
INFO - 2016-06-03 17:10:09 --> Form Validation Class Initialized
INFO - 2016-06-03 17:10:09 --> Final output sent to browser
DEBUG - 2016-06-03 17:10:09 --> Total execution time: 0.0589
INFO - 2016-06-03 17:12:00 --> Config Class Initialized
INFO - 2016-06-03 17:12:00 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:12:00 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:12:00 --> Utf8 Class Initialized
INFO - 2016-06-03 17:12:00 --> URI Class Initialized
INFO - 2016-06-03 17:12:00 --> Router Class Initialized
INFO - 2016-06-03 17:12:00 --> Output Class Initialized
INFO - 2016-06-03 17:12:00 --> Security Class Initialized
DEBUG - 2016-06-03 17:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:12:00 --> CSRF cookie sent
INFO - 2016-06-03 17:12:00 --> Input Class Initialized
INFO - 2016-06-03 17:12:00 --> Language Class Initialized
INFO - 2016-06-03 17:12:00 --> Loader Class Initialized
INFO - 2016-06-03 17:12:00 --> Helper loaded: form_helper
INFO - 2016-06-03 17:12:00 --> Database Driver Class Initialized
INFO - 2016-06-03 17:12:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:12:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:12:00 --> Email Class Initialized
INFO - 2016-06-03 17:12:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:12:00 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:12:00 --> Helper loaded: language_helper
INFO - 2016-06-03 17:12:00 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:12:00 --> Model Class Initialized
INFO - 2016-06-03 17:12:00 --> Helper loaded: date_helper
INFO - 2016-06-03 17:12:00 --> Controller Class Initialized
INFO - 2016-06-03 17:12:00 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:12:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:12:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:12:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:12:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:12:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:12:00 --> Model Class Initialized
INFO - 2016-06-03 17:12:00 --> Form Validation Class Initialized
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:12:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:12:00 --> Final output sent to browser
DEBUG - 2016-06-03 17:12:00 --> Total execution time: 0.0815
INFO - 2016-06-03 17:12:05 --> Config Class Initialized
INFO - 2016-06-03 17:12:05 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:12:05 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:12:05 --> Utf8 Class Initialized
INFO - 2016-06-03 17:12:05 --> URI Class Initialized
INFO - 2016-06-03 17:12:05 --> Router Class Initialized
INFO - 2016-06-03 17:12:05 --> Output Class Initialized
INFO - 2016-06-03 17:12:05 --> Security Class Initialized
DEBUG - 2016-06-03 17:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:12:05 --> CSRF cookie sent
INFO - 2016-06-03 17:12:05 --> CSRF token verified
INFO - 2016-06-03 17:12:05 --> Input Class Initialized
INFO - 2016-06-03 17:12:05 --> Language Class Initialized
INFO - 2016-06-03 17:12:05 --> Loader Class Initialized
INFO - 2016-06-03 17:12:05 --> Helper loaded: form_helper
INFO - 2016-06-03 17:12:05 --> Database Driver Class Initialized
INFO - 2016-06-03 17:12:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:12:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:12:05 --> Email Class Initialized
INFO - 2016-06-03 17:12:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:12:05 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:12:05 --> Helper loaded: language_helper
INFO - 2016-06-03 17:12:05 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:12:05 --> Model Class Initialized
INFO - 2016-06-03 17:12:05 --> Helper loaded: date_helper
INFO - 2016-06-03 17:12:05 --> Controller Class Initialized
INFO - 2016-06-03 17:12:05 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:12:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:12:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:12:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:12:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:12:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:12:05 --> Model Class Initialized
INFO - 2016-06-03 17:12:05 --> Form Validation Class Initialized
INFO - 2016-06-03 17:12:05 --> Final output sent to browser
DEBUG - 2016-06-03 17:12:05 --> Total execution time: 0.0862
INFO - 2016-06-03 17:12:49 --> Config Class Initialized
INFO - 2016-06-03 17:12:49 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:12:49 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:12:49 --> Utf8 Class Initialized
INFO - 2016-06-03 17:12:49 --> URI Class Initialized
INFO - 2016-06-03 17:12:49 --> Router Class Initialized
INFO - 2016-06-03 17:12:49 --> Output Class Initialized
INFO - 2016-06-03 17:12:49 --> Security Class Initialized
DEBUG - 2016-06-03 17:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:12:49 --> CSRF cookie sent
INFO - 2016-06-03 17:12:49 --> Input Class Initialized
INFO - 2016-06-03 17:12:49 --> Language Class Initialized
INFO - 2016-06-03 17:12:49 --> Loader Class Initialized
INFO - 2016-06-03 17:12:49 --> Helper loaded: form_helper
INFO - 2016-06-03 17:12:49 --> Database Driver Class Initialized
INFO - 2016-06-03 17:12:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:12:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:12:49 --> Email Class Initialized
INFO - 2016-06-03 17:12:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:12:49 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:12:49 --> Helper loaded: language_helper
INFO - 2016-06-03 17:12:49 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:12:49 --> Model Class Initialized
INFO - 2016-06-03 17:12:49 --> Helper loaded: date_helper
INFO - 2016-06-03 17:12:49 --> Controller Class Initialized
INFO - 2016-06-03 17:12:49 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:12:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:12:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:12:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:12:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:12:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:12:49 --> Model Class Initialized
INFO - 2016-06-03 17:12:49 --> Form Validation Class Initialized
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:12:49 --> Final output sent to browser
DEBUG - 2016-06-03 17:12:49 --> Total execution time: 0.0474
INFO - 2016-06-03 17:12:56 --> Config Class Initialized
INFO - 2016-06-03 17:12:56 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:12:56 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:12:56 --> Utf8 Class Initialized
INFO - 2016-06-03 17:12:56 --> URI Class Initialized
INFO - 2016-06-03 17:12:56 --> Router Class Initialized
INFO - 2016-06-03 17:12:56 --> Output Class Initialized
INFO - 2016-06-03 17:12:56 --> Security Class Initialized
DEBUG - 2016-06-03 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:12:56 --> CSRF cookie sent
INFO - 2016-06-03 17:12:56 --> CSRF token verified
INFO - 2016-06-03 17:12:56 --> Input Class Initialized
INFO - 2016-06-03 17:12:56 --> Language Class Initialized
INFO - 2016-06-03 17:12:56 --> Loader Class Initialized
INFO - 2016-06-03 17:12:56 --> Helper loaded: form_helper
INFO - 2016-06-03 17:12:56 --> Database Driver Class Initialized
INFO - 2016-06-03 17:12:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:12:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:12:56 --> Email Class Initialized
INFO - 2016-06-03 17:12:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:12:56 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:12:56 --> Helper loaded: language_helper
INFO - 2016-06-03 17:12:56 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:12:56 --> Model Class Initialized
INFO - 2016-06-03 17:12:56 --> Helper loaded: date_helper
INFO - 2016-06-03 17:12:56 --> Controller Class Initialized
INFO - 2016-06-03 17:12:56 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:12:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:12:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:12:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:12:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:12:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:12:56 --> Model Class Initialized
INFO - 2016-06-03 17:12:56 --> Form Validation Class Initialized
INFO - 2016-06-03 17:12:56 --> Final output sent to browser
DEBUG - 2016-06-03 17:12:56 --> Total execution time: 0.0466
INFO - 2016-06-03 17:13:14 --> Config Class Initialized
INFO - 2016-06-03 17:13:14 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:13:14 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:13:14 --> Utf8 Class Initialized
INFO - 2016-06-03 17:13:14 --> URI Class Initialized
INFO - 2016-06-03 17:13:14 --> Router Class Initialized
INFO - 2016-06-03 17:13:14 --> Output Class Initialized
INFO - 2016-06-03 17:13:14 --> Security Class Initialized
DEBUG - 2016-06-03 17:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:13:14 --> CSRF cookie sent
INFO - 2016-06-03 17:13:14 --> Input Class Initialized
INFO - 2016-06-03 17:13:14 --> Language Class Initialized
INFO - 2016-06-03 17:13:14 --> Loader Class Initialized
INFO - 2016-06-03 17:13:14 --> Helper loaded: form_helper
INFO - 2016-06-03 17:13:14 --> Database Driver Class Initialized
INFO - 2016-06-03 17:13:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:13:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:13:14 --> Email Class Initialized
INFO - 2016-06-03 17:13:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:13:14 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:13:14 --> Helper loaded: language_helper
INFO - 2016-06-03 17:13:14 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:13:14 --> Model Class Initialized
INFO - 2016-06-03 17:13:14 --> Helper loaded: date_helper
INFO - 2016-06-03 17:13:14 --> Controller Class Initialized
INFO - 2016-06-03 17:13:14 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:13:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:13:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:13:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:13:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:13:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:13:14 --> Model Class Initialized
INFO - 2016-06-03 17:13:14 --> Form Validation Class Initialized
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:13:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:13:14 --> Final output sent to browser
DEBUG - 2016-06-03 17:13:14 --> Total execution time: 0.0991
INFO - 2016-06-03 17:13:21 --> Config Class Initialized
INFO - 2016-06-03 17:13:21 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:13:21 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:13:21 --> Utf8 Class Initialized
INFO - 2016-06-03 17:13:21 --> URI Class Initialized
INFO - 2016-06-03 17:13:21 --> Router Class Initialized
INFO - 2016-06-03 17:13:21 --> Output Class Initialized
INFO - 2016-06-03 17:13:21 --> Security Class Initialized
DEBUG - 2016-06-03 17:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:13:21 --> CSRF cookie sent
INFO - 2016-06-03 17:13:21 --> CSRF token verified
INFO - 2016-06-03 17:13:21 --> Input Class Initialized
INFO - 2016-06-03 17:13:21 --> Language Class Initialized
INFO - 2016-06-03 17:13:21 --> Loader Class Initialized
INFO - 2016-06-03 17:13:21 --> Helper loaded: form_helper
INFO - 2016-06-03 17:13:21 --> Database Driver Class Initialized
INFO - 2016-06-03 17:13:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:13:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:13:21 --> Email Class Initialized
INFO - 2016-06-03 17:13:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:13:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:13:21 --> Helper loaded: language_helper
INFO - 2016-06-03 17:13:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:13:21 --> Model Class Initialized
INFO - 2016-06-03 17:13:21 --> Helper loaded: date_helper
INFO - 2016-06-03 17:13:21 --> Controller Class Initialized
INFO - 2016-06-03 17:13:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:13:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:13:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:13:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:13:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:13:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:13:21 --> Model Class Initialized
INFO - 2016-06-03 17:13:21 --> Form Validation Class Initialized
INFO - 2016-06-03 17:13:21 --> Final output sent to browser
DEBUG - 2016-06-03 17:13:21 --> Total execution time: 0.0441
INFO - 2016-06-03 17:14:10 --> Config Class Initialized
INFO - 2016-06-03 17:14:10 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:14:10 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:14:10 --> Utf8 Class Initialized
INFO - 2016-06-03 17:14:10 --> URI Class Initialized
INFO - 2016-06-03 17:14:10 --> Router Class Initialized
INFO - 2016-06-03 17:14:10 --> Output Class Initialized
INFO - 2016-06-03 17:14:10 --> Security Class Initialized
DEBUG - 2016-06-03 17:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:14:10 --> CSRF cookie sent
INFO - 2016-06-03 17:14:10 --> Input Class Initialized
INFO - 2016-06-03 17:14:10 --> Language Class Initialized
INFO - 2016-06-03 17:14:10 --> Loader Class Initialized
INFO - 2016-06-03 17:14:10 --> Helper loaded: form_helper
INFO - 2016-06-03 17:14:10 --> Database Driver Class Initialized
INFO - 2016-06-03 17:14:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:14:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:14:10 --> Email Class Initialized
INFO - 2016-06-03 17:14:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:14:10 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:14:10 --> Helper loaded: language_helper
INFO - 2016-06-03 17:14:10 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:14:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:14:10 --> Model Class Initialized
INFO - 2016-06-03 17:14:10 --> Helper loaded: date_helper
INFO - 2016-06-03 17:14:10 --> Controller Class Initialized
INFO - 2016-06-03 17:14:10 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:14:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:14:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:14:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:14:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:14:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:14:10 --> Model Class Initialized
INFO - 2016-06-03 17:14:10 --> Form Validation Class Initialized
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:14:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:14:10 --> Final output sent to browser
DEBUG - 2016-06-03 17:14:10 --> Total execution time: 0.0476
INFO - 2016-06-03 17:14:16 --> Config Class Initialized
INFO - 2016-06-03 17:14:16 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:14:16 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:14:16 --> Utf8 Class Initialized
INFO - 2016-06-03 17:14:16 --> URI Class Initialized
INFO - 2016-06-03 17:14:16 --> Router Class Initialized
INFO - 2016-06-03 17:14:16 --> Output Class Initialized
INFO - 2016-06-03 17:14:16 --> Security Class Initialized
DEBUG - 2016-06-03 17:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:14:16 --> CSRF cookie sent
INFO - 2016-06-03 17:14:16 --> CSRF token verified
INFO - 2016-06-03 17:14:16 --> Input Class Initialized
INFO - 2016-06-03 17:14:16 --> Language Class Initialized
INFO - 2016-06-03 17:14:16 --> Loader Class Initialized
INFO - 2016-06-03 17:14:16 --> Helper loaded: form_helper
INFO - 2016-06-03 17:14:16 --> Database Driver Class Initialized
INFO - 2016-06-03 17:14:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:14:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:14:16 --> Email Class Initialized
INFO - 2016-06-03 17:14:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:14:16 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:14:16 --> Helper loaded: language_helper
INFO - 2016-06-03 17:14:16 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:14:16 --> Model Class Initialized
INFO - 2016-06-03 17:14:16 --> Helper loaded: date_helper
INFO - 2016-06-03 17:14:16 --> Controller Class Initialized
INFO - 2016-06-03 17:14:16 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:14:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:14:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:14:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:14:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:14:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:14:16 --> Model Class Initialized
INFO - 2016-06-03 17:14:16 --> Form Validation Class Initialized
INFO - 2016-06-03 17:14:16 --> Final output sent to browser
DEBUG - 2016-06-03 17:14:16 --> Total execution time: 0.0585
INFO - 2016-06-03 17:15:02 --> Config Class Initialized
INFO - 2016-06-03 17:15:02 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:15:02 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:15:02 --> Utf8 Class Initialized
INFO - 2016-06-03 17:15:02 --> URI Class Initialized
INFO - 2016-06-03 17:15:02 --> Router Class Initialized
INFO - 2016-06-03 17:15:02 --> Output Class Initialized
INFO - 2016-06-03 17:15:02 --> Security Class Initialized
DEBUG - 2016-06-03 17:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:15:02 --> CSRF cookie sent
INFO - 2016-06-03 17:15:02 --> Input Class Initialized
INFO - 2016-06-03 17:15:02 --> Language Class Initialized
INFO - 2016-06-03 17:15:02 --> Loader Class Initialized
INFO - 2016-06-03 17:15:02 --> Helper loaded: form_helper
INFO - 2016-06-03 17:15:02 --> Database Driver Class Initialized
INFO - 2016-06-03 17:15:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:15:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:15:02 --> Email Class Initialized
INFO - 2016-06-03 17:15:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:15:02 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:15:02 --> Helper loaded: language_helper
INFO - 2016-06-03 17:15:02 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:15:02 --> Model Class Initialized
INFO - 2016-06-03 17:15:02 --> Helper loaded: date_helper
INFO - 2016-06-03 17:15:02 --> Controller Class Initialized
INFO - 2016-06-03 17:15:02 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:15:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:15:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:15:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:15:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:15:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:15:02 --> Model Class Initialized
INFO - 2016-06-03 17:15:02 --> Form Validation Class Initialized
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:15:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:15:02 --> Final output sent to browser
DEBUG - 2016-06-03 17:15:02 --> Total execution time: 0.0472
INFO - 2016-06-03 17:15:08 --> Config Class Initialized
INFO - 2016-06-03 17:15:08 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:15:08 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:15:08 --> Utf8 Class Initialized
INFO - 2016-06-03 17:15:08 --> URI Class Initialized
INFO - 2016-06-03 17:15:08 --> Router Class Initialized
INFO - 2016-06-03 17:15:08 --> Output Class Initialized
INFO - 2016-06-03 17:15:08 --> Security Class Initialized
DEBUG - 2016-06-03 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:15:08 --> CSRF cookie sent
INFO - 2016-06-03 17:15:08 --> CSRF token verified
INFO - 2016-06-03 17:15:08 --> Input Class Initialized
INFO - 2016-06-03 17:15:08 --> Language Class Initialized
INFO - 2016-06-03 17:15:08 --> Loader Class Initialized
INFO - 2016-06-03 17:15:08 --> Helper loaded: form_helper
INFO - 2016-06-03 17:15:08 --> Database Driver Class Initialized
INFO - 2016-06-03 17:15:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:15:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:15:08 --> Email Class Initialized
INFO - 2016-06-03 17:15:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:15:08 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:15:08 --> Helper loaded: language_helper
INFO - 2016-06-03 17:15:08 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:15:08 --> Model Class Initialized
INFO - 2016-06-03 17:15:08 --> Helper loaded: date_helper
INFO - 2016-06-03 17:15:08 --> Controller Class Initialized
INFO - 2016-06-03 17:15:08 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:15:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:15:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:15:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:15:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:15:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:15:08 --> Model Class Initialized
INFO - 2016-06-03 17:15:08 --> Form Validation Class Initialized
INFO - 2016-06-03 17:15:08 --> Final output sent to browser
DEBUG - 2016-06-03 17:15:08 --> Total execution time: 0.0496
INFO - 2016-06-03 17:15:50 --> Config Class Initialized
INFO - 2016-06-03 17:15:50 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:15:50 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:15:50 --> Utf8 Class Initialized
INFO - 2016-06-03 17:15:50 --> URI Class Initialized
INFO - 2016-06-03 17:15:50 --> Router Class Initialized
INFO - 2016-06-03 17:15:50 --> Output Class Initialized
INFO - 2016-06-03 17:15:50 --> Security Class Initialized
DEBUG - 2016-06-03 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:15:50 --> CSRF cookie sent
INFO - 2016-06-03 17:15:50 --> CSRF token verified
INFO - 2016-06-03 17:15:50 --> Input Class Initialized
INFO - 2016-06-03 17:15:50 --> Language Class Initialized
INFO - 2016-06-03 17:15:50 --> Loader Class Initialized
INFO - 2016-06-03 17:15:50 --> Helper loaded: form_helper
INFO - 2016-06-03 17:15:50 --> Database Driver Class Initialized
INFO - 2016-06-03 17:15:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:15:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:15:50 --> Email Class Initialized
INFO - 2016-06-03 17:15:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:15:50 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:15:50 --> Helper loaded: language_helper
INFO - 2016-06-03 17:15:50 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:15:50 --> Model Class Initialized
INFO - 2016-06-03 17:15:50 --> Helper loaded: date_helper
INFO - 2016-06-03 17:15:50 --> Controller Class Initialized
INFO - 2016-06-03 17:15:50 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:15:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:15:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:15:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:15:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:15:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:15:50 --> Model Class Initialized
INFO - 2016-06-03 17:15:50 --> Form Validation Class Initialized
INFO - 2016-06-03 17:15:50 --> Final output sent to browser
DEBUG - 2016-06-03 17:15:50 --> Total execution time: 0.0520
INFO - 2016-06-03 17:17:21 --> Config Class Initialized
INFO - 2016-06-03 17:17:21 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:17:21 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:17:21 --> Utf8 Class Initialized
INFO - 2016-06-03 17:17:21 --> URI Class Initialized
INFO - 2016-06-03 17:17:21 --> Router Class Initialized
INFO - 2016-06-03 17:17:21 --> Output Class Initialized
INFO - 2016-06-03 17:17:21 --> Security Class Initialized
DEBUG - 2016-06-03 17:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:17:21 --> CSRF cookie sent
INFO - 2016-06-03 17:17:21 --> Input Class Initialized
INFO - 2016-06-03 17:17:21 --> Language Class Initialized
INFO - 2016-06-03 17:17:21 --> Loader Class Initialized
INFO - 2016-06-03 17:17:21 --> Helper loaded: form_helper
INFO - 2016-06-03 17:17:21 --> Database Driver Class Initialized
INFO - 2016-06-03 17:17:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:17:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:17:21 --> Email Class Initialized
INFO - 2016-06-03 17:17:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:17:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:17:21 --> Helper loaded: language_helper
INFO - 2016-06-03 17:17:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:17:21 --> Model Class Initialized
INFO - 2016-06-03 17:17:21 --> Helper loaded: date_helper
INFO - 2016-06-03 17:17:21 --> Controller Class Initialized
INFO - 2016-06-03 17:17:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:17:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:17:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:17:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:17:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:17:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:17:21 --> Model Class Initialized
INFO - 2016-06-03 17:17:21 --> Form Validation Class Initialized
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:17:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:17:21 --> Final output sent to browser
DEBUG - 2016-06-03 17:17:21 --> Total execution time: 0.0628
INFO - 2016-06-03 17:17:26 --> Config Class Initialized
INFO - 2016-06-03 17:17:26 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:17:26 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:17:26 --> Utf8 Class Initialized
INFO - 2016-06-03 17:17:26 --> URI Class Initialized
INFO - 2016-06-03 17:17:26 --> Router Class Initialized
INFO - 2016-06-03 17:17:26 --> Output Class Initialized
INFO - 2016-06-03 17:17:26 --> Security Class Initialized
DEBUG - 2016-06-03 17:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:17:26 --> CSRF cookie sent
INFO - 2016-06-03 17:17:26 --> CSRF token verified
INFO - 2016-06-03 17:17:26 --> Input Class Initialized
INFO - 2016-06-03 17:17:26 --> Language Class Initialized
INFO - 2016-06-03 17:17:26 --> Loader Class Initialized
INFO - 2016-06-03 17:17:26 --> Helper loaded: form_helper
INFO - 2016-06-03 17:17:26 --> Database Driver Class Initialized
INFO - 2016-06-03 17:17:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:17:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:17:26 --> Email Class Initialized
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:17:26 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:17:26 --> Helper loaded: language_helper
INFO - 2016-06-03 17:17:26 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:17:26 --> Model Class Initialized
INFO - 2016-06-03 17:17:26 --> Helper loaded: date_helper
INFO - 2016-06-03 17:17:26 --> Controller Class Initialized
INFO - 2016-06-03 17:17:26 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:17:26 --> Model Class Initialized
INFO - 2016-06-03 17:17:26 --> Form Validation Class Initialized
INFO - 2016-06-03 17:17:26 --> Final output sent to browser
DEBUG - 2016-06-03 17:17:26 --> Total execution time: 0.0715
INFO - 2016-06-03 17:17:26 --> Config Class Initialized
INFO - 2016-06-03 17:17:26 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:17:26 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:17:26 --> Utf8 Class Initialized
INFO - 2016-06-03 17:17:26 --> URI Class Initialized
INFO - 2016-06-03 17:17:26 --> Router Class Initialized
INFO - 2016-06-03 17:17:26 --> Output Class Initialized
INFO - 2016-06-03 17:17:26 --> Security Class Initialized
DEBUG - 2016-06-03 17:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:17:26 --> CSRF cookie sent
INFO - 2016-06-03 17:17:26 --> Input Class Initialized
INFO - 2016-06-03 17:17:26 --> Language Class Initialized
INFO - 2016-06-03 17:17:26 --> Loader Class Initialized
INFO - 2016-06-03 17:17:26 --> Helper loaded: form_helper
INFO - 2016-06-03 17:17:26 --> Database Driver Class Initialized
INFO - 2016-06-03 17:17:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:17:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:17:26 --> Email Class Initialized
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:17:26 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:17:26 --> Helper loaded: language_helper
INFO - 2016-06-03 17:17:26 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:17:26 --> Model Class Initialized
INFO - 2016-06-03 17:17:26 --> Helper loaded: date_helper
INFO - 2016-06-03 17:17:26 --> Controller Class Initialized
INFO - 2016-06-03 17:17:26 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:17:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:17:26 --> Model Class Initialized
INFO - 2016-06-03 17:17:26 --> Form Validation Class Initialized
DEBUG - 2016-06-03 17:17:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-03 17:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:17:26 --> Final output sent to browser
DEBUG - 2016-06-03 17:17:26 --> Total execution time: 0.0702
INFO - 2016-06-03 17:17:58 --> Config Class Initialized
INFO - 2016-06-03 17:17:58 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:17:58 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:17:58 --> Utf8 Class Initialized
INFO - 2016-06-03 17:17:58 --> URI Class Initialized
INFO - 2016-06-03 17:17:58 --> Router Class Initialized
INFO - 2016-06-03 17:17:58 --> Output Class Initialized
INFO - 2016-06-03 17:17:58 --> Security Class Initialized
DEBUG - 2016-06-03 17:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:17:58 --> CSRF cookie sent
INFO - 2016-06-03 17:17:58 --> CSRF token verified
INFO - 2016-06-03 17:17:58 --> Input Class Initialized
INFO - 2016-06-03 17:17:58 --> Language Class Initialized
INFO - 2016-06-03 17:17:58 --> Loader Class Initialized
INFO - 2016-06-03 17:17:58 --> Helper loaded: form_helper
INFO - 2016-06-03 17:17:58 --> Database Driver Class Initialized
INFO - 2016-06-03 17:17:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:17:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:17:58 --> Email Class Initialized
INFO - 2016-06-03 17:17:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:17:58 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:17:58 --> Helper loaded: language_helper
INFO - 2016-06-03 17:17:58 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:17:58 --> Model Class Initialized
INFO - 2016-06-03 17:17:58 --> Helper loaded: date_helper
INFO - 2016-06-03 17:17:58 --> Controller Class Initialized
INFO - 2016-06-03 17:17:58 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:17:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:17:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:17:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:17:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:17:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:17:58 --> Model Class Initialized
INFO - 2016-06-03 17:17:58 --> Form Validation Class Initialized
DEBUG - 2016-06-03 17:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:17:59 --> Config Class Initialized
INFO - 2016-06-03 17:17:59 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:17:59 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:17:59 --> Utf8 Class Initialized
INFO - 2016-06-03 17:17:59 --> URI Class Initialized
INFO - 2016-06-03 17:17:59 --> Router Class Initialized
INFO - 2016-06-03 17:17:59 --> Output Class Initialized
INFO - 2016-06-03 17:17:59 --> Security Class Initialized
DEBUG - 2016-06-03 17:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:17:59 --> CSRF cookie sent
INFO - 2016-06-03 17:17:59 --> Input Class Initialized
INFO - 2016-06-03 17:17:59 --> Language Class Initialized
INFO - 2016-06-03 17:17:59 --> Loader Class Initialized
INFO - 2016-06-03 17:17:59 --> Helper loaded: form_helper
INFO - 2016-06-03 17:17:59 --> Database Driver Class Initialized
INFO - 2016-06-03 17:17:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:17:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:17:59 --> Email Class Initialized
INFO - 2016-06-03 17:17:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:17:59 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:17:59 --> Helper loaded: language_helper
INFO - 2016-06-03 17:17:59 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:17:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:17:59 --> Model Class Initialized
INFO - 2016-06-03 17:17:59 --> Helper loaded: date_helper
INFO - 2016-06-03 17:17:59 --> Controller Class Initialized
INFO - 2016-06-03 17:17:59 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:17:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:17:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:17:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:17:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:17:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:17:59 --> Model Class Initialized
INFO - 2016-06-03 17:17:59 --> Form Validation Class Initialized
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:17:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:17:59 --> Final output sent to browser
DEBUG - 2016-06-03 17:17:59 --> Total execution time: 0.0842
INFO - 2016-06-03 17:18:03 --> Config Class Initialized
INFO - 2016-06-03 17:18:03 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:18:03 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:18:03 --> Utf8 Class Initialized
INFO - 2016-06-03 17:18:03 --> URI Class Initialized
INFO - 2016-06-03 17:18:03 --> Router Class Initialized
INFO - 2016-06-03 17:18:03 --> Output Class Initialized
INFO - 2016-06-03 17:18:03 --> Security Class Initialized
DEBUG - 2016-06-03 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:18:03 --> CSRF cookie sent
INFO - 2016-06-03 17:18:03 --> CSRF token verified
INFO - 2016-06-03 17:18:03 --> Input Class Initialized
INFO - 2016-06-03 17:18:03 --> Language Class Initialized
INFO - 2016-06-03 17:18:03 --> Loader Class Initialized
INFO - 2016-06-03 17:18:03 --> Helper loaded: form_helper
INFO - 2016-06-03 17:18:03 --> Database Driver Class Initialized
INFO - 2016-06-03 17:18:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:18:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:18:03 --> Email Class Initialized
INFO - 2016-06-03 17:18:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:18:03 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:18:03 --> Helper loaded: language_helper
INFO - 2016-06-03 17:18:03 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:18:03 --> Model Class Initialized
INFO - 2016-06-03 17:18:03 --> Helper loaded: date_helper
INFO - 2016-06-03 17:18:03 --> Controller Class Initialized
INFO - 2016-06-03 17:18:03 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:18:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:18:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:18:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:18:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:18:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:18:03 --> Model Class Initialized
INFO - 2016-06-03 17:18:03 --> Form Validation Class Initialized
INFO - 2016-06-03 17:18:03 --> Final output sent to browser
DEBUG - 2016-06-03 17:18:03 --> Total execution time: 0.0616
INFO - 2016-06-03 17:18:43 --> Config Class Initialized
INFO - 2016-06-03 17:18:43 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:18:43 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:18:43 --> Utf8 Class Initialized
INFO - 2016-06-03 17:18:43 --> URI Class Initialized
INFO - 2016-06-03 17:18:43 --> Router Class Initialized
INFO - 2016-06-03 17:18:43 --> Output Class Initialized
INFO - 2016-06-03 17:18:43 --> Security Class Initialized
DEBUG - 2016-06-03 17:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:18:43 --> CSRF cookie sent
INFO - 2016-06-03 17:18:43 --> Input Class Initialized
INFO - 2016-06-03 17:18:43 --> Language Class Initialized
INFO - 2016-06-03 17:18:43 --> Loader Class Initialized
INFO - 2016-06-03 17:18:43 --> Helper loaded: form_helper
INFO - 2016-06-03 17:18:43 --> Database Driver Class Initialized
INFO - 2016-06-03 17:18:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:18:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:18:43 --> Email Class Initialized
INFO - 2016-06-03 17:18:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:18:43 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:18:43 --> Helper loaded: language_helper
INFO - 2016-06-03 17:18:43 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:18:43 --> Model Class Initialized
INFO - 2016-06-03 17:18:43 --> Helper loaded: date_helper
INFO - 2016-06-03 17:18:43 --> Controller Class Initialized
INFO - 2016-06-03 17:18:43 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:18:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:18:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:18:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:18:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:18:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:18:43 --> Model Class Initialized
INFO - 2016-06-03 17:18:43 --> Form Validation Class Initialized
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:18:43 --> Final output sent to browser
DEBUG - 2016-06-03 17:18:43 --> Total execution time: 0.0949
INFO - 2016-06-03 17:18:49 --> Config Class Initialized
INFO - 2016-06-03 17:18:49 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:18:49 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:18:49 --> Utf8 Class Initialized
INFO - 2016-06-03 17:18:49 --> URI Class Initialized
INFO - 2016-06-03 17:18:49 --> Router Class Initialized
INFO - 2016-06-03 17:18:49 --> Output Class Initialized
INFO - 2016-06-03 17:18:49 --> Security Class Initialized
DEBUG - 2016-06-03 17:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:18:49 --> CSRF cookie sent
INFO - 2016-06-03 17:18:49 --> CSRF token verified
INFO - 2016-06-03 17:18:49 --> Input Class Initialized
INFO - 2016-06-03 17:18:49 --> Language Class Initialized
INFO - 2016-06-03 17:18:49 --> Loader Class Initialized
INFO - 2016-06-03 17:18:49 --> Helper loaded: form_helper
INFO - 2016-06-03 17:18:49 --> Database Driver Class Initialized
INFO - 2016-06-03 17:18:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:18:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:18:49 --> Email Class Initialized
INFO - 2016-06-03 17:18:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:18:49 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:18:49 --> Helper loaded: language_helper
INFO - 2016-06-03 17:18:49 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:18:49 --> Model Class Initialized
INFO - 2016-06-03 17:18:49 --> Helper loaded: date_helper
INFO - 2016-06-03 17:18:49 --> Controller Class Initialized
INFO - 2016-06-03 17:18:49 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:18:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:18:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:18:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:18:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:18:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:18:49 --> Model Class Initialized
INFO - 2016-06-03 17:18:49 --> Form Validation Class Initialized
INFO - 2016-06-03 17:18:49 --> Final output sent to browser
DEBUG - 2016-06-03 17:18:49 --> Total execution time: 0.0237
INFO - 2016-06-03 17:19:23 --> Config Class Initialized
INFO - 2016-06-03 17:19:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:19:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:19:23 --> Utf8 Class Initialized
INFO - 2016-06-03 17:19:23 --> URI Class Initialized
INFO - 2016-06-03 17:19:23 --> Router Class Initialized
INFO - 2016-06-03 17:19:23 --> Output Class Initialized
INFO - 2016-06-03 17:19:23 --> Security Class Initialized
DEBUG - 2016-06-03 17:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:19:23 --> CSRF cookie sent
INFO - 2016-06-03 17:19:23 --> Input Class Initialized
INFO - 2016-06-03 17:19:23 --> Language Class Initialized
INFO - 2016-06-03 17:19:23 --> Loader Class Initialized
INFO - 2016-06-03 17:19:23 --> Helper loaded: form_helper
INFO - 2016-06-03 17:19:23 --> Database Driver Class Initialized
INFO - 2016-06-03 17:19:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:19:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:19:23 --> Email Class Initialized
INFO - 2016-06-03 17:19:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:19:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:19:23 --> Helper loaded: language_helper
INFO - 2016-06-03 17:19:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:23 --> Model Class Initialized
INFO - 2016-06-03 17:19:23 --> Helper loaded: date_helper
INFO - 2016-06-03 17:19:23 --> Controller Class Initialized
INFO - 2016-06-03 17:19:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:19:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:19:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:19:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:19:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:19:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:19:23 --> Model Class Initialized
INFO - 2016-06-03 17:19:23 --> Form Validation Class Initialized
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:19:23 --> Final output sent to browser
DEBUG - 2016-06-03 17:19:23 --> Total execution time: 0.0475
INFO - 2016-06-03 17:19:28 --> Config Class Initialized
INFO - 2016-06-03 17:19:28 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:19:28 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:19:28 --> Utf8 Class Initialized
INFO - 2016-06-03 17:19:28 --> URI Class Initialized
INFO - 2016-06-03 17:19:28 --> Router Class Initialized
INFO - 2016-06-03 17:19:28 --> Output Class Initialized
INFO - 2016-06-03 17:19:28 --> Security Class Initialized
DEBUG - 2016-06-03 17:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:19:28 --> CSRF cookie sent
INFO - 2016-06-03 17:19:28 --> CSRF token verified
INFO - 2016-06-03 17:19:28 --> Input Class Initialized
INFO - 2016-06-03 17:19:28 --> Language Class Initialized
INFO - 2016-06-03 17:19:28 --> Loader Class Initialized
INFO - 2016-06-03 17:19:28 --> Helper loaded: form_helper
INFO - 2016-06-03 17:19:28 --> Database Driver Class Initialized
INFO - 2016-06-03 17:19:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:19:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:19:28 --> Email Class Initialized
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:19:28 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:19:28 --> Helper loaded: language_helper
INFO - 2016-06-03 17:19:28 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:28 --> Model Class Initialized
INFO - 2016-06-03 17:19:28 --> Helper loaded: date_helper
INFO - 2016-06-03 17:19:28 --> Controller Class Initialized
INFO - 2016-06-03 17:19:28 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:19:28 --> Model Class Initialized
INFO - 2016-06-03 17:19:28 --> Form Validation Class Initialized
INFO - 2016-06-03 17:19:28 --> Final output sent to browser
DEBUG - 2016-06-03 17:19:28 --> Total execution time: 0.0164
INFO - 2016-06-03 17:19:28 --> Config Class Initialized
INFO - 2016-06-03 17:19:28 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:19:28 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:19:28 --> Utf8 Class Initialized
INFO - 2016-06-03 17:19:28 --> URI Class Initialized
INFO - 2016-06-03 17:19:28 --> Router Class Initialized
INFO - 2016-06-03 17:19:28 --> Output Class Initialized
INFO - 2016-06-03 17:19:28 --> Security Class Initialized
DEBUG - 2016-06-03 17:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:19:28 --> CSRF cookie sent
INFO - 2016-06-03 17:19:28 --> Input Class Initialized
INFO - 2016-06-03 17:19:28 --> Language Class Initialized
INFO - 2016-06-03 17:19:28 --> Loader Class Initialized
INFO - 2016-06-03 17:19:28 --> Helper loaded: form_helper
INFO - 2016-06-03 17:19:28 --> Database Driver Class Initialized
INFO - 2016-06-03 17:19:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:19:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:19:28 --> Email Class Initialized
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:19:28 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:19:28 --> Helper loaded: language_helper
INFO - 2016-06-03 17:19:28 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:28 --> Model Class Initialized
INFO - 2016-06-03 17:19:28 --> Helper loaded: date_helper
INFO - 2016-06-03 17:19:28 --> Controller Class Initialized
INFO - 2016-06-03 17:19:28 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:19:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:19:28 --> Model Class Initialized
INFO - 2016-06-03 17:19:28 --> Form Validation Class Initialized
DEBUG - 2016-06-03 17:19:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-03 17:19:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:19:28 --> Final output sent to browser
DEBUG - 2016-06-03 17:19:28 --> Total execution time: 0.0245
INFO - 2016-06-03 17:19:38 --> Config Class Initialized
INFO - 2016-06-03 17:19:38 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:19:38 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:19:38 --> Utf8 Class Initialized
INFO - 2016-06-03 17:19:38 --> URI Class Initialized
INFO - 2016-06-03 17:19:38 --> Router Class Initialized
INFO - 2016-06-03 17:19:38 --> Output Class Initialized
INFO - 2016-06-03 17:19:38 --> Security Class Initialized
DEBUG - 2016-06-03 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:19:38 --> CSRF cookie sent
INFO - 2016-06-03 17:19:38 --> CSRF token verified
INFO - 2016-06-03 17:19:38 --> Input Class Initialized
INFO - 2016-06-03 17:19:38 --> Language Class Initialized
INFO - 2016-06-03 17:19:38 --> Loader Class Initialized
INFO - 2016-06-03 17:19:38 --> Helper loaded: form_helper
INFO - 2016-06-03 17:19:38 --> Database Driver Class Initialized
INFO - 2016-06-03 17:19:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:19:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:19:38 --> Email Class Initialized
INFO - 2016-06-03 17:19:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:19:38 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:19:38 --> Helper loaded: language_helper
INFO - 2016-06-03 17:19:38 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:38 --> Model Class Initialized
INFO - 2016-06-03 17:19:38 --> Helper loaded: date_helper
INFO - 2016-06-03 17:19:38 --> Controller Class Initialized
INFO - 2016-06-03 17:19:38 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:19:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:19:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:19:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:19:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:19:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:19:38 --> Model Class Initialized
INFO - 2016-06-03 17:19:38 --> Form Validation Class Initialized
DEBUG - 2016-06-03 17:19:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:42 --> Config Class Initialized
INFO - 2016-06-03 17:19:42 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:19:42 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:19:42 --> Utf8 Class Initialized
INFO - 2016-06-03 17:19:42 --> URI Class Initialized
INFO - 2016-06-03 17:19:42 --> Router Class Initialized
INFO - 2016-06-03 17:19:42 --> Output Class Initialized
INFO - 2016-06-03 17:19:42 --> Security Class Initialized
DEBUG - 2016-06-03 17:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:19:42 --> CSRF cookie sent
INFO - 2016-06-03 17:19:42 --> Input Class Initialized
INFO - 2016-06-03 17:19:42 --> Language Class Initialized
INFO - 2016-06-03 17:19:42 --> Loader Class Initialized
INFO - 2016-06-03 17:19:42 --> Helper loaded: form_helper
INFO - 2016-06-03 17:19:42 --> Database Driver Class Initialized
INFO - 2016-06-03 17:19:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:19:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:19:42 --> Email Class Initialized
INFO - 2016-06-03 17:19:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:19:42 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:19:42 --> Helper loaded: language_helper
INFO - 2016-06-03 17:19:42 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:42 --> Model Class Initialized
INFO - 2016-06-03 17:19:42 --> Helper loaded: date_helper
INFO - 2016-06-03 17:19:42 --> Controller Class Initialized
INFO - 2016-06-03 17:19:42 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:19:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:19:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:19:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:19:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:19:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:19:42 --> Model Class Initialized
INFO - 2016-06-03 17:19:42 --> Form Validation Class Initialized
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:19:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:19:42 --> Final output sent to browser
DEBUG - 2016-06-03 17:19:42 --> Total execution time: 0.0261
INFO - 2016-06-03 17:19:47 --> Config Class Initialized
INFO - 2016-06-03 17:19:47 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:19:47 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:19:47 --> Utf8 Class Initialized
INFO - 2016-06-03 17:19:47 --> URI Class Initialized
INFO - 2016-06-03 17:19:47 --> Router Class Initialized
INFO - 2016-06-03 17:19:47 --> Output Class Initialized
INFO - 2016-06-03 17:19:47 --> Security Class Initialized
DEBUG - 2016-06-03 17:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:19:47 --> CSRF cookie sent
INFO - 2016-06-03 17:19:47 --> CSRF token verified
INFO - 2016-06-03 17:19:47 --> Input Class Initialized
INFO - 2016-06-03 17:19:47 --> Language Class Initialized
INFO - 2016-06-03 17:19:47 --> Loader Class Initialized
INFO - 2016-06-03 17:19:47 --> Helper loaded: form_helper
INFO - 2016-06-03 17:19:47 --> Database Driver Class Initialized
INFO - 2016-06-03 17:19:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:19:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:19:47 --> Email Class Initialized
INFO - 2016-06-03 17:19:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:19:47 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:19:47 --> Helper loaded: language_helper
INFO - 2016-06-03 17:19:47 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:19:47 --> Model Class Initialized
INFO - 2016-06-03 17:19:47 --> Helper loaded: date_helper
INFO - 2016-06-03 17:19:47 --> Controller Class Initialized
INFO - 2016-06-03 17:19:47 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:19:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:19:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:19:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:19:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:19:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:19:47 --> Model Class Initialized
INFO - 2016-06-03 17:19:47 --> Form Validation Class Initialized
INFO - 2016-06-03 17:19:47 --> Final output sent to browser
DEBUG - 2016-06-03 17:19:47 --> Total execution time: 0.0187
INFO - 2016-06-03 17:23:18 --> Config Class Initialized
INFO - 2016-06-03 17:23:18 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:23:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:23:18 --> Utf8 Class Initialized
INFO - 2016-06-03 17:23:18 --> URI Class Initialized
INFO - 2016-06-03 17:23:18 --> Router Class Initialized
INFO - 2016-06-03 17:23:18 --> Output Class Initialized
INFO - 2016-06-03 17:23:18 --> Security Class Initialized
DEBUG - 2016-06-03 17:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:23:18 --> CSRF cookie sent
INFO - 2016-06-03 17:23:18 --> Input Class Initialized
INFO - 2016-06-03 17:23:18 --> Language Class Initialized
INFO - 2016-06-03 17:23:18 --> Loader Class Initialized
INFO - 2016-06-03 17:23:18 --> Helper loaded: form_helper
INFO - 2016-06-03 17:23:18 --> Database Driver Class Initialized
INFO - 2016-06-03 17:23:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:23:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:23:18 --> Email Class Initialized
INFO - 2016-06-03 17:23:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:23:18 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:23:18 --> Helper loaded: language_helper
INFO - 2016-06-03 17:23:18 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:23:18 --> Model Class Initialized
INFO - 2016-06-03 17:23:18 --> Helper loaded: date_helper
INFO - 2016-06-03 17:23:18 --> Controller Class Initialized
INFO - 2016-06-03 17:23:18 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:23:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:23:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:23:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:23:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:23:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:23:18 --> Model Class Initialized
INFO - 2016-06-03 17:23:18 --> Form Validation Class Initialized
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 17:23:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 17:23:18 --> Final output sent to browser
DEBUG - 2016-06-03 17:23:18 --> Total execution time: 0.0639
INFO - 2016-06-03 17:23:22 --> Config Class Initialized
INFO - 2016-06-03 17:23:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:23:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:23:22 --> Utf8 Class Initialized
INFO - 2016-06-03 17:23:22 --> URI Class Initialized
INFO - 2016-06-03 17:23:22 --> Router Class Initialized
INFO - 2016-06-03 17:23:22 --> Output Class Initialized
INFO - 2016-06-03 17:23:22 --> Security Class Initialized
DEBUG - 2016-06-03 17:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:23:22 --> CSRF cookie sent
INFO - 2016-06-03 17:23:22 --> CSRF token verified
INFO - 2016-06-03 17:23:22 --> Input Class Initialized
INFO - 2016-06-03 17:23:22 --> Language Class Initialized
INFO - 2016-06-03 17:23:22 --> Loader Class Initialized
INFO - 2016-06-03 17:23:22 --> Helper loaded: form_helper
INFO - 2016-06-03 17:23:22 --> Database Driver Class Initialized
INFO - 2016-06-03 17:23:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:23:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:23:22 --> Email Class Initialized
INFO - 2016-06-03 17:23:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:23:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:23:22 --> Helper loaded: language_helper
INFO - 2016-06-03 17:23:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:23:22 --> Model Class Initialized
INFO - 2016-06-03 17:23:22 --> Helper loaded: date_helper
INFO - 2016-06-03 17:23:22 --> Controller Class Initialized
INFO - 2016-06-03 17:23:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:23:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:23:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:23:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:23:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:23:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:23:22 --> Model Class Initialized
INFO - 2016-06-03 17:23:22 --> Form Validation Class Initialized
INFO - 2016-06-03 17:23:22 --> Final output sent to browser
DEBUG - 2016-06-03 17:23:22 --> Total execution time: 0.0314
INFO - 2016-06-03 17:23:34 --> Config Class Initialized
INFO - 2016-06-03 17:23:34 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:23:34 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:23:34 --> Utf8 Class Initialized
INFO - 2016-06-03 17:23:34 --> URI Class Initialized
INFO - 2016-06-03 17:23:34 --> Router Class Initialized
INFO - 2016-06-03 17:23:34 --> Output Class Initialized
INFO - 2016-06-03 17:23:34 --> Security Class Initialized
DEBUG - 2016-06-03 17:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:23:34 --> CSRF cookie sent
INFO - 2016-06-03 17:23:34 --> CSRF token verified
INFO - 2016-06-03 17:23:34 --> Input Class Initialized
INFO - 2016-06-03 17:23:34 --> Language Class Initialized
INFO - 2016-06-03 17:23:34 --> Loader Class Initialized
INFO - 2016-06-03 17:23:34 --> Helper loaded: form_helper
INFO - 2016-06-03 17:23:34 --> Database Driver Class Initialized
INFO - 2016-06-03 17:23:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:23:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:23:34 --> Email Class Initialized
INFO - 2016-06-03 17:23:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:23:34 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:23:34 --> Helper loaded: language_helper
INFO - 2016-06-03 17:23:34 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:23:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:23:34 --> Model Class Initialized
INFO - 2016-06-03 17:23:34 --> Helper loaded: date_helper
INFO - 2016-06-03 17:23:34 --> Controller Class Initialized
INFO - 2016-06-03 17:23:34 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:23:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:23:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:23:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:23:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:23:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:23:34 --> Model Class Initialized
INFO - 2016-06-03 17:23:34 --> Form Validation Class Initialized
INFO - 2016-06-03 17:23:34 --> Final output sent to browser
DEBUG - 2016-06-03 17:23:34 --> Total execution time: 0.0621
INFO - 2016-06-03 17:23:41 --> Config Class Initialized
INFO - 2016-06-03 17:23:41 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:23:41 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:23:41 --> Utf8 Class Initialized
INFO - 2016-06-03 17:23:41 --> URI Class Initialized
INFO - 2016-06-03 17:23:41 --> Router Class Initialized
INFO - 2016-06-03 17:23:41 --> Output Class Initialized
INFO - 2016-06-03 17:23:41 --> Security Class Initialized
DEBUG - 2016-06-03 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:23:41 --> CSRF cookie sent
INFO - 2016-06-03 17:23:41 --> CSRF token verified
INFO - 2016-06-03 17:23:41 --> Input Class Initialized
INFO - 2016-06-03 17:23:41 --> Language Class Initialized
INFO - 2016-06-03 17:23:41 --> Loader Class Initialized
INFO - 2016-06-03 17:23:41 --> Helper loaded: form_helper
INFO - 2016-06-03 17:23:41 --> Database Driver Class Initialized
INFO - 2016-06-03 17:23:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:23:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:23:41 --> Email Class Initialized
INFO - 2016-06-03 17:23:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:23:41 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:23:41 --> Helper loaded: language_helper
INFO - 2016-06-03 17:23:41 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:23:41 --> Model Class Initialized
INFO - 2016-06-03 17:23:41 --> Helper loaded: date_helper
INFO - 2016-06-03 17:23:41 --> Controller Class Initialized
INFO - 2016-06-03 17:23:41 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:23:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:23:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:23:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:23:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:23:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 17:23:41 --> Model Class Initialized
INFO - 2016-06-03 17:23:41 --> Form Validation Class Initialized
INFO - 2016-06-03 17:23:41 --> Final output sent to browser
DEBUG - 2016-06-03 17:23:41 --> Total execution time: 0.0599
INFO - 2016-06-03 17:41:04 --> Config Class Initialized
INFO - 2016-06-03 17:41:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:41:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:41:04 --> Utf8 Class Initialized
INFO - 2016-06-03 17:41:04 --> URI Class Initialized
INFO - 2016-06-03 17:41:04 --> Router Class Initialized
INFO - 2016-06-03 17:41:04 --> Output Class Initialized
INFO - 2016-06-03 17:41:04 --> Security Class Initialized
DEBUG - 2016-06-03 17:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:41:04 --> CSRF cookie sent
INFO - 2016-06-03 17:41:04 --> Input Class Initialized
INFO - 2016-06-03 17:41:04 --> Language Class Initialized
INFO - 2016-06-03 17:41:04 --> Loader Class Initialized
INFO - 2016-06-03 17:41:04 --> Helper loaded: form_helper
INFO - 2016-06-03 17:41:04 --> Database Driver Class Initialized
INFO - 2016-06-03 17:41:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:41:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:41:04 --> Email Class Initialized
INFO - 2016-06-03 17:41:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:41:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:41:04 --> Helper loaded: language_helper
INFO - 2016-06-03 17:41:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:41:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:41:04 --> Model Class Initialized
INFO - 2016-06-03 17:41:04 --> Helper loaded: date_helper
INFO - 2016-06-03 17:41:04 --> Controller Class Initialized
INFO - 2016-06-03 17:41:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:41:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:41:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:41:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:41:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:41:04 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 17:41:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:41:04 --> Form Validation Class Initialized
INFO - 2016-06-03 17:41:05 --> Config Class Initialized
INFO - 2016-06-03 17:41:05 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:41:05 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:41:05 --> Utf8 Class Initialized
INFO - 2016-06-03 17:41:05 --> URI Class Initialized
INFO - 2016-06-03 17:41:05 --> Router Class Initialized
INFO - 2016-06-03 17:41:05 --> Output Class Initialized
INFO - 2016-06-03 17:41:05 --> Security Class Initialized
DEBUG - 2016-06-03 17:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:41:05 --> CSRF cookie sent
INFO - 2016-06-03 17:41:05 --> Input Class Initialized
INFO - 2016-06-03 17:41:05 --> Language Class Initialized
INFO - 2016-06-03 17:41:05 --> Loader Class Initialized
INFO - 2016-06-03 17:41:05 --> Helper loaded: form_helper
INFO - 2016-06-03 17:41:05 --> Database Driver Class Initialized
INFO - 2016-06-03 17:41:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:41:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:41:05 --> Email Class Initialized
INFO - 2016-06-03 17:41:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:41:05 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:41:05 --> Helper loaded: language_helper
INFO - 2016-06-03 17:41:05 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:41:05 --> Model Class Initialized
INFO - 2016-06-03 17:41:05 --> Helper loaded: date_helper
INFO - 2016-06-03 17:41:05 --> Controller Class Initialized
INFO - 2016-06-03 17:41:05 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:41:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:41:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:41:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:41:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:41:05 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 17:41:05 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:41:05 --> Form Validation Class Initialized
ERROR - 2016-06-03 17:41:05 --> Severity: Warning --> include_once(/home/demis/www/platformadiabet/securimage/securimage.php): failed to open stream: No such file or directory /home/demis/www/platformadiabet/application/controllers/Auth.php 60
ERROR - 2016-06-03 17:41:05 --> Severity: Warning --> include_once(): Failed opening '/home/demis/www/platformadiabet/securimage/securimage.php' for inclusion (include_path='.:/usr/share/php:/usr/share/pear:') /home/demis/www/platformadiabet/application/controllers/Auth.php 60
ERROR - 2016-06-03 17:41:05 --> Severity: Error --> Class 'Securimage' not found /home/demis/www/platformadiabet/application/controllers/Auth.php 61
INFO - 2016-06-03 17:42:43 --> Config Class Initialized
INFO - 2016-06-03 17:42:43 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:42:43 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:42:43 --> Utf8 Class Initialized
INFO - 2016-06-03 17:42:43 --> URI Class Initialized
INFO - 2016-06-03 17:42:43 --> Router Class Initialized
INFO - 2016-06-03 17:42:43 --> Output Class Initialized
INFO - 2016-06-03 17:42:43 --> Security Class Initialized
DEBUG - 2016-06-03 17:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:42:43 --> CSRF cookie sent
INFO - 2016-06-03 17:42:43 --> Input Class Initialized
INFO - 2016-06-03 17:42:43 --> Language Class Initialized
INFO - 2016-06-03 17:42:43 --> Loader Class Initialized
INFO - 2016-06-03 17:42:43 --> Helper loaded: form_helper
INFO - 2016-06-03 17:42:43 --> Database Driver Class Initialized
INFO - 2016-06-03 17:42:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:42:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:42:43 --> Email Class Initialized
INFO - 2016-06-03 17:42:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:42:43 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:42:43 --> Helper loaded: language_helper
INFO - 2016-06-03 17:42:43 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:42:43 --> Model Class Initialized
INFO - 2016-06-03 17:42:43 --> Helper loaded: date_helper
INFO - 2016-06-03 17:42:43 --> Controller Class Initialized
INFO - 2016-06-03 17:42:43 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:42:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:42:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:42:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:42:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:42:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 17:42:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:42:43 --> Form Validation Class Initialized
INFO - 2016-06-03 17:42:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
ERROR - 2016-06-03 17:42:43 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/demis/www/platformadiabet/application/views/auth/login.php 1
INFO - 2016-06-03 17:42:43 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 17:42:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 17:42:43 --> Final output sent to browser
DEBUG - 2016-06-03 17:42:43 --> Total execution time: 0.0917
INFO - 2016-06-03 17:43:05 --> Config Class Initialized
INFO - 2016-06-03 17:43:05 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:43:05 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:43:05 --> Utf8 Class Initialized
INFO - 2016-06-03 17:43:05 --> URI Class Initialized
INFO - 2016-06-03 17:43:05 --> Router Class Initialized
INFO - 2016-06-03 17:43:05 --> Output Class Initialized
INFO - 2016-06-03 17:43:05 --> Security Class Initialized
DEBUG - 2016-06-03 17:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:43:05 --> CSRF cookie sent
INFO - 2016-06-03 17:43:05 --> Input Class Initialized
INFO - 2016-06-03 17:43:05 --> Language Class Initialized
INFO - 2016-06-03 17:43:05 --> Loader Class Initialized
INFO - 2016-06-03 17:43:05 --> Helper loaded: form_helper
INFO - 2016-06-03 17:43:05 --> Database Driver Class Initialized
INFO - 2016-06-03 17:43:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 17:43:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 17:43:05 --> Email Class Initialized
INFO - 2016-06-03 17:43:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 17:43:05 --> Helper loaded: cookie_helper
INFO - 2016-06-03 17:43:05 --> Helper loaded: language_helper
INFO - 2016-06-03 17:43:05 --> Helper loaded: url_helper
DEBUG - 2016-06-03 17:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:43:05 --> Model Class Initialized
INFO - 2016-06-03 17:43:05 --> Helper loaded: date_helper
INFO - 2016-06-03 17:43:05 --> Controller Class Initialized
INFO - 2016-06-03 17:43:05 --> Helper loaded: languages_helper
INFO - 2016-06-03 17:43:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 17:43:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 17:43:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 17:43:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 17:43:05 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 17:43:05 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 17:43:05 --> Form Validation Class Initialized
INFO - 2016-06-03 17:43:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 17:43:05 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 17:43:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 17:43:05 --> Final output sent to browser
DEBUG - 2016-06-03 17:43:05 --> Total execution time: 0.0553
INFO - 2016-06-03 17:43:06 --> Config Class Initialized
INFO - 2016-06-03 17:43:06 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:43:06 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:43:06 --> Utf8 Class Initialized
INFO - 2016-06-03 17:43:06 --> URI Class Initialized
INFO - 2016-06-03 17:43:06 --> Router Class Initialized
INFO - 2016-06-03 17:43:06 --> Output Class Initialized
INFO - 2016-06-03 17:43:06 --> Security Class Initialized
DEBUG - 2016-06-03 17:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:43:06 --> CSRF cookie sent
INFO - 2016-06-03 17:43:06 --> Input Class Initialized
INFO - 2016-06-03 17:43:06 --> Language Class Initialized
ERROR - 2016-06-03 17:43:06 --> 404 Page Not Found: Index/securimage
INFO - 2016-06-03 17:43:07 --> Config Class Initialized
INFO - 2016-06-03 17:43:07 --> Hooks Class Initialized
DEBUG - 2016-06-03 17:43:07 --> UTF-8 Support Enabled
INFO - 2016-06-03 17:43:07 --> Utf8 Class Initialized
INFO - 2016-06-03 17:43:07 --> URI Class Initialized
INFO - 2016-06-03 17:43:07 --> Router Class Initialized
INFO - 2016-06-03 17:43:07 --> Output Class Initialized
INFO - 2016-06-03 17:43:07 --> Security Class Initialized
DEBUG - 2016-06-03 17:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 17:43:07 --> CSRF cookie sent
INFO - 2016-06-03 17:43:07 --> Input Class Initialized
INFO - 2016-06-03 17:43:07 --> Language Class Initialized
ERROR - 2016-06-03 17:43:07 --> 404 Page Not Found: Index/securimage
INFO - 2016-06-03 18:23:00 --> Config Class Initialized
INFO - 2016-06-03 18:23:00 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:23:00 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:23:00 --> Utf8 Class Initialized
INFO - 2016-06-03 18:23:00 --> URI Class Initialized
INFO - 2016-06-03 18:23:00 --> Router Class Initialized
INFO - 2016-06-03 18:23:00 --> Output Class Initialized
INFO - 2016-06-03 18:23:00 --> Security Class Initialized
DEBUG - 2016-06-03 18:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:23:00 --> CSRF cookie sent
INFO - 2016-06-03 18:23:00 --> Input Class Initialized
INFO - 2016-06-03 18:23:00 --> Language Class Initialized
INFO - 2016-06-03 18:23:00 --> Loader Class Initialized
INFO - 2016-06-03 18:23:00 --> Helper loaded: form_helper
INFO - 2016-06-03 18:23:00 --> Database Driver Class Initialized
INFO - 2016-06-03 18:23:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:23:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:23:00 --> Email Class Initialized
INFO - 2016-06-03 18:23:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:23:00 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:23:00 --> Helper loaded: language_helper
INFO - 2016-06-03 18:23:00 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:23:00 --> Model Class Initialized
INFO - 2016-06-03 18:23:00 --> Helper loaded: date_helper
INFO - 2016-06-03 18:23:00 --> Controller Class Initialized
INFO - 2016-06-03 18:23:00 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:23:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:23:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:23:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:23:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:23:00 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:23:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:23:00 --> Form Validation Class Initialized
ERROR - 2016-06-03 18:23:00 --> Severity: Notice --> Undefined index: captcha_code /home/demis/www/platformadiabet/application/controllers/Auth.php 67
INFO - 2016-06-03 18:23:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
ERROR - 2016-06-03 18:23:00 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/demis/www/platformadiabet/application/views/auth/login.php 1
INFO - 2016-06-03 18:23:00 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:23:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:23:00 --> Final output sent to browser
DEBUG - 2016-06-03 18:23:00 --> Total execution time: 0.0932
INFO - 2016-06-03 18:24:02 --> Config Class Initialized
INFO - 2016-06-03 18:24:02 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:24:02 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:24:02 --> Utf8 Class Initialized
INFO - 2016-06-03 18:24:02 --> URI Class Initialized
INFO - 2016-06-03 18:24:02 --> Router Class Initialized
INFO - 2016-06-03 18:24:02 --> Output Class Initialized
INFO - 2016-06-03 18:24:02 --> Security Class Initialized
DEBUG - 2016-06-03 18:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:24:02 --> CSRF cookie sent
INFO - 2016-06-03 18:24:02 --> Input Class Initialized
INFO - 2016-06-03 18:24:02 --> Language Class Initialized
INFO - 2016-06-03 18:24:02 --> Loader Class Initialized
INFO - 2016-06-03 18:24:02 --> Helper loaded: form_helper
INFO - 2016-06-03 18:24:02 --> Database Driver Class Initialized
INFO - 2016-06-03 18:24:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:24:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:24:02 --> Email Class Initialized
INFO - 2016-06-03 18:24:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:24:02 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:24:02 --> Helper loaded: language_helper
INFO - 2016-06-03 18:24:02 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:24:02 --> Model Class Initialized
INFO - 2016-06-03 18:24:02 --> Helper loaded: date_helper
INFO - 2016-06-03 18:24:02 --> Controller Class Initialized
INFO - 2016-06-03 18:24:02 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:24:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:24:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:24:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:24:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:24:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:24:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:24:02 --> Form Validation Class Initialized
INFO - 2016-06-03 18:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
ERROR - 2016-06-03 18:24:02 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/demis/www/platformadiabet/application/views/auth/login.php 1
INFO - 2016-06-03 18:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:24:02 --> Final output sent to browser
DEBUG - 2016-06-03 18:24:02 --> Total execution time: 0.0253
INFO - 2016-06-03 18:24:28 --> Config Class Initialized
INFO - 2016-06-03 18:24:28 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:24:28 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:24:28 --> Utf8 Class Initialized
INFO - 2016-06-03 18:24:28 --> URI Class Initialized
INFO - 2016-06-03 18:24:28 --> Router Class Initialized
INFO - 2016-06-03 18:24:28 --> Output Class Initialized
INFO - 2016-06-03 18:24:28 --> Security Class Initialized
DEBUG - 2016-06-03 18:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:24:28 --> CSRF cookie sent
INFO - 2016-06-03 18:24:28 --> Input Class Initialized
INFO - 2016-06-03 18:24:28 --> Language Class Initialized
INFO - 2016-06-03 18:24:28 --> Loader Class Initialized
INFO - 2016-06-03 18:24:28 --> Helper loaded: form_helper
INFO - 2016-06-03 18:24:28 --> Database Driver Class Initialized
INFO - 2016-06-03 18:24:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:24:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:24:28 --> Email Class Initialized
INFO - 2016-06-03 18:24:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:24:28 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:24:28 --> Helper loaded: language_helper
INFO - 2016-06-03 18:24:28 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:24:28 --> Model Class Initialized
INFO - 2016-06-03 18:24:28 --> Helper loaded: date_helper
INFO - 2016-06-03 18:24:28 --> Controller Class Initialized
INFO - 2016-06-03 18:24:28 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:24:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:24:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:24:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:24:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:24:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:24:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:24:28 --> Form Validation Class Initialized
INFO - 2016-06-03 18:24:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:24:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:24:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:24:28 --> Final output sent to browser
DEBUG - 2016-06-03 18:24:28 --> Total execution time: 0.1193
INFO - 2016-06-03 18:34:53 --> Config Class Initialized
INFO - 2016-06-03 18:34:53 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:34:53 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:34:53 --> Utf8 Class Initialized
INFO - 2016-06-03 18:34:53 --> URI Class Initialized
INFO - 2016-06-03 18:34:53 --> Router Class Initialized
INFO - 2016-06-03 18:34:53 --> Output Class Initialized
INFO - 2016-06-03 18:34:53 --> Security Class Initialized
DEBUG - 2016-06-03 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:34:53 --> CSRF cookie sent
INFO - 2016-06-03 18:34:53 --> Input Class Initialized
INFO - 2016-06-03 18:34:53 --> Language Class Initialized
INFO - 2016-06-03 18:34:53 --> Loader Class Initialized
INFO - 2016-06-03 18:34:53 --> Helper loaded: form_helper
INFO - 2016-06-03 18:34:53 --> Database Driver Class Initialized
INFO - 2016-06-03 18:34:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:34:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:34:53 --> Email Class Initialized
INFO - 2016-06-03 18:34:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:34:53 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:34:53 --> Helper loaded: language_helper
INFO - 2016-06-03 18:34:53 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:34:53 --> Model Class Initialized
INFO - 2016-06-03 18:34:53 --> Helper loaded: date_helper
INFO - 2016-06-03 18:34:53 --> Controller Class Initialized
INFO - 2016-06-03 18:34:53 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:34:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:34:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:34:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:34:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:34:53 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:34:53 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:34:53 --> Form Validation Class Initialized
INFO - 2016-06-03 18:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:34:53 --> Final output sent to browser
DEBUG - 2016-06-03 18:34:53 --> Total execution time: 0.0885
INFO - 2016-06-03 18:35:06 --> Config Class Initialized
INFO - 2016-06-03 18:35:06 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:35:06 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:35:06 --> Utf8 Class Initialized
INFO - 2016-06-03 18:35:06 --> URI Class Initialized
INFO - 2016-06-03 18:35:06 --> Router Class Initialized
INFO - 2016-06-03 18:35:06 --> Output Class Initialized
INFO - 2016-06-03 18:35:06 --> Security Class Initialized
DEBUG - 2016-06-03 18:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:35:06 --> CSRF cookie sent
INFO - 2016-06-03 18:35:06 --> CSRF token verified
INFO - 2016-06-03 18:35:06 --> Input Class Initialized
INFO - 2016-06-03 18:35:06 --> Language Class Initialized
INFO - 2016-06-03 18:35:06 --> Loader Class Initialized
INFO - 2016-06-03 18:35:06 --> Helper loaded: form_helper
INFO - 2016-06-03 18:35:06 --> Database Driver Class Initialized
INFO - 2016-06-03 18:35:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:35:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:35:06 --> Email Class Initialized
INFO - 2016-06-03 18:35:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:35:06 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:35:06 --> Helper loaded: language_helper
INFO - 2016-06-03 18:35:06 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:35:06 --> Model Class Initialized
INFO - 2016-06-03 18:35:06 --> Helper loaded: date_helper
INFO - 2016-06-03 18:35:06 --> Controller Class Initialized
INFO - 2016-06-03 18:35:06 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:35:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:35:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:35:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:35:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:35:06 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:35:06 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:35:06 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:35:06 --> Unable to find callback validation rule: captcha_check
ERROR - 2016-06-03 18:35:06 --> Could not find the language line "form_validation_captcha_check"
INFO - 2016-06-03 18:35:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:35:06 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:35:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:35:06 --> Final output sent to browser
DEBUG - 2016-06-03 18:35:06 --> Total execution time: 0.0574
INFO - 2016-06-03 18:37:07 --> Config Class Initialized
INFO - 2016-06-03 18:37:07 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:37:07 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:37:07 --> Utf8 Class Initialized
INFO - 2016-06-03 18:37:07 --> URI Class Initialized
INFO - 2016-06-03 18:37:07 --> Router Class Initialized
INFO - 2016-06-03 18:37:07 --> Output Class Initialized
INFO - 2016-06-03 18:37:07 --> Security Class Initialized
DEBUG - 2016-06-03 18:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:37:07 --> CSRF cookie sent
INFO - 2016-06-03 18:37:07 --> CSRF token verified
INFO - 2016-06-03 18:37:07 --> Input Class Initialized
INFO - 2016-06-03 18:37:07 --> Language Class Initialized
INFO - 2016-06-03 18:37:07 --> Loader Class Initialized
INFO - 2016-06-03 18:37:07 --> Helper loaded: form_helper
INFO - 2016-06-03 18:37:07 --> Database Driver Class Initialized
INFO - 2016-06-03 18:37:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:37:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:37:07 --> Email Class Initialized
INFO - 2016-06-03 18:37:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:37:07 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:37:07 --> Helper loaded: language_helper
INFO - 2016-06-03 18:37:07 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:37:07 --> Model Class Initialized
INFO - 2016-06-03 18:37:07 --> Helper loaded: date_helper
INFO - 2016-06-03 18:37:07 --> Controller Class Initialized
INFO - 2016-06-03 18:37:07 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:37:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:37:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:37:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:37:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:37:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:37:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:37:07 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:37:07 --> Unable to find callback validation rule: captcha_check
ERROR - 2016-06-03 18:37:07 --> Could not find the language line "form_validation_captcha_check"
INFO - 2016-06-03 18:37:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:37:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:37:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:37:07 --> Final output sent to browser
DEBUG - 2016-06-03 18:37:07 --> Total execution time: 0.0377
INFO - 2016-06-03 18:37:22 --> Config Class Initialized
INFO - 2016-06-03 18:37:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:37:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:37:22 --> Utf8 Class Initialized
INFO - 2016-06-03 18:37:22 --> URI Class Initialized
INFO - 2016-06-03 18:37:22 --> Router Class Initialized
INFO - 2016-06-03 18:37:22 --> Output Class Initialized
INFO - 2016-06-03 18:37:22 --> Security Class Initialized
DEBUG - 2016-06-03 18:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:37:32 --> Config Class Initialized
INFO - 2016-06-03 18:37:32 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:37:32 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:37:32 --> Utf8 Class Initialized
INFO - 2016-06-03 18:37:32 --> URI Class Initialized
INFO - 2016-06-03 18:37:32 --> Router Class Initialized
INFO - 2016-06-03 18:37:32 --> Output Class Initialized
INFO - 2016-06-03 18:37:32 --> Security Class Initialized
DEBUG - 2016-06-03 18:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:37:32 --> CSRF cookie sent
INFO - 2016-06-03 18:37:32 --> Input Class Initialized
INFO - 2016-06-03 18:37:32 --> Language Class Initialized
INFO - 2016-06-03 18:37:32 --> Loader Class Initialized
INFO - 2016-06-03 18:37:32 --> Helper loaded: form_helper
INFO - 2016-06-03 18:37:32 --> Database Driver Class Initialized
INFO - 2016-06-03 18:37:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:37:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:37:32 --> Email Class Initialized
INFO - 2016-06-03 18:37:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:37:32 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:37:32 --> Helper loaded: language_helper
INFO - 2016-06-03 18:37:32 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:37:32 --> Model Class Initialized
INFO - 2016-06-03 18:37:32 --> Helper loaded: date_helper
INFO - 2016-06-03 18:37:32 --> Controller Class Initialized
INFO - 2016-06-03 18:37:32 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:37:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:37:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:37:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:37:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:37:32 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:37:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:37:32 --> Form Validation Class Initialized
INFO - 2016-06-03 18:37:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:37:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:37:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:37:32 --> Final output sent to browser
DEBUG - 2016-06-03 18:37:32 --> Total execution time: 0.0356
INFO - 2016-06-03 18:37:45 --> Config Class Initialized
INFO - 2016-06-03 18:37:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:37:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:37:45 --> Utf8 Class Initialized
INFO - 2016-06-03 18:37:45 --> URI Class Initialized
INFO - 2016-06-03 18:37:45 --> Router Class Initialized
INFO - 2016-06-03 18:37:45 --> Output Class Initialized
INFO - 2016-06-03 18:37:45 --> Security Class Initialized
DEBUG - 2016-06-03 18:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:37:45 --> CSRF cookie sent
INFO - 2016-06-03 18:37:45 --> CSRF token verified
INFO - 2016-06-03 18:37:45 --> Input Class Initialized
INFO - 2016-06-03 18:37:45 --> Language Class Initialized
INFO - 2016-06-03 18:37:45 --> Loader Class Initialized
INFO - 2016-06-03 18:37:45 --> Helper loaded: form_helper
INFO - 2016-06-03 18:37:45 --> Database Driver Class Initialized
INFO - 2016-06-03 18:37:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:37:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:37:45 --> Email Class Initialized
INFO - 2016-06-03 18:37:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:37:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:37:45 --> Helper loaded: language_helper
INFO - 2016-06-03 18:37:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:37:45 --> Model Class Initialized
INFO - 2016-06-03 18:37:45 --> Helper loaded: date_helper
INFO - 2016-06-03 18:37:45 --> Controller Class Initialized
INFO - 2016-06-03 18:37:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:37:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:37:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:37:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:37:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:37:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:37:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:37:45 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:37:45 --> Unable to find callback validation rule: captcha_check
ERROR - 2016-06-03 18:37:45 --> Could not find the language line "form_validation_captcha_check"
INFO - 2016-06-03 18:37:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:37:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:37:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:37:45 --> Final output sent to browser
DEBUG - 2016-06-03 18:37:45 --> Total execution time: 0.0185
INFO - 2016-06-03 18:41:08 --> Config Class Initialized
INFO - 2016-06-03 18:41:08 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:08 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:08 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:08 --> URI Class Initialized
INFO - 2016-06-03 18:41:08 --> Router Class Initialized
INFO - 2016-06-03 18:41:08 --> Output Class Initialized
INFO - 2016-06-03 18:41:08 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:08 --> CSRF cookie sent
INFO - 2016-06-03 18:41:08 --> CSRF token verified
INFO - 2016-06-03 18:41:08 --> Input Class Initialized
INFO - 2016-06-03 18:41:08 --> Language Class Initialized
INFO - 2016-06-03 18:41:08 --> Loader Class Initialized
INFO - 2016-06-03 18:41:08 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:08 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:08 --> Email Class Initialized
INFO - 2016-06-03 18:41:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:08 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:08 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:08 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:08 --> Model Class Initialized
INFO - 2016-06-03 18:41:08 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:08 --> Controller Class Initialized
INFO - 2016-06-03 18:41:08 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:08 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:41:08 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:08 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:09 --> Config Class Initialized
INFO - 2016-06-03 18:41:09 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:09 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:09 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:09 --> URI Class Initialized
DEBUG - 2016-06-03 18:41:09 --> No URI present. Default controller set.
INFO - 2016-06-03 18:41:09 --> Router Class Initialized
INFO - 2016-06-03 18:41:09 --> Output Class Initialized
INFO - 2016-06-03 18:41:09 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:09 --> CSRF cookie sent
INFO - 2016-06-03 18:41:09 --> Input Class Initialized
INFO - 2016-06-03 18:41:09 --> Language Class Initialized
INFO - 2016-06-03 18:41:09 --> Loader Class Initialized
INFO - 2016-06-03 18:41:09 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:09 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:09 --> Email Class Initialized
INFO - 2016-06-03 18:41:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:09 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:09 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:09 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:09 --> Model Class Initialized
INFO - 2016-06-03 18:41:09 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:09 --> Controller Class Initialized
INFO - 2016-06-03 18:41:09 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:41:10 --> Config Class Initialized
INFO - 2016-06-03 18:41:10 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:10 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:10 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:10 --> URI Class Initialized
INFO - 2016-06-03 18:41:10 --> Router Class Initialized
INFO - 2016-06-03 18:41:10 --> Output Class Initialized
INFO - 2016-06-03 18:41:10 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:10 --> CSRF cookie sent
INFO - 2016-06-03 18:41:10 --> Input Class Initialized
INFO - 2016-06-03 18:41:10 --> Language Class Initialized
INFO - 2016-06-03 18:41:10 --> Loader Class Initialized
INFO - 2016-06-03 18:41:10 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:10 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:10 --> Email Class Initialized
INFO - 2016-06-03 18:41:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:10 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:10 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:10 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:10 --> Model Class Initialized
INFO - 2016-06-03 18:41:10 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:10 --> Controller Class Initialized
INFO - 2016-06-03 18:41:10 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:41:10 --> Model Class Initialized
INFO - 2016-06-03 18:41:10 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 18:41:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 18:41:10 --> Final output sent to browser
DEBUG - 2016-06-03 18:41:10 --> Total execution time: 0.0442
INFO - 2016-06-03 18:41:15 --> Config Class Initialized
INFO - 2016-06-03 18:41:15 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:15 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:15 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:15 --> URI Class Initialized
INFO - 2016-06-03 18:41:15 --> Router Class Initialized
INFO - 2016-06-03 18:41:15 --> Output Class Initialized
INFO - 2016-06-03 18:41:15 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:15 --> CSRF cookie sent
INFO - 2016-06-03 18:41:15 --> CSRF token verified
INFO - 2016-06-03 18:41:15 --> Input Class Initialized
INFO - 2016-06-03 18:41:15 --> Language Class Initialized
INFO - 2016-06-03 18:41:15 --> Loader Class Initialized
INFO - 2016-06-03 18:41:15 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:15 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:15 --> Email Class Initialized
INFO - 2016-06-03 18:41:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:15 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:15 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:15 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:15 --> Model Class Initialized
INFO - 2016-06-03 18:41:15 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:15 --> Controller Class Initialized
INFO - 2016-06-03 18:41:15 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:41:15 --> Model Class Initialized
INFO - 2016-06-03 18:41:15 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:15 --> Final output sent to browser
DEBUG - 2016-06-03 18:41:15 --> Total execution time: 0.0391
INFO - 2016-06-03 18:41:20 --> Config Class Initialized
INFO - 2016-06-03 18:41:20 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:20 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:20 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:20 --> URI Class Initialized
INFO - 2016-06-03 18:41:20 --> Router Class Initialized
INFO - 2016-06-03 18:41:20 --> Output Class Initialized
INFO - 2016-06-03 18:41:20 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:20 --> CSRF cookie sent
INFO - 2016-06-03 18:41:20 --> Input Class Initialized
INFO - 2016-06-03 18:41:20 --> Language Class Initialized
INFO - 2016-06-03 18:41:20 --> Loader Class Initialized
INFO - 2016-06-03 18:41:20 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:20 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:20 --> Email Class Initialized
INFO - 2016-06-03 18:41:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:20 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:20 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:20 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:20 --> Model Class Initialized
INFO - 2016-06-03 18:41:20 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:20 --> Controller Class Initialized
INFO - 2016-06-03 18:41:20 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:20 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:41:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:20 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:25 --> Config Class Initialized
INFO - 2016-06-03 18:41:25 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:25 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:25 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:25 --> URI Class Initialized
DEBUG - 2016-06-03 18:41:25 --> No URI present. Default controller set.
INFO - 2016-06-03 18:41:25 --> Router Class Initialized
INFO - 2016-06-03 18:41:25 --> Output Class Initialized
INFO - 2016-06-03 18:41:25 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:25 --> CSRF cookie sent
INFO - 2016-06-03 18:41:25 --> Input Class Initialized
INFO - 2016-06-03 18:41:25 --> Language Class Initialized
INFO - 2016-06-03 18:41:25 --> Loader Class Initialized
INFO - 2016-06-03 18:41:25 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:25 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:25 --> Email Class Initialized
INFO - 2016-06-03 18:41:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:25 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:25 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:25 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:25 --> Model Class Initialized
INFO - 2016-06-03 18:41:25 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:25 --> Controller Class Initialized
INFO - 2016-06-03 18:41:25 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:41:26 --> Config Class Initialized
INFO - 2016-06-03 18:41:26 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:26 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:26 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:26 --> URI Class Initialized
INFO - 2016-06-03 18:41:26 --> Router Class Initialized
INFO - 2016-06-03 18:41:26 --> Output Class Initialized
INFO - 2016-06-03 18:41:26 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:26 --> CSRF cookie sent
INFO - 2016-06-03 18:41:26 --> Input Class Initialized
INFO - 2016-06-03 18:41:26 --> Language Class Initialized
INFO - 2016-06-03 18:41:26 --> Loader Class Initialized
INFO - 2016-06-03 18:41:26 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:26 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:26 --> Email Class Initialized
INFO - 2016-06-03 18:41:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:26 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:26 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:26 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:26 --> Model Class Initialized
INFO - 2016-06-03 18:41:26 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:26 --> Controller Class Initialized
INFO - 2016-06-03 18:41:26 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:41:26 --> Model Class Initialized
INFO - 2016-06-03 18:41:26 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 18:41:26 --> Final output sent to browser
DEBUG - 2016-06-03 18:41:26 --> Total execution time: 0.0452
INFO - 2016-06-03 18:41:31 --> Config Class Initialized
INFO - 2016-06-03 18:41:31 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:31 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:31 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:31 --> URI Class Initialized
INFO - 2016-06-03 18:41:31 --> Router Class Initialized
INFO - 2016-06-03 18:41:31 --> Output Class Initialized
INFO - 2016-06-03 18:41:31 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:31 --> CSRF cookie sent
INFO - 2016-06-03 18:41:31 --> CSRF token verified
INFO - 2016-06-03 18:41:31 --> Input Class Initialized
INFO - 2016-06-03 18:41:31 --> Language Class Initialized
INFO - 2016-06-03 18:41:31 --> Loader Class Initialized
INFO - 2016-06-03 18:41:31 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:31 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:31 --> Email Class Initialized
INFO - 2016-06-03 18:41:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:31 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:31 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:31 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:31 --> Model Class Initialized
INFO - 2016-06-03 18:41:31 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:31 --> Controller Class Initialized
INFO - 2016-06-03 18:41:31 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:41:31 --> Model Class Initialized
INFO - 2016-06-03 18:41:31 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:31 --> Final output sent to browser
DEBUG - 2016-06-03 18:41:31 --> Total execution time: 0.0331
INFO - 2016-06-03 18:41:32 --> Config Class Initialized
INFO - 2016-06-03 18:41:32 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:32 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:32 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:32 --> URI Class Initialized
INFO - 2016-06-03 18:41:32 --> Router Class Initialized
INFO - 2016-06-03 18:41:32 --> Output Class Initialized
INFO - 2016-06-03 18:41:32 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:32 --> CSRF cookie sent
INFO - 2016-06-03 18:41:32 --> Input Class Initialized
INFO - 2016-06-03 18:41:32 --> Language Class Initialized
INFO - 2016-06-03 18:41:32 --> Loader Class Initialized
INFO - 2016-06-03 18:41:32 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:32 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:32 --> Email Class Initialized
INFO - 2016-06-03 18:41:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:32 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:32 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:32 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:32 --> Model Class Initialized
INFO - 2016-06-03 18:41:32 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:32 --> Controller Class Initialized
INFO - 2016-06-03 18:41:32 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:32 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:41:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:32 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:37 --> Config Class Initialized
INFO - 2016-06-03 18:41:37 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:41:37 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:41:37 --> Utf8 Class Initialized
INFO - 2016-06-03 18:41:37 --> URI Class Initialized
INFO - 2016-06-03 18:41:37 --> Router Class Initialized
INFO - 2016-06-03 18:41:37 --> Output Class Initialized
INFO - 2016-06-03 18:41:37 --> Security Class Initialized
DEBUG - 2016-06-03 18:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:41:37 --> CSRF cookie sent
INFO - 2016-06-03 18:41:37 --> Input Class Initialized
INFO - 2016-06-03 18:41:37 --> Language Class Initialized
INFO - 2016-06-03 18:41:37 --> Loader Class Initialized
INFO - 2016-06-03 18:41:37 --> Helper loaded: form_helper
INFO - 2016-06-03 18:41:37 --> Database Driver Class Initialized
INFO - 2016-06-03 18:41:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:41:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:41:37 --> Email Class Initialized
INFO - 2016-06-03 18:41:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:41:37 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:41:37 --> Helper loaded: language_helper
INFO - 2016-06-03 18:41:37 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:37 --> Model Class Initialized
INFO - 2016-06-03 18:41:37 --> Helper loaded: date_helper
INFO - 2016-06-03 18:41:37 --> Controller Class Initialized
INFO - 2016-06-03 18:41:37 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:41:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:41:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:41:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:41:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:41:37 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:41:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:41:37 --> Form Validation Class Initialized
INFO - 2016-06-03 18:41:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:41:37 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:41:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:41:37 --> Final output sent to browser
DEBUG - 2016-06-03 18:41:37 --> Total execution time: 0.0144
INFO - 2016-06-03 18:43:34 --> Config Class Initialized
INFO - 2016-06-03 18:43:34 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:43:34 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:43:34 --> Utf8 Class Initialized
INFO - 2016-06-03 18:43:34 --> URI Class Initialized
INFO - 2016-06-03 18:43:34 --> Router Class Initialized
INFO - 2016-06-03 18:43:34 --> Output Class Initialized
INFO - 2016-06-03 18:43:34 --> Security Class Initialized
DEBUG - 2016-06-03 18:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:43:34 --> CSRF cookie sent
INFO - 2016-06-03 18:43:34 --> CSRF token verified
INFO - 2016-06-03 18:43:34 --> Input Class Initialized
INFO - 2016-06-03 18:43:34 --> Language Class Initialized
INFO - 2016-06-03 18:43:34 --> Loader Class Initialized
INFO - 2016-06-03 18:43:34 --> Helper loaded: form_helper
INFO - 2016-06-03 18:43:34 --> Database Driver Class Initialized
INFO - 2016-06-03 18:43:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:43:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:43:34 --> Email Class Initialized
INFO - 2016-06-03 18:43:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:43:34 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:43:34 --> Helper loaded: language_helper
INFO - 2016-06-03 18:43:34 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:34 --> Model Class Initialized
INFO - 2016-06-03 18:43:34 --> Helper loaded: date_helper
INFO - 2016-06-03 18:43:34 --> Controller Class Initialized
INFO - 2016-06-03 18:43:34 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:43:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:43:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:43:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:43:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:43:34 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:43:34 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:34 --> Form Validation Class Initialized
INFO - 2016-06-03 18:43:35 --> Config Class Initialized
INFO - 2016-06-03 18:43:35 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:43:35 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:43:35 --> Utf8 Class Initialized
INFO - 2016-06-03 18:43:35 --> URI Class Initialized
DEBUG - 2016-06-03 18:43:35 --> No URI present. Default controller set.
INFO - 2016-06-03 18:43:35 --> Router Class Initialized
INFO - 2016-06-03 18:43:35 --> Output Class Initialized
INFO - 2016-06-03 18:43:35 --> Security Class Initialized
DEBUG - 2016-06-03 18:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:43:35 --> CSRF cookie sent
INFO - 2016-06-03 18:43:35 --> Input Class Initialized
INFO - 2016-06-03 18:43:35 --> Language Class Initialized
INFO - 2016-06-03 18:43:35 --> Loader Class Initialized
INFO - 2016-06-03 18:43:35 --> Helper loaded: form_helper
INFO - 2016-06-03 18:43:35 --> Database Driver Class Initialized
INFO - 2016-06-03 18:43:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:43:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:43:35 --> Email Class Initialized
INFO - 2016-06-03 18:43:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:43:35 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:43:35 --> Helper loaded: language_helper
INFO - 2016-06-03 18:43:35 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:35 --> Model Class Initialized
INFO - 2016-06-03 18:43:35 --> Helper loaded: date_helper
INFO - 2016-06-03 18:43:35 --> Controller Class Initialized
INFO - 2016-06-03 18:43:35 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:43:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:43:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:43:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:43:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:43:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:43:36 --> Config Class Initialized
INFO - 2016-06-03 18:43:36 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:43:36 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:43:36 --> Utf8 Class Initialized
INFO - 2016-06-03 18:43:36 --> URI Class Initialized
INFO - 2016-06-03 18:43:36 --> Router Class Initialized
INFO - 2016-06-03 18:43:36 --> Output Class Initialized
INFO - 2016-06-03 18:43:36 --> Security Class Initialized
DEBUG - 2016-06-03 18:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:43:36 --> CSRF cookie sent
INFO - 2016-06-03 18:43:36 --> Input Class Initialized
INFO - 2016-06-03 18:43:36 --> Language Class Initialized
INFO - 2016-06-03 18:43:36 --> Loader Class Initialized
INFO - 2016-06-03 18:43:36 --> Helper loaded: form_helper
INFO - 2016-06-03 18:43:36 --> Database Driver Class Initialized
INFO - 2016-06-03 18:43:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:43:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:43:36 --> Email Class Initialized
INFO - 2016-06-03 18:43:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:43:36 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:43:36 --> Helper loaded: language_helper
INFO - 2016-06-03 18:43:36 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:36 --> Model Class Initialized
INFO - 2016-06-03 18:43:36 --> Helper loaded: date_helper
INFO - 2016-06-03 18:43:36 --> Controller Class Initialized
INFO - 2016-06-03 18:43:36 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:43:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:43:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:43:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:43:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:43:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:43:36 --> Model Class Initialized
INFO - 2016-06-03 18:43:36 --> Form Validation Class Initialized
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 18:43:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 18:43:36 --> Final output sent to browser
DEBUG - 2016-06-03 18:43:36 --> Total execution time: 0.0292
INFO - 2016-06-03 18:43:43 --> Config Class Initialized
INFO - 2016-06-03 18:43:43 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:43:43 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:43:43 --> Utf8 Class Initialized
INFO - 2016-06-03 18:43:43 --> URI Class Initialized
INFO - 2016-06-03 18:43:43 --> Router Class Initialized
INFO - 2016-06-03 18:43:43 --> Output Class Initialized
INFO - 2016-06-03 18:43:43 --> Security Class Initialized
DEBUG - 2016-06-03 18:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:43:43 --> CSRF cookie sent
INFO - 2016-06-03 18:43:43 --> Input Class Initialized
INFO - 2016-06-03 18:43:43 --> Language Class Initialized
INFO - 2016-06-03 18:43:43 --> Loader Class Initialized
INFO - 2016-06-03 18:43:43 --> Helper loaded: form_helper
INFO - 2016-06-03 18:43:43 --> Database Driver Class Initialized
INFO - 2016-06-03 18:43:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:43:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:43:43 --> Email Class Initialized
INFO - 2016-06-03 18:43:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:43:43 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:43:43 --> Helper loaded: language_helper
INFO - 2016-06-03 18:43:43 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:43 --> Model Class Initialized
INFO - 2016-06-03 18:43:43 --> Helper loaded: date_helper
INFO - 2016-06-03 18:43:43 --> Controller Class Initialized
INFO - 2016-06-03 18:43:43 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:43:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:43:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:43:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:43:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:43:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:43:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:43 --> Form Validation Class Initialized
INFO - 2016-06-03 18:43:44 --> Config Class Initialized
INFO - 2016-06-03 18:43:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:43:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:43:44 --> Utf8 Class Initialized
INFO - 2016-06-03 18:43:44 --> URI Class Initialized
INFO - 2016-06-03 18:43:44 --> Router Class Initialized
INFO - 2016-06-03 18:43:44 --> Output Class Initialized
INFO - 2016-06-03 18:43:44 --> Security Class Initialized
DEBUG - 2016-06-03 18:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:43:44 --> CSRF cookie sent
INFO - 2016-06-03 18:43:44 --> CSRF token verified
INFO - 2016-06-03 18:43:44 --> Input Class Initialized
INFO - 2016-06-03 18:43:44 --> Language Class Initialized
INFO - 2016-06-03 18:43:44 --> Loader Class Initialized
INFO - 2016-06-03 18:43:44 --> Helper loaded: form_helper
INFO - 2016-06-03 18:43:44 --> Database Driver Class Initialized
INFO - 2016-06-03 18:43:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:43:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:43:44 --> Email Class Initialized
INFO - 2016-06-03 18:43:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:43:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:43:44 --> Helper loaded: language_helper
INFO - 2016-06-03 18:43:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:44 --> Model Class Initialized
INFO - 2016-06-03 18:43:44 --> Helper loaded: date_helper
INFO - 2016-06-03 18:43:44 --> Controller Class Initialized
INFO - 2016-06-03 18:43:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:43:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:43:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:43:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:43:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:43:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:43:44 --> Model Class Initialized
INFO - 2016-06-03 18:43:44 --> Form Validation Class Initialized
INFO - 2016-06-03 18:43:45 --> Config Class Initialized
INFO - 2016-06-03 18:43:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:43:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:43:45 --> Utf8 Class Initialized
INFO - 2016-06-03 18:43:45 --> URI Class Initialized
INFO - 2016-06-03 18:43:45 --> Router Class Initialized
INFO - 2016-06-03 18:43:45 --> Output Class Initialized
INFO - 2016-06-03 18:43:45 --> Security Class Initialized
DEBUG - 2016-06-03 18:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:43:45 --> CSRF cookie sent
INFO - 2016-06-03 18:43:45 --> Input Class Initialized
INFO - 2016-06-03 18:43:45 --> Language Class Initialized
INFO - 2016-06-03 18:43:45 --> Loader Class Initialized
INFO - 2016-06-03 18:43:45 --> Helper loaded: form_helper
INFO - 2016-06-03 18:43:45 --> Database Driver Class Initialized
INFO - 2016-06-03 18:43:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:43:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:43:45 --> Email Class Initialized
INFO - 2016-06-03 18:43:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:43:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:43:45 --> Helper loaded: language_helper
INFO - 2016-06-03 18:43:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:45 --> Model Class Initialized
INFO - 2016-06-03 18:43:45 --> Helper loaded: date_helper
INFO - 2016-06-03 18:43:45 --> Controller Class Initialized
INFO - 2016-06-03 18:43:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:43:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:43:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:43:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:43:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:43:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:43:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:43:45 --> Form Validation Class Initialized
INFO - 2016-06-03 18:43:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:43:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:43:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:43:45 --> Final output sent to browser
DEBUG - 2016-06-03 18:43:45 --> Total execution time: 0.0157
INFO - 2016-06-03 18:44:23 --> Config Class Initialized
INFO - 2016-06-03 18:44:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:44:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:44:23 --> Utf8 Class Initialized
INFO - 2016-06-03 18:44:23 --> URI Class Initialized
INFO - 2016-06-03 18:44:23 --> Router Class Initialized
INFO - 2016-06-03 18:44:23 --> Output Class Initialized
INFO - 2016-06-03 18:44:23 --> Security Class Initialized
DEBUG - 2016-06-03 18:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:44:23 --> CSRF cookie sent
INFO - 2016-06-03 18:44:23 --> CSRF token verified
INFO - 2016-06-03 18:44:23 --> Input Class Initialized
INFO - 2016-06-03 18:44:23 --> Language Class Initialized
INFO - 2016-06-03 18:44:23 --> Loader Class Initialized
INFO - 2016-06-03 18:44:23 --> Helper loaded: form_helper
INFO - 2016-06-03 18:44:23 --> Database Driver Class Initialized
INFO - 2016-06-03 18:44:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:44:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:44:23 --> Email Class Initialized
INFO - 2016-06-03 18:44:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:44:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:44:23 --> Helper loaded: language_helper
INFO - 2016-06-03 18:44:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:44:23 --> Model Class Initialized
INFO - 2016-06-03 18:44:23 --> Helper loaded: date_helper
INFO - 2016-06-03 18:44:23 --> Controller Class Initialized
INFO - 2016-06-03 18:44:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:44:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:44:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:44:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:44:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:44:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:44:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:44:23 --> Form Validation Class Initialized
INFO - 2016-06-03 18:44:24 --> Config Class Initialized
INFO - 2016-06-03 18:44:24 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:44:24 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:44:24 --> Utf8 Class Initialized
INFO - 2016-06-03 18:44:24 --> URI Class Initialized
DEBUG - 2016-06-03 18:44:24 --> No URI present. Default controller set.
INFO - 2016-06-03 18:44:24 --> Router Class Initialized
INFO - 2016-06-03 18:44:24 --> Output Class Initialized
INFO - 2016-06-03 18:44:24 --> Security Class Initialized
DEBUG - 2016-06-03 18:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:44:24 --> CSRF cookie sent
INFO - 2016-06-03 18:44:24 --> Input Class Initialized
INFO - 2016-06-03 18:44:24 --> Language Class Initialized
INFO - 2016-06-03 18:44:24 --> Loader Class Initialized
INFO - 2016-06-03 18:44:24 --> Helper loaded: form_helper
INFO - 2016-06-03 18:44:24 --> Database Driver Class Initialized
INFO - 2016-06-03 18:44:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:44:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:44:24 --> Email Class Initialized
INFO - 2016-06-03 18:44:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:44:24 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:44:24 --> Helper loaded: language_helper
INFO - 2016-06-03 18:44:24 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:44:24 --> Model Class Initialized
INFO - 2016-06-03 18:44:24 --> Helper loaded: date_helper
INFO - 2016-06-03 18:44:24 --> Controller Class Initialized
INFO - 2016-06-03 18:44:24 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:44:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:44:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:44:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:44:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:44:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:44:25 --> Config Class Initialized
INFO - 2016-06-03 18:44:25 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:44:25 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:44:25 --> Utf8 Class Initialized
INFO - 2016-06-03 18:44:25 --> URI Class Initialized
INFO - 2016-06-03 18:44:25 --> Router Class Initialized
INFO - 2016-06-03 18:44:25 --> Output Class Initialized
INFO - 2016-06-03 18:44:25 --> Security Class Initialized
DEBUG - 2016-06-03 18:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:44:25 --> CSRF cookie sent
INFO - 2016-06-03 18:44:25 --> Input Class Initialized
INFO - 2016-06-03 18:44:25 --> Language Class Initialized
INFO - 2016-06-03 18:44:25 --> Loader Class Initialized
INFO - 2016-06-03 18:44:25 --> Helper loaded: form_helper
INFO - 2016-06-03 18:44:25 --> Database Driver Class Initialized
INFO - 2016-06-03 18:44:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:44:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:44:25 --> Email Class Initialized
INFO - 2016-06-03 18:44:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:44:25 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:44:25 --> Helper loaded: language_helper
INFO - 2016-06-03 18:44:25 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:44:25 --> Model Class Initialized
INFO - 2016-06-03 18:44:25 --> Helper loaded: date_helper
INFO - 2016-06-03 18:44:25 --> Controller Class Initialized
INFO - 2016-06-03 18:44:25 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:44:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:44:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:44:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:44:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:44:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:44:25 --> Model Class Initialized
INFO - 2016-06-03 18:44:25 --> Form Validation Class Initialized
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 18:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 18:44:25 --> Final output sent to browser
DEBUG - 2016-06-03 18:44:25 --> Total execution time: 0.0458
INFO - 2016-06-03 18:44:32 --> Config Class Initialized
INFO - 2016-06-03 18:44:32 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:44:32 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:44:32 --> Utf8 Class Initialized
INFO - 2016-06-03 18:44:32 --> URI Class Initialized
INFO - 2016-06-03 18:44:32 --> Router Class Initialized
INFO - 2016-06-03 18:44:32 --> Output Class Initialized
INFO - 2016-06-03 18:44:32 --> Security Class Initialized
DEBUG - 2016-06-03 18:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:44:32 --> CSRF cookie sent
INFO - 2016-06-03 18:44:32 --> CSRF token verified
INFO - 2016-06-03 18:44:32 --> Input Class Initialized
INFO - 2016-06-03 18:44:32 --> Language Class Initialized
INFO - 2016-06-03 18:44:32 --> Loader Class Initialized
INFO - 2016-06-03 18:44:32 --> Helper loaded: form_helper
INFO - 2016-06-03 18:44:32 --> Database Driver Class Initialized
INFO - 2016-06-03 18:44:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:44:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:44:32 --> Email Class Initialized
INFO - 2016-06-03 18:44:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:44:32 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:44:32 --> Helper loaded: language_helper
INFO - 2016-06-03 18:44:32 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:44:32 --> Model Class Initialized
INFO - 2016-06-03 18:44:32 --> Helper loaded: date_helper
INFO - 2016-06-03 18:44:32 --> Controller Class Initialized
INFO - 2016-06-03 18:44:32 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:44:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:44:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:44:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:44:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:44:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:44:32 --> Model Class Initialized
INFO - 2016-06-03 18:44:32 --> Form Validation Class Initialized
INFO - 2016-06-03 18:44:33 --> Final output sent to browser
DEBUG - 2016-06-03 18:44:33 --> Total execution time: 0.0219
INFO - 2016-06-03 18:45:20 --> Config Class Initialized
INFO - 2016-06-03 18:45:20 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:45:20 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:45:20 --> Utf8 Class Initialized
INFO - 2016-06-03 18:45:20 --> URI Class Initialized
INFO - 2016-06-03 18:45:20 --> Router Class Initialized
INFO - 2016-06-03 18:45:20 --> Output Class Initialized
INFO - 2016-06-03 18:45:20 --> Security Class Initialized
DEBUG - 2016-06-03 18:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:45:20 --> CSRF cookie sent
INFO - 2016-06-03 18:45:20 --> Input Class Initialized
INFO - 2016-06-03 18:45:20 --> Language Class Initialized
INFO - 2016-06-03 18:45:20 --> Loader Class Initialized
INFO - 2016-06-03 18:45:20 --> Helper loaded: form_helper
INFO - 2016-06-03 18:45:20 --> Database Driver Class Initialized
INFO - 2016-06-03 18:45:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:45:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:45:20 --> Email Class Initialized
INFO - 2016-06-03 18:45:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:45:20 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:45:20 --> Helper loaded: language_helper
INFO - 2016-06-03 18:45:20 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:45:20 --> Model Class Initialized
INFO - 2016-06-03 18:45:20 --> Helper loaded: date_helper
INFO - 2016-06-03 18:45:20 --> Controller Class Initialized
INFO - 2016-06-03 18:45:20 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:45:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:45:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:45:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:45:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:45:20 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:45:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:45:20 --> Form Validation Class Initialized
INFO - 2016-06-03 18:45:21 --> Config Class Initialized
INFO - 2016-06-03 18:45:21 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:45:21 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:45:21 --> Utf8 Class Initialized
INFO - 2016-06-03 18:45:21 --> URI Class Initialized
INFO - 2016-06-03 18:45:21 --> Router Class Initialized
INFO - 2016-06-03 18:45:21 --> Output Class Initialized
INFO - 2016-06-03 18:45:21 --> Security Class Initialized
DEBUG - 2016-06-03 18:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:45:21 --> CSRF cookie sent
INFO - 2016-06-03 18:45:21 --> Input Class Initialized
INFO - 2016-06-03 18:45:21 --> Language Class Initialized
INFO - 2016-06-03 18:45:21 --> Loader Class Initialized
INFO - 2016-06-03 18:45:21 --> Helper loaded: form_helper
INFO - 2016-06-03 18:45:21 --> Database Driver Class Initialized
INFO - 2016-06-03 18:45:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:45:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:45:21 --> Email Class Initialized
INFO - 2016-06-03 18:45:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:45:21 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:45:21 --> Helper loaded: language_helper
INFO - 2016-06-03 18:45:21 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:45:21 --> Model Class Initialized
INFO - 2016-06-03 18:45:21 --> Helper loaded: date_helper
INFO - 2016-06-03 18:45:21 --> Controller Class Initialized
INFO - 2016-06-03 18:45:21 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:45:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:45:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:45:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:45:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:45:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:45:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:45:21 --> Form Validation Class Initialized
INFO - 2016-06-03 18:45:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:45:21 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:45:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:45:21 --> Final output sent to browser
DEBUG - 2016-06-03 18:45:21 --> Total execution time: 0.0139
INFO - 2016-06-03 18:46:28 --> Config Class Initialized
INFO - 2016-06-03 18:46:28 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:46:28 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:46:28 --> Utf8 Class Initialized
INFO - 2016-06-03 18:46:28 --> URI Class Initialized
INFO - 2016-06-03 18:46:28 --> Router Class Initialized
INFO - 2016-06-03 18:46:28 --> Output Class Initialized
INFO - 2016-06-03 18:46:28 --> Security Class Initialized
DEBUG - 2016-06-03 18:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:46:28 --> CSRF cookie sent
INFO - 2016-06-03 18:46:28 --> Input Class Initialized
INFO - 2016-06-03 18:46:28 --> Language Class Initialized
INFO - 2016-06-03 18:46:28 --> Loader Class Initialized
INFO - 2016-06-03 18:46:28 --> Helper loaded: form_helper
INFO - 2016-06-03 18:46:28 --> Database Driver Class Initialized
INFO - 2016-06-03 18:46:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:46:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:46:28 --> Email Class Initialized
INFO - 2016-06-03 18:46:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:46:28 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:46:28 --> Helper loaded: language_helper
INFO - 2016-06-03 18:46:28 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:46:28 --> Model Class Initialized
INFO - 2016-06-03 18:46:28 --> Helper loaded: date_helper
INFO - 2016-06-03 18:46:28 --> Controller Class Initialized
INFO - 2016-06-03 18:46:28 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:46:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:46:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:46:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:46:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:46:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:46:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:46:28 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:46:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-03 18:46:28 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /home/demis/www/platformadiabet/application/controllers/Auth.php 63
INFO - 2016-06-03 18:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:46:28 --> Final output sent to browser
DEBUG - 2016-06-03 18:46:28 --> Total execution time: 0.0430
INFO - 2016-06-03 18:47:25 --> Config Class Initialized
INFO - 2016-06-03 18:47:25 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:25 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:25 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:25 --> URI Class Initialized
INFO - 2016-06-03 18:47:25 --> Router Class Initialized
INFO - 2016-06-03 18:47:25 --> Output Class Initialized
INFO - 2016-06-03 18:47:25 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:25 --> CSRF cookie sent
INFO - 2016-06-03 18:47:25 --> Input Class Initialized
INFO - 2016-06-03 18:47:25 --> Language Class Initialized
INFO - 2016-06-03 18:47:25 --> Loader Class Initialized
INFO - 2016-06-03 18:47:25 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:25 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:25 --> Email Class Initialized
INFO - 2016-06-03 18:47:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:25 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:25 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:25 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:25 --> Model Class Initialized
INFO - 2016-06-03 18:47:25 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:25 --> Controller Class Initialized
INFO - 2016-06-03 18:47:25 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:47:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:25 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:47:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:47:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:47:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:47:25 --> Final output sent to browser
DEBUG - 2016-06-03 18:47:25 --> Total execution time: 0.0231
INFO - 2016-06-03 18:47:37 --> Config Class Initialized
INFO - 2016-06-03 18:47:37 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:37 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:37 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:37 --> URI Class Initialized
INFO - 2016-06-03 18:47:37 --> Router Class Initialized
INFO - 2016-06-03 18:47:37 --> Output Class Initialized
INFO - 2016-06-03 18:47:37 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:37 --> CSRF cookie sent
INFO - 2016-06-03 18:47:37 --> CSRF token verified
INFO - 2016-06-03 18:47:37 --> Input Class Initialized
INFO - 2016-06-03 18:47:37 --> Language Class Initialized
INFO - 2016-06-03 18:47:37 --> Loader Class Initialized
INFO - 2016-06-03 18:47:37 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:37 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:37 --> Email Class Initialized
INFO - 2016-06-03 18:47:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:37 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:37 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:37 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:37 --> Model Class Initialized
INFO - 2016-06-03 18:47:37 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:37 --> Controller Class Initialized
INFO - 2016-06-03 18:47:37 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:37 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:47:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:37 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:47:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:42 --> Config Class Initialized
INFO - 2016-06-03 18:47:42 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:42 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:42 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:42 --> URI Class Initialized
DEBUG - 2016-06-03 18:47:42 --> No URI present. Default controller set.
INFO - 2016-06-03 18:47:42 --> Router Class Initialized
INFO - 2016-06-03 18:47:42 --> Output Class Initialized
INFO - 2016-06-03 18:47:42 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:42 --> CSRF cookie sent
INFO - 2016-06-03 18:47:42 --> Input Class Initialized
INFO - 2016-06-03 18:47:42 --> Language Class Initialized
INFO - 2016-06-03 18:47:42 --> Loader Class Initialized
INFO - 2016-06-03 18:47:42 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:42 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:42 --> Email Class Initialized
INFO - 2016-06-03 18:47:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:42 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:42 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:42 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:42 --> Model Class Initialized
INFO - 2016-06-03 18:47:42 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:42 --> Controller Class Initialized
INFO - 2016-06-03 18:47:42 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:47:43 --> Config Class Initialized
INFO - 2016-06-03 18:47:43 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:43 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:43 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:43 --> URI Class Initialized
INFO - 2016-06-03 18:47:43 --> Router Class Initialized
INFO - 2016-06-03 18:47:43 --> Output Class Initialized
INFO - 2016-06-03 18:47:43 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:43 --> CSRF cookie sent
INFO - 2016-06-03 18:47:43 --> Input Class Initialized
INFO - 2016-06-03 18:47:43 --> Language Class Initialized
INFO - 2016-06-03 18:47:43 --> Loader Class Initialized
INFO - 2016-06-03 18:47:43 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:43 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:43 --> Email Class Initialized
INFO - 2016-06-03 18:47:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:43 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:43 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:43 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:43 --> Model Class Initialized
INFO - 2016-06-03 18:47:43 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:43 --> Controller Class Initialized
INFO - 2016-06-03 18:47:43 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:47:43 --> Model Class Initialized
INFO - 2016-06-03 18:47:43 --> Form Validation Class Initialized
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 18:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 18:47:43 --> Final output sent to browser
DEBUG - 2016-06-03 18:47:43 --> Total execution time: 0.0343
INFO - 2016-06-03 18:47:48 --> Config Class Initialized
INFO - 2016-06-03 18:47:48 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:48 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:48 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:48 --> URI Class Initialized
INFO - 2016-06-03 18:47:48 --> Router Class Initialized
INFO - 2016-06-03 18:47:48 --> Output Class Initialized
INFO - 2016-06-03 18:47:48 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:48 --> CSRF cookie sent
INFO - 2016-06-03 18:47:48 --> CSRF token verified
INFO - 2016-06-03 18:47:48 --> Input Class Initialized
INFO - 2016-06-03 18:47:48 --> Language Class Initialized
INFO - 2016-06-03 18:47:48 --> Loader Class Initialized
INFO - 2016-06-03 18:47:48 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:48 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:48 --> Email Class Initialized
INFO - 2016-06-03 18:47:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:48 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:48 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:48 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:48 --> Model Class Initialized
INFO - 2016-06-03 18:47:48 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:48 --> Controller Class Initialized
INFO - 2016-06-03 18:47:48 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:47:48 --> Model Class Initialized
INFO - 2016-06-03 18:47:48 --> Form Validation Class Initialized
INFO - 2016-06-03 18:47:48 --> Final output sent to browser
DEBUG - 2016-06-03 18:47:48 --> Total execution time: 0.0428
INFO - 2016-06-03 18:47:51 --> Config Class Initialized
INFO - 2016-06-03 18:47:51 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:51 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:51 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:51 --> URI Class Initialized
INFO - 2016-06-03 18:47:51 --> Router Class Initialized
INFO - 2016-06-03 18:47:51 --> Output Class Initialized
INFO - 2016-06-03 18:47:51 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:51 --> CSRF cookie sent
INFO - 2016-06-03 18:47:51 --> Input Class Initialized
INFO - 2016-06-03 18:47:51 --> Language Class Initialized
INFO - 2016-06-03 18:47:51 --> Loader Class Initialized
INFO - 2016-06-03 18:47:51 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:51 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:51 --> Email Class Initialized
INFO - 2016-06-03 18:47:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:51 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:51 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:51 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:51 --> Model Class Initialized
INFO - 2016-06-03 18:47:51 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:51 --> Controller Class Initialized
INFO - 2016-06-03 18:47:51 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:51 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:47:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:51 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:47:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:57 --> Config Class Initialized
INFO - 2016-06-03 18:47:57 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:57 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:57 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:57 --> URI Class Initialized
DEBUG - 2016-06-03 18:47:57 --> No URI present. Default controller set.
INFO - 2016-06-03 18:47:57 --> Router Class Initialized
INFO - 2016-06-03 18:47:57 --> Output Class Initialized
INFO - 2016-06-03 18:47:57 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:57 --> CSRF cookie sent
INFO - 2016-06-03 18:47:57 --> Input Class Initialized
INFO - 2016-06-03 18:47:57 --> Language Class Initialized
INFO - 2016-06-03 18:47:57 --> Loader Class Initialized
INFO - 2016-06-03 18:47:57 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:57 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:57 --> Email Class Initialized
INFO - 2016-06-03 18:47:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:57 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:57 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:57 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:57 --> Model Class Initialized
INFO - 2016-06-03 18:47:57 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:57 --> Controller Class Initialized
INFO - 2016-06-03 18:47:57 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:47:58 --> Config Class Initialized
INFO - 2016-06-03 18:47:58 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:47:58 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:47:58 --> Utf8 Class Initialized
INFO - 2016-06-03 18:47:58 --> URI Class Initialized
INFO - 2016-06-03 18:47:58 --> Router Class Initialized
INFO - 2016-06-03 18:47:58 --> Output Class Initialized
INFO - 2016-06-03 18:47:58 --> Security Class Initialized
DEBUG - 2016-06-03 18:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:47:58 --> CSRF cookie sent
INFO - 2016-06-03 18:47:58 --> Input Class Initialized
INFO - 2016-06-03 18:47:58 --> Language Class Initialized
INFO - 2016-06-03 18:47:58 --> Loader Class Initialized
INFO - 2016-06-03 18:47:58 --> Helper loaded: form_helper
INFO - 2016-06-03 18:47:58 --> Database Driver Class Initialized
INFO - 2016-06-03 18:47:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:47:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:47:58 --> Email Class Initialized
INFO - 2016-06-03 18:47:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:47:58 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:47:58 --> Helper loaded: language_helper
INFO - 2016-06-03 18:47:58 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:47:58 --> Model Class Initialized
INFO - 2016-06-03 18:47:58 --> Helper loaded: date_helper
INFO - 2016-06-03 18:47:58 --> Controller Class Initialized
INFO - 2016-06-03 18:47:58 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:47:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:47:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:47:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:47:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:47:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:47:58 --> Model Class Initialized
INFO - 2016-06-03 18:47:58 --> Form Validation Class Initialized
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-03 18:47:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-03 18:47:58 --> Final output sent to browser
DEBUG - 2016-06-03 18:47:58 --> Total execution time: 0.0265
INFO - 2016-06-03 18:48:03 --> Config Class Initialized
INFO - 2016-06-03 18:48:03 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:48:03 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:48:03 --> Utf8 Class Initialized
INFO - 2016-06-03 18:48:03 --> URI Class Initialized
INFO - 2016-06-03 18:48:03 --> Router Class Initialized
INFO - 2016-06-03 18:48:03 --> Output Class Initialized
INFO - 2016-06-03 18:48:03 --> Security Class Initialized
DEBUG - 2016-06-03 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:48:03 --> CSRF cookie sent
INFO - 2016-06-03 18:48:03 --> CSRF token verified
INFO - 2016-06-03 18:48:03 --> Input Class Initialized
INFO - 2016-06-03 18:48:03 --> Language Class Initialized
INFO - 2016-06-03 18:48:03 --> Loader Class Initialized
INFO - 2016-06-03 18:48:03 --> Helper loaded: form_helper
INFO - 2016-06-03 18:48:03 --> Database Driver Class Initialized
INFO - 2016-06-03 18:48:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:48:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:48:03 --> Email Class Initialized
INFO - 2016-06-03 18:48:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:48:03 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:48:03 --> Helper loaded: language_helper
INFO - 2016-06-03 18:48:03 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:03 --> Model Class Initialized
INFO - 2016-06-03 18:48:03 --> Helper loaded: date_helper
INFO - 2016-06-03 18:48:03 --> Controller Class Initialized
INFO - 2016-06-03 18:48:03 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:48:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:48:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:48:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:48:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:48:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-03 18:48:03 --> Model Class Initialized
INFO - 2016-06-03 18:48:03 --> Form Validation Class Initialized
INFO - 2016-06-03 18:48:03 --> Final output sent to browser
DEBUG - 2016-06-03 18:48:03 --> Total execution time: 0.0157
INFO - 2016-06-03 18:48:04 --> Config Class Initialized
INFO - 2016-06-03 18:48:04 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:48:04 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:48:04 --> Utf8 Class Initialized
INFO - 2016-06-03 18:48:04 --> URI Class Initialized
INFO - 2016-06-03 18:48:04 --> Router Class Initialized
INFO - 2016-06-03 18:48:04 --> Output Class Initialized
INFO - 2016-06-03 18:48:04 --> Security Class Initialized
DEBUG - 2016-06-03 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:48:04 --> CSRF cookie sent
INFO - 2016-06-03 18:48:04 --> Input Class Initialized
INFO - 2016-06-03 18:48:04 --> Language Class Initialized
INFO - 2016-06-03 18:48:04 --> Loader Class Initialized
INFO - 2016-06-03 18:48:04 --> Helper loaded: form_helper
INFO - 2016-06-03 18:48:04 --> Database Driver Class Initialized
INFO - 2016-06-03 18:48:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:48:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:48:04 --> Email Class Initialized
INFO - 2016-06-03 18:48:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:48:04 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:48:04 --> Helper loaded: language_helper
INFO - 2016-06-03 18:48:04 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:04 --> Model Class Initialized
INFO - 2016-06-03 18:48:04 --> Helper loaded: date_helper
INFO - 2016-06-03 18:48:04 --> Controller Class Initialized
INFO - 2016-06-03 18:48:04 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:48:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:48:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:48:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:48:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:48:04 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:48:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:04 --> Form Validation Class Initialized
INFO - 2016-06-03 18:48:10 --> Config Class Initialized
INFO - 2016-06-03 18:48:10 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:48:10 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:48:10 --> Utf8 Class Initialized
INFO - 2016-06-03 18:48:10 --> URI Class Initialized
INFO - 2016-06-03 18:48:10 --> Router Class Initialized
INFO - 2016-06-03 18:48:10 --> Output Class Initialized
INFO - 2016-06-03 18:48:10 --> Security Class Initialized
DEBUG - 2016-06-03 18:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:48:10 --> CSRF cookie sent
INFO - 2016-06-03 18:48:10 --> Input Class Initialized
INFO - 2016-06-03 18:48:10 --> Language Class Initialized
INFO - 2016-06-03 18:48:10 --> Loader Class Initialized
INFO - 2016-06-03 18:48:10 --> Helper loaded: form_helper
INFO - 2016-06-03 18:48:10 --> Database Driver Class Initialized
INFO - 2016-06-03 18:48:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:48:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:48:10 --> Email Class Initialized
INFO - 2016-06-03 18:48:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:48:10 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:48:10 --> Helper loaded: language_helper
INFO - 2016-06-03 18:48:10 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:10 --> Model Class Initialized
INFO - 2016-06-03 18:48:10 --> Helper loaded: date_helper
INFO - 2016-06-03 18:48:10 --> Controller Class Initialized
INFO - 2016-06-03 18:48:10 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:48:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:48:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:48:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:48:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:48:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:48:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:10 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:48:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:48:10 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:48:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:48:10 --> Final output sent to browser
DEBUG - 2016-06-03 18:48:10 --> Total execution time: 0.0772
INFO - 2016-06-03 18:48:19 --> Config Class Initialized
INFO - 2016-06-03 18:48:19 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:48:19 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:48:19 --> Utf8 Class Initialized
INFO - 2016-06-03 18:48:19 --> URI Class Initialized
INFO - 2016-06-03 18:48:19 --> Router Class Initialized
INFO - 2016-06-03 18:48:19 --> Output Class Initialized
INFO - 2016-06-03 18:48:19 --> Security Class Initialized
DEBUG - 2016-06-03 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:48:19 --> CSRF cookie sent
INFO - 2016-06-03 18:48:19 --> CSRF token verified
INFO - 2016-06-03 18:48:19 --> Input Class Initialized
INFO - 2016-06-03 18:48:19 --> Language Class Initialized
INFO - 2016-06-03 18:48:19 --> Loader Class Initialized
INFO - 2016-06-03 18:48:19 --> Helper loaded: form_helper
INFO - 2016-06-03 18:48:19 --> Database Driver Class Initialized
INFO - 2016-06-03 18:48:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:48:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:48:19 --> Email Class Initialized
INFO - 2016-06-03 18:48:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:48:19 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:48:19 --> Helper loaded: language_helper
INFO - 2016-06-03 18:48:19 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:19 --> Model Class Initialized
INFO - 2016-06-03 18:48:19 --> Helper loaded: date_helper
INFO - 2016-06-03 18:48:19 --> Controller Class Initialized
INFO - 2016-06-03 18:48:19 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:48:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:48:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:48:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:48:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:48:19 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:48:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:19 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:48:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:48:19 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:48:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:48:19 --> Final output sent to browser
DEBUG - 2016-06-03 18:48:19 --> Total execution time: 0.0343
INFO - 2016-06-03 18:48:33 --> Config Class Initialized
INFO - 2016-06-03 18:48:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:48:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:48:33 --> Utf8 Class Initialized
INFO - 2016-06-03 18:48:33 --> URI Class Initialized
INFO - 2016-06-03 18:48:33 --> Router Class Initialized
INFO - 2016-06-03 18:48:33 --> Output Class Initialized
INFO - 2016-06-03 18:48:33 --> Security Class Initialized
DEBUG - 2016-06-03 18:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:48:33 --> CSRF cookie sent
INFO - 2016-06-03 18:48:33 --> CSRF token verified
INFO - 2016-06-03 18:48:33 --> Input Class Initialized
INFO - 2016-06-03 18:48:33 --> Language Class Initialized
INFO - 2016-06-03 18:48:33 --> Loader Class Initialized
INFO - 2016-06-03 18:48:33 --> Helper loaded: form_helper
INFO - 2016-06-03 18:48:33 --> Database Driver Class Initialized
INFO - 2016-06-03 18:48:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:48:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:48:33 --> Email Class Initialized
INFO - 2016-06-03 18:48:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:48:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:48:33 --> Helper loaded: language_helper
INFO - 2016-06-03 18:48:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:33 --> Model Class Initialized
INFO - 2016-06-03 18:48:33 --> Helper loaded: date_helper
INFO - 2016-06-03 18:48:33 --> Controller Class Initialized
INFO - 2016-06-03 18:48:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:48:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:48:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:48:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:48:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:48:33 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:48:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:48:33 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:48:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:48:33 --> Unable to find validation rule: captcha_check(qwert12345)
ERROR - 2016-06-03 18:48:33 --> Could not find the language line "form_validation_captcha_check(qwert12345)"
INFO - 2016-06-03 18:48:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:48:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:48:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:48:33 --> Final output sent to browser
DEBUG - 2016-06-03 18:48:33 --> Total execution time: 0.0309
INFO - 2016-06-03 18:49:13 --> Config Class Initialized
INFO - 2016-06-03 18:49:13 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:49:13 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:49:13 --> Utf8 Class Initialized
INFO - 2016-06-03 18:49:13 --> URI Class Initialized
INFO - 2016-06-03 18:49:13 --> Router Class Initialized
INFO - 2016-06-03 18:49:13 --> Output Class Initialized
INFO - 2016-06-03 18:49:13 --> Security Class Initialized
DEBUG - 2016-06-03 18:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:49:13 --> CSRF cookie sent
INFO - 2016-06-03 18:49:13 --> CSRF token verified
INFO - 2016-06-03 18:49:13 --> Input Class Initialized
INFO - 2016-06-03 18:49:13 --> Language Class Initialized
INFO - 2016-06-03 18:49:13 --> Loader Class Initialized
INFO - 2016-06-03 18:49:13 --> Helper loaded: form_helper
INFO - 2016-06-03 18:49:13 --> Database Driver Class Initialized
INFO - 2016-06-03 18:49:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:49:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:49:13 --> Email Class Initialized
INFO - 2016-06-03 18:49:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:49:13 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:49:13 --> Helper loaded: language_helper
INFO - 2016-06-03 18:49:13 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:49:13 --> Model Class Initialized
INFO - 2016-06-03 18:49:13 --> Helper loaded: date_helper
INFO - 2016-06-03 18:49:13 --> Controller Class Initialized
INFO - 2016-06-03 18:49:13 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:49:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:49:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:49:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:49:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:49:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:49:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:49:13 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:49:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:49:13 --> Final output sent to browser
DEBUG - 2016-06-03 18:49:13 --> Total execution time: 0.0244
INFO - 2016-06-03 18:49:22 --> Config Class Initialized
INFO - 2016-06-03 18:49:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:49:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:49:22 --> Utf8 Class Initialized
INFO - 2016-06-03 18:49:22 --> URI Class Initialized
INFO - 2016-06-03 18:49:22 --> Router Class Initialized
INFO - 2016-06-03 18:49:22 --> Output Class Initialized
INFO - 2016-06-03 18:49:22 --> Security Class Initialized
DEBUG - 2016-06-03 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:49:22 --> CSRF cookie sent
INFO - 2016-06-03 18:49:22 --> CSRF token verified
INFO - 2016-06-03 18:49:22 --> Input Class Initialized
INFO - 2016-06-03 18:49:22 --> Language Class Initialized
INFO - 2016-06-03 18:49:22 --> Loader Class Initialized
INFO - 2016-06-03 18:49:22 --> Helper loaded: form_helper
INFO - 2016-06-03 18:49:22 --> Database Driver Class Initialized
INFO - 2016-06-03 18:49:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:49:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:49:22 --> Email Class Initialized
INFO - 2016-06-03 18:49:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:49:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:49:22 --> Helper loaded: language_helper
INFO - 2016-06-03 18:49:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:49:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:49:22 --> Model Class Initialized
INFO - 2016-06-03 18:49:22 --> Helper loaded: date_helper
INFO - 2016-06-03 18:49:22 --> Controller Class Initialized
INFO - 2016-06-03 18:49:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:49:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:49:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:49:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:49:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:49:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:49:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:49:22 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:49:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:49:22 --> Unable to find validation rule: captcha_check(qwert12345)
ERROR - 2016-06-03 18:49:22 --> Could not find the language line "form_validation_captcha_check(qwert12345)"
INFO - 2016-06-03 18:49:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:49:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:49:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:49:22 --> Final output sent to browser
DEBUG - 2016-06-03 18:49:22 --> Total execution time: 0.0231
INFO - 2016-06-03 18:50:26 --> Config Class Initialized
INFO - 2016-06-03 18:50:26 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:50:26 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:50:26 --> Utf8 Class Initialized
INFO - 2016-06-03 18:50:26 --> URI Class Initialized
INFO - 2016-06-03 18:50:26 --> Router Class Initialized
INFO - 2016-06-03 18:50:26 --> Output Class Initialized
INFO - 2016-06-03 18:50:26 --> Security Class Initialized
DEBUG - 2016-06-03 18:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:50:26 --> CSRF cookie sent
INFO - 2016-06-03 18:50:26 --> CSRF token verified
INFO - 2016-06-03 18:50:26 --> Input Class Initialized
INFO - 2016-06-03 18:50:26 --> Language Class Initialized
INFO - 2016-06-03 18:50:26 --> Loader Class Initialized
INFO - 2016-06-03 18:50:26 --> Helper loaded: form_helper
INFO - 2016-06-03 18:50:26 --> Database Driver Class Initialized
INFO - 2016-06-03 18:50:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:50:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:50:26 --> Email Class Initialized
INFO - 2016-06-03 18:50:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:50:26 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:50:26 --> Helper loaded: language_helper
INFO - 2016-06-03 18:50:26 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:50:26 --> Model Class Initialized
INFO - 2016-06-03 18:50:26 --> Helper loaded: date_helper
INFO - 2016-06-03 18:50:26 --> Controller Class Initialized
INFO - 2016-06-03 18:50:26 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:50:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:50:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:50:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:50:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:50:26 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:50:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:50:26 --> Form Validation Class Initialized
INFO - 2016-06-03 18:50:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:50:26 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:50:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:50:26 --> Final output sent to browser
DEBUG - 2016-06-03 18:50:26 --> Total execution time: 0.0468
INFO - 2016-06-03 18:50:39 --> Config Class Initialized
INFO - 2016-06-03 18:50:39 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:50:39 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:50:39 --> Utf8 Class Initialized
INFO - 2016-06-03 18:50:39 --> URI Class Initialized
INFO - 2016-06-03 18:50:39 --> Router Class Initialized
INFO - 2016-06-03 18:50:39 --> Output Class Initialized
INFO - 2016-06-03 18:50:39 --> Security Class Initialized
DEBUG - 2016-06-03 18:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:50:39 --> CSRF cookie sent
INFO - 2016-06-03 18:50:39 --> CSRF token verified
INFO - 2016-06-03 18:50:39 --> Input Class Initialized
INFO - 2016-06-03 18:50:39 --> Language Class Initialized
INFO - 2016-06-03 18:50:39 --> Loader Class Initialized
INFO - 2016-06-03 18:50:39 --> Helper loaded: form_helper
INFO - 2016-06-03 18:50:39 --> Database Driver Class Initialized
INFO - 2016-06-03 18:50:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:50:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:50:39 --> Email Class Initialized
INFO - 2016-06-03 18:50:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:50:39 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:50:39 --> Helper loaded: language_helper
INFO - 2016-06-03 18:50:39 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:50:39 --> Model Class Initialized
INFO - 2016-06-03 18:50:39 --> Helper loaded: date_helper
INFO - 2016-06-03 18:50:39 --> Controller Class Initialized
INFO - 2016-06-03 18:50:39 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:50:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:50:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:50:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:50:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:50:39 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:50:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:50:39 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:50:39 --> Unable to find callback validation rule: captcha_check(qwert12345)
ERROR - 2016-06-03 18:50:39 --> Could not find the language line "form_validation_captcha_check(qwert12345)"
INFO - 2016-06-03 18:50:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:50:39 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:50:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:50:39 --> Final output sent to browser
DEBUG - 2016-06-03 18:50:39 --> Total execution time: 0.0168
INFO - 2016-06-03 18:52:43 --> Config Class Initialized
INFO - 2016-06-03 18:52:43 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:52:43 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:52:43 --> Utf8 Class Initialized
INFO - 2016-06-03 18:52:43 --> URI Class Initialized
INFO - 2016-06-03 18:52:43 --> Router Class Initialized
INFO - 2016-06-03 18:52:43 --> Output Class Initialized
INFO - 2016-06-03 18:52:43 --> Security Class Initialized
DEBUG - 2016-06-03 18:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:52:43 --> CSRF cookie sent
INFO - 2016-06-03 18:52:43 --> CSRF token verified
INFO - 2016-06-03 18:52:43 --> Input Class Initialized
INFO - 2016-06-03 18:52:43 --> Language Class Initialized
INFO - 2016-06-03 18:52:43 --> Loader Class Initialized
INFO - 2016-06-03 18:52:43 --> Helper loaded: form_helper
INFO - 2016-06-03 18:52:43 --> Database Driver Class Initialized
INFO - 2016-06-03 18:52:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:52:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:52:43 --> Email Class Initialized
INFO - 2016-06-03 18:52:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:52:43 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:52:43 --> Helper loaded: language_helper
INFO - 2016-06-03 18:52:43 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:52:43 --> Model Class Initialized
INFO - 2016-06-03 18:52:43 --> Helper loaded: date_helper
INFO - 2016-06-03 18:52:43 --> Controller Class Initialized
INFO - 2016-06-03 18:52:43 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:52:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:52:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:52:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:52:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:52:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:52:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:52:43 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:52:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:52:43 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:52:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:52:43 --> Final output sent to browser
DEBUG - 2016-06-03 18:52:43 --> Total execution time: 0.0221
INFO - 2016-06-03 18:52:51 --> Config Class Initialized
INFO - 2016-06-03 18:52:51 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:52:51 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:52:51 --> Utf8 Class Initialized
INFO - 2016-06-03 18:52:51 --> URI Class Initialized
INFO - 2016-06-03 18:52:51 --> Router Class Initialized
INFO - 2016-06-03 18:52:51 --> Output Class Initialized
INFO - 2016-06-03 18:52:51 --> Security Class Initialized
DEBUG - 2016-06-03 18:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:52:51 --> CSRF cookie sent
INFO - 2016-06-03 18:52:51 --> CSRF token verified
INFO - 2016-06-03 18:52:51 --> Input Class Initialized
INFO - 2016-06-03 18:52:51 --> Language Class Initialized
INFO - 2016-06-03 18:52:51 --> Loader Class Initialized
INFO - 2016-06-03 18:52:51 --> Helper loaded: form_helper
INFO - 2016-06-03 18:52:51 --> Database Driver Class Initialized
INFO - 2016-06-03 18:52:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:52:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:52:51 --> Email Class Initialized
INFO - 2016-06-03 18:52:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:52:51 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:52:51 --> Helper loaded: language_helper
INFO - 2016-06-03 18:52:51 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:52:51 --> Model Class Initialized
INFO - 2016-06-03 18:52:51 --> Helper loaded: date_helper
INFO - 2016-06-03 18:52:51 --> Controller Class Initialized
INFO - 2016-06-03 18:52:51 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:52:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:52:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:52:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:52:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:52:51 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:52:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:52:51 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:52:51 --> Unable to find validation rule: captcha_check(adsad)
ERROR - 2016-06-03 18:52:51 --> Could not find the language line "form_validation_captcha_check(adsad)"
INFO - 2016-06-03 18:52:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:52:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:52:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:52:51 --> Final output sent to browser
DEBUG - 2016-06-03 18:52:51 --> Total execution time: 0.0231
INFO - 2016-06-03 18:53:14 --> Config Class Initialized
INFO - 2016-06-03 18:53:14 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:53:14 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:53:14 --> Utf8 Class Initialized
INFO - 2016-06-03 18:53:14 --> URI Class Initialized
INFO - 2016-06-03 18:53:14 --> Router Class Initialized
INFO - 2016-06-03 18:53:14 --> Output Class Initialized
INFO - 2016-06-03 18:53:14 --> Security Class Initialized
DEBUG - 2016-06-03 18:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:53:14 --> CSRF cookie sent
INFO - 2016-06-03 18:53:14 --> CSRF token verified
INFO - 2016-06-03 18:53:14 --> Input Class Initialized
INFO - 2016-06-03 18:53:14 --> Language Class Initialized
INFO - 2016-06-03 18:53:14 --> Loader Class Initialized
INFO - 2016-06-03 18:53:14 --> Helper loaded: form_helper
INFO - 2016-06-03 18:53:14 --> Database Driver Class Initialized
INFO - 2016-06-03 18:53:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:53:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:53:14 --> Email Class Initialized
INFO - 2016-06-03 18:53:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:53:14 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:53:14 --> Helper loaded: language_helper
INFO - 2016-06-03 18:53:14 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:53:14 --> Model Class Initialized
INFO - 2016-06-03 18:53:14 --> Helper loaded: date_helper
INFO - 2016-06-03 18:53:14 --> Controller Class Initialized
INFO - 2016-06-03 18:53:14 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:53:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:53:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:53:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:53:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:53:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:53:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:53:14 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:53:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:53:14 --> Unable to find validation rule: captcha_check(fds)
ERROR - 2016-06-03 18:53:14 --> Could not find the language line "form_validation_captcha_check(fds)"
INFO - 2016-06-03 18:53:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:53:14 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:53:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:53:14 --> Final output sent to browser
DEBUG - 2016-06-03 18:53:14 --> Total execution time: 0.0308
INFO - 2016-06-03 18:53:45 --> Config Class Initialized
INFO - 2016-06-03 18:53:45 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:53:45 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:53:45 --> Utf8 Class Initialized
INFO - 2016-06-03 18:53:45 --> URI Class Initialized
INFO - 2016-06-03 18:53:45 --> Router Class Initialized
INFO - 2016-06-03 18:53:45 --> Output Class Initialized
INFO - 2016-06-03 18:53:45 --> Security Class Initialized
DEBUG - 2016-06-03 18:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:53:45 --> CSRF cookie sent
INFO - 2016-06-03 18:53:45 --> CSRF token verified
INFO - 2016-06-03 18:53:45 --> Input Class Initialized
INFO - 2016-06-03 18:53:45 --> Language Class Initialized
INFO - 2016-06-03 18:53:45 --> Loader Class Initialized
INFO - 2016-06-03 18:53:45 --> Helper loaded: form_helper
INFO - 2016-06-03 18:53:45 --> Database Driver Class Initialized
INFO - 2016-06-03 18:53:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:53:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:53:45 --> Email Class Initialized
INFO - 2016-06-03 18:53:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:53:45 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:53:45 --> Helper loaded: language_helper
INFO - 2016-06-03 18:53:45 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:53:45 --> Model Class Initialized
INFO - 2016-06-03 18:53:45 --> Helper loaded: date_helper
INFO - 2016-06-03 18:53:45 --> Controller Class Initialized
INFO - 2016-06-03 18:53:45 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:53:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:53:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:53:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:53:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:53:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:53:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:53:45 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:53:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:53:45 --> Unable to find validation rule: captcha_check(tdf)
ERROR - 2016-06-03 18:53:45 --> Could not find the language line "form_validation_captcha_check(tdf)"
INFO - 2016-06-03 18:53:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:53:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:53:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:53:45 --> Final output sent to browser
DEBUG - 2016-06-03 18:53:45 --> Total execution time: 0.0420
INFO - 2016-06-03 18:56:15 --> Config Class Initialized
INFO - 2016-06-03 18:56:15 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:56:15 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:56:15 --> Utf8 Class Initialized
INFO - 2016-06-03 18:56:15 --> URI Class Initialized
INFO - 2016-06-03 18:56:15 --> Router Class Initialized
INFO - 2016-06-03 18:56:15 --> Output Class Initialized
INFO - 2016-06-03 18:56:15 --> Security Class Initialized
DEBUG - 2016-06-03 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:56:15 --> CSRF cookie sent
INFO - 2016-06-03 18:56:15 --> CSRF token verified
INFO - 2016-06-03 18:56:15 --> Input Class Initialized
INFO - 2016-06-03 18:56:15 --> Language Class Initialized
INFO - 2016-06-03 18:56:15 --> Loader Class Initialized
INFO - 2016-06-03 18:56:15 --> Helper loaded: form_helper
INFO - 2016-06-03 18:56:15 --> Database Driver Class Initialized
INFO - 2016-06-03 18:56:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:56:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:56:15 --> Email Class Initialized
INFO - 2016-06-03 18:56:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:56:15 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:56:15 --> Helper loaded: language_helper
INFO - 2016-06-03 18:56:15 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:56:15 --> Model Class Initialized
INFO - 2016-06-03 18:56:15 --> Helper loaded: date_helper
INFO - 2016-06-03 18:56:15 --> Controller Class Initialized
INFO - 2016-06-03 18:56:15 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:56:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:56:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:56:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:56:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:56:15 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:56:15 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:56:15 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:56:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:56:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:56:15 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:56:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:56:15 --> Final output sent to browser
DEBUG - 2016-06-03 18:56:15 --> Total execution time: 0.0215
INFO - 2016-06-03 18:56:23 --> Config Class Initialized
INFO - 2016-06-03 18:56:23 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:56:23 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:56:23 --> Utf8 Class Initialized
INFO - 2016-06-03 18:56:23 --> URI Class Initialized
INFO - 2016-06-03 18:56:23 --> Router Class Initialized
INFO - 2016-06-03 18:56:23 --> Output Class Initialized
INFO - 2016-06-03 18:56:23 --> Security Class Initialized
DEBUG - 2016-06-03 18:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:56:23 --> CSRF cookie sent
INFO - 2016-06-03 18:56:23 --> CSRF token verified
INFO - 2016-06-03 18:56:23 --> Input Class Initialized
INFO - 2016-06-03 18:56:23 --> Language Class Initialized
INFO - 2016-06-03 18:56:23 --> Loader Class Initialized
INFO - 2016-06-03 18:56:23 --> Helper loaded: form_helper
INFO - 2016-06-03 18:56:23 --> Database Driver Class Initialized
INFO - 2016-06-03 18:56:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:56:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:56:23 --> Email Class Initialized
INFO - 2016-06-03 18:56:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:56:23 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:56:23 --> Helper loaded: language_helper
INFO - 2016-06-03 18:56:23 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:56:23 --> Model Class Initialized
INFO - 2016-06-03 18:56:23 --> Helper loaded: date_helper
INFO - 2016-06-03 18:56:23 --> Controller Class Initialized
INFO - 2016-06-03 18:56:23 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:56:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:56:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:56:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:56:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:56:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:56:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:56:23 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:56:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:56:23 --> Unable to find validation rule: captcha_check(gfd)
ERROR - 2016-06-03 18:56:23 --> Could not find the language line "form_validation_captcha_check(gfd)"
INFO - 2016-06-03 18:56:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:56:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:56:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:56:23 --> Final output sent to browser
DEBUG - 2016-06-03 18:56:23 --> Total execution time: 0.0261
INFO - 2016-06-03 18:57:22 --> Config Class Initialized
INFO - 2016-06-03 18:57:22 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:57:22 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:57:22 --> Utf8 Class Initialized
INFO - 2016-06-03 18:57:22 --> URI Class Initialized
INFO - 2016-06-03 18:57:22 --> Router Class Initialized
INFO - 2016-06-03 18:57:22 --> Output Class Initialized
INFO - 2016-06-03 18:57:22 --> Security Class Initialized
DEBUG - 2016-06-03 18:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:57:22 --> CSRF cookie sent
INFO - 2016-06-03 18:57:22 --> CSRF token verified
INFO - 2016-06-03 18:57:22 --> Input Class Initialized
INFO - 2016-06-03 18:57:22 --> Language Class Initialized
INFO - 2016-06-03 18:57:22 --> Loader Class Initialized
INFO - 2016-06-03 18:57:22 --> Helper loaded: form_helper
INFO - 2016-06-03 18:57:22 --> Database Driver Class Initialized
INFO - 2016-06-03 18:57:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:57:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:57:22 --> Email Class Initialized
INFO - 2016-06-03 18:57:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:57:22 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:57:22 --> Helper loaded: language_helper
INFO - 2016-06-03 18:57:22 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:57:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:57:22 --> Model Class Initialized
INFO - 2016-06-03 18:57:22 --> Helper loaded: date_helper
INFO - 2016-06-03 18:57:22 --> Controller Class Initialized
INFO - 2016-06-03 18:57:22 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:57:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:57:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:57:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:57:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:57:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:57:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:57:22 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:57:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:57:22 --> Unable to find validation rule: captcha_check(gfdgf)
ERROR - 2016-06-03 18:57:22 --> Could not find the language line "form_validation_captcha_check(gfdgf)"
INFO - 2016-06-03 18:57:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:57:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:57:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:57:22 --> Final output sent to browser
DEBUG - 2016-06-03 18:57:22 --> Total execution time: 0.0387
INFO - 2016-06-03 18:58:33 --> Config Class Initialized
INFO - 2016-06-03 18:58:33 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:58:33 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:58:33 --> Utf8 Class Initialized
INFO - 2016-06-03 18:58:33 --> URI Class Initialized
INFO - 2016-06-03 18:58:33 --> Router Class Initialized
INFO - 2016-06-03 18:58:33 --> Output Class Initialized
INFO - 2016-06-03 18:58:33 --> Security Class Initialized
DEBUG - 2016-06-03 18:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:58:33 --> CSRF cookie sent
INFO - 2016-06-03 18:58:33 --> CSRF token verified
INFO - 2016-06-03 18:58:33 --> Input Class Initialized
INFO - 2016-06-03 18:58:33 --> Language Class Initialized
INFO - 2016-06-03 18:58:33 --> Loader Class Initialized
INFO - 2016-06-03 18:58:33 --> Helper loaded: form_helper
INFO - 2016-06-03 18:58:33 --> Database Driver Class Initialized
INFO - 2016-06-03 18:58:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:58:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:58:33 --> Email Class Initialized
INFO - 2016-06-03 18:58:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:58:33 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:58:33 --> Helper loaded: language_helper
INFO - 2016-06-03 18:58:33 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:58:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:58:33 --> Model Class Initialized
INFO - 2016-06-03 18:58:33 --> Helper loaded: date_helper
INFO - 2016-06-03 18:58:33 --> Controller Class Initialized
INFO - 2016-06-03 18:58:33 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:58:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:58:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:58:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:58:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:58:33 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:58:33 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-06-03 18:58:33 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/demis/www/platformadiabet/application/libraries/SVS_Form_validation.php 45
INFO - 2016-06-03 18:58:58 --> Config Class Initialized
INFO - 2016-06-03 18:58:58 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:58:58 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:58:58 --> Utf8 Class Initialized
INFO - 2016-06-03 18:58:58 --> URI Class Initialized
INFO - 2016-06-03 18:58:58 --> Router Class Initialized
INFO - 2016-06-03 18:58:58 --> Output Class Initialized
INFO - 2016-06-03 18:58:58 --> Security Class Initialized
DEBUG - 2016-06-03 18:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:59:24 --> Config Class Initialized
INFO - 2016-06-03 18:59:24 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:59:24 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:59:24 --> Utf8 Class Initialized
INFO - 2016-06-03 18:59:24 --> URI Class Initialized
INFO - 2016-06-03 18:59:24 --> Router Class Initialized
INFO - 2016-06-03 18:59:24 --> Output Class Initialized
INFO - 2016-06-03 18:59:24 --> Security Class Initialized
DEBUG - 2016-06-03 18:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:59:24 --> CSRF cookie sent
INFO - 2016-06-03 18:59:24 --> Input Class Initialized
INFO - 2016-06-03 18:59:24 --> Language Class Initialized
INFO - 2016-06-03 18:59:24 --> Loader Class Initialized
INFO - 2016-06-03 18:59:24 --> Helper loaded: form_helper
INFO - 2016-06-03 18:59:24 --> Database Driver Class Initialized
INFO - 2016-06-03 18:59:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:59:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:59:24 --> Email Class Initialized
INFO - 2016-06-03 18:59:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:59:24 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:59:24 --> Helper loaded: language_helper
INFO - 2016-06-03 18:59:24 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:59:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:59:24 --> Model Class Initialized
INFO - 2016-06-03 18:59:24 --> Helper loaded: date_helper
INFO - 2016-06-03 18:59:24 --> Controller Class Initialized
INFO - 2016-06-03 18:59:24 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:59:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:59:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:59:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:59:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:59:24 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:59:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:59:24 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:59:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:59:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:59:24 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:59:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:59:24 --> Final output sent to browser
DEBUG - 2016-06-03 18:59:24 --> Total execution time: 0.0482
INFO - 2016-06-03 18:59:38 --> Config Class Initialized
INFO - 2016-06-03 18:59:38 --> Hooks Class Initialized
DEBUG - 2016-06-03 18:59:38 --> UTF-8 Support Enabled
INFO - 2016-06-03 18:59:38 --> Utf8 Class Initialized
INFO - 2016-06-03 18:59:38 --> URI Class Initialized
INFO - 2016-06-03 18:59:38 --> Router Class Initialized
INFO - 2016-06-03 18:59:38 --> Output Class Initialized
INFO - 2016-06-03 18:59:38 --> Security Class Initialized
DEBUG - 2016-06-03 18:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 18:59:38 --> CSRF cookie sent
INFO - 2016-06-03 18:59:38 --> CSRF token verified
INFO - 2016-06-03 18:59:38 --> Input Class Initialized
INFO - 2016-06-03 18:59:38 --> Language Class Initialized
INFO - 2016-06-03 18:59:38 --> Loader Class Initialized
INFO - 2016-06-03 18:59:38 --> Helper loaded: form_helper
INFO - 2016-06-03 18:59:38 --> Database Driver Class Initialized
INFO - 2016-06-03 18:59:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 18:59:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 18:59:38 --> Email Class Initialized
INFO - 2016-06-03 18:59:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 18:59:38 --> Helper loaded: cookie_helper
INFO - 2016-06-03 18:59:38 --> Helper loaded: language_helper
INFO - 2016-06-03 18:59:38 --> Helper loaded: url_helper
DEBUG - 2016-06-03 18:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:59:38 --> Model Class Initialized
INFO - 2016-06-03 18:59:38 --> Helper loaded: date_helper
INFO - 2016-06-03 18:59:38 --> Controller Class Initialized
INFO - 2016-06-03 18:59:38 --> Helper loaded: languages_helper
INFO - 2016-06-03 18:59:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 18:59:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 18:59:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 18:59:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 18:59:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 18:59:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 18:59:38 --> Form Validation Class Initialized
DEBUG - 2016-06-03 18:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 18:59:38 --> Unable to find validation rule: captcha_check(hgfd)
ERROR - 2016-06-03 18:59:38 --> Could not find the language line "form_validation_captcha_check(hgfd)"
INFO - 2016-06-03 18:59:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 18:59:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 18:59:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 18:59:38 --> Final output sent to browser
DEBUG - 2016-06-03 18:59:38 --> Total execution time: 0.0419
INFO - 2016-06-03 19:00:18 --> Config Class Initialized
INFO - 2016-06-03 19:00:18 --> Hooks Class Initialized
DEBUG - 2016-06-03 19:00:18 --> UTF-8 Support Enabled
INFO - 2016-06-03 19:00:18 --> Utf8 Class Initialized
INFO - 2016-06-03 19:00:18 --> URI Class Initialized
INFO - 2016-06-03 19:00:18 --> Router Class Initialized
INFO - 2016-06-03 19:00:18 --> Output Class Initialized
INFO - 2016-06-03 19:00:18 --> Security Class Initialized
DEBUG - 2016-06-03 19:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 19:00:18 --> CSRF cookie sent
INFO - 2016-06-03 19:00:18 --> CSRF token verified
INFO - 2016-06-03 19:00:18 --> Input Class Initialized
INFO - 2016-06-03 19:00:18 --> Language Class Initialized
INFO - 2016-06-03 19:00:18 --> Loader Class Initialized
INFO - 2016-06-03 19:00:18 --> Helper loaded: form_helper
INFO - 2016-06-03 19:00:18 --> Database Driver Class Initialized
INFO - 2016-06-03 19:00:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 19:00:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 19:00:18 --> Email Class Initialized
INFO - 2016-06-03 19:00:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 19:00:18 --> Helper loaded: cookie_helper
INFO - 2016-06-03 19:00:18 --> Helper loaded: language_helper
INFO - 2016-06-03 19:00:18 --> Helper loaded: url_helper
DEBUG - 2016-06-03 19:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:00:18 --> Model Class Initialized
INFO - 2016-06-03 19:00:18 --> Helper loaded: date_helper
INFO - 2016-06-03 19:00:18 --> Controller Class Initialized
INFO - 2016-06-03 19:00:18 --> Helper loaded: languages_helper
INFO - 2016-06-03 19:00:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 19:00:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 19:00:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 19:00:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 19:00:18 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 19:00:18 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:00:18 --> Form Validation Class Initialized
DEBUG - 2016-06-03 19:00:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 19:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 19:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 19:00:18 --> Final output sent to browser
DEBUG - 2016-06-03 19:00:18 --> Total execution time: 0.0334
INFO - 2016-06-03 19:00:27 --> Config Class Initialized
INFO - 2016-06-03 19:00:27 --> Hooks Class Initialized
DEBUG - 2016-06-03 19:00:27 --> UTF-8 Support Enabled
INFO - 2016-06-03 19:00:27 --> Utf8 Class Initialized
INFO - 2016-06-03 19:00:27 --> URI Class Initialized
INFO - 2016-06-03 19:00:27 --> Router Class Initialized
INFO - 2016-06-03 19:00:27 --> Output Class Initialized
INFO - 2016-06-03 19:00:27 --> Security Class Initialized
DEBUG - 2016-06-03 19:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 19:00:27 --> CSRF cookie sent
INFO - 2016-06-03 19:00:27 --> CSRF token verified
INFO - 2016-06-03 19:00:27 --> Input Class Initialized
INFO - 2016-06-03 19:00:27 --> Language Class Initialized
INFO - 2016-06-03 19:00:27 --> Loader Class Initialized
INFO - 2016-06-03 19:00:27 --> Helper loaded: form_helper
INFO - 2016-06-03 19:00:27 --> Database Driver Class Initialized
INFO - 2016-06-03 19:00:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 19:00:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 19:00:27 --> Email Class Initialized
INFO - 2016-06-03 19:00:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 19:00:27 --> Helper loaded: cookie_helper
INFO - 2016-06-03 19:00:27 --> Helper loaded: language_helper
INFO - 2016-06-03 19:00:27 --> Helper loaded: url_helper
DEBUG - 2016-06-03 19:00:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:00:27 --> Model Class Initialized
INFO - 2016-06-03 19:00:27 --> Helper loaded: date_helper
INFO - 2016-06-03 19:00:27 --> Controller Class Initialized
INFO - 2016-06-03 19:00:27 --> Helper loaded: languages_helper
INFO - 2016-06-03 19:00:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 19:00:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 19:00:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 19:00:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 19:00:27 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 19:00:27 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:00:27 --> Form Validation Class Initialized
DEBUG - 2016-06-03 19:00:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 19:00:27 --> Unable to find validation rule: captcha_check(gfd)
ERROR - 2016-06-03 19:00:27 --> Could not find the language line "form_validation_captcha_check(gfd)"
INFO - 2016-06-03 19:00:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 19:00:27 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 19:00:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 19:00:27 --> Final output sent to browser
DEBUG - 2016-06-03 19:00:27 --> Total execution time: 0.0161
INFO - 2016-06-03 19:04:41 --> Config Class Initialized
INFO - 2016-06-03 19:04:41 --> Hooks Class Initialized
DEBUG - 2016-06-03 19:04:41 --> UTF-8 Support Enabled
INFO - 2016-06-03 19:04:41 --> Utf8 Class Initialized
INFO - 2016-06-03 19:04:41 --> URI Class Initialized
INFO - 2016-06-03 19:04:41 --> Router Class Initialized
INFO - 2016-06-03 19:04:41 --> Output Class Initialized
INFO - 2016-06-03 19:04:41 --> Security Class Initialized
DEBUG - 2016-06-03 19:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 19:04:41 --> CSRF cookie sent
INFO - 2016-06-03 19:04:41 --> CSRF token verified
INFO - 2016-06-03 19:04:41 --> Input Class Initialized
INFO - 2016-06-03 19:04:41 --> Language Class Initialized
INFO - 2016-06-03 19:04:41 --> Loader Class Initialized
INFO - 2016-06-03 19:04:41 --> Helper loaded: form_helper
INFO - 2016-06-03 19:04:41 --> Database Driver Class Initialized
INFO - 2016-06-03 19:04:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 19:04:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 19:04:41 --> Email Class Initialized
INFO - 2016-06-03 19:04:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 19:04:41 --> Helper loaded: cookie_helper
INFO - 2016-06-03 19:04:41 --> Helper loaded: language_helper
INFO - 2016-06-03 19:04:41 --> Helper loaded: url_helper
DEBUG - 2016-06-03 19:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:04:41 --> Model Class Initialized
INFO - 2016-06-03 19:04:41 --> Helper loaded: date_helper
INFO - 2016-06-03 19:04:41 --> Controller Class Initialized
INFO - 2016-06-03 19:04:41 --> Helper loaded: languages_helper
INFO - 2016-06-03 19:04:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 19:04:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 19:04:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 19:04:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 19:04:41 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 19:04:41 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:04:41 --> Form Validation Class Initialized
DEBUG - 2016-06-03 19:04:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 19:04:41 --> Unable to find validation rule: captcha_check()
ERROR - 2016-06-03 19:04:41 --> Could not find the language line "form_validation_captcha_check()"
INFO - 2016-06-03 19:04:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 19:04:41 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 19:04:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 19:04:41 --> Final output sent to browser
DEBUG - 2016-06-03 19:04:41 --> Total execution time: 0.0396
INFO - 2016-06-03 19:05:30 --> Config Class Initialized
INFO - 2016-06-03 19:05:30 --> Hooks Class Initialized
DEBUG - 2016-06-03 19:05:30 --> UTF-8 Support Enabled
INFO - 2016-06-03 19:05:30 --> Utf8 Class Initialized
INFO - 2016-06-03 19:05:30 --> URI Class Initialized
INFO - 2016-06-03 19:05:30 --> Router Class Initialized
INFO - 2016-06-03 19:05:30 --> Output Class Initialized
INFO - 2016-06-03 19:05:30 --> Security Class Initialized
DEBUG - 2016-06-03 19:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 19:05:44 --> Config Class Initialized
INFO - 2016-06-03 19:05:44 --> Hooks Class Initialized
DEBUG - 2016-06-03 19:05:44 --> UTF-8 Support Enabled
INFO - 2016-06-03 19:05:44 --> Utf8 Class Initialized
INFO - 2016-06-03 19:05:44 --> URI Class Initialized
INFO - 2016-06-03 19:05:44 --> Router Class Initialized
INFO - 2016-06-03 19:05:44 --> Output Class Initialized
INFO - 2016-06-03 19:05:44 --> Security Class Initialized
DEBUG - 2016-06-03 19:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 19:05:44 --> CSRF cookie sent
INFO - 2016-06-03 19:05:44 --> Input Class Initialized
INFO - 2016-06-03 19:05:44 --> Language Class Initialized
INFO - 2016-06-03 19:05:44 --> Loader Class Initialized
INFO - 2016-06-03 19:05:44 --> Helper loaded: form_helper
INFO - 2016-06-03 19:05:44 --> Database Driver Class Initialized
INFO - 2016-06-03 19:05:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 19:05:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 19:05:44 --> Email Class Initialized
INFO - 2016-06-03 19:05:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 19:05:44 --> Helper loaded: cookie_helper
INFO - 2016-06-03 19:05:44 --> Helper loaded: language_helper
INFO - 2016-06-03 19:05:44 --> Helper loaded: url_helper
DEBUG - 2016-06-03 19:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:05:44 --> Model Class Initialized
INFO - 2016-06-03 19:05:44 --> Helper loaded: date_helper
INFO - 2016-06-03 19:05:44 --> Controller Class Initialized
INFO - 2016-06-03 19:05:44 --> Helper loaded: languages_helper
INFO - 2016-06-03 19:05:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 19:05:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 19:05:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 19:05:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 19:05:44 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 19:05:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:05:44 --> Form Validation Class Initialized
DEBUG - 2016-06-03 19:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:05:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 19:05:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 19:05:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 19:05:44 --> Final output sent to browser
DEBUG - 2016-06-03 19:05:44 --> Total execution time: 0.0669
INFO - 2016-06-03 19:05:52 --> Config Class Initialized
INFO - 2016-06-03 19:05:52 --> Hooks Class Initialized
DEBUG - 2016-06-03 19:05:52 --> UTF-8 Support Enabled
INFO - 2016-06-03 19:05:52 --> Utf8 Class Initialized
INFO - 2016-06-03 19:05:52 --> URI Class Initialized
INFO - 2016-06-03 19:05:52 --> Router Class Initialized
INFO - 2016-06-03 19:05:52 --> Output Class Initialized
INFO - 2016-06-03 19:05:52 --> Security Class Initialized
DEBUG - 2016-06-03 19:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-03 19:05:52 --> CSRF cookie sent
INFO - 2016-06-03 19:05:52 --> CSRF token verified
INFO - 2016-06-03 19:05:52 --> Input Class Initialized
INFO - 2016-06-03 19:05:52 --> Language Class Initialized
INFO - 2016-06-03 19:05:52 --> Loader Class Initialized
INFO - 2016-06-03 19:05:52 --> Helper loaded: form_helper
INFO - 2016-06-03 19:05:52 --> Database Driver Class Initialized
INFO - 2016-06-03 19:05:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-03 19:05:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-03 19:05:52 --> Email Class Initialized
INFO - 2016-06-03 19:05:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-03 19:05:52 --> Helper loaded: cookie_helper
INFO - 2016-06-03 19:05:52 --> Helper loaded: language_helper
INFO - 2016-06-03 19:05:52 --> Helper loaded: url_helper
DEBUG - 2016-06-03 19:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:05:52 --> Model Class Initialized
INFO - 2016-06-03 19:05:52 --> Helper loaded: date_helper
INFO - 2016-06-03 19:05:52 --> Controller Class Initialized
INFO - 2016-06-03 19:05:52 --> Helper loaded: languages_helper
INFO - 2016-06-03 19:05:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-03 19:05:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-03 19:05:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-03 19:05:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-03 19:05:52 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-03 19:05:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-03 19:05:52 --> Form Validation Class Initialized
DEBUG - 2016-06-03 19:05:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-03 19:05:52 --> Unable to find validation rule: captcha_check()
ERROR - 2016-06-03 19:05:52 --> Could not find the language line "form_validation_captcha_check()"
INFO - 2016-06-03 19:05:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-03 19:05:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-03 19:05:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-03 19:05:52 --> Final output sent to browser
DEBUG - 2016-06-03 19:05:52 --> Total execution time: 0.0194
