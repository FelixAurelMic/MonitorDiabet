<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-02 10:23:27 --> Config Class Initialized
INFO - 2016-06-02 10:23:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:23:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:23:27 --> Utf8 Class Initialized
INFO - 2016-06-02 10:23:27 --> URI Class Initialized
INFO - 2016-06-02 10:23:27 --> Router Class Initialized
INFO - 2016-06-02 10:23:27 --> Output Class Initialized
INFO - 2016-06-02 10:23:27 --> Security Class Initialized
DEBUG - 2016-06-02 10:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:23:27 --> CSRF cookie sent
INFO - 2016-06-02 10:23:27 --> Input Class Initialized
INFO - 2016-06-02 10:23:27 --> Language Class Initialized
INFO - 2016-06-02 10:23:27 --> Loader Class Initialized
INFO - 2016-06-02 10:23:27 --> Helper loaded: form_helper
INFO - 2016-06-02 10:23:27 --> Database Driver Class Initialized
INFO - 2016-06-02 10:23:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:23:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:23:28 --> Email Class Initialized
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:23:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:23:28 --> Helper loaded: language_helper
INFO - 2016-06-02 10:23:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:23:28 --> Model Class Initialized
INFO - 2016-06-02 10:23:28 --> Helper loaded: date_helper
INFO - 2016-06-02 10:23:28 --> Controller Class Initialized
INFO - 2016-06-02 10:23:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:23:28 --> Model Class Initialized
INFO - 2016-06-02 10:23:28 --> Form Validation Class Initialized
INFO - 2016-06-02 10:23:28 --> Config Class Initialized
INFO - 2016-06-02 10:23:28 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:23:28 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:23:28 --> Utf8 Class Initialized
INFO - 2016-06-02 10:23:28 --> URI Class Initialized
INFO - 2016-06-02 10:23:28 --> Router Class Initialized
INFO - 2016-06-02 10:23:28 --> Output Class Initialized
INFO - 2016-06-02 10:23:28 --> Security Class Initialized
DEBUG - 2016-06-02 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:23:28 --> CSRF cookie sent
INFO - 2016-06-02 10:23:28 --> Input Class Initialized
INFO - 2016-06-02 10:23:28 --> Language Class Initialized
INFO - 2016-06-02 10:23:28 --> Loader Class Initialized
INFO - 2016-06-02 10:23:28 --> Helper loaded: form_helper
INFO - 2016-06-02 10:23:28 --> Database Driver Class Initialized
INFO - 2016-06-02 10:23:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:23:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:23:28 --> Email Class Initialized
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:23:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:23:28 --> Helper loaded: language_helper
INFO - 2016-06-02 10:23:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:23:28 --> Model Class Initialized
INFO - 2016-06-02 10:23:28 --> Helper loaded: date_helper
INFO - 2016-06-02 10:23:28 --> Controller Class Initialized
INFO - 2016-06-02 10:23:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:23:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-02 10:23:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:23:28 --> Form Validation Class Initialized
INFO - 2016-06-02 10:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-02 10:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-02 10:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-02 10:23:28 --> Final output sent to browser
DEBUG - 2016-06-02 10:23:28 --> Total execution time: 0.2155
INFO - 2016-06-02 10:23:30 --> Config Class Initialized
INFO - 2016-06-02 10:23:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:23:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:23:30 --> Utf8 Class Initialized
INFO - 2016-06-02 10:23:30 --> URI Class Initialized
DEBUG - 2016-06-02 10:23:30 --> No URI present. Default controller set.
INFO - 2016-06-02 10:23:30 --> Router Class Initialized
INFO - 2016-06-02 10:23:30 --> Output Class Initialized
INFO - 2016-06-02 10:23:30 --> Security Class Initialized
DEBUG - 2016-06-02 10:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:23:30 --> CSRF cookie sent
INFO - 2016-06-02 10:23:30 --> Input Class Initialized
INFO - 2016-06-02 10:23:30 --> Language Class Initialized
INFO - 2016-06-02 10:23:30 --> Loader Class Initialized
INFO - 2016-06-02 10:23:30 --> Helper loaded: form_helper
INFO - 2016-06-02 10:23:30 --> Database Driver Class Initialized
INFO - 2016-06-02 10:23:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:23:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:23:30 --> Email Class Initialized
INFO - 2016-06-02 10:23:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:23:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:23:30 --> Helper loaded: language_helper
INFO - 2016-06-02 10:23:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:23:30 --> Model Class Initialized
INFO - 2016-06-02 10:23:30 --> Helper loaded: date_helper
INFO - 2016-06-02 10:23:30 --> Controller Class Initialized
INFO - 2016-06-02 10:23:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:23:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:23:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:23:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:23:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:23:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-02 10:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-02 10:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-02 10:23:30 --> Final output sent to browser
DEBUG - 2016-06-02 10:23:30 --> Total execution time: 0.1209
INFO - 2016-06-02 10:23:33 --> Config Class Initialized
INFO - 2016-06-02 10:23:33 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:23:33 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:23:33 --> Utf8 Class Initialized
INFO - 2016-06-02 10:23:33 --> URI Class Initialized
INFO - 2016-06-02 10:23:33 --> Router Class Initialized
INFO - 2016-06-02 10:23:33 --> Output Class Initialized
INFO - 2016-06-02 10:23:33 --> Security Class Initialized
DEBUG - 2016-06-02 10:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:23:33 --> CSRF cookie sent
INFO - 2016-06-02 10:23:33 --> Input Class Initialized
INFO - 2016-06-02 10:23:33 --> Language Class Initialized
ERROR - 2016-06-02 10:23:33 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-02 10:23:41 --> Config Class Initialized
INFO - 2016-06-02 10:23:41 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:23:41 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:23:41 --> Utf8 Class Initialized
INFO - 2016-06-02 10:23:41 --> URI Class Initialized
INFO - 2016-06-02 10:23:41 --> Router Class Initialized
INFO - 2016-06-02 10:23:41 --> Output Class Initialized
INFO - 2016-06-02 10:23:41 --> Security Class Initialized
DEBUG - 2016-06-02 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:23:41 --> CSRF cookie sent
INFO - 2016-06-02 10:23:41 --> Input Class Initialized
INFO - 2016-06-02 10:23:41 --> Language Class Initialized
INFO - 2016-06-02 10:23:41 --> Loader Class Initialized
INFO - 2016-06-02 10:23:41 --> Helper loaded: form_helper
INFO - 2016-06-02 10:23:41 --> Database Driver Class Initialized
INFO - 2016-06-02 10:23:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:23:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:23:41 --> Email Class Initialized
INFO - 2016-06-02 10:23:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:23:41 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:23:41 --> Helper loaded: language_helper
INFO - 2016-06-02 10:23:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:23:41 --> Model Class Initialized
INFO - 2016-06-02 10:23:41 --> Helper loaded: date_helper
INFO - 2016-06-02 10:23:41 --> Controller Class Initialized
INFO - 2016-06-02 10:23:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:23:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:23:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:23:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:23:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:23:41 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-02 10:23:41 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:23:41 --> Form Validation Class Initialized
INFO - 2016-06-02 10:23:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-02 10:23:41 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-02 10:23:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-02 10:23:41 --> Final output sent to browser
DEBUG - 2016-06-02 10:23:41 --> Total execution time: 0.0665
INFO - 2016-06-02 10:25:08 --> Config Class Initialized
INFO - 2016-06-02 10:25:08 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:25:08 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:25:08 --> Utf8 Class Initialized
INFO - 2016-06-02 10:25:08 --> URI Class Initialized
DEBUG - 2016-06-02 10:25:08 --> No URI present. Default controller set.
INFO - 2016-06-02 10:25:08 --> Router Class Initialized
INFO - 2016-06-02 10:25:08 --> Output Class Initialized
INFO - 2016-06-02 10:25:08 --> Security Class Initialized
DEBUG - 2016-06-02 10:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:25:08 --> CSRF cookie sent
INFO - 2016-06-02 10:25:08 --> Input Class Initialized
INFO - 2016-06-02 10:25:08 --> Language Class Initialized
INFO - 2016-06-02 10:25:08 --> Loader Class Initialized
INFO - 2016-06-02 10:25:08 --> Helper loaded: form_helper
INFO - 2016-06-02 10:25:08 --> Database Driver Class Initialized
INFO - 2016-06-02 10:25:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:25:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:25:08 --> Email Class Initialized
INFO - 2016-06-02 10:25:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:25:08 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:25:08 --> Helper loaded: language_helper
INFO - 2016-06-02 10:25:08 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:25:08 --> Model Class Initialized
INFO - 2016-06-02 10:25:08 --> Helper loaded: date_helper
INFO - 2016-06-02 10:25:08 --> Controller Class Initialized
INFO - 2016-06-02 10:25:08 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:25:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:25:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:25:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:25:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:25:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:25:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-02 10:25:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-02 10:25:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-02 10:25:08 --> Final output sent to browser
DEBUG - 2016-06-02 10:25:08 --> Total execution time: 0.0297
INFO - 2016-06-02 10:31:21 --> Config Class Initialized
INFO - 2016-06-02 10:31:21 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:31:21 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:31:21 --> Utf8 Class Initialized
INFO - 2016-06-02 10:31:21 --> URI Class Initialized
INFO - 2016-06-02 10:31:21 --> Router Class Initialized
INFO - 2016-06-02 10:31:21 --> Output Class Initialized
INFO - 2016-06-02 10:31:21 --> Security Class Initialized
DEBUG - 2016-06-02 10:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:31:21 --> CSRF cookie sent
INFO - 2016-06-02 10:31:21 --> CSRF token verified
INFO - 2016-06-02 10:31:21 --> Input Class Initialized
INFO - 2016-06-02 10:31:21 --> Language Class Initialized
INFO - 2016-06-02 10:31:21 --> Loader Class Initialized
INFO - 2016-06-02 10:31:21 --> Helper loaded: form_helper
INFO - 2016-06-02 10:31:21 --> Database Driver Class Initialized
INFO - 2016-06-02 10:31:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:31:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:31:21 --> Email Class Initialized
INFO - 2016-06-02 10:31:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:31:21 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:31:21 --> Helper loaded: language_helper
INFO - 2016-06-02 10:31:21 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:31:21 --> Model Class Initialized
INFO - 2016-06-02 10:31:21 --> Helper loaded: date_helper
INFO - 2016-06-02 10:31:21 --> Controller Class Initialized
INFO - 2016-06-02 10:31:21 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:31:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:31:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:31:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:31:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:31:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-02 10:31:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:31:21 --> Form Validation Class Initialized
INFO - 2016-06-02 10:31:23 --> Config Class Initialized
INFO - 2016-06-02 10:31:23 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:31:23 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:31:23 --> Utf8 Class Initialized
INFO - 2016-06-02 10:31:23 --> URI Class Initialized
DEBUG - 2016-06-02 10:31:23 --> No URI present. Default controller set.
INFO - 2016-06-02 10:31:23 --> Router Class Initialized
INFO - 2016-06-02 10:31:23 --> Output Class Initialized
INFO - 2016-06-02 10:31:23 --> Security Class Initialized
DEBUG - 2016-06-02 10:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:31:23 --> CSRF cookie sent
INFO - 2016-06-02 10:31:23 --> Input Class Initialized
INFO - 2016-06-02 10:31:23 --> Language Class Initialized
INFO - 2016-06-02 10:31:23 --> Loader Class Initialized
INFO - 2016-06-02 10:31:23 --> Helper loaded: form_helper
INFO - 2016-06-02 10:31:23 --> Database Driver Class Initialized
INFO - 2016-06-02 10:31:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:31:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:31:23 --> Email Class Initialized
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:31:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:31:23 --> Helper loaded: language_helper
INFO - 2016-06-02 10:31:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:31:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:31:23 --> Model Class Initialized
INFO - 2016-06-02 10:31:23 --> Helper loaded: date_helper
INFO - 2016-06-02 10:31:23 --> Controller Class Initialized
INFO - 2016-06-02 10:31:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:31:23 --> Config Class Initialized
INFO - 2016-06-02 10:31:23 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:31:23 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:31:23 --> Utf8 Class Initialized
INFO - 2016-06-02 10:31:23 --> URI Class Initialized
INFO - 2016-06-02 10:31:23 --> Router Class Initialized
INFO - 2016-06-02 10:31:23 --> Output Class Initialized
INFO - 2016-06-02 10:31:23 --> Security Class Initialized
DEBUG - 2016-06-02 10:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:31:23 --> CSRF cookie sent
INFO - 2016-06-02 10:31:23 --> Input Class Initialized
INFO - 2016-06-02 10:31:23 --> Language Class Initialized
INFO - 2016-06-02 10:31:23 --> Loader Class Initialized
INFO - 2016-06-02 10:31:23 --> Helper loaded: form_helper
INFO - 2016-06-02 10:31:23 --> Database Driver Class Initialized
INFO - 2016-06-02 10:31:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:31:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:31:23 --> Email Class Initialized
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:31:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:31:23 --> Helper loaded: language_helper
INFO - 2016-06-02 10:31:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:31:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:31:23 --> Model Class Initialized
INFO - 2016-06-02 10:31:23 --> Helper loaded: date_helper
INFO - 2016-06-02 10:31:23 --> Controller Class Initialized
INFO - 2016-06-02 10:31:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:31:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:31:23 --> Model Class Initialized
INFO - 2016-06-02 10:31:23 --> Form Validation Class Initialized
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 10:31:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 10:31:23 --> Final output sent to browser
DEBUG - 2016-06-02 10:31:23 --> Total execution time: 0.1469
INFO - 2016-06-02 10:31:27 --> Config Class Initialized
INFO - 2016-06-02 10:31:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:31:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:31:27 --> Utf8 Class Initialized
INFO - 2016-06-02 10:31:27 --> URI Class Initialized
INFO - 2016-06-02 10:31:27 --> Router Class Initialized
INFO - 2016-06-02 10:31:27 --> Output Class Initialized
INFO - 2016-06-02 10:31:27 --> Security Class Initialized
DEBUG - 2016-06-02 10:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:31:27 --> CSRF cookie sent
INFO - 2016-06-02 10:31:27 --> CSRF token verified
INFO - 2016-06-02 10:31:27 --> Input Class Initialized
INFO - 2016-06-02 10:31:27 --> Language Class Initialized
INFO - 2016-06-02 10:31:27 --> Loader Class Initialized
INFO - 2016-06-02 10:31:27 --> Helper loaded: form_helper
INFO - 2016-06-02 10:31:27 --> Database Driver Class Initialized
INFO - 2016-06-02 10:31:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:31:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:31:27 --> Email Class Initialized
INFO - 2016-06-02 10:31:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:31:27 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:31:27 --> Helper loaded: language_helper
INFO - 2016-06-02 10:31:27 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:31:27 --> Model Class Initialized
INFO - 2016-06-02 10:31:27 --> Helper loaded: date_helper
INFO - 2016-06-02 10:31:27 --> Controller Class Initialized
INFO - 2016-06-02 10:31:27 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:31:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:31:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:31:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:31:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:31:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:31:27 --> Model Class Initialized
INFO - 2016-06-02 10:31:27 --> Form Validation Class Initialized
INFO - 2016-06-02 10:31:27 --> Final output sent to browser
DEBUG - 2016-06-02 10:31:27 --> Total execution time: 0.0635
INFO - 2016-06-02 10:32:07 --> Config Class Initialized
INFO - 2016-06-02 10:32:07 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:32:07 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:32:07 --> Utf8 Class Initialized
INFO - 2016-06-02 10:32:07 --> URI Class Initialized
INFO - 2016-06-02 10:32:07 --> Router Class Initialized
INFO - 2016-06-02 10:32:07 --> Output Class Initialized
INFO - 2016-06-02 10:32:07 --> Security Class Initialized
DEBUG - 2016-06-02 10:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:32:07 --> CSRF cookie sent
INFO - 2016-06-02 10:32:07 --> Input Class Initialized
INFO - 2016-06-02 10:32:07 --> Language Class Initialized
INFO - 2016-06-02 10:32:07 --> Loader Class Initialized
INFO - 2016-06-02 10:32:07 --> Helper loaded: form_helper
INFO - 2016-06-02 10:32:07 --> Database Driver Class Initialized
INFO - 2016-06-02 10:32:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:32:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:32:07 --> Email Class Initialized
INFO - 2016-06-02 10:32:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:32:07 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:32:07 --> Helper loaded: language_helper
INFO - 2016-06-02 10:32:07 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:32:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:32:07 --> Model Class Initialized
INFO - 2016-06-02 10:32:07 --> Helper loaded: date_helper
INFO - 2016-06-02 10:32:07 --> Controller Class Initialized
INFO - 2016-06-02 10:32:07 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:32:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:32:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:32:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:32:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:32:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:32:07 --> Model Class Initialized
INFO - 2016-06-02 10:32:07 --> Form Validation Class Initialized
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 10:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 10:32:07 --> Final output sent to browser
DEBUG - 2016-06-02 10:32:07 --> Total execution time: 0.0585
INFO - 2016-06-02 10:32:13 --> Config Class Initialized
INFO - 2016-06-02 10:32:13 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:32:13 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:32:13 --> Utf8 Class Initialized
INFO - 2016-06-02 10:32:13 --> URI Class Initialized
INFO - 2016-06-02 10:32:13 --> Router Class Initialized
INFO - 2016-06-02 10:32:13 --> Output Class Initialized
INFO - 2016-06-02 10:32:13 --> Security Class Initialized
DEBUG - 2016-06-02 10:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:32:13 --> CSRF cookie sent
INFO - 2016-06-02 10:32:13 --> CSRF token verified
INFO - 2016-06-02 10:32:13 --> Input Class Initialized
INFO - 2016-06-02 10:32:13 --> Language Class Initialized
INFO - 2016-06-02 10:32:13 --> Loader Class Initialized
INFO - 2016-06-02 10:32:13 --> Helper loaded: form_helper
INFO - 2016-06-02 10:32:13 --> Database Driver Class Initialized
INFO - 2016-06-02 10:32:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:32:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:32:13 --> Email Class Initialized
INFO - 2016-06-02 10:32:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:32:13 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:32:13 --> Helper loaded: language_helper
INFO - 2016-06-02 10:32:13 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:32:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:32:13 --> Model Class Initialized
INFO - 2016-06-02 10:32:13 --> Helper loaded: date_helper
INFO - 2016-06-02 10:32:13 --> Controller Class Initialized
INFO - 2016-06-02 10:32:13 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:32:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:32:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:32:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:32:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:32:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:32:13 --> Model Class Initialized
INFO - 2016-06-02 10:32:13 --> Form Validation Class Initialized
INFO - 2016-06-02 10:32:13 --> Final output sent to browser
DEBUG - 2016-06-02 10:32:13 --> Total execution time: 0.0248
INFO - 2016-06-02 10:40:38 --> Config Class Initialized
INFO - 2016-06-02 10:40:38 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:40:38 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:40:38 --> Utf8 Class Initialized
INFO - 2016-06-02 10:40:38 --> URI Class Initialized
INFO - 2016-06-02 10:40:38 --> Router Class Initialized
INFO - 2016-06-02 10:40:38 --> Output Class Initialized
INFO - 2016-06-02 10:40:38 --> Security Class Initialized
DEBUG - 2016-06-02 10:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:40:38 --> CSRF cookie sent
INFO - 2016-06-02 10:40:38 --> Input Class Initialized
INFO - 2016-06-02 10:40:38 --> Language Class Initialized
INFO - 2016-06-02 10:40:38 --> Loader Class Initialized
INFO - 2016-06-02 10:40:38 --> Helper loaded: form_helper
INFO - 2016-06-02 10:40:38 --> Database Driver Class Initialized
INFO - 2016-06-02 10:40:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:40:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:40:38 --> Email Class Initialized
INFO - 2016-06-02 10:40:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:40:38 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:40:38 --> Helper loaded: language_helper
INFO - 2016-06-02 10:40:38 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:40:38 --> Model Class Initialized
INFO - 2016-06-02 10:40:38 --> Helper loaded: date_helper
INFO - 2016-06-02 10:40:38 --> Controller Class Initialized
INFO - 2016-06-02 10:40:38 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:40:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:40:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:40:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:40:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:40:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:40:38 --> Model Class Initialized
INFO - 2016-06-02 10:40:38 --> Form Validation Class Initialized
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 10:40:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 10:40:38 --> Final output sent to browser
DEBUG - 2016-06-02 10:40:38 --> Total execution time: 0.0694
INFO - 2016-06-02 10:40:39 --> Config Class Initialized
INFO - 2016-06-02 10:40:39 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:40:39 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:40:39 --> Utf8 Class Initialized
INFO - 2016-06-02 10:40:39 --> URI Class Initialized
INFO - 2016-06-02 10:40:39 --> Router Class Initialized
INFO - 2016-06-02 10:40:39 --> Output Class Initialized
INFO - 2016-06-02 10:40:39 --> Security Class Initialized
DEBUG - 2016-06-02 10:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:40:39 --> CSRF cookie sent
INFO - 2016-06-02 10:40:39 --> Input Class Initialized
INFO - 2016-06-02 10:40:39 --> Language Class Initialized
ERROR - 2016-06-02 10:40:39 --> 404 Page Not Found: Diabet/button-print.png
INFO - 2016-06-02 10:40:40 --> Config Class Initialized
INFO - 2016-06-02 10:40:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:40:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:40:40 --> Utf8 Class Initialized
INFO - 2016-06-02 10:40:40 --> URI Class Initialized
INFO - 2016-06-02 10:40:40 --> Router Class Initialized
INFO - 2016-06-02 10:40:40 --> Output Class Initialized
INFO - 2016-06-02 10:40:40 --> Security Class Initialized
DEBUG - 2016-06-02 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:40:40 --> CSRF cookie sent
INFO - 2016-06-02 10:40:40 --> Input Class Initialized
INFO - 2016-06-02 10:40:40 --> Language Class Initialized
ERROR - 2016-06-02 10:40:40 --> 404 Page Not Found: Diabet/button-print.png
INFO - 2016-06-02 10:40:46 --> Config Class Initialized
INFO - 2016-06-02 10:40:46 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:40:46 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:40:46 --> Utf8 Class Initialized
INFO - 2016-06-02 10:40:46 --> URI Class Initialized
INFO - 2016-06-02 10:40:46 --> Router Class Initialized
INFO - 2016-06-02 10:40:46 --> Output Class Initialized
INFO - 2016-06-02 10:40:46 --> Security Class Initialized
DEBUG - 2016-06-02 10:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:40:46 --> CSRF cookie sent
INFO - 2016-06-02 10:40:46 --> CSRF token verified
INFO - 2016-06-02 10:40:46 --> Input Class Initialized
INFO - 2016-06-02 10:40:46 --> Language Class Initialized
INFO - 2016-06-02 10:40:46 --> Loader Class Initialized
INFO - 2016-06-02 10:40:46 --> Helper loaded: form_helper
INFO - 2016-06-02 10:40:46 --> Database Driver Class Initialized
INFO - 2016-06-02 10:40:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:40:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:40:46 --> Email Class Initialized
INFO - 2016-06-02 10:40:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:40:46 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:40:46 --> Helper loaded: language_helper
INFO - 2016-06-02 10:40:46 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:40:46 --> Model Class Initialized
INFO - 2016-06-02 10:40:46 --> Helper loaded: date_helper
INFO - 2016-06-02 10:40:46 --> Controller Class Initialized
INFO - 2016-06-02 10:40:46 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:40:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:40:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:40:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:40:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:40:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:40:46 --> Model Class Initialized
INFO - 2016-06-02 10:40:46 --> Form Validation Class Initialized
INFO - 2016-06-02 10:40:46 --> Final output sent to browser
DEBUG - 2016-06-02 10:40:46 --> Total execution time: 0.0434
INFO - 2016-06-02 10:44:35 --> Config Class Initialized
INFO - 2016-06-02 10:44:35 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:44:35 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:44:35 --> Utf8 Class Initialized
INFO - 2016-06-02 10:44:35 --> URI Class Initialized
INFO - 2016-06-02 10:44:35 --> Router Class Initialized
INFO - 2016-06-02 10:44:35 --> Output Class Initialized
INFO - 2016-06-02 10:44:35 --> Security Class Initialized
DEBUG - 2016-06-02 10:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:44:35 --> CSRF cookie sent
INFO - 2016-06-02 10:44:35 --> Input Class Initialized
INFO - 2016-06-02 10:44:35 --> Language Class Initialized
INFO - 2016-06-02 10:44:35 --> Loader Class Initialized
INFO - 2016-06-02 10:44:35 --> Helper loaded: form_helper
INFO - 2016-06-02 10:44:35 --> Database Driver Class Initialized
INFO - 2016-06-02 10:44:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:44:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:44:35 --> Email Class Initialized
INFO - 2016-06-02 10:44:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:44:35 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:44:35 --> Helper loaded: language_helper
INFO - 2016-06-02 10:44:35 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:44:35 --> Model Class Initialized
INFO - 2016-06-02 10:44:35 --> Helper loaded: date_helper
INFO - 2016-06-02 10:44:35 --> Controller Class Initialized
INFO - 2016-06-02 10:44:35 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:44:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:44:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:44:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:44:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:44:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:44:35 --> Model Class Initialized
INFO - 2016-06-02 10:44:35 --> Form Validation Class Initialized
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 10:44:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 10:44:35 --> Final output sent to browser
DEBUG - 2016-06-02 10:44:35 --> Total execution time: 0.1020
INFO - 2016-06-02 10:44:41 --> Config Class Initialized
INFO - 2016-06-02 10:44:41 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:44:41 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:44:41 --> Utf8 Class Initialized
INFO - 2016-06-02 10:44:41 --> URI Class Initialized
INFO - 2016-06-02 10:44:41 --> Router Class Initialized
INFO - 2016-06-02 10:44:41 --> Output Class Initialized
INFO - 2016-06-02 10:44:41 --> Security Class Initialized
DEBUG - 2016-06-02 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:44:41 --> CSRF cookie sent
INFO - 2016-06-02 10:44:41 --> CSRF token verified
INFO - 2016-06-02 10:44:41 --> Input Class Initialized
INFO - 2016-06-02 10:44:41 --> Language Class Initialized
INFO - 2016-06-02 10:44:41 --> Loader Class Initialized
INFO - 2016-06-02 10:44:41 --> Helper loaded: form_helper
INFO - 2016-06-02 10:44:41 --> Database Driver Class Initialized
INFO - 2016-06-02 10:44:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:44:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:44:41 --> Email Class Initialized
INFO - 2016-06-02 10:44:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:44:41 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:44:41 --> Helper loaded: language_helper
INFO - 2016-06-02 10:44:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:44:41 --> Model Class Initialized
INFO - 2016-06-02 10:44:41 --> Helper loaded: date_helper
INFO - 2016-06-02 10:44:41 --> Controller Class Initialized
INFO - 2016-06-02 10:44:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:44:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:44:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:44:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:44:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:44:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:44:41 --> Model Class Initialized
INFO - 2016-06-02 10:44:41 --> Form Validation Class Initialized
INFO - 2016-06-02 10:44:41 --> Final output sent to browser
DEBUG - 2016-06-02 10:44:41 --> Total execution time: 0.0320
INFO - 2016-06-02 10:45:01 --> Config Class Initialized
INFO - 2016-06-02 10:45:01 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:45:01 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:45:01 --> Utf8 Class Initialized
INFO - 2016-06-02 10:45:01 --> URI Class Initialized
INFO - 2016-06-02 10:45:01 --> Router Class Initialized
INFO - 2016-06-02 10:45:01 --> Output Class Initialized
INFO - 2016-06-02 10:45:01 --> Security Class Initialized
DEBUG - 2016-06-02 10:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:45:01 --> CSRF cookie sent
INFO - 2016-06-02 10:45:01 --> Input Class Initialized
INFO - 2016-06-02 10:45:01 --> Language Class Initialized
INFO - 2016-06-02 10:45:01 --> Loader Class Initialized
INFO - 2016-06-02 10:45:01 --> Helper loaded: form_helper
INFO - 2016-06-02 10:45:01 --> Database Driver Class Initialized
INFO - 2016-06-02 10:45:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:45:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:45:01 --> Email Class Initialized
INFO - 2016-06-02 10:45:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:45:01 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:45:01 --> Helper loaded: language_helper
INFO - 2016-06-02 10:45:01 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:45:01 --> Model Class Initialized
INFO - 2016-06-02 10:45:01 --> Helper loaded: date_helper
INFO - 2016-06-02 10:45:01 --> Controller Class Initialized
INFO - 2016-06-02 10:45:01 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:45:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:45:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:45:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:45:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:45:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:45:01 --> Model Class Initialized
INFO - 2016-06-02 10:45:01 --> Form Validation Class Initialized
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 10:45:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 10:45:01 --> Final output sent to browser
DEBUG - 2016-06-02 10:45:01 --> Total execution time: 0.0282
INFO - 2016-06-02 10:45:07 --> Config Class Initialized
INFO - 2016-06-02 10:45:07 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:45:07 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:45:07 --> Utf8 Class Initialized
INFO - 2016-06-02 10:45:07 --> URI Class Initialized
INFO - 2016-06-02 10:45:07 --> Router Class Initialized
INFO - 2016-06-02 10:45:07 --> Output Class Initialized
INFO - 2016-06-02 10:45:07 --> Security Class Initialized
DEBUG - 2016-06-02 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:45:07 --> CSRF cookie sent
INFO - 2016-06-02 10:45:07 --> CSRF token verified
INFO - 2016-06-02 10:45:07 --> Input Class Initialized
INFO - 2016-06-02 10:45:07 --> Language Class Initialized
INFO - 2016-06-02 10:45:07 --> Loader Class Initialized
INFO - 2016-06-02 10:45:07 --> Helper loaded: form_helper
INFO - 2016-06-02 10:45:07 --> Database Driver Class Initialized
INFO - 2016-06-02 10:45:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:45:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:45:07 --> Email Class Initialized
INFO - 2016-06-02 10:45:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:45:07 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:45:07 --> Helper loaded: language_helper
INFO - 2016-06-02 10:45:07 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:45:07 --> Model Class Initialized
INFO - 2016-06-02 10:45:07 --> Helper loaded: date_helper
INFO - 2016-06-02 10:45:07 --> Controller Class Initialized
INFO - 2016-06-02 10:45:07 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:45:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:45:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:45:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:45:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:45:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:45:07 --> Model Class Initialized
INFO - 2016-06-02 10:45:07 --> Form Validation Class Initialized
INFO - 2016-06-02 10:45:07 --> Final output sent to browser
DEBUG - 2016-06-02 10:45:07 --> Total execution time: 0.0564
INFO - 2016-06-02 10:45:51 --> Config Class Initialized
INFO - 2016-06-02 10:45:51 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:45:51 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:45:51 --> Utf8 Class Initialized
INFO - 2016-06-02 10:45:51 --> URI Class Initialized
INFO - 2016-06-02 10:45:51 --> Router Class Initialized
INFO - 2016-06-02 10:45:51 --> Output Class Initialized
INFO - 2016-06-02 10:45:51 --> Security Class Initialized
DEBUG - 2016-06-02 10:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:45:51 --> CSRF cookie sent
INFO - 2016-06-02 10:45:51 --> Input Class Initialized
INFO - 2016-06-02 10:45:51 --> Language Class Initialized
INFO - 2016-06-02 10:45:52 --> Loader Class Initialized
INFO - 2016-06-02 10:45:52 --> Helper loaded: form_helper
INFO - 2016-06-02 10:45:52 --> Database Driver Class Initialized
INFO - 2016-06-02 10:45:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:45:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:45:52 --> Email Class Initialized
INFO - 2016-06-02 10:45:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:45:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:45:52 --> Helper loaded: language_helper
INFO - 2016-06-02 10:45:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:45:52 --> Model Class Initialized
INFO - 2016-06-02 10:45:52 --> Helper loaded: date_helper
INFO - 2016-06-02 10:45:52 --> Controller Class Initialized
INFO - 2016-06-02 10:45:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:45:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:45:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:45:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:45:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:45:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:45:52 --> Model Class Initialized
INFO - 2016-06-02 10:45:52 --> Form Validation Class Initialized
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 10:45:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 10:45:52 --> Final output sent to browser
DEBUG - 2016-06-02 10:45:52 --> Total execution time: 0.2409
INFO - 2016-06-02 10:45:58 --> Config Class Initialized
INFO - 2016-06-02 10:45:58 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:45:58 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:45:58 --> Utf8 Class Initialized
INFO - 2016-06-02 10:45:58 --> URI Class Initialized
INFO - 2016-06-02 10:45:58 --> Router Class Initialized
INFO - 2016-06-02 10:45:58 --> Output Class Initialized
INFO - 2016-06-02 10:45:58 --> Security Class Initialized
DEBUG - 2016-06-02 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:45:58 --> CSRF cookie sent
INFO - 2016-06-02 10:45:58 --> CSRF token verified
INFO - 2016-06-02 10:45:58 --> Input Class Initialized
INFO - 2016-06-02 10:45:58 --> Language Class Initialized
INFO - 2016-06-02 10:45:58 --> Loader Class Initialized
INFO - 2016-06-02 10:45:58 --> Helper loaded: form_helper
INFO - 2016-06-02 10:45:58 --> Database Driver Class Initialized
INFO - 2016-06-02 10:45:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:45:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:45:58 --> Email Class Initialized
INFO - 2016-06-02 10:45:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:45:58 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:45:58 --> Helper loaded: language_helper
INFO - 2016-06-02 10:45:58 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:45:58 --> Model Class Initialized
INFO - 2016-06-02 10:45:58 --> Helper loaded: date_helper
INFO - 2016-06-02 10:45:58 --> Controller Class Initialized
INFO - 2016-06-02 10:45:58 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:45:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:45:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:45:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:45:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:45:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:45:58 --> Model Class Initialized
INFO - 2016-06-02 10:45:58 --> Form Validation Class Initialized
INFO - 2016-06-02 10:45:58 --> Final output sent to browser
DEBUG - 2016-06-02 10:45:58 --> Total execution time: 0.0405
INFO - 2016-06-02 10:49:13 --> Config Class Initialized
INFO - 2016-06-02 10:49:13 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:49:13 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:49:13 --> Utf8 Class Initialized
INFO - 2016-06-02 10:49:13 --> URI Class Initialized
INFO - 2016-06-02 10:49:13 --> Router Class Initialized
INFO - 2016-06-02 10:49:13 --> Output Class Initialized
INFO - 2016-06-02 10:49:13 --> Security Class Initialized
DEBUG - 2016-06-02 10:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:49:13 --> CSRF cookie sent
INFO - 2016-06-02 10:49:13 --> Input Class Initialized
INFO - 2016-06-02 10:49:13 --> Language Class Initialized
INFO - 2016-06-02 10:49:13 --> Loader Class Initialized
INFO - 2016-06-02 10:49:13 --> Helper loaded: form_helper
INFO - 2016-06-02 10:49:13 --> Database Driver Class Initialized
INFO - 2016-06-02 10:49:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:49:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:49:13 --> Email Class Initialized
INFO - 2016-06-02 10:49:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:49:13 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:49:13 --> Helper loaded: language_helper
INFO - 2016-06-02 10:49:13 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:49:13 --> Model Class Initialized
INFO - 2016-06-02 10:49:13 --> Helper loaded: date_helper
INFO - 2016-06-02 10:49:13 --> Controller Class Initialized
INFO - 2016-06-02 10:49:13 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:49:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:49:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:49:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:49:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:49:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:49:13 --> Model Class Initialized
INFO - 2016-06-02 10:49:13 --> Form Validation Class Initialized
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 10:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 10:49:13 --> Final output sent to browser
DEBUG - 2016-06-02 10:49:13 --> Total execution time: 0.0387
INFO - 2016-06-02 10:49:20 --> Config Class Initialized
INFO - 2016-06-02 10:49:20 --> Hooks Class Initialized
DEBUG - 2016-06-02 10:49:20 --> UTF-8 Support Enabled
INFO - 2016-06-02 10:49:20 --> Utf8 Class Initialized
INFO - 2016-06-02 10:49:20 --> URI Class Initialized
INFO - 2016-06-02 10:49:20 --> Router Class Initialized
INFO - 2016-06-02 10:49:20 --> Output Class Initialized
INFO - 2016-06-02 10:49:20 --> Security Class Initialized
DEBUG - 2016-06-02 10:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 10:49:20 --> CSRF cookie sent
INFO - 2016-06-02 10:49:20 --> CSRF token verified
INFO - 2016-06-02 10:49:20 --> Input Class Initialized
INFO - 2016-06-02 10:49:20 --> Language Class Initialized
INFO - 2016-06-02 10:49:20 --> Loader Class Initialized
INFO - 2016-06-02 10:49:20 --> Helper loaded: form_helper
INFO - 2016-06-02 10:49:20 --> Database Driver Class Initialized
INFO - 2016-06-02 10:49:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 10:49:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 10:49:20 --> Email Class Initialized
INFO - 2016-06-02 10:49:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 10:49:20 --> Helper loaded: cookie_helper
INFO - 2016-06-02 10:49:20 --> Helper loaded: language_helper
INFO - 2016-06-02 10:49:20 --> Helper loaded: url_helper
DEBUG - 2016-06-02 10:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 10:49:20 --> Model Class Initialized
INFO - 2016-06-02 10:49:20 --> Helper loaded: date_helper
INFO - 2016-06-02 10:49:20 --> Controller Class Initialized
INFO - 2016-06-02 10:49:20 --> Helper loaded: languages_helper
INFO - 2016-06-02 10:49:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 10:49:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 10:49:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 10:49:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 10:49:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 10:49:20 --> Model Class Initialized
INFO - 2016-06-02 10:49:20 --> Form Validation Class Initialized
INFO - 2016-06-02 10:49:20 --> Final output sent to browser
DEBUG - 2016-06-02 10:49:20 --> Total execution time: 0.0285
INFO - 2016-06-02 11:09:22 --> Config Class Initialized
INFO - 2016-06-02 11:09:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:09:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:09:22 --> Utf8 Class Initialized
INFO - 2016-06-02 11:09:22 --> URI Class Initialized
INFO - 2016-06-02 11:09:22 --> Router Class Initialized
INFO - 2016-06-02 11:09:22 --> Output Class Initialized
INFO - 2016-06-02 11:09:22 --> Security Class Initialized
DEBUG - 2016-06-02 11:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:09:22 --> CSRF cookie sent
INFO - 2016-06-02 11:09:22 --> Input Class Initialized
INFO - 2016-06-02 11:09:22 --> Language Class Initialized
INFO - 2016-06-02 11:09:22 --> Loader Class Initialized
INFO - 2016-06-02 11:09:22 --> Helper loaded: form_helper
INFO - 2016-06-02 11:09:22 --> Database Driver Class Initialized
INFO - 2016-06-02 11:09:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:09:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:09:22 --> Email Class Initialized
INFO - 2016-06-02 11:09:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:09:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:09:22 --> Helper loaded: language_helper
INFO - 2016-06-02 11:09:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:09:22 --> Model Class Initialized
INFO - 2016-06-02 11:09:22 --> Helper loaded: date_helper
INFO - 2016-06-02 11:09:22 --> Controller Class Initialized
INFO - 2016-06-02 11:09:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:09:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:09:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:09:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:09:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:09:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:09:22 --> Model Class Initialized
INFO - 2016-06-02 11:09:22 --> Form Validation Class Initialized
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:09:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:09:22 --> Final output sent to browser
DEBUG - 2016-06-02 11:09:22 --> Total execution time: 0.5920
INFO - 2016-06-02 11:09:32 --> Config Class Initialized
INFO - 2016-06-02 11:09:32 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:09:32 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:09:32 --> Utf8 Class Initialized
INFO - 2016-06-02 11:09:32 --> URI Class Initialized
INFO - 2016-06-02 11:09:32 --> Router Class Initialized
INFO - 2016-06-02 11:09:32 --> Output Class Initialized
INFO - 2016-06-02 11:09:32 --> Security Class Initialized
DEBUG - 2016-06-02 11:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:09:32 --> CSRF cookie sent
INFO - 2016-06-02 11:09:32 --> CSRF token verified
INFO - 2016-06-02 11:09:32 --> Input Class Initialized
INFO - 2016-06-02 11:09:32 --> Language Class Initialized
INFO - 2016-06-02 11:09:32 --> Loader Class Initialized
INFO - 2016-06-02 11:09:32 --> Helper loaded: form_helper
INFO - 2016-06-02 11:09:32 --> Database Driver Class Initialized
INFO - 2016-06-02 11:09:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:09:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:09:32 --> Email Class Initialized
INFO - 2016-06-02 11:09:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:09:32 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:09:32 --> Helper loaded: language_helper
INFO - 2016-06-02 11:09:32 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:09:32 --> Model Class Initialized
INFO - 2016-06-02 11:09:32 --> Helper loaded: date_helper
INFO - 2016-06-02 11:09:32 --> Controller Class Initialized
INFO - 2016-06-02 11:09:32 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:09:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:09:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:09:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:09:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:09:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:09:32 --> Model Class Initialized
INFO - 2016-06-02 11:09:32 --> Form Validation Class Initialized
INFO - 2016-06-02 11:09:32 --> Final output sent to browser
DEBUG - 2016-06-02 11:09:32 --> Total execution time: 0.1866
INFO - 2016-06-02 11:17:09 --> Config Class Initialized
INFO - 2016-06-02 11:17:09 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:17:09 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:17:09 --> Utf8 Class Initialized
INFO - 2016-06-02 11:17:09 --> URI Class Initialized
INFO - 2016-06-02 11:17:09 --> Router Class Initialized
INFO - 2016-06-02 11:17:09 --> Output Class Initialized
INFO - 2016-06-02 11:17:09 --> Security Class Initialized
DEBUG - 2016-06-02 11:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:17:09 --> CSRF cookie sent
INFO - 2016-06-02 11:17:09 --> Input Class Initialized
INFO - 2016-06-02 11:17:09 --> Language Class Initialized
INFO - 2016-06-02 11:17:09 --> Loader Class Initialized
INFO - 2016-06-02 11:17:09 --> Helper loaded: form_helper
INFO - 2016-06-02 11:17:09 --> Database Driver Class Initialized
INFO - 2016-06-02 11:17:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:17:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:17:09 --> Email Class Initialized
INFO - 2016-06-02 11:17:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:17:09 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:17:09 --> Helper loaded: language_helper
INFO - 2016-06-02 11:17:09 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:17:09 --> Model Class Initialized
INFO - 2016-06-02 11:17:09 --> Helper loaded: date_helper
INFO - 2016-06-02 11:17:09 --> Controller Class Initialized
INFO - 2016-06-02 11:17:09 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:17:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:17:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:17:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:17:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:17:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:17:09 --> Model Class Initialized
INFO - 2016-06-02 11:17:09 --> Form Validation Class Initialized
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:17:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:17:09 --> Final output sent to browser
DEBUG - 2016-06-02 11:17:09 --> Total execution time: 0.1279
INFO - 2016-06-02 11:17:18 --> Config Class Initialized
INFO - 2016-06-02 11:17:18 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:17:18 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:17:18 --> Utf8 Class Initialized
INFO - 2016-06-02 11:17:18 --> URI Class Initialized
INFO - 2016-06-02 11:17:18 --> Router Class Initialized
INFO - 2016-06-02 11:17:18 --> Output Class Initialized
INFO - 2016-06-02 11:17:18 --> Security Class Initialized
DEBUG - 2016-06-02 11:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:17:18 --> CSRF cookie sent
INFO - 2016-06-02 11:17:18 --> CSRF token verified
INFO - 2016-06-02 11:17:18 --> Input Class Initialized
INFO - 2016-06-02 11:17:18 --> Language Class Initialized
INFO - 2016-06-02 11:17:18 --> Loader Class Initialized
INFO - 2016-06-02 11:17:18 --> Helper loaded: form_helper
INFO - 2016-06-02 11:17:18 --> Database Driver Class Initialized
INFO - 2016-06-02 11:17:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:17:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:17:18 --> Email Class Initialized
INFO - 2016-06-02 11:17:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:17:18 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:17:18 --> Helper loaded: language_helper
INFO - 2016-06-02 11:17:18 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:17:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:17:18 --> Model Class Initialized
INFO - 2016-06-02 11:17:18 --> Helper loaded: date_helper
INFO - 2016-06-02 11:17:18 --> Controller Class Initialized
INFO - 2016-06-02 11:17:18 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:17:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:17:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:17:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:17:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:17:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:17:18 --> Model Class Initialized
INFO - 2016-06-02 11:17:18 --> Form Validation Class Initialized
INFO - 2016-06-02 11:17:18 --> Final output sent to browser
DEBUG - 2016-06-02 11:17:18 --> Total execution time: 0.0570
INFO - 2016-06-02 11:18:57 --> Config Class Initialized
INFO - 2016-06-02 11:18:57 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:18:57 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:18:57 --> Utf8 Class Initialized
INFO - 2016-06-02 11:18:57 --> URI Class Initialized
INFO - 2016-06-02 11:18:57 --> Router Class Initialized
INFO - 2016-06-02 11:18:57 --> Output Class Initialized
INFO - 2016-06-02 11:18:57 --> Security Class Initialized
DEBUG - 2016-06-02 11:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:18:57 --> CSRF cookie sent
INFO - 2016-06-02 11:18:57 --> Input Class Initialized
INFO - 2016-06-02 11:18:57 --> Language Class Initialized
INFO - 2016-06-02 11:18:57 --> Loader Class Initialized
INFO - 2016-06-02 11:18:57 --> Helper loaded: form_helper
INFO - 2016-06-02 11:18:57 --> Database Driver Class Initialized
INFO - 2016-06-02 11:18:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:18:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:18:57 --> Email Class Initialized
INFO - 2016-06-02 11:18:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:18:57 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:18:57 --> Helper loaded: language_helper
INFO - 2016-06-02 11:18:57 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:18:57 --> Model Class Initialized
INFO - 2016-06-02 11:18:57 --> Helper loaded: date_helper
INFO - 2016-06-02 11:18:57 --> Controller Class Initialized
INFO - 2016-06-02 11:18:57 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:18:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:18:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:18:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:18:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:18:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:18:57 --> Model Class Initialized
INFO - 2016-06-02 11:18:57 --> Form Validation Class Initialized
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:18:57 --> Final output sent to browser
DEBUG - 2016-06-02 11:18:57 --> Total execution time: 0.0438
INFO - 2016-06-02 11:19:07 --> Config Class Initialized
INFO - 2016-06-02 11:19:07 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:19:07 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:19:07 --> Utf8 Class Initialized
INFO - 2016-06-02 11:19:07 --> URI Class Initialized
INFO - 2016-06-02 11:19:07 --> Router Class Initialized
INFO - 2016-06-02 11:19:07 --> Output Class Initialized
INFO - 2016-06-02 11:19:07 --> Security Class Initialized
DEBUG - 2016-06-02 11:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:19:07 --> CSRF cookie sent
INFO - 2016-06-02 11:19:07 --> CSRF token verified
INFO - 2016-06-02 11:19:07 --> Input Class Initialized
INFO - 2016-06-02 11:19:07 --> Language Class Initialized
INFO - 2016-06-02 11:19:07 --> Loader Class Initialized
INFO - 2016-06-02 11:19:07 --> Helper loaded: form_helper
INFO - 2016-06-02 11:19:07 --> Database Driver Class Initialized
INFO - 2016-06-02 11:19:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:19:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:19:07 --> Email Class Initialized
INFO - 2016-06-02 11:19:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:19:07 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:19:07 --> Helper loaded: language_helper
INFO - 2016-06-02 11:19:07 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:19:07 --> Model Class Initialized
INFO - 2016-06-02 11:19:07 --> Helper loaded: date_helper
INFO - 2016-06-02 11:19:07 --> Controller Class Initialized
INFO - 2016-06-02 11:19:07 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:19:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:19:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:19:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:19:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:19:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:19:07 --> Model Class Initialized
INFO - 2016-06-02 11:19:07 --> Form Validation Class Initialized
INFO - 2016-06-02 11:19:07 --> Final output sent to browser
DEBUG - 2016-06-02 11:19:07 --> Total execution time: 0.0150
INFO - 2016-06-02 11:22:26 --> Config Class Initialized
INFO - 2016-06-02 11:22:26 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:22:26 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:22:26 --> Utf8 Class Initialized
INFO - 2016-06-02 11:22:26 --> URI Class Initialized
INFO - 2016-06-02 11:22:26 --> Router Class Initialized
INFO - 2016-06-02 11:22:26 --> Output Class Initialized
INFO - 2016-06-02 11:22:26 --> Security Class Initialized
DEBUG - 2016-06-02 11:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:22:26 --> CSRF cookie sent
INFO - 2016-06-02 11:22:26 --> Input Class Initialized
INFO - 2016-06-02 11:22:26 --> Language Class Initialized
INFO - 2016-06-02 11:22:26 --> Loader Class Initialized
INFO - 2016-06-02 11:22:26 --> Helper loaded: form_helper
INFO - 2016-06-02 11:22:26 --> Database Driver Class Initialized
INFO - 2016-06-02 11:22:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:22:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:22:26 --> Email Class Initialized
INFO - 2016-06-02 11:22:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:22:26 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:22:26 --> Helper loaded: language_helper
INFO - 2016-06-02 11:22:26 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:22:26 --> Model Class Initialized
INFO - 2016-06-02 11:22:26 --> Helper loaded: date_helper
INFO - 2016-06-02 11:22:26 --> Controller Class Initialized
INFO - 2016-06-02 11:22:26 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:22:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:22:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:22:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:22:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:22:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:22:26 --> Model Class Initialized
INFO - 2016-06-02 11:22:26 --> Form Validation Class Initialized
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:22:26 --> Final output sent to browser
DEBUG - 2016-06-02 11:22:26 --> Total execution time: 0.0496
INFO - 2016-06-02 11:22:38 --> Config Class Initialized
INFO - 2016-06-02 11:22:38 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:22:38 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:22:38 --> Utf8 Class Initialized
INFO - 2016-06-02 11:22:38 --> URI Class Initialized
INFO - 2016-06-02 11:22:38 --> Router Class Initialized
INFO - 2016-06-02 11:22:38 --> Output Class Initialized
INFO - 2016-06-02 11:22:38 --> Security Class Initialized
DEBUG - 2016-06-02 11:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:22:38 --> CSRF cookie sent
INFO - 2016-06-02 11:22:38 --> CSRF token verified
INFO - 2016-06-02 11:22:38 --> Input Class Initialized
INFO - 2016-06-02 11:22:38 --> Language Class Initialized
INFO - 2016-06-02 11:22:38 --> Loader Class Initialized
INFO - 2016-06-02 11:22:38 --> Helper loaded: form_helper
INFO - 2016-06-02 11:22:38 --> Database Driver Class Initialized
INFO - 2016-06-02 11:22:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:22:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:22:38 --> Email Class Initialized
INFO - 2016-06-02 11:22:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:22:38 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:22:38 --> Helper loaded: language_helper
INFO - 2016-06-02 11:22:38 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:22:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:22:38 --> Model Class Initialized
INFO - 2016-06-02 11:22:38 --> Helper loaded: date_helper
INFO - 2016-06-02 11:22:38 --> Controller Class Initialized
INFO - 2016-06-02 11:22:38 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:22:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:22:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:22:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:22:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:22:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:22:38 --> Model Class Initialized
INFO - 2016-06-02 11:22:38 --> Form Validation Class Initialized
INFO - 2016-06-02 11:22:38 --> Final output sent to browser
DEBUG - 2016-06-02 11:22:38 --> Total execution time: 0.0563
INFO - 2016-06-02 11:23:01 --> Config Class Initialized
INFO - 2016-06-02 11:23:01 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:23:01 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:23:01 --> Utf8 Class Initialized
INFO - 2016-06-02 11:23:01 --> URI Class Initialized
INFO - 2016-06-02 11:23:01 --> Router Class Initialized
INFO - 2016-06-02 11:23:01 --> Output Class Initialized
INFO - 2016-06-02 11:23:01 --> Security Class Initialized
DEBUG - 2016-06-02 11:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:23:01 --> CSRF cookie sent
INFO - 2016-06-02 11:23:01 --> Input Class Initialized
INFO - 2016-06-02 11:23:01 --> Language Class Initialized
INFO - 2016-06-02 11:23:01 --> Loader Class Initialized
INFO - 2016-06-02 11:23:01 --> Helper loaded: form_helper
INFO - 2016-06-02 11:23:01 --> Database Driver Class Initialized
INFO - 2016-06-02 11:23:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:23:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:23:01 --> Email Class Initialized
INFO - 2016-06-02 11:23:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:23:01 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:23:01 --> Helper loaded: language_helper
INFO - 2016-06-02 11:23:01 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:23:01 --> Model Class Initialized
INFO - 2016-06-02 11:23:01 --> Helper loaded: date_helper
INFO - 2016-06-02 11:23:01 --> Controller Class Initialized
INFO - 2016-06-02 11:23:01 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:23:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:23:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:23:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:23:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:23:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:23:01 --> Model Class Initialized
INFO - 2016-06-02 11:23:01 --> Form Validation Class Initialized
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:23:01 --> Final output sent to browser
DEBUG - 2016-06-02 11:23:01 --> Total execution time: 0.0220
INFO - 2016-06-02 11:23:12 --> Config Class Initialized
INFO - 2016-06-02 11:23:12 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:23:12 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:23:12 --> Utf8 Class Initialized
INFO - 2016-06-02 11:23:12 --> URI Class Initialized
INFO - 2016-06-02 11:23:12 --> Router Class Initialized
INFO - 2016-06-02 11:23:12 --> Output Class Initialized
INFO - 2016-06-02 11:23:12 --> Security Class Initialized
DEBUG - 2016-06-02 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:23:12 --> CSRF cookie sent
INFO - 2016-06-02 11:23:12 --> CSRF token verified
INFO - 2016-06-02 11:23:12 --> Input Class Initialized
INFO - 2016-06-02 11:23:12 --> Language Class Initialized
INFO - 2016-06-02 11:23:12 --> Loader Class Initialized
INFO - 2016-06-02 11:23:12 --> Helper loaded: form_helper
INFO - 2016-06-02 11:23:12 --> Database Driver Class Initialized
INFO - 2016-06-02 11:23:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:23:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:23:12 --> Email Class Initialized
INFO - 2016-06-02 11:23:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:23:12 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:23:12 --> Helper loaded: language_helper
INFO - 2016-06-02 11:23:12 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:23:12 --> Model Class Initialized
INFO - 2016-06-02 11:23:12 --> Helper loaded: date_helper
INFO - 2016-06-02 11:23:12 --> Controller Class Initialized
INFO - 2016-06-02 11:23:12 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:23:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:23:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:23:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:23:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:23:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:23:12 --> Model Class Initialized
INFO - 2016-06-02 11:23:12 --> Form Validation Class Initialized
INFO - 2016-06-02 11:23:12 --> Final output sent to browser
DEBUG - 2016-06-02 11:23:12 --> Total execution time: 0.0190
INFO - 2016-06-02 11:23:21 --> Config Class Initialized
INFO - 2016-06-02 11:23:21 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:23:21 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:23:21 --> Utf8 Class Initialized
INFO - 2016-06-02 11:23:21 --> URI Class Initialized
INFO - 2016-06-02 11:23:21 --> Router Class Initialized
INFO - 2016-06-02 11:23:21 --> Output Class Initialized
INFO - 2016-06-02 11:23:21 --> Security Class Initialized
DEBUG - 2016-06-02 11:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:23:21 --> CSRF cookie sent
INFO - 2016-06-02 11:23:21 --> Input Class Initialized
INFO - 2016-06-02 11:23:21 --> Language Class Initialized
INFO - 2016-06-02 11:23:21 --> Loader Class Initialized
INFO - 2016-06-02 11:23:21 --> Helper loaded: form_helper
INFO - 2016-06-02 11:23:21 --> Database Driver Class Initialized
INFO - 2016-06-02 11:23:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:23:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:23:21 --> Email Class Initialized
INFO - 2016-06-02 11:23:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:23:21 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:23:21 --> Helper loaded: language_helper
INFO - 2016-06-02 11:23:21 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:23:21 --> Model Class Initialized
INFO - 2016-06-02 11:23:21 --> Helper loaded: date_helper
INFO - 2016-06-02 11:23:21 --> Controller Class Initialized
INFO - 2016-06-02 11:23:21 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:23:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:23:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:23:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:23:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:23:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:23:21 --> Model Class Initialized
INFO - 2016-06-02 11:23:21 --> Form Validation Class Initialized
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:23:21 --> Final output sent to browser
DEBUG - 2016-06-02 11:23:21 --> Total execution time: 0.0234
INFO - 2016-06-02 11:23:33 --> Config Class Initialized
INFO - 2016-06-02 11:23:33 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:23:33 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:23:33 --> Utf8 Class Initialized
INFO - 2016-06-02 11:23:33 --> URI Class Initialized
INFO - 2016-06-02 11:23:33 --> Router Class Initialized
INFO - 2016-06-02 11:23:33 --> Output Class Initialized
INFO - 2016-06-02 11:23:33 --> Security Class Initialized
DEBUG - 2016-06-02 11:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:23:33 --> CSRF cookie sent
INFO - 2016-06-02 11:23:33 --> CSRF token verified
INFO - 2016-06-02 11:23:33 --> Input Class Initialized
INFO - 2016-06-02 11:23:33 --> Language Class Initialized
INFO - 2016-06-02 11:23:33 --> Loader Class Initialized
INFO - 2016-06-02 11:23:33 --> Helper loaded: form_helper
INFO - 2016-06-02 11:23:33 --> Database Driver Class Initialized
INFO - 2016-06-02 11:23:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:23:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:23:33 --> Email Class Initialized
INFO - 2016-06-02 11:23:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:23:33 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:23:33 --> Helper loaded: language_helper
INFO - 2016-06-02 11:23:33 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:23:33 --> Model Class Initialized
INFO - 2016-06-02 11:23:33 --> Helper loaded: date_helper
INFO - 2016-06-02 11:23:33 --> Controller Class Initialized
INFO - 2016-06-02 11:23:33 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:23:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:23:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:23:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:23:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:23:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:23:33 --> Model Class Initialized
INFO - 2016-06-02 11:23:33 --> Form Validation Class Initialized
INFO - 2016-06-02 11:23:33 --> Final output sent to browser
DEBUG - 2016-06-02 11:23:33 --> Total execution time: 0.0259
INFO - 2016-06-02 11:26:12 --> Config Class Initialized
INFO - 2016-06-02 11:26:12 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:26:12 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:26:12 --> Utf8 Class Initialized
INFO - 2016-06-02 11:26:12 --> URI Class Initialized
INFO - 2016-06-02 11:26:12 --> Router Class Initialized
INFO - 2016-06-02 11:26:12 --> Output Class Initialized
INFO - 2016-06-02 11:26:12 --> Security Class Initialized
DEBUG - 2016-06-02 11:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:26:12 --> CSRF cookie sent
INFO - 2016-06-02 11:26:12 --> Input Class Initialized
INFO - 2016-06-02 11:26:12 --> Language Class Initialized
INFO - 2016-06-02 11:26:12 --> Loader Class Initialized
INFO - 2016-06-02 11:26:12 --> Helper loaded: form_helper
INFO - 2016-06-02 11:26:12 --> Database Driver Class Initialized
INFO - 2016-06-02 11:26:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:26:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:26:12 --> Email Class Initialized
INFO - 2016-06-02 11:26:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:26:12 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:26:12 --> Helper loaded: language_helper
INFO - 2016-06-02 11:26:12 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:26:12 --> Model Class Initialized
INFO - 2016-06-02 11:26:12 --> Helper loaded: date_helper
INFO - 2016-06-02 11:26:12 --> Controller Class Initialized
INFO - 2016-06-02 11:26:12 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:26:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:26:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:26:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:26:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:26:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:26:12 --> Model Class Initialized
INFO - 2016-06-02 11:26:12 --> Form Validation Class Initialized
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:26:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:26:12 --> Final output sent to browser
DEBUG - 2016-06-02 11:26:12 --> Total execution time: 0.0693
INFO - 2016-06-02 11:26:38 --> Config Class Initialized
INFO - 2016-06-02 11:26:38 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:26:38 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:26:38 --> Utf8 Class Initialized
INFO - 2016-06-02 11:26:38 --> URI Class Initialized
INFO - 2016-06-02 11:26:38 --> Router Class Initialized
INFO - 2016-06-02 11:26:38 --> Output Class Initialized
INFO - 2016-06-02 11:26:38 --> Security Class Initialized
DEBUG - 2016-06-02 11:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:26:38 --> CSRF cookie sent
INFO - 2016-06-02 11:26:38 --> CSRF token verified
INFO - 2016-06-02 11:26:38 --> Input Class Initialized
INFO - 2016-06-02 11:26:38 --> Language Class Initialized
INFO - 2016-06-02 11:26:38 --> Loader Class Initialized
INFO - 2016-06-02 11:26:38 --> Helper loaded: form_helper
INFO - 2016-06-02 11:26:38 --> Database Driver Class Initialized
INFO - 2016-06-02 11:26:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:26:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:26:38 --> Email Class Initialized
INFO - 2016-06-02 11:26:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:26:38 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:26:38 --> Helper loaded: language_helper
INFO - 2016-06-02 11:26:38 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:26:38 --> Model Class Initialized
INFO - 2016-06-02 11:26:38 --> Helper loaded: date_helper
INFO - 2016-06-02 11:26:38 --> Controller Class Initialized
INFO - 2016-06-02 11:26:38 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:26:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:26:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:26:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:26:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:26:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:26:38 --> Model Class Initialized
INFO - 2016-06-02 11:26:38 --> Form Validation Class Initialized
INFO - 2016-06-02 11:26:38 --> Final output sent to browser
DEBUG - 2016-06-02 11:26:38 --> Total execution time: 0.0202
INFO - 2016-06-02 11:30:36 --> Config Class Initialized
INFO - 2016-06-02 11:30:36 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:30:36 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:30:36 --> Utf8 Class Initialized
INFO - 2016-06-02 11:30:36 --> URI Class Initialized
INFO - 2016-06-02 11:30:36 --> Router Class Initialized
INFO - 2016-06-02 11:30:36 --> Output Class Initialized
INFO - 2016-06-02 11:30:36 --> Security Class Initialized
DEBUG - 2016-06-02 11:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:30:36 --> CSRF cookie sent
INFO - 2016-06-02 11:30:36 --> Input Class Initialized
INFO - 2016-06-02 11:30:36 --> Language Class Initialized
INFO - 2016-06-02 11:30:36 --> Loader Class Initialized
INFO - 2016-06-02 11:30:36 --> Helper loaded: form_helper
INFO - 2016-06-02 11:30:36 --> Database Driver Class Initialized
INFO - 2016-06-02 11:30:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:30:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:30:36 --> Email Class Initialized
INFO - 2016-06-02 11:30:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:30:36 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:30:36 --> Helper loaded: language_helper
INFO - 2016-06-02 11:30:36 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:30:36 --> Model Class Initialized
INFO - 2016-06-02 11:30:36 --> Helper loaded: date_helper
INFO - 2016-06-02 11:30:36 --> Controller Class Initialized
INFO - 2016-06-02 11:30:36 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:30:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:30:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:30:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:30:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:30:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:30:36 --> Model Class Initialized
INFO - 2016-06-02 11:30:36 --> Form Validation Class Initialized
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 11:30:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 11:30:36 --> Final output sent to browser
DEBUG - 2016-06-02 11:30:36 --> Total execution time: 0.1226
INFO - 2016-06-02 11:30:41 --> Config Class Initialized
INFO - 2016-06-02 11:30:41 --> Hooks Class Initialized
DEBUG - 2016-06-02 11:30:41 --> UTF-8 Support Enabled
INFO - 2016-06-02 11:30:41 --> Utf8 Class Initialized
INFO - 2016-06-02 11:30:41 --> URI Class Initialized
INFO - 2016-06-02 11:30:41 --> Router Class Initialized
INFO - 2016-06-02 11:30:41 --> Output Class Initialized
INFO - 2016-06-02 11:30:41 --> Security Class Initialized
DEBUG - 2016-06-02 11:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 11:30:41 --> CSRF cookie sent
INFO - 2016-06-02 11:30:41 --> CSRF token verified
INFO - 2016-06-02 11:30:41 --> Input Class Initialized
INFO - 2016-06-02 11:30:41 --> Language Class Initialized
INFO - 2016-06-02 11:30:41 --> Loader Class Initialized
INFO - 2016-06-02 11:30:41 --> Helper loaded: form_helper
INFO - 2016-06-02 11:30:41 --> Database Driver Class Initialized
INFO - 2016-06-02 11:30:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 11:30:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 11:30:41 --> Email Class Initialized
INFO - 2016-06-02 11:30:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 11:30:41 --> Helper loaded: cookie_helper
INFO - 2016-06-02 11:30:41 --> Helper loaded: language_helper
INFO - 2016-06-02 11:30:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 11:30:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 11:30:41 --> Model Class Initialized
INFO - 2016-06-02 11:30:41 --> Helper loaded: date_helper
INFO - 2016-06-02 11:30:41 --> Controller Class Initialized
INFO - 2016-06-02 11:30:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 11:30:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 11:30:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 11:30:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 11:30:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 11:30:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 11:30:41 --> Model Class Initialized
INFO - 2016-06-02 11:30:41 --> Form Validation Class Initialized
INFO - 2016-06-02 11:30:41 --> Final output sent to browser
DEBUG - 2016-06-02 11:30:41 --> Total execution time: 0.0253
INFO - 2016-06-02 12:01:31 --> Config Class Initialized
INFO - 2016-06-02 12:01:31 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:01:31 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:01:31 --> Utf8 Class Initialized
INFO - 2016-06-02 12:01:31 --> URI Class Initialized
INFO - 2016-06-02 12:01:31 --> Router Class Initialized
INFO - 2016-06-02 12:01:31 --> Output Class Initialized
INFO - 2016-06-02 12:01:31 --> Security Class Initialized
DEBUG - 2016-06-02 12:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:01:31 --> CSRF cookie sent
INFO - 2016-06-02 12:01:31 --> CSRF token verified
INFO - 2016-06-02 12:01:31 --> Input Class Initialized
INFO - 2016-06-02 12:01:31 --> Language Class Initialized
INFO - 2016-06-02 12:01:31 --> Loader Class Initialized
INFO - 2016-06-02 12:01:31 --> Helper loaded: form_helper
INFO - 2016-06-02 12:01:31 --> Database Driver Class Initialized
INFO - 2016-06-02 12:01:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:01:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:01:31 --> Email Class Initialized
INFO - 2016-06-02 12:01:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:01:31 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:01:31 --> Helper loaded: language_helper
INFO - 2016-06-02 12:01:31 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:01:31 --> Model Class Initialized
INFO - 2016-06-02 12:01:31 --> Helper loaded: date_helper
INFO - 2016-06-02 12:01:31 --> Controller Class Initialized
INFO - 2016-06-02 12:01:31 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:01:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:01:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:01:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:01:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:01:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:01:31 --> Model Class Initialized
INFO - 2016-06-02 12:01:31 --> Form Validation Class Initialized
INFO - 2016-06-02 12:01:31 --> Final output sent to browser
DEBUG - 2016-06-02 12:01:31 --> Total execution time: 0.0435
INFO - 2016-06-02 12:04:44 --> Config Class Initialized
INFO - 2016-06-02 12:04:44 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:04:44 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:04:44 --> Utf8 Class Initialized
INFO - 2016-06-02 12:04:44 --> URI Class Initialized
INFO - 2016-06-02 12:04:44 --> Router Class Initialized
INFO - 2016-06-02 12:04:44 --> Output Class Initialized
INFO - 2016-06-02 12:04:44 --> Security Class Initialized
DEBUG - 2016-06-02 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:04:44 --> CSRF cookie sent
INFO - 2016-06-02 12:04:44 --> CSRF token verified
INFO - 2016-06-02 12:04:44 --> Input Class Initialized
INFO - 2016-06-02 12:04:44 --> Language Class Initialized
INFO - 2016-06-02 12:04:44 --> Loader Class Initialized
INFO - 2016-06-02 12:04:44 --> Helper loaded: form_helper
INFO - 2016-06-02 12:04:44 --> Database Driver Class Initialized
INFO - 2016-06-02 12:04:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:04:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:04:44 --> Email Class Initialized
INFO - 2016-06-02 12:04:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:04:44 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:04:44 --> Helper loaded: language_helper
INFO - 2016-06-02 12:04:44 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:04:44 --> Model Class Initialized
INFO - 2016-06-02 12:04:44 --> Helper loaded: date_helper
INFO - 2016-06-02 12:04:44 --> Controller Class Initialized
INFO - 2016-06-02 12:04:44 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:04:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:04:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:04:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:04:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:04:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:04:44 --> Model Class Initialized
INFO - 2016-06-02 12:04:44 --> Form Validation Class Initialized
INFO - 2016-06-02 12:04:44 --> Final output sent to browser
DEBUG - 2016-06-02 12:04:44 --> Total execution time: 0.0968
INFO - 2016-06-02 12:05:39 --> Config Class Initialized
INFO - 2016-06-02 12:05:39 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:05:39 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:05:39 --> Utf8 Class Initialized
INFO - 2016-06-02 12:05:39 --> URI Class Initialized
INFO - 2016-06-02 12:05:39 --> Router Class Initialized
INFO - 2016-06-02 12:05:39 --> Output Class Initialized
INFO - 2016-06-02 12:05:39 --> Security Class Initialized
DEBUG - 2016-06-02 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:05:39 --> CSRF cookie sent
INFO - 2016-06-02 12:05:39 --> Input Class Initialized
INFO - 2016-06-02 12:05:39 --> Language Class Initialized
INFO - 2016-06-02 12:05:39 --> Loader Class Initialized
INFO - 2016-06-02 12:05:39 --> Helper loaded: form_helper
INFO - 2016-06-02 12:05:39 --> Database Driver Class Initialized
INFO - 2016-06-02 12:05:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:05:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:05:39 --> Email Class Initialized
INFO - 2016-06-02 12:05:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:05:39 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:05:39 --> Helper loaded: language_helper
INFO - 2016-06-02 12:05:39 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:05:39 --> Model Class Initialized
INFO - 2016-06-02 12:05:39 --> Helper loaded: date_helper
INFO - 2016-06-02 12:05:39 --> Controller Class Initialized
INFO - 2016-06-02 12:05:39 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:05:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:05:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:05:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:05:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:05:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:05:39 --> Model Class Initialized
INFO - 2016-06-02 12:05:39 --> Form Validation Class Initialized
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:05:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:05:39 --> Final output sent to browser
DEBUG - 2016-06-02 12:05:39 --> Total execution time: 0.0234
INFO - 2016-06-02 12:05:46 --> Config Class Initialized
INFO - 2016-06-02 12:05:46 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:05:46 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:05:46 --> Utf8 Class Initialized
INFO - 2016-06-02 12:05:46 --> URI Class Initialized
INFO - 2016-06-02 12:05:46 --> Router Class Initialized
INFO - 2016-06-02 12:05:46 --> Output Class Initialized
INFO - 2016-06-02 12:05:46 --> Security Class Initialized
DEBUG - 2016-06-02 12:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:05:46 --> CSRF cookie sent
INFO - 2016-06-02 12:05:46 --> CSRF token verified
INFO - 2016-06-02 12:05:46 --> Input Class Initialized
INFO - 2016-06-02 12:05:46 --> Language Class Initialized
INFO - 2016-06-02 12:05:46 --> Loader Class Initialized
INFO - 2016-06-02 12:05:46 --> Helper loaded: form_helper
INFO - 2016-06-02 12:05:46 --> Database Driver Class Initialized
INFO - 2016-06-02 12:05:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:05:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:05:46 --> Email Class Initialized
INFO - 2016-06-02 12:05:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:05:46 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:05:46 --> Helper loaded: language_helper
INFO - 2016-06-02 12:05:46 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:05:46 --> Model Class Initialized
INFO - 2016-06-02 12:05:46 --> Helper loaded: date_helper
INFO - 2016-06-02 12:05:46 --> Controller Class Initialized
INFO - 2016-06-02 12:05:46 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:05:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:05:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:05:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:05:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:05:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:05:46 --> Model Class Initialized
INFO - 2016-06-02 12:05:46 --> Form Validation Class Initialized
INFO - 2016-06-02 12:05:46 --> Final output sent to browser
DEBUG - 2016-06-02 12:05:46 --> Total execution time: 0.0220
INFO - 2016-06-02 12:07:07 --> Config Class Initialized
INFO - 2016-06-02 12:07:07 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:07:07 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:07:07 --> Utf8 Class Initialized
INFO - 2016-06-02 12:07:07 --> URI Class Initialized
INFO - 2016-06-02 12:07:07 --> Router Class Initialized
INFO - 2016-06-02 12:07:07 --> Output Class Initialized
INFO - 2016-06-02 12:07:07 --> Security Class Initialized
DEBUG - 2016-06-02 12:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:07:07 --> CSRF cookie sent
INFO - 2016-06-02 12:07:07 --> Input Class Initialized
INFO - 2016-06-02 12:07:07 --> Language Class Initialized
INFO - 2016-06-02 12:07:07 --> Loader Class Initialized
INFO - 2016-06-02 12:07:07 --> Helper loaded: form_helper
INFO - 2016-06-02 12:07:07 --> Database Driver Class Initialized
INFO - 2016-06-02 12:07:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:07:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:07:07 --> Email Class Initialized
INFO - 2016-06-02 12:07:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:07:07 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:07:07 --> Helper loaded: language_helper
INFO - 2016-06-02 12:07:07 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:07:07 --> Model Class Initialized
INFO - 2016-06-02 12:07:07 --> Helper loaded: date_helper
INFO - 2016-06-02 12:07:07 --> Controller Class Initialized
INFO - 2016-06-02 12:07:07 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:07:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:07:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:07:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:07:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:07:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:07:07 --> Model Class Initialized
INFO - 2016-06-02 12:07:07 --> Form Validation Class Initialized
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:07:07 --> Final output sent to browser
DEBUG - 2016-06-02 12:07:07 --> Total execution time: 0.0200
INFO - 2016-06-02 12:07:13 --> Config Class Initialized
INFO - 2016-06-02 12:07:13 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:07:13 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:07:13 --> Utf8 Class Initialized
INFO - 2016-06-02 12:07:13 --> URI Class Initialized
INFO - 2016-06-02 12:07:13 --> Router Class Initialized
INFO - 2016-06-02 12:07:13 --> Output Class Initialized
INFO - 2016-06-02 12:07:13 --> Security Class Initialized
DEBUG - 2016-06-02 12:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:07:13 --> CSRF cookie sent
INFO - 2016-06-02 12:07:13 --> CSRF token verified
INFO - 2016-06-02 12:07:13 --> Input Class Initialized
INFO - 2016-06-02 12:07:13 --> Language Class Initialized
INFO - 2016-06-02 12:07:13 --> Loader Class Initialized
INFO - 2016-06-02 12:07:13 --> Helper loaded: form_helper
INFO - 2016-06-02 12:07:13 --> Database Driver Class Initialized
INFO - 2016-06-02 12:07:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:07:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:07:13 --> Email Class Initialized
INFO - 2016-06-02 12:07:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:07:13 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:07:13 --> Helper loaded: language_helper
INFO - 2016-06-02 12:07:13 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:07:13 --> Model Class Initialized
INFO - 2016-06-02 12:07:13 --> Helper loaded: date_helper
INFO - 2016-06-02 12:07:13 --> Controller Class Initialized
INFO - 2016-06-02 12:07:13 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:07:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:07:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:07:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:07:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:07:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:07:13 --> Model Class Initialized
INFO - 2016-06-02 12:07:13 --> Form Validation Class Initialized
INFO - 2016-06-02 12:07:13 --> Final output sent to browser
DEBUG - 2016-06-02 12:07:13 --> Total execution time: 0.0573
INFO - 2016-06-02 12:11:35 --> Config Class Initialized
INFO - 2016-06-02 12:11:35 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:11:35 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:11:35 --> Utf8 Class Initialized
INFO - 2016-06-02 12:11:35 --> URI Class Initialized
INFO - 2016-06-02 12:11:35 --> Router Class Initialized
INFO - 2016-06-02 12:11:35 --> Output Class Initialized
INFO - 2016-06-02 12:11:35 --> Security Class Initialized
DEBUG - 2016-06-02 12:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:11:35 --> CSRF cookie sent
INFO - 2016-06-02 12:11:35 --> Input Class Initialized
INFO - 2016-06-02 12:11:35 --> Language Class Initialized
INFO - 2016-06-02 12:11:35 --> Loader Class Initialized
INFO - 2016-06-02 12:11:35 --> Helper loaded: form_helper
INFO - 2016-06-02 12:11:35 --> Database Driver Class Initialized
INFO - 2016-06-02 12:11:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:11:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:11:35 --> Email Class Initialized
INFO - 2016-06-02 12:11:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:11:35 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:11:35 --> Helper loaded: language_helper
INFO - 2016-06-02 12:11:35 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:11:35 --> Model Class Initialized
INFO - 2016-06-02 12:11:35 --> Helper loaded: date_helper
INFO - 2016-06-02 12:11:35 --> Controller Class Initialized
INFO - 2016-06-02 12:11:35 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:11:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:11:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:11:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:11:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:11:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:11:35 --> Model Class Initialized
INFO - 2016-06-02 12:11:35 --> Form Validation Class Initialized
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:11:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:11:35 --> Final output sent to browser
DEBUG - 2016-06-02 12:11:35 --> Total execution time: 0.0280
INFO - 2016-06-02 12:11:40 --> Config Class Initialized
INFO - 2016-06-02 12:11:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:11:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:11:40 --> Utf8 Class Initialized
INFO - 2016-06-02 12:11:40 --> URI Class Initialized
INFO - 2016-06-02 12:11:40 --> Router Class Initialized
INFO - 2016-06-02 12:11:40 --> Output Class Initialized
INFO - 2016-06-02 12:11:40 --> Security Class Initialized
DEBUG - 2016-06-02 12:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:11:40 --> CSRF cookie sent
INFO - 2016-06-02 12:11:40 --> CSRF token verified
INFO - 2016-06-02 12:11:40 --> Input Class Initialized
INFO - 2016-06-02 12:11:40 --> Language Class Initialized
INFO - 2016-06-02 12:11:40 --> Loader Class Initialized
INFO - 2016-06-02 12:11:40 --> Helper loaded: form_helper
INFO - 2016-06-02 12:11:40 --> Database Driver Class Initialized
INFO - 2016-06-02 12:11:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:11:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:11:40 --> Email Class Initialized
INFO - 2016-06-02 12:11:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:11:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:11:40 --> Helper loaded: language_helper
INFO - 2016-06-02 12:11:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:11:40 --> Model Class Initialized
INFO - 2016-06-02 12:11:40 --> Helper loaded: date_helper
INFO - 2016-06-02 12:11:40 --> Controller Class Initialized
INFO - 2016-06-02 12:11:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:11:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:11:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:11:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:11:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:11:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:11:40 --> Model Class Initialized
INFO - 2016-06-02 12:11:40 --> Form Validation Class Initialized
INFO - 2016-06-02 12:11:40 --> Final output sent to browser
DEBUG - 2016-06-02 12:11:40 --> Total execution time: 0.0330
INFO - 2016-06-02 12:12:45 --> Config Class Initialized
INFO - 2016-06-02 12:12:45 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:12:45 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:12:45 --> Utf8 Class Initialized
INFO - 2016-06-02 12:12:45 --> URI Class Initialized
INFO - 2016-06-02 12:12:45 --> Router Class Initialized
INFO - 2016-06-02 12:12:45 --> Output Class Initialized
INFO - 2016-06-02 12:12:45 --> Security Class Initialized
DEBUG - 2016-06-02 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:12:45 --> CSRF cookie sent
INFO - 2016-06-02 12:12:45 --> Input Class Initialized
INFO - 2016-06-02 12:12:45 --> Language Class Initialized
INFO - 2016-06-02 12:12:45 --> Loader Class Initialized
INFO - 2016-06-02 12:12:45 --> Helper loaded: form_helper
INFO - 2016-06-02 12:12:45 --> Database Driver Class Initialized
INFO - 2016-06-02 12:12:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:12:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:12:45 --> Email Class Initialized
INFO - 2016-06-02 12:12:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:12:45 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:12:45 --> Helper loaded: language_helper
INFO - 2016-06-02 12:12:45 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:12:45 --> Model Class Initialized
INFO - 2016-06-02 12:12:45 --> Helper loaded: date_helper
INFO - 2016-06-02 12:12:45 --> Controller Class Initialized
INFO - 2016-06-02 12:12:45 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:12:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:12:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:12:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:12:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:12:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:12:45 --> Model Class Initialized
INFO - 2016-06-02 12:12:45 --> Form Validation Class Initialized
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:12:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:12:45 --> Final output sent to browser
DEBUG - 2016-06-02 12:12:45 --> Total execution time: 0.0286
INFO - 2016-06-02 12:12:50 --> Config Class Initialized
INFO - 2016-06-02 12:12:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:12:50 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:12:50 --> Utf8 Class Initialized
INFO - 2016-06-02 12:12:50 --> URI Class Initialized
INFO - 2016-06-02 12:12:50 --> Router Class Initialized
INFO - 2016-06-02 12:12:50 --> Output Class Initialized
INFO - 2016-06-02 12:12:50 --> Security Class Initialized
DEBUG - 2016-06-02 12:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:12:50 --> CSRF cookie sent
INFO - 2016-06-02 12:12:50 --> CSRF token verified
INFO - 2016-06-02 12:12:50 --> Input Class Initialized
INFO - 2016-06-02 12:12:50 --> Language Class Initialized
INFO - 2016-06-02 12:12:50 --> Loader Class Initialized
INFO - 2016-06-02 12:12:50 --> Helper loaded: form_helper
INFO - 2016-06-02 12:12:50 --> Database Driver Class Initialized
INFO - 2016-06-02 12:12:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:12:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:12:50 --> Email Class Initialized
INFO - 2016-06-02 12:12:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:12:50 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:12:50 --> Helper loaded: language_helper
INFO - 2016-06-02 12:12:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:12:50 --> Model Class Initialized
INFO - 2016-06-02 12:12:50 --> Helper loaded: date_helper
INFO - 2016-06-02 12:12:50 --> Controller Class Initialized
INFO - 2016-06-02 12:12:50 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:12:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:12:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:12:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:12:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:12:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:12:50 --> Model Class Initialized
INFO - 2016-06-02 12:12:50 --> Form Validation Class Initialized
INFO - 2016-06-02 12:12:50 --> Final output sent to browser
DEBUG - 2016-06-02 12:12:50 --> Total execution time: 0.0435
INFO - 2016-06-02 12:13:40 --> Config Class Initialized
INFO - 2016-06-02 12:13:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:13:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:13:40 --> Utf8 Class Initialized
INFO - 2016-06-02 12:13:40 --> URI Class Initialized
INFO - 2016-06-02 12:13:40 --> Router Class Initialized
INFO - 2016-06-02 12:13:40 --> Output Class Initialized
INFO - 2016-06-02 12:13:40 --> Security Class Initialized
DEBUG - 2016-06-02 12:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:13:40 --> CSRF cookie sent
INFO - 2016-06-02 12:13:40 --> Input Class Initialized
INFO - 2016-06-02 12:13:40 --> Language Class Initialized
INFO - 2016-06-02 12:13:40 --> Loader Class Initialized
INFO - 2016-06-02 12:13:40 --> Helper loaded: form_helper
INFO - 2016-06-02 12:13:40 --> Database Driver Class Initialized
INFO - 2016-06-02 12:13:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:13:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:13:40 --> Email Class Initialized
INFO - 2016-06-02 12:13:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:13:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:13:40 --> Helper loaded: language_helper
INFO - 2016-06-02 12:13:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:13:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:13:40 --> Model Class Initialized
INFO - 2016-06-02 12:13:40 --> Helper loaded: date_helper
INFO - 2016-06-02 12:13:40 --> Controller Class Initialized
INFO - 2016-06-02 12:13:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:13:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:13:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:13:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:13:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:13:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:13:40 --> Model Class Initialized
INFO - 2016-06-02 12:13:40 --> Form Validation Class Initialized
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:13:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:13:40 --> Final output sent to browser
DEBUG - 2016-06-02 12:13:40 --> Total execution time: 0.0222
INFO - 2016-06-02 12:13:46 --> Config Class Initialized
INFO - 2016-06-02 12:13:46 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:13:46 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:13:46 --> Utf8 Class Initialized
INFO - 2016-06-02 12:13:46 --> URI Class Initialized
INFO - 2016-06-02 12:13:46 --> Router Class Initialized
INFO - 2016-06-02 12:13:46 --> Output Class Initialized
INFO - 2016-06-02 12:13:46 --> Security Class Initialized
DEBUG - 2016-06-02 12:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:13:46 --> CSRF cookie sent
INFO - 2016-06-02 12:13:46 --> CSRF token verified
INFO - 2016-06-02 12:13:46 --> Input Class Initialized
INFO - 2016-06-02 12:13:46 --> Language Class Initialized
INFO - 2016-06-02 12:13:46 --> Loader Class Initialized
INFO - 2016-06-02 12:13:46 --> Helper loaded: form_helper
INFO - 2016-06-02 12:13:46 --> Database Driver Class Initialized
INFO - 2016-06-02 12:13:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:13:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:13:46 --> Email Class Initialized
INFO - 2016-06-02 12:13:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:13:46 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:13:46 --> Helper loaded: language_helper
INFO - 2016-06-02 12:13:46 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:13:46 --> Model Class Initialized
INFO - 2016-06-02 12:13:46 --> Helper loaded: date_helper
INFO - 2016-06-02 12:13:46 --> Controller Class Initialized
INFO - 2016-06-02 12:13:46 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:13:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:13:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:13:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:13:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:13:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:13:46 --> Model Class Initialized
INFO - 2016-06-02 12:13:46 --> Form Validation Class Initialized
INFO - 2016-06-02 12:13:46 --> Final output sent to browser
DEBUG - 2016-06-02 12:13:46 --> Total execution time: 0.0272
INFO - 2016-06-02 12:15:31 --> Config Class Initialized
INFO - 2016-06-02 12:15:31 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:15:31 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:15:31 --> Utf8 Class Initialized
INFO - 2016-06-02 12:15:31 --> URI Class Initialized
INFO - 2016-06-02 12:15:31 --> Router Class Initialized
INFO - 2016-06-02 12:15:31 --> Output Class Initialized
INFO - 2016-06-02 12:15:31 --> Security Class Initialized
DEBUG - 2016-06-02 12:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:15:31 --> CSRF cookie sent
INFO - 2016-06-02 12:15:31 --> Input Class Initialized
INFO - 2016-06-02 12:15:31 --> Language Class Initialized
INFO - 2016-06-02 12:15:31 --> Loader Class Initialized
INFO - 2016-06-02 12:15:31 --> Helper loaded: form_helper
INFO - 2016-06-02 12:15:31 --> Database Driver Class Initialized
INFO - 2016-06-02 12:15:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:15:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:15:31 --> Email Class Initialized
INFO - 2016-06-02 12:15:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:15:31 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:15:31 --> Helper loaded: language_helper
INFO - 2016-06-02 12:15:31 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:15:31 --> Model Class Initialized
INFO - 2016-06-02 12:15:31 --> Helper loaded: date_helper
INFO - 2016-06-02 12:15:31 --> Controller Class Initialized
INFO - 2016-06-02 12:15:31 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:15:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:15:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:15:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:15:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:15:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:15:31 --> Model Class Initialized
INFO - 2016-06-02 12:15:31 --> Form Validation Class Initialized
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:15:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:15:31 --> Final output sent to browser
DEBUG - 2016-06-02 12:15:31 --> Total execution time: 0.0285
INFO - 2016-06-02 12:15:36 --> Config Class Initialized
INFO - 2016-06-02 12:15:36 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:15:36 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:15:36 --> Utf8 Class Initialized
INFO - 2016-06-02 12:15:36 --> URI Class Initialized
INFO - 2016-06-02 12:15:36 --> Router Class Initialized
INFO - 2016-06-02 12:15:36 --> Output Class Initialized
INFO - 2016-06-02 12:15:36 --> Security Class Initialized
DEBUG - 2016-06-02 12:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:15:36 --> CSRF cookie sent
INFO - 2016-06-02 12:15:36 --> CSRF token verified
INFO - 2016-06-02 12:15:36 --> Input Class Initialized
INFO - 2016-06-02 12:15:36 --> Language Class Initialized
INFO - 2016-06-02 12:15:36 --> Loader Class Initialized
INFO - 2016-06-02 12:15:36 --> Helper loaded: form_helper
INFO - 2016-06-02 12:15:36 --> Database Driver Class Initialized
INFO - 2016-06-02 12:15:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:15:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:15:36 --> Email Class Initialized
INFO - 2016-06-02 12:15:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:15:36 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:15:36 --> Helper loaded: language_helper
INFO - 2016-06-02 12:15:36 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:15:36 --> Model Class Initialized
INFO - 2016-06-02 12:15:36 --> Helper loaded: date_helper
INFO - 2016-06-02 12:15:36 --> Controller Class Initialized
INFO - 2016-06-02 12:15:36 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:15:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:15:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:15:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:15:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:15:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:15:36 --> Model Class Initialized
INFO - 2016-06-02 12:15:36 --> Form Validation Class Initialized
INFO - 2016-06-02 12:15:36 --> Final output sent to browser
DEBUG - 2016-06-02 12:15:36 --> Total execution time: 0.0567
INFO - 2016-06-02 12:17:45 --> Config Class Initialized
INFO - 2016-06-02 12:17:45 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:17:45 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:17:45 --> Utf8 Class Initialized
INFO - 2016-06-02 12:17:45 --> URI Class Initialized
INFO - 2016-06-02 12:17:45 --> Router Class Initialized
INFO - 2016-06-02 12:17:45 --> Output Class Initialized
INFO - 2016-06-02 12:17:45 --> Security Class Initialized
DEBUG - 2016-06-02 12:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:17:45 --> CSRF cookie sent
INFO - 2016-06-02 12:17:45 --> Input Class Initialized
INFO - 2016-06-02 12:17:45 --> Language Class Initialized
INFO - 2016-06-02 12:17:45 --> Loader Class Initialized
INFO - 2016-06-02 12:17:45 --> Helper loaded: form_helper
INFO - 2016-06-02 12:17:45 --> Database Driver Class Initialized
INFO - 2016-06-02 12:17:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:17:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:17:45 --> Email Class Initialized
INFO - 2016-06-02 12:17:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:17:45 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:17:45 --> Helper loaded: language_helper
INFO - 2016-06-02 12:17:45 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:17:45 --> Model Class Initialized
INFO - 2016-06-02 12:17:45 --> Helper loaded: date_helper
INFO - 2016-06-02 12:17:45 --> Controller Class Initialized
INFO - 2016-06-02 12:17:45 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:17:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:17:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:17:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:17:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:17:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:17:45 --> Model Class Initialized
INFO - 2016-06-02 12:17:45 --> Form Validation Class Initialized
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:17:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:17:45 --> Final output sent to browser
DEBUG - 2016-06-02 12:17:45 --> Total execution time: 0.0267
INFO - 2016-06-02 12:17:54 --> Config Class Initialized
INFO - 2016-06-02 12:17:54 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:17:54 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:17:54 --> Utf8 Class Initialized
INFO - 2016-06-02 12:17:54 --> URI Class Initialized
INFO - 2016-06-02 12:17:54 --> Router Class Initialized
INFO - 2016-06-02 12:17:54 --> Output Class Initialized
INFO - 2016-06-02 12:17:54 --> Security Class Initialized
DEBUG - 2016-06-02 12:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:17:54 --> CSRF cookie sent
INFO - 2016-06-02 12:17:54 --> CSRF token verified
INFO - 2016-06-02 12:17:54 --> Input Class Initialized
INFO - 2016-06-02 12:17:54 --> Language Class Initialized
INFO - 2016-06-02 12:17:54 --> Loader Class Initialized
INFO - 2016-06-02 12:17:54 --> Helper loaded: form_helper
INFO - 2016-06-02 12:17:54 --> Database Driver Class Initialized
INFO - 2016-06-02 12:17:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:17:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:17:54 --> Email Class Initialized
INFO - 2016-06-02 12:17:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:17:54 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:17:54 --> Helper loaded: language_helper
INFO - 2016-06-02 12:17:54 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:17:54 --> Model Class Initialized
INFO - 2016-06-02 12:17:54 --> Helper loaded: date_helper
INFO - 2016-06-02 12:17:54 --> Controller Class Initialized
INFO - 2016-06-02 12:17:54 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:17:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:17:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:17:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:17:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:17:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:17:54 --> Model Class Initialized
INFO - 2016-06-02 12:17:54 --> Form Validation Class Initialized
INFO - 2016-06-02 12:17:54 --> Final output sent to browser
DEBUG - 2016-06-02 12:17:54 --> Total execution time: 0.0289
INFO - 2016-06-02 12:18:22 --> Config Class Initialized
INFO - 2016-06-02 12:18:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:18:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:18:22 --> Utf8 Class Initialized
INFO - 2016-06-02 12:18:22 --> URI Class Initialized
INFO - 2016-06-02 12:18:22 --> Router Class Initialized
INFO - 2016-06-02 12:18:22 --> Output Class Initialized
INFO - 2016-06-02 12:18:22 --> Security Class Initialized
DEBUG - 2016-06-02 12:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:18:22 --> CSRF cookie sent
INFO - 2016-06-02 12:18:22 --> Input Class Initialized
INFO - 2016-06-02 12:18:22 --> Language Class Initialized
INFO - 2016-06-02 12:18:22 --> Loader Class Initialized
INFO - 2016-06-02 12:18:22 --> Helper loaded: form_helper
INFO - 2016-06-02 12:18:22 --> Database Driver Class Initialized
INFO - 2016-06-02 12:18:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:18:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:18:22 --> Email Class Initialized
INFO - 2016-06-02 12:18:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:18:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:18:22 --> Helper loaded: language_helper
INFO - 2016-06-02 12:18:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:18:22 --> Model Class Initialized
INFO - 2016-06-02 12:18:22 --> Helper loaded: date_helper
INFO - 2016-06-02 12:18:22 --> Controller Class Initialized
INFO - 2016-06-02 12:18:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:18:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:18:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:18:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:18:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:18:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:18:22 --> Model Class Initialized
INFO - 2016-06-02 12:18:22 --> Form Validation Class Initialized
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:18:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:18:22 --> Final output sent to browser
DEBUG - 2016-06-02 12:18:22 --> Total execution time: 0.0218
INFO - 2016-06-02 12:18:29 --> Config Class Initialized
INFO - 2016-06-02 12:18:29 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:18:29 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:18:29 --> Utf8 Class Initialized
INFO - 2016-06-02 12:18:29 --> URI Class Initialized
INFO - 2016-06-02 12:18:29 --> Router Class Initialized
INFO - 2016-06-02 12:18:29 --> Output Class Initialized
INFO - 2016-06-02 12:18:29 --> Security Class Initialized
DEBUG - 2016-06-02 12:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:18:29 --> CSRF cookie sent
INFO - 2016-06-02 12:18:29 --> CSRF token verified
INFO - 2016-06-02 12:18:29 --> Input Class Initialized
INFO - 2016-06-02 12:18:29 --> Language Class Initialized
INFO - 2016-06-02 12:18:29 --> Loader Class Initialized
INFO - 2016-06-02 12:18:29 --> Helper loaded: form_helper
INFO - 2016-06-02 12:18:29 --> Database Driver Class Initialized
INFO - 2016-06-02 12:18:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:18:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:18:29 --> Email Class Initialized
INFO - 2016-06-02 12:18:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:18:29 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:18:29 --> Helper loaded: language_helper
INFO - 2016-06-02 12:18:29 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:18:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:18:29 --> Model Class Initialized
INFO - 2016-06-02 12:18:29 --> Helper loaded: date_helper
INFO - 2016-06-02 12:18:29 --> Controller Class Initialized
INFO - 2016-06-02 12:18:29 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:18:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:18:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:18:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:18:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:18:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:18:29 --> Model Class Initialized
INFO - 2016-06-02 12:18:29 --> Form Validation Class Initialized
INFO - 2016-06-02 12:18:29 --> Final output sent to browser
DEBUG - 2016-06-02 12:18:29 --> Total execution time: 0.0159
INFO - 2016-06-02 12:18:43 --> Config Class Initialized
INFO - 2016-06-02 12:18:43 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:18:43 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:18:43 --> Utf8 Class Initialized
INFO - 2016-06-02 12:18:43 --> URI Class Initialized
INFO - 2016-06-02 12:18:43 --> Router Class Initialized
INFO - 2016-06-02 12:18:43 --> Output Class Initialized
INFO - 2016-06-02 12:18:43 --> Security Class Initialized
DEBUG - 2016-06-02 12:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:18:43 --> CSRF cookie sent
INFO - 2016-06-02 12:18:43 --> Input Class Initialized
INFO - 2016-06-02 12:18:43 --> Language Class Initialized
INFO - 2016-06-02 12:18:43 --> Loader Class Initialized
INFO - 2016-06-02 12:18:43 --> Helper loaded: form_helper
INFO - 2016-06-02 12:18:43 --> Database Driver Class Initialized
INFO - 2016-06-02 12:18:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:18:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:18:43 --> Email Class Initialized
INFO - 2016-06-02 12:18:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:18:43 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:18:43 --> Helper loaded: language_helper
INFO - 2016-06-02 12:18:43 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:18:43 --> Model Class Initialized
INFO - 2016-06-02 12:18:43 --> Helper loaded: date_helper
INFO - 2016-06-02 12:18:43 --> Controller Class Initialized
INFO - 2016-06-02 12:18:43 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:18:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:18:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:18:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:18:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:18:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:18:43 --> Model Class Initialized
INFO - 2016-06-02 12:18:43 --> Form Validation Class Initialized
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:18:43 --> Final output sent to browser
DEBUG - 2016-06-02 12:18:43 --> Total execution time: 0.0207
INFO - 2016-06-02 12:18:53 --> Config Class Initialized
INFO - 2016-06-02 12:18:53 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:18:53 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:18:53 --> Utf8 Class Initialized
INFO - 2016-06-02 12:18:53 --> URI Class Initialized
INFO - 2016-06-02 12:18:53 --> Router Class Initialized
INFO - 2016-06-02 12:18:53 --> Output Class Initialized
INFO - 2016-06-02 12:18:53 --> Security Class Initialized
DEBUG - 2016-06-02 12:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:18:53 --> CSRF cookie sent
INFO - 2016-06-02 12:18:53 --> CSRF token verified
INFO - 2016-06-02 12:18:53 --> Input Class Initialized
INFO - 2016-06-02 12:18:53 --> Language Class Initialized
INFO - 2016-06-02 12:18:53 --> Loader Class Initialized
INFO - 2016-06-02 12:18:53 --> Helper loaded: form_helper
INFO - 2016-06-02 12:18:53 --> Database Driver Class Initialized
INFO - 2016-06-02 12:18:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:18:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:18:53 --> Email Class Initialized
INFO - 2016-06-02 12:18:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:18:53 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:18:53 --> Helper loaded: language_helper
INFO - 2016-06-02 12:18:53 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:18:53 --> Model Class Initialized
INFO - 2016-06-02 12:18:53 --> Helper loaded: date_helper
INFO - 2016-06-02 12:18:53 --> Controller Class Initialized
INFO - 2016-06-02 12:18:53 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:18:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:18:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:18:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:18:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:18:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:18:53 --> Model Class Initialized
INFO - 2016-06-02 12:18:53 --> Form Validation Class Initialized
INFO - 2016-06-02 12:18:53 --> Final output sent to browser
DEBUG - 2016-06-02 12:18:53 --> Total execution time: 0.0157
INFO - 2016-06-02 12:19:44 --> Config Class Initialized
INFO - 2016-06-02 12:19:44 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:19:44 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:19:44 --> Utf8 Class Initialized
INFO - 2016-06-02 12:19:44 --> URI Class Initialized
INFO - 2016-06-02 12:19:44 --> Router Class Initialized
INFO - 2016-06-02 12:19:44 --> Output Class Initialized
INFO - 2016-06-02 12:19:44 --> Security Class Initialized
DEBUG - 2016-06-02 12:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:19:44 --> CSRF cookie sent
INFO - 2016-06-02 12:19:44 --> Input Class Initialized
INFO - 2016-06-02 12:19:44 --> Language Class Initialized
INFO - 2016-06-02 12:19:44 --> Loader Class Initialized
INFO - 2016-06-02 12:19:44 --> Helper loaded: form_helper
INFO - 2016-06-02 12:19:44 --> Database Driver Class Initialized
INFO - 2016-06-02 12:19:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:19:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:19:44 --> Email Class Initialized
INFO - 2016-06-02 12:19:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:19:44 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:19:44 --> Helper loaded: language_helper
INFO - 2016-06-02 12:19:44 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:19:44 --> Model Class Initialized
INFO - 2016-06-02 12:19:44 --> Helper loaded: date_helper
INFO - 2016-06-02 12:19:44 --> Controller Class Initialized
INFO - 2016-06-02 12:19:44 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:19:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:19:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:19:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:19:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:19:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:19:44 --> Model Class Initialized
INFO - 2016-06-02 12:19:44 --> Form Validation Class Initialized
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:19:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:19:44 --> Final output sent to browser
DEBUG - 2016-06-02 12:19:44 --> Total execution time: 0.0257
INFO - 2016-06-02 12:19:50 --> Config Class Initialized
INFO - 2016-06-02 12:19:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:19:50 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:19:50 --> Utf8 Class Initialized
INFO - 2016-06-02 12:19:50 --> URI Class Initialized
INFO - 2016-06-02 12:19:50 --> Router Class Initialized
INFO - 2016-06-02 12:19:50 --> Output Class Initialized
INFO - 2016-06-02 12:19:50 --> Security Class Initialized
DEBUG - 2016-06-02 12:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:19:50 --> CSRF cookie sent
INFO - 2016-06-02 12:19:50 --> CSRF token verified
INFO - 2016-06-02 12:19:50 --> Input Class Initialized
INFO - 2016-06-02 12:19:50 --> Language Class Initialized
INFO - 2016-06-02 12:19:50 --> Loader Class Initialized
INFO - 2016-06-02 12:19:50 --> Helper loaded: form_helper
INFO - 2016-06-02 12:19:50 --> Database Driver Class Initialized
INFO - 2016-06-02 12:19:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:19:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:19:50 --> Email Class Initialized
INFO - 2016-06-02 12:19:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:19:50 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:19:50 --> Helper loaded: language_helper
INFO - 2016-06-02 12:19:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:19:50 --> Model Class Initialized
INFO - 2016-06-02 12:19:50 --> Helper loaded: date_helper
INFO - 2016-06-02 12:19:50 --> Controller Class Initialized
INFO - 2016-06-02 12:19:50 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:19:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:19:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:19:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:19:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:19:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:19:50 --> Model Class Initialized
INFO - 2016-06-02 12:19:50 --> Form Validation Class Initialized
INFO - 2016-06-02 12:19:50 --> Final output sent to browser
DEBUG - 2016-06-02 12:19:50 --> Total execution time: 0.0585
INFO - 2016-06-02 12:20:15 --> Config Class Initialized
INFO - 2016-06-02 12:20:15 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:20:15 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:20:15 --> Utf8 Class Initialized
INFO - 2016-06-02 12:20:15 --> URI Class Initialized
INFO - 2016-06-02 12:20:15 --> Router Class Initialized
INFO - 2016-06-02 12:20:15 --> Output Class Initialized
INFO - 2016-06-02 12:20:15 --> Security Class Initialized
DEBUG - 2016-06-02 12:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:20:15 --> CSRF cookie sent
INFO - 2016-06-02 12:20:15 --> Input Class Initialized
INFO - 2016-06-02 12:20:15 --> Language Class Initialized
INFO - 2016-06-02 12:20:15 --> Loader Class Initialized
INFO - 2016-06-02 12:20:15 --> Helper loaded: form_helper
INFO - 2016-06-02 12:20:15 --> Database Driver Class Initialized
INFO - 2016-06-02 12:20:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:20:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:20:15 --> Email Class Initialized
INFO - 2016-06-02 12:20:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:20:15 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:20:15 --> Helper loaded: language_helper
INFO - 2016-06-02 12:20:15 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:20:15 --> Model Class Initialized
INFO - 2016-06-02 12:20:15 --> Helper loaded: date_helper
INFO - 2016-06-02 12:20:15 --> Controller Class Initialized
INFO - 2016-06-02 12:20:15 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:20:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:20:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:20:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:20:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:20:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:20:15 --> Model Class Initialized
INFO - 2016-06-02 12:20:15 --> Form Validation Class Initialized
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:20:15 --> Final output sent to browser
DEBUG - 2016-06-02 12:20:15 --> Total execution time: 0.0245
INFO - 2016-06-02 12:20:25 --> Config Class Initialized
INFO - 2016-06-02 12:20:25 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:20:25 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:20:25 --> Utf8 Class Initialized
INFO - 2016-06-02 12:20:25 --> URI Class Initialized
INFO - 2016-06-02 12:20:25 --> Router Class Initialized
INFO - 2016-06-02 12:20:25 --> Output Class Initialized
INFO - 2016-06-02 12:20:25 --> Security Class Initialized
DEBUG - 2016-06-02 12:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:20:25 --> CSRF cookie sent
INFO - 2016-06-02 12:20:25 --> CSRF token verified
INFO - 2016-06-02 12:20:25 --> Input Class Initialized
INFO - 2016-06-02 12:20:25 --> Language Class Initialized
INFO - 2016-06-02 12:20:25 --> Loader Class Initialized
INFO - 2016-06-02 12:20:25 --> Helper loaded: form_helper
INFO - 2016-06-02 12:20:25 --> Database Driver Class Initialized
INFO - 2016-06-02 12:20:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:20:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:20:25 --> Email Class Initialized
INFO - 2016-06-02 12:20:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:20:25 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:20:25 --> Helper loaded: language_helper
INFO - 2016-06-02 12:20:25 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:20:25 --> Model Class Initialized
INFO - 2016-06-02 12:20:25 --> Helper loaded: date_helper
INFO - 2016-06-02 12:20:25 --> Controller Class Initialized
INFO - 2016-06-02 12:20:25 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:20:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:20:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:20:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:20:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:20:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:20:25 --> Model Class Initialized
INFO - 2016-06-02 12:20:25 --> Form Validation Class Initialized
INFO - 2016-06-02 12:20:25 --> Final output sent to browser
DEBUG - 2016-06-02 12:20:25 --> Total execution time: 0.0155
INFO - 2016-06-02 12:20:30 --> Config Class Initialized
INFO - 2016-06-02 12:20:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:20:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:20:30 --> Utf8 Class Initialized
INFO - 2016-06-02 12:20:30 --> URI Class Initialized
INFO - 2016-06-02 12:20:30 --> Router Class Initialized
INFO - 2016-06-02 12:20:30 --> Output Class Initialized
INFO - 2016-06-02 12:20:30 --> Security Class Initialized
DEBUG - 2016-06-02 12:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:20:30 --> CSRF cookie sent
INFO - 2016-06-02 12:20:30 --> CSRF token verified
INFO - 2016-06-02 12:20:30 --> Input Class Initialized
INFO - 2016-06-02 12:20:30 --> Language Class Initialized
INFO - 2016-06-02 12:20:30 --> Loader Class Initialized
INFO - 2016-06-02 12:20:30 --> Helper loaded: form_helper
INFO - 2016-06-02 12:20:30 --> Database Driver Class Initialized
INFO - 2016-06-02 12:20:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:20:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:20:30 --> Email Class Initialized
INFO - 2016-06-02 12:20:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:20:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:20:30 --> Helper loaded: language_helper
INFO - 2016-06-02 12:20:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:20:30 --> Model Class Initialized
INFO - 2016-06-02 12:20:30 --> Helper loaded: date_helper
INFO - 2016-06-02 12:20:30 --> Controller Class Initialized
INFO - 2016-06-02 12:20:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:20:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:20:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:20:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:20:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:20:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:20:30 --> Model Class Initialized
INFO - 2016-06-02 12:20:30 --> Form Validation Class Initialized
INFO - 2016-06-02 12:20:30 --> Final output sent to browser
DEBUG - 2016-06-02 12:20:30 --> Total execution time: 0.0550
INFO - 2016-06-02 12:26:25 --> Config Class Initialized
INFO - 2016-06-02 12:26:25 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:26:25 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:26:25 --> Utf8 Class Initialized
INFO - 2016-06-02 12:26:25 --> URI Class Initialized
INFO - 2016-06-02 12:26:25 --> Router Class Initialized
INFO - 2016-06-02 12:26:25 --> Output Class Initialized
INFO - 2016-06-02 12:26:25 --> Security Class Initialized
DEBUG - 2016-06-02 12:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:26:25 --> CSRF cookie sent
INFO - 2016-06-02 12:26:25 --> Input Class Initialized
INFO - 2016-06-02 12:26:25 --> Language Class Initialized
INFO - 2016-06-02 12:26:25 --> Loader Class Initialized
INFO - 2016-06-02 12:26:25 --> Helper loaded: form_helper
INFO - 2016-06-02 12:26:25 --> Database Driver Class Initialized
INFO - 2016-06-02 12:26:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:26:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:26:25 --> Email Class Initialized
INFO - 2016-06-02 12:26:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:26:25 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:26:25 --> Helper loaded: language_helper
INFO - 2016-06-02 12:26:25 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:26:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:26:25 --> Model Class Initialized
INFO - 2016-06-02 12:26:25 --> Helper loaded: date_helper
INFO - 2016-06-02 12:26:25 --> Controller Class Initialized
INFO - 2016-06-02 12:26:25 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:26:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:26:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:26:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:26:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:26:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:26:25 --> Model Class Initialized
INFO - 2016-06-02 12:26:25 --> Form Validation Class Initialized
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:26:25 --> Final output sent to browser
DEBUG - 2016-06-02 12:26:25 --> Total execution time: 0.0229
INFO - 2016-06-02 12:26:33 --> Config Class Initialized
INFO - 2016-06-02 12:26:33 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:26:33 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:26:33 --> Utf8 Class Initialized
INFO - 2016-06-02 12:26:33 --> URI Class Initialized
INFO - 2016-06-02 12:26:33 --> Router Class Initialized
INFO - 2016-06-02 12:26:33 --> Output Class Initialized
INFO - 2016-06-02 12:26:33 --> Security Class Initialized
DEBUG - 2016-06-02 12:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:26:33 --> CSRF cookie sent
INFO - 2016-06-02 12:26:33 --> CSRF token verified
INFO - 2016-06-02 12:26:33 --> Input Class Initialized
INFO - 2016-06-02 12:26:33 --> Language Class Initialized
INFO - 2016-06-02 12:26:33 --> Loader Class Initialized
INFO - 2016-06-02 12:26:33 --> Helper loaded: form_helper
INFO - 2016-06-02 12:26:33 --> Database Driver Class Initialized
INFO - 2016-06-02 12:26:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:26:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:26:33 --> Email Class Initialized
INFO - 2016-06-02 12:26:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:26:33 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:26:33 --> Helper loaded: language_helper
INFO - 2016-06-02 12:26:33 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:26:33 --> Model Class Initialized
INFO - 2016-06-02 12:26:33 --> Helper loaded: date_helper
INFO - 2016-06-02 12:26:33 --> Controller Class Initialized
INFO - 2016-06-02 12:26:33 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:26:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:26:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:26:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:26:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:26:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:26:33 --> Model Class Initialized
INFO - 2016-06-02 12:26:33 --> Form Validation Class Initialized
INFO - 2016-06-02 12:26:33 --> Final output sent to browser
DEBUG - 2016-06-02 12:26:33 --> Total execution time: 0.0420
INFO - 2016-06-02 12:28:03 --> Config Class Initialized
INFO - 2016-06-02 12:28:03 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:28:03 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:28:03 --> Utf8 Class Initialized
INFO - 2016-06-02 12:28:03 --> URI Class Initialized
INFO - 2016-06-02 12:28:03 --> Router Class Initialized
INFO - 2016-06-02 12:28:03 --> Output Class Initialized
INFO - 2016-06-02 12:28:03 --> Security Class Initialized
DEBUG - 2016-06-02 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:28:03 --> CSRF cookie sent
INFO - 2016-06-02 12:28:03 --> Input Class Initialized
INFO - 2016-06-02 12:28:03 --> Language Class Initialized
INFO - 2016-06-02 12:28:03 --> Loader Class Initialized
INFO - 2016-06-02 12:28:03 --> Helper loaded: form_helper
INFO - 2016-06-02 12:28:03 --> Database Driver Class Initialized
INFO - 2016-06-02 12:28:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:28:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:28:03 --> Email Class Initialized
INFO - 2016-06-02 12:28:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:28:03 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:28:03 --> Helper loaded: language_helper
INFO - 2016-06-02 12:28:03 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:28:03 --> Model Class Initialized
INFO - 2016-06-02 12:28:03 --> Helper loaded: date_helper
INFO - 2016-06-02 12:28:03 --> Controller Class Initialized
INFO - 2016-06-02 12:28:03 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:28:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:28:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:28:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:28:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:28:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:28:03 --> Model Class Initialized
INFO - 2016-06-02 12:28:03 --> Form Validation Class Initialized
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:28:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:28:03 --> Final output sent to browser
DEBUG - 2016-06-02 12:28:03 --> Total execution time: 0.0412
INFO - 2016-06-02 12:28:38 --> Config Class Initialized
INFO - 2016-06-02 12:28:38 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:28:38 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:28:38 --> Utf8 Class Initialized
INFO - 2016-06-02 12:28:38 --> URI Class Initialized
INFO - 2016-06-02 12:28:38 --> Router Class Initialized
INFO - 2016-06-02 12:28:38 --> Output Class Initialized
INFO - 2016-06-02 12:28:38 --> Security Class Initialized
DEBUG - 2016-06-02 12:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:28:38 --> CSRF cookie sent
INFO - 2016-06-02 12:28:38 --> CSRF token verified
INFO - 2016-06-02 12:28:38 --> Input Class Initialized
INFO - 2016-06-02 12:28:38 --> Language Class Initialized
INFO - 2016-06-02 12:28:38 --> Loader Class Initialized
INFO - 2016-06-02 12:28:38 --> Helper loaded: form_helper
INFO - 2016-06-02 12:28:38 --> Database Driver Class Initialized
INFO - 2016-06-02 12:28:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:28:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:28:38 --> Email Class Initialized
INFO - 2016-06-02 12:28:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:28:38 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:28:38 --> Helper loaded: language_helper
INFO - 2016-06-02 12:28:38 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:28:38 --> Model Class Initialized
INFO - 2016-06-02 12:28:38 --> Helper loaded: date_helper
INFO - 2016-06-02 12:28:38 --> Controller Class Initialized
INFO - 2016-06-02 12:28:38 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:28:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:28:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:28:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:28:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:28:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:28:38 --> Model Class Initialized
INFO - 2016-06-02 12:28:38 --> Form Validation Class Initialized
INFO - 2016-06-02 12:28:38 --> Final output sent to browser
DEBUG - 2016-06-02 12:28:38 --> Total execution time: 0.0572
INFO - 2016-06-02 12:28:59 --> Config Class Initialized
INFO - 2016-06-02 12:28:59 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:28:59 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:28:59 --> Utf8 Class Initialized
INFO - 2016-06-02 12:28:59 --> URI Class Initialized
INFO - 2016-06-02 12:28:59 --> Router Class Initialized
INFO - 2016-06-02 12:28:59 --> Output Class Initialized
INFO - 2016-06-02 12:28:59 --> Security Class Initialized
DEBUG - 2016-06-02 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:28:59 --> CSRF cookie sent
INFO - 2016-06-02 12:28:59 --> Input Class Initialized
INFO - 2016-06-02 12:28:59 --> Language Class Initialized
INFO - 2016-06-02 12:28:59 --> Loader Class Initialized
INFO - 2016-06-02 12:28:59 --> Helper loaded: form_helper
INFO - 2016-06-02 12:28:59 --> Database Driver Class Initialized
INFO - 2016-06-02 12:28:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:28:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:28:59 --> Email Class Initialized
INFO - 2016-06-02 12:28:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:28:59 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:28:59 --> Helper loaded: language_helper
INFO - 2016-06-02 12:28:59 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:28:59 --> Model Class Initialized
INFO - 2016-06-02 12:28:59 --> Helper loaded: date_helper
INFO - 2016-06-02 12:28:59 --> Controller Class Initialized
INFO - 2016-06-02 12:28:59 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:28:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:28:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:28:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:28:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:28:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:28:59 --> Model Class Initialized
INFO - 2016-06-02 12:28:59 --> Form Validation Class Initialized
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:28:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:28:59 --> Final output sent to browser
DEBUG - 2016-06-02 12:28:59 --> Total execution time: 0.0312
INFO - 2016-06-02 12:29:09 --> Config Class Initialized
INFO - 2016-06-02 12:29:09 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:29:09 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:29:09 --> Utf8 Class Initialized
INFO - 2016-06-02 12:29:09 --> URI Class Initialized
INFO - 2016-06-02 12:29:09 --> Router Class Initialized
INFO - 2016-06-02 12:29:09 --> Output Class Initialized
INFO - 2016-06-02 12:29:09 --> Security Class Initialized
DEBUG - 2016-06-02 12:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:29:09 --> CSRF cookie sent
INFO - 2016-06-02 12:29:09 --> CSRF token verified
INFO - 2016-06-02 12:29:09 --> Input Class Initialized
INFO - 2016-06-02 12:29:09 --> Language Class Initialized
INFO - 2016-06-02 12:29:09 --> Loader Class Initialized
INFO - 2016-06-02 12:29:09 --> Helper loaded: form_helper
INFO - 2016-06-02 12:29:09 --> Database Driver Class Initialized
INFO - 2016-06-02 12:29:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:29:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:29:09 --> Email Class Initialized
INFO - 2016-06-02 12:29:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:29:09 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:29:09 --> Helper loaded: language_helper
INFO - 2016-06-02 12:29:09 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:29:09 --> Model Class Initialized
INFO - 2016-06-02 12:29:09 --> Helper loaded: date_helper
INFO - 2016-06-02 12:29:09 --> Controller Class Initialized
INFO - 2016-06-02 12:29:09 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:29:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:29:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:29:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:29:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:29:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:29:09 --> Model Class Initialized
INFO - 2016-06-02 12:29:09 --> Form Validation Class Initialized
INFO - 2016-06-02 12:29:09 --> Final output sent to browser
DEBUG - 2016-06-02 12:29:09 --> Total execution time: 0.0585
INFO - 2016-06-02 12:37:42 --> Config Class Initialized
INFO - 2016-06-02 12:37:42 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:37:42 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:37:42 --> Utf8 Class Initialized
INFO - 2016-06-02 12:37:42 --> URI Class Initialized
INFO - 2016-06-02 12:37:42 --> Router Class Initialized
INFO - 2016-06-02 12:37:42 --> Output Class Initialized
INFO - 2016-06-02 12:37:42 --> Security Class Initialized
DEBUG - 2016-06-02 12:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:37:42 --> CSRF cookie sent
INFO - 2016-06-02 12:37:42 --> Input Class Initialized
INFO - 2016-06-02 12:37:42 --> Language Class Initialized
INFO - 2016-06-02 12:37:42 --> Loader Class Initialized
INFO - 2016-06-02 12:37:42 --> Helper loaded: form_helper
INFO - 2016-06-02 12:37:42 --> Database Driver Class Initialized
INFO - 2016-06-02 12:37:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:37:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:37:42 --> Email Class Initialized
INFO - 2016-06-02 12:37:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:37:42 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:37:42 --> Helper loaded: language_helper
INFO - 2016-06-02 12:37:42 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:37:42 --> Model Class Initialized
INFO - 2016-06-02 12:37:42 --> Helper loaded: date_helper
INFO - 2016-06-02 12:37:42 --> Controller Class Initialized
INFO - 2016-06-02 12:37:42 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:37:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:37:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:37:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:37:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:37:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:37:42 --> Model Class Initialized
INFO - 2016-06-02 12:37:42 --> Form Validation Class Initialized
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:37:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:37:42 --> Final output sent to browser
DEBUG - 2016-06-02 12:37:42 --> Total execution time: 0.0569
INFO - 2016-06-02 12:37:48 --> Config Class Initialized
INFO - 2016-06-02 12:37:48 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:37:48 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:37:48 --> Utf8 Class Initialized
INFO - 2016-06-02 12:37:48 --> URI Class Initialized
INFO - 2016-06-02 12:37:48 --> Router Class Initialized
INFO - 2016-06-02 12:37:48 --> Output Class Initialized
INFO - 2016-06-02 12:37:48 --> Security Class Initialized
DEBUG - 2016-06-02 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:37:48 --> CSRF cookie sent
INFO - 2016-06-02 12:37:48 --> CSRF token verified
INFO - 2016-06-02 12:37:48 --> Input Class Initialized
INFO - 2016-06-02 12:37:48 --> Language Class Initialized
INFO - 2016-06-02 12:37:48 --> Loader Class Initialized
INFO - 2016-06-02 12:37:48 --> Helper loaded: form_helper
INFO - 2016-06-02 12:37:48 --> Database Driver Class Initialized
INFO - 2016-06-02 12:37:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:37:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:37:48 --> Email Class Initialized
INFO - 2016-06-02 12:37:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:37:48 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:37:48 --> Helper loaded: language_helper
INFO - 2016-06-02 12:37:48 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:37:48 --> Model Class Initialized
INFO - 2016-06-02 12:37:48 --> Helper loaded: date_helper
INFO - 2016-06-02 12:37:48 --> Controller Class Initialized
INFO - 2016-06-02 12:37:48 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:37:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:37:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:37:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:37:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:37:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:37:48 --> Model Class Initialized
INFO - 2016-06-02 12:37:48 --> Form Validation Class Initialized
INFO - 2016-06-02 12:37:48 --> Final output sent to browser
DEBUG - 2016-06-02 12:37:48 --> Total execution time: 0.0334
INFO - 2016-06-02 12:37:53 --> Config Class Initialized
INFO - 2016-06-02 12:37:53 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:37:53 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:37:53 --> Utf8 Class Initialized
INFO - 2016-06-02 12:37:53 --> URI Class Initialized
INFO - 2016-06-02 12:37:53 --> Router Class Initialized
INFO - 2016-06-02 12:37:53 --> Output Class Initialized
INFO - 2016-06-02 12:37:53 --> Security Class Initialized
DEBUG - 2016-06-02 12:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:37:53 --> CSRF cookie sent
INFO - 2016-06-02 12:37:53 --> Input Class Initialized
INFO - 2016-06-02 12:37:53 --> Language Class Initialized
INFO - 2016-06-02 12:37:53 --> Loader Class Initialized
INFO - 2016-06-02 12:37:53 --> Helper loaded: form_helper
INFO - 2016-06-02 12:37:53 --> Database Driver Class Initialized
INFO - 2016-06-02 12:37:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:37:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:37:53 --> Email Class Initialized
INFO - 2016-06-02 12:37:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:37:53 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:37:53 --> Helper loaded: language_helper
INFO - 2016-06-02 12:37:53 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:37:53 --> Model Class Initialized
INFO - 2016-06-02 12:37:53 --> Helper loaded: date_helper
INFO - 2016-06-02 12:37:53 --> Controller Class Initialized
INFO - 2016-06-02 12:37:53 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:37:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:37:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:37:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:37:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:37:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:37:53 --> Model Class Initialized
INFO - 2016-06-02 12:37:53 --> Form Validation Class Initialized
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:37:53 --> Final output sent to browser
DEBUG - 2016-06-02 12:37:53 --> Total execution time: 0.0484
INFO - 2016-06-02 12:37:59 --> Config Class Initialized
INFO - 2016-06-02 12:37:59 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:37:59 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:37:59 --> Utf8 Class Initialized
INFO - 2016-06-02 12:37:59 --> URI Class Initialized
INFO - 2016-06-02 12:37:59 --> Router Class Initialized
INFO - 2016-06-02 12:37:59 --> Output Class Initialized
INFO - 2016-06-02 12:37:59 --> Security Class Initialized
DEBUG - 2016-06-02 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:37:59 --> CSRF cookie sent
INFO - 2016-06-02 12:37:59 --> CSRF token verified
INFO - 2016-06-02 12:37:59 --> Input Class Initialized
INFO - 2016-06-02 12:37:59 --> Language Class Initialized
INFO - 2016-06-02 12:37:59 --> Loader Class Initialized
INFO - 2016-06-02 12:37:59 --> Helper loaded: form_helper
INFO - 2016-06-02 12:37:59 --> Database Driver Class Initialized
INFO - 2016-06-02 12:37:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:37:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:37:59 --> Email Class Initialized
INFO - 2016-06-02 12:37:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:37:59 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:37:59 --> Helper loaded: language_helper
INFO - 2016-06-02 12:37:59 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:37:59 --> Model Class Initialized
INFO - 2016-06-02 12:37:59 --> Helper loaded: date_helper
INFO - 2016-06-02 12:37:59 --> Controller Class Initialized
INFO - 2016-06-02 12:37:59 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:37:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:37:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:37:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:37:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:37:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:37:59 --> Model Class Initialized
INFO - 2016-06-02 12:37:59 --> Form Validation Class Initialized
INFO - 2016-06-02 12:37:59 --> Final output sent to browser
DEBUG - 2016-06-02 12:37:59 --> Total execution time: 0.0155
INFO - 2016-06-02 12:40:14 --> Config Class Initialized
INFO - 2016-06-02 12:40:14 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:40:14 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:40:14 --> Utf8 Class Initialized
INFO - 2016-06-02 12:40:14 --> URI Class Initialized
INFO - 2016-06-02 12:40:14 --> Router Class Initialized
INFO - 2016-06-02 12:40:14 --> Output Class Initialized
INFO - 2016-06-02 12:40:14 --> Security Class Initialized
DEBUG - 2016-06-02 12:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:40:14 --> CSRF cookie sent
INFO - 2016-06-02 12:40:14 --> Input Class Initialized
INFO - 2016-06-02 12:40:14 --> Language Class Initialized
INFO - 2016-06-02 12:40:14 --> Loader Class Initialized
INFO - 2016-06-02 12:40:14 --> Helper loaded: form_helper
INFO - 2016-06-02 12:40:14 --> Database Driver Class Initialized
INFO - 2016-06-02 12:40:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:40:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:40:14 --> Email Class Initialized
INFO - 2016-06-02 12:40:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:40:14 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:40:14 --> Helper loaded: language_helper
INFO - 2016-06-02 12:40:14 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:40:14 --> Model Class Initialized
INFO - 2016-06-02 12:40:14 --> Helper loaded: date_helper
INFO - 2016-06-02 12:40:14 --> Controller Class Initialized
INFO - 2016-06-02 12:40:14 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:40:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:40:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:40:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:40:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:40:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:40:14 --> Model Class Initialized
INFO - 2016-06-02 12:40:14 --> Form Validation Class Initialized
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:40:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:40:14 --> Final output sent to browser
DEBUG - 2016-06-02 12:40:14 --> Total execution time: 0.0227
INFO - 2016-06-02 12:40:22 --> Config Class Initialized
INFO - 2016-06-02 12:40:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:40:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:40:22 --> Utf8 Class Initialized
INFO - 2016-06-02 12:40:22 --> URI Class Initialized
INFO - 2016-06-02 12:40:22 --> Router Class Initialized
INFO - 2016-06-02 12:40:22 --> Output Class Initialized
INFO - 2016-06-02 12:40:22 --> Security Class Initialized
DEBUG - 2016-06-02 12:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:40:22 --> CSRF cookie sent
INFO - 2016-06-02 12:40:22 --> CSRF token verified
INFO - 2016-06-02 12:40:22 --> Input Class Initialized
INFO - 2016-06-02 12:40:22 --> Language Class Initialized
INFO - 2016-06-02 12:40:22 --> Loader Class Initialized
INFO - 2016-06-02 12:40:22 --> Helper loaded: form_helper
INFO - 2016-06-02 12:40:22 --> Database Driver Class Initialized
INFO - 2016-06-02 12:40:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:40:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:40:22 --> Email Class Initialized
INFO - 2016-06-02 12:40:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:40:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:40:22 --> Helper loaded: language_helper
INFO - 2016-06-02 12:40:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:40:22 --> Model Class Initialized
INFO - 2016-06-02 12:40:22 --> Helper loaded: date_helper
INFO - 2016-06-02 12:40:22 --> Controller Class Initialized
INFO - 2016-06-02 12:40:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:40:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:40:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:40:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:40:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:40:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:40:22 --> Model Class Initialized
INFO - 2016-06-02 12:40:22 --> Form Validation Class Initialized
INFO - 2016-06-02 12:40:22 --> Final output sent to browser
DEBUG - 2016-06-02 12:40:22 --> Total execution time: 0.0156
INFO - 2016-06-02 12:41:39 --> Config Class Initialized
INFO - 2016-06-02 12:41:39 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:41:39 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:41:39 --> Utf8 Class Initialized
INFO - 2016-06-02 12:41:39 --> URI Class Initialized
INFO - 2016-06-02 12:41:39 --> Router Class Initialized
INFO - 2016-06-02 12:41:39 --> Output Class Initialized
INFO - 2016-06-02 12:41:39 --> Security Class Initialized
DEBUG - 2016-06-02 12:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:41:39 --> CSRF cookie sent
INFO - 2016-06-02 12:41:39 --> Input Class Initialized
INFO - 2016-06-02 12:41:39 --> Language Class Initialized
INFO - 2016-06-02 12:41:39 --> Loader Class Initialized
INFO - 2016-06-02 12:41:39 --> Helper loaded: form_helper
INFO - 2016-06-02 12:41:39 --> Database Driver Class Initialized
INFO - 2016-06-02 12:41:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:41:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:41:39 --> Email Class Initialized
INFO - 2016-06-02 12:41:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:41:39 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:41:39 --> Helper loaded: language_helper
INFO - 2016-06-02 12:41:39 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:41:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:41:39 --> Model Class Initialized
INFO - 2016-06-02 12:41:39 --> Helper loaded: date_helper
INFO - 2016-06-02 12:41:39 --> Controller Class Initialized
INFO - 2016-06-02 12:41:39 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:41:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:41:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:41:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:41:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:41:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:41:39 --> Model Class Initialized
INFO - 2016-06-02 12:41:39 --> Form Validation Class Initialized
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:41:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:41:39 --> Final output sent to browser
DEBUG - 2016-06-02 12:41:39 --> Total execution time: 0.0800
INFO - 2016-06-02 12:41:43 --> Config Class Initialized
INFO - 2016-06-02 12:41:43 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:41:43 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:41:43 --> Utf8 Class Initialized
INFO - 2016-06-02 12:41:43 --> URI Class Initialized
INFO - 2016-06-02 12:41:43 --> Router Class Initialized
INFO - 2016-06-02 12:41:43 --> Output Class Initialized
INFO - 2016-06-02 12:41:43 --> Security Class Initialized
DEBUG - 2016-06-02 12:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:41:43 --> CSRF cookie sent
INFO - 2016-06-02 12:41:43 --> CSRF token verified
INFO - 2016-06-02 12:41:43 --> Input Class Initialized
INFO - 2016-06-02 12:41:43 --> Language Class Initialized
INFO - 2016-06-02 12:41:43 --> Loader Class Initialized
INFO - 2016-06-02 12:41:43 --> Helper loaded: form_helper
INFO - 2016-06-02 12:41:43 --> Database Driver Class Initialized
INFO - 2016-06-02 12:41:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:41:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:41:43 --> Email Class Initialized
INFO - 2016-06-02 12:41:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:41:43 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:41:43 --> Helper loaded: language_helper
INFO - 2016-06-02 12:41:43 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:41:43 --> Model Class Initialized
INFO - 2016-06-02 12:41:43 --> Helper loaded: date_helper
INFO - 2016-06-02 12:41:43 --> Controller Class Initialized
INFO - 2016-06-02 12:41:43 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:41:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:41:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:41:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:41:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:41:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:41:43 --> Model Class Initialized
INFO - 2016-06-02 12:41:43 --> Form Validation Class Initialized
INFO - 2016-06-02 12:41:43 --> Final output sent to browser
DEBUG - 2016-06-02 12:41:43 --> Total execution time: 0.0133
INFO - 2016-06-02 12:51:16 --> Config Class Initialized
INFO - 2016-06-02 12:51:16 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:51:16 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:51:16 --> Utf8 Class Initialized
INFO - 2016-06-02 12:51:16 --> URI Class Initialized
INFO - 2016-06-02 12:51:16 --> Router Class Initialized
INFO - 2016-06-02 12:51:16 --> Output Class Initialized
INFO - 2016-06-02 12:51:16 --> Security Class Initialized
DEBUG - 2016-06-02 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:51:16 --> CSRF cookie sent
INFO - 2016-06-02 12:51:16 --> Input Class Initialized
INFO - 2016-06-02 12:51:16 --> Language Class Initialized
INFO - 2016-06-02 12:51:16 --> Loader Class Initialized
INFO - 2016-06-02 12:51:16 --> Helper loaded: form_helper
INFO - 2016-06-02 12:51:16 --> Database Driver Class Initialized
INFO - 2016-06-02 12:51:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:51:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:51:16 --> Email Class Initialized
INFO - 2016-06-02 12:51:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:51:16 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:51:16 --> Helper loaded: language_helper
INFO - 2016-06-02 12:51:16 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:51:16 --> Model Class Initialized
INFO - 2016-06-02 12:51:16 --> Helper loaded: date_helper
INFO - 2016-06-02 12:51:16 --> Controller Class Initialized
INFO - 2016-06-02 12:51:16 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:51:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:51:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:51:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:51:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:51:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:51:16 --> Model Class Initialized
INFO - 2016-06-02 12:51:16 --> Form Validation Class Initialized
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:51:16 --> Final output sent to browser
DEBUG - 2016-06-02 12:51:16 --> Total execution time: 0.0522
INFO - 2016-06-02 12:51:21 --> Config Class Initialized
INFO - 2016-06-02 12:51:21 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:51:21 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:51:21 --> Utf8 Class Initialized
INFO - 2016-06-02 12:51:21 --> URI Class Initialized
INFO - 2016-06-02 12:51:21 --> Router Class Initialized
INFO - 2016-06-02 12:51:21 --> Output Class Initialized
INFO - 2016-06-02 12:51:21 --> Security Class Initialized
DEBUG - 2016-06-02 12:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:51:21 --> CSRF cookie sent
INFO - 2016-06-02 12:51:21 --> CSRF token verified
INFO - 2016-06-02 12:51:21 --> Input Class Initialized
INFO - 2016-06-02 12:51:21 --> Language Class Initialized
INFO - 2016-06-02 12:51:21 --> Loader Class Initialized
INFO - 2016-06-02 12:51:21 --> Helper loaded: form_helper
INFO - 2016-06-02 12:51:21 --> Database Driver Class Initialized
INFO - 2016-06-02 12:51:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:51:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:51:21 --> Email Class Initialized
INFO - 2016-06-02 12:51:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:51:21 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:51:21 --> Helper loaded: language_helper
INFO - 2016-06-02 12:51:21 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:51:21 --> Model Class Initialized
INFO - 2016-06-02 12:51:21 --> Helper loaded: date_helper
INFO - 2016-06-02 12:51:21 --> Controller Class Initialized
INFO - 2016-06-02 12:51:21 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:51:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:51:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:51:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:51:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:51:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:51:21 --> Model Class Initialized
INFO - 2016-06-02 12:51:21 --> Form Validation Class Initialized
INFO - 2016-06-02 12:51:21 --> Final output sent to browser
DEBUG - 2016-06-02 12:51:21 --> Total execution time: 0.0127
INFO - 2016-06-02 12:54:00 --> Config Class Initialized
INFO - 2016-06-02 12:54:00 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:54:00 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:54:00 --> Utf8 Class Initialized
INFO - 2016-06-02 12:54:00 --> URI Class Initialized
INFO - 2016-06-02 12:54:00 --> Router Class Initialized
INFO - 2016-06-02 12:54:00 --> Output Class Initialized
INFO - 2016-06-02 12:54:00 --> Security Class Initialized
DEBUG - 2016-06-02 12:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:54:00 --> CSRF cookie sent
INFO - 2016-06-02 12:54:00 --> Input Class Initialized
INFO - 2016-06-02 12:54:00 --> Language Class Initialized
INFO - 2016-06-02 12:54:00 --> Loader Class Initialized
INFO - 2016-06-02 12:54:00 --> Helper loaded: form_helper
INFO - 2016-06-02 12:54:00 --> Database Driver Class Initialized
INFO - 2016-06-02 12:54:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:54:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:54:00 --> Email Class Initialized
INFO - 2016-06-02 12:54:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:54:00 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:54:00 --> Helper loaded: language_helper
INFO - 2016-06-02 12:54:00 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:54:00 --> Model Class Initialized
INFO - 2016-06-02 12:54:00 --> Helper loaded: date_helper
INFO - 2016-06-02 12:54:00 --> Controller Class Initialized
INFO - 2016-06-02 12:54:00 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:54:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:54:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:54:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:54:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:54:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:54:00 --> Model Class Initialized
INFO - 2016-06-02 12:54:00 --> Form Validation Class Initialized
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:54:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:54:00 --> Final output sent to browser
DEBUG - 2016-06-02 12:54:00 --> Total execution time: 0.0273
INFO - 2016-06-02 12:54:07 --> Config Class Initialized
INFO - 2016-06-02 12:54:07 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:54:07 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:54:07 --> Utf8 Class Initialized
INFO - 2016-06-02 12:54:07 --> URI Class Initialized
INFO - 2016-06-02 12:54:07 --> Router Class Initialized
INFO - 2016-06-02 12:54:07 --> Output Class Initialized
INFO - 2016-06-02 12:54:07 --> Security Class Initialized
DEBUG - 2016-06-02 12:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:54:07 --> CSRF cookie sent
INFO - 2016-06-02 12:54:07 --> CSRF token verified
INFO - 2016-06-02 12:54:07 --> Input Class Initialized
INFO - 2016-06-02 12:54:07 --> Language Class Initialized
INFO - 2016-06-02 12:54:07 --> Loader Class Initialized
INFO - 2016-06-02 12:54:07 --> Helper loaded: form_helper
INFO - 2016-06-02 12:54:07 --> Database Driver Class Initialized
INFO - 2016-06-02 12:54:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:54:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:54:07 --> Email Class Initialized
INFO - 2016-06-02 12:54:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:54:07 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:54:07 --> Helper loaded: language_helper
INFO - 2016-06-02 12:54:07 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:54:07 --> Model Class Initialized
INFO - 2016-06-02 12:54:07 --> Helper loaded: date_helper
INFO - 2016-06-02 12:54:07 --> Controller Class Initialized
INFO - 2016-06-02 12:54:07 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:54:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:54:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:54:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:54:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:54:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:54:07 --> Model Class Initialized
INFO - 2016-06-02 12:54:07 --> Form Validation Class Initialized
INFO - 2016-06-02 12:54:07 --> Final output sent to browser
DEBUG - 2016-06-02 12:54:07 --> Total execution time: 0.0549
INFO - 2016-06-02 12:54:23 --> Config Class Initialized
INFO - 2016-06-02 12:54:23 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:54:23 --> Utf8 Class Initialized
INFO - 2016-06-02 12:54:23 --> URI Class Initialized
INFO - 2016-06-02 12:54:23 --> Router Class Initialized
INFO - 2016-06-02 12:54:23 --> Output Class Initialized
INFO - 2016-06-02 12:54:23 --> Security Class Initialized
DEBUG - 2016-06-02 12:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:54:23 --> CSRF cookie sent
INFO - 2016-06-02 12:54:23 --> Input Class Initialized
INFO - 2016-06-02 12:54:23 --> Language Class Initialized
INFO - 2016-06-02 12:54:23 --> Loader Class Initialized
INFO - 2016-06-02 12:54:23 --> Helper loaded: form_helper
INFO - 2016-06-02 12:54:23 --> Database Driver Class Initialized
INFO - 2016-06-02 12:54:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:54:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:54:23 --> Email Class Initialized
INFO - 2016-06-02 12:54:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:54:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:54:23 --> Helper loaded: language_helper
INFO - 2016-06-02 12:54:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:54:23 --> Model Class Initialized
INFO - 2016-06-02 12:54:23 --> Helper loaded: date_helper
INFO - 2016-06-02 12:54:23 --> Controller Class Initialized
INFO - 2016-06-02 12:54:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:54:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:54:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:54:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:54:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:54:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:54:23 --> Model Class Initialized
INFO - 2016-06-02 12:54:23 --> Form Validation Class Initialized
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 12:54:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 12:54:23 --> Final output sent to browser
DEBUG - 2016-06-02 12:54:23 --> Total execution time: 0.0436
INFO - 2016-06-02 12:54:30 --> Config Class Initialized
INFO - 2016-06-02 12:54:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 12:54:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 12:54:30 --> Utf8 Class Initialized
INFO - 2016-06-02 12:54:30 --> URI Class Initialized
INFO - 2016-06-02 12:54:30 --> Router Class Initialized
INFO - 2016-06-02 12:54:30 --> Output Class Initialized
INFO - 2016-06-02 12:54:30 --> Security Class Initialized
DEBUG - 2016-06-02 12:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 12:54:30 --> CSRF cookie sent
INFO - 2016-06-02 12:54:30 --> CSRF token verified
INFO - 2016-06-02 12:54:30 --> Input Class Initialized
INFO - 2016-06-02 12:54:30 --> Language Class Initialized
INFO - 2016-06-02 12:54:30 --> Loader Class Initialized
INFO - 2016-06-02 12:54:30 --> Helper loaded: form_helper
INFO - 2016-06-02 12:54:30 --> Database Driver Class Initialized
INFO - 2016-06-02 12:54:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 12:54:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 12:54:30 --> Email Class Initialized
INFO - 2016-06-02 12:54:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 12:54:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 12:54:30 --> Helper loaded: language_helper
INFO - 2016-06-02 12:54:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 12:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 12:54:30 --> Model Class Initialized
INFO - 2016-06-02 12:54:30 --> Helper loaded: date_helper
INFO - 2016-06-02 12:54:30 --> Controller Class Initialized
INFO - 2016-06-02 12:54:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 12:54:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 12:54:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 12:54:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 12:54:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 12:54:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 12:54:30 --> Model Class Initialized
INFO - 2016-06-02 12:54:30 --> Form Validation Class Initialized
INFO - 2016-06-02 12:54:30 --> Final output sent to browser
DEBUG - 2016-06-02 12:54:30 --> Total execution time: 0.0968
INFO - 2016-06-02 13:02:24 --> Config Class Initialized
INFO - 2016-06-02 13:02:24 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:02:24 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:02:24 --> Utf8 Class Initialized
INFO - 2016-06-02 13:02:24 --> URI Class Initialized
INFO - 2016-06-02 13:02:24 --> Router Class Initialized
INFO - 2016-06-02 13:02:24 --> Output Class Initialized
INFO - 2016-06-02 13:02:24 --> Security Class Initialized
DEBUG - 2016-06-02 13:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:02:24 --> CSRF cookie sent
INFO - 2016-06-02 13:02:24 --> Input Class Initialized
INFO - 2016-06-02 13:02:24 --> Language Class Initialized
INFO - 2016-06-02 13:02:24 --> Loader Class Initialized
INFO - 2016-06-02 13:02:24 --> Helper loaded: form_helper
INFO - 2016-06-02 13:02:24 --> Database Driver Class Initialized
INFO - 2016-06-02 13:02:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:02:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:02:24 --> Email Class Initialized
INFO - 2016-06-02 13:02:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:02:24 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:02:24 --> Helper loaded: language_helper
INFO - 2016-06-02 13:02:24 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:02:24 --> Model Class Initialized
INFO - 2016-06-02 13:02:24 --> Helper loaded: date_helper
INFO - 2016-06-02 13:02:24 --> Controller Class Initialized
INFO - 2016-06-02 13:02:24 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:02:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:02:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:02:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:02:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:02:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:02:24 --> Model Class Initialized
INFO - 2016-06-02 13:02:24 --> Form Validation Class Initialized
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:02:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:02:25 --> Final output sent to browser
DEBUG - 2016-06-02 13:02:25 --> Total execution time: 0.0372
INFO - 2016-06-02 13:02:28 --> Config Class Initialized
INFO - 2016-06-02 13:02:28 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:02:28 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:02:28 --> Utf8 Class Initialized
INFO - 2016-06-02 13:02:28 --> URI Class Initialized
INFO - 2016-06-02 13:02:28 --> Router Class Initialized
INFO - 2016-06-02 13:02:28 --> Output Class Initialized
INFO - 2016-06-02 13:02:28 --> Security Class Initialized
DEBUG - 2016-06-02 13:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:02:28 --> CSRF cookie sent
INFO - 2016-06-02 13:02:28 --> CSRF token verified
INFO - 2016-06-02 13:02:28 --> Input Class Initialized
INFO - 2016-06-02 13:02:28 --> Language Class Initialized
INFO - 2016-06-02 13:02:28 --> Loader Class Initialized
INFO - 2016-06-02 13:02:28 --> Helper loaded: form_helper
INFO - 2016-06-02 13:02:28 --> Database Driver Class Initialized
INFO - 2016-06-02 13:02:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:02:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:02:28 --> Email Class Initialized
INFO - 2016-06-02 13:02:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:02:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:02:28 --> Helper loaded: language_helper
INFO - 2016-06-02 13:02:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:02:28 --> Model Class Initialized
INFO - 2016-06-02 13:02:28 --> Helper loaded: date_helper
INFO - 2016-06-02 13:02:28 --> Controller Class Initialized
INFO - 2016-06-02 13:02:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:02:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:02:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:02:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:02:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:02:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:02:28 --> Model Class Initialized
INFO - 2016-06-02 13:02:28 --> Form Validation Class Initialized
INFO - 2016-06-02 13:02:28 --> Final output sent to browser
DEBUG - 2016-06-02 13:02:28 --> Total execution time: 0.0266
INFO - 2016-06-02 13:02:40 --> Config Class Initialized
INFO - 2016-06-02 13:02:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:02:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:02:40 --> Utf8 Class Initialized
INFO - 2016-06-02 13:02:40 --> URI Class Initialized
INFO - 2016-06-02 13:02:40 --> Router Class Initialized
INFO - 2016-06-02 13:02:40 --> Output Class Initialized
INFO - 2016-06-02 13:02:40 --> Security Class Initialized
DEBUG - 2016-06-02 13:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:02:40 --> CSRF cookie sent
INFO - 2016-06-02 13:02:40 --> CSRF token verified
INFO - 2016-06-02 13:02:40 --> Input Class Initialized
INFO - 2016-06-02 13:02:40 --> Language Class Initialized
INFO - 2016-06-02 13:02:40 --> Loader Class Initialized
INFO - 2016-06-02 13:02:40 --> Helper loaded: form_helper
INFO - 2016-06-02 13:02:40 --> Database Driver Class Initialized
INFO - 2016-06-02 13:02:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:02:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:02:40 --> Email Class Initialized
INFO - 2016-06-02 13:02:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:02:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:02:40 --> Helper loaded: language_helper
INFO - 2016-06-02 13:02:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:02:40 --> Model Class Initialized
INFO - 2016-06-02 13:02:40 --> Helper loaded: date_helper
INFO - 2016-06-02 13:02:40 --> Controller Class Initialized
INFO - 2016-06-02 13:02:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:02:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:02:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:02:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:02:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:02:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:02:40 --> Model Class Initialized
INFO - 2016-06-02 13:02:40 --> Form Validation Class Initialized
INFO - 2016-06-02 13:02:40 --> Final output sent to browser
DEBUG - 2016-06-02 13:02:40 --> Total execution time: 0.0566
INFO - 2016-06-02 13:03:19 --> Config Class Initialized
INFO - 2016-06-02 13:03:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:03:19 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:03:19 --> Utf8 Class Initialized
INFO - 2016-06-02 13:03:19 --> URI Class Initialized
INFO - 2016-06-02 13:03:19 --> Router Class Initialized
INFO - 2016-06-02 13:03:19 --> Output Class Initialized
INFO - 2016-06-02 13:03:19 --> Security Class Initialized
DEBUG - 2016-06-02 13:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:03:19 --> CSRF cookie sent
INFO - 2016-06-02 13:03:19 --> Input Class Initialized
INFO - 2016-06-02 13:03:19 --> Language Class Initialized
INFO - 2016-06-02 13:03:19 --> Loader Class Initialized
INFO - 2016-06-02 13:03:19 --> Helper loaded: form_helper
INFO - 2016-06-02 13:03:19 --> Database Driver Class Initialized
INFO - 2016-06-02 13:03:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:03:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:03:19 --> Email Class Initialized
INFO - 2016-06-02 13:03:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:03:19 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:03:19 --> Helper loaded: language_helper
INFO - 2016-06-02 13:03:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:03:19 --> Model Class Initialized
INFO - 2016-06-02 13:03:19 --> Helper loaded: date_helper
INFO - 2016-06-02 13:03:19 --> Controller Class Initialized
INFO - 2016-06-02 13:03:19 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:03:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:03:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:03:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:03:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:03:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:03:19 --> Model Class Initialized
INFO - 2016-06-02 13:03:19 --> Form Validation Class Initialized
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:03:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:03:19 --> Final output sent to browser
DEBUG - 2016-06-02 13:03:19 --> Total execution time: 0.0341
INFO - 2016-06-02 13:03:23 --> Config Class Initialized
INFO - 2016-06-02 13:03:23 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:03:23 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:03:23 --> Utf8 Class Initialized
INFO - 2016-06-02 13:03:23 --> URI Class Initialized
INFO - 2016-06-02 13:03:23 --> Router Class Initialized
INFO - 2016-06-02 13:03:23 --> Output Class Initialized
INFO - 2016-06-02 13:03:23 --> Security Class Initialized
DEBUG - 2016-06-02 13:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:03:23 --> CSRF cookie sent
INFO - 2016-06-02 13:03:23 --> CSRF token verified
INFO - 2016-06-02 13:03:23 --> Input Class Initialized
INFO - 2016-06-02 13:03:23 --> Language Class Initialized
INFO - 2016-06-02 13:03:23 --> Loader Class Initialized
INFO - 2016-06-02 13:03:23 --> Helper loaded: form_helper
INFO - 2016-06-02 13:03:23 --> Database Driver Class Initialized
INFO - 2016-06-02 13:03:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:03:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:03:23 --> Email Class Initialized
INFO - 2016-06-02 13:03:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:03:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:03:23 --> Helper loaded: language_helper
INFO - 2016-06-02 13:03:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:03:23 --> Model Class Initialized
INFO - 2016-06-02 13:03:23 --> Helper loaded: date_helper
INFO - 2016-06-02 13:03:23 --> Controller Class Initialized
INFO - 2016-06-02 13:03:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:03:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:03:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:03:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:03:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:03:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:03:23 --> Model Class Initialized
INFO - 2016-06-02 13:03:23 --> Form Validation Class Initialized
INFO - 2016-06-02 13:03:23 --> Final output sent to browser
DEBUG - 2016-06-02 13:03:23 --> Total execution time: 0.0198
INFO - 2016-06-02 13:04:22 --> Config Class Initialized
INFO - 2016-06-02 13:04:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:04:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:04:22 --> Utf8 Class Initialized
INFO - 2016-06-02 13:04:22 --> URI Class Initialized
INFO - 2016-06-02 13:04:22 --> Router Class Initialized
INFO - 2016-06-02 13:04:22 --> Output Class Initialized
INFO - 2016-06-02 13:04:22 --> Security Class Initialized
DEBUG - 2016-06-02 13:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:04:22 --> CSRF cookie sent
INFO - 2016-06-02 13:04:22 --> Input Class Initialized
INFO - 2016-06-02 13:04:22 --> Language Class Initialized
INFO - 2016-06-02 13:04:22 --> Loader Class Initialized
INFO - 2016-06-02 13:04:22 --> Helper loaded: form_helper
INFO - 2016-06-02 13:04:22 --> Database Driver Class Initialized
INFO - 2016-06-02 13:04:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:04:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:04:22 --> Email Class Initialized
INFO - 2016-06-02 13:04:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:04:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:04:22 --> Helper loaded: language_helper
INFO - 2016-06-02 13:04:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:04:22 --> Model Class Initialized
INFO - 2016-06-02 13:04:22 --> Helper loaded: date_helper
INFO - 2016-06-02 13:04:22 --> Controller Class Initialized
INFO - 2016-06-02 13:04:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:04:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:04:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:04:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:04:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:04:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:04:22 --> Model Class Initialized
INFO - 2016-06-02 13:04:22 --> Form Validation Class Initialized
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:04:22 --> Final output sent to browser
DEBUG - 2016-06-02 13:04:22 --> Total execution time: 0.0398
INFO - 2016-06-02 13:04:27 --> Config Class Initialized
INFO - 2016-06-02 13:04:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:04:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:04:27 --> Utf8 Class Initialized
INFO - 2016-06-02 13:04:27 --> URI Class Initialized
INFO - 2016-06-02 13:04:27 --> Router Class Initialized
INFO - 2016-06-02 13:04:27 --> Output Class Initialized
INFO - 2016-06-02 13:04:27 --> Security Class Initialized
DEBUG - 2016-06-02 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:04:27 --> CSRF cookie sent
INFO - 2016-06-02 13:04:27 --> CSRF token verified
INFO - 2016-06-02 13:04:28 --> Input Class Initialized
INFO - 2016-06-02 13:04:28 --> Language Class Initialized
INFO - 2016-06-02 13:04:28 --> Loader Class Initialized
INFO - 2016-06-02 13:04:28 --> Helper loaded: form_helper
INFO - 2016-06-02 13:04:28 --> Database Driver Class Initialized
INFO - 2016-06-02 13:04:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:04:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:04:28 --> Email Class Initialized
INFO - 2016-06-02 13:04:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:04:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:04:28 --> Helper loaded: language_helper
INFO - 2016-06-02 13:04:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:04:28 --> Model Class Initialized
INFO - 2016-06-02 13:04:28 --> Helper loaded: date_helper
INFO - 2016-06-02 13:04:28 --> Controller Class Initialized
INFO - 2016-06-02 13:04:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:04:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:04:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:04:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:04:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:04:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:04:28 --> Model Class Initialized
INFO - 2016-06-02 13:04:28 --> Form Validation Class Initialized
INFO - 2016-06-02 13:04:28 --> Final output sent to browser
DEBUG - 2016-06-02 13:04:28 --> Total execution time: 0.0426
INFO - 2016-06-02 13:04:52 --> Config Class Initialized
INFO - 2016-06-02 13:04:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:04:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:04:52 --> Utf8 Class Initialized
INFO - 2016-06-02 13:04:52 --> URI Class Initialized
INFO - 2016-06-02 13:04:52 --> Router Class Initialized
INFO - 2016-06-02 13:04:52 --> Output Class Initialized
INFO - 2016-06-02 13:04:52 --> Security Class Initialized
DEBUG - 2016-06-02 13:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:04:52 --> CSRF cookie sent
INFO - 2016-06-02 13:04:52 --> Input Class Initialized
INFO - 2016-06-02 13:04:52 --> Language Class Initialized
INFO - 2016-06-02 13:04:52 --> Loader Class Initialized
INFO - 2016-06-02 13:04:52 --> Helper loaded: form_helper
INFO - 2016-06-02 13:04:52 --> Database Driver Class Initialized
INFO - 2016-06-02 13:04:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:04:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:04:52 --> Email Class Initialized
INFO - 2016-06-02 13:04:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:04:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:04:52 --> Helper loaded: language_helper
INFO - 2016-06-02 13:04:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:04:52 --> Model Class Initialized
INFO - 2016-06-02 13:04:52 --> Helper loaded: date_helper
INFO - 2016-06-02 13:04:52 --> Controller Class Initialized
INFO - 2016-06-02 13:04:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:04:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:04:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:04:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:04:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:04:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:04:52 --> Model Class Initialized
INFO - 2016-06-02 13:04:52 --> Form Validation Class Initialized
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:04:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:04:52 --> Final output sent to browser
DEBUG - 2016-06-02 13:04:52 --> Total execution time: 0.0330
INFO - 2016-06-02 13:04:57 --> Config Class Initialized
INFO - 2016-06-02 13:04:57 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:04:57 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:04:57 --> Utf8 Class Initialized
INFO - 2016-06-02 13:04:57 --> URI Class Initialized
INFO - 2016-06-02 13:04:57 --> Router Class Initialized
INFO - 2016-06-02 13:04:57 --> Output Class Initialized
INFO - 2016-06-02 13:04:57 --> Security Class Initialized
DEBUG - 2016-06-02 13:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:04:57 --> CSRF cookie sent
INFO - 2016-06-02 13:04:57 --> CSRF token verified
INFO - 2016-06-02 13:04:57 --> Input Class Initialized
INFO - 2016-06-02 13:04:57 --> Language Class Initialized
INFO - 2016-06-02 13:04:57 --> Loader Class Initialized
INFO - 2016-06-02 13:04:57 --> Helper loaded: form_helper
INFO - 2016-06-02 13:04:57 --> Database Driver Class Initialized
INFO - 2016-06-02 13:04:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:04:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:04:57 --> Email Class Initialized
INFO - 2016-06-02 13:04:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:04:57 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:04:57 --> Helper loaded: language_helper
INFO - 2016-06-02 13:04:57 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:04:57 --> Model Class Initialized
INFO - 2016-06-02 13:04:57 --> Helper loaded: date_helper
INFO - 2016-06-02 13:04:57 --> Controller Class Initialized
INFO - 2016-06-02 13:04:57 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:04:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:04:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:04:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:04:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:04:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:04:57 --> Model Class Initialized
INFO - 2016-06-02 13:04:57 --> Form Validation Class Initialized
INFO - 2016-06-02 13:04:57 --> Final output sent to browser
DEBUG - 2016-06-02 13:04:57 --> Total execution time: 0.0453
INFO - 2016-06-02 13:05:40 --> Config Class Initialized
INFO - 2016-06-02 13:05:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:05:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:05:40 --> Utf8 Class Initialized
INFO - 2016-06-02 13:05:40 --> URI Class Initialized
INFO - 2016-06-02 13:05:40 --> Router Class Initialized
INFO - 2016-06-02 13:05:40 --> Output Class Initialized
INFO - 2016-06-02 13:05:40 --> Security Class Initialized
DEBUG - 2016-06-02 13:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:05:40 --> CSRF cookie sent
INFO - 2016-06-02 13:05:40 --> Input Class Initialized
INFO - 2016-06-02 13:05:40 --> Language Class Initialized
INFO - 2016-06-02 13:05:40 --> Loader Class Initialized
INFO - 2016-06-02 13:05:40 --> Helper loaded: form_helper
INFO - 2016-06-02 13:05:40 --> Database Driver Class Initialized
INFO - 2016-06-02 13:05:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:05:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:05:40 --> Email Class Initialized
INFO - 2016-06-02 13:05:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:05:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:05:40 --> Helper loaded: language_helper
INFO - 2016-06-02 13:05:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:05:40 --> Model Class Initialized
INFO - 2016-06-02 13:05:40 --> Helper loaded: date_helper
INFO - 2016-06-02 13:05:40 --> Controller Class Initialized
INFO - 2016-06-02 13:05:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:05:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:05:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:05:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:05:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:05:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:05:40 --> Model Class Initialized
INFO - 2016-06-02 13:05:40 --> Form Validation Class Initialized
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:05:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:05:40 --> Final output sent to browser
DEBUG - 2016-06-02 13:05:40 --> Total execution time: 0.0646
INFO - 2016-06-02 13:05:44 --> Config Class Initialized
INFO - 2016-06-02 13:05:44 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:05:44 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:05:44 --> Utf8 Class Initialized
INFO - 2016-06-02 13:05:44 --> URI Class Initialized
INFO - 2016-06-02 13:05:44 --> Router Class Initialized
INFO - 2016-06-02 13:05:44 --> Output Class Initialized
INFO - 2016-06-02 13:05:44 --> Security Class Initialized
DEBUG - 2016-06-02 13:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:05:44 --> CSRF cookie sent
INFO - 2016-06-02 13:05:44 --> CSRF token verified
INFO - 2016-06-02 13:05:44 --> Input Class Initialized
INFO - 2016-06-02 13:05:44 --> Language Class Initialized
INFO - 2016-06-02 13:05:44 --> Loader Class Initialized
INFO - 2016-06-02 13:05:44 --> Helper loaded: form_helper
INFO - 2016-06-02 13:05:44 --> Database Driver Class Initialized
INFO - 2016-06-02 13:05:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:05:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:05:44 --> Email Class Initialized
INFO - 2016-06-02 13:05:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:05:44 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:05:44 --> Helper loaded: language_helper
INFO - 2016-06-02 13:05:44 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:05:44 --> Model Class Initialized
INFO - 2016-06-02 13:05:44 --> Helper loaded: date_helper
INFO - 2016-06-02 13:05:44 --> Controller Class Initialized
INFO - 2016-06-02 13:05:44 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:05:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:05:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:05:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:05:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:05:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:05:44 --> Model Class Initialized
INFO - 2016-06-02 13:05:44 --> Form Validation Class Initialized
INFO - 2016-06-02 13:05:44 --> Final output sent to browser
DEBUG - 2016-06-02 13:05:44 --> Total execution time: 0.0548
INFO - 2016-06-02 13:07:05 --> Config Class Initialized
INFO - 2016-06-02 13:07:05 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:07:05 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:07:05 --> Utf8 Class Initialized
INFO - 2016-06-02 13:07:05 --> URI Class Initialized
INFO - 2016-06-02 13:07:05 --> Router Class Initialized
INFO - 2016-06-02 13:07:05 --> Output Class Initialized
INFO - 2016-06-02 13:07:05 --> Security Class Initialized
DEBUG - 2016-06-02 13:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:07:05 --> CSRF cookie sent
INFO - 2016-06-02 13:07:05 --> Input Class Initialized
INFO - 2016-06-02 13:07:05 --> Language Class Initialized
INFO - 2016-06-02 13:07:05 --> Loader Class Initialized
INFO - 2016-06-02 13:07:05 --> Helper loaded: form_helper
INFO - 2016-06-02 13:07:05 --> Database Driver Class Initialized
INFO - 2016-06-02 13:07:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:07:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:07:05 --> Email Class Initialized
INFO - 2016-06-02 13:07:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:07:05 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:07:05 --> Helper loaded: language_helper
INFO - 2016-06-02 13:07:05 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:07:05 --> Model Class Initialized
INFO - 2016-06-02 13:07:05 --> Helper loaded: date_helper
INFO - 2016-06-02 13:07:05 --> Controller Class Initialized
INFO - 2016-06-02 13:07:05 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:07:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:07:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:07:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:07:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:07:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:07:05 --> Model Class Initialized
INFO - 2016-06-02 13:07:05 --> Form Validation Class Initialized
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:07:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:07:05 --> Final output sent to browser
DEBUG - 2016-06-02 13:07:05 --> Total execution time: 0.0350
INFO - 2016-06-02 13:07:11 --> Config Class Initialized
INFO - 2016-06-02 13:07:11 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:07:11 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:07:11 --> Utf8 Class Initialized
INFO - 2016-06-02 13:07:11 --> URI Class Initialized
INFO - 2016-06-02 13:07:11 --> Router Class Initialized
INFO - 2016-06-02 13:07:11 --> Output Class Initialized
INFO - 2016-06-02 13:07:11 --> Security Class Initialized
DEBUG - 2016-06-02 13:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:07:11 --> CSRF cookie sent
INFO - 2016-06-02 13:07:11 --> CSRF token verified
INFO - 2016-06-02 13:07:11 --> Input Class Initialized
INFO - 2016-06-02 13:07:11 --> Language Class Initialized
INFO - 2016-06-02 13:07:11 --> Loader Class Initialized
INFO - 2016-06-02 13:07:11 --> Helper loaded: form_helper
INFO - 2016-06-02 13:07:11 --> Database Driver Class Initialized
INFO - 2016-06-02 13:07:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:07:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:07:11 --> Email Class Initialized
INFO - 2016-06-02 13:07:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:07:11 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:07:11 --> Helper loaded: language_helper
INFO - 2016-06-02 13:07:11 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:07:11 --> Model Class Initialized
INFO - 2016-06-02 13:07:11 --> Helper loaded: date_helper
INFO - 2016-06-02 13:07:11 --> Controller Class Initialized
INFO - 2016-06-02 13:07:11 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:07:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:07:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:07:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:07:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:07:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:07:11 --> Model Class Initialized
INFO - 2016-06-02 13:07:11 --> Form Validation Class Initialized
INFO - 2016-06-02 13:07:12 --> Final output sent to browser
DEBUG - 2016-06-02 13:07:12 --> Total execution time: 0.0585
INFO - 2016-06-02 13:07:21 --> Config Class Initialized
INFO - 2016-06-02 13:07:21 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:07:21 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:07:21 --> Utf8 Class Initialized
INFO - 2016-06-02 13:07:21 --> URI Class Initialized
INFO - 2016-06-02 13:07:21 --> Router Class Initialized
INFO - 2016-06-02 13:07:21 --> Output Class Initialized
INFO - 2016-06-02 13:07:21 --> Security Class Initialized
DEBUG - 2016-06-02 13:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:07:21 --> CSRF cookie sent
INFO - 2016-06-02 13:07:21 --> Input Class Initialized
INFO - 2016-06-02 13:07:21 --> Language Class Initialized
INFO - 2016-06-02 13:07:21 --> Loader Class Initialized
INFO - 2016-06-02 13:07:21 --> Helper loaded: form_helper
INFO - 2016-06-02 13:07:21 --> Database Driver Class Initialized
INFO - 2016-06-02 13:07:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:07:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:07:21 --> Email Class Initialized
INFO - 2016-06-02 13:07:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:07:21 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:07:21 --> Helper loaded: language_helper
INFO - 2016-06-02 13:07:21 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:07:21 --> Model Class Initialized
INFO - 2016-06-02 13:07:21 --> Helper loaded: date_helper
INFO - 2016-06-02 13:07:21 --> Controller Class Initialized
INFO - 2016-06-02 13:07:21 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:07:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:07:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:07:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:07:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:07:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:07:21 --> Model Class Initialized
INFO - 2016-06-02 13:07:21 --> Form Validation Class Initialized
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:07:21 --> Final output sent to browser
DEBUG - 2016-06-02 13:07:21 --> Total execution time: 0.0466
INFO - 2016-06-02 13:07:28 --> Config Class Initialized
INFO - 2016-06-02 13:07:28 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:07:28 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:07:28 --> Utf8 Class Initialized
INFO - 2016-06-02 13:07:28 --> URI Class Initialized
INFO - 2016-06-02 13:07:28 --> Router Class Initialized
INFO - 2016-06-02 13:07:28 --> Output Class Initialized
INFO - 2016-06-02 13:07:28 --> Security Class Initialized
DEBUG - 2016-06-02 13:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:07:28 --> CSRF cookie sent
INFO - 2016-06-02 13:07:28 --> CSRF token verified
INFO - 2016-06-02 13:07:28 --> Input Class Initialized
INFO - 2016-06-02 13:07:28 --> Language Class Initialized
INFO - 2016-06-02 13:07:28 --> Loader Class Initialized
INFO - 2016-06-02 13:07:28 --> Helper loaded: form_helper
INFO - 2016-06-02 13:07:28 --> Database Driver Class Initialized
INFO - 2016-06-02 13:07:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:07:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:07:28 --> Email Class Initialized
INFO - 2016-06-02 13:07:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:07:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:07:28 --> Helper loaded: language_helper
INFO - 2016-06-02 13:07:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:07:28 --> Model Class Initialized
INFO - 2016-06-02 13:07:28 --> Helper loaded: date_helper
INFO - 2016-06-02 13:07:28 --> Controller Class Initialized
INFO - 2016-06-02 13:07:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:07:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:07:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:07:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:07:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:07:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:07:29 --> Model Class Initialized
INFO - 2016-06-02 13:07:29 --> Form Validation Class Initialized
INFO - 2016-06-02 13:07:29 --> Final output sent to browser
DEBUG - 2016-06-02 13:07:29 --> Total execution time: 0.0552
INFO - 2016-06-02 13:07:54 --> Config Class Initialized
INFO - 2016-06-02 13:07:54 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:07:54 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:07:54 --> Utf8 Class Initialized
INFO - 2016-06-02 13:07:54 --> URI Class Initialized
INFO - 2016-06-02 13:07:54 --> Router Class Initialized
INFO - 2016-06-02 13:07:54 --> Output Class Initialized
INFO - 2016-06-02 13:07:54 --> Security Class Initialized
DEBUG - 2016-06-02 13:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:07:54 --> CSRF cookie sent
INFO - 2016-06-02 13:07:54 --> Input Class Initialized
INFO - 2016-06-02 13:07:54 --> Language Class Initialized
INFO - 2016-06-02 13:07:54 --> Loader Class Initialized
INFO - 2016-06-02 13:07:54 --> Helper loaded: form_helper
INFO - 2016-06-02 13:07:54 --> Database Driver Class Initialized
INFO - 2016-06-02 13:07:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:07:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:07:54 --> Email Class Initialized
INFO - 2016-06-02 13:07:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:07:54 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:07:54 --> Helper loaded: language_helper
INFO - 2016-06-02 13:07:54 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:07:54 --> Model Class Initialized
INFO - 2016-06-02 13:07:54 --> Helper loaded: date_helper
INFO - 2016-06-02 13:07:54 --> Controller Class Initialized
INFO - 2016-06-02 13:07:54 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:07:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:07:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:07:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:07:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:07:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:07:54 --> Model Class Initialized
INFO - 2016-06-02 13:07:54 --> Form Validation Class Initialized
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:07:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:07:54 --> Final output sent to browser
DEBUG - 2016-06-02 13:07:54 --> Total execution time: 0.0200
INFO - 2016-06-02 13:08:00 --> Config Class Initialized
INFO - 2016-06-02 13:08:00 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:08:00 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:08:00 --> Utf8 Class Initialized
INFO - 2016-06-02 13:08:00 --> URI Class Initialized
INFO - 2016-06-02 13:08:00 --> Router Class Initialized
INFO - 2016-06-02 13:08:00 --> Output Class Initialized
INFO - 2016-06-02 13:08:00 --> Security Class Initialized
DEBUG - 2016-06-02 13:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:08:00 --> CSRF cookie sent
INFO - 2016-06-02 13:08:00 --> CSRF token verified
INFO - 2016-06-02 13:08:00 --> Input Class Initialized
INFO - 2016-06-02 13:08:00 --> Language Class Initialized
INFO - 2016-06-02 13:08:00 --> Loader Class Initialized
INFO - 2016-06-02 13:08:00 --> Helper loaded: form_helper
INFO - 2016-06-02 13:08:00 --> Database Driver Class Initialized
INFO - 2016-06-02 13:08:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:08:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:08:00 --> Email Class Initialized
INFO - 2016-06-02 13:08:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:08:00 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:08:00 --> Helper loaded: language_helper
INFO - 2016-06-02 13:08:00 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:08:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:08:00 --> Model Class Initialized
INFO - 2016-06-02 13:08:00 --> Helper loaded: date_helper
INFO - 2016-06-02 13:08:00 --> Controller Class Initialized
INFO - 2016-06-02 13:08:00 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:08:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:08:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:08:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:08:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:08:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:08:00 --> Model Class Initialized
INFO - 2016-06-02 13:08:00 --> Form Validation Class Initialized
INFO - 2016-06-02 13:08:00 --> Final output sent to browser
DEBUG - 2016-06-02 13:08:00 --> Total execution time: 0.0554
INFO - 2016-06-02 13:08:15 --> Config Class Initialized
INFO - 2016-06-02 13:08:15 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:08:15 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:08:15 --> Utf8 Class Initialized
INFO - 2016-06-02 13:08:15 --> URI Class Initialized
INFO - 2016-06-02 13:08:15 --> Router Class Initialized
INFO - 2016-06-02 13:08:15 --> Output Class Initialized
INFO - 2016-06-02 13:08:15 --> Security Class Initialized
DEBUG - 2016-06-02 13:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:08:15 --> CSRF cookie sent
INFO - 2016-06-02 13:08:15 --> Input Class Initialized
INFO - 2016-06-02 13:08:15 --> Language Class Initialized
INFO - 2016-06-02 13:08:15 --> Loader Class Initialized
INFO - 2016-06-02 13:08:15 --> Helper loaded: form_helper
INFO - 2016-06-02 13:08:15 --> Database Driver Class Initialized
INFO - 2016-06-02 13:08:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:08:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:08:15 --> Email Class Initialized
INFO - 2016-06-02 13:08:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:08:15 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:08:15 --> Helper loaded: language_helper
INFO - 2016-06-02 13:08:15 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:08:15 --> Model Class Initialized
INFO - 2016-06-02 13:08:15 --> Helper loaded: date_helper
INFO - 2016-06-02 13:08:15 --> Controller Class Initialized
INFO - 2016-06-02 13:08:15 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:08:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:08:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:08:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:08:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:08:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:08:15 --> Model Class Initialized
INFO - 2016-06-02 13:08:15 --> Form Validation Class Initialized
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:08:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:08:15 --> Final output sent to browser
DEBUG - 2016-06-02 13:08:15 --> Total execution time: 0.0364
INFO - 2016-06-02 13:08:23 --> Config Class Initialized
INFO - 2016-06-02 13:08:23 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:08:23 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:08:23 --> Utf8 Class Initialized
INFO - 2016-06-02 13:08:23 --> URI Class Initialized
INFO - 2016-06-02 13:08:23 --> Router Class Initialized
INFO - 2016-06-02 13:08:23 --> Output Class Initialized
INFO - 2016-06-02 13:08:23 --> Security Class Initialized
DEBUG - 2016-06-02 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:08:23 --> CSRF cookie sent
INFO - 2016-06-02 13:08:23 --> CSRF token verified
INFO - 2016-06-02 13:08:23 --> Input Class Initialized
INFO - 2016-06-02 13:08:23 --> Language Class Initialized
INFO - 2016-06-02 13:08:23 --> Loader Class Initialized
INFO - 2016-06-02 13:08:23 --> Helper loaded: form_helper
INFO - 2016-06-02 13:08:23 --> Database Driver Class Initialized
INFO - 2016-06-02 13:08:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:08:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:08:23 --> Email Class Initialized
INFO - 2016-06-02 13:08:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:08:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:08:23 --> Helper loaded: language_helper
INFO - 2016-06-02 13:08:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:08:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:08:23 --> Model Class Initialized
INFO - 2016-06-02 13:08:23 --> Helper loaded: date_helper
INFO - 2016-06-02 13:08:23 --> Controller Class Initialized
INFO - 2016-06-02 13:08:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:08:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:08:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:08:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:08:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:08:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:08:23 --> Model Class Initialized
INFO - 2016-06-02 13:08:23 --> Form Validation Class Initialized
INFO - 2016-06-02 13:08:23 --> Final output sent to browser
DEBUG - 2016-06-02 13:08:23 --> Total execution time: 0.0532
INFO - 2016-06-02 13:09:04 --> Config Class Initialized
INFO - 2016-06-02 13:09:04 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:09:04 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:09:04 --> Utf8 Class Initialized
INFO - 2016-06-02 13:09:04 --> URI Class Initialized
INFO - 2016-06-02 13:09:04 --> Router Class Initialized
INFO - 2016-06-02 13:09:04 --> Output Class Initialized
INFO - 2016-06-02 13:09:04 --> Security Class Initialized
DEBUG - 2016-06-02 13:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:09:04 --> CSRF cookie sent
INFO - 2016-06-02 13:09:04 --> Input Class Initialized
INFO - 2016-06-02 13:09:04 --> Language Class Initialized
INFO - 2016-06-02 13:09:04 --> Loader Class Initialized
INFO - 2016-06-02 13:09:04 --> Helper loaded: form_helper
INFO - 2016-06-02 13:09:04 --> Database Driver Class Initialized
INFO - 2016-06-02 13:09:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:09:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:09:04 --> Email Class Initialized
INFO - 2016-06-02 13:09:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:09:04 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:09:04 --> Helper loaded: language_helper
INFO - 2016-06-02 13:09:04 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:09:04 --> Model Class Initialized
INFO - 2016-06-02 13:09:04 --> Helper loaded: date_helper
INFO - 2016-06-02 13:09:04 --> Controller Class Initialized
INFO - 2016-06-02 13:09:04 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:09:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:09:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:09:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:09:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:09:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:09:04 --> Model Class Initialized
INFO - 2016-06-02 13:09:04 --> Form Validation Class Initialized
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:09:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:09:04 --> Final output sent to browser
DEBUG - 2016-06-02 13:09:04 --> Total execution time: 0.0275
INFO - 2016-06-02 13:09:10 --> Config Class Initialized
INFO - 2016-06-02 13:09:10 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:09:10 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:09:10 --> Utf8 Class Initialized
INFO - 2016-06-02 13:09:10 --> URI Class Initialized
INFO - 2016-06-02 13:09:10 --> Router Class Initialized
INFO - 2016-06-02 13:09:10 --> Output Class Initialized
INFO - 2016-06-02 13:09:10 --> Security Class Initialized
DEBUG - 2016-06-02 13:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:09:10 --> CSRF cookie sent
INFO - 2016-06-02 13:09:10 --> CSRF token verified
INFO - 2016-06-02 13:09:10 --> Input Class Initialized
INFO - 2016-06-02 13:09:10 --> Language Class Initialized
INFO - 2016-06-02 13:09:10 --> Loader Class Initialized
INFO - 2016-06-02 13:09:10 --> Helper loaded: form_helper
INFO - 2016-06-02 13:09:10 --> Database Driver Class Initialized
INFO - 2016-06-02 13:09:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:09:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:09:10 --> Email Class Initialized
INFO - 2016-06-02 13:09:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:09:10 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:09:10 --> Helper loaded: language_helper
INFO - 2016-06-02 13:09:10 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:09:10 --> Model Class Initialized
INFO - 2016-06-02 13:09:10 --> Helper loaded: date_helper
INFO - 2016-06-02 13:09:10 --> Controller Class Initialized
INFO - 2016-06-02 13:09:10 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:09:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:09:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:09:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:09:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:09:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:09:10 --> Model Class Initialized
INFO - 2016-06-02 13:09:10 --> Form Validation Class Initialized
INFO - 2016-06-02 13:09:10 --> Final output sent to browser
DEBUG - 2016-06-02 13:09:10 --> Total execution time: 0.0449
INFO - 2016-06-02 13:10:34 --> Config Class Initialized
INFO - 2016-06-02 13:10:34 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:10:34 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:10:34 --> Utf8 Class Initialized
INFO - 2016-06-02 13:10:34 --> URI Class Initialized
INFO - 2016-06-02 13:10:34 --> Router Class Initialized
INFO - 2016-06-02 13:10:34 --> Output Class Initialized
INFO - 2016-06-02 13:10:34 --> Security Class Initialized
DEBUG - 2016-06-02 13:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:10:34 --> CSRF cookie sent
INFO - 2016-06-02 13:10:34 --> Input Class Initialized
INFO - 2016-06-02 13:10:34 --> Language Class Initialized
INFO - 2016-06-02 13:10:34 --> Loader Class Initialized
INFO - 2016-06-02 13:10:34 --> Helper loaded: form_helper
INFO - 2016-06-02 13:10:34 --> Database Driver Class Initialized
INFO - 2016-06-02 13:10:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:10:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:10:34 --> Email Class Initialized
INFO - 2016-06-02 13:10:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:10:34 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:10:34 --> Helper loaded: language_helper
INFO - 2016-06-02 13:10:34 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:10:34 --> Model Class Initialized
INFO - 2016-06-02 13:10:34 --> Helper loaded: date_helper
INFO - 2016-06-02 13:10:34 --> Controller Class Initialized
INFO - 2016-06-02 13:10:34 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:10:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:10:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:10:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:10:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:10:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:10:34 --> Model Class Initialized
INFO - 2016-06-02 13:10:34 --> Form Validation Class Initialized
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:10:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:10:34 --> Final output sent to browser
DEBUG - 2016-06-02 13:10:34 --> Total execution time: 0.0656
INFO - 2016-06-02 13:10:40 --> Config Class Initialized
INFO - 2016-06-02 13:10:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:10:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:10:40 --> Utf8 Class Initialized
INFO - 2016-06-02 13:10:40 --> URI Class Initialized
INFO - 2016-06-02 13:10:40 --> Router Class Initialized
INFO - 2016-06-02 13:10:40 --> Output Class Initialized
INFO - 2016-06-02 13:10:40 --> Security Class Initialized
DEBUG - 2016-06-02 13:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:10:40 --> CSRF cookie sent
INFO - 2016-06-02 13:10:40 --> CSRF token verified
INFO - 2016-06-02 13:10:40 --> Input Class Initialized
INFO - 2016-06-02 13:10:40 --> Language Class Initialized
INFO - 2016-06-02 13:10:40 --> Loader Class Initialized
INFO - 2016-06-02 13:10:40 --> Helper loaded: form_helper
INFO - 2016-06-02 13:10:40 --> Database Driver Class Initialized
INFO - 2016-06-02 13:10:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:10:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:10:40 --> Email Class Initialized
INFO - 2016-06-02 13:10:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:10:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:10:40 --> Helper loaded: language_helper
INFO - 2016-06-02 13:10:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:10:40 --> Model Class Initialized
INFO - 2016-06-02 13:10:41 --> Helper loaded: date_helper
INFO - 2016-06-02 13:10:41 --> Controller Class Initialized
INFO - 2016-06-02 13:10:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:10:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:10:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:10:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:10:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:10:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:10:41 --> Model Class Initialized
INFO - 2016-06-02 13:10:41 --> Form Validation Class Initialized
INFO - 2016-06-02 13:10:41 --> Final output sent to browser
DEBUG - 2016-06-02 13:10:41 --> Total execution time: 0.0556
INFO - 2016-06-02 13:11:07 --> Config Class Initialized
INFO - 2016-06-02 13:11:07 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:11:07 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:11:07 --> Utf8 Class Initialized
INFO - 2016-06-02 13:11:07 --> URI Class Initialized
INFO - 2016-06-02 13:11:07 --> Router Class Initialized
INFO - 2016-06-02 13:11:07 --> Output Class Initialized
INFO - 2016-06-02 13:11:07 --> Security Class Initialized
DEBUG - 2016-06-02 13:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:11:07 --> CSRF cookie sent
INFO - 2016-06-02 13:11:07 --> CSRF token verified
INFO - 2016-06-02 13:11:07 --> Input Class Initialized
INFO - 2016-06-02 13:11:07 --> Language Class Initialized
INFO - 2016-06-02 13:11:07 --> Loader Class Initialized
INFO - 2016-06-02 13:11:07 --> Helper loaded: form_helper
INFO - 2016-06-02 13:11:07 --> Database Driver Class Initialized
INFO - 2016-06-02 13:11:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:11:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:11:07 --> Email Class Initialized
INFO - 2016-06-02 13:11:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:11:07 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:11:07 --> Helper loaded: language_helper
INFO - 2016-06-02 13:11:07 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:11:07 --> Model Class Initialized
INFO - 2016-06-02 13:11:07 --> Helper loaded: date_helper
INFO - 2016-06-02 13:11:07 --> Controller Class Initialized
INFO - 2016-06-02 13:11:07 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:11:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:11:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:11:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:11:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:11:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:11:07 --> Model Class Initialized
INFO - 2016-06-02 13:11:07 --> Form Validation Class Initialized
INFO - 2016-06-02 13:11:07 --> Final output sent to browser
DEBUG - 2016-06-02 13:11:07 --> Total execution time: 0.0616
INFO - 2016-06-02 13:11:23 --> Config Class Initialized
INFO - 2016-06-02 13:11:23 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:11:23 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:11:23 --> Utf8 Class Initialized
INFO - 2016-06-02 13:11:23 --> URI Class Initialized
INFO - 2016-06-02 13:11:23 --> Router Class Initialized
INFO - 2016-06-02 13:11:23 --> Output Class Initialized
INFO - 2016-06-02 13:11:23 --> Security Class Initialized
DEBUG - 2016-06-02 13:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:11:23 --> CSRF cookie sent
INFO - 2016-06-02 13:11:23 --> CSRF token verified
INFO - 2016-06-02 13:11:23 --> Input Class Initialized
INFO - 2016-06-02 13:11:23 --> Language Class Initialized
INFO - 2016-06-02 13:11:23 --> Loader Class Initialized
INFO - 2016-06-02 13:11:23 --> Helper loaded: form_helper
INFO - 2016-06-02 13:11:23 --> Database Driver Class Initialized
INFO - 2016-06-02 13:11:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:11:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:11:23 --> Email Class Initialized
INFO - 2016-06-02 13:11:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:11:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:11:23 --> Helper loaded: language_helper
INFO - 2016-06-02 13:11:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:11:23 --> Model Class Initialized
INFO - 2016-06-02 13:11:23 --> Helper loaded: date_helper
INFO - 2016-06-02 13:11:23 --> Controller Class Initialized
INFO - 2016-06-02 13:11:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:11:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:11:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:11:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:11:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:11:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:11:23 --> Model Class Initialized
INFO - 2016-06-02 13:11:23 --> Form Validation Class Initialized
INFO - 2016-06-02 13:11:23 --> Final output sent to browser
DEBUG - 2016-06-02 13:11:23 --> Total execution time: 0.0560
INFO - 2016-06-02 13:34:52 --> Config Class Initialized
INFO - 2016-06-02 13:34:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:34:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:34:52 --> Utf8 Class Initialized
INFO - 2016-06-02 13:34:52 --> URI Class Initialized
INFO - 2016-06-02 13:34:52 --> Router Class Initialized
INFO - 2016-06-02 13:34:52 --> Output Class Initialized
INFO - 2016-06-02 13:34:52 --> Security Class Initialized
DEBUG - 2016-06-02 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:34:52 --> CSRF cookie sent
INFO - 2016-06-02 13:34:52 --> Input Class Initialized
INFO - 2016-06-02 13:34:52 --> Language Class Initialized
INFO - 2016-06-02 13:34:52 --> Loader Class Initialized
INFO - 2016-06-02 13:34:52 --> Helper loaded: form_helper
INFO - 2016-06-02 13:34:52 --> Database Driver Class Initialized
INFO - 2016-06-02 13:34:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:34:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:34:52 --> Email Class Initialized
INFO - 2016-06-02 13:34:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:34:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:34:52 --> Helper loaded: language_helper
INFO - 2016-06-02 13:34:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:34:52 --> Model Class Initialized
INFO - 2016-06-02 13:34:52 --> Helper loaded: date_helper
INFO - 2016-06-02 13:34:52 --> Controller Class Initialized
INFO - 2016-06-02 13:34:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:34:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:34:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:34:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:34:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:34:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:34:52 --> Model Class Initialized
INFO - 2016-06-02 13:34:52 --> Form Validation Class Initialized
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:34:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:34:52 --> Final output sent to browser
DEBUG - 2016-06-02 13:34:52 --> Total execution time: 0.0780
INFO - 2016-06-02 13:34:56 --> Config Class Initialized
INFO - 2016-06-02 13:34:56 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:34:56 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:34:56 --> Utf8 Class Initialized
INFO - 2016-06-02 13:34:56 --> URI Class Initialized
INFO - 2016-06-02 13:34:56 --> Router Class Initialized
INFO - 2016-06-02 13:34:56 --> Output Class Initialized
INFO - 2016-06-02 13:34:56 --> Security Class Initialized
DEBUG - 2016-06-02 13:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:34:56 --> CSRF cookie sent
INFO - 2016-06-02 13:34:56 --> CSRF token verified
INFO - 2016-06-02 13:34:56 --> Input Class Initialized
INFO - 2016-06-02 13:34:56 --> Language Class Initialized
INFO - 2016-06-02 13:34:56 --> Loader Class Initialized
INFO - 2016-06-02 13:34:56 --> Helper loaded: form_helper
INFO - 2016-06-02 13:34:56 --> Database Driver Class Initialized
INFO - 2016-06-02 13:34:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:34:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:34:56 --> Email Class Initialized
INFO - 2016-06-02 13:34:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:34:56 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:34:56 --> Helper loaded: language_helper
INFO - 2016-06-02 13:34:56 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:34:56 --> Model Class Initialized
INFO - 2016-06-02 13:34:56 --> Helper loaded: date_helper
INFO - 2016-06-02 13:34:56 --> Controller Class Initialized
INFO - 2016-06-02 13:34:56 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:34:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:34:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:34:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:34:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:34:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:34:56 --> Model Class Initialized
INFO - 2016-06-02 13:34:56 --> Form Validation Class Initialized
INFO - 2016-06-02 13:34:56 --> Final output sent to browser
DEBUG - 2016-06-02 13:34:56 --> Total execution time: 0.0292
INFO - 2016-06-02 13:40:40 --> Config Class Initialized
INFO - 2016-06-02 13:40:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:40:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:40:40 --> Utf8 Class Initialized
INFO - 2016-06-02 13:40:40 --> URI Class Initialized
INFO - 2016-06-02 13:40:40 --> Router Class Initialized
INFO - 2016-06-02 13:40:40 --> Output Class Initialized
INFO - 2016-06-02 13:40:40 --> Security Class Initialized
DEBUG - 2016-06-02 13:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:40:40 --> CSRF cookie sent
INFO - 2016-06-02 13:40:40 --> Input Class Initialized
INFO - 2016-06-02 13:40:40 --> Language Class Initialized
INFO - 2016-06-02 13:40:40 --> Loader Class Initialized
INFO - 2016-06-02 13:40:40 --> Helper loaded: form_helper
INFO - 2016-06-02 13:40:40 --> Database Driver Class Initialized
INFO - 2016-06-02 13:40:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:40:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:40:40 --> Email Class Initialized
INFO - 2016-06-02 13:40:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:40:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:40:40 --> Helper loaded: language_helper
INFO - 2016-06-02 13:40:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:40:40 --> Model Class Initialized
INFO - 2016-06-02 13:40:40 --> Helper loaded: date_helper
INFO - 2016-06-02 13:40:40 --> Controller Class Initialized
INFO - 2016-06-02 13:40:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:40:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:40:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:40:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:40:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:40:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:40:40 --> Model Class Initialized
INFO - 2016-06-02 13:40:40 --> Form Validation Class Initialized
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:40:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:40:40 --> Final output sent to browser
DEBUG - 2016-06-02 13:40:40 --> Total execution time: 0.1027
INFO - 2016-06-02 13:41:05 --> Config Class Initialized
INFO - 2016-06-02 13:41:05 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:41:05 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:41:05 --> Utf8 Class Initialized
INFO - 2016-06-02 13:41:05 --> URI Class Initialized
INFO - 2016-06-02 13:41:05 --> Router Class Initialized
INFO - 2016-06-02 13:41:05 --> Output Class Initialized
INFO - 2016-06-02 13:41:05 --> Security Class Initialized
DEBUG - 2016-06-02 13:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:41:05 --> CSRF cookie sent
INFO - 2016-06-02 13:41:05 --> Input Class Initialized
INFO - 2016-06-02 13:41:05 --> Language Class Initialized
INFO - 2016-06-02 13:41:05 --> Loader Class Initialized
INFO - 2016-06-02 13:41:05 --> Helper loaded: form_helper
INFO - 2016-06-02 13:41:05 --> Database Driver Class Initialized
INFO - 2016-06-02 13:41:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:41:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:41:05 --> Email Class Initialized
INFO - 2016-06-02 13:41:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:41:05 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:41:05 --> Helper loaded: language_helper
INFO - 2016-06-02 13:41:05 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:41:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:41:05 --> Model Class Initialized
INFO - 2016-06-02 13:41:05 --> Helper loaded: date_helper
INFO - 2016-06-02 13:41:05 --> Controller Class Initialized
INFO - 2016-06-02 13:41:05 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:41:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:41:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:41:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:41:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:41:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:41:05 --> Model Class Initialized
INFO - 2016-06-02 13:41:05 --> Form Validation Class Initialized
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:41:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:41:05 --> Final output sent to browser
DEBUG - 2016-06-02 13:41:05 --> Total execution time: 0.0699
INFO - 2016-06-02 13:41:11 --> Config Class Initialized
INFO - 2016-06-02 13:41:11 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:41:11 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:41:11 --> Utf8 Class Initialized
INFO - 2016-06-02 13:41:11 --> URI Class Initialized
INFO - 2016-06-02 13:41:11 --> Router Class Initialized
INFO - 2016-06-02 13:41:11 --> Output Class Initialized
INFO - 2016-06-02 13:41:11 --> Security Class Initialized
DEBUG - 2016-06-02 13:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:41:11 --> CSRF cookie sent
INFO - 2016-06-02 13:41:11 --> CSRF token verified
INFO - 2016-06-02 13:41:11 --> Input Class Initialized
INFO - 2016-06-02 13:41:11 --> Language Class Initialized
INFO - 2016-06-02 13:41:11 --> Loader Class Initialized
INFO - 2016-06-02 13:41:11 --> Helper loaded: form_helper
INFO - 2016-06-02 13:41:11 --> Database Driver Class Initialized
INFO - 2016-06-02 13:41:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:41:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:41:11 --> Email Class Initialized
INFO - 2016-06-02 13:41:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:41:11 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:41:11 --> Helper loaded: language_helper
INFO - 2016-06-02 13:41:11 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:41:11 --> Model Class Initialized
INFO - 2016-06-02 13:41:11 --> Helper loaded: date_helper
INFO - 2016-06-02 13:41:11 --> Controller Class Initialized
INFO - 2016-06-02 13:41:11 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:41:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:41:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:41:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:41:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:41:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:41:11 --> Model Class Initialized
INFO - 2016-06-02 13:41:11 --> Form Validation Class Initialized
INFO - 2016-06-02 13:41:11 --> Final output sent to browser
DEBUG - 2016-06-02 13:41:11 --> Total execution time: 0.0631
INFO - 2016-06-02 13:41:18 --> Config Class Initialized
INFO - 2016-06-02 13:41:18 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:41:18 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:41:18 --> Utf8 Class Initialized
INFO - 2016-06-02 13:41:18 --> URI Class Initialized
INFO - 2016-06-02 13:41:18 --> Router Class Initialized
INFO - 2016-06-02 13:41:18 --> Output Class Initialized
INFO - 2016-06-02 13:41:18 --> Security Class Initialized
DEBUG - 2016-06-02 13:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:41:18 --> CSRF cookie sent
INFO - 2016-06-02 13:41:18 --> Input Class Initialized
INFO - 2016-06-02 13:41:18 --> Language Class Initialized
INFO - 2016-06-02 13:41:18 --> Loader Class Initialized
INFO - 2016-06-02 13:41:18 --> Helper loaded: form_helper
INFO - 2016-06-02 13:41:18 --> Database Driver Class Initialized
INFO - 2016-06-02 13:41:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:41:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:41:18 --> Email Class Initialized
INFO - 2016-06-02 13:41:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:41:18 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:41:18 --> Helper loaded: language_helper
INFO - 2016-06-02 13:41:18 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:41:18 --> Model Class Initialized
INFO - 2016-06-02 13:41:18 --> Helper loaded: date_helper
INFO - 2016-06-02 13:41:18 --> Controller Class Initialized
INFO - 2016-06-02 13:41:18 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:41:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:41:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:41:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:41:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:41:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:41:18 --> Model Class Initialized
INFO - 2016-06-02 13:41:18 --> Form Validation Class Initialized
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-02 13:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:41:18 --> Final output sent to browser
DEBUG - 2016-06-02 13:41:18 --> Total execution time: 0.3986
INFO - 2016-06-02 13:41:30 --> Config Class Initialized
INFO - 2016-06-02 13:41:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:41:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:41:30 --> Utf8 Class Initialized
INFO - 2016-06-02 13:41:30 --> URI Class Initialized
INFO - 2016-06-02 13:41:30 --> Router Class Initialized
INFO - 2016-06-02 13:41:30 --> Output Class Initialized
INFO - 2016-06-02 13:41:30 --> Security Class Initialized
DEBUG - 2016-06-02 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:41:30 --> CSRF cookie sent
INFO - 2016-06-02 13:41:30 --> Input Class Initialized
INFO - 2016-06-02 13:41:30 --> Language Class Initialized
INFO - 2016-06-02 13:41:30 --> Loader Class Initialized
INFO - 2016-06-02 13:41:30 --> Helper loaded: form_helper
INFO - 2016-06-02 13:41:30 --> Database Driver Class Initialized
INFO - 2016-06-02 13:41:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:41:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:41:30 --> Email Class Initialized
INFO - 2016-06-02 13:41:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:41:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:41:30 --> Helper loaded: language_helper
INFO - 2016-06-02 13:41:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:41:30 --> Model Class Initialized
INFO - 2016-06-02 13:41:30 --> Helper loaded: date_helper
INFO - 2016-06-02 13:41:30 --> Controller Class Initialized
INFO - 2016-06-02 13:41:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:41:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:41:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:41:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:41:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:41:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:41:30 --> Model Class Initialized
INFO - 2016-06-02 13:41:30 --> Form Validation Class Initialized
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_user_data.php
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:41:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:41:30 --> Final output sent to browser
DEBUG - 2016-06-02 13:41:30 --> Total execution time: 0.1057
INFO - 2016-06-02 13:41:33 --> Config Class Initialized
INFO - 2016-06-02 13:41:33 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:41:33 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:41:33 --> Utf8 Class Initialized
INFO - 2016-06-02 13:41:33 --> URI Class Initialized
INFO - 2016-06-02 13:41:33 --> Router Class Initialized
INFO - 2016-06-02 13:41:33 --> Output Class Initialized
INFO - 2016-06-02 13:41:33 --> Security Class Initialized
DEBUG - 2016-06-02 13:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:41:33 --> CSRF cookie sent
INFO - 2016-06-02 13:41:33 --> CSRF token verified
INFO - 2016-06-02 13:41:33 --> Input Class Initialized
INFO - 2016-06-02 13:41:33 --> Language Class Initialized
INFO - 2016-06-02 13:41:33 --> Loader Class Initialized
INFO - 2016-06-02 13:41:33 --> Helper loaded: form_helper
INFO - 2016-06-02 13:41:33 --> Database Driver Class Initialized
INFO - 2016-06-02 13:41:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:41:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:41:33 --> Email Class Initialized
INFO - 2016-06-02 13:41:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:41:33 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:41:33 --> Helper loaded: language_helper
INFO - 2016-06-02 13:41:33 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:41:33 --> Model Class Initialized
INFO - 2016-06-02 13:41:33 --> Helper loaded: date_helper
INFO - 2016-06-02 13:41:33 --> Controller Class Initialized
INFO - 2016-06-02 13:41:33 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:41:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:41:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:41:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:41:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:41:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:41:33 --> Model Class Initialized
INFO - 2016-06-02 13:41:33 --> Form Validation Class Initialized
INFO - 2016-06-02 13:41:33 --> Final output sent to browser
DEBUG - 2016-06-02 13:41:33 --> Total execution time: 0.0140
INFO - 2016-06-02 13:44:43 --> Config Class Initialized
INFO - 2016-06-02 13:44:43 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:44:43 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:44:43 --> Utf8 Class Initialized
INFO - 2016-06-02 13:44:43 --> URI Class Initialized
INFO - 2016-06-02 13:44:43 --> Router Class Initialized
INFO - 2016-06-02 13:44:43 --> Output Class Initialized
INFO - 2016-06-02 13:44:43 --> Security Class Initialized
DEBUG - 2016-06-02 13:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:44:43 --> CSRF cookie sent
INFO - 2016-06-02 13:44:43 --> Input Class Initialized
INFO - 2016-06-02 13:44:43 --> Language Class Initialized
INFO - 2016-06-02 13:44:43 --> Loader Class Initialized
INFO - 2016-06-02 13:44:43 --> Helper loaded: form_helper
INFO - 2016-06-02 13:44:43 --> Database Driver Class Initialized
INFO - 2016-06-02 13:44:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:44:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:44:43 --> Email Class Initialized
INFO - 2016-06-02 13:44:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:44:43 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:44:43 --> Helper loaded: language_helper
INFO - 2016-06-02 13:44:43 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:44:43 --> Model Class Initialized
INFO - 2016-06-02 13:44:43 --> Helper loaded: date_helper
INFO - 2016-06-02 13:44:43 --> Controller Class Initialized
INFO - 2016-06-02 13:44:43 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:44:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:44:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:44:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:44:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:44:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:44:43 --> Model Class Initialized
INFO - 2016-06-02 13:44:43 --> Form Validation Class Initialized
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-02 13:44:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:44:43 --> Final output sent to browser
DEBUG - 2016-06-02 13:44:43 --> Total execution time: 0.0781
INFO - 2016-06-02 13:44:55 --> Config Class Initialized
INFO - 2016-06-02 13:44:55 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:44:55 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:44:55 --> Utf8 Class Initialized
INFO - 2016-06-02 13:44:55 --> URI Class Initialized
INFO - 2016-06-02 13:44:55 --> Router Class Initialized
INFO - 2016-06-02 13:44:55 --> Output Class Initialized
INFO - 2016-06-02 13:44:55 --> Security Class Initialized
DEBUG - 2016-06-02 13:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:44:55 --> CSRF cookie sent
INFO - 2016-06-02 13:44:55 --> Input Class Initialized
INFO - 2016-06-02 13:44:55 --> Language Class Initialized
INFO - 2016-06-02 13:44:55 --> Loader Class Initialized
INFO - 2016-06-02 13:44:55 --> Helper loaded: form_helper
INFO - 2016-06-02 13:44:55 --> Database Driver Class Initialized
INFO - 2016-06-02 13:44:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:44:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:44:55 --> Email Class Initialized
INFO - 2016-06-02 13:44:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:44:55 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:44:55 --> Helper loaded: language_helper
INFO - 2016-06-02 13:44:55 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:44:55 --> Model Class Initialized
INFO - 2016-06-02 13:44:55 --> Helper loaded: date_helper
INFO - 2016-06-02 13:44:55 --> Controller Class Initialized
INFO - 2016-06-02 13:44:55 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:44:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:44:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:44:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:44:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:44:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:44:55 --> Model Class Initialized
INFO - 2016-06-02 13:44:55 --> Form Validation Class Initialized
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:44:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:44:55 --> Final output sent to browser
DEBUG - 2016-06-02 13:44:55 --> Total execution time: 0.0321
INFO - 2016-06-02 13:45:03 --> Config Class Initialized
INFO - 2016-06-02 13:45:03 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:45:03 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:45:03 --> Utf8 Class Initialized
INFO - 2016-06-02 13:45:03 --> URI Class Initialized
INFO - 2016-06-02 13:45:03 --> Router Class Initialized
INFO - 2016-06-02 13:45:03 --> Output Class Initialized
INFO - 2016-06-02 13:45:03 --> Security Class Initialized
DEBUG - 2016-06-02 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:45:03 --> CSRF cookie sent
INFO - 2016-06-02 13:45:03 --> CSRF token verified
INFO - 2016-06-02 13:45:03 --> Input Class Initialized
INFO - 2016-06-02 13:45:03 --> Language Class Initialized
INFO - 2016-06-02 13:45:03 --> Loader Class Initialized
INFO - 2016-06-02 13:45:03 --> Helper loaded: form_helper
INFO - 2016-06-02 13:45:03 --> Database Driver Class Initialized
INFO - 2016-06-02 13:45:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:45:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:45:03 --> Email Class Initialized
INFO - 2016-06-02 13:45:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:45:03 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:45:03 --> Helper loaded: language_helper
INFO - 2016-06-02 13:45:03 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:45:03 --> Model Class Initialized
INFO - 2016-06-02 13:45:03 --> Helper loaded: date_helper
INFO - 2016-06-02 13:45:03 --> Controller Class Initialized
INFO - 2016-06-02 13:45:03 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:45:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:45:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:45:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:45:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:45:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:45:03 --> Model Class Initialized
INFO - 2016-06-02 13:45:03 --> Form Validation Class Initialized
INFO - 2016-06-02 13:45:03 --> Final output sent to browser
DEBUG - 2016-06-02 13:45:03 --> Total execution time: 0.0494
INFO - 2016-06-02 13:45:30 --> Config Class Initialized
INFO - 2016-06-02 13:45:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:45:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:45:30 --> Utf8 Class Initialized
INFO - 2016-06-02 13:45:30 --> URI Class Initialized
INFO - 2016-06-02 13:45:30 --> Router Class Initialized
INFO - 2016-06-02 13:45:30 --> Output Class Initialized
INFO - 2016-06-02 13:45:30 --> Security Class Initialized
DEBUG - 2016-06-02 13:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:45:30 --> CSRF cookie sent
INFO - 2016-06-02 13:45:30 --> Input Class Initialized
INFO - 2016-06-02 13:45:30 --> Language Class Initialized
INFO - 2016-06-02 13:45:30 --> Loader Class Initialized
INFO - 2016-06-02 13:45:30 --> Helper loaded: form_helper
INFO - 2016-06-02 13:45:30 --> Database Driver Class Initialized
INFO - 2016-06-02 13:45:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:45:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:45:30 --> Email Class Initialized
INFO - 2016-06-02 13:45:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:45:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:45:30 --> Helper loaded: language_helper
INFO - 2016-06-02 13:45:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:45:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:45:30 --> Model Class Initialized
INFO - 2016-06-02 13:45:30 --> Helper loaded: date_helper
INFO - 2016-06-02 13:45:30 --> Controller Class Initialized
INFO - 2016-06-02 13:45:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:45:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:45:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:45:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:45:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:45:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:45:30 --> Model Class Initialized
INFO - 2016-06-02 13:45:30 --> Form Validation Class Initialized
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:45:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:45:30 --> Final output sent to browser
DEBUG - 2016-06-02 13:45:30 --> Total execution time: 0.0208
INFO - 2016-06-02 13:45:37 --> Config Class Initialized
INFO - 2016-06-02 13:45:37 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:45:37 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:45:37 --> Utf8 Class Initialized
INFO - 2016-06-02 13:45:37 --> URI Class Initialized
INFO - 2016-06-02 13:45:37 --> Router Class Initialized
INFO - 2016-06-02 13:45:37 --> Output Class Initialized
INFO - 2016-06-02 13:45:37 --> Security Class Initialized
DEBUG - 2016-06-02 13:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:45:37 --> CSRF cookie sent
INFO - 2016-06-02 13:45:37 --> CSRF token verified
INFO - 2016-06-02 13:45:37 --> Input Class Initialized
INFO - 2016-06-02 13:45:37 --> Language Class Initialized
INFO - 2016-06-02 13:45:37 --> Loader Class Initialized
INFO - 2016-06-02 13:45:37 --> Helper loaded: form_helper
INFO - 2016-06-02 13:45:37 --> Database Driver Class Initialized
INFO - 2016-06-02 13:45:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:45:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:45:37 --> Email Class Initialized
INFO - 2016-06-02 13:45:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:45:37 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:45:37 --> Helper loaded: language_helper
INFO - 2016-06-02 13:45:37 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:45:37 --> Model Class Initialized
INFO - 2016-06-02 13:45:37 --> Helper loaded: date_helper
INFO - 2016-06-02 13:45:37 --> Controller Class Initialized
INFO - 2016-06-02 13:45:37 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:45:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:45:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:45:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:45:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:45:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:45:37 --> Model Class Initialized
INFO - 2016-06-02 13:45:37 --> Form Validation Class Initialized
INFO - 2016-06-02 13:45:37 --> Final output sent to browser
DEBUG - 2016-06-02 13:45:37 --> Total execution time: 0.0180
INFO - 2016-06-02 13:45:40 --> Config Class Initialized
INFO - 2016-06-02 13:45:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:45:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:45:40 --> Utf8 Class Initialized
INFO - 2016-06-02 13:45:40 --> URI Class Initialized
INFO - 2016-06-02 13:45:40 --> Router Class Initialized
INFO - 2016-06-02 13:45:40 --> Output Class Initialized
INFO - 2016-06-02 13:45:40 --> Security Class Initialized
DEBUG - 2016-06-02 13:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:45:40 --> CSRF cookie sent
INFO - 2016-06-02 13:45:40 --> CSRF token verified
INFO - 2016-06-02 13:45:40 --> Input Class Initialized
INFO - 2016-06-02 13:45:40 --> Language Class Initialized
INFO - 2016-06-02 13:45:40 --> Loader Class Initialized
INFO - 2016-06-02 13:45:40 --> Helper loaded: form_helper
INFO - 2016-06-02 13:45:40 --> Database Driver Class Initialized
INFO - 2016-06-02 13:45:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:45:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:45:40 --> Email Class Initialized
INFO - 2016-06-02 13:45:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:45:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:45:40 --> Helper loaded: language_helper
INFO - 2016-06-02 13:45:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:45:40 --> Model Class Initialized
INFO - 2016-06-02 13:45:40 --> Helper loaded: date_helper
INFO - 2016-06-02 13:45:40 --> Controller Class Initialized
INFO - 2016-06-02 13:45:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:45:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:45:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:45:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:45:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:45:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:45:40 --> Model Class Initialized
INFO - 2016-06-02 13:45:40 --> Form Validation Class Initialized
INFO - 2016-06-02 13:54:27 --> Config Class Initialized
INFO - 2016-06-02 13:54:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:54:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:54:27 --> Utf8 Class Initialized
INFO - 2016-06-02 13:54:27 --> URI Class Initialized
INFO - 2016-06-02 13:54:27 --> Router Class Initialized
INFO - 2016-06-02 13:54:27 --> Output Class Initialized
INFO - 2016-06-02 13:54:27 --> Security Class Initialized
DEBUG - 2016-06-02 13:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:54:27 --> CSRF cookie sent
INFO - 2016-06-02 13:54:27 --> CSRF token verified
INFO - 2016-06-02 13:54:27 --> Input Class Initialized
INFO - 2016-06-02 13:54:27 --> Language Class Initialized
INFO - 2016-06-02 13:54:27 --> Loader Class Initialized
INFO - 2016-06-02 13:54:27 --> Helper loaded: form_helper
INFO - 2016-06-02 13:54:27 --> Database Driver Class Initialized
INFO - 2016-06-02 13:54:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:54:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:54:27 --> Email Class Initialized
INFO - 2016-06-02 13:54:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:54:27 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:54:27 --> Helper loaded: language_helper
INFO - 2016-06-02 13:54:27 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:54:27 --> Model Class Initialized
INFO - 2016-06-02 13:54:27 --> Helper loaded: date_helper
INFO - 2016-06-02 13:54:27 --> Controller Class Initialized
INFO - 2016-06-02 13:54:27 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:54:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:54:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:54:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:54:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:54:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:54:27 --> Model Class Initialized
INFO - 2016-06-02 13:54:27 --> Form Validation Class Initialized
INFO - 2016-06-02 13:55:10 --> Config Class Initialized
INFO - 2016-06-02 13:55:10 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:55:10 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:55:10 --> Utf8 Class Initialized
INFO - 2016-06-02 13:55:10 --> URI Class Initialized
INFO - 2016-06-02 13:55:10 --> Router Class Initialized
INFO - 2016-06-02 13:55:10 --> Output Class Initialized
INFO - 2016-06-02 13:55:10 --> Security Class Initialized
DEBUG - 2016-06-02 13:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:55:10 --> CSRF cookie sent
INFO - 2016-06-02 13:55:10 --> CSRF token verified
INFO - 2016-06-02 13:55:10 --> Input Class Initialized
INFO - 2016-06-02 13:55:10 --> Language Class Initialized
INFO - 2016-06-02 13:55:10 --> Loader Class Initialized
INFO - 2016-06-02 13:55:10 --> Helper loaded: form_helper
INFO - 2016-06-02 13:55:10 --> Database Driver Class Initialized
INFO - 2016-06-02 13:55:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:55:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:55:10 --> Email Class Initialized
INFO - 2016-06-02 13:55:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:55:10 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:55:10 --> Helper loaded: language_helper
INFO - 2016-06-02 13:55:10 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:55:10 --> Model Class Initialized
INFO - 2016-06-02 13:55:10 --> Helper loaded: date_helper
INFO - 2016-06-02 13:55:10 --> Controller Class Initialized
INFO - 2016-06-02 13:55:10 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:55:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:55:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:55:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:55:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:55:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:55:10 --> Model Class Initialized
INFO - 2016-06-02 13:55:10 --> Form Validation Class Initialized
INFO - 2016-06-02 13:56:06 --> Config Class Initialized
INFO - 2016-06-02 13:56:06 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:56:06 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:56:06 --> Utf8 Class Initialized
INFO - 2016-06-02 13:56:06 --> URI Class Initialized
INFO - 2016-06-02 13:56:06 --> Router Class Initialized
INFO - 2016-06-02 13:56:06 --> Output Class Initialized
INFO - 2016-06-02 13:56:06 --> Security Class Initialized
DEBUG - 2016-06-02 13:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:56:06 --> CSRF cookie sent
INFO - 2016-06-02 13:56:06 --> CSRF token verified
INFO - 2016-06-02 13:56:06 --> Input Class Initialized
INFO - 2016-06-02 13:56:06 --> Language Class Initialized
INFO - 2016-06-02 13:56:06 --> Loader Class Initialized
INFO - 2016-06-02 13:56:06 --> Helper loaded: form_helper
INFO - 2016-06-02 13:56:06 --> Database Driver Class Initialized
INFO - 2016-06-02 13:56:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:56:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:56:06 --> Email Class Initialized
INFO - 2016-06-02 13:56:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:56:06 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:56:06 --> Helper loaded: language_helper
INFO - 2016-06-02 13:56:06 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:56:06 --> Model Class Initialized
INFO - 2016-06-02 13:56:06 --> Helper loaded: date_helper
INFO - 2016-06-02 13:56:06 --> Controller Class Initialized
INFO - 2016-06-02 13:56:06 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:56:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:56:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:56:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:56:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:56:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:56:06 --> Model Class Initialized
INFO - 2016-06-02 13:56:06 --> Form Validation Class Initialized
ERROR - 2016-06-02 13:56:06 --> Severity: Warning --> date() expects at least 1 parameter, 0 given /home/demis/www/platformadiabet/application/controllers/Diabet.php 376
INFO - 2016-06-02 13:56:52 --> Config Class Initialized
INFO - 2016-06-02 13:56:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:56:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:56:52 --> Utf8 Class Initialized
INFO - 2016-06-02 13:56:52 --> URI Class Initialized
INFO - 2016-06-02 13:56:52 --> Router Class Initialized
INFO - 2016-06-02 13:56:52 --> Output Class Initialized
INFO - 2016-06-02 13:56:52 --> Security Class Initialized
DEBUG - 2016-06-02 13:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:56:52 --> CSRF cookie sent
INFO - 2016-06-02 13:56:52 --> CSRF token verified
INFO - 2016-06-02 13:56:52 --> Input Class Initialized
INFO - 2016-06-02 13:56:52 --> Language Class Initialized
INFO - 2016-06-02 13:56:52 --> Loader Class Initialized
INFO - 2016-06-02 13:56:52 --> Helper loaded: form_helper
INFO - 2016-06-02 13:56:52 --> Database Driver Class Initialized
INFO - 2016-06-02 13:56:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:56:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:56:52 --> Email Class Initialized
INFO - 2016-06-02 13:56:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:56:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:56:52 --> Helper loaded: language_helper
INFO - 2016-06-02 13:56:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:56:52 --> Model Class Initialized
INFO - 2016-06-02 13:56:52 --> Helper loaded: date_helper
INFO - 2016-06-02 13:56:52 --> Controller Class Initialized
INFO - 2016-06-02 13:56:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:56:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:56:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:56:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:56:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:56:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:56:52 --> Model Class Initialized
INFO - 2016-06-02 13:56:52 --> Form Validation Class Initialized
INFO - 2016-06-02 13:57:37 --> Config Class Initialized
INFO - 2016-06-02 13:57:37 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:57:37 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:57:37 --> Utf8 Class Initialized
INFO - 2016-06-02 13:57:37 --> URI Class Initialized
INFO - 2016-06-02 13:57:37 --> Router Class Initialized
INFO - 2016-06-02 13:57:37 --> Output Class Initialized
INFO - 2016-06-02 13:57:37 --> Security Class Initialized
DEBUG - 2016-06-02 13:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:57:37 --> CSRF cookie sent
INFO - 2016-06-02 13:57:37 --> CSRF token verified
INFO - 2016-06-02 13:57:37 --> Input Class Initialized
INFO - 2016-06-02 13:57:37 --> Language Class Initialized
INFO - 2016-06-02 13:57:37 --> Loader Class Initialized
INFO - 2016-06-02 13:57:37 --> Helper loaded: form_helper
INFO - 2016-06-02 13:57:37 --> Database Driver Class Initialized
INFO - 2016-06-02 13:57:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:57:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:57:37 --> Email Class Initialized
INFO - 2016-06-02 13:57:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:57:37 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:57:37 --> Helper loaded: language_helper
INFO - 2016-06-02 13:57:37 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:57:37 --> Model Class Initialized
INFO - 2016-06-02 13:57:37 --> Helper loaded: date_helper
INFO - 2016-06-02 13:57:37 --> Controller Class Initialized
INFO - 2016-06-02 13:57:37 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:57:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:57:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:57:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:57:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:57:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:57:37 --> Model Class Initialized
INFO - 2016-06-02 13:57:37 --> Form Validation Class Initialized
INFO - 2016-06-02 13:58:04 --> Config Class Initialized
INFO - 2016-06-02 13:58:04 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:58:04 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:58:04 --> Utf8 Class Initialized
INFO - 2016-06-02 13:58:04 --> URI Class Initialized
INFO - 2016-06-02 13:58:04 --> Router Class Initialized
INFO - 2016-06-02 13:58:04 --> Output Class Initialized
INFO - 2016-06-02 13:58:04 --> Security Class Initialized
DEBUG - 2016-06-02 13:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:58:04 --> CSRF cookie sent
INFO - 2016-06-02 13:58:04 --> CSRF token verified
INFO - 2016-06-02 13:58:04 --> Input Class Initialized
INFO - 2016-06-02 13:58:04 --> Language Class Initialized
INFO - 2016-06-02 13:58:04 --> Loader Class Initialized
INFO - 2016-06-02 13:58:04 --> Helper loaded: form_helper
INFO - 2016-06-02 13:58:04 --> Database Driver Class Initialized
INFO - 2016-06-02 13:58:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:58:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:58:04 --> Email Class Initialized
INFO - 2016-06-02 13:58:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:58:04 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:58:04 --> Helper loaded: language_helper
INFO - 2016-06-02 13:58:04 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:58:04 --> Model Class Initialized
INFO - 2016-06-02 13:58:04 --> Helper loaded: date_helper
INFO - 2016-06-02 13:58:04 --> Controller Class Initialized
INFO - 2016-06-02 13:58:04 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:58:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:58:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:58:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:58:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:58:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:58:04 --> Model Class Initialized
INFO - 2016-06-02 13:58:04 --> Form Validation Class Initialized
INFO - 2016-06-02 13:58:45 --> Config Class Initialized
INFO - 2016-06-02 13:58:45 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:58:45 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:58:45 --> Utf8 Class Initialized
INFO - 2016-06-02 13:58:45 --> URI Class Initialized
INFO - 2016-06-02 13:58:45 --> Router Class Initialized
INFO - 2016-06-02 13:58:45 --> Output Class Initialized
INFO - 2016-06-02 13:58:45 --> Security Class Initialized
DEBUG - 2016-06-02 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:58:45 --> CSRF cookie sent
INFO - 2016-06-02 13:58:45 --> Input Class Initialized
INFO - 2016-06-02 13:58:45 --> Language Class Initialized
INFO - 2016-06-02 13:58:45 --> Loader Class Initialized
INFO - 2016-06-02 13:58:45 --> Helper loaded: form_helper
INFO - 2016-06-02 13:58:45 --> Database Driver Class Initialized
INFO - 2016-06-02 13:58:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:58:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:58:45 --> Email Class Initialized
INFO - 2016-06-02 13:58:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:58:45 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:58:45 --> Helper loaded: language_helper
INFO - 2016-06-02 13:58:45 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:58:45 --> Model Class Initialized
INFO - 2016-06-02 13:58:45 --> Helper loaded: date_helper
INFO - 2016-06-02 13:58:45 --> Controller Class Initialized
INFO - 2016-06-02 13:58:45 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:58:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:58:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:58:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:58:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:58:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:58:45 --> Model Class Initialized
INFO - 2016-06-02 13:58:45 --> Form Validation Class Initialized
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 13:58:45 --> Final output sent to browser
DEBUG - 2016-06-02 13:58:45 --> Total execution time: 0.0260
INFO - 2016-06-02 13:58:50 --> Config Class Initialized
INFO - 2016-06-02 13:58:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:58:50 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:58:50 --> Utf8 Class Initialized
INFO - 2016-06-02 13:58:50 --> URI Class Initialized
INFO - 2016-06-02 13:58:50 --> Router Class Initialized
INFO - 2016-06-02 13:58:50 --> Output Class Initialized
INFO - 2016-06-02 13:58:50 --> Security Class Initialized
DEBUG - 2016-06-02 13:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:58:50 --> CSRF cookie sent
INFO - 2016-06-02 13:58:50 --> CSRF token verified
INFO - 2016-06-02 13:58:50 --> Input Class Initialized
INFO - 2016-06-02 13:58:50 --> Language Class Initialized
INFO - 2016-06-02 13:58:50 --> Loader Class Initialized
INFO - 2016-06-02 13:58:50 --> Helper loaded: form_helper
INFO - 2016-06-02 13:58:50 --> Database Driver Class Initialized
INFO - 2016-06-02 13:58:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:58:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:58:50 --> Email Class Initialized
INFO - 2016-06-02 13:58:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:58:50 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:58:50 --> Helper loaded: language_helper
INFO - 2016-06-02 13:58:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:58:50 --> Model Class Initialized
INFO - 2016-06-02 13:58:50 --> Helper loaded: date_helper
INFO - 2016-06-02 13:58:50 --> Controller Class Initialized
INFO - 2016-06-02 13:58:50 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:58:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:58:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:58:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:58:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:58:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:58:50 --> Model Class Initialized
INFO - 2016-06-02 13:58:50 --> Form Validation Class Initialized
INFO - 2016-06-02 13:58:52 --> Config Class Initialized
INFO - 2016-06-02 13:58:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:58:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:58:52 --> Utf8 Class Initialized
INFO - 2016-06-02 13:58:52 --> URI Class Initialized
INFO - 2016-06-02 13:58:52 --> Router Class Initialized
INFO - 2016-06-02 13:58:52 --> Output Class Initialized
INFO - 2016-06-02 13:58:52 --> Security Class Initialized
DEBUG - 2016-06-02 13:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:58:52 --> CSRF cookie sent
INFO - 2016-06-02 13:58:52 --> CSRF token verified
INFO - 2016-06-02 13:58:52 --> Input Class Initialized
INFO - 2016-06-02 13:58:52 --> Language Class Initialized
INFO - 2016-06-02 13:58:52 --> Loader Class Initialized
INFO - 2016-06-02 13:58:52 --> Helper loaded: form_helper
INFO - 2016-06-02 13:58:52 --> Database Driver Class Initialized
INFO - 2016-06-02 13:58:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:58:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:58:52 --> Email Class Initialized
INFO - 2016-06-02 13:58:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:58:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:58:52 --> Helper loaded: language_helper
INFO - 2016-06-02 13:58:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:58:52 --> Model Class Initialized
INFO - 2016-06-02 13:58:52 --> Helper loaded: date_helper
INFO - 2016-06-02 13:58:52 --> Controller Class Initialized
INFO - 2016-06-02 13:58:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:58:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:58:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:58:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:58:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:58:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:58:52 --> Model Class Initialized
INFO - 2016-06-02 13:58:52 --> Form Validation Class Initialized
INFO - 2016-06-02 13:58:52 --> Final output sent to browser
DEBUG - 2016-06-02 13:58:52 --> Total execution time: 0.0438
INFO - 2016-06-02 13:59:40 --> Config Class Initialized
INFO - 2016-06-02 13:59:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 13:59:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 13:59:40 --> Utf8 Class Initialized
INFO - 2016-06-02 13:59:40 --> URI Class Initialized
INFO - 2016-06-02 13:59:40 --> Router Class Initialized
INFO - 2016-06-02 13:59:40 --> Output Class Initialized
INFO - 2016-06-02 13:59:40 --> Security Class Initialized
DEBUG - 2016-06-02 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 13:59:40 --> CSRF cookie sent
INFO - 2016-06-02 13:59:40 --> CSRF token verified
INFO - 2016-06-02 13:59:40 --> Input Class Initialized
INFO - 2016-06-02 13:59:40 --> Language Class Initialized
INFO - 2016-06-02 13:59:40 --> Loader Class Initialized
INFO - 2016-06-02 13:59:40 --> Helper loaded: form_helper
INFO - 2016-06-02 13:59:40 --> Database Driver Class Initialized
INFO - 2016-06-02 13:59:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 13:59:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 13:59:40 --> Email Class Initialized
INFO - 2016-06-02 13:59:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 13:59:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 13:59:40 --> Helper loaded: language_helper
INFO - 2016-06-02 13:59:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 13:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 13:59:40 --> Model Class Initialized
INFO - 2016-06-02 13:59:40 --> Helper loaded: date_helper
INFO - 2016-06-02 13:59:40 --> Controller Class Initialized
INFO - 2016-06-02 13:59:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 13:59:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 13:59:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 13:59:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 13:59:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 13:59:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 13:59:40 --> Model Class Initialized
INFO - 2016-06-02 13:59:40 --> Form Validation Class Initialized
ERROR - 2016-06-02 13:59:40 --> Severity: Error --> Call to a member function field_data() on array /home/demis/www/platformadiabet/application/libraries/Excel.php 10
INFO - 2016-06-02 14:03:08 --> Config Class Initialized
INFO - 2016-06-02 14:03:08 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:03:08 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:03:08 --> Utf8 Class Initialized
INFO - 2016-06-02 14:03:08 --> URI Class Initialized
INFO - 2016-06-02 14:03:08 --> Router Class Initialized
INFO - 2016-06-02 14:03:08 --> Output Class Initialized
INFO - 2016-06-02 14:03:08 --> Security Class Initialized
DEBUG - 2016-06-02 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:03:08 --> CSRF cookie sent
INFO - 2016-06-02 14:03:08 --> CSRF token verified
INFO - 2016-06-02 14:03:08 --> Input Class Initialized
INFO - 2016-06-02 14:03:08 --> Language Class Initialized
INFO - 2016-06-02 14:03:08 --> Loader Class Initialized
INFO - 2016-06-02 14:03:08 --> Helper loaded: form_helper
INFO - 2016-06-02 14:03:08 --> Database Driver Class Initialized
INFO - 2016-06-02 14:03:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:03:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:03:08 --> Email Class Initialized
INFO - 2016-06-02 14:03:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:03:08 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:03:08 --> Helper loaded: language_helper
INFO - 2016-06-02 14:03:08 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:03:08 --> Model Class Initialized
INFO - 2016-06-02 14:03:08 --> Helper loaded: date_helper
INFO - 2016-06-02 14:03:08 --> Controller Class Initialized
INFO - 2016-06-02 14:03:08 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:03:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:03:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:03:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:03:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:03:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:03:08 --> Model Class Initialized
INFO - 2016-06-02 14:03:08 --> Form Validation Class Initialized
ERROR - 2016-06-02 14:03:08 --> Severity: Warning --> Missing argument 2 for Excel::make_from_array(), called in /home/demis/www/platformadiabet/application/controllers/Diabet.php on line 377 and defined /home/demis/www/platformadiabet/application/libraries/Excel.php 38
ERROR - 2016-06-02 14:03:08 --> Severity: Notice --> Undefined variable: array /home/demis/www/platformadiabet/application/libraries/Excel.php 41
INFO - 2016-06-02 14:05:55 --> Config Class Initialized
INFO - 2016-06-02 14:05:55 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:05:55 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:05:55 --> Utf8 Class Initialized
INFO - 2016-06-02 14:05:55 --> URI Class Initialized
INFO - 2016-06-02 14:05:55 --> Router Class Initialized
INFO - 2016-06-02 14:05:55 --> Output Class Initialized
INFO - 2016-06-02 14:05:55 --> Security Class Initialized
DEBUG - 2016-06-02 14:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:05:55 --> CSRF cookie sent
INFO - 2016-06-02 14:05:55 --> CSRF token verified
INFO - 2016-06-02 14:05:55 --> Input Class Initialized
INFO - 2016-06-02 14:05:55 --> Language Class Initialized
INFO - 2016-06-02 14:05:55 --> Loader Class Initialized
INFO - 2016-06-02 14:05:55 --> Helper loaded: form_helper
INFO - 2016-06-02 14:05:55 --> Database Driver Class Initialized
INFO - 2016-06-02 14:05:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:05:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:05:56 --> Email Class Initialized
INFO - 2016-06-02 14:05:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:05:56 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:05:56 --> Helper loaded: language_helper
INFO - 2016-06-02 14:05:56 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:05:56 --> Model Class Initialized
INFO - 2016-06-02 14:05:56 --> Helper loaded: date_helper
INFO - 2016-06-02 14:05:56 --> Controller Class Initialized
INFO - 2016-06-02 14:05:56 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:05:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:05:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:05:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:05:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:05:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:05:56 --> Model Class Initialized
INFO - 2016-06-02 14:05:56 --> Form Validation Class Initialized
INFO - 2016-06-02 14:09:35 --> Config Class Initialized
INFO - 2016-06-02 14:09:35 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:09:35 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:09:35 --> Utf8 Class Initialized
INFO - 2016-06-02 14:09:35 --> URI Class Initialized
INFO - 2016-06-02 14:09:35 --> Router Class Initialized
INFO - 2016-06-02 14:09:35 --> Output Class Initialized
INFO - 2016-06-02 14:09:35 --> Security Class Initialized
DEBUG - 2016-06-02 14:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:09:35 --> CSRF cookie sent
INFO - 2016-06-02 14:09:35 --> CSRF token verified
INFO - 2016-06-02 14:09:35 --> Input Class Initialized
INFO - 2016-06-02 14:09:35 --> Language Class Initialized
INFO - 2016-06-02 14:09:35 --> Loader Class Initialized
INFO - 2016-06-02 14:09:35 --> Helper loaded: form_helper
INFO - 2016-06-02 14:09:35 --> Database Driver Class Initialized
INFO - 2016-06-02 14:09:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:09:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:09:35 --> Email Class Initialized
INFO - 2016-06-02 14:09:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:09:35 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:09:35 --> Helper loaded: language_helper
INFO - 2016-06-02 14:09:35 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:09:35 --> Model Class Initialized
INFO - 2016-06-02 14:09:35 --> Helper loaded: date_helper
INFO - 2016-06-02 14:09:35 --> Controller Class Initialized
INFO - 2016-06-02 14:09:35 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:09:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:09:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:09:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:09:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:09:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:09:35 --> Model Class Initialized
INFO - 2016-06-02 14:09:35 --> Form Validation Class Initialized
ERROR - 2016-06-02 14:09:35 --> Severity: Error --> Cannot use object of type stdClass as array /home/demis/www/platformadiabet/application/controllers/Diabet.php 376
INFO - 2016-06-02 14:10:22 --> Config Class Initialized
INFO - 2016-06-02 14:10:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:10:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:10:22 --> Utf8 Class Initialized
INFO - 2016-06-02 14:10:22 --> URI Class Initialized
INFO - 2016-06-02 14:10:22 --> Router Class Initialized
INFO - 2016-06-02 14:10:22 --> Output Class Initialized
INFO - 2016-06-02 14:10:22 --> Security Class Initialized
DEBUG - 2016-06-02 14:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:10:22 --> CSRF cookie sent
INFO - 2016-06-02 14:10:22 --> Input Class Initialized
INFO - 2016-06-02 14:10:22 --> Language Class Initialized
INFO - 2016-06-02 14:10:22 --> Loader Class Initialized
INFO - 2016-06-02 14:10:22 --> Helper loaded: form_helper
INFO - 2016-06-02 14:10:22 --> Database Driver Class Initialized
INFO - 2016-06-02 14:10:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:10:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:10:22 --> Email Class Initialized
INFO - 2016-06-02 14:10:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:10:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:10:22 --> Helper loaded: language_helper
INFO - 2016-06-02 14:10:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:10:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:10:22 --> Model Class Initialized
INFO - 2016-06-02 14:10:22 --> Helper loaded: date_helper
INFO - 2016-06-02 14:10:22 --> Controller Class Initialized
INFO - 2016-06-02 14:10:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:10:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:10:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:10:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:10:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:10:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:10:22 --> Model Class Initialized
INFO - 2016-06-02 14:10:22 --> Form Validation Class Initialized
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 14:10:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 14:10:22 --> Final output sent to browser
DEBUG - 2016-06-02 14:10:22 --> Total execution time: 0.0362
INFO - 2016-06-02 14:10:29 --> Config Class Initialized
INFO - 2016-06-02 14:10:29 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:10:29 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:10:29 --> Utf8 Class Initialized
INFO - 2016-06-02 14:10:29 --> URI Class Initialized
INFO - 2016-06-02 14:10:29 --> Router Class Initialized
INFO - 2016-06-02 14:10:29 --> Output Class Initialized
INFO - 2016-06-02 14:10:29 --> Security Class Initialized
DEBUG - 2016-06-02 14:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:10:29 --> CSRF cookie sent
INFO - 2016-06-02 14:10:29 --> CSRF token verified
INFO - 2016-06-02 14:10:29 --> Input Class Initialized
INFO - 2016-06-02 14:10:29 --> Language Class Initialized
INFO - 2016-06-02 14:10:29 --> Loader Class Initialized
INFO - 2016-06-02 14:10:29 --> Helper loaded: form_helper
INFO - 2016-06-02 14:10:29 --> Database Driver Class Initialized
INFO - 2016-06-02 14:10:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:10:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:10:29 --> Email Class Initialized
INFO - 2016-06-02 14:10:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:10:29 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:10:29 --> Helper loaded: language_helper
INFO - 2016-06-02 14:10:29 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:10:29 --> Model Class Initialized
INFO - 2016-06-02 14:10:29 --> Helper loaded: date_helper
INFO - 2016-06-02 14:10:29 --> Controller Class Initialized
INFO - 2016-06-02 14:10:29 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:10:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:10:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:10:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:10:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:10:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:10:29 --> Model Class Initialized
INFO - 2016-06-02 14:10:29 --> Form Validation Class Initialized
INFO - 2016-06-02 14:10:29 --> Final output sent to browser
DEBUG - 2016-06-02 14:10:29 --> Total execution time: 0.0163
INFO - 2016-06-02 14:10:31 --> Config Class Initialized
INFO - 2016-06-02 14:10:31 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:10:31 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:10:31 --> Utf8 Class Initialized
INFO - 2016-06-02 14:10:31 --> URI Class Initialized
INFO - 2016-06-02 14:10:31 --> Router Class Initialized
INFO - 2016-06-02 14:10:31 --> Output Class Initialized
INFO - 2016-06-02 14:10:31 --> Security Class Initialized
DEBUG - 2016-06-02 14:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:10:31 --> CSRF cookie sent
INFO - 2016-06-02 14:10:31 --> CSRF token verified
INFO - 2016-06-02 14:10:31 --> Input Class Initialized
INFO - 2016-06-02 14:10:31 --> Language Class Initialized
INFO - 2016-06-02 14:10:31 --> Loader Class Initialized
INFO - 2016-06-02 14:10:31 --> Helper loaded: form_helper
INFO - 2016-06-02 14:10:31 --> Database Driver Class Initialized
INFO - 2016-06-02 14:10:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:10:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:10:31 --> Email Class Initialized
INFO - 2016-06-02 14:10:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:10:31 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:10:31 --> Helper loaded: language_helper
INFO - 2016-06-02 14:10:31 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:10:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:10:31 --> Model Class Initialized
INFO - 2016-06-02 14:10:31 --> Helper loaded: date_helper
INFO - 2016-06-02 14:10:31 --> Controller Class Initialized
INFO - 2016-06-02 14:10:31 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:10:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:10:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:10:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:10:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:10:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:10:31 --> Model Class Initialized
INFO - 2016-06-02 14:10:31 --> Form Validation Class Initialized
INFO - 2016-06-02 14:13:36 --> Config Class Initialized
INFO - 2016-06-02 14:13:36 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:13:36 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:13:36 --> Utf8 Class Initialized
INFO - 2016-06-02 14:13:36 --> URI Class Initialized
INFO - 2016-06-02 14:13:36 --> Router Class Initialized
INFO - 2016-06-02 14:13:36 --> Output Class Initialized
INFO - 2016-06-02 14:13:36 --> Security Class Initialized
DEBUG - 2016-06-02 14:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:13:36 --> CSRF cookie sent
INFO - 2016-06-02 14:13:36 --> CSRF token verified
INFO - 2016-06-02 14:13:36 --> Input Class Initialized
INFO - 2016-06-02 14:13:36 --> Language Class Initialized
INFO - 2016-06-02 14:13:36 --> Loader Class Initialized
INFO - 2016-06-02 14:13:36 --> Helper loaded: form_helper
INFO - 2016-06-02 14:13:36 --> Database Driver Class Initialized
INFO - 2016-06-02 14:13:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:13:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:13:36 --> Email Class Initialized
INFO - 2016-06-02 14:13:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:13:36 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:13:36 --> Helper loaded: language_helper
INFO - 2016-06-02 14:13:36 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:13:36 --> Model Class Initialized
INFO - 2016-06-02 14:13:36 --> Helper loaded: date_helper
INFO - 2016-06-02 14:13:36 --> Controller Class Initialized
INFO - 2016-06-02 14:13:36 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:13:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:13:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:13:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:13:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:13:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:13:36 --> Model Class Initialized
INFO - 2016-06-02 14:13:36 --> Form Validation Class Initialized
ERROR - 2016-06-02 14:13:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM 
                1_glicemie 
            WHERE 
                `fk_user` =' at line 13 - Invalid query: 
            SELECT 
                `date`,
                `interval_1`,
                `interval_2`,
                `interval_3`,
                `interval_4`,
                `interval_5`,
                `interval_6`,
                `interval_7`,
                `interval_8`,
                `interval_9`,
                `interval_10`,           
            FROM 
                1_glicemie 
            WHERE 
                `fk_user` = 2.
            AND 
                DATE(`date`) > (NOW() - INTERVAL 7 DAY)
            LIMIT
                7
            
        
INFO - 2016-06-02 14:14:13 --> Config Class Initialized
INFO - 2016-06-02 14:14:13 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:14:13 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:14:13 --> Utf8 Class Initialized
INFO - 2016-06-02 14:14:13 --> URI Class Initialized
INFO - 2016-06-02 14:14:13 --> Router Class Initialized
INFO - 2016-06-02 14:14:13 --> Output Class Initialized
INFO - 2016-06-02 14:14:13 --> Security Class Initialized
DEBUG - 2016-06-02 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:14:13 --> CSRF cookie sent
INFO - 2016-06-02 14:14:13 --> CSRF token verified
INFO - 2016-06-02 14:14:13 --> Input Class Initialized
INFO - 2016-06-02 14:14:13 --> Language Class Initialized
INFO - 2016-06-02 14:14:13 --> Loader Class Initialized
INFO - 2016-06-02 14:14:13 --> Helper loaded: form_helper
INFO - 2016-06-02 14:14:13 --> Database Driver Class Initialized
INFO - 2016-06-02 14:14:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:14:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:14:13 --> Email Class Initialized
INFO - 2016-06-02 14:14:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:14:13 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:14:13 --> Helper loaded: language_helper
INFO - 2016-06-02 14:14:13 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:14:13 --> Model Class Initialized
INFO - 2016-06-02 14:14:13 --> Helper loaded: date_helper
INFO - 2016-06-02 14:14:13 --> Controller Class Initialized
INFO - 2016-06-02 14:14:13 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:14:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:14:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:14:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:14:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:14:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:14:13 --> Model Class Initialized
INFO - 2016-06-02 14:14:13 --> Form Validation Class Initialized
ERROR - 2016-06-02 14:14:13 --> Severity: Error --> Cannot use object of type stdClass as array /home/demis/www/platformadiabet/application/controllers/Diabet.php 373
INFO - 2016-06-02 14:14:30 --> Config Class Initialized
INFO - 2016-06-02 14:14:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:14:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:14:30 --> Utf8 Class Initialized
INFO - 2016-06-02 14:14:30 --> URI Class Initialized
INFO - 2016-06-02 14:14:30 --> Router Class Initialized
INFO - 2016-06-02 14:14:30 --> Output Class Initialized
INFO - 2016-06-02 14:14:30 --> Security Class Initialized
DEBUG - 2016-06-02 14:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:14:30 --> CSRF cookie sent
INFO - 2016-06-02 14:14:30 --> CSRF token verified
INFO - 2016-06-02 14:14:30 --> Input Class Initialized
INFO - 2016-06-02 14:14:30 --> Language Class Initialized
INFO - 2016-06-02 14:14:30 --> Loader Class Initialized
INFO - 2016-06-02 14:14:30 --> Helper loaded: form_helper
INFO - 2016-06-02 14:14:30 --> Database Driver Class Initialized
INFO - 2016-06-02 14:14:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:14:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:14:30 --> Email Class Initialized
INFO - 2016-06-02 14:14:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:14:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:14:30 --> Helper loaded: language_helper
INFO - 2016-06-02 14:14:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:14:30 --> Model Class Initialized
INFO - 2016-06-02 14:14:30 --> Helper loaded: date_helper
INFO - 2016-06-02 14:14:30 --> Controller Class Initialized
INFO - 2016-06-02 14:14:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:14:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:14:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:14:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:14:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:14:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:14:30 --> Model Class Initialized
INFO - 2016-06-02 14:14:30 --> Form Validation Class Initialized
INFO - 2016-06-02 14:14:58 --> Config Class Initialized
INFO - 2016-06-02 14:14:58 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:14:58 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:14:58 --> Utf8 Class Initialized
INFO - 2016-06-02 14:14:58 --> URI Class Initialized
INFO - 2016-06-02 14:14:58 --> Router Class Initialized
INFO - 2016-06-02 14:14:58 --> Output Class Initialized
INFO - 2016-06-02 14:14:58 --> Security Class Initialized
DEBUG - 2016-06-02 14:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:14:58 --> CSRF cookie sent
INFO - 2016-06-02 14:14:58 --> CSRF token verified
INFO - 2016-06-02 14:14:58 --> Input Class Initialized
INFO - 2016-06-02 14:14:58 --> Language Class Initialized
INFO - 2016-06-02 14:14:58 --> Loader Class Initialized
INFO - 2016-06-02 14:14:58 --> Helper loaded: form_helper
INFO - 2016-06-02 14:14:58 --> Database Driver Class Initialized
INFO - 2016-06-02 14:14:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:14:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:14:58 --> Email Class Initialized
INFO - 2016-06-02 14:14:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:14:58 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:14:58 --> Helper loaded: language_helper
INFO - 2016-06-02 14:14:58 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:14:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:14:58 --> Model Class Initialized
INFO - 2016-06-02 14:14:58 --> Helper loaded: date_helper
INFO - 2016-06-02 14:14:58 --> Controller Class Initialized
INFO - 2016-06-02 14:14:58 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:14:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:14:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:14:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:14:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:14:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:14:58 --> Model Class Initialized
INFO - 2016-06-02 14:14:58 --> Form Validation Class Initialized
ERROR - 2016-06-02 14:14:58 --> Severity: Error --> Call to a member function field_data() on array /home/demis/www/platformadiabet/application/libraries/Excel.php 10
INFO - 2016-06-02 14:19:57 --> Config Class Initialized
INFO - 2016-06-02 14:19:57 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:19:57 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:19:57 --> Utf8 Class Initialized
INFO - 2016-06-02 14:19:57 --> URI Class Initialized
INFO - 2016-06-02 14:19:57 --> Router Class Initialized
INFO - 2016-06-02 14:19:57 --> Output Class Initialized
INFO - 2016-06-02 14:19:57 --> Security Class Initialized
DEBUG - 2016-06-02 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:19:57 --> CSRF cookie sent
INFO - 2016-06-02 14:19:57 --> CSRF token verified
INFO - 2016-06-02 14:19:57 --> Input Class Initialized
INFO - 2016-06-02 14:19:57 --> Language Class Initialized
INFO - 2016-06-02 14:19:57 --> Loader Class Initialized
INFO - 2016-06-02 14:19:57 --> Helper loaded: form_helper
INFO - 2016-06-02 14:19:57 --> Database Driver Class Initialized
INFO - 2016-06-02 14:19:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:19:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:19:57 --> Email Class Initialized
INFO - 2016-06-02 14:19:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:19:57 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:19:57 --> Helper loaded: language_helper
INFO - 2016-06-02 14:19:57 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:19:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:19:57 --> Model Class Initialized
INFO - 2016-06-02 14:19:57 --> Helper loaded: date_helper
INFO - 2016-06-02 14:19:57 --> Controller Class Initialized
INFO - 2016-06-02 14:19:57 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:19:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:19:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:19:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:19:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:19:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:19:57 --> Model Class Initialized
INFO - 2016-06-02 14:19:57 --> Form Validation Class Initialized
INFO - 2016-06-02 14:23:44 --> Config Class Initialized
INFO - 2016-06-02 14:23:44 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:23:44 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:23:44 --> Utf8 Class Initialized
INFO - 2016-06-02 14:23:44 --> URI Class Initialized
INFO - 2016-06-02 14:23:44 --> Router Class Initialized
INFO - 2016-06-02 14:23:44 --> Output Class Initialized
INFO - 2016-06-02 14:23:44 --> Security Class Initialized
DEBUG - 2016-06-02 14:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:23:44 --> CSRF cookie sent
INFO - 2016-06-02 14:23:44 --> CSRF token verified
INFO - 2016-06-02 14:23:44 --> Input Class Initialized
INFO - 2016-06-02 14:23:44 --> Language Class Initialized
INFO - 2016-06-02 14:23:45 --> Loader Class Initialized
INFO - 2016-06-02 14:23:45 --> Helper loaded: form_helper
INFO - 2016-06-02 14:23:45 --> Database Driver Class Initialized
INFO - 2016-06-02 14:23:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:23:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:23:45 --> Email Class Initialized
INFO - 2016-06-02 14:23:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:23:45 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:23:45 --> Helper loaded: language_helper
INFO - 2016-06-02 14:23:45 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:23:45 --> Model Class Initialized
INFO - 2016-06-02 14:23:45 --> Helper loaded: date_helper
INFO - 2016-06-02 14:23:45 --> Controller Class Initialized
INFO - 2016-06-02 14:23:45 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:23:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:23:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:23:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:23:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:23:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:23:45 --> Model Class Initialized
INFO - 2016-06-02 14:23:45 --> Form Validation Class Initialized
INFO - 2016-06-02 14:24:51 --> Config Class Initialized
INFO - 2016-06-02 14:24:51 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:24:51 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:24:51 --> Utf8 Class Initialized
INFO - 2016-06-02 14:24:51 --> URI Class Initialized
INFO - 2016-06-02 14:24:51 --> Router Class Initialized
INFO - 2016-06-02 14:24:51 --> Output Class Initialized
INFO - 2016-06-02 14:24:51 --> Security Class Initialized
DEBUG - 2016-06-02 14:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:24:51 --> CSRF cookie sent
INFO - 2016-06-02 14:24:51 --> CSRF token verified
INFO - 2016-06-02 14:24:51 --> Input Class Initialized
INFO - 2016-06-02 14:24:51 --> Language Class Initialized
INFO - 2016-06-02 14:24:51 --> Loader Class Initialized
INFO - 2016-06-02 14:24:51 --> Helper loaded: form_helper
INFO - 2016-06-02 14:24:51 --> Database Driver Class Initialized
INFO - 2016-06-02 14:24:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:24:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:24:51 --> Email Class Initialized
INFO - 2016-06-02 14:24:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:24:51 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:24:51 --> Helper loaded: language_helper
INFO - 2016-06-02 14:24:51 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:24:51 --> Model Class Initialized
INFO - 2016-06-02 14:24:51 --> Helper loaded: date_helper
INFO - 2016-06-02 14:24:51 --> Controller Class Initialized
INFO - 2016-06-02 14:24:51 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:24:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:24:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:24:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:24:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:24:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:24:51 --> Model Class Initialized
INFO - 2016-06-02 14:24:51 --> Form Validation Class Initialized
INFO - 2016-06-02 14:24:58 --> Config Class Initialized
INFO - 2016-06-02 14:24:58 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:24:58 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:24:58 --> Utf8 Class Initialized
INFO - 2016-06-02 14:24:58 --> URI Class Initialized
INFO - 2016-06-02 14:24:58 --> Router Class Initialized
INFO - 2016-06-02 14:24:58 --> Output Class Initialized
INFO - 2016-06-02 14:24:58 --> Security Class Initialized
DEBUG - 2016-06-02 14:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:24:58 --> CSRF cookie sent
INFO - 2016-06-02 14:24:58 --> CSRF token verified
INFO - 2016-06-02 14:24:58 --> Input Class Initialized
INFO - 2016-06-02 14:24:58 --> Language Class Initialized
INFO - 2016-06-02 14:24:58 --> Loader Class Initialized
INFO - 2016-06-02 14:24:58 --> Helper loaded: form_helper
INFO - 2016-06-02 14:24:58 --> Database Driver Class Initialized
INFO - 2016-06-02 14:24:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:24:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:24:58 --> Email Class Initialized
INFO - 2016-06-02 14:24:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:24:58 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:24:58 --> Helper loaded: language_helper
INFO - 2016-06-02 14:24:58 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:24:58 --> Model Class Initialized
INFO - 2016-06-02 14:24:58 --> Helper loaded: date_helper
INFO - 2016-06-02 14:24:58 --> Controller Class Initialized
INFO - 2016-06-02 14:24:58 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:24:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:24:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:24:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:24:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:24:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:24:58 --> Model Class Initialized
INFO - 2016-06-02 14:24:58 --> Form Validation Class Initialized
INFO - 2016-06-02 14:24:58 --> Final output sent to browser
DEBUG - 2016-06-02 14:24:58 --> Total execution time: 0.0795
INFO - 2016-06-02 14:26:59 --> Config Class Initialized
INFO - 2016-06-02 14:26:59 --> Hooks Class Initialized
DEBUG - 2016-06-02 14:26:59 --> UTF-8 Support Enabled
INFO - 2016-06-02 14:26:59 --> Utf8 Class Initialized
INFO - 2016-06-02 14:26:59 --> URI Class Initialized
INFO - 2016-06-02 14:26:59 --> Router Class Initialized
INFO - 2016-06-02 14:26:59 --> Output Class Initialized
INFO - 2016-06-02 14:26:59 --> Security Class Initialized
DEBUG - 2016-06-02 14:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 14:26:59 --> CSRF cookie sent
INFO - 2016-06-02 14:26:59 --> Input Class Initialized
INFO - 2016-06-02 14:26:59 --> Language Class Initialized
INFO - 2016-06-02 14:26:59 --> Loader Class Initialized
INFO - 2016-06-02 14:26:59 --> Helper loaded: form_helper
INFO - 2016-06-02 14:26:59 --> Database Driver Class Initialized
INFO - 2016-06-02 14:26:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 14:26:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 14:26:59 --> Email Class Initialized
INFO - 2016-06-02 14:26:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 14:26:59 --> Helper loaded: cookie_helper
INFO - 2016-06-02 14:26:59 --> Helper loaded: language_helper
INFO - 2016-06-02 14:26:59 --> Helper loaded: url_helper
DEBUG - 2016-06-02 14:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 14:26:59 --> Model Class Initialized
INFO - 2016-06-02 14:26:59 --> Helper loaded: date_helper
INFO - 2016-06-02 14:26:59 --> Controller Class Initialized
INFO - 2016-06-02 14:26:59 --> Helper loaded: languages_helper
INFO - 2016-06-02 14:26:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 14:26:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 14:26:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 14:26:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 14:26:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 14:26:59 --> Model Class Initialized
INFO - 2016-06-02 14:26:59 --> Form Validation Class Initialized
INFO - 2016-06-02 14:26:59 --> Final output sent to browser
DEBUG - 2016-06-02 14:26:59 --> Total execution time: 0.0241
INFO - 2016-06-02 15:14:19 --> Config Class Initialized
INFO - 2016-06-02 15:14:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:14:19 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:14:19 --> Utf8 Class Initialized
INFO - 2016-06-02 15:14:19 --> URI Class Initialized
INFO - 2016-06-02 15:14:19 --> Router Class Initialized
INFO - 2016-06-02 15:14:19 --> Output Class Initialized
INFO - 2016-06-02 15:14:19 --> Security Class Initialized
DEBUG - 2016-06-02 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:14:19 --> CSRF cookie sent
INFO - 2016-06-02 15:14:19 --> CSRF token verified
INFO - 2016-06-02 15:14:19 --> Input Class Initialized
INFO - 2016-06-02 15:14:19 --> Language Class Initialized
INFO - 2016-06-02 15:14:19 --> Loader Class Initialized
INFO - 2016-06-02 15:14:19 --> Helper loaded: form_helper
INFO - 2016-06-02 15:14:19 --> Database Driver Class Initialized
INFO - 2016-06-02 15:14:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:14:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:14:19 --> Email Class Initialized
INFO - 2016-06-02 15:14:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:14:19 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:14:19 --> Helper loaded: language_helper
INFO - 2016-06-02 15:14:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:14:19 --> Model Class Initialized
INFO - 2016-06-02 15:14:19 --> Helper loaded: date_helper
INFO - 2016-06-02 15:14:19 --> Controller Class Initialized
INFO - 2016-06-02 15:14:19 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:14:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:14:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:14:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:14:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:14:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:14:19 --> Model Class Initialized
INFO - 2016-06-02 15:14:19 --> Form Validation Class Initialized
INFO - 2016-06-02 15:14:19 --> Final output sent to browser
DEBUG - 2016-06-02 15:14:19 --> Total execution time: 0.0557
INFO - 2016-06-02 15:16:04 --> Config Class Initialized
INFO - 2016-06-02 15:16:04 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:16:04 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:16:04 --> Utf8 Class Initialized
INFO - 2016-06-02 15:16:04 --> URI Class Initialized
INFO - 2016-06-02 15:16:04 --> Router Class Initialized
INFO - 2016-06-02 15:16:04 --> Output Class Initialized
INFO - 2016-06-02 15:16:04 --> Security Class Initialized
DEBUG - 2016-06-02 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:16:04 --> CSRF cookie sent
INFO - 2016-06-02 15:16:04 --> CSRF token verified
INFO - 2016-06-02 15:16:04 --> Input Class Initialized
INFO - 2016-06-02 15:16:04 --> Language Class Initialized
INFO - 2016-06-02 15:16:04 --> Loader Class Initialized
INFO - 2016-06-02 15:16:04 --> Helper loaded: form_helper
INFO - 2016-06-02 15:16:04 --> Database Driver Class Initialized
INFO - 2016-06-02 15:16:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:16:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:16:04 --> Email Class Initialized
INFO - 2016-06-02 15:16:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:16:04 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:16:04 --> Helper loaded: language_helper
INFO - 2016-06-02 15:16:04 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:16:04 --> Model Class Initialized
INFO - 2016-06-02 15:16:04 --> Helper loaded: date_helper
INFO - 2016-06-02 15:16:04 --> Controller Class Initialized
INFO - 2016-06-02 15:16:04 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:16:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:16:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:16:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:16:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:16:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:16:04 --> Model Class Initialized
INFO - 2016-06-02 15:16:04 --> Form Validation Class Initialized
INFO - 2016-06-02 15:16:04 --> Final output sent to browser
DEBUG - 2016-06-02 15:16:04 --> Total execution time: 0.0521
INFO - 2016-06-02 15:23:23 --> Config Class Initialized
INFO - 2016-06-02 15:23:23 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:23:23 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:23:23 --> Utf8 Class Initialized
INFO - 2016-06-02 15:23:23 --> URI Class Initialized
INFO - 2016-06-02 15:23:23 --> Router Class Initialized
INFO - 2016-06-02 15:23:23 --> Output Class Initialized
INFO - 2016-06-02 15:23:23 --> Security Class Initialized
DEBUG - 2016-06-02 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:23:23 --> CSRF cookie sent
INFO - 2016-06-02 15:23:23 --> CSRF token verified
INFO - 2016-06-02 15:23:23 --> Input Class Initialized
INFO - 2016-06-02 15:23:23 --> Language Class Initialized
INFO - 2016-06-02 15:23:23 --> Loader Class Initialized
INFO - 2016-06-02 15:23:23 --> Helper loaded: form_helper
INFO - 2016-06-02 15:23:23 --> Database Driver Class Initialized
INFO - 2016-06-02 15:23:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:23:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:23:23 --> Email Class Initialized
INFO - 2016-06-02 15:23:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:23:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:23:23 --> Helper loaded: language_helper
INFO - 2016-06-02 15:23:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:23:23 --> Model Class Initialized
INFO - 2016-06-02 15:23:23 --> Helper loaded: date_helper
INFO - 2016-06-02 15:23:23 --> Controller Class Initialized
INFO - 2016-06-02 15:23:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:23:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:23:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:23:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:23:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:23:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:23:23 --> Model Class Initialized
INFO - 2016-06-02 15:23:23 --> Form Validation Class Initialized
INFO - 2016-06-02 15:23:23 --> Final output sent to browser
DEBUG - 2016-06-02 15:23:23 --> Total execution time: 0.0298
INFO - 2016-06-02 15:23:29 --> Config Class Initialized
INFO - 2016-06-02 15:23:29 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:23:29 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:23:29 --> Utf8 Class Initialized
INFO - 2016-06-02 15:23:29 --> URI Class Initialized
INFO - 2016-06-02 15:23:29 --> Router Class Initialized
INFO - 2016-06-02 15:23:29 --> Output Class Initialized
INFO - 2016-06-02 15:23:29 --> Security Class Initialized
DEBUG - 2016-06-02 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:23:29 --> CSRF cookie sent
INFO - 2016-06-02 15:23:29 --> Input Class Initialized
INFO - 2016-06-02 15:23:29 --> Language Class Initialized
INFO - 2016-06-02 15:23:29 --> Loader Class Initialized
INFO - 2016-06-02 15:23:29 --> Helper loaded: form_helper
INFO - 2016-06-02 15:23:29 --> Database Driver Class Initialized
INFO - 2016-06-02 15:23:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:23:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:23:29 --> Email Class Initialized
INFO - 2016-06-02 15:23:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:23:29 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:23:29 --> Helper loaded: language_helper
INFO - 2016-06-02 15:23:29 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:23:29 --> Model Class Initialized
INFO - 2016-06-02 15:23:29 --> Helper loaded: date_helper
INFO - 2016-06-02 15:23:29 --> Controller Class Initialized
INFO - 2016-06-02 15:23:29 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:23:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:23:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:23:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:23:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:23:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:23:29 --> Model Class Initialized
INFO - 2016-06-02 15:23:29 --> Form Validation Class Initialized
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 15:23:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 15:23:29 --> Final output sent to browser
DEBUG - 2016-06-02 15:23:29 --> Total execution time: 0.0670
INFO - 2016-06-02 15:23:37 --> Config Class Initialized
INFO - 2016-06-02 15:23:37 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:23:37 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:23:37 --> Utf8 Class Initialized
INFO - 2016-06-02 15:23:37 --> URI Class Initialized
INFO - 2016-06-02 15:23:37 --> Router Class Initialized
INFO - 2016-06-02 15:23:37 --> Output Class Initialized
INFO - 2016-06-02 15:23:37 --> Security Class Initialized
DEBUG - 2016-06-02 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:23:37 --> CSRF cookie sent
INFO - 2016-06-02 15:23:37 --> CSRF token verified
INFO - 2016-06-02 15:23:37 --> Input Class Initialized
INFO - 2016-06-02 15:23:37 --> Language Class Initialized
INFO - 2016-06-02 15:23:37 --> Loader Class Initialized
INFO - 2016-06-02 15:23:37 --> Helper loaded: form_helper
INFO - 2016-06-02 15:23:37 --> Database Driver Class Initialized
INFO - 2016-06-02 15:23:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:23:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:23:37 --> Email Class Initialized
INFO - 2016-06-02 15:23:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:23:37 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:23:37 --> Helper loaded: language_helper
INFO - 2016-06-02 15:23:37 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:23:37 --> Model Class Initialized
INFO - 2016-06-02 15:23:37 --> Helper loaded: date_helper
INFO - 2016-06-02 15:23:37 --> Controller Class Initialized
INFO - 2016-06-02 15:23:37 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:23:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:23:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:23:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:23:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:23:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:23:37 --> Model Class Initialized
INFO - 2016-06-02 15:23:37 --> Form Validation Class Initialized
INFO - 2016-06-02 15:23:37 --> Final output sent to browser
DEBUG - 2016-06-02 15:23:37 --> Total execution time: 0.0571
INFO - 2016-06-02 15:23:41 --> Config Class Initialized
INFO - 2016-06-02 15:23:41 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:23:41 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:23:41 --> Utf8 Class Initialized
INFO - 2016-06-02 15:23:41 --> URI Class Initialized
INFO - 2016-06-02 15:23:41 --> Router Class Initialized
INFO - 2016-06-02 15:23:41 --> Output Class Initialized
INFO - 2016-06-02 15:23:41 --> Security Class Initialized
DEBUG - 2016-06-02 15:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:23:41 --> CSRF cookie sent
INFO - 2016-06-02 15:23:41 --> CSRF token verified
INFO - 2016-06-02 15:23:41 --> Input Class Initialized
INFO - 2016-06-02 15:23:41 --> Language Class Initialized
INFO - 2016-06-02 15:23:41 --> Loader Class Initialized
INFO - 2016-06-02 15:23:41 --> Helper loaded: form_helper
INFO - 2016-06-02 15:23:41 --> Database Driver Class Initialized
INFO - 2016-06-02 15:23:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:23:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:23:41 --> Email Class Initialized
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:23:41 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:23:41 --> Helper loaded: language_helper
INFO - 2016-06-02 15:23:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:23:41 --> Model Class Initialized
INFO - 2016-06-02 15:23:41 --> Helper loaded: date_helper
INFO - 2016-06-02 15:23:41 --> Controller Class Initialized
INFO - 2016-06-02 15:23:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:23:41 --> Model Class Initialized
INFO - 2016-06-02 15:23:41 --> Form Validation Class Initialized
INFO - 2016-06-02 15:23:41 --> Final output sent to browser
DEBUG - 2016-06-02 15:23:41 --> Total execution time: 0.0629
INFO - 2016-06-02 15:23:41 --> Config Class Initialized
INFO - 2016-06-02 15:23:41 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:23:41 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:23:41 --> Utf8 Class Initialized
INFO - 2016-06-02 15:23:41 --> URI Class Initialized
INFO - 2016-06-02 15:23:41 --> Router Class Initialized
INFO - 2016-06-02 15:23:41 --> Output Class Initialized
INFO - 2016-06-02 15:23:41 --> Security Class Initialized
DEBUG - 2016-06-02 15:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:23:41 --> CSRF cookie sent
INFO - 2016-06-02 15:23:41 --> Input Class Initialized
INFO - 2016-06-02 15:23:41 --> Language Class Initialized
INFO - 2016-06-02 15:23:41 --> Loader Class Initialized
INFO - 2016-06-02 15:23:41 --> Helper loaded: form_helper
INFO - 2016-06-02 15:23:41 --> Database Driver Class Initialized
INFO - 2016-06-02 15:23:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:23:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:23:41 --> Email Class Initialized
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:23:41 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:23:41 --> Helper loaded: language_helper
INFO - 2016-06-02 15:23:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:23:41 --> Model Class Initialized
INFO - 2016-06-02 15:23:41 --> Helper loaded: date_helper
INFO - 2016-06-02 15:23:41 --> Controller Class Initialized
INFO - 2016-06-02 15:23:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:23:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:23:41 --> Model Class Initialized
INFO - 2016-06-02 15:23:41 --> Form Validation Class Initialized
INFO - 2016-06-02 15:23:41 --> Final output sent to browser
DEBUG - 2016-06-02 15:23:41 --> Total execution time: 0.0365
INFO - 2016-06-02 15:24:21 --> Config Class Initialized
INFO - 2016-06-02 15:24:21 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:24:21 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:24:21 --> Utf8 Class Initialized
INFO - 2016-06-02 15:24:21 --> URI Class Initialized
INFO - 2016-06-02 15:24:21 --> Router Class Initialized
INFO - 2016-06-02 15:24:21 --> Output Class Initialized
INFO - 2016-06-02 15:24:21 --> Security Class Initialized
DEBUG - 2016-06-02 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:24:21 --> CSRF cookie sent
INFO - 2016-06-02 15:24:21 --> CSRF token verified
INFO - 2016-06-02 15:24:21 --> Input Class Initialized
INFO - 2016-06-02 15:24:21 --> Language Class Initialized
INFO - 2016-06-02 15:24:21 --> Loader Class Initialized
INFO - 2016-06-02 15:24:21 --> Helper loaded: form_helper
INFO - 2016-06-02 15:24:21 --> Database Driver Class Initialized
INFO - 2016-06-02 15:24:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:24:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:24:21 --> Email Class Initialized
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:24:21 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:24:21 --> Helper loaded: language_helper
INFO - 2016-06-02 15:24:21 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:24:21 --> Model Class Initialized
INFO - 2016-06-02 15:24:21 --> Helper loaded: date_helper
INFO - 2016-06-02 15:24:21 --> Controller Class Initialized
INFO - 2016-06-02 15:24:21 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:24:21 --> Model Class Initialized
INFO - 2016-06-02 15:24:21 --> Form Validation Class Initialized
INFO - 2016-06-02 15:24:21 --> Final output sent to browser
DEBUG - 2016-06-02 15:24:21 --> Total execution time: 0.0427
INFO - 2016-06-02 15:24:21 --> Config Class Initialized
INFO - 2016-06-02 15:24:21 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:24:21 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:24:21 --> Utf8 Class Initialized
INFO - 2016-06-02 15:24:21 --> URI Class Initialized
INFO - 2016-06-02 15:24:21 --> Router Class Initialized
INFO - 2016-06-02 15:24:21 --> Output Class Initialized
INFO - 2016-06-02 15:24:21 --> Security Class Initialized
DEBUG - 2016-06-02 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:24:21 --> CSRF cookie sent
INFO - 2016-06-02 15:24:21 --> Input Class Initialized
INFO - 2016-06-02 15:24:21 --> Language Class Initialized
INFO - 2016-06-02 15:24:21 --> Loader Class Initialized
INFO - 2016-06-02 15:24:21 --> Helper loaded: form_helper
INFO - 2016-06-02 15:24:21 --> Database Driver Class Initialized
INFO - 2016-06-02 15:24:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:24:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:24:21 --> Email Class Initialized
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:24:21 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:24:21 --> Helper loaded: language_helper
INFO - 2016-06-02 15:24:21 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:24:21 --> Model Class Initialized
INFO - 2016-06-02 15:24:21 --> Helper loaded: date_helper
INFO - 2016-06-02 15:24:21 --> Controller Class Initialized
INFO - 2016-06-02 15:24:21 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:24:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:24:21 --> Model Class Initialized
INFO - 2016-06-02 15:24:21 --> Form Validation Class Initialized
INFO - 2016-06-02 15:24:21 --> Final output sent to browser
DEBUG - 2016-06-02 15:24:21 --> Total execution time: 0.0167
INFO - 2016-06-02 15:25:43 --> Config Class Initialized
INFO - 2016-06-02 15:25:43 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:25:43 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:25:43 --> Utf8 Class Initialized
INFO - 2016-06-02 15:25:43 --> URI Class Initialized
INFO - 2016-06-02 15:25:43 --> Router Class Initialized
INFO - 2016-06-02 15:25:43 --> Output Class Initialized
INFO - 2016-06-02 15:25:43 --> Security Class Initialized
DEBUG - 2016-06-02 15:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:25:43 --> CSRF cookie sent
INFO - 2016-06-02 15:25:43 --> CSRF token verified
INFO - 2016-06-02 15:25:43 --> Input Class Initialized
INFO - 2016-06-02 15:25:43 --> Language Class Initialized
INFO - 2016-06-02 15:25:43 --> Loader Class Initialized
INFO - 2016-06-02 15:25:43 --> Helper loaded: form_helper
INFO - 2016-06-02 15:25:43 --> Database Driver Class Initialized
INFO - 2016-06-02 15:25:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:25:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:25:43 --> Email Class Initialized
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:25:43 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:25:43 --> Helper loaded: language_helper
INFO - 2016-06-02 15:25:43 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:25:43 --> Model Class Initialized
INFO - 2016-06-02 15:25:43 --> Helper loaded: date_helper
INFO - 2016-06-02 15:25:43 --> Controller Class Initialized
INFO - 2016-06-02 15:25:43 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:25:43 --> Model Class Initialized
INFO - 2016-06-02 15:25:43 --> Form Validation Class Initialized
INFO - 2016-06-02 15:25:43 --> Final output sent to browser
DEBUG - 2016-06-02 15:25:43 --> Total execution time: 0.0636
INFO - 2016-06-02 15:25:43 --> Config Class Initialized
INFO - 2016-06-02 15:25:43 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:25:43 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:25:43 --> Utf8 Class Initialized
INFO - 2016-06-02 15:25:43 --> URI Class Initialized
INFO - 2016-06-02 15:25:43 --> Router Class Initialized
INFO - 2016-06-02 15:25:43 --> Output Class Initialized
INFO - 2016-06-02 15:25:43 --> Security Class Initialized
DEBUG - 2016-06-02 15:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:25:43 --> CSRF cookie sent
INFO - 2016-06-02 15:25:43 --> Input Class Initialized
INFO - 2016-06-02 15:25:43 --> Language Class Initialized
INFO - 2016-06-02 15:25:43 --> Loader Class Initialized
INFO - 2016-06-02 15:25:43 --> Helper loaded: form_helper
INFO - 2016-06-02 15:25:43 --> Database Driver Class Initialized
INFO - 2016-06-02 15:25:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:25:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:25:43 --> Email Class Initialized
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:25:43 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:25:43 --> Helper loaded: language_helper
INFO - 2016-06-02 15:25:43 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:25:43 --> Model Class Initialized
INFO - 2016-06-02 15:25:43 --> Helper loaded: date_helper
INFO - 2016-06-02 15:25:43 --> Controller Class Initialized
INFO - 2016-06-02 15:25:43 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:25:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:25:43 --> Model Class Initialized
INFO - 2016-06-02 15:25:43 --> Form Validation Class Initialized
INFO - 2016-06-02 15:25:43 --> Final output sent to browser
DEBUG - 2016-06-02 15:25:43 --> Total execution time: 0.0158
INFO - 2016-06-02 15:31:19 --> Config Class Initialized
INFO - 2016-06-02 15:31:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:31:19 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:31:19 --> Utf8 Class Initialized
INFO - 2016-06-02 15:31:19 --> URI Class Initialized
INFO - 2016-06-02 15:31:19 --> Router Class Initialized
INFO - 2016-06-02 15:31:19 --> Output Class Initialized
INFO - 2016-06-02 15:31:19 --> Security Class Initialized
DEBUG - 2016-06-02 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:31:19 --> CSRF cookie sent
INFO - 2016-06-02 15:31:19 --> CSRF token verified
INFO - 2016-06-02 15:31:19 --> Input Class Initialized
INFO - 2016-06-02 15:31:19 --> Language Class Initialized
INFO - 2016-06-02 15:31:19 --> Loader Class Initialized
INFO - 2016-06-02 15:31:19 --> Helper loaded: form_helper
INFO - 2016-06-02 15:31:19 --> Database Driver Class Initialized
INFO - 2016-06-02 15:31:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:31:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:31:19 --> Email Class Initialized
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:31:19 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:31:19 --> Helper loaded: language_helper
INFO - 2016-06-02 15:31:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:31:19 --> Model Class Initialized
INFO - 2016-06-02 15:31:19 --> Helper loaded: date_helper
INFO - 2016-06-02 15:31:19 --> Controller Class Initialized
INFO - 2016-06-02 15:31:19 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:31:19 --> Model Class Initialized
INFO - 2016-06-02 15:31:19 --> Form Validation Class Initialized
ERROR - 2016-06-02 15:31:19 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 382
ERROR - 2016-06-02 15:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 382
ERROR - 2016-06-02 15:31:19 --> Severity: Notice --> Undefined variable: titles /home/demis/www/platformadiabet/application/controllers/Diabet.php 389
INFO - 2016-06-02 15:31:19 --> Final output sent to browser
DEBUG - 2016-06-02 15:31:19 --> Total execution time: 0.0211
INFO - 2016-06-02 15:31:19 --> Config Class Initialized
INFO - 2016-06-02 15:31:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:31:19 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:31:19 --> Utf8 Class Initialized
INFO - 2016-06-02 15:31:19 --> URI Class Initialized
INFO - 2016-06-02 15:31:19 --> Router Class Initialized
INFO - 2016-06-02 15:31:19 --> Output Class Initialized
INFO - 2016-06-02 15:31:19 --> Security Class Initialized
DEBUG - 2016-06-02 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:31:19 --> CSRF cookie sent
INFO - 2016-06-02 15:31:19 --> Input Class Initialized
INFO - 2016-06-02 15:31:19 --> Language Class Initialized
INFO - 2016-06-02 15:31:19 --> Loader Class Initialized
INFO - 2016-06-02 15:31:19 --> Helper loaded: form_helper
INFO - 2016-06-02 15:31:19 --> Database Driver Class Initialized
INFO - 2016-06-02 15:31:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:31:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:31:19 --> Email Class Initialized
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:31:19 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:31:19 --> Helper loaded: language_helper
INFO - 2016-06-02 15:31:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:31:19 --> Model Class Initialized
INFO - 2016-06-02 15:31:19 --> Helper loaded: date_helper
INFO - 2016-06-02 15:31:19 --> Controller Class Initialized
INFO - 2016-06-02 15:31:19 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:31:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:31:19 --> Model Class Initialized
INFO - 2016-06-02 15:31:19 --> Form Validation Class Initialized
ERROR - 2016-06-02 15:31:19 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 382
ERROR - 2016-06-02 15:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 382
ERROR - 2016-06-02 15:31:19 --> Severity: Notice --> Undefined variable: titles /home/demis/www/platformadiabet/application/controllers/Diabet.php 389
INFO - 2016-06-02 15:31:19 --> Final output sent to browser
DEBUG - 2016-06-02 15:31:19 --> Total execution time: 0.0181
INFO - 2016-06-02 15:31:59 --> Config Class Initialized
INFO - 2016-06-02 15:31:59 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:31:59 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:31:59 --> Utf8 Class Initialized
INFO - 2016-06-02 15:31:59 --> URI Class Initialized
INFO - 2016-06-02 15:31:59 --> Router Class Initialized
INFO - 2016-06-02 15:31:59 --> Output Class Initialized
INFO - 2016-06-02 15:31:59 --> Security Class Initialized
DEBUG - 2016-06-02 15:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:31:59 --> CSRF cookie sent
INFO - 2016-06-02 15:31:59 --> CSRF token verified
INFO - 2016-06-02 15:31:59 --> Input Class Initialized
INFO - 2016-06-02 15:31:59 --> Language Class Initialized
INFO - 2016-06-02 15:31:59 --> Loader Class Initialized
INFO - 2016-06-02 15:31:59 --> Helper loaded: form_helper
INFO - 2016-06-02 15:31:59 --> Database Driver Class Initialized
INFO - 2016-06-02 15:31:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:31:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:31:59 --> Email Class Initialized
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:31:59 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:31:59 --> Helper loaded: language_helper
INFO - 2016-06-02 15:31:59 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:31:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:31:59 --> Model Class Initialized
INFO - 2016-06-02 15:31:59 --> Helper loaded: date_helper
INFO - 2016-06-02 15:31:59 --> Controller Class Initialized
INFO - 2016-06-02 15:31:59 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:31:59 --> Model Class Initialized
INFO - 2016-06-02 15:31:59 --> Form Validation Class Initialized
INFO - 2016-06-02 15:31:59 --> Final output sent to browser
DEBUG - 2016-06-02 15:31:59 --> Total execution time: 0.0634
INFO - 2016-06-02 15:31:59 --> Config Class Initialized
INFO - 2016-06-02 15:31:59 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:31:59 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:31:59 --> Utf8 Class Initialized
INFO - 2016-06-02 15:31:59 --> URI Class Initialized
INFO - 2016-06-02 15:31:59 --> Router Class Initialized
INFO - 2016-06-02 15:31:59 --> Output Class Initialized
INFO - 2016-06-02 15:31:59 --> Security Class Initialized
DEBUG - 2016-06-02 15:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:31:59 --> CSRF cookie sent
INFO - 2016-06-02 15:31:59 --> Input Class Initialized
INFO - 2016-06-02 15:31:59 --> Language Class Initialized
INFO - 2016-06-02 15:31:59 --> Loader Class Initialized
INFO - 2016-06-02 15:31:59 --> Helper loaded: form_helper
INFO - 2016-06-02 15:31:59 --> Database Driver Class Initialized
INFO - 2016-06-02 15:31:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:31:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:31:59 --> Email Class Initialized
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:31:59 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:31:59 --> Helper loaded: language_helper
INFO - 2016-06-02 15:31:59 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:31:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:31:59 --> Model Class Initialized
INFO - 2016-06-02 15:31:59 --> Helper loaded: date_helper
INFO - 2016-06-02 15:31:59 --> Controller Class Initialized
INFO - 2016-06-02 15:31:59 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:31:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:31:59 --> Model Class Initialized
INFO - 2016-06-02 15:31:59 --> Form Validation Class Initialized
INFO - 2016-06-02 15:31:59 --> Final output sent to browser
DEBUG - 2016-06-02 15:31:59 --> Total execution time: 0.0274
INFO - 2016-06-02 15:38:52 --> Config Class Initialized
INFO - 2016-06-02 15:38:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:38:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:38:52 --> Utf8 Class Initialized
INFO - 2016-06-02 15:38:52 --> URI Class Initialized
INFO - 2016-06-02 15:38:52 --> Router Class Initialized
INFO - 2016-06-02 15:38:52 --> Output Class Initialized
INFO - 2016-06-02 15:38:52 --> Security Class Initialized
DEBUG - 2016-06-02 15:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:38:52 --> CSRF cookie sent
INFO - 2016-06-02 15:38:52 --> CSRF token verified
INFO - 2016-06-02 15:38:52 --> Input Class Initialized
INFO - 2016-06-02 15:38:52 --> Language Class Initialized
INFO - 2016-06-02 15:38:52 --> Loader Class Initialized
INFO - 2016-06-02 15:38:52 --> Helper loaded: form_helper
INFO - 2016-06-02 15:38:52 --> Database Driver Class Initialized
INFO - 2016-06-02 15:38:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:38:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:38:52 --> Email Class Initialized
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:38:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:38:52 --> Helper loaded: language_helper
INFO - 2016-06-02 15:38:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:38:52 --> Model Class Initialized
INFO - 2016-06-02 15:38:52 --> Helper loaded: date_helper
INFO - 2016-06-02 15:38:52 --> Controller Class Initialized
INFO - 2016-06-02 15:38:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:38:52 --> Model Class Initialized
INFO - 2016-06-02 15:38:52 --> Form Validation Class Initialized
INFO - 2016-06-02 15:38:52 --> Final output sent to browser
DEBUG - 2016-06-02 15:38:52 --> Total execution time: 0.0564
INFO - 2016-06-02 15:38:52 --> Config Class Initialized
INFO - 2016-06-02 15:38:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:38:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:38:52 --> Utf8 Class Initialized
INFO - 2016-06-02 15:38:52 --> URI Class Initialized
INFO - 2016-06-02 15:38:52 --> Router Class Initialized
INFO - 2016-06-02 15:38:52 --> Output Class Initialized
INFO - 2016-06-02 15:38:52 --> Security Class Initialized
DEBUG - 2016-06-02 15:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:38:52 --> CSRF cookie sent
INFO - 2016-06-02 15:38:52 --> Input Class Initialized
INFO - 2016-06-02 15:38:52 --> Language Class Initialized
INFO - 2016-06-02 15:38:52 --> Loader Class Initialized
INFO - 2016-06-02 15:38:52 --> Helper loaded: form_helper
INFO - 2016-06-02 15:38:52 --> Database Driver Class Initialized
INFO - 2016-06-02 15:38:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:38:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:38:52 --> Email Class Initialized
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:38:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:38:52 --> Helper loaded: language_helper
INFO - 2016-06-02 15:38:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:38:52 --> Model Class Initialized
INFO - 2016-06-02 15:38:52 --> Helper loaded: date_helper
INFO - 2016-06-02 15:38:52 --> Controller Class Initialized
INFO - 2016-06-02 15:38:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:38:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:38:52 --> Model Class Initialized
INFO - 2016-06-02 15:38:52 --> Form Validation Class Initialized
INFO - 2016-06-02 15:38:52 --> Final output sent to browser
DEBUG - 2016-06-02 15:38:52 --> Total execution time: 0.0226
INFO - 2016-06-02 15:40:52 --> Config Class Initialized
INFO - 2016-06-02 15:40:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:40:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:40:52 --> Utf8 Class Initialized
INFO - 2016-06-02 15:40:52 --> URI Class Initialized
INFO - 2016-06-02 15:40:52 --> Router Class Initialized
INFO - 2016-06-02 15:40:52 --> Output Class Initialized
INFO - 2016-06-02 15:40:52 --> Security Class Initialized
DEBUG - 2016-06-02 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:40:52 --> CSRF cookie sent
INFO - 2016-06-02 15:40:52 --> CSRF token verified
INFO - 2016-06-02 15:40:52 --> Input Class Initialized
INFO - 2016-06-02 15:40:52 --> Language Class Initialized
INFO - 2016-06-02 15:40:52 --> Loader Class Initialized
INFO - 2016-06-02 15:40:52 --> Helper loaded: form_helper
INFO - 2016-06-02 15:40:52 --> Database Driver Class Initialized
INFO - 2016-06-02 15:40:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:40:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:40:52 --> Email Class Initialized
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:40:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:40:52 --> Helper loaded: language_helper
INFO - 2016-06-02 15:40:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:40:52 --> Model Class Initialized
INFO - 2016-06-02 15:40:52 --> Helper loaded: date_helper
INFO - 2016-06-02 15:40:52 --> Controller Class Initialized
INFO - 2016-06-02 15:40:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:40:52 --> Model Class Initialized
INFO - 2016-06-02 15:40:52 --> Form Validation Class Initialized
INFO - 2016-06-02 15:40:52 --> Final output sent to browser
DEBUG - 2016-06-02 15:40:52 --> Total execution time: 0.0514
INFO - 2016-06-02 15:40:52 --> Config Class Initialized
INFO - 2016-06-02 15:40:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:40:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:40:52 --> Utf8 Class Initialized
INFO - 2016-06-02 15:40:52 --> URI Class Initialized
INFO - 2016-06-02 15:40:52 --> Router Class Initialized
INFO - 2016-06-02 15:40:52 --> Output Class Initialized
INFO - 2016-06-02 15:40:52 --> Security Class Initialized
DEBUG - 2016-06-02 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:40:52 --> CSRF cookie sent
INFO - 2016-06-02 15:40:52 --> Input Class Initialized
INFO - 2016-06-02 15:40:52 --> Language Class Initialized
INFO - 2016-06-02 15:40:52 --> Loader Class Initialized
INFO - 2016-06-02 15:40:52 --> Helper loaded: form_helper
INFO - 2016-06-02 15:40:52 --> Database Driver Class Initialized
INFO - 2016-06-02 15:40:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:40:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:40:52 --> Email Class Initialized
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:40:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:40:52 --> Helper loaded: language_helper
INFO - 2016-06-02 15:40:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:40:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:40:52 --> Model Class Initialized
INFO - 2016-06-02 15:40:52 --> Helper loaded: date_helper
INFO - 2016-06-02 15:40:52 --> Controller Class Initialized
INFO - 2016-06-02 15:40:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:40:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:40:52 --> Model Class Initialized
INFO - 2016-06-02 15:40:52 --> Form Validation Class Initialized
INFO - 2016-06-02 15:40:53 --> Final output sent to browser
DEBUG - 2016-06-02 15:40:53 --> Total execution time: 0.0634
INFO - 2016-06-02 15:43:18 --> Config Class Initialized
INFO - 2016-06-02 15:43:18 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:43:18 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:43:18 --> Utf8 Class Initialized
INFO - 2016-06-02 15:43:18 --> URI Class Initialized
INFO - 2016-06-02 15:43:18 --> Router Class Initialized
INFO - 2016-06-02 15:43:18 --> Output Class Initialized
INFO - 2016-06-02 15:43:18 --> Security Class Initialized
DEBUG - 2016-06-02 15:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:43:18 --> CSRF cookie sent
INFO - 2016-06-02 15:43:18 --> CSRF token verified
INFO - 2016-06-02 15:43:18 --> Input Class Initialized
INFO - 2016-06-02 15:43:18 --> Language Class Initialized
INFO - 2016-06-02 15:43:18 --> Loader Class Initialized
INFO - 2016-06-02 15:43:18 --> Helper loaded: form_helper
INFO - 2016-06-02 15:43:18 --> Database Driver Class Initialized
INFO - 2016-06-02 15:43:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:43:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:43:18 --> Email Class Initialized
INFO - 2016-06-02 15:43:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:43:18 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:43:18 --> Helper loaded: language_helper
INFO - 2016-06-02 15:43:18 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:43:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:43:18 --> Model Class Initialized
INFO - 2016-06-02 15:43:18 --> Helper loaded: date_helper
INFO - 2016-06-02 15:43:18 --> Controller Class Initialized
INFO - 2016-06-02 15:43:18 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:43:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:43:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:43:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:43:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:43:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:43:18 --> Model Class Initialized
INFO - 2016-06-02 15:43:18 --> Form Validation Class Initialized
INFO - 2016-06-02 15:43:18 --> Final output sent to browser
DEBUG - 2016-06-02 15:43:18 --> Total execution time: 0.0413
INFO - 2016-06-02 15:43:19 --> Config Class Initialized
INFO - 2016-06-02 15:43:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:43:19 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:43:19 --> Utf8 Class Initialized
INFO - 2016-06-02 15:43:19 --> URI Class Initialized
INFO - 2016-06-02 15:43:19 --> Router Class Initialized
INFO - 2016-06-02 15:43:19 --> Output Class Initialized
INFO - 2016-06-02 15:43:19 --> Security Class Initialized
DEBUG - 2016-06-02 15:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:43:19 --> CSRF cookie sent
INFO - 2016-06-02 15:43:19 --> Input Class Initialized
INFO - 2016-06-02 15:43:19 --> Language Class Initialized
INFO - 2016-06-02 15:43:19 --> Loader Class Initialized
INFO - 2016-06-02 15:43:19 --> Helper loaded: form_helper
INFO - 2016-06-02 15:43:19 --> Database Driver Class Initialized
INFO - 2016-06-02 15:43:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:43:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:43:19 --> Email Class Initialized
INFO - 2016-06-02 15:43:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:43:19 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:43:19 --> Helper loaded: language_helper
INFO - 2016-06-02 15:43:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:43:19 --> Model Class Initialized
INFO - 2016-06-02 15:43:19 --> Helper loaded: date_helper
INFO - 2016-06-02 15:43:19 --> Controller Class Initialized
INFO - 2016-06-02 15:43:19 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:43:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:43:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:43:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:43:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:43:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:43:19 --> Model Class Initialized
INFO - 2016-06-02 15:43:19 --> Form Validation Class Initialized
INFO - 2016-06-02 15:43:19 --> Final output sent to browser
DEBUG - 2016-06-02 15:43:19 --> Total execution time: 0.0338
INFO - 2016-06-02 15:46:19 --> Config Class Initialized
INFO - 2016-06-02 15:46:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:46:19 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:46:19 --> Utf8 Class Initialized
INFO - 2016-06-02 15:46:19 --> URI Class Initialized
INFO - 2016-06-02 15:46:19 --> Router Class Initialized
INFO - 2016-06-02 15:46:19 --> Output Class Initialized
INFO - 2016-06-02 15:46:19 --> Security Class Initialized
DEBUG - 2016-06-02 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:46:19 --> CSRF cookie sent
INFO - 2016-06-02 15:46:19 --> CSRF token verified
INFO - 2016-06-02 15:46:19 --> Input Class Initialized
INFO - 2016-06-02 15:46:19 --> Language Class Initialized
INFO - 2016-06-02 15:46:19 --> Loader Class Initialized
INFO - 2016-06-02 15:46:19 --> Helper loaded: form_helper
INFO - 2016-06-02 15:46:19 --> Database Driver Class Initialized
INFO - 2016-06-02 15:46:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:46:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:46:19 --> Email Class Initialized
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:46:19 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:46:19 --> Helper loaded: language_helper
INFO - 2016-06-02 15:46:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:46:19 --> Model Class Initialized
INFO - 2016-06-02 15:46:19 --> Helper loaded: date_helper
INFO - 2016-06-02 15:46:19 --> Controller Class Initialized
INFO - 2016-06-02 15:46:19 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:46:19 --> Model Class Initialized
INFO - 2016-06-02 15:46:19 --> Form Validation Class Initialized
INFO - 2016-06-02 15:46:19 --> Final output sent to browser
DEBUG - 2016-06-02 15:46:19 --> Total execution time: 0.0425
INFO - 2016-06-02 15:46:19 --> Config Class Initialized
INFO - 2016-06-02 15:46:19 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:46:19 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:46:19 --> Utf8 Class Initialized
INFO - 2016-06-02 15:46:19 --> URI Class Initialized
INFO - 2016-06-02 15:46:19 --> Router Class Initialized
INFO - 2016-06-02 15:46:19 --> Output Class Initialized
INFO - 2016-06-02 15:46:19 --> Security Class Initialized
DEBUG - 2016-06-02 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:46:19 --> CSRF cookie sent
INFO - 2016-06-02 15:46:19 --> Input Class Initialized
INFO - 2016-06-02 15:46:19 --> Language Class Initialized
INFO - 2016-06-02 15:46:19 --> Loader Class Initialized
INFO - 2016-06-02 15:46:19 --> Helper loaded: form_helper
INFO - 2016-06-02 15:46:19 --> Database Driver Class Initialized
INFO - 2016-06-02 15:46:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:46:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:46:19 --> Email Class Initialized
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:46:19 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:46:19 --> Helper loaded: language_helper
INFO - 2016-06-02 15:46:19 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:46:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:46:19 --> Model Class Initialized
INFO - 2016-06-02 15:46:19 --> Helper loaded: date_helper
INFO - 2016-06-02 15:46:19 --> Controller Class Initialized
INFO - 2016-06-02 15:46:19 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:46:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:46:19 --> Model Class Initialized
INFO - 2016-06-02 15:46:19 --> Form Validation Class Initialized
INFO - 2016-06-02 15:46:19 --> Final output sent to browser
DEBUG - 2016-06-02 15:46:19 --> Total execution time: 0.0312
INFO - 2016-06-02 15:50:22 --> Config Class Initialized
INFO - 2016-06-02 15:50:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:50:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:50:22 --> Utf8 Class Initialized
INFO - 2016-06-02 15:50:22 --> URI Class Initialized
INFO - 2016-06-02 15:50:22 --> Router Class Initialized
INFO - 2016-06-02 15:50:22 --> Output Class Initialized
INFO - 2016-06-02 15:50:22 --> Security Class Initialized
DEBUG - 2016-06-02 15:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:50:22 --> CSRF cookie sent
INFO - 2016-06-02 15:50:22 --> Input Class Initialized
INFO - 2016-06-02 15:50:22 --> Language Class Initialized
INFO - 2016-06-02 15:50:22 --> Loader Class Initialized
INFO - 2016-06-02 15:50:22 --> Helper loaded: form_helper
INFO - 2016-06-02 15:50:22 --> Database Driver Class Initialized
INFO - 2016-06-02 15:50:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:50:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:50:22 --> Email Class Initialized
INFO - 2016-06-02 15:50:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:50:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:50:22 --> Helper loaded: language_helper
INFO - 2016-06-02 15:50:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:50:22 --> Model Class Initialized
INFO - 2016-06-02 15:50:22 --> Helper loaded: date_helper
INFO - 2016-06-02 15:50:22 --> Controller Class Initialized
INFO - 2016-06-02 15:50:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:50:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:50:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:50:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:50:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:50:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:50:22 --> Model Class Initialized
INFO - 2016-06-02 15:50:22 --> Form Validation Class Initialized
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 15:50:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 15:50:22 --> Final output sent to browser
DEBUG - 2016-06-02 15:50:22 --> Total execution time: 0.0966
INFO - 2016-06-02 15:50:27 --> Config Class Initialized
INFO - 2016-06-02 15:50:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:50:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:50:27 --> Utf8 Class Initialized
INFO - 2016-06-02 15:50:27 --> URI Class Initialized
INFO - 2016-06-02 15:50:27 --> Router Class Initialized
INFO - 2016-06-02 15:50:27 --> Output Class Initialized
INFO - 2016-06-02 15:50:27 --> Security Class Initialized
DEBUG - 2016-06-02 15:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:50:27 --> CSRF cookie sent
INFO - 2016-06-02 15:50:27 --> CSRF token verified
INFO - 2016-06-02 15:50:27 --> Input Class Initialized
INFO - 2016-06-02 15:50:27 --> Language Class Initialized
INFO - 2016-06-02 15:50:27 --> Loader Class Initialized
INFO - 2016-06-02 15:50:27 --> Helper loaded: form_helper
INFO - 2016-06-02 15:50:27 --> Database Driver Class Initialized
INFO - 2016-06-02 15:50:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:50:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:50:27 --> Email Class Initialized
INFO - 2016-06-02 15:50:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:50:27 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:50:27 --> Helper loaded: language_helper
INFO - 2016-06-02 15:50:27 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:50:27 --> Model Class Initialized
INFO - 2016-06-02 15:50:27 --> Helper loaded: date_helper
INFO - 2016-06-02 15:50:27 --> Controller Class Initialized
INFO - 2016-06-02 15:50:27 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:50:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:50:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:50:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:50:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:50:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:50:27 --> Model Class Initialized
INFO - 2016-06-02 15:50:27 --> Form Validation Class Initialized
INFO - 2016-06-02 15:50:27 --> Final output sent to browser
DEBUG - 2016-06-02 15:50:27 --> Total execution time: 0.0154
INFO - 2016-06-02 15:50:31 --> Config Class Initialized
INFO - 2016-06-02 15:50:31 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:50:31 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:50:31 --> Utf8 Class Initialized
INFO - 2016-06-02 15:50:31 --> URI Class Initialized
INFO - 2016-06-02 15:50:31 --> Router Class Initialized
INFO - 2016-06-02 15:50:31 --> Output Class Initialized
INFO - 2016-06-02 15:50:31 --> Security Class Initialized
DEBUG - 2016-06-02 15:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:50:31 --> CSRF cookie sent
INFO - 2016-06-02 15:50:31 --> CSRF token verified
INFO - 2016-06-02 15:50:31 --> Input Class Initialized
INFO - 2016-06-02 15:50:31 --> Language Class Initialized
INFO - 2016-06-02 15:50:31 --> Loader Class Initialized
INFO - 2016-06-02 15:50:31 --> Helper loaded: form_helper
INFO - 2016-06-02 15:50:31 --> Database Driver Class Initialized
INFO - 2016-06-02 15:50:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:50:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:50:31 --> Email Class Initialized
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:50:31 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:50:31 --> Helper loaded: language_helper
INFO - 2016-06-02 15:50:31 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:50:31 --> Model Class Initialized
INFO - 2016-06-02 15:50:31 --> Helper loaded: date_helper
INFO - 2016-06-02 15:50:31 --> Controller Class Initialized
INFO - 2016-06-02 15:50:31 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:50:31 --> Model Class Initialized
INFO - 2016-06-02 15:50:31 --> Form Validation Class Initialized
INFO - 2016-06-02 15:50:31 --> Final output sent to browser
DEBUG - 2016-06-02 15:50:31 --> Total execution time: 0.0461
INFO - 2016-06-02 15:50:31 --> Config Class Initialized
INFO - 2016-06-02 15:50:31 --> Hooks Class Initialized
DEBUG - 2016-06-02 15:50:31 --> UTF-8 Support Enabled
INFO - 2016-06-02 15:50:31 --> Utf8 Class Initialized
INFO - 2016-06-02 15:50:31 --> URI Class Initialized
INFO - 2016-06-02 15:50:31 --> Router Class Initialized
INFO - 2016-06-02 15:50:31 --> Output Class Initialized
INFO - 2016-06-02 15:50:31 --> Security Class Initialized
DEBUG - 2016-06-02 15:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 15:50:31 --> CSRF cookie sent
INFO - 2016-06-02 15:50:31 --> Input Class Initialized
INFO - 2016-06-02 15:50:31 --> Language Class Initialized
INFO - 2016-06-02 15:50:31 --> Loader Class Initialized
INFO - 2016-06-02 15:50:31 --> Helper loaded: form_helper
INFO - 2016-06-02 15:50:31 --> Database Driver Class Initialized
INFO - 2016-06-02 15:50:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 15:50:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 15:50:31 --> Email Class Initialized
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 15:50:31 --> Helper loaded: cookie_helper
INFO - 2016-06-02 15:50:31 --> Helper loaded: language_helper
INFO - 2016-06-02 15:50:31 --> Helper loaded: url_helper
DEBUG - 2016-06-02 15:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 15:50:31 --> Model Class Initialized
INFO - 2016-06-02 15:50:31 --> Helper loaded: date_helper
INFO - 2016-06-02 15:50:31 --> Controller Class Initialized
INFO - 2016-06-02 15:50:31 --> Helper loaded: languages_helper
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 15:50:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 15:50:31 --> Model Class Initialized
INFO - 2016-06-02 15:50:31 --> Form Validation Class Initialized
INFO - 2016-06-02 15:50:31 --> Final output sent to browser
DEBUG - 2016-06-02 15:50:31 --> Total execution time: 0.0168
INFO - 2016-06-02 16:18:26 --> Config Class Initialized
INFO - 2016-06-02 16:18:26 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:18:26 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:18:26 --> Utf8 Class Initialized
INFO - 2016-06-02 16:18:26 --> URI Class Initialized
INFO - 2016-06-02 16:18:26 --> Router Class Initialized
INFO - 2016-06-02 16:18:26 --> Output Class Initialized
INFO - 2016-06-02 16:18:26 --> Security Class Initialized
DEBUG - 2016-06-02 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:18:26 --> CSRF cookie sent
INFO - 2016-06-02 16:18:26 --> Input Class Initialized
INFO - 2016-06-02 16:18:26 --> Language Class Initialized
INFO - 2016-06-02 16:18:26 --> Loader Class Initialized
INFO - 2016-06-02 16:18:26 --> Helper loaded: form_helper
INFO - 2016-06-02 16:18:26 --> Database Driver Class Initialized
INFO - 2016-06-02 16:18:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:18:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:18:26 --> Email Class Initialized
INFO - 2016-06-02 16:18:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:18:26 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:18:26 --> Helper loaded: language_helper
INFO - 2016-06-02 16:18:26 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:18:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:18:26 --> Model Class Initialized
INFO - 2016-06-02 16:18:26 --> Helper loaded: date_helper
INFO - 2016-06-02 16:18:26 --> Controller Class Initialized
INFO - 2016-06-02 16:18:26 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:18:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:18:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:18:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:18:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:18:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:18:26 --> Model Class Initialized
INFO - 2016-06-02 16:18:26 --> Form Validation Class Initialized
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:18:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:18:26 --> Final output sent to browser
DEBUG - 2016-06-02 16:18:26 --> Total execution time: 0.0853
INFO - 2016-06-02 16:18:33 --> Config Class Initialized
INFO - 2016-06-02 16:18:33 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:18:33 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:18:33 --> Utf8 Class Initialized
INFO - 2016-06-02 16:18:33 --> URI Class Initialized
INFO - 2016-06-02 16:18:33 --> Router Class Initialized
INFO - 2016-06-02 16:18:33 --> Output Class Initialized
INFO - 2016-06-02 16:18:33 --> Security Class Initialized
DEBUG - 2016-06-02 16:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:18:33 --> CSRF cookie sent
INFO - 2016-06-02 16:18:33 --> CSRF token verified
INFO - 2016-06-02 16:18:33 --> Input Class Initialized
INFO - 2016-06-02 16:18:33 --> Language Class Initialized
INFO - 2016-06-02 16:18:33 --> Loader Class Initialized
INFO - 2016-06-02 16:18:33 --> Helper loaded: form_helper
INFO - 2016-06-02 16:18:33 --> Database Driver Class Initialized
INFO - 2016-06-02 16:18:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:18:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:18:33 --> Email Class Initialized
INFO - 2016-06-02 16:18:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:18:33 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:18:33 --> Helper loaded: language_helper
INFO - 2016-06-02 16:18:33 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:18:33 --> Model Class Initialized
INFO - 2016-06-02 16:18:33 --> Helper loaded: date_helper
INFO - 2016-06-02 16:18:33 --> Controller Class Initialized
INFO - 2016-06-02 16:18:33 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:18:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:18:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:18:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:18:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:18:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:18:33 --> Model Class Initialized
INFO - 2016-06-02 16:18:33 --> Form Validation Class Initialized
INFO - 2016-06-02 16:18:33 --> Final output sent to browser
DEBUG - 2016-06-02 16:18:33 --> Total execution time: 0.0160
INFO - 2016-06-02 16:19:03 --> Config Class Initialized
INFO - 2016-06-02 16:19:03 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:19:03 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:19:03 --> Utf8 Class Initialized
INFO - 2016-06-02 16:19:03 --> URI Class Initialized
INFO - 2016-06-02 16:19:03 --> Router Class Initialized
INFO - 2016-06-02 16:19:03 --> Output Class Initialized
INFO - 2016-06-02 16:19:03 --> Security Class Initialized
DEBUG - 2016-06-02 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:19:03 --> CSRF cookie sent
INFO - 2016-06-02 16:19:03 --> Input Class Initialized
INFO - 2016-06-02 16:19:03 --> Language Class Initialized
INFO - 2016-06-02 16:19:03 --> Loader Class Initialized
INFO - 2016-06-02 16:19:03 --> Helper loaded: form_helper
INFO - 2016-06-02 16:19:03 --> Database Driver Class Initialized
INFO - 2016-06-02 16:19:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:19:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:19:03 --> Email Class Initialized
INFO - 2016-06-02 16:19:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:19:03 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:19:03 --> Helper loaded: language_helper
INFO - 2016-06-02 16:19:03 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:19:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:19:03 --> Model Class Initialized
INFO - 2016-06-02 16:19:03 --> Helper loaded: date_helper
INFO - 2016-06-02 16:19:03 --> Controller Class Initialized
INFO - 2016-06-02 16:19:03 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:19:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:19:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:19:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:19:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:19:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:19:03 --> Model Class Initialized
INFO - 2016-06-02 16:19:03 --> Form Validation Class Initialized
ERROR - 2016-06-02 16:19:03 --> Severity: Notice --> Use of undefined constant PERIOD - assumed 'PERIOD' /home/demis/www/platformadiabet/application/controllers/Diabet.php 367
ERROR - 2016-06-02 16:19:03 --> Query error: Undeclared variable: PERIOD - Invalid query: 
            SELECT 
                `date`,
                `interval_1`,
                `interval_2`,
                `interval_3`,
                `interval_4`,
                `interval_5`,
                `interval_6`,
                `interval_7`,
                `interval_8`,
                `interval_9`,
                `interval_10`,
                `notes`             
            FROM 
                1_glicemie 
            WHERE 
                `fk_user` = 2.
            AND 
                DATE(`date`) > (NOW() - INTERVAL PERIOD DAY)
            LIMIT
                PERIOD
            
        
INFO - 2016-06-02 16:24:26 --> Config Class Initialized
INFO - 2016-06-02 16:24:26 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:24:26 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:24:26 --> Utf8 Class Initialized
INFO - 2016-06-02 16:24:26 --> URI Class Initialized
INFO - 2016-06-02 16:24:26 --> Router Class Initialized
INFO - 2016-06-02 16:24:26 --> Output Class Initialized
INFO - 2016-06-02 16:24:26 --> Security Class Initialized
DEBUG - 2016-06-02 16:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:24:26 --> CSRF cookie sent
INFO - 2016-06-02 16:24:26 --> Input Class Initialized
INFO - 2016-06-02 16:24:26 --> Language Class Initialized
INFO - 2016-06-02 16:24:26 --> Loader Class Initialized
INFO - 2016-06-02 16:24:26 --> Helper loaded: form_helper
INFO - 2016-06-02 16:24:26 --> Database Driver Class Initialized
INFO - 2016-06-02 16:24:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:24:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:24:26 --> Email Class Initialized
INFO - 2016-06-02 16:24:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:24:26 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:24:26 --> Helper loaded: language_helper
INFO - 2016-06-02 16:24:26 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:24:26 --> Model Class Initialized
INFO - 2016-06-02 16:24:26 --> Helper loaded: date_helper
INFO - 2016-06-02 16:24:26 --> Controller Class Initialized
INFO - 2016-06-02 16:24:26 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:24:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:24:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:24:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:24:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:24:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:24:26 --> Model Class Initialized
INFO - 2016-06-02 16:24:26 --> Form Validation Class Initialized
INFO - 2016-06-02 16:24:26 --> Final output sent to browser
DEBUG - 2016-06-02 16:24:26 --> Total execution time: 0.0500
INFO - 2016-06-02 16:24:30 --> Config Class Initialized
INFO - 2016-06-02 16:24:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:24:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:24:30 --> Utf8 Class Initialized
INFO - 2016-06-02 16:24:30 --> URI Class Initialized
INFO - 2016-06-02 16:24:30 --> Router Class Initialized
INFO - 2016-06-02 16:24:30 --> Output Class Initialized
INFO - 2016-06-02 16:24:30 --> Security Class Initialized
DEBUG - 2016-06-02 16:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:24:30 --> CSRF cookie sent
INFO - 2016-06-02 16:24:30 --> Input Class Initialized
INFO - 2016-06-02 16:24:30 --> Language Class Initialized
INFO - 2016-06-02 16:24:30 --> Loader Class Initialized
INFO - 2016-06-02 16:24:30 --> Helper loaded: form_helper
INFO - 2016-06-02 16:24:30 --> Database Driver Class Initialized
INFO - 2016-06-02 16:24:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:24:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:24:30 --> Email Class Initialized
INFO - 2016-06-02 16:24:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:24:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:24:30 --> Helper loaded: language_helper
INFO - 2016-06-02 16:24:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:24:30 --> Model Class Initialized
INFO - 2016-06-02 16:24:30 --> Helper loaded: date_helper
INFO - 2016-06-02 16:24:30 --> Controller Class Initialized
INFO - 2016-06-02 16:24:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:24:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:24:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:24:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:24:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:24:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:24:30 --> Model Class Initialized
INFO - 2016-06-02 16:24:30 --> Form Validation Class Initialized
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:24:30 --> Final output sent to browser
DEBUG - 2016-06-02 16:24:30 --> Total execution time: 0.1351
INFO - 2016-06-02 16:24:36 --> Config Class Initialized
INFO - 2016-06-02 16:24:36 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:24:36 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:24:36 --> Utf8 Class Initialized
INFO - 2016-06-02 16:24:36 --> URI Class Initialized
INFO - 2016-06-02 16:24:36 --> Router Class Initialized
INFO - 2016-06-02 16:24:36 --> Output Class Initialized
INFO - 2016-06-02 16:24:36 --> Security Class Initialized
DEBUG - 2016-06-02 16:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:24:36 --> CSRF cookie sent
INFO - 2016-06-02 16:24:36 --> CSRF token verified
INFO - 2016-06-02 16:24:36 --> Input Class Initialized
INFO - 2016-06-02 16:24:36 --> Language Class Initialized
INFO - 2016-06-02 16:24:36 --> Loader Class Initialized
INFO - 2016-06-02 16:24:36 --> Helper loaded: form_helper
INFO - 2016-06-02 16:24:36 --> Database Driver Class Initialized
INFO - 2016-06-02 16:24:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:24:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:24:36 --> Email Class Initialized
INFO - 2016-06-02 16:24:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:24:36 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:24:36 --> Helper loaded: language_helper
INFO - 2016-06-02 16:24:36 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:24:36 --> Model Class Initialized
INFO - 2016-06-02 16:24:36 --> Helper loaded: date_helper
INFO - 2016-06-02 16:24:36 --> Controller Class Initialized
INFO - 2016-06-02 16:24:36 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:24:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:24:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:24:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:24:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:24:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:24:36 --> Model Class Initialized
INFO - 2016-06-02 16:24:36 --> Form Validation Class Initialized
ERROR - 2016-06-02 16:24:36 --> Severity: Error --> Call to undefined function runkit_constant_redefine() /home/demis/www/platformadiabet/application/controllers/Diabet.php 348
INFO - 2016-06-02 16:25:15 --> Config Class Initialized
INFO - 2016-06-02 16:25:15 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:25:15 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:25:15 --> Utf8 Class Initialized
INFO - 2016-06-02 16:25:15 --> URI Class Initialized
INFO - 2016-06-02 16:25:15 --> Router Class Initialized
INFO - 2016-06-02 16:25:15 --> Output Class Initialized
INFO - 2016-06-02 16:25:15 --> Security Class Initialized
DEBUG - 2016-06-02 16:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:25:15 --> CSRF cookie sent
INFO - 2016-06-02 16:25:15 --> Input Class Initialized
INFO - 2016-06-02 16:25:15 --> Language Class Initialized
INFO - 2016-06-02 16:25:15 --> Loader Class Initialized
INFO - 2016-06-02 16:25:15 --> Helper loaded: form_helper
INFO - 2016-06-02 16:25:15 --> Database Driver Class Initialized
INFO - 2016-06-02 16:25:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:25:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:25:15 --> Email Class Initialized
INFO - 2016-06-02 16:25:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:25:15 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:25:15 --> Helper loaded: language_helper
INFO - 2016-06-02 16:25:15 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:25:15 --> Model Class Initialized
INFO - 2016-06-02 16:25:15 --> Helper loaded: date_helper
INFO - 2016-06-02 16:25:15 --> Controller Class Initialized
INFO - 2016-06-02 16:25:15 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:25:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:25:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:25:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:25:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:25:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:25:15 --> Model Class Initialized
INFO - 2016-06-02 16:25:15 --> Form Validation Class Initialized
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:25:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:25:15 --> Final output sent to browser
DEBUG - 2016-06-02 16:25:15 --> Total execution time: 0.0655
INFO - 2016-06-02 16:25:20 --> Config Class Initialized
INFO - 2016-06-02 16:25:20 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:25:20 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:25:20 --> Utf8 Class Initialized
INFO - 2016-06-02 16:25:20 --> URI Class Initialized
INFO - 2016-06-02 16:25:20 --> Router Class Initialized
INFO - 2016-06-02 16:25:20 --> Output Class Initialized
INFO - 2016-06-02 16:25:20 --> Security Class Initialized
DEBUG - 2016-06-02 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:25:20 --> CSRF cookie sent
INFO - 2016-06-02 16:25:20 --> CSRF token verified
INFO - 2016-06-02 16:25:20 --> Input Class Initialized
INFO - 2016-06-02 16:25:20 --> Language Class Initialized
INFO - 2016-06-02 16:25:20 --> Loader Class Initialized
INFO - 2016-06-02 16:25:20 --> Helper loaded: form_helper
INFO - 2016-06-02 16:25:20 --> Database Driver Class Initialized
INFO - 2016-06-02 16:25:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:25:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:25:20 --> Email Class Initialized
INFO - 2016-06-02 16:25:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:25:20 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:25:20 --> Helper loaded: language_helper
INFO - 2016-06-02 16:25:20 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:25:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:25:20 --> Model Class Initialized
INFO - 2016-06-02 16:25:20 --> Helper loaded: date_helper
INFO - 2016-06-02 16:25:20 --> Controller Class Initialized
INFO - 2016-06-02 16:25:20 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:25:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:25:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:25:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:25:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:25:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:25:20 --> Model Class Initialized
INFO - 2016-06-02 16:25:20 --> Form Validation Class Initialized
ERROR - 2016-06-02 16:25:20 --> Severity: Error --> Call to undefined function runkit_constant_redefine() /home/demis/www/platformadiabet/application/controllers/Diabet.php 348
INFO - 2016-06-02 16:25:25 --> Config Class Initialized
INFO - 2016-06-02 16:25:25 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:25:25 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:25:25 --> Utf8 Class Initialized
INFO - 2016-06-02 16:25:25 --> URI Class Initialized
INFO - 2016-06-02 16:25:25 --> Router Class Initialized
INFO - 2016-06-02 16:25:25 --> Output Class Initialized
INFO - 2016-06-02 16:25:25 --> Security Class Initialized
DEBUG - 2016-06-02 16:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:25:25 --> CSRF cookie sent
INFO - 2016-06-02 16:25:25 --> Input Class Initialized
INFO - 2016-06-02 16:25:25 --> Language Class Initialized
INFO - 2016-06-02 16:25:25 --> Loader Class Initialized
INFO - 2016-06-02 16:25:25 --> Helper loaded: form_helper
INFO - 2016-06-02 16:25:25 --> Database Driver Class Initialized
INFO - 2016-06-02 16:25:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:25:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:25:25 --> Email Class Initialized
INFO - 2016-06-02 16:25:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:25:25 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:25:25 --> Helper loaded: language_helper
INFO - 2016-06-02 16:25:25 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:25:25 --> Model Class Initialized
INFO - 2016-06-02 16:25:25 --> Helper loaded: date_helper
INFO - 2016-06-02 16:25:25 --> Controller Class Initialized
INFO - 2016-06-02 16:25:25 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:25:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:25:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:25:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:25:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:25:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:25:26 --> Model Class Initialized
INFO - 2016-06-02 16:25:26 --> Form Validation Class Initialized
INFO - 2016-06-02 16:25:26 --> Final output sent to browser
DEBUG - 2016-06-02 16:25:26 --> Total execution time: 0.0878
INFO - 2016-06-02 16:25:50 --> Config Class Initialized
INFO - 2016-06-02 16:25:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:25:50 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:25:50 --> Utf8 Class Initialized
INFO - 2016-06-02 16:25:50 --> URI Class Initialized
INFO - 2016-06-02 16:25:50 --> Router Class Initialized
INFO - 2016-06-02 16:25:50 --> Output Class Initialized
INFO - 2016-06-02 16:25:50 --> Security Class Initialized
DEBUG - 2016-06-02 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:25:50 --> CSRF cookie sent
INFO - 2016-06-02 16:25:50 --> CSRF token verified
INFO - 2016-06-02 16:25:50 --> Input Class Initialized
INFO - 2016-06-02 16:25:50 --> Language Class Initialized
INFO - 2016-06-02 16:25:50 --> Loader Class Initialized
INFO - 2016-06-02 16:25:50 --> Helper loaded: form_helper
INFO - 2016-06-02 16:25:50 --> Database Driver Class Initialized
INFO - 2016-06-02 16:25:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:25:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:25:50 --> Email Class Initialized
INFO - 2016-06-02 16:25:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:25:50 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:25:50 --> Helper loaded: language_helper
INFO - 2016-06-02 16:25:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:25:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:25:50 --> Model Class Initialized
INFO - 2016-06-02 16:25:50 --> Helper loaded: date_helper
INFO - 2016-06-02 16:25:50 --> Controller Class Initialized
INFO - 2016-06-02 16:25:50 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:25:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:25:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:25:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:25:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:25:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:25:50 --> Model Class Initialized
INFO - 2016-06-02 16:25:50 --> Form Validation Class Initialized
ERROR - 2016-06-02 16:25:50 --> Severity: Error --> Call to undefined function runkit_constant_redefine() /home/demis/www/platformadiabet/application/controllers/Diabet.php 348
INFO - 2016-06-02 16:25:52 --> Config Class Initialized
INFO - 2016-06-02 16:25:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:25:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:25:52 --> Utf8 Class Initialized
INFO - 2016-06-02 16:25:52 --> URI Class Initialized
INFO - 2016-06-02 16:25:52 --> Router Class Initialized
INFO - 2016-06-02 16:25:52 --> Output Class Initialized
INFO - 2016-06-02 16:25:52 --> Security Class Initialized
DEBUG - 2016-06-02 16:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:25:52 --> CSRF cookie sent
INFO - 2016-06-02 16:25:52 --> Input Class Initialized
INFO - 2016-06-02 16:25:52 --> Language Class Initialized
INFO - 2016-06-02 16:25:52 --> Loader Class Initialized
INFO - 2016-06-02 16:25:52 --> Helper loaded: form_helper
INFO - 2016-06-02 16:25:52 --> Database Driver Class Initialized
INFO - 2016-06-02 16:25:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:25:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:25:52 --> Email Class Initialized
INFO - 2016-06-02 16:25:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:25:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:25:52 --> Helper loaded: language_helper
INFO - 2016-06-02 16:25:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:25:52 --> Model Class Initialized
INFO - 2016-06-02 16:25:52 --> Helper loaded: date_helper
INFO - 2016-06-02 16:25:52 --> Controller Class Initialized
INFO - 2016-06-02 16:25:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:25:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:25:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:25:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:25:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:25:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:25:52 --> Model Class Initialized
INFO - 2016-06-02 16:25:52 --> Form Validation Class Initialized
INFO - 2016-06-02 16:25:52 --> Final output sent to browser
DEBUG - 2016-06-02 16:25:52 --> Total execution time: 0.0188
INFO - 2016-06-02 16:26:22 --> Config Class Initialized
INFO - 2016-06-02 16:26:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:26:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:26:22 --> Utf8 Class Initialized
INFO - 2016-06-02 16:26:22 --> URI Class Initialized
INFO - 2016-06-02 16:26:22 --> Router Class Initialized
INFO - 2016-06-02 16:26:22 --> Output Class Initialized
INFO - 2016-06-02 16:26:22 --> Security Class Initialized
DEBUG - 2016-06-02 16:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:26:22 --> CSRF cookie sent
INFO - 2016-06-02 16:26:22 --> Input Class Initialized
INFO - 2016-06-02 16:26:22 --> Language Class Initialized
INFO - 2016-06-02 16:26:22 --> Loader Class Initialized
INFO - 2016-06-02 16:26:22 --> Helper loaded: form_helper
INFO - 2016-06-02 16:26:22 --> Database Driver Class Initialized
INFO - 2016-06-02 16:26:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:26:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:26:23 --> Email Class Initialized
INFO - 2016-06-02 16:26:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:26:23 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:26:23 --> Helper loaded: language_helper
INFO - 2016-06-02 16:26:23 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:26:23 --> Model Class Initialized
INFO - 2016-06-02 16:26:23 --> Helper loaded: date_helper
INFO - 2016-06-02 16:26:23 --> Controller Class Initialized
INFO - 2016-06-02 16:26:23 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:26:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:26:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:26:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:26:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:26:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:26:23 --> Model Class Initialized
INFO - 2016-06-02 16:26:23 --> Form Validation Class Initialized
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:26:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:26:23 --> Final output sent to browser
DEBUG - 2016-06-02 16:26:23 --> Total execution time: 0.1002
INFO - 2016-06-02 16:26:28 --> Config Class Initialized
INFO - 2016-06-02 16:26:28 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:26:28 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:26:28 --> Utf8 Class Initialized
INFO - 2016-06-02 16:26:28 --> URI Class Initialized
INFO - 2016-06-02 16:26:28 --> Router Class Initialized
INFO - 2016-06-02 16:26:28 --> Output Class Initialized
INFO - 2016-06-02 16:26:28 --> Security Class Initialized
DEBUG - 2016-06-02 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:26:28 --> CSRF cookie sent
INFO - 2016-06-02 16:26:28 --> CSRF token verified
INFO - 2016-06-02 16:26:28 --> Input Class Initialized
INFO - 2016-06-02 16:26:28 --> Language Class Initialized
INFO - 2016-06-02 16:26:28 --> Loader Class Initialized
INFO - 2016-06-02 16:26:28 --> Helper loaded: form_helper
INFO - 2016-06-02 16:26:28 --> Database Driver Class Initialized
INFO - 2016-06-02 16:26:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:26:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:26:28 --> Email Class Initialized
INFO - 2016-06-02 16:26:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:26:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:26:28 --> Helper loaded: language_helper
INFO - 2016-06-02 16:26:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:26:28 --> Model Class Initialized
INFO - 2016-06-02 16:26:28 --> Helper loaded: date_helper
INFO - 2016-06-02 16:26:28 --> Controller Class Initialized
INFO - 2016-06-02 16:26:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:26:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:26:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:26:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:26:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:26:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:26:28 --> Model Class Initialized
INFO - 2016-06-02 16:26:28 --> Form Validation Class Initialized
ERROR - 2016-06-02 16:26:28 --> Severity: Error --> Call to undefined function runkit_constant_redefine() /home/demis/www/platformadiabet/application/controllers/Diabet.php 348
INFO - 2016-06-02 16:40:22 --> Config Class Initialized
INFO - 2016-06-02 16:40:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:40:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:40:22 --> Utf8 Class Initialized
INFO - 2016-06-02 16:40:22 --> URI Class Initialized
INFO - 2016-06-02 16:40:22 --> Router Class Initialized
INFO - 2016-06-02 16:40:22 --> Output Class Initialized
INFO - 2016-06-02 16:40:22 --> Security Class Initialized
DEBUG - 2016-06-02 16:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:40:22 --> CSRF cookie sent
INFO - 2016-06-02 16:40:22 --> Input Class Initialized
INFO - 2016-06-02 16:40:22 --> Language Class Initialized
INFO - 2016-06-02 16:40:22 --> Loader Class Initialized
INFO - 2016-06-02 16:40:22 --> Helper loaded: form_helper
INFO - 2016-06-02 16:40:22 --> Database Driver Class Initialized
INFO - 2016-06-02 16:40:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:40:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:40:22 --> Email Class Initialized
INFO - 2016-06-02 16:40:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:40:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:40:22 --> Helper loaded: language_helper
INFO - 2016-06-02 16:40:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:40:22 --> Model Class Initialized
INFO - 2016-06-02 16:40:22 --> Helper loaded: date_helper
INFO - 2016-06-02 16:40:22 --> Controller Class Initialized
INFO - 2016-06-02 16:40:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:40:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:40:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:40:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:40:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:40:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:40:22 --> Model Class Initialized
INFO - 2016-06-02 16:40:22 --> Form Validation Class Initialized
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:40:22 --> Final output sent to browser
DEBUG - 2016-06-02 16:40:22 --> Total execution time: 0.0855
INFO - 2016-06-02 16:40:27 --> Config Class Initialized
INFO - 2016-06-02 16:40:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:40:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:40:27 --> Utf8 Class Initialized
INFO - 2016-06-02 16:40:27 --> URI Class Initialized
INFO - 2016-06-02 16:40:27 --> Router Class Initialized
INFO - 2016-06-02 16:40:27 --> Output Class Initialized
INFO - 2016-06-02 16:40:27 --> Security Class Initialized
DEBUG - 2016-06-02 16:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:40:27 --> CSRF cookie sent
INFO - 2016-06-02 16:40:27 --> CSRF token verified
INFO - 2016-06-02 16:40:27 --> Input Class Initialized
INFO - 2016-06-02 16:40:27 --> Language Class Initialized
INFO - 2016-06-02 16:40:27 --> Loader Class Initialized
INFO - 2016-06-02 16:40:27 --> Helper loaded: form_helper
INFO - 2016-06-02 16:40:27 --> Database Driver Class Initialized
INFO - 2016-06-02 16:40:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:40:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:40:27 --> Email Class Initialized
INFO - 2016-06-02 16:40:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:40:27 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:40:27 --> Helper loaded: language_helper
INFO - 2016-06-02 16:40:27 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:40:27 --> Model Class Initialized
INFO - 2016-06-02 16:40:27 --> Helper loaded: date_helper
INFO - 2016-06-02 16:40:27 --> Controller Class Initialized
INFO - 2016-06-02 16:40:27 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:40:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:40:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:40:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:40:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:40:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:40:27 --> Model Class Initialized
INFO - 2016-06-02 16:40:27 --> Form Validation Class Initialized
INFO - 2016-06-02 16:40:27 --> Final output sent to browser
DEBUG - 2016-06-02 16:40:27 --> Total execution time: 0.0627
INFO - 2016-06-02 16:40:56 --> Config Class Initialized
INFO - 2016-06-02 16:40:56 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:40:56 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:40:56 --> Utf8 Class Initialized
INFO - 2016-06-02 16:40:56 --> URI Class Initialized
INFO - 2016-06-02 16:40:56 --> Router Class Initialized
INFO - 2016-06-02 16:40:56 --> Output Class Initialized
INFO - 2016-06-02 16:40:56 --> Security Class Initialized
DEBUG - 2016-06-02 16:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:40:56 --> CSRF cookie sent
INFO - 2016-06-02 16:40:56 --> Input Class Initialized
INFO - 2016-06-02 16:40:56 --> Language Class Initialized
INFO - 2016-06-02 16:40:56 --> Loader Class Initialized
INFO - 2016-06-02 16:40:56 --> Helper loaded: form_helper
INFO - 2016-06-02 16:40:56 --> Database Driver Class Initialized
INFO - 2016-06-02 16:40:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:40:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:40:56 --> Email Class Initialized
INFO - 2016-06-02 16:40:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:40:56 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:40:56 --> Helper loaded: language_helper
INFO - 2016-06-02 16:40:56 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:40:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:40:56 --> Model Class Initialized
INFO - 2016-06-02 16:40:56 --> Helper loaded: date_helper
INFO - 2016-06-02 16:40:56 --> Controller Class Initialized
INFO - 2016-06-02 16:40:56 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:40:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:40:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:40:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:40:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:40:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:40:56 --> Model Class Initialized
INFO - 2016-06-02 16:40:56 --> Form Validation Class Initialized
ERROR - 2016-06-02 16:40:56 --> Severity: Notice --> Undefined variable: period_defined /home/demis/www/platformadiabet/application/controllers/Diabet.php 367
ERROR - 2016-06-02 16:40:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
            LIMIT' at line 19 - Invalid query: 
            SELECT 
                `date`,
                `interval_1`,
                `interval_2`,
                `interval_3`,
                `interval_4`,
                `interval_5`,
                `interval_6`,
                `interval_7`,
                `interval_8`,
                `interval_9`,
                `interval_10`,
                `notes`             
            FROM 
                1_glicemie 
            WHERE 
                `fk_user` = 2.
            AND 
                DATE(`date`) > (NOW() - INTERVAL  DAY)
            LIMIT
                
            
        
INFO - 2016-06-02 16:41:22 --> Config Class Initialized
INFO - 2016-06-02 16:41:22 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:41:22 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:41:22 --> Utf8 Class Initialized
INFO - 2016-06-02 16:41:22 --> URI Class Initialized
INFO - 2016-06-02 16:41:22 --> Router Class Initialized
INFO - 2016-06-02 16:41:22 --> Output Class Initialized
INFO - 2016-06-02 16:41:22 --> Security Class Initialized
DEBUG - 2016-06-02 16:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:41:22 --> CSRF cookie sent
INFO - 2016-06-02 16:41:22 --> Input Class Initialized
INFO - 2016-06-02 16:41:22 --> Language Class Initialized
INFO - 2016-06-02 16:41:22 --> Loader Class Initialized
INFO - 2016-06-02 16:41:22 --> Helper loaded: form_helper
INFO - 2016-06-02 16:41:22 --> Database Driver Class Initialized
INFO - 2016-06-02 16:41:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:41:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:41:22 --> Email Class Initialized
INFO - 2016-06-02 16:41:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:41:22 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:41:22 --> Helper loaded: language_helper
INFO - 2016-06-02 16:41:22 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:41:22 --> Model Class Initialized
INFO - 2016-06-02 16:41:22 --> Helper loaded: date_helper
INFO - 2016-06-02 16:41:22 --> Controller Class Initialized
INFO - 2016-06-02 16:41:22 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:41:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:41:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:41:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:41:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:41:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:41:22 --> Model Class Initialized
INFO - 2016-06-02 16:41:22 --> Form Validation Class Initialized
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:41:22 --> Final output sent to browser
DEBUG - 2016-06-02 16:41:22 --> Total execution time: 0.0535
INFO - 2016-06-02 16:41:26 --> Config Class Initialized
INFO - 2016-06-02 16:41:26 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:41:26 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:41:26 --> Utf8 Class Initialized
INFO - 2016-06-02 16:41:26 --> URI Class Initialized
INFO - 2016-06-02 16:41:26 --> Router Class Initialized
INFO - 2016-06-02 16:41:26 --> Output Class Initialized
INFO - 2016-06-02 16:41:26 --> Security Class Initialized
DEBUG - 2016-06-02 16:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:41:26 --> CSRF cookie sent
INFO - 2016-06-02 16:41:26 --> CSRF token verified
INFO - 2016-06-02 16:41:26 --> Input Class Initialized
INFO - 2016-06-02 16:41:26 --> Language Class Initialized
INFO - 2016-06-02 16:41:26 --> Loader Class Initialized
INFO - 2016-06-02 16:41:26 --> Helper loaded: form_helper
INFO - 2016-06-02 16:41:26 --> Database Driver Class Initialized
INFO - 2016-06-02 16:41:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:41:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:41:26 --> Email Class Initialized
INFO - 2016-06-02 16:41:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:41:26 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:41:26 --> Helper loaded: language_helper
INFO - 2016-06-02 16:41:26 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:41:26 --> Model Class Initialized
INFO - 2016-06-02 16:41:26 --> Helper loaded: date_helper
INFO - 2016-06-02 16:41:26 --> Controller Class Initialized
INFO - 2016-06-02 16:41:26 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:41:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:41:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:41:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:41:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:41:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:41:26 --> Model Class Initialized
INFO - 2016-06-02 16:41:26 --> Form Validation Class Initialized
INFO - 2016-06-02 16:41:26 --> Final output sent to browser
DEBUG - 2016-06-02 16:41:26 --> Total execution time: 0.0562
INFO - 2016-06-02 16:41:28 --> Config Class Initialized
INFO - 2016-06-02 16:41:28 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:41:28 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:41:28 --> Utf8 Class Initialized
INFO - 2016-06-02 16:41:28 --> URI Class Initialized
INFO - 2016-06-02 16:41:28 --> Router Class Initialized
INFO - 2016-06-02 16:41:28 --> Output Class Initialized
INFO - 2016-06-02 16:41:28 --> Security Class Initialized
DEBUG - 2016-06-02 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:41:28 --> CSRF cookie sent
INFO - 2016-06-02 16:41:28 --> Input Class Initialized
INFO - 2016-06-02 16:41:28 --> Language Class Initialized
INFO - 2016-06-02 16:41:28 --> Loader Class Initialized
INFO - 2016-06-02 16:41:28 --> Helper loaded: form_helper
INFO - 2016-06-02 16:41:28 --> Database Driver Class Initialized
INFO - 2016-06-02 16:41:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:41:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:41:28 --> Email Class Initialized
INFO - 2016-06-02 16:41:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:41:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:41:28 --> Helper loaded: language_helper
INFO - 2016-06-02 16:41:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:41:28 --> Model Class Initialized
INFO - 2016-06-02 16:41:28 --> Helper loaded: date_helper
INFO - 2016-06-02 16:41:28 --> Controller Class Initialized
INFO - 2016-06-02 16:41:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:41:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:41:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:41:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:41:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:41:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:41:28 --> Model Class Initialized
INFO - 2016-06-02 16:41:28 --> Form Validation Class Initialized
INFO - 2016-06-02 16:41:28 --> Final output sent to browser
DEBUG - 2016-06-02 16:41:28 --> Total execution time: 0.0345
INFO - 2016-06-02 16:41:42 --> Config Class Initialized
INFO - 2016-06-02 16:41:42 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:41:42 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:41:42 --> Utf8 Class Initialized
INFO - 2016-06-02 16:41:42 --> URI Class Initialized
INFO - 2016-06-02 16:41:42 --> Router Class Initialized
INFO - 2016-06-02 16:41:42 --> Output Class Initialized
INFO - 2016-06-02 16:41:42 --> Security Class Initialized
DEBUG - 2016-06-02 16:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:41:42 --> CSRF cookie sent
INFO - 2016-06-02 16:41:42 --> Input Class Initialized
INFO - 2016-06-02 16:41:42 --> Language Class Initialized
INFO - 2016-06-02 16:41:42 --> Loader Class Initialized
INFO - 2016-06-02 16:41:42 --> Helper loaded: form_helper
INFO - 2016-06-02 16:41:42 --> Database Driver Class Initialized
INFO - 2016-06-02 16:41:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:41:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:41:42 --> Email Class Initialized
INFO - 2016-06-02 16:41:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:41:42 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:41:42 --> Helper loaded: language_helper
INFO - 2016-06-02 16:41:42 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:41:42 --> Model Class Initialized
INFO - 2016-06-02 16:41:42 --> Helper loaded: date_helper
INFO - 2016-06-02 16:41:42 --> Controller Class Initialized
INFO - 2016-06-02 16:41:42 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:41:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:41:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:41:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:41:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:41:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:41:42 --> Model Class Initialized
INFO - 2016-06-02 16:41:42 --> Form Validation Class Initialized
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:41:42 --> Final output sent to browser
DEBUG - 2016-06-02 16:41:42 --> Total execution time: 0.0597
INFO - 2016-06-02 16:41:49 --> Config Class Initialized
INFO - 2016-06-02 16:41:49 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:41:49 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:41:49 --> Utf8 Class Initialized
INFO - 2016-06-02 16:41:49 --> URI Class Initialized
INFO - 2016-06-02 16:41:49 --> Router Class Initialized
INFO - 2016-06-02 16:41:49 --> Output Class Initialized
INFO - 2016-06-02 16:41:49 --> Security Class Initialized
DEBUG - 2016-06-02 16:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:41:49 --> CSRF cookie sent
INFO - 2016-06-02 16:41:49 --> CSRF token verified
INFO - 2016-06-02 16:41:49 --> Input Class Initialized
INFO - 2016-06-02 16:41:49 --> Language Class Initialized
INFO - 2016-06-02 16:41:49 --> Loader Class Initialized
INFO - 2016-06-02 16:41:49 --> Helper loaded: form_helper
INFO - 2016-06-02 16:41:49 --> Database Driver Class Initialized
INFO - 2016-06-02 16:41:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:41:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:41:49 --> Email Class Initialized
INFO - 2016-06-02 16:41:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:41:49 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:41:49 --> Helper loaded: language_helper
INFO - 2016-06-02 16:41:49 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:41:49 --> Model Class Initialized
INFO - 2016-06-02 16:41:49 --> Helper loaded: date_helper
INFO - 2016-06-02 16:41:49 --> Controller Class Initialized
INFO - 2016-06-02 16:41:49 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:41:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:41:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:41:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:41:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:41:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:41:49 --> Model Class Initialized
INFO - 2016-06-02 16:41:49 --> Form Validation Class Initialized
INFO - 2016-06-02 16:41:49 --> Final output sent to browser
DEBUG - 2016-06-02 16:41:49 --> Total execution time: 0.0314
INFO - 2016-06-02 16:41:53 --> Config Class Initialized
INFO - 2016-06-02 16:41:53 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:41:53 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:41:53 --> Utf8 Class Initialized
INFO - 2016-06-02 16:41:53 --> URI Class Initialized
INFO - 2016-06-02 16:41:53 --> Router Class Initialized
INFO - 2016-06-02 16:41:53 --> Output Class Initialized
INFO - 2016-06-02 16:41:53 --> Security Class Initialized
DEBUG - 2016-06-02 16:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:41:53 --> CSRF cookie sent
INFO - 2016-06-02 16:41:53 --> Input Class Initialized
INFO - 2016-06-02 16:41:53 --> Language Class Initialized
INFO - 2016-06-02 16:41:53 --> Loader Class Initialized
INFO - 2016-06-02 16:41:53 --> Helper loaded: form_helper
INFO - 2016-06-02 16:41:53 --> Database Driver Class Initialized
INFO - 2016-06-02 16:41:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:41:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:41:53 --> Email Class Initialized
INFO - 2016-06-02 16:41:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:41:53 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:41:53 --> Helper loaded: language_helper
INFO - 2016-06-02 16:41:53 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:41:53 --> Model Class Initialized
INFO - 2016-06-02 16:41:53 --> Helper loaded: date_helper
INFO - 2016-06-02 16:41:53 --> Controller Class Initialized
INFO - 2016-06-02 16:41:53 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:41:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:41:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:41:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:41:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:41:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:41:53 --> Model Class Initialized
INFO - 2016-06-02 16:41:53 --> Form Validation Class Initialized
INFO - 2016-06-02 16:41:53 --> Final output sent to browser
DEBUG - 2016-06-02 16:41:53 --> Total execution time: 0.0625
INFO - 2016-06-02 16:42:13 --> Config Class Initialized
INFO - 2016-06-02 16:42:13 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:42:13 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:42:13 --> Utf8 Class Initialized
INFO - 2016-06-02 16:42:13 --> URI Class Initialized
INFO - 2016-06-02 16:42:13 --> Router Class Initialized
INFO - 2016-06-02 16:42:13 --> Output Class Initialized
INFO - 2016-06-02 16:42:13 --> Security Class Initialized
DEBUG - 2016-06-02 16:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:42:13 --> CSRF cookie sent
INFO - 2016-06-02 16:42:13 --> CSRF token verified
INFO - 2016-06-02 16:42:13 --> Input Class Initialized
INFO - 2016-06-02 16:42:13 --> Language Class Initialized
INFO - 2016-06-02 16:42:13 --> Loader Class Initialized
INFO - 2016-06-02 16:42:13 --> Helper loaded: form_helper
INFO - 2016-06-02 16:42:13 --> Database Driver Class Initialized
INFO - 2016-06-02 16:42:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:42:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:42:13 --> Email Class Initialized
INFO - 2016-06-02 16:42:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:42:13 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:42:13 --> Helper loaded: language_helper
INFO - 2016-06-02 16:42:13 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:42:13 --> Model Class Initialized
INFO - 2016-06-02 16:42:13 --> Helper loaded: date_helper
INFO - 2016-06-02 16:42:13 --> Controller Class Initialized
INFO - 2016-06-02 16:42:13 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:42:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:42:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:42:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:42:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:42:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:42:13 --> Model Class Initialized
INFO - 2016-06-02 16:42:13 --> Form Validation Class Initialized
INFO - 2016-06-02 16:42:13 --> Final output sent to browser
DEBUG - 2016-06-02 16:42:13 --> Total execution time: 0.0415
INFO - 2016-06-02 16:42:17 --> Config Class Initialized
INFO - 2016-06-02 16:42:17 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:42:17 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:42:17 --> Utf8 Class Initialized
INFO - 2016-06-02 16:42:17 --> URI Class Initialized
INFO - 2016-06-02 16:42:17 --> Router Class Initialized
INFO - 2016-06-02 16:42:17 --> Output Class Initialized
INFO - 2016-06-02 16:42:17 --> Security Class Initialized
DEBUG - 2016-06-02 16:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:42:17 --> CSRF cookie sent
INFO - 2016-06-02 16:42:17 --> Input Class Initialized
INFO - 2016-06-02 16:42:17 --> Language Class Initialized
INFO - 2016-06-02 16:42:17 --> Loader Class Initialized
INFO - 2016-06-02 16:42:17 --> Helper loaded: form_helper
INFO - 2016-06-02 16:42:17 --> Database Driver Class Initialized
INFO - 2016-06-02 16:42:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:42:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:42:17 --> Email Class Initialized
INFO - 2016-06-02 16:42:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:42:17 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:42:17 --> Helper loaded: language_helper
INFO - 2016-06-02 16:42:17 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:42:17 --> Model Class Initialized
INFO - 2016-06-02 16:42:17 --> Helper loaded: date_helper
INFO - 2016-06-02 16:42:17 --> Controller Class Initialized
INFO - 2016-06-02 16:42:17 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:42:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:42:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:42:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:42:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:42:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:42:17 --> Model Class Initialized
INFO - 2016-06-02 16:42:17 --> Form Validation Class Initialized
INFO - 2016-06-02 16:42:17 --> Final output sent to browser
DEBUG - 2016-06-02 16:42:17 --> Total execution time: 0.0583
INFO - 2016-06-02 16:43:34 --> Config Class Initialized
INFO - 2016-06-02 16:43:34 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:43:34 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:43:34 --> Utf8 Class Initialized
INFO - 2016-06-02 16:43:34 --> URI Class Initialized
INFO - 2016-06-02 16:43:34 --> Router Class Initialized
INFO - 2016-06-02 16:43:34 --> Output Class Initialized
INFO - 2016-06-02 16:43:34 --> Security Class Initialized
DEBUG - 2016-06-02 16:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:43:34 --> CSRF cookie sent
INFO - 2016-06-02 16:43:34 --> Input Class Initialized
INFO - 2016-06-02 16:43:34 --> Language Class Initialized
INFO - 2016-06-02 16:43:34 --> Loader Class Initialized
INFO - 2016-06-02 16:43:34 --> Helper loaded: form_helper
INFO - 2016-06-02 16:43:34 --> Database Driver Class Initialized
INFO - 2016-06-02 16:43:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:43:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:43:34 --> Email Class Initialized
INFO - 2016-06-02 16:43:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:43:34 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:43:34 --> Helper loaded: language_helper
INFO - 2016-06-02 16:43:34 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:43:34 --> Model Class Initialized
INFO - 2016-06-02 16:43:34 --> Helper loaded: date_helper
INFO - 2016-06-02 16:43:34 --> Controller Class Initialized
INFO - 2016-06-02 16:43:34 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:43:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:43:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:43:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:43:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:43:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:43:34 --> Model Class Initialized
INFO - 2016-06-02 16:43:34 --> Form Validation Class Initialized
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:43:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:43:34 --> Final output sent to browser
DEBUG - 2016-06-02 16:43:34 --> Total execution time: 0.0430
INFO - 2016-06-02 16:43:40 --> Config Class Initialized
INFO - 2016-06-02 16:43:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:43:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:43:40 --> Utf8 Class Initialized
INFO - 2016-06-02 16:43:40 --> URI Class Initialized
INFO - 2016-06-02 16:43:40 --> Router Class Initialized
INFO - 2016-06-02 16:43:40 --> Output Class Initialized
INFO - 2016-06-02 16:43:40 --> Security Class Initialized
DEBUG - 2016-06-02 16:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:43:40 --> CSRF cookie sent
INFO - 2016-06-02 16:43:40 --> CSRF token verified
INFO - 2016-06-02 16:43:40 --> Input Class Initialized
INFO - 2016-06-02 16:43:40 --> Language Class Initialized
INFO - 2016-06-02 16:43:40 --> Loader Class Initialized
INFO - 2016-06-02 16:43:40 --> Helper loaded: form_helper
INFO - 2016-06-02 16:43:40 --> Database Driver Class Initialized
INFO - 2016-06-02 16:43:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:43:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:43:40 --> Email Class Initialized
INFO - 2016-06-02 16:43:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:43:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:43:40 --> Helper loaded: language_helper
INFO - 2016-06-02 16:43:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:43:40 --> Model Class Initialized
INFO - 2016-06-02 16:43:40 --> Helper loaded: date_helper
INFO - 2016-06-02 16:43:40 --> Controller Class Initialized
INFO - 2016-06-02 16:43:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:43:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:43:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:43:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:43:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:43:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:43:40 --> Model Class Initialized
INFO - 2016-06-02 16:43:40 --> Form Validation Class Initialized
INFO - 2016-06-02 16:43:40 --> Final output sent to browser
DEBUG - 2016-06-02 16:43:40 --> Total execution time: 0.0341
INFO - 2016-06-02 16:43:42 --> Config Class Initialized
INFO - 2016-06-02 16:43:42 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:43:42 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:43:42 --> Utf8 Class Initialized
INFO - 2016-06-02 16:43:42 --> URI Class Initialized
INFO - 2016-06-02 16:43:42 --> Router Class Initialized
INFO - 2016-06-02 16:43:42 --> Output Class Initialized
INFO - 2016-06-02 16:43:42 --> Security Class Initialized
DEBUG - 2016-06-02 16:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:43:42 --> CSRF cookie sent
INFO - 2016-06-02 16:43:42 --> Input Class Initialized
INFO - 2016-06-02 16:43:42 --> Language Class Initialized
INFO - 2016-06-02 16:43:42 --> Loader Class Initialized
INFO - 2016-06-02 16:43:42 --> Helper loaded: form_helper
INFO - 2016-06-02 16:43:42 --> Database Driver Class Initialized
INFO - 2016-06-02 16:43:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:43:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:43:42 --> Email Class Initialized
INFO - 2016-06-02 16:43:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:43:42 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:43:42 --> Helper loaded: language_helper
INFO - 2016-06-02 16:43:42 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:43:42 --> Model Class Initialized
INFO - 2016-06-02 16:43:42 --> Helper loaded: date_helper
INFO - 2016-06-02 16:43:42 --> Controller Class Initialized
INFO - 2016-06-02 16:43:42 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:43:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:43:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:43:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:43:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:43:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:43:42 --> Model Class Initialized
INFO - 2016-06-02 16:43:42 --> Form Validation Class Initialized
INFO - 2016-06-02 16:43:42 --> Final output sent to browser
DEBUG - 2016-06-02 16:43:42 --> Total execution time: 0.0139
INFO - 2016-06-02 16:44:46 --> Config Class Initialized
INFO - 2016-06-02 16:44:46 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:44:46 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:44:46 --> Utf8 Class Initialized
INFO - 2016-06-02 16:44:46 --> URI Class Initialized
INFO - 2016-06-02 16:44:46 --> Router Class Initialized
INFO - 2016-06-02 16:44:46 --> Output Class Initialized
INFO - 2016-06-02 16:44:46 --> Security Class Initialized
DEBUG - 2016-06-02 16:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:44:46 --> CSRF cookie sent
INFO - 2016-06-02 16:44:46 --> Input Class Initialized
INFO - 2016-06-02 16:44:46 --> Language Class Initialized
INFO - 2016-06-02 16:44:46 --> Loader Class Initialized
INFO - 2016-06-02 16:44:46 --> Helper loaded: form_helper
INFO - 2016-06-02 16:44:46 --> Database Driver Class Initialized
INFO - 2016-06-02 16:44:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:44:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:44:46 --> Email Class Initialized
INFO - 2016-06-02 16:44:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:44:46 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:44:46 --> Helper loaded: language_helper
INFO - 2016-06-02 16:44:46 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:44:46 --> Model Class Initialized
INFO - 2016-06-02 16:44:46 --> Helper loaded: date_helper
INFO - 2016-06-02 16:44:46 --> Controller Class Initialized
INFO - 2016-06-02 16:44:46 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:44:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:44:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:44:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:44:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:44:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:44:46 --> Model Class Initialized
INFO - 2016-06-02 16:44:46 --> Form Validation Class Initialized
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:44:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:44:46 --> Final output sent to browser
DEBUG - 2016-06-02 16:44:46 --> Total execution time: 0.0652
INFO - 2016-06-02 16:44:50 --> Config Class Initialized
INFO - 2016-06-02 16:44:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:44:50 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:44:50 --> Utf8 Class Initialized
INFO - 2016-06-02 16:44:50 --> URI Class Initialized
INFO - 2016-06-02 16:44:50 --> Router Class Initialized
INFO - 2016-06-02 16:44:50 --> Output Class Initialized
INFO - 2016-06-02 16:44:50 --> Security Class Initialized
DEBUG - 2016-06-02 16:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:44:50 --> CSRF cookie sent
INFO - 2016-06-02 16:44:50 --> CSRF token verified
INFO - 2016-06-02 16:44:50 --> Input Class Initialized
INFO - 2016-06-02 16:44:50 --> Language Class Initialized
INFO - 2016-06-02 16:44:50 --> Loader Class Initialized
INFO - 2016-06-02 16:44:50 --> Helper loaded: form_helper
INFO - 2016-06-02 16:44:50 --> Database Driver Class Initialized
INFO - 2016-06-02 16:44:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:44:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:44:50 --> Email Class Initialized
INFO - 2016-06-02 16:44:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:44:50 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:44:50 --> Helper loaded: language_helper
INFO - 2016-06-02 16:44:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:44:50 --> Model Class Initialized
INFO - 2016-06-02 16:44:50 --> Helper loaded: date_helper
INFO - 2016-06-02 16:44:50 --> Controller Class Initialized
INFO - 2016-06-02 16:44:50 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:44:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:44:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:44:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:44:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:44:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:44:50 --> Model Class Initialized
INFO - 2016-06-02 16:44:50 --> Form Validation Class Initialized
INFO - 2016-06-02 16:44:50 --> Final output sent to browser
DEBUG - 2016-06-02 16:44:50 --> Total execution time: 0.0314
INFO - 2016-06-02 16:44:57 --> Config Class Initialized
INFO - 2016-06-02 16:44:57 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:44:57 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:44:57 --> Utf8 Class Initialized
INFO - 2016-06-02 16:44:57 --> URI Class Initialized
INFO - 2016-06-02 16:44:57 --> Router Class Initialized
INFO - 2016-06-02 16:44:57 --> Output Class Initialized
INFO - 2016-06-02 16:44:57 --> Security Class Initialized
DEBUG - 2016-06-02 16:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:44:57 --> CSRF cookie sent
INFO - 2016-06-02 16:44:57 --> Input Class Initialized
INFO - 2016-06-02 16:44:57 --> Language Class Initialized
INFO - 2016-06-02 16:44:57 --> Loader Class Initialized
INFO - 2016-06-02 16:44:57 --> Helper loaded: form_helper
INFO - 2016-06-02 16:44:57 --> Database Driver Class Initialized
INFO - 2016-06-02 16:44:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:44:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:44:57 --> Email Class Initialized
INFO - 2016-06-02 16:44:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:44:57 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:44:57 --> Helper loaded: language_helper
INFO - 2016-06-02 16:44:57 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:44:57 --> Model Class Initialized
INFO - 2016-06-02 16:44:57 --> Helper loaded: date_helper
INFO - 2016-06-02 16:44:57 --> Controller Class Initialized
INFO - 2016-06-02 16:44:57 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:44:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:44:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:44:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:44:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:44:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:44:57 --> Model Class Initialized
INFO - 2016-06-02 16:44:57 --> Form Validation Class Initialized
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:44:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:44:57 --> Final output sent to browser
DEBUG - 2016-06-02 16:44:57 --> Total execution time: 0.0209
INFO - 2016-06-02 16:45:05 --> Config Class Initialized
INFO - 2016-06-02 16:45:05 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:45:05 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:45:05 --> Utf8 Class Initialized
INFO - 2016-06-02 16:45:05 --> URI Class Initialized
INFO - 2016-06-02 16:45:05 --> Router Class Initialized
INFO - 2016-06-02 16:45:05 --> Output Class Initialized
INFO - 2016-06-02 16:45:05 --> Security Class Initialized
DEBUG - 2016-06-02 16:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:45:05 --> CSRF cookie sent
INFO - 2016-06-02 16:45:05 --> CSRF token verified
INFO - 2016-06-02 16:45:05 --> Input Class Initialized
INFO - 2016-06-02 16:45:05 --> Language Class Initialized
INFO - 2016-06-02 16:45:05 --> Loader Class Initialized
INFO - 2016-06-02 16:45:05 --> Helper loaded: form_helper
INFO - 2016-06-02 16:45:05 --> Database Driver Class Initialized
INFO - 2016-06-02 16:45:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:45:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:45:05 --> Email Class Initialized
INFO - 2016-06-02 16:45:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:45:05 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:45:05 --> Helper loaded: language_helper
INFO - 2016-06-02 16:45:05 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:45:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:45:05 --> Model Class Initialized
INFO - 2016-06-02 16:45:05 --> Helper loaded: date_helper
INFO - 2016-06-02 16:45:05 --> Controller Class Initialized
INFO - 2016-06-02 16:45:05 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:45:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:45:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:45:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:45:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:45:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:45:05 --> Model Class Initialized
INFO - 2016-06-02 16:45:05 --> Form Validation Class Initialized
INFO - 2016-06-02 16:45:05 --> Final output sent to browser
DEBUG - 2016-06-02 16:45:05 --> Total execution time: 0.0602
INFO - 2016-06-02 16:45:07 --> Config Class Initialized
INFO - 2016-06-02 16:45:07 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:45:07 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:45:07 --> Utf8 Class Initialized
INFO - 2016-06-02 16:45:07 --> URI Class Initialized
INFO - 2016-06-02 16:45:07 --> Router Class Initialized
INFO - 2016-06-02 16:45:07 --> Output Class Initialized
INFO - 2016-06-02 16:45:07 --> Security Class Initialized
DEBUG - 2016-06-02 16:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:45:07 --> CSRF cookie sent
INFO - 2016-06-02 16:45:07 --> Input Class Initialized
INFO - 2016-06-02 16:45:07 --> Language Class Initialized
INFO - 2016-06-02 16:45:07 --> Loader Class Initialized
INFO - 2016-06-02 16:45:07 --> Helper loaded: form_helper
INFO - 2016-06-02 16:45:07 --> Database Driver Class Initialized
INFO - 2016-06-02 16:45:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:45:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:45:07 --> Email Class Initialized
INFO - 2016-06-02 16:45:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:45:07 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:45:07 --> Helper loaded: language_helper
INFO - 2016-06-02 16:45:07 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:45:07 --> Model Class Initialized
INFO - 2016-06-02 16:45:07 --> Helper loaded: date_helper
INFO - 2016-06-02 16:45:07 --> Controller Class Initialized
INFO - 2016-06-02 16:45:07 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:45:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:45:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:45:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:45:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:45:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:45:07 --> Model Class Initialized
INFO - 2016-06-02 16:45:07 --> Form Validation Class Initialized
INFO - 2016-06-02 16:45:07 --> Database Utility Class Initialized
INFO - 2016-06-02 16:45:07 --> Helper loaded: file_helper
INFO - 2016-06-02 16:45:07 --> Helper loaded: download_helper
ERROR - 2016-06-02 16:45:07 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given /home/demis/www/platformadiabet/system/database/DB_driver.php 1047
ERROR - 2016-06-02 16:45:07 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given /home/demis/www/platformadiabet/system/database/drivers/mysqli/mysqli_driver.php 322
ERROR - 2016-06-02 16:45:07 --> Severity: Warning --> mysqli::query() expects parameter 1 to be string, object given /home/demis/www/platformadiabet/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2016-06-02 16:45:07 --> Severity: Error --> Call to a member function field_seek() on null /home/demis/www/platformadiabet/system/database/drivers/mysqli/mysqli_result.php 89
INFO - 2016-06-02 16:57:37 --> Config Class Initialized
INFO - 2016-06-02 16:57:37 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:57:37 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:57:37 --> Utf8 Class Initialized
INFO - 2016-06-02 16:57:37 --> URI Class Initialized
INFO - 2016-06-02 16:57:37 --> Router Class Initialized
INFO - 2016-06-02 16:57:37 --> Output Class Initialized
INFO - 2016-06-02 16:57:37 --> Security Class Initialized
DEBUG - 2016-06-02 16:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:57:37 --> CSRF cookie sent
INFO - 2016-06-02 16:57:37 --> Input Class Initialized
INFO - 2016-06-02 16:57:37 --> Language Class Initialized
INFO - 2016-06-02 16:57:37 --> Loader Class Initialized
INFO - 2016-06-02 16:57:37 --> Helper loaded: form_helper
INFO - 2016-06-02 16:57:37 --> Database Driver Class Initialized
INFO - 2016-06-02 16:57:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:57:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:57:37 --> Email Class Initialized
INFO - 2016-06-02 16:57:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:57:37 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:57:37 --> Helper loaded: language_helper
INFO - 2016-06-02 16:57:37 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:57:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:57:37 --> Model Class Initialized
INFO - 2016-06-02 16:57:37 --> Helper loaded: date_helper
INFO - 2016-06-02 16:57:37 --> Controller Class Initialized
INFO - 2016-06-02 16:57:37 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:57:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:57:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:57:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:57:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:57:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:57:37 --> Model Class Initialized
INFO - 2016-06-02 16:57:37 --> Form Validation Class Initialized
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 16:57:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 16:57:37 --> Final output sent to browser
DEBUG - 2016-06-02 16:57:37 --> Total execution time: 0.0493
INFO - 2016-06-02 16:57:42 --> Config Class Initialized
INFO - 2016-06-02 16:57:42 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:57:42 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:57:42 --> Utf8 Class Initialized
INFO - 2016-06-02 16:57:42 --> URI Class Initialized
INFO - 2016-06-02 16:57:42 --> Router Class Initialized
INFO - 2016-06-02 16:57:42 --> Output Class Initialized
INFO - 2016-06-02 16:57:42 --> Security Class Initialized
DEBUG - 2016-06-02 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:57:42 --> CSRF cookie sent
INFO - 2016-06-02 16:57:42 --> CSRF token verified
INFO - 2016-06-02 16:57:42 --> Input Class Initialized
INFO - 2016-06-02 16:57:42 --> Language Class Initialized
INFO - 2016-06-02 16:57:42 --> Loader Class Initialized
INFO - 2016-06-02 16:57:42 --> Helper loaded: form_helper
INFO - 2016-06-02 16:57:42 --> Database Driver Class Initialized
INFO - 2016-06-02 16:57:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:57:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:57:42 --> Email Class Initialized
INFO - 2016-06-02 16:57:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:57:42 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:57:42 --> Helper loaded: language_helper
INFO - 2016-06-02 16:57:42 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:57:42 --> Model Class Initialized
INFO - 2016-06-02 16:57:42 --> Helper loaded: date_helper
INFO - 2016-06-02 16:57:42 --> Controller Class Initialized
INFO - 2016-06-02 16:57:42 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:57:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:57:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:57:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:57:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:57:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:57:42 --> Model Class Initialized
INFO - 2016-06-02 16:57:42 --> Form Validation Class Initialized
INFO - 2016-06-02 16:57:42 --> Final output sent to browser
DEBUG - 2016-06-02 16:57:42 --> Total execution time: 0.0426
INFO - 2016-06-02 16:57:46 --> Config Class Initialized
INFO - 2016-06-02 16:57:46 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:57:46 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:57:46 --> Utf8 Class Initialized
INFO - 2016-06-02 16:57:46 --> URI Class Initialized
INFO - 2016-06-02 16:57:46 --> Router Class Initialized
INFO - 2016-06-02 16:57:46 --> Output Class Initialized
INFO - 2016-06-02 16:57:46 --> Security Class Initialized
DEBUG - 2016-06-02 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:57:46 --> CSRF cookie sent
INFO - 2016-06-02 16:57:46 --> Input Class Initialized
INFO - 2016-06-02 16:57:46 --> Language Class Initialized
INFO - 2016-06-02 16:57:46 --> Loader Class Initialized
INFO - 2016-06-02 16:57:46 --> Helper loaded: form_helper
INFO - 2016-06-02 16:57:46 --> Database Driver Class Initialized
INFO - 2016-06-02 16:57:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:57:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:57:46 --> Email Class Initialized
INFO - 2016-06-02 16:57:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:57:46 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:57:46 --> Helper loaded: language_helper
INFO - 2016-06-02 16:57:46 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:57:46 --> Model Class Initialized
INFO - 2016-06-02 16:57:46 --> Helper loaded: date_helper
INFO - 2016-06-02 16:57:46 --> Controller Class Initialized
INFO - 2016-06-02 16:57:46 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:57:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:57:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:57:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:57:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:57:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:57:46 --> Model Class Initialized
INFO - 2016-06-02 16:57:46 --> Form Validation Class Initialized
INFO - 2016-06-02 16:57:46 --> Database Utility Class Initialized
INFO - 2016-06-02 16:57:46 --> Helper loaded: file_helper
INFO - 2016-06-02 16:57:46 --> Helper loaded: download_helper
ERROR - 2016-06-02 16:57:46 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given /home/demis/www/platformadiabet/system/database/DB_driver.php 1047
ERROR - 2016-06-02 16:57:46 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given /home/demis/www/platformadiabet/system/database/drivers/mysqli/mysqli_driver.php 322
ERROR - 2016-06-02 16:57:46 --> Severity: Warning --> mysqli::query() expects parameter 1 to be string, object given /home/demis/www/platformadiabet/system/database/drivers/mysqli/mysqli_driver.php 305
INFO - 2016-06-02 16:58:42 --> Config Class Initialized
INFO - 2016-06-02 16:58:42 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:58:42 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:58:42 --> Utf8 Class Initialized
INFO - 2016-06-02 16:58:42 --> URI Class Initialized
INFO - 2016-06-02 16:58:42 --> Router Class Initialized
INFO - 2016-06-02 16:58:42 --> Output Class Initialized
INFO - 2016-06-02 16:58:42 --> Security Class Initialized
DEBUG - 2016-06-02 16:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:58:42 --> CSRF cookie sent
INFO - 2016-06-02 16:58:42 --> Input Class Initialized
INFO - 2016-06-02 16:58:42 --> Language Class Initialized
INFO - 2016-06-02 16:58:42 --> Loader Class Initialized
INFO - 2016-06-02 16:58:42 --> Helper loaded: form_helper
INFO - 2016-06-02 16:58:42 --> Database Driver Class Initialized
INFO - 2016-06-02 16:58:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:58:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:58:42 --> Email Class Initialized
INFO - 2016-06-02 16:58:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:58:42 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:58:42 --> Helper loaded: language_helper
INFO - 2016-06-02 16:58:42 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:58:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:58:42 --> Model Class Initialized
INFO - 2016-06-02 16:58:42 --> Helper loaded: date_helper
INFO - 2016-06-02 16:58:42 --> Controller Class Initialized
INFO - 2016-06-02 16:58:42 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:58:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:58:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:58:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:58:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:58:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:58:42 --> Model Class Initialized
INFO - 2016-06-02 16:58:42 --> Form Validation Class Initialized
INFO - 2016-06-02 16:58:42 --> Database Utility Class Initialized
INFO - 2016-06-02 16:58:42 --> Helper loaded: file_helper
INFO - 2016-06-02 16:58:42 --> Helper loaded: download_helper
INFO - 2016-06-02 16:59:32 --> Config Class Initialized
INFO - 2016-06-02 16:59:32 --> Hooks Class Initialized
DEBUG - 2016-06-02 16:59:32 --> UTF-8 Support Enabled
INFO - 2016-06-02 16:59:32 --> Utf8 Class Initialized
INFO - 2016-06-02 16:59:32 --> URI Class Initialized
INFO - 2016-06-02 16:59:32 --> Router Class Initialized
INFO - 2016-06-02 16:59:32 --> Output Class Initialized
INFO - 2016-06-02 16:59:32 --> Security Class Initialized
DEBUG - 2016-06-02 16:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 16:59:32 --> CSRF cookie sent
INFO - 2016-06-02 16:59:32 --> Input Class Initialized
INFO - 2016-06-02 16:59:32 --> Language Class Initialized
INFO - 2016-06-02 16:59:32 --> Loader Class Initialized
INFO - 2016-06-02 16:59:32 --> Helper loaded: form_helper
INFO - 2016-06-02 16:59:32 --> Database Driver Class Initialized
INFO - 2016-06-02 16:59:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 16:59:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 16:59:32 --> Email Class Initialized
INFO - 2016-06-02 16:59:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 16:59:32 --> Helper loaded: cookie_helper
INFO - 2016-06-02 16:59:32 --> Helper loaded: language_helper
INFO - 2016-06-02 16:59:32 --> Helper loaded: url_helper
DEBUG - 2016-06-02 16:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 16:59:32 --> Model Class Initialized
INFO - 2016-06-02 16:59:32 --> Helper loaded: date_helper
INFO - 2016-06-02 16:59:32 --> Controller Class Initialized
INFO - 2016-06-02 16:59:32 --> Helper loaded: languages_helper
INFO - 2016-06-02 16:59:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 16:59:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 16:59:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 16:59:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 16:59:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 16:59:32 --> Model Class Initialized
INFO - 2016-06-02 16:59:32 --> Form Validation Class Initialized
INFO - 2016-06-02 16:59:32 --> Database Utility Class Initialized
INFO - 2016-06-02 16:59:32 --> Helper loaded: file_helper
INFO - 2016-06-02 16:59:32 --> Helper loaded: download_helper
ERROR - 2016-06-02 16:59:32 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given /home/demis/www/platformadiabet/system/database/DB_driver.php 1047
ERROR - 2016-06-02 16:59:32 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given /home/demis/www/platformadiabet/system/database/drivers/mysqli/mysqli_driver.php 322
ERROR - 2016-06-02 16:59:32 --> Severity: Warning --> mysqli::query() expects parameter 1 to be string, object given /home/demis/www/platformadiabet/system/database/drivers/mysqli/mysqli_driver.php 305
INFO - 2016-06-02 17:01:52 --> Config Class Initialized
INFO - 2016-06-02 17:01:52 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:01:52 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:01:52 --> Utf8 Class Initialized
INFO - 2016-06-02 17:01:52 --> URI Class Initialized
INFO - 2016-06-02 17:01:52 --> Router Class Initialized
INFO - 2016-06-02 17:01:52 --> Output Class Initialized
INFO - 2016-06-02 17:01:52 --> Security Class Initialized
DEBUG - 2016-06-02 17:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:01:52 --> CSRF cookie sent
INFO - 2016-06-02 17:01:52 --> Input Class Initialized
INFO - 2016-06-02 17:01:52 --> Language Class Initialized
INFO - 2016-06-02 17:01:52 --> Loader Class Initialized
INFO - 2016-06-02 17:01:52 --> Helper loaded: form_helper
INFO - 2016-06-02 17:01:52 --> Database Driver Class Initialized
INFO - 2016-06-02 17:01:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:01:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:01:52 --> Email Class Initialized
INFO - 2016-06-02 17:01:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:01:52 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:01:52 --> Helper loaded: language_helper
INFO - 2016-06-02 17:01:52 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:01:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:01:52 --> Model Class Initialized
INFO - 2016-06-02 17:01:52 --> Helper loaded: date_helper
INFO - 2016-06-02 17:01:52 --> Controller Class Initialized
INFO - 2016-06-02 17:01:52 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:01:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:01:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:01:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:01:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:01:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:01:52 --> Model Class Initialized
INFO - 2016-06-02 17:01:52 --> Form Validation Class Initialized
INFO - 2016-06-02 17:01:52 --> Database Utility Class Initialized
INFO - 2016-06-02 17:01:52 --> Helper loaded: file_helper
INFO - 2016-06-02 17:01:52 --> Helper loaded: download_helper
INFO - 2016-06-02 17:02:47 --> Config Class Initialized
INFO - 2016-06-02 17:02:47 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:02:47 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:02:47 --> Utf8 Class Initialized
INFO - 2016-06-02 17:02:47 --> URI Class Initialized
INFO - 2016-06-02 17:02:47 --> Router Class Initialized
INFO - 2016-06-02 17:02:47 --> Output Class Initialized
INFO - 2016-06-02 17:02:47 --> Security Class Initialized
DEBUG - 2016-06-02 17:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:02:47 --> CSRF cookie sent
INFO - 2016-06-02 17:02:47 --> Input Class Initialized
INFO - 2016-06-02 17:02:47 --> Language Class Initialized
INFO - 2016-06-02 17:02:47 --> Loader Class Initialized
INFO - 2016-06-02 17:02:47 --> Helper loaded: form_helper
INFO - 2016-06-02 17:02:47 --> Database Driver Class Initialized
INFO - 2016-06-02 17:02:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:02:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:02:47 --> Email Class Initialized
INFO - 2016-06-02 17:02:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:02:47 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:02:47 --> Helper loaded: language_helper
INFO - 2016-06-02 17:02:47 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:02:47 --> Model Class Initialized
INFO - 2016-06-02 17:02:47 --> Helper loaded: date_helper
INFO - 2016-06-02 17:02:47 --> Controller Class Initialized
INFO - 2016-06-02 17:02:47 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:02:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:02:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:02:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:02:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:02:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:02:47 --> Model Class Initialized
INFO - 2016-06-02 17:02:47 --> Form Validation Class Initialized
INFO - 2016-06-02 17:02:47 --> Database Utility Class Initialized
INFO - 2016-06-02 17:02:47 --> Helper loaded: file_helper
INFO - 2016-06-02 17:02:47 --> Helper loaded: download_helper
INFO - 2016-06-02 17:03:50 --> Config Class Initialized
INFO - 2016-06-02 17:03:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:03:50 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:03:50 --> Utf8 Class Initialized
INFO - 2016-06-02 17:03:50 --> URI Class Initialized
INFO - 2016-06-02 17:03:50 --> Router Class Initialized
INFO - 2016-06-02 17:03:50 --> Output Class Initialized
INFO - 2016-06-02 17:03:50 --> Security Class Initialized
DEBUG - 2016-06-02 17:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:03:50 --> CSRF cookie sent
INFO - 2016-06-02 17:03:50 --> Input Class Initialized
INFO - 2016-06-02 17:03:50 --> Language Class Initialized
INFO - 2016-06-02 17:03:50 --> Loader Class Initialized
INFO - 2016-06-02 17:03:50 --> Helper loaded: form_helper
INFO - 2016-06-02 17:03:50 --> Database Driver Class Initialized
INFO - 2016-06-02 17:03:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:03:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:03:50 --> Email Class Initialized
INFO - 2016-06-02 17:03:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:03:50 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:03:50 --> Helper loaded: language_helper
INFO - 2016-06-02 17:03:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:03:50 --> Model Class Initialized
INFO - 2016-06-02 17:03:50 --> Helper loaded: date_helper
INFO - 2016-06-02 17:03:50 --> Controller Class Initialized
INFO - 2016-06-02 17:03:50 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:03:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:03:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:03:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:03:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:03:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:03:50 --> Model Class Initialized
INFO - 2016-06-02 17:03:50 --> Form Validation Class Initialized
INFO - 2016-06-02 17:03:50 --> Database Utility Class Initialized
INFO - 2016-06-02 17:03:50 --> Helper loaded: file_helper
INFO - 2016-06-02 17:03:50 --> Helper loaded: download_helper
INFO - 2016-06-02 17:04:41 --> Config Class Initialized
INFO - 2016-06-02 17:04:41 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:04:41 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:04:41 --> Utf8 Class Initialized
INFO - 2016-06-02 17:04:41 --> URI Class Initialized
INFO - 2016-06-02 17:04:41 --> Router Class Initialized
INFO - 2016-06-02 17:04:41 --> Output Class Initialized
INFO - 2016-06-02 17:04:41 --> Security Class Initialized
DEBUG - 2016-06-02 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:04:41 --> CSRF cookie sent
INFO - 2016-06-02 17:04:41 --> Input Class Initialized
INFO - 2016-06-02 17:04:41 --> Language Class Initialized
INFO - 2016-06-02 17:04:41 --> Loader Class Initialized
INFO - 2016-06-02 17:04:41 --> Helper loaded: form_helper
INFO - 2016-06-02 17:04:41 --> Database Driver Class Initialized
INFO - 2016-06-02 17:04:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:04:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:04:41 --> Email Class Initialized
INFO - 2016-06-02 17:04:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:04:41 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:04:41 --> Helper loaded: language_helper
INFO - 2016-06-02 17:04:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:04:41 --> Model Class Initialized
INFO - 2016-06-02 17:04:41 --> Helper loaded: date_helper
INFO - 2016-06-02 17:04:41 --> Controller Class Initialized
INFO - 2016-06-02 17:04:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:04:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:04:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:04:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:04:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:04:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:04:41 --> Model Class Initialized
INFO - 2016-06-02 17:04:41 --> Form Validation Class Initialized
INFO - 2016-06-02 17:04:41 --> Database Utility Class Initialized
INFO - 2016-06-02 17:04:41 --> Helper loaded: file_helper
INFO - 2016-06-02 17:04:41 --> Helper loaded: download_helper
INFO - 2016-06-02 17:04:59 --> Config Class Initialized
INFO - 2016-06-02 17:04:59 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:04:59 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:04:59 --> Utf8 Class Initialized
INFO - 2016-06-02 17:04:59 --> URI Class Initialized
INFO - 2016-06-02 17:04:59 --> Router Class Initialized
INFO - 2016-06-02 17:04:59 --> Output Class Initialized
INFO - 2016-06-02 17:04:59 --> Security Class Initialized
DEBUG - 2016-06-02 17:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:04:59 --> CSRF cookie sent
INFO - 2016-06-02 17:04:59 --> Input Class Initialized
INFO - 2016-06-02 17:04:59 --> Language Class Initialized
INFO - 2016-06-02 17:04:59 --> Loader Class Initialized
INFO - 2016-06-02 17:04:59 --> Helper loaded: form_helper
INFO - 2016-06-02 17:04:59 --> Database Driver Class Initialized
INFO - 2016-06-02 17:04:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:04:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:04:59 --> Email Class Initialized
INFO - 2016-06-02 17:04:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:04:59 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:04:59 --> Helper loaded: language_helper
INFO - 2016-06-02 17:04:59 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:04:59 --> Model Class Initialized
INFO - 2016-06-02 17:04:59 --> Helper loaded: date_helper
INFO - 2016-06-02 17:04:59 --> Controller Class Initialized
INFO - 2016-06-02 17:04:59 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:04:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:04:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:04:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:04:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:04:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:04:59 --> Model Class Initialized
INFO - 2016-06-02 17:04:59 --> Form Validation Class Initialized
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 17:04:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 17:04:59 --> Final output sent to browser
DEBUG - 2016-06-02 17:04:59 --> Total execution time: 0.0450
INFO - 2016-06-02 17:05:04 --> Config Class Initialized
INFO - 2016-06-02 17:05:04 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:05:04 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:05:04 --> Utf8 Class Initialized
INFO - 2016-06-02 17:05:04 --> URI Class Initialized
INFO - 2016-06-02 17:05:04 --> Router Class Initialized
INFO - 2016-06-02 17:05:04 --> Output Class Initialized
INFO - 2016-06-02 17:05:04 --> Security Class Initialized
DEBUG - 2016-06-02 17:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:05:04 --> CSRF cookie sent
INFO - 2016-06-02 17:05:04 --> CSRF token verified
INFO - 2016-06-02 17:05:04 --> Input Class Initialized
INFO - 2016-06-02 17:05:04 --> Language Class Initialized
INFO - 2016-06-02 17:05:04 --> Loader Class Initialized
INFO - 2016-06-02 17:05:04 --> Helper loaded: form_helper
INFO - 2016-06-02 17:05:04 --> Database Driver Class Initialized
INFO - 2016-06-02 17:05:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:05:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:05:04 --> Email Class Initialized
INFO - 2016-06-02 17:05:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:05:04 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:05:04 --> Helper loaded: language_helper
INFO - 2016-06-02 17:05:04 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:05:04 --> Model Class Initialized
INFO - 2016-06-02 17:05:04 --> Helper loaded: date_helper
INFO - 2016-06-02 17:05:04 --> Controller Class Initialized
INFO - 2016-06-02 17:05:04 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:05:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:05:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:05:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:05:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:05:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:05:04 --> Model Class Initialized
INFO - 2016-06-02 17:05:04 --> Form Validation Class Initialized
INFO - 2016-06-02 17:05:04 --> Final output sent to browser
DEBUG - 2016-06-02 17:05:04 --> Total execution time: 0.0656
INFO - 2016-06-02 17:30:45 --> Config Class Initialized
INFO - 2016-06-02 17:30:45 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:30:45 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:30:45 --> Utf8 Class Initialized
INFO - 2016-06-02 17:30:45 --> URI Class Initialized
INFO - 2016-06-02 17:30:45 --> Router Class Initialized
INFO - 2016-06-02 17:30:45 --> Output Class Initialized
INFO - 2016-06-02 17:30:45 --> Security Class Initialized
DEBUG - 2016-06-02 17:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:30:45 --> CSRF cookie sent
INFO - 2016-06-02 17:30:45 --> Input Class Initialized
INFO - 2016-06-02 17:30:45 --> Language Class Initialized
INFO - 2016-06-02 17:30:45 --> Loader Class Initialized
INFO - 2016-06-02 17:30:45 --> Helper loaded: form_helper
INFO - 2016-06-02 17:30:45 --> Database Driver Class Initialized
INFO - 2016-06-02 17:30:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:30:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:30:45 --> Email Class Initialized
INFO - 2016-06-02 17:30:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:30:45 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:30:45 --> Helper loaded: language_helper
INFO - 2016-06-02 17:30:45 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:30:45 --> Model Class Initialized
INFO - 2016-06-02 17:30:45 --> Helper loaded: date_helper
INFO - 2016-06-02 17:30:45 --> Controller Class Initialized
INFO - 2016-06-02 17:30:45 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:30:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:30:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:30:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:30:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:30:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:30:45 --> Model Class Initialized
INFO - 2016-06-02 17:30:45 --> Form Validation Class Initialized
INFO - 2016-06-02 17:37:53 --> Config Class Initialized
INFO - 2016-06-02 17:37:53 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:37:53 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:37:53 --> Utf8 Class Initialized
INFO - 2016-06-02 17:37:53 --> URI Class Initialized
INFO - 2016-06-02 17:37:53 --> Router Class Initialized
INFO - 2016-06-02 17:37:53 --> Output Class Initialized
INFO - 2016-06-02 17:37:53 --> Security Class Initialized
DEBUG - 2016-06-02 17:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:37:53 --> CSRF cookie sent
INFO - 2016-06-02 17:37:53 --> Input Class Initialized
INFO - 2016-06-02 17:37:53 --> Language Class Initialized
INFO - 2016-06-02 17:37:53 --> Loader Class Initialized
INFO - 2016-06-02 17:37:53 --> Helper loaded: form_helper
INFO - 2016-06-02 17:37:53 --> Database Driver Class Initialized
INFO - 2016-06-02 17:37:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:37:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:37:53 --> Email Class Initialized
INFO - 2016-06-02 17:37:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:37:53 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:37:53 --> Helper loaded: language_helper
INFO - 2016-06-02 17:37:53 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:37:53 --> Model Class Initialized
INFO - 2016-06-02 17:37:53 --> Helper loaded: date_helper
INFO - 2016-06-02 17:37:53 --> Controller Class Initialized
INFO - 2016-06-02 17:37:53 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:37:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:37:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:37:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:37:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:37:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:37:53 --> Model Class Initialized
INFO - 2016-06-02 17:37:53 --> Form Validation Class Initialized
INFO - 2016-06-02 17:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 17:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 17:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 17:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 17:37:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 17:37:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 17:37:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 17:37:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 17:37:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 17:37:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 17:37:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 17:37:54 --> Final output sent to browser
DEBUG - 2016-06-02 17:37:54 --> Total execution time: 0.0833
INFO - 2016-06-02 17:37:59 --> Config Class Initialized
INFO - 2016-06-02 17:37:59 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:37:59 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:37:59 --> Utf8 Class Initialized
INFO - 2016-06-02 17:37:59 --> URI Class Initialized
INFO - 2016-06-02 17:37:59 --> Router Class Initialized
INFO - 2016-06-02 17:37:59 --> Output Class Initialized
INFO - 2016-06-02 17:37:59 --> Security Class Initialized
DEBUG - 2016-06-02 17:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:37:59 --> CSRF cookie sent
INFO - 2016-06-02 17:37:59 --> CSRF token verified
INFO - 2016-06-02 17:37:59 --> Input Class Initialized
INFO - 2016-06-02 17:37:59 --> Language Class Initialized
INFO - 2016-06-02 17:37:59 --> Loader Class Initialized
INFO - 2016-06-02 17:37:59 --> Helper loaded: form_helper
INFO - 2016-06-02 17:37:59 --> Database Driver Class Initialized
INFO - 2016-06-02 17:37:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:37:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:37:59 --> Email Class Initialized
INFO - 2016-06-02 17:37:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:37:59 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:37:59 --> Helper loaded: language_helper
INFO - 2016-06-02 17:37:59 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:37:59 --> Model Class Initialized
INFO - 2016-06-02 17:37:59 --> Helper loaded: date_helper
INFO - 2016-06-02 17:37:59 --> Controller Class Initialized
INFO - 2016-06-02 17:37:59 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:37:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:37:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:37:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:37:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:37:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:37:59 --> Model Class Initialized
INFO - 2016-06-02 17:37:59 --> Form Validation Class Initialized
INFO - 2016-06-02 17:37:59 --> Final output sent to browser
DEBUG - 2016-06-02 17:37:59 --> Total execution time: 0.0144
INFO - 2016-06-02 17:38:30 --> Config Class Initialized
INFO - 2016-06-02 17:38:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:38:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:38:30 --> Utf8 Class Initialized
INFO - 2016-06-02 17:38:30 --> URI Class Initialized
INFO - 2016-06-02 17:38:30 --> Router Class Initialized
INFO - 2016-06-02 17:38:30 --> Output Class Initialized
INFO - 2016-06-02 17:38:30 --> Security Class Initialized
DEBUG - 2016-06-02 17:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:38:30 --> CSRF cookie sent
INFO - 2016-06-02 17:38:30 --> Input Class Initialized
INFO - 2016-06-02 17:38:30 --> Language Class Initialized
INFO - 2016-06-02 17:38:30 --> Loader Class Initialized
INFO - 2016-06-02 17:38:30 --> Helper loaded: form_helper
INFO - 2016-06-02 17:38:30 --> Database Driver Class Initialized
INFO - 2016-06-02 17:38:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:38:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:38:30 --> Email Class Initialized
INFO - 2016-06-02 17:38:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:38:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:38:30 --> Helper loaded: language_helper
INFO - 2016-06-02 17:38:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:38:30 --> Model Class Initialized
INFO - 2016-06-02 17:38:30 --> Helper loaded: date_helper
INFO - 2016-06-02 17:38:30 --> Controller Class Initialized
INFO - 2016-06-02 17:38:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:38:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:38:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:38:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:38:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:38:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:38:30 --> Model Class Initialized
INFO - 2016-06-02 17:38:30 --> Form Validation Class Initialized
ERROR - 2016-06-02 17:38:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
            LIMIT' at line 19 - Invalid query: 
            SELECT 
                `date`,
                `interval_1`,
                `interval_2`,
                `interval_3`,
                `interval_4`,
                `interval_5`,
                `interval_6`,
                `interval_7`,
                `interval_8`,
                `interval_9`,
                `interval_10`,
                `notes`             
            FROM 
                1_glicemie 
            WHERE 
                `fk_user` = 2.
            AND 
                DATE(`date`) > (NOW() - INTERVAL  DAY)
            LIMIT
                
            
        
INFO - 2016-06-02 17:39:28 --> Config Class Initialized
INFO - 2016-06-02 17:39:28 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:39:28 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:39:28 --> Utf8 Class Initialized
INFO - 2016-06-02 17:39:28 --> URI Class Initialized
INFO - 2016-06-02 17:39:28 --> Router Class Initialized
INFO - 2016-06-02 17:39:28 --> Output Class Initialized
INFO - 2016-06-02 17:39:28 --> Security Class Initialized
DEBUG - 2016-06-02 17:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:39:28 --> CSRF cookie sent
INFO - 2016-06-02 17:39:28 --> Input Class Initialized
INFO - 2016-06-02 17:39:28 --> Language Class Initialized
INFO - 2016-06-02 17:39:28 --> Loader Class Initialized
INFO - 2016-06-02 17:39:28 --> Helper loaded: form_helper
INFO - 2016-06-02 17:39:28 --> Database Driver Class Initialized
INFO - 2016-06-02 17:39:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:39:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:39:28 --> Email Class Initialized
INFO - 2016-06-02 17:39:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:39:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:39:28 --> Helper loaded: language_helper
INFO - 2016-06-02 17:39:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:39:28 --> Model Class Initialized
INFO - 2016-06-02 17:39:28 --> Helper loaded: date_helper
INFO - 2016-06-02 17:39:28 --> Controller Class Initialized
INFO - 2016-06-02 17:39:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:39:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:39:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:39:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:39:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:39:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:39:28 --> Model Class Initialized
INFO - 2016-06-02 17:39:28 --> Form Validation Class Initialized
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 17:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 17:39:28 --> Final output sent to browser
DEBUG - 2016-06-02 17:39:28 --> Total execution time: 0.0527
INFO - 2016-06-02 17:39:33 --> Config Class Initialized
INFO - 2016-06-02 17:39:33 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:39:33 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:39:33 --> Utf8 Class Initialized
INFO - 2016-06-02 17:39:33 --> URI Class Initialized
INFO - 2016-06-02 17:39:33 --> Router Class Initialized
INFO - 2016-06-02 17:39:33 --> Output Class Initialized
INFO - 2016-06-02 17:39:33 --> Security Class Initialized
DEBUG - 2016-06-02 17:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:39:33 --> CSRF cookie sent
INFO - 2016-06-02 17:39:33 --> CSRF token verified
INFO - 2016-06-02 17:39:33 --> Input Class Initialized
INFO - 2016-06-02 17:39:33 --> Language Class Initialized
INFO - 2016-06-02 17:39:33 --> Loader Class Initialized
INFO - 2016-06-02 17:39:33 --> Helper loaded: form_helper
INFO - 2016-06-02 17:39:33 --> Database Driver Class Initialized
INFO - 2016-06-02 17:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:39:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:39:33 --> Email Class Initialized
INFO - 2016-06-02 17:39:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:39:33 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:39:33 --> Helper loaded: language_helper
INFO - 2016-06-02 17:39:33 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:39:33 --> Model Class Initialized
INFO - 2016-06-02 17:39:33 --> Helper loaded: date_helper
INFO - 2016-06-02 17:39:33 --> Controller Class Initialized
INFO - 2016-06-02 17:39:33 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:39:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:39:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:39:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:39:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:39:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:39:33 --> Model Class Initialized
INFO - 2016-06-02 17:39:33 --> Form Validation Class Initialized
INFO - 2016-06-02 17:39:33 --> Final output sent to browser
DEBUG - 2016-06-02 17:39:33 --> Total execution time: 0.0667
INFO - 2016-06-02 17:39:44 --> Config Class Initialized
INFO - 2016-06-02 17:39:44 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:39:44 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:39:44 --> Utf8 Class Initialized
INFO - 2016-06-02 17:39:44 --> URI Class Initialized
INFO - 2016-06-02 17:39:44 --> Router Class Initialized
INFO - 2016-06-02 17:39:44 --> Output Class Initialized
INFO - 2016-06-02 17:39:44 --> Security Class Initialized
DEBUG - 2016-06-02 17:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:39:44 --> CSRF cookie sent
INFO - 2016-06-02 17:39:44 --> Input Class Initialized
INFO - 2016-06-02 17:39:44 --> Language Class Initialized
INFO - 2016-06-02 17:39:44 --> Loader Class Initialized
INFO - 2016-06-02 17:39:44 --> Helper loaded: form_helper
INFO - 2016-06-02 17:39:44 --> Database Driver Class Initialized
INFO - 2016-06-02 17:39:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:39:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:39:44 --> Email Class Initialized
INFO - 2016-06-02 17:39:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:39:44 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:39:44 --> Helper loaded: language_helper
INFO - 2016-06-02 17:39:44 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:39:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:39:44 --> Model Class Initialized
INFO - 2016-06-02 17:39:44 --> Helper loaded: date_helper
INFO - 2016-06-02 17:39:44 --> Controller Class Initialized
INFO - 2016-06-02 17:39:44 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:39:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:39:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:39:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:39:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:39:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:39:44 --> Model Class Initialized
INFO - 2016-06-02 17:39:44 --> Form Validation Class Initialized
INFO - 2016-06-02 17:40:45 --> Config Class Initialized
INFO - 2016-06-02 17:40:45 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:40:45 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:40:45 --> Utf8 Class Initialized
INFO - 2016-06-02 17:40:45 --> URI Class Initialized
INFO - 2016-06-02 17:40:45 --> Router Class Initialized
INFO - 2016-06-02 17:40:45 --> Output Class Initialized
INFO - 2016-06-02 17:40:45 --> Security Class Initialized
DEBUG - 2016-06-02 17:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:40:45 --> CSRF cookie sent
INFO - 2016-06-02 17:40:45 --> Input Class Initialized
INFO - 2016-06-02 17:40:45 --> Language Class Initialized
INFO - 2016-06-02 17:40:45 --> Loader Class Initialized
INFO - 2016-06-02 17:40:45 --> Helper loaded: form_helper
INFO - 2016-06-02 17:40:45 --> Database Driver Class Initialized
INFO - 2016-06-02 17:40:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:40:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:40:45 --> Email Class Initialized
INFO - 2016-06-02 17:40:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:40:45 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:40:45 --> Helper loaded: language_helper
INFO - 2016-06-02 17:40:45 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:40:45 --> Model Class Initialized
INFO - 2016-06-02 17:40:45 --> Helper loaded: date_helper
INFO - 2016-06-02 17:40:45 --> Controller Class Initialized
INFO - 2016-06-02 17:40:45 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:40:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:40:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:40:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:40:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:40:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:40:45 --> Model Class Initialized
INFO - 2016-06-02 17:40:45 --> Form Validation Class Initialized
INFO - 2016-06-02 17:41:09 --> Config Class Initialized
INFO - 2016-06-02 17:41:09 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:41:09 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:41:09 --> Utf8 Class Initialized
INFO - 2016-06-02 17:41:09 --> URI Class Initialized
INFO - 2016-06-02 17:41:09 --> Router Class Initialized
INFO - 2016-06-02 17:41:09 --> Output Class Initialized
INFO - 2016-06-02 17:41:09 --> Security Class Initialized
DEBUG - 2016-06-02 17:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:41:09 --> CSRF cookie sent
INFO - 2016-06-02 17:41:09 --> Input Class Initialized
INFO - 2016-06-02 17:41:09 --> Language Class Initialized
INFO - 2016-06-02 17:41:09 --> Loader Class Initialized
INFO - 2016-06-02 17:41:09 --> Helper loaded: form_helper
INFO - 2016-06-02 17:41:09 --> Database Driver Class Initialized
INFO - 2016-06-02 17:41:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:41:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:41:09 --> Email Class Initialized
INFO - 2016-06-02 17:41:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:41:09 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:41:09 --> Helper loaded: language_helper
INFO - 2016-06-02 17:41:09 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:41:09 --> Model Class Initialized
INFO - 2016-06-02 17:41:09 --> Helper loaded: date_helper
INFO - 2016-06-02 17:41:09 --> Controller Class Initialized
INFO - 2016-06-02 17:41:09 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:41:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:41:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:41:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:41:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:41:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:41:09 --> Model Class Initialized
INFO - 2016-06-02 17:41:09 --> Form Validation Class Initialized
ERROR - 2016-06-02 17:41:09 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 33
INFO - 2016-06-02 17:41:26 --> Config Class Initialized
INFO - 2016-06-02 17:41:26 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:41:26 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:41:26 --> Utf8 Class Initialized
INFO - 2016-06-02 17:41:26 --> URI Class Initialized
INFO - 2016-06-02 17:41:26 --> Router Class Initialized
INFO - 2016-06-02 17:41:26 --> Output Class Initialized
INFO - 2016-06-02 17:41:26 --> Security Class Initialized
DEBUG - 2016-06-02 17:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:41:26 --> CSRF cookie sent
INFO - 2016-06-02 17:41:26 --> Input Class Initialized
INFO - 2016-06-02 17:41:26 --> Language Class Initialized
INFO - 2016-06-02 17:41:26 --> Loader Class Initialized
INFO - 2016-06-02 17:41:26 --> Helper loaded: form_helper
INFO - 2016-06-02 17:41:26 --> Database Driver Class Initialized
INFO - 2016-06-02 17:41:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:41:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:41:26 --> Email Class Initialized
INFO - 2016-06-02 17:41:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:41:26 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:41:26 --> Helper loaded: language_helper
INFO - 2016-06-02 17:41:26 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:41:26 --> Model Class Initialized
INFO - 2016-06-02 17:41:26 --> Helper loaded: date_helper
INFO - 2016-06-02 17:41:26 --> Controller Class Initialized
INFO - 2016-06-02 17:41:26 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:41:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:41:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:41:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:41:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:41:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:41:26 --> Model Class Initialized
INFO - 2016-06-02 17:41:26 --> Form Validation Class Initialized
INFO - 2016-06-02 17:41:56 --> Config Class Initialized
INFO - 2016-06-02 17:41:56 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:41:56 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:41:56 --> Utf8 Class Initialized
INFO - 2016-06-02 17:41:56 --> URI Class Initialized
INFO - 2016-06-02 17:41:56 --> Router Class Initialized
INFO - 2016-06-02 17:41:56 --> Output Class Initialized
INFO - 2016-06-02 17:41:56 --> Security Class Initialized
DEBUG - 2016-06-02 17:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:41:56 --> CSRF cookie sent
INFO - 2016-06-02 17:41:56 --> Input Class Initialized
INFO - 2016-06-02 17:41:56 --> Language Class Initialized
INFO - 2016-06-02 17:41:56 --> Loader Class Initialized
INFO - 2016-06-02 17:41:56 --> Helper loaded: form_helper
INFO - 2016-06-02 17:41:56 --> Database Driver Class Initialized
INFO - 2016-06-02 17:41:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:41:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:41:56 --> Email Class Initialized
INFO - 2016-06-02 17:41:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:41:56 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:41:56 --> Helper loaded: language_helper
INFO - 2016-06-02 17:41:56 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:41:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:41:56 --> Model Class Initialized
INFO - 2016-06-02 17:41:56 --> Helper loaded: date_helper
INFO - 2016-06-02 17:41:56 --> Controller Class Initialized
INFO - 2016-06-02 17:41:56 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:41:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:41:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:41:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:41:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:41:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:41:56 --> Model Class Initialized
INFO - 2016-06-02 17:41:56 --> Form Validation Class Initialized
INFO - 2016-06-02 17:42:08 --> Config Class Initialized
INFO - 2016-06-02 17:42:08 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:42:08 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:42:08 --> Utf8 Class Initialized
INFO - 2016-06-02 17:42:08 --> URI Class Initialized
INFO - 2016-06-02 17:42:08 --> Router Class Initialized
INFO - 2016-06-02 17:42:08 --> Output Class Initialized
INFO - 2016-06-02 17:42:08 --> Security Class Initialized
DEBUG - 2016-06-02 17:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:42:08 --> CSRF cookie sent
INFO - 2016-06-02 17:42:08 --> Input Class Initialized
INFO - 2016-06-02 17:42:08 --> Language Class Initialized
INFO - 2016-06-02 17:42:08 --> Loader Class Initialized
INFO - 2016-06-02 17:42:08 --> Helper loaded: form_helper
INFO - 2016-06-02 17:42:08 --> Database Driver Class Initialized
INFO - 2016-06-02 17:42:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:42:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:42:08 --> Email Class Initialized
INFO - 2016-06-02 17:42:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:42:08 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:42:08 --> Helper loaded: language_helper
INFO - 2016-06-02 17:42:08 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:42:08 --> Model Class Initialized
INFO - 2016-06-02 17:42:08 --> Helper loaded: date_helper
INFO - 2016-06-02 17:42:08 --> Controller Class Initialized
INFO - 2016-06-02 17:42:08 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:42:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:42:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:42:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:42:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:42:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:42:08 --> Model Class Initialized
INFO - 2016-06-02 17:42:08 --> Form Validation Class Initialized
INFO - 2016-06-02 17:42:27 --> Config Class Initialized
INFO - 2016-06-02 17:42:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:42:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:42:27 --> Utf8 Class Initialized
INFO - 2016-06-02 17:42:27 --> URI Class Initialized
INFO - 2016-06-02 17:42:27 --> Router Class Initialized
INFO - 2016-06-02 17:42:27 --> Output Class Initialized
INFO - 2016-06-02 17:42:27 --> Security Class Initialized
DEBUG - 2016-06-02 17:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:42:27 --> CSRF cookie sent
INFO - 2016-06-02 17:42:27 --> Input Class Initialized
INFO - 2016-06-02 17:42:27 --> Language Class Initialized
INFO - 2016-06-02 17:42:27 --> Loader Class Initialized
INFO - 2016-06-02 17:42:27 --> Helper loaded: form_helper
INFO - 2016-06-02 17:42:27 --> Database Driver Class Initialized
INFO - 2016-06-02 17:42:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:42:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:42:27 --> Email Class Initialized
INFO - 2016-06-02 17:42:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:42:27 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:42:27 --> Helper loaded: language_helper
INFO - 2016-06-02 17:42:27 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:42:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:42:27 --> Model Class Initialized
INFO - 2016-06-02 17:42:27 --> Helper loaded: date_helper
INFO - 2016-06-02 17:42:27 --> Controller Class Initialized
INFO - 2016-06-02 17:42:27 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:42:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:42:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:42:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:42:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:42:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:42:27 --> Model Class Initialized
INFO - 2016-06-02 17:42:27 --> Form Validation Class Initialized
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 17:42:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 17:42:27 --> Final output sent to browser
DEBUG - 2016-06-02 17:42:27 --> Total execution time: 0.0495
INFO - 2016-06-02 17:42:36 --> Config Class Initialized
INFO - 2016-06-02 17:42:36 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:42:36 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:42:36 --> Utf8 Class Initialized
INFO - 2016-06-02 17:42:36 --> URI Class Initialized
INFO - 2016-06-02 17:42:36 --> Router Class Initialized
INFO - 2016-06-02 17:42:36 --> Output Class Initialized
INFO - 2016-06-02 17:42:36 --> Security Class Initialized
DEBUG - 2016-06-02 17:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:42:36 --> CSRF cookie sent
INFO - 2016-06-02 17:42:36 --> CSRF token verified
INFO - 2016-06-02 17:42:36 --> Input Class Initialized
INFO - 2016-06-02 17:42:36 --> Language Class Initialized
INFO - 2016-06-02 17:42:36 --> Loader Class Initialized
INFO - 2016-06-02 17:42:36 --> Helper loaded: form_helper
INFO - 2016-06-02 17:42:36 --> Database Driver Class Initialized
INFO - 2016-06-02 17:42:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:42:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:42:36 --> Email Class Initialized
INFO - 2016-06-02 17:42:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:42:36 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:42:36 --> Helper loaded: language_helper
INFO - 2016-06-02 17:42:36 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:42:36 --> Model Class Initialized
INFO - 2016-06-02 17:42:36 --> Helper loaded: date_helper
INFO - 2016-06-02 17:42:36 --> Controller Class Initialized
INFO - 2016-06-02 17:42:36 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:42:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:42:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:42:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:42:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:42:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:42:36 --> Model Class Initialized
INFO - 2016-06-02 17:42:36 --> Form Validation Class Initialized
INFO - 2016-06-02 17:42:36 --> Final output sent to browser
DEBUG - 2016-06-02 17:42:36 --> Total execution time: 0.0687
INFO - 2016-06-02 17:42:57 --> Config Class Initialized
INFO - 2016-06-02 17:42:57 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:42:57 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:42:57 --> Utf8 Class Initialized
INFO - 2016-06-02 17:42:57 --> URI Class Initialized
INFO - 2016-06-02 17:42:57 --> Router Class Initialized
INFO - 2016-06-02 17:42:57 --> Output Class Initialized
INFO - 2016-06-02 17:42:57 --> Security Class Initialized
DEBUG - 2016-06-02 17:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:42:57 --> CSRF cookie sent
INFO - 2016-06-02 17:42:57 --> Input Class Initialized
INFO - 2016-06-02 17:42:57 --> Language Class Initialized
INFO - 2016-06-02 17:42:57 --> Loader Class Initialized
INFO - 2016-06-02 17:42:57 --> Helper loaded: form_helper
INFO - 2016-06-02 17:42:57 --> Database Driver Class Initialized
INFO - 2016-06-02 17:42:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:42:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:42:57 --> Email Class Initialized
INFO - 2016-06-02 17:42:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:42:57 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:42:57 --> Helper loaded: language_helper
INFO - 2016-06-02 17:42:57 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:42:57 --> Model Class Initialized
INFO - 2016-06-02 17:42:57 --> Helper loaded: date_helper
INFO - 2016-06-02 17:42:57 --> Controller Class Initialized
INFO - 2016-06-02 17:42:57 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:42:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:42:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:42:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:42:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:42:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:42:57 --> Model Class Initialized
INFO - 2016-06-02 17:42:57 --> Form Validation Class Initialized
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 17:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 17:42:57 --> Final output sent to browser
DEBUG - 2016-06-02 17:42:57 --> Total execution time: 0.0446
INFO - 2016-06-02 17:43:06 --> Config Class Initialized
INFO - 2016-06-02 17:43:06 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:43:06 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:43:06 --> Utf8 Class Initialized
INFO - 2016-06-02 17:43:06 --> URI Class Initialized
INFO - 2016-06-02 17:43:06 --> Router Class Initialized
INFO - 2016-06-02 17:43:06 --> Output Class Initialized
INFO - 2016-06-02 17:43:06 --> Security Class Initialized
DEBUG - 2016-06-02 17:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:43:06 --> CSRF cookie sent
INFO - 2016-06-02 17:43:06 --> CSRF token verified
INFO - 2016-06-02 17:43:06 --> Input Class Initialized
INFO - 2016-06-02 17:43:06 --> Language Class Initialized
INFO - 2016-06-02 17:43:06 --> Loader Class Initialized
INFO - 2016-06-02 17:43:06 --> Helper loaded: form_helper
INFO - 2016-06-02 17:43:06 --> Database Driver Class Initialized
INFO - 2016-06-02 17:43:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:43:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:43:06 --> Email Class Initialized
INFO - 2016-06-02 17:43:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:43:06 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:43:06 --> Helper loaded: language_helper
INFO - 2016-06-02 17:43:06 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:43:06 --> Model Class Initialized
INFO - 2016-06-02 17:43:06 --> Helper loaded: date_helper
INFO - 2016-06-02 17:43:06 --> Controller Class Initialized
INFO - 2016-06-02 17:43:06 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:43:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:43:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:43:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:43:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:43:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:43:06 --> Model Class Initialized
INFO - 2016-06-02 17:43:06 --> Form Validation Class Initialized
INFO - 2016-06-02 17:43:06 --> Final output sent to browser
DEBUG - 2016-06-02 17:43:06 --> Total execution time: 0.0398
INFO - 2016-06-02 17:43:21 --> Config Class Initialized
INFO - 2016-06-02 17:43:21 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:43:21 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:43:21 --> Utf8 Class Initialized
INFO - 2016-06-02 17:43:21 --> URI Class Initialized
INFO - 2016-06-02 17:43:21 --> Router Class Initialized
INFO - 2016-06-02 17:43:21 --> Output Class Initialized
INFO - 2016-06-02 17:43:21 --> Security Class Initialized
DEBUG - 2016-06-02 17:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:43:21 --> CSRF cookie sent
INFO - 2016-06-02 17:43:21 --> CSRF token verified
INFO - 2016-06-02 17:43:21 --> Input Class Initialized
INFO - 2016-06-02 17:43:21 --> Language Class Initialized
INFO - 2016-06-02 17:43:21 --> Loader Class Initialized
INFO - 2016-06-02 17:43:21 --> Helper loaded: form_helper
INFO - 2016-06-02 17:43:21 --> Database Driver Class Initialized
INFO - 2016-06-02 17:43:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:43:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:43:21 --> Email Class Initialized
INFO - 2016-06-02 17:43:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:43:21 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:43:21 --> Helper loaded: language_helper
INFO - 2016-06-02 17:43:21 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:43:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:43:21 --> Model Class Initialized
INFO - 2016-06-02 17:43:21 --> Helper loaded: date_helper
INFO - 2016-06-02 17:43:21 --> Controller Class Initialized
INFO - 2016-06-02 17:43:21 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:43:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:43:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:43:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:43:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:43:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:43:21 --> Model Class Initialized
INFO - 2016-06-02 17:43:21 --> Form Validation Class Initialized
INFO - 2016-06-02 17:43:21 --> Final output sent to browser
DEBUG - 2016-06-02 17:43:21 --> Total execution time: 0.0607
INFO - 2016-06-02 17:43:40 --> Config Class Initialized
INFO - 2016-06-02 17:43:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:43:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:43:40 --> Utf8 Class Initialized
INFO - 2016-06-02 17:43:40 --> URI Class Initialized
INFO - 2016-06-02 17:43:40 --> Router Class Initialized
INFO - 2016-06-02 17:43:40 --> Output Class Initialized
INFO - 2016-06-02 17:43:40 --> Security Class Initialized
DEBUG - 2016-06-02 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:43:40 --> CSRF cookie sent
INFO - 2016-06-02 17:43:40 --> Input Class Initialized
INFO - 2016-06-02 17:43:40 --> Language Class Initialized
INFO - 2016-06-02 17:43:40 --> Loader Class Initialized
INFO - 2016-06-02 17:43:40 --> Helper loaded: form_helper
INFO - 2016-06-02 17:43:40 --> Database Driver Class Initialized
INFO - 2016-06-02 17:43:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:43:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:43:40 --> Email Class Initialized
INFO - 2016-06-02 17:43:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:43:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:43:40 --> Helper loaded: language_helper
INFO - 2016-06-02 17:43:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:43:40 --> Model Class Initialized
INFO - 2016-06-02 17:43:40 --> Helper loaded: date_helper
INFO - 2016-06-02 17:43:40 --> Controller Class Initialized
INFO - 2016-06-02 17:43:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:43:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:43:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:43:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:43:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:43:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:43:40 --> Model Class Initialized
INFO - 2016-06-02 17:43:40 --> Form Validation Class Initialized
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 17:43:40 --> Final output sent to browser
DEBUG - 2016-06-02 17:43:40 --> Total execution time: 0.0501
INFO - 2016-06-02 17:43:47 --> Config Class Initialized
INFO - 2016-06-02 17:43:47 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:43:47 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:43:47 --> Utf8 Class Initialized
INFO - 2016-06-02 17:43:47 --> URI Class Initialized
INFO - 2016-06-02 17:43:47 --> Router Class Initialized
INFO - 2016-06-02 17:43:47 --> Output Class Initialized
INFO - 2016-06-02 17:43:47 --> Security Class Initialized
DEBUG - 2016-06-02 17:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:43:47 --> CSRF cookie sent
INFO - 2016-06-02 17:43:47 --> CSRF token verified
INFO - 2016-06-02 17:43:47 --> Input Class Initialized
INFO - 2016-06-02 17:43:47 --> Language Class Initialized
INFO - 2016-06-02 17:43:47 --> Loader Class Initialized
INFO - 2016-06-02 17:43:47 --> Helper loaded: form_helper
INFO - 2016-06-02 17:43:47 --> Database Driver Class Initialized
INFO - 2016-06-02 17:43:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:43:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:43:47 --> Email Class Initialized
INFO - 2016-06-02 17:43:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:43:47 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:43:47 --> Helper loaded: language_helper
INFO - 2016-06-02 17:43:47 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:43:47 --> Model Class Initialized
INFO - 2016-06-02 17:43:47 --> Helper loaded: date_helper
INFO - 2016-06-02 17:43:47 --> Controller Class Initialized
INFO - 2016-06-02 17:43:47 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:43:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:43:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:43:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:43:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:43:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:43:47 --> Model Class Initialized
INFO - 2016-06-02 17:43:47 --> Form Validation Class Initialized
INFO - 2016-06-02 17:43:47 --> Final output sent to browser
DEBUG - 2016-06-02 17:43:47 --> Total execution time: 0.0388
INFO - 2016-06-02 17:43:55 --> Config Class Initialized
INFO - 2016-06-02 17:43:55 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:43:55 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:43:55 --> Utf8 Class Initialized
INFO - 2016-06-02 17:43:55 --> URI Class Initialized
INFO - 2016-06-02 17:43:55 --> Router Class Initialized
INFO - 2016-06-02 17:43:55 --> Output Class Initialized
INFO - 2016-06-02 17:43:55 --> Security Class Initialized
DEBUG - 2016-06-02 17:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:43:55 --> CSRF cookie sent
INFO - 2016-06-02 17:43:55 --> Input Class Initialized
INFO - 2016-06-02 17:43:55 --> Language Class Initialized
INFO - 2016-06-02 17:43:55 --> Loader Class Initialized
INFO - 2016-06-02 17:43:55 --> Helper loaded: form_helper
INFO - 2016-06-02 17:43:55 --> Database Driver Class Initialized
INFO - 2016-06-02 17:43:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:43:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:43:55 --> Email Class Initialized
INFO - 2016-06-02 17:43:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:43:55 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:43:55 --> Helper loaded: language_helper
INFO - 2016-06-02 17:43:55 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:43:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:43:55 --> Model Class Initialized
INFO - 2016-06-02 17:43:55 --> Helper loaded: date_helper
INFO - 2016-06-02 17:43:55 --> Controller Class Initialized
INFO - 2016-06-02 17:43:55 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:43:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:43:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:43:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:43:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:43:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:43:55 --> Model Class Initialized
INFO - 2016-06-02 17:43:55 --> Form Validation Class Initialized
ERROR - 2016-06-02 17:43:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
            LIMIT' at line 19 - Invalid query: 
            SELECT 
                `date`,
                `interval_1`,
                `interval_2`,
                `interval_3`,
                `interval_4`,
                `interval_5`,
                `interval_6`,
                `interval_7`,
                `interval_8`,
                `interval_9`,
                `interval_10`,
                `notes`             
            FROM 
                1_glicemie 
            WHERE 
                `fk_user` = 2.
            AND 
                DATE(`date`) > (NOW() - INTERVAL  DAY)
            LIMIT
                
            
        
INFO - 2016-06-02 17:45:18 --> Config Class Initialized
INFO - 2016-06-02 17:45:18 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:45:18 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:45:18 --> Utf8 Class Initialized
INFO - 2016-06-02 17:45:18 --> URI Class Initialized
INFO - 2016-06-02 17:45:18 --> Router Class Initialized
INFO - 2016-06-02 17:45:18 --> Output Class Initialized
INFO - 2016-06-02 17:45:18 --> Security Class Initialized
DEBUG - 2016-06-02 17:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:45:18 --> CSRF cookie sent
INFO - 2016-06-02 17:45:18 --> Input Class Initialized
INFO - 2016-06-02 17:45:18 --> Language Class Initialized
INFO - 2016-06-02 17:45:18 --> Loader Class Initialized
INFO - 2016-06-02 17:45:18 --> Helper loaded: form_helper
INFO - 2016-06-02 17:45:18 --> Database Driver Class Initialized
INFO - 2016-06-02 17:45:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:45:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:45:18 --> Email Class Initialized
INFO - 2016-06-02 17:45:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:45:18 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:45:18 --> Helper loaded: language_helper
INFO - 2016-06-02 17:45:18 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:45:18 --> Model Class Initialized
INFO - 2016-06-02 17:45:18 --> Helper loaded: date_helper
INFO - 2016-06-02 17:45:18 --> Controller Class Initialized
INFO - 2016-06-02 17:45:18 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:45:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:45:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:45:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:45:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:45:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:45:18 --> Model Class Initialized
INFO - 2016-06-02 17:45:18 --> Form Validation Class Initialized
INFO - 2016-06-02 17:45:18 --> Final output sent to browser
DEBUG - 2016-06-02 17:45:18 --> Total execution time: 0.0482
INFO - 2016-06-02 17:45:27 --> Config Class Initialized
INFO - 2016-06-02 17:45:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:45:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:45:27 --> Utf8 Class Initialized
INFO - 2016-06-02 17:45:27 --> URI Class Initialized
INFO - 2016-06-02 17:45:27 --> Router Class Initialized
INFO - 2016-06-02 17:45:27 --> Output Class Initialized
INFO - 2016-06-02 17:45:27 --> Security Class Initialized
DEBUG - 2016-06-02 17:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:45:27 --> CSRF cookie sent
INFO - 2016-06-02 17:45:27 --> Input Class Initialized
INFO - 2016-06-02 17:45:27 --> Language Class Initialized
INFO - 2016-06-02 17:45:27 --> Loader Class Initialized
INFO - 2016-06-02 17:45:27 --> Helper loaded: form_helper
INFO - 2016-06-02 17:45:27 --> Database Driver Class Initialized
INFO - 2016-06-02 17:45:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:45:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:45:27 --> Email Class Initialized
INFO - 2016-06-02 17:45:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:45:27 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:45:27 --> Helper loaded: language_helper
INFO - 2016-06-02 17:45:27 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:45:27 --> Model Class Initialized
INFO - 2016-06-02 17:45:27 --> Helper loaded: date_helper
INFO - 2016-06-02 17:45:27 --> Controller Class Initialized
INFO - 2016-06-02 17:45:27 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:45:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:45:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:45:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:45:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:45:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:45:27 --> Model Class Initialized
INFO - 2016-06-02 17:45:27 --> Form Validation Class Initialized
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 17:45:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 17:45:27 --> Final output sent to browser
DEBUG - 2016-06-02 17:45:27 --> Total execution time: 0.0521
INFO - 2016-06-02 17:45:33 --> Config Class Initialized
INFO - 2016-06-02 17:45:33 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:45:33 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:45:33 --> Utf8 Class Initialized
INFO - 2016-06-02 17:45:33 --> URI Class Initialized
INFO - 2016-06-02 17:45:33 --> Router Class Initialized
INFO - 2016-06-02 17:45:33 --> Output Class Initialized
INFO - 2016-06-02 17:45:33 --> Security Class Initialized
DEBUG - 2016-06-02 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:45:33 --> CSRF cookie sent
INFO - 2016-06-02 17:45:33 --> CSRF token verified
INFO - 2016-06-02 17:45:33 --> Input Class Initialized
INFO - 2016-06-02 17:45:33 --> Language Class Initialized
INFO - 2016-06-02 17:45:33 --> Loader Class Initialized
INFO - 2016-06-02 17:45:33 --> Helper loaded: form_helper
INFO - 2016-06-02 17:45:33 --> Database Driver Class Initialized
INFO - 2016-06-02 17:45:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:45:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:45:33 --> Email Class Initialized
INFO - 2016-06-02 17:45:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:45:33 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:45:33 --> Helper loaded: language_helper
INFO - 2016-06-02 17:45:33 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:45:33 --> Model Class Initialized
INFO - 2016-06-02 17:45:33 --> Helper loaded: date_helper
INFO - 2016-06-02 17:45:33 --> Controller Class Initialized
INFO - 2016-06-02 17:45:33 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:45:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:45:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:45:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:45:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:45:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:45:33 --> Model Class Initialized
INFO - 2016-06-02 17:45:33 --> Form Validation Class Initialized
INFO - 2016-06-02 17:45:33 --> Final output sent to browser
DEBUG - 2016-06-02 17:45:33 --> Total execution time: 0.0393
INFO - 2016-06-02 17:45:38 --> Config Class Initialized
INFO - 2016-06-02 17:45:38 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:45:39 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:45:39 --> Utf8 Class Initialized
INFO - 2016-06-02 17:45:39 --> URI Class Initialized
INFO - 2016-06-02 17:45:39 --> Router Class Initialized
INFO - 2016-06-02 17:45:39 --> Output Class Initialized
INFO - 2016-06-02 17:45:39 --> Security Class Initialized
DEBUG - 2016-06-02 17:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:45:39 --> CSRF cookie sent
INFO - 2016-06-02 17:45:39 --> CSRF token verified
INFO - 2016-06-02 17:45:39 --> Input Class Initialized
INFO - 2016-06-02 17:45:39 --> Language Class Initialized
INFO - 2016-06-02 17:45:39 --> Loader Class Initialized
INFO - 2016-06-02 17:45:39 --> Helper loaded: form_helper
INFO - 2016-06-02 17:45:39 --> Database Driver Class Initialized
INFO - 2016-06-02 17:45:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:45:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:45:39 --> Email Class Initialized
INFO - 2016-06-02 17:45:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:45:39 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:45:39 --> Helper loaded: language_helper
INFO - 2016-06-02 17:45:39 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:45:39 --> Model Class Initialized
INFO - 2016-06-02 17:45:39 --> Helper loaded: date_helper
INFO - 2016-06-02 17:45:39 --> Controller Class Initialized
INFO - 2016-06-02 17:45:39 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:45:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:45:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:45:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:45:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:45:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:45:39 --> Model Class Initialized
INFO - 2016-06-02 17:45:39 --> Form Validation Class Initialized
INFO - 2016-06-02 17:45:39 --> Final output sent to browser
DEBUG - 2016-06-02 17:45:39 --> Total execution time: 0.0622
INFO - 2016-06-02 17:45:42 --> Config Class Initialized
INFO - 2016-06-02 17:45:42 --> Hooks Class Initialized
DEBUG - 2016-06-02 17:45:42 --> UTF-8 Support Enabled
INFO - 2016-06-02 17:45:42 --> Utf8 Class Initialized
INFO - 2016-06-02 17:45:42 --> URI Class Initialized
INFO - 2016-06-02 17:45:42 --> Router Class Initialized
INFO - 2016-06-02 17:45:42 --> Output Class Initialized
INFO - 2016-06-02 17:45:42 --> Security Class Initialized
DEBUG - 2016-06-02 17:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 17:45:42 --> CSRF cookie sent
INFO - 2016-06-02 17:45:42 --> Input Class Initialized
INFO - 2016-06-02 17:45:42 --> Language Class Initialized
INFO - 2016-06-02 17:45:42 --> Loader Class Initialized
INFO - 2016-06-02 17:45:42 --> Helper loaded: form_helper
INFO - 2016-06-02 17:45:42 --> Database Driver Class Initialized
INFO - 2016-06-02 17:45:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 17:45:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 17:45:42 --> Email Class Initialized
INFO - 2016-06-02 17:45:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 17:45:42 --> Helper loaded: cookie_helper
INFO - 2016-06-02 17:45:42 --> Helper loaded: language_helper
INFO - 2016-06-02 17:45:42 --> Helper loaded: url_helper
DEBUG - 2016-06-02 17:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 17:45:42 --> Model Class Initialized
INFO - 2016-06-02 17:45:42 --> Helper loaded: date_helper
INFO - 2016-06-02 17:45:42 --> Controller Class Initialized
INFO - 2016-06-02 17:45:42 --> Helper loaded: languages_helper
INFO - 2016-06-02 17:45:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 17:45:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 17:45:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 17:45:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 17:45:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 17:45:42 --> Model Class Initialized
INFO - 2016-06-02 17:45:42 --> Form Validation Class Initialized
INFO - 2016-06-02 17:45:42 --> Final output sent to browser
DEBUG - 2016-06-02 17:45:42 --> Total execution time: 0.0174
INFO - 2016-06-02 18:00:02 --> Config Class Initialized
INFO - 2016-06-02 18:00:02 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:00:02 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:00:02 --> Utf8 Class Initialized
INFO - 2016-06-02 18:00:02 --> URI Class Initialized
INFO - 2016-06-02 18:00:02 --> Router Class Initialized
INFO - 2016-06-02 18:00:02 --> Output Class Initialized
INFO - 2016-06-02 18:00:02 --> Security Class Initialized
DEBUG - 2016-06-02 18:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:00:02 --> CSRF cookie sent
INFO - 2016-06-02 18:00:02 --> Input Class Initialized
INFO - 2016-06-02 18:00:02 --> Language Class Initialized
INFO - 2016-06-02 18:00:02 --> Loader Class Initialized
INFO - 2016-06-02 18:00:02 --> Helper loaded: form_helper
INFO - 2016-06-02 18:00:02 --> Database Driver Class Initialized
INFO - 2016-06-02 18:00:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:00:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:00:03 --> Email Class Initialized
INFO - 2016-06-02 18:00:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:00:03 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:00:03 --> Helper loaded: language_helper
INFO - 2016-06-02 18:00:03 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:00:03 --> Model Class Initialized
INFO - 2016-06-02 18:00:03 --> Helper loaded: date_helper
INFO - 2016-06-02 18:00:03 --> Controller Class Initialized
INFO - 2016-06-02 18:00:03 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:00:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:00:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:00:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:00:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:00:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:00:03 --> Model Class Initialized
INFO - 2016-06-02 18:00:03 --> Form Validation Class Initialized
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 18:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 18:00:03 --> Final output sent to browser
DEBUG - 2016-06-02 18:00:03 --> Total execution time: 0.0588
INFO - 2016-06-02 18:00:15 --> Config Class Initialized
INFO - 2016-06-02 18:00:15 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:00:15 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:00:15 --> Utf8 Class Initialized
INFO - 2016-06-02 18:00:15 --> URI Class Initialized
INFO - 2016-06-02 18:00:15 --> Router Class Initialized
INFO - 2016-06-02 18:00:15 --> Output Class Initialized
INFO - 2016-06-02 18:00:15 --> Security Class Initialized
DEBUG - 2016-06-02 18:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:00:15 --> CSRF cookie sent
INFO - 2016-06-02 18:00:15 --> CSRF token verified
INFO - 2016-06-02 18:00:15 --> Input Class Initialized
INFO - 2016-06-02 18:00:15 --> Language Class Initialized
INFO - 2016-06-02 18:00:15 --> Loader Class Initialized
INFO - 2016-06-02 18:00:15 --> Helper loaded: form_helper
INFO - 2016-06-02 18:00:15 --> Database Driver Class Initialized
INFO - 2016-06-02 18:00:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:00:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:00:15 --> Email Class Initialized
INFO - 2016-06-02 18:00:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:00:15 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:00:15 --> Helper loaded: language_helper
INFO - 2016-06-02 18:00:15 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:00:15 --> Model Class Initialized
INFO - 2016-06-02 18:00:15 --> Helper loaded: date_helper
INFO - 2016-06-02 18:00:15 --> Controller Class Initialized
INFO - 2016-06-02 18:00:15 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:00:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:00:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:00:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:00:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:00:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:00:15 --> Model Class Initialized
INFO - 2016-06-02 18:00:15 --> Form Validation Class Initialized
INFO - 2016-06-02 18:00:15 --> Final output sent to browser
DEBUG - 2016-06-02 18:00:15 --> Total execution time: 0.0381
INFO - 2016-06-02 18:00:15 --> Config Class Initialized
INFO - 2016-06-02 18:00:15 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:00:15 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:00:15 --> Utf8 Class Initialized
INFO - 2016-06-02 18:00:15 --> URI Class Initialized
INFO - 2016-06-02 18:00:15 --> Router Class Initialized
INFO - 2016-06-02 18:00:15 --> Output Class Initialized
INFO - 2016-06-02 18:00:15 --> Security Class Initialized
DEBUG - 2016-06-02 18:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:00:15 --> CSRF cookie sent
INFO - 2016-06-02 18:00:15 --> CSRF token verified
INFO - 2016-06-02 18:00:15 --> Input Class Initialized
INFO - 2016-06-02 18:00:15 --> Language Class Initialized
INFO - 2016-06-02 18:00:15 --> Loader Class Initialized
INFO - 2016-06-02 18:00:15 --> Helper loaded: form_helper
INFO - 2016-06-02 18:00:15 --> Database Driver Class Initialized
INFO - 2016-06-02 18:00:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:00:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:00:16 --> Email Class Initialized
INFO - 2016-06-02 18:00:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:00:16 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:00:16 --> Helper loaded: language_helper
INFO - 2016-06-02 18:00:16 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:00:16 --> Model Class Initialized
INFO - 2016-06-02 18:00:16 --> Helper loaded: date_helper
INFO - 2016-06-02 18:00:16 --> Controller Class Initialized
INFO - 2016-06-02 18:00:16 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:00:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:00:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:00:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:00:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:00:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:00:16 --> Model Class Initialized
INFO - 2016-06-02 18:00:16 --> Form Validation Class Initialized
INFO - 2016-06-02 18:00:16 --> Final output sent to browser
DEBUG - 2016-06-02 18:00:16 --> Total execution time: 0.0645
INFO - 2016-06-02 18:03:35 --> Config Class Initialized
INFO - 2016-06-02 18:03:35 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:03:35 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:03:35 --> Utf8 Class Initialized
INFO - 2016-06-02 18:03:35 --> URI Class Initialized
INFO - 2016-06-02 18:03:35 --> Router Class Initialized
INFO - 2016-06-02 18:03:35 --> Output Class Initialized
INFO - 2016-06-02 18:03:35 --> Security Class Initialized
DEBUG - 2016-06-02 18:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:03:35 --> CSRF cookie sent
INFO - 2016-06-02 18:03:35 --> Input Class Initialized
INFO - 2016-06-02 18:03:35 --> Language Class Initialized
INFO - 2016-06-02 18:03:35 --> Loader Class Initialized
INFO - 2016-06-02 18:03:35 --> Helper loaded: form_helper
INFO - 2016-06-02 18:03:35 --> Database Driver Class Initialized
INFO - 2016-06-02 18:03:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:03:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:03:35 --> Email Class Initialized
INFO - 2016-06-02 18:03:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:03:35 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:03:35 --> Helper loaded: language_helper
INFO - 2016-06-02 18:03:35 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:03:35 --> Model Class Initialized
INFO - 2016-06-02 18:03:35 --> Helper loaded: date_helper
INFO - 2016-06-02 18:03:35 --> Controller Class Initialized
INFO - 2016-06-02 18:03:35 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:03:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:03:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:03:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:03:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:03:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:03:35 --> Model Class Initialized
INFO - 2016-06-02 18:03:35 --> Form Validation Class Initialized
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 18:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 18:03:35 --> Final output sent to browser
DEBUG - 2016-06-02 18:03:35 --> Total execution time: 0.0415
INFO - 2016-06-02 18:03:41 --> Config Class Initialized
INFO - 2016-06-02 18:03:41 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:03:41 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:03:41 --> Utf8 Class Initialized
INFO - 2016-06-02 18:03:41 --> URI Class Initialized
INFO - 2016-06-02 18:03:41 --> Router Class Initialized
INFO - 2016-06-02 18:03:41 --> Output Class Initialized
INFO - 2016-06-02 18:03:41 --> Security Class Initialized
DEBUG - 2016-06-02 18:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:03:41 --> CSRF cookie sent
INFO - 2016-06-02 18:03:41 --> CSRF token verified
INFO - 2016-06-02 18:03:41 --> Input Class Initialized
INFO - 2016-06-02 18:03:41 --> Language Class Initialized
INFO - 2016-06-02 18:03:41 --> Loader Class Initialized
INFO - 2016-06-02 18:03:41 --> Helper loaded: form_helper
INFO - 2016-06-02 18:03:41 --> Database Driver Class Initialized
INFO - 2016-06-02 18:03:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:03:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:03:41 --> Email Class Initialized
INFO - 2016-06-02 18:03:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:03:41 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:03:41 --> Helper loaded: language_helper
INFO - 2016-06-02 18:03:41 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:03:41 --> Model Class Initialized
INFO - 2016-06-02 18:03:41 --> Helper loaded: date_helper
INFO - 2016-06-02 18:03:41 --> Controller Class Initialized
INFO - 2016-06-02 18:03:41 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:03:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:03:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:03:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:03:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:03:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:03:41 --> Model Class Initialized
INFO - 2016-06-02 18:03:41 --> Form Validation Class Initialized
INFO - 2016-06-02 18:03:41 --> Final output sent to browser
DEBUG - 2016-06-02 18:03:41 --> Total execution time: 0.0564
INFO - 2016-06-02 18:03:48 --> Config Class Initialized
INFO - 2016-06-02 18:03:48 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:03:48 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:03:48 --> Utf8 Class Initialized
INFO - 2016-06-02 18:03:48 --> URI Class Initialized
INFO - 2016-06-02 18:03:48 --> Router Class Initialized
INFO - 2016-06-02 18:03:48 --> Output Class Initialized
INFO - 2016-06-02 18:03:48 --> Security Class Initialized
DEBUG - 2016-06-02 18:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:03:48 --> CSRF cookie sent
INFO - 2016-06-02 18:03:48 --> CSRF token verified
INFO - 2016-06-02 18:03:48 --> Input Class Initialized
INFO - 2016-06-02 18:03:48 --> Language Class Initialized
INFO - 2016-06-02 18:03:48 --> Loader Class Initialized
INFO - 2016-06-02 18:03:48 --> Helper loaded: form_helper
INFO - 2016-06-02 18:03:48 --> Database Driver Class Initialized
INFO - 2016-06-02 18:03:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:03:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:03:48 --> Email Class Initialized
INFO - 2016-06-02 18:03:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:03:48 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:03:48 --> Helper loaded: language_helper
INFO - 2016-06-02 18:03:48 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:03:48 --> Model Class Initialized
INFO - 2016-06-02 18:03:48 --> Helper loaded: date_helper
INFO - 2016-06-02 18:03:48 --> Controller Class Initialized
INFO - 2016-06-02 18:03:48 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:03:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:03:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:03:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:03:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:03:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:03:49 --> Model Class Initialized
INFO - 2016-06-02 18:03:49 --> Form Validation Class Initialized
INFO - 2016-06-02 18:03:49 --> Final output sent to browser
DEBUG - 2016-06-02 18:03:49 --> Total execution time: 0.0824
INFO - 2016-06-02 18:04:27 --> Config Class Initialized
INFO - 2016-06-02 18:04:27 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:04:27 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:04:27 --> Utf8 Class Initialized
INFO - 2016-06-02 18:04:27 --> URI Class Initialized
INFO - 2016-06-02 18:04:27 --> Router Class Initialized
INFO - 2016-06-02 18:04:27 --> Output Class Initialized
INFO - 2016-06-02 18:04:27 --> Security Class Initialized
DEBUG - 2016-06-02 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:04:27 --> CSRF cookie sent
INFO - 2016-06-02 18:04:27 --> CSRF token verified
INFO - 2016-06-02 18:04:27 --> Input Class Initialized
INFO - 2016-06-02 18:04:27 --> Language Class Initialized
INFO - 2016-06-02 18:04:27 --> Loader Class Initialized
INFO - 2016-06-02 18:04:27 --> Helper loaded: form_helper
INFO - 2016-06-02 18:04:27 --> Database Driver Class Initialized
INFO - 2016-06-02 18:04:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:04:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:04:27 --> Email Class Initialized
INFO - 2016-06-02 18:04:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:04:27 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:04:27 --> Helper loaded: language_helper
INFO - 2016-06-02 18:04:27 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:04:27 --> Model Class Initialized
INFO - 2016-06-02 18:04:27 --> Helper loaded: date_helper
INFO - 2016-06-02 18:04:27 --> Controller Class Initialized
INFO - 2016-06-02 18:04:27 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:04:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:04:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:04:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:04:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:04:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:04:27 --> Model Class Initialized
INFO - 2016-06-02 18:04:27 --> Form Validation Class Initialized
INFO - 2016-06-02 18:04:27 --> Final output sent to browser
DEBUG - 2016-06-02 18:04:27 --> Total execution time: 0.0580
INFO - 2016-06-02 18:04:34 --> Config Class Initialized
INFO - 2016-06-02 18:04:34 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:04:34 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:04:34 --> Utf8 Class Initialized
INFO - 2016-06-02 18:04:34 --> URI Class Initialized
INFO - 2016-06-02 18:04:34 --> Router Class Initialized
INFO - 2016-06-02 18:04:34 --> Output Class Initialized
INFO - 2016-06-02 18:04:34 --> Security Class Initialized
DEBUG - 2016-06-02 18:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:04:34 --> CSRF cookie sent
INFO - 2016-06-02 18:04:34 --> CSRF token verified
INFO - 2016-06-02 18:04:34 --> Input Class Initialized
INFO - 2016-06-02 18:04:34 --> Language Class Initialized
INFO - 2016-06-02 18:04:34 --> Loader Class Initialized
INFO - 2016-06-02 18:04:34 --> Helper loaded: form_helper
INFO - 2016-06-02 18:04:34 --> Database Driver Class Initialized
INFO - 2016-06-02 18:04:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:04:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:04:34 --> Email Class Initialized
INFO - 2016-06-02 18:04:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:04:34 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:04:34 --> Helper loaded: language_helper
INFO - 2016-06-02 18:04:34 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:04:34 --> Model Class Initialized
INFO - 2016-06-02 18:04:34 --> Helper loaded: date_helper
INFO - 2016-06-02 18:04:34 --> Controller Class Initialized
INFO - 2016-06-02 18:04:34 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:04:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:04:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:04:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:04:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:04:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:04:34 --> Model Class Initialized
INFO - 2016-06-02 18:04:34 --> Form Validation Class Initialized
INFO - 2016-06-02 18:04:34 --> Final output sent to browser
DEBUG - 2016-06-02 18:04:34 --> Total execution time: 0.0768
INFO - 2016-06-02 18:04:40 --> Config Class Initialized
INFO - 2016-06-02 18:04:40 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:04:40 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:04:40 --> Utf8 Class Initialized
INFO - 2016-06-02 18:04:40 --> URI Class Initialized
INFO - 2016-06-02 18:04:40 --> Router Class Initialized
INFO - 2016-06-02 18:04:40 --> Output Class Initialized
INFO - 2016-06-02 18:04:40 --> Security Class Initialized
DEBUG - 2016-06-02 18:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:04:40 --> CSRF cookie sent
INFO - 2016-06-02 18:04:40 --> CSRF token verified
INFO - 2016-06-02 18:04:40 --> Input Class Initialized
INFO - 2016-06-02 18:04:40 --> Language Class Initialized
INFO - 2016-06-02 18:04:40 --> Loader Class Initialized
INFO - 2016-06-02 18:04:40 --> Helper loaded: form_helper
INFO - 2016-06-02 18:04:40 --> Database Driver Class Initialized
INFO - 2016-06-02 18:04:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:04:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:04:40 --> Email Class Initialized
INFO - 2016-06-02 18:04:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:04:40 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:04:40 --> Helper loaded: language_helper
INFO - 2016-06-02 18:04:40 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:04:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:04:40 --> Model Class Initialized
INFO - 2016-06-02 18:04:40 --> Helper loaded: date_helper
INFO - 2016-06-02 18:04:40 --> Controller Class Initialized
INFO - 2016-06-02 18:04:40 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:04:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:04:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:04:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:04:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:04:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:04:40 --> Model Class Initialized
INFO - 2016-06-02 18:04:40 --> Form Validation Class Initialized
INFO - 2016-06-02 18:04:40 --> Final output sent to browser
DEBUG - 2016-06-02 18:04:40 --> Total execution time: 0.0600
INFO - 2016-06-02 18:04:46 --> Config Class Initialized
INFO - 2016-06-02 18:04:46 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:04:46 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:04:46 --> Utf8 Class Initialized
INFO - 2016-06-02 18:04:46 --> URI Class Initialized
INFO - 2016-06-02 18:04:46 --> Router Class Initialized
INFO - 2016-06-02 18:04:46 --> Output Class Initialized
INFO - 2016-06-02 18:04:46 --> Security Class Initialized
DEBUG - 2016-06-02 18:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:04:46 --> CSRF cookie sent
INFO - 2016-06-02 18:04:46 --> CSRF token verified
INFO - 2016-06-02 18:04:46 --> Input Class Initialized
INFO - 2016-06-02 18:04:46 --> Language Class Initialized
INFO - 2016-06-02 18:04:46 --> Loader Class Initialized
INFO - 2016-06-02 18:04:46 --> Helper loaded: form_helper
INFO - 2016-06-02 18:04:46 --> Database Driver Class Initialized
INFO - 2016-06-02 18:04:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:04:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:04:46 --> Email Class Initialized
INFO - 2016-06-02 18:04:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:04:46 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:04:46 --> Helper loaded: language_helper
INFO - 2016-06-02 18:04:46 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:04:46 --> Model Class Initialized
INFO - 2016-06-02 18:04:46 --> Helper loaded: date_helper
INFO - 2016-06-02 18:04:46 --> Controller Class Initialized
INFO - 2016-06-02 18:04:46 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:04:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:04:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:04:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:04:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:04:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:04:46 --> Model Class Initialized
INFO - 2016-06-02 18:04:46 --> Form Validation Class Initialized
INFO - 2016-06-02 18:04:46 --> Final output sent to browser
DEBUG - 2016-06-02 18:04:46 --> Total execution time: 0.0346
INFO - 2016-06-02 18:04:50 --> Config Class Initialized
INFO - 2016-06-02 18:04:50 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:04:50 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:04:50 --> Utf8 Class Initialized
INFO - 2016-06-02 18:04:50 --> URI Class Initialized
INFO - 2016-06-02 18:04:50 --> Router Class Initialized
INFO - 2016-06-02 18:04:50 --> Output Class Initialized
INFO - 2016-06-02 18:04:50 --> Security Class Initialized
DEBUG - 2016-06-02 18:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:04:50 --> CSRF cookie sent
INFO - 2016-06-02 18:04:50 --> CSRF token verified
INFO - 2016-06-02 18:04:50 --> Input Class Initialized
INFO - 2016-06-02 18:04:50 --> Language Class Initialized
INFO - 2016-06-02 18:04:50 --> Loader Class Initialized
INFO - 2016-06-02 18:04:50 --> Helper loaded: form_helper
INFO - 2016-06-02 18:04:50 --> Database Driver Class Initialized
INFO - 2016-06-02 18:04:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:04:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:04:50 --> Email Class Initialized
INFO - 2016-06-02 18:04:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:04:50 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:04:50 --> Helper loaded: language_helper
INFO - 2016-06-02 18:04:50 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:04:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:04:50 --> Model Class Initialized
INFO - 2016-06-02 18:04:50 --> Helper loaded: date_helper
INFO - 2016-06-02 18:04:50 --> Controller Class Initialized
INFO - 2016-06-02 18:04:50 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:04:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:04:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:04:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:04:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:04:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:04:50 --> Model Class Initialized
INFO - 2016-06-02 18:04:50 --> Form Validation Class Initialized
INFO - 2016-06-02 18:04:50 --> Final output sent to browser
DEBUG - 2016-06-02 18:04:50 --> Total execution time: 0.0535
INFO - 2016-06-02 18:13:28 --> Config Class Initialized
INFO - 2016-06-02 18:13:28 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:13:28 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:13:28 --> Utf8 Class Initialized
INFO - 2016-06-02 18:13:28 --> URI Class Initialized
INFO - 2016-06-02 18:13:28 --> Router Class Initialized
INFO - 2016-06-02 18:13:28 --> Output Class Initialized
INFO - 2016-06-02 18:13:28 --> Security Class Initialized
DEBUG - 2016-06-02 18:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:13:28 --> CSRF cookie sent
INFO - 2016-06-02 18:13:28 --> Input Class Initialized
INFO - 2016-06-02 18:13:28 --> Language Class Initialized
INFO - 2016-06-02 18:13:28 --> Loader Class Initialized
INFO - 2016-06-02 18:13:28 --> Helper loaded: form_helper
INFO - 2016-06-02 18:13:28 --> Database Driver Class Initialized
INFO - 2016-06-02 18:13:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:13:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:13:28 --> Email Class Initialized
INFO - 2016-06-02 18:13:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:13:28 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:13:28 --> Helper loaded: language_helper
INFO - 2016-06-02 18:13:28 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:13:28 --> Model Class Initialized
INFO - 2016-06-02 18:13:28 --> Helper loaded: date_helper
INFO - 2016-06-02 18:13:28 --> Controller Class Initialized
INFO - 2016-06-02 18:13:28 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:13:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:13:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:13:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:13:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:13:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:13:28 --> Model Class Initialized
INFO - 2016-06-02 18:13:28 --> Form Validation Class Initialized
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-02 18:13:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-02 18:13:28 --> Final output sent to browser
DEBUG - 2016-06-02 18:13:28 --> Total execution time: 0.1312
INFO - 2016-06-02 18:13:30 --> Config Class Initialized
INFO - 2016-06-02 18:13:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:13:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:13:30 --> Utf8 Class Initialized
INFO - 2016-06-02 18:13:30 --> URI Class Initialized
INFO - 2016-06-02 18:13:30 --> Router Class Initialized
INFO - 2016-06-02 18:13:30 --> Output Class Initialized
INFO - 2016-06-02 18:13:30 --> Security Class Initialized
DEBUG - 2016-06-02 18:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:13:30 --> CSRF cookie sent
INFO - 2016-06-02 18:13:30 --> CSRF token verified
INFO - 2016-06-02 18:13:30 --> Input Class Initialized
INFO - 2016-06-02 18:13:30 --> Language Class Initialized
INFO - 2016-06-02 18:13:30 --> Loader Class Initialized
INFO - 2016-06-02 18:13:30 --> Helper loaded: form_helper
INFO - 2016-06-02 18:13:30 --> Database Driver Class Initialized
INFO - 2016-06-02 18:13:30 --> Config Class Initialized
INFO - 2016-06-02 18:13:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:13:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:13:30 --> Utf8 Class Initialized
INFO - 2016-06-02 18:13:30 --> URI Class Initialized
INFO - 2016-06-02 18:13:30 --> Router Class Initialized
INFO - 2016-06-02 18:13:30 --> Output Class Initialized
INFO - 2016-06-02 18:13:30 --> Security Class Initialized
DEBUG - 2016-06-02 18:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:13:30 --> CSRF cookie sent
INFO - 2016-06-02 18:13:30 --> CSRF token verified
INFO - 2016-06-02 18:13:30 --> Input Class Initialized
INFO - 2016-06-02 18:13:30 --> Language Class Initialized
INFO - 2016-06-02 18:13:30 --> Loader Class Initialized
INFO - 2016-06-02 18:13:30 --> Helper loaded: form_helper
INFO - 2016-06-02 18:13:30 --> Database Driver Class Initialized
INFO - 2016-06-02 18:13:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:13:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:13:30 --> Email Class Initialized
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:13:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:13:30 --> Helper loaded: language_helper
INFO - 2016-06-02 18:13:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:13:30 --> Model Class Initialized
INFO - 2016-06-02 18:13:30 --> Helper loaded: date_helper
INFO - 2016-06-02 18:13:30 --> Controller Class Initialized
INFO - 2016-06-02 18:13:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:13:30 --> Model Class Initialized
INFO - 2016-06-02 18:13:30 --> Form Validation Class Initialized
INFO - 2016-06-02 18:13:30 --> Final output sent to browser
DEBUG - 2016-06-02 18:13:30 --> Total execution time: 0.0761
INFO - 2016-06-02 18:13:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-02 18:13:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-02 18:13:30 --> Email Class Initialized
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-02 18:13:30 --> Helper loaded: cookie_helper
INFO - 2016-06-02 18:13:30 --> Helper loaded: language_helper
INFO - 2016-06-02 18:13:30 --> Helper loaded: url_helper
DEBUG - 2016-06-02 18:13:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-02 18:13:30 --> Model Class Initialized
INFO - 2016-06-02 18:13:30 --> Helper loaded: date_helper
INFO - 2016-06-02 18:13:30 --> Controller Class Initialized
INFO - 2016-06-02 18:13:30 --> Helper loaded: languages_helper
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-02 18:13:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-02 18:13:30 --> Model Class Initialized
INFO - 2016-06-02 18:13:30 --> Form Validation Class Initialized
INFO - 2016-06-02 18:13:30 --> Final output sent to browser
DEBUG - 2016-06-02 18:13:30 --> Total execution time: 0.0620
INFO - 2016-06-02 18:13:30 --> Config Class Initialized
INFO - 2016-06-02 18:13:30 --> Hooks Class Initialized
DEBUG - 2016-06-02 18:13:30 --> UTF-8 Support Enabled
INFO - 2016-06-02 18:13:30 --> Utf8 Class Initialized
INFO - 2016-06-02 18:13:30 --> URI Class Initialized
INFO - 2016-06-02 18:13:30 --> Router Class Initialized
INFO - 2016-06-02 18:13:30 --> Output Class Initialized
INFO - 2016-06-02 18:13:30 --> Security Class Initialized
DEBUG - 2016-06-02 18:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-02 18:13:30 --> CSRF cookie sent
INFO - 2016-06-02 18:13:30 --> Input Class Initialized
INFO - 2016-06-02 18:13:30 --> Language Class Initialized
ERROR - 2016-06-02 18:13:30 --> 404 Page Not Found: Faviconico/index
