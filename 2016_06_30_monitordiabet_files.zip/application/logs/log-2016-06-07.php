<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-07 10:19:47 --> Config Class Initialized
INFO - 2016-06-07 10:19:47 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:19:47 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:19:47 --> Utf8 Class Initialized
INFO - 2016-06-07 10:19:47 --> URI Class Initialized
INFO - 2016-06-07 10:19:47 --> Router Class Initialized
INFO - 2016-06-07 10:19:47 --> Output Class Initialized
INFO - 2016-06-07 10:19:47 --> Security Class Initialized
DEBUG - 2016-06-07 10:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:19:47 --> Input Class Initialized
INFO - 2016-06-07 10:19:47 --> Language Class Initialized
INFO - 2016-06-07 10:19:47 --> Loader Class Initialized
INFO - 2016-06-07 10:19:47 --> Helper loaded: form_helper
INFO - 2016-06-07 10:19:47 --> Database Driver Class Initialized
INFO - 2016-06-07 10:19:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:19:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:19:47 --> Email Class Initialized
INFO - 2016-06-07 10:19:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:19:47 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:19:47 --> Helper loaded: language_helper
INFO - 2016-06-07 10:19:47 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:19:47 --> Model Class Initialized
INFO - 2016-06-07 10:19:47 --> Helper loaded: date_helper
INFO - 2016-06-07 10:19:47 --> Controller Class Initialized
INFO - 2016-06-07 10:19:47 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:19:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:19:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:19:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:19:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:19:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:19:48 --> Model Class Initialized
INFO - 2016-06-07 10:19:48 --> Form Validation Class Initialized
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:19:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:19:48 --> Final output sent to browser
DEBUG - 2016-06-07 10:19:48 --> Total execution time: 1.1423
INFO - 2016-06-07 10:19:52 --> Config Class Initialized
INFO - 2016-06-07 10:19:52 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:19:52 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:19:52 --> Utf8 Class Initialized
INFO - 2016-06-07 10:19:52 --> URI Class Initialized
INFO - 2016-06-07 10:19:52 --> Router Class Initialized
INFO - 2016-06-07 10:19:52 --> Output Class Initialized
INFO - 2016-06-07 10:19:52 --> Security Class Initialized
DEBUG - 2016-06-07 10:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:19:52 --> Input Class Initialized
INFO - 2016-06-07 10:19:52 --> Language Class Initialized
INFO - 2016-06-07 10:19:52 --> Loader Class Initialized
INFO - 2016-06-07 10:19:52 --> Helper loaded: form_helper
INFO - 2016-06-07 10:19:52 --> Database Driver Class Initialized
INFO - 2016-06-07 10:19:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:19:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:19:52 --> Email Class Initialized
INFO - 2016-06-07 10:19:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:19:52 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:19:52 --> Helper loaded: language_helper
INFO - 2016-06-07 10:19:52 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:19:52 --> Model Class Initialized
INFO - 2016-06-07 10:19:52 --> Helper loaded: date_helper
INFO - 2016-06-07 10:19:52 --> Controller Class Initialized
INFO - 2016-06-07 10:19:52 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:19:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:19:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:19:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:19:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:19:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:19:52 --> Model Class Initialized
INFO - 2016-06-07 10:19:52 --> Form Validation Class Initialized
INFO - 2016-06-07 10:19:52 --> Final output sent to browser
DEBUG - 2016-06-07 10:19:52 --> Total execution time: 0.0577
INFO - 2016-06-07 10:19:52 --> Config Class Initialized
INFO - 2016-06-07 10:19:52 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:19:52 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:19:52 --> Utf8 Class Initialized
INFO - 2016-06-07 10:19:52 --> URI Class Initialized
INFO - 2016-06-07 10:19:52 --> Router Class Initialized
INFO - 2016-06-07 10:19:52 --> Output Class Initialized
INFO - 2016-06-07 10:19:52 --> Security Class Initialized
DEBUG - 2016-06-07 10:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:19:52 --> Input Class Initialized
INFO - 2016-06-07 10:19:52 --> Language Class Initialized
ERROR - 2016-06-07 10:19:52 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-07 10:22:41 --> Config Class Initialized
INFO - 2016-06-07 10:22:41 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:22:41 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:22:41 --> Utf8 Class Initialized
INFO - 2016-06-07 10:22:41 --> URI Class Initialized
INFO - 2016-06-07 10:22:41 --> Router Class Initialized
INFO - 2016-06-07 10:22:41 --> Output Class Initialized
INFO - 2016-06-07 10:22:41 --> Security Class Initialized
DEBUG - 2016-06-07 10:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:22:41 --> Input Class Initialized
INFO - 2016-06-07 10:22:41 --> Language Class Initialized
INFO - 2016-06-07 10:22:41 --> Loader Class Initialized
INFO - 2016-06-07 10:22:41 --> Helper loaded: form_helper
INFO - 2016-06-07 10:22:41 --> Database Driver Class Initialized
INFO - 2016-06-07 10:22:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:22:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:22:41 --> Email Class Initialized
INFO - 2016-06-07 10:22:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:22:41 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:22:41 --> Helper loaded: language_helper
INFO - 2016-06-07 10:22:41 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:22:41 --> Model Class Initialized
INFO - 2016-06-07 10:22:41 --> Helper loaded: date_helper
INFO - 2016-06-07 10:22:41 --> Controller Class Initialized
INFO - 2016-06-07 10:22:41 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:22:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:22:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:22:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:22:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:22:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:22:41 --> Model Class Initialized
INFO - 2016-06-07 10:22:41 --> Form Validation Class Initialized
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 41
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 48
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 55
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 62
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 69
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 77
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 84
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 91
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 98
ERROR - 2016-06-07 10:22:41 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 105
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:22:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:22:41 --> Final output sent to browser
DEBUG - 2016-06-07 10:22:41 --> Total execution time: 0.1359
INFO - 2016-06-07 10:22:43 --> Config Class Initialized
INFO - 2016-06-07 10:22:43 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:22:43 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:22:43 --> Utf8 Class Initialized
INFO - 2016-06-07 10:22:43 --> URI Class Initialized
INFO - 2016-06-07 10:22:43 --> Router Class Initialized
INFO - 2016-06-07 10:22:43 --> Output Class Initialized
INFO - 2016-06-07 10:22:43 --> Security Class Initialized
DEBUG - 2016-06-07 10:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:22:43 --> Input Class Initialized
INFO - 2016-06-07 10:22:43 --> Language Class Initialized
INFO - 2016-06-07 10:22:43 --> Loader Class Initialized
INFO - 2016-06-07 10:22:43 --> Helper loaded: form_helper
INFO - 2016-06-07 10:22:43 --> Database Driver Class Initialized
INFO - 2016-06-07 10:22:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:22:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:22:43 --> Email Class Initialized
INFO - 2016-06-07 10:22:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:22:43 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:22:43 --> Helper loaded: language_helper
INFO - 2016-06-07 10:22:43 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:22:43 --> Model Class Initialized
INFO - 2016-06-07 10:22:43 --> Helper loaded: date_helper
INFO - 2016-06-07 10:22:43 --> Controller Class Initialized
INFO - 2016-06-07 10:22:43 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:22:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:22:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:22:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:22:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:22:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:22:43 --> Model Class Initialized
INFO - 2016-06-07 10:22:43 --> Form Validation Class Initialized
INFO - 2016-06-07 10:22:43 --> Final output sent to browser
DEBUG - 2016-06-07 10:22:43 --> Total execution time: 0.0344
INFO - 2016-06-07 10:23:20 --> Config Class Initialized
INFO - 2016-06-07 10:23:20 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:23:20 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:23:20 --> Utf8 Class Initialized
INFO - 2016-06-07 10:23:20 --> URI Class Initialized
INFO - 2016-06-07 10:23:20 --> Router Class Initialized
INFO - 2016-06-07 10:23:20 --> Output Class Initialized
INFO - 2016-06-07 10:23:20 --> Security Class Initialized
DEBUG - 2016-06-07 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:23:20 --> Input Class Initialized
INFO - 2016-06-07 10:23:20 --> Language Class Initialized
INFO - 2016-06-07 10:23:20 --> Loader Class Initialized
INFO - 2016-06-07 10:23:20 --> Helper loaded: form_helper
INFO - 2016-06-07 10:23:20 --> Database Driver Class Initialized
INFO - 2016-06-07 10:23:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:23:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:23:20 --> Email Class Initialized
INFO - 2016-06-07 10:23:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:23:20 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:23:20 --> Helper loaded: language_helper
INFO - 2016-06-07 10:23:20 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:23:20 --> Model Class Initialized
INFO - 2016-06-07 10:23:20 --> Helper loaded: date_helper
INFO - 2016-06-07 10:23:20 --> Controller Class Initialized
INFO - 2016-06-07 10:23:20 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:23:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:23:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:23:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:23:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:23:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:23:20 --> Model Class Initialized
INFO - 2016-06-07 10:23:20 --> Form Validation Class Initialized
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 41
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 48
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 55
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 62
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 69
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 77
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 84
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 91
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 98
ERROR - 2016-06-07 10:23:20 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 105
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:23:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:23:20 --> Final output sent to browser
DEBUG - 2016-06-07 10:23:20 --> Total execution time: 0.1491
INFO - 2016-06-07 10:23:22 --> Config Class Initialized
INFO - 2016-06-07 10:23:22 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:23:22 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:23:22 --> Utf8 Class Initialized
INFO - 2016-06-07 10:23:22 --> URI Class Initialized
INFO - 2016-06-07 10:23:22 --> Router Class Initialized
INFO - 2016-06-07 10:23:22 --> Output Class Initialized
INFO - 2016-06-07 10:23:22 --> Security Class Initialized
DEBUG - 2016-06-07 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:23:22 --> Input Class Initialized
INFO - 2016-06-07 10:23:22 --> Language Class Initialized
INFO - 2016-06-07 10:23:22 --> Loader Class Initialized
INFO - 2016-06-07 10:23:22 --> Helper loaded: form_helper
INFO - 2016-06-07 10:23:22 --> Database Driver Class Initialized
INFO - 2016-06-07 10:23:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:23:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:23:22 --> Email Class Initialized
INFO - 2016-06-07 10:23:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:23:22 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:23:22 --> Helper loaded: language_helper
INFO - 2016-06-07 10:23:22 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:23:22 --> Model Class Initialized
INFO - 2016-06-07 10:23:22 --> Helper loaded: date_helper
INFO - 2016-06-07 10:23:22 --> Controller Class Initialized
INFO - 2016-06-07 10:23:22 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:23:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:23:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:23:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:23:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:23:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:23:22 --> Model Class Initialized
INFO - 2016-06-07 10:23:22 --> Form Validation Class Initialized
INFO - 2016-06-07 10:23:22 --> Final output sent to browser
DEBUG - 2016-06-07 10:23:22 --> Total execution time: 0.0151
INFO - 2016-06-07 10:26:41 --> Config Class Initialized
INFO - 2016-06-07 10:26:41 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:26:41 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:26:41 --> Utf8 Class Initialized
INFO - 2016-06-07 10:26:41 --> URI Class Initialized
INFO - 2016-06-07 10:26:41 --> Router Class Initialized
INFO - 2016-06-07 10:26:41 --> Output Class Initialized
INFO - 2016-06-07 10:26:41 --> Security Class Initialized
DEBUG - 2016-06-07 10:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:26:41 --> Input Class Initialized
INFO - 2016-06-07 10:26:41 --> Language Class Initialized
INFO - 2016-06-07 10:26:41 --> Loader Class Initialized
INFO - 2016-06-07 10:26:41 --> Helper loaded: form_helper
INFO - 2016-06-07 10:26:41 --> Database Driver Class Initialized
INFO - 2016-06-07 10:26:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:26:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:26:41 --> Email Class Initialized
INFO - 2016-06-07 10:26:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:26:41 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:26:41 --> Helper loaded: language_helper
INFO - 2016-06-07 10:26:41 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:26:41 --> Model Class Initialized
INFO - 2016-06-07 10:26:41 --> Helper loaded: date_helper
INFO - 2016-06-07 10:26:41 --> Controller Class Initialized
INFO - 2016-06-07 10:26:41 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:26:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:26:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:26:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:26:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:26:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:26:41 --> Model Class Initialized
INFO - 2016-06-07 10:26:41 --> Form Validation Class Initialized
INFO - 2016-06-07 10:27:35 --> Config Class Initialized
INFO - 2016-06-07 10:27:35 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:27:35 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:27:35 --> Utf8 Class Initialized
INFO - 2016-06-07 10:27:35 --> URI Class Initialized
INFO - 2016-06-07 10:27:35 --> Router Class Initialized
INFO - 2016-06-07 10:27:35 --> Output Class Initialized
INFO - 2016-06-07 10:27:35 --> Security Class Initialized
DEBUG - 2016-06-07 10:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:27:35 --> Input Class Initialized
INFO - 2016-06-07 10:27:35 --> Language Class Initialized
INFO - 2016-06-07 10:27:35 --> Loader Class Initialized
INFO - 2016-06-07 10:27:35 --> Helper loaded: form_helper
INFO - 2016-06-07 10:27:35 --> Database Driver Class Initialized
INFO - 2016-06-07 10:27:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:27:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:27:35 --> Email Class Initialized
INFO - 2016-06-07 10:27:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:27:35 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:27:35 --> Helper loaded: language_helper
INFO - 2016-06-07 10:27:35 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:27:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:27:35 --> Model Class Initialized
INFO - 2016-06-07 10:27:35 --> Helper loaded: date_helper
INFO - 2016-06-07 10:27:35 --> Controller Class Initialized
INFO - 2016-06-07 10:27:35 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:27:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:27:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:27:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:27:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:27:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:27:35 --> Model Class Initialized
INFO - 2016-06-07 10:27:35 --> Form Validation Class Initialized
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:27:35 --> Final output sent to browser
DEBUG - 2016-06-07 10:27:35 --> Total execution time: 0.0521
INFO - 2016-06-07 10:27:37 --> Config Class Initialized
INFO - 2016-06-07 10:27:37 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:27:37 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:27:37 --> Utf8 Class Initialized
INFO - 2016-06-07 10:27:37 --> URI Class Initialized
INFO - 2016-06-07 10:27:37 --> Router Class Initialized
INFO - 2016-06-07 10:27:37 --> Output Class Initialized
INFO - 2016-06-07 10:27:37 --> Security Class Initialized
DEBUG - 2016-06-07 10:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:27:37 --> Input Class Initialized
INFO - 2016-06-07 10:27:37 --> Language Class Initialized
INFO - 2016-06-07 10:27:37 --> Loader Class Initialized
INFO - 2016-06-07 10:27:37 --> Helper loaded: form_helper
INFO - 2016-06-07 10:27:37 --> Database Driver Class Initialized
INFO - 2016-06-07 10:27:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:27:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:27:37 --> Email Class Initialized
INFO - 2016-06-07 10:27:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:27:37 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:27:37 --> Helper loaded: language_helper
INFO - 2016-06-07 10:27:37 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:27:37 --> Model Class Initialized
INFO - 2016-06-07 10:27:37 --> Helper loaded: date_helper
INFO - 2016-06-07 10:27:37 --> Controller Class Initialized
INFO - 2016-06-07 10:27:37 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:27:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:27:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:27:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:27:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:27:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:27:37 --> Model Class Initialized
INFO - 2016-06-07 10:27:37 --> Form Validation Class Initialized
INFO - 2016-06-07 10:27:37 --> Final output sent to browser
DEBUG - 2016-06-07 10:27:37 --> Total execution time: 0.0322
INFO - 2016-06-07 10:37:14 --> Config Class Initialized
INFO - 2016-06-07 10:37:14 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:37:14 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:37:14 --> Utf8 Class Initialized
INFO - 2016-06-07 10:37:14 --> URI Class Initialized
INFO - 2016-06-07 10:37:14 --> Router Class Initialized
INFO - 2016-06-07 10:37:14 --> Output Class Initialized
INFO - 2016-06-07 10:37:14 --> Security Class Initialized
DEBUG - 2016-06-07 10:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:37:14 --> Input Class Initialized
INFO - 2016-06-07 10:37:14 --> Language Class Initialized
INFO - 2016-06-07 10:37:14 --> Loader Class Initialized
INFO - 2016-06-07 10:37:14 --> Helper loaded: form_helper
INFO - 2016-06-07 10:37:14 --> Database Driver Class Initialized
INFO - 2016-06-07 10:37:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:37:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:37:14 --> Email Class Initialized
INFO - 2016-06-07 10:37:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:37:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:37:15 --> Helper loaded: language_helper
INFO - 2016-06-07 10:37:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:37:15 --> Model Class Initialized
INFO - 2016-06-07 10:37:15 --> Helper loaded: date_helper
INFO - 2016-06-07 10:37:15 --> Controller Class Initialized
INFO - 2016-06-07 10:37:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:37:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:37:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:37:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:37:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:37:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:37:15 --> Model Class Initialized
INFO - 2016-06-07 10:37:15 --> Form Validation Class Initialized
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:37:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:37:15 --> Final output sent to browser
DEBUG - 2016-06-07 10:37:15 --> Total execution time: 1.7113
INFO - 2016-06-07 10:37:19 --> Config Class Initialized
INFO - 2016-06-07 10:37:19 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:37:19 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:37:19 --> Utf8 Class Initialized
INFO - 2016-06-07 10:37:19 --> URI Class Initialized
INFO - 2016-06-07 10:37:19 --> Router Class Initialized
INFO - 2016-06-07 10:37:19 --> Output Class Initialized
INFO - 2016-06-07 10:37:19 --> Security Class Initialized
DEBUG - 2016-06-07 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:37:19 --> Input Class Initialized
INFO - 2016-06-07 10:37:19 --> Language Class Initialized
INFO - 2016-06-07 10:37:19 --> Loader Class Initialized
INFO - 2016-06-07 10:37:19 --> Helper loaded: form_helper
INFO - 2016-06-07 10:37:19 --> Database Driver Class Initialized
INFO - 2016-06-07 10:37:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:37:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:37:19 --> Email Class Initialized
INFO - 2016-06-07 10:37:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:37:19 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:37:19 --> Helper loaded: language_helper
INFO - 2016-06-07 10:37:19 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:37:19 --> Model Class Initialized
INFO - 2016-06-07 10:37:19 --> Helper loaded: date_helper
INFO - 2016-06-07 10:37:19 --> Controller Class Initialized
INFO - 2016-06-07 10:37:19 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:37:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:37:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:37:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:37:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:37:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:37:19 --> Model Class Initialized
INFO - 2016-06-07 10:37:19 --> Form Validation Class Initialized
INFO - 2016-06-07 10:37:19 --> Final output sent to browser
DEBUG - 2016-06-07 10:37:19 --> Total execution time: 0.1799
INFO - 2016-06-07 10:38:17 --> Config Class Initialized
INFO - 2016-06-07 10:38:17 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:38:17 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:38:17 --> Utf8 Class Initialized
INFO - 2016-06-07 10:38:17 --> URI Class Initialized
INFO - 2016-06-07 10:38:17 --> Router Class Initialized
INFO - 2016-06-07 10:38:17 --> Output Class Initialized
INFO - 2016-06-07 10:38:17 --> Security Class Initialized
DEBUG - 2016-06-07 10:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:38:17 --> Input Class Initialized
INFO - 2016-06-07 10:38:17 --> Language Class Initialized
INFO - 2016-06-07 10:38:17 --> Loader Class Initialized
INFO - 2016-06-07 10:38:17 --> Helper loaded: form_helper
INFO - 2016-06-07 10:38:17 --> Database Driver Class Initialized
INFO - 2016-06-07 10:38:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:38:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:38:17 --> Email Class Initialized
INFO - 2016-06-07 10:38:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:38:17 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:38:17 --> Helper loaded: language_helper
INFO - 2016-06-07 10:38:17 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:38:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:38:17 --> Model Class Initialized
INFO - 2016-06-07 10:38:17 --> Helper loaded: date_helper
INFO - 2016-06-07 10:38:17 --> Controller Class Initialized
INFO - 2016-06-07 10:38:17 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:38:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:38:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:38:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:38:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:38:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:38:17 --> Model Class Initialized
INFO - 2016-06-07 10:38:17 --> Form Validation Class Initialized
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:38:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:38:17 --> Final output sent to browser
DEBUG - 2016-06-07 10:38:17 --> Total execution time: 0.2010
INFO - 2016-06-07 10:38:19 --> Config Class Initialized
INFO - 2016-06-07 10:38:19 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:38:19 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:38:19 --> Utf8 Class Initialized
INFO - 2016-06-07 10:38:19 --> URI Class Initialized
INFO - 2016-06-07 10:38:19 --> Router Class Initialized
INFO - 2016-06-07 10:38:19 --> Output Class Initialized
INFO - 2016-06-07 10:38:19 --> Security Class Initialized
DEBUG - 2016-06-07 10:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:38:19 --> Input Class Initialized
INFO - 2016-06-07 10:38:19 --> Language Class Initialized
INFO - 2016-06-07 10:38:19 --> Loader Class Initialized
INFO - 2016-06-07 10:38:19 --> Helper loaded: form_helper
INFO - 2016-06-07 10:38:19 --> Database Driver Class Initialized
INFO - 2016-06-07 10:38:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:38:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:38:19 --> Email Class Initialized
INFO - 2016-06-07 10:38:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:38:19 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:38:19 --> Helper loaded: language_helper
INFO - 2016-06-07 10:38:19 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:38:19 --> Model Class Initialized
INFO - 2016-06-07 10:38:19 --> Helper loaded: date_helper
INFO - 2016-06-07 10:38:19 --> Controller Class Initialized
INFO - 2016-06-07 10:38:19 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:38:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:38:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:38:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:38:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:38:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:38:19 --> Model Class Initialized
INFO - 2016-06-07 10:38:19 --> Form Validation Class Initialized
INFO - 2016-06-07 10:38:19 --> Final output sent to browser
DEBUG - 2016-06-07 10:38:19 --> Total execution time: 0.0430
INFO - 2016-06-07 10:39:39 --> Config Class Initialized
INFO - 2016-06-07 10:39:39 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:39:39 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:39:39 --> Utf8 Class Initialized
INFO - 2016-06-07 10:39:39 --> URI Class Initialized
INFO - 2016-06-07 10:39:39 --> Router Class Initialized
INFO - 2016-06-07 10:39:39 --> Output Class Initialized
INFO - 2016-06-07 10:39:39 --> Security Class Initialized
DEBUG - 2016-06-07 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:39:40 --> Input Class Initialized
INFO - 2016-06-07 10:39:40 --> Language Class Initialized
INFO - 2016-06-07 10:39:40 --> Loader Class Initialized
INFO - 2016-06-07 10:39:40 --> Helper loaded: form_helper
INFO - 2016-06-07 10:39:40 --> Database Driver Class Initialized
INFO - 2016-06-07 10:39:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:39:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:39:40 --> Email Class Initialized
INFO - 2016-06-07 10:39:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:39:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:39:40 --> Helper loaded: language_helper
INFO - 2016-06-07 10:39:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:39:40 --> Model Class Initialized
INFO - 2016-06-07 10:39:40 --> Helper loaded: date_helper
INFO - 2016-06-07 10:39:40 --> Controller Class Initialized
INFO - 2016-06-07 10:39:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:39:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:39:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:39:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:39:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:39:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:39:40 --> Model Class Initialized
INFO - 2016-06-07 10:39:40 --> Form Validation Class Initialized
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:39:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:39:40 --> Final output sent to browser
DEBUG - 2016-06-07 10:39:40 --> Total execution time: 0.1257
INFO - 2016-06-07 10:39:42 --> Config Class Initialized
INFO - 2016-06-07 10:39:42 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:39:42 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:39:42 --> Utf8 Class Initialized
INFO - 2016-06-07 10:39:42 --> URI Class Initialized
INFO - 2016-06-07 10:39:42 --> Router Class Initialized
INFO - 2016-06-07 10:39:42 --> Output Class Initialized
INFO - 2016-06-07 10:39:42 --> Security Class Initialized
DEBUG - 2016-06-07 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:39:42 --> Input Class Initialized
INFO - 2016-06-07 10:39:42 --> Language Class Initialized
INFO - 2016-06-07 10:39:42 --> Loader Class Initialized
INFO - 2016-06-07 10:39:42 --> Helper loaded: form_helper
INFO - 2016-06-07 10:39:42 --> Database Driver Class Initialized
INFO - 2016-06-07 10:39:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:39:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:39:42 --> Email Class Initialized
INFO - 2016-06-07 10:39:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:39:42 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:39:42 --> Helper loaded: language_helper
INFO - 2016-06-07 10:39:42 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:39:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:39:42 --> Model Class Initialized
INFO - 2016-06-07 10:39:42 --> Helper loaded: date_helper
INFO - 2016-06-07 10:39:42 --> Controller Class Initialized
INFO - 2016-06-07 10:39:42 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:39:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:39:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:39:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:39:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:39:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:39:42 --> Model Class Initialized
INFO - 2016-06-07 10:39:42 --> Form Validation Class Initialized
INFO - 2016-06-07 10:39:42 --> Final output sent to browser
DEBUG - 2016-06-07 10:39:42 --> Total execution time: 0.1154
INFO - 2016-06-07 10:45:58 --> Config Class Initialized
INFO - 2016-06-07 10:45:58 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:45:58 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:45:58 --> Utf8 Class Initialized
INFO - 2016-06-07 10:45:58 --> URI Class Initialized
INFO - 2016-06-07 10:45:58 --> Router Class Initialized
INFO - 2016-06-07 10:45:58 --> Output Class Initialized
INFO - 2016-06-07 10:45:58 --> Security Class Initialized
DEBUG - 2016-06-07 10:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:45:58 --> Input Class Initialized
INFO - 2016-06-07 10:45:58 --> Language Class Initialized
INFO - 2016-06-07 10:45:58 --> Loader Class Initialized
INFO - 2016-06-07 10:45:58 --> Helper loaded: form_helper
INFO - 2016-06-07 10:45:58 --> Database Driver Class Initialized
INFO - 2016-06-07 10:45:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:45:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:45:58 --> Email Class Initialized
INFO - 2016-06-07 10:45:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:45:58 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:45:58 --> Helper loaded: language_helper
INFO - 2016-06-07 10:45:58 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:45:58 --> Model Class Initialized
INFO - 2016-06-07 10:45:58 --> Helper loaded: date_helper
INFO - 2016-06-07 10:45:58 --> Controller Class Initialized
INFO - 2016-06-07 10:45:58 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:45:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:45:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:45:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:45:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:45:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:45:58 --> Model Class Initialized
INFO - 2016-06-07 10:45:58 --> Form Validation Class Initialized
INFO - 2016-06-07 10:45:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:45:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:45:59 --> Final output sent to browser
DEBUG - 2016-06-07 10:45:59 --> Total execution time: 0.0871
INFO - 2016-06-07 10:46:03 --> Config Class Initialized
INFO - 2016-06-07 10:46:03 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:46:03 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:46:03 --> Utf8 Class Initialized
INFO - 2016-06-07 10:46:03 --> URI Class Initialized
INFO - 2016-06-07 10:46:03 --> Router Class Initialized
INFO - 2016-06-07 10:46:03 --> Output Class Initialized
INFO - 2016-06-07 10:46:03 --> Security Class Initialized
DEBUG - 2016-06-07 10:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:46:03 --> Input Class Initialized
INFO - 2016-06-07 10:46:03 --> Language Class Initialized
INFO - 2016-06-07 10:46:03 --> Loader Class Initialized
INFO - 2016-06-07 10:46:03 --> Helper loaded: form_helper
INFO - 2016-06-07 10:46:03 --> Database Driver Class Initialized
INFO - 2016-06-07 10:46:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:46:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:46:03 --> Email Class Initialized
INFO - 2016-06-07 10:46:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:46:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:46:03 --> Helper loaded: language_helper
INFO - 2016-06-07 10:46:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:46:03 --> Model Class Initialized
INFO - 2016-06-07 10:46:03 --> Helper loaded: date_helper
INFO - 2016-06-07 10:46:03 --> Controller Class Initialized
INFO - 2016-06-07 10:46:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:46:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:46:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:46:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:46:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:46:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:46:03 --> Model Class Initialized
INFO - 2016-06-07 10:46:03 --> Form Validation Class Initialized
INFO - 2016-06-07 10:46:03 --> Final output sent to browser
DEBUG - 2016-06-07 10:46:03 --> Total execution time: 0.3614
INFO - 2016-06-07 10:52:03 --> Config Class Initialized
INFO - 2016-06-07 10:52:03 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:52:03 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:52:03 --> Utf8 Class Initialized
INFO - 2016-06-07 10:52:03 --> URI Class Initialized
INFO - 2016-06-07 10:52:03 --> Router Class Initialized
INFO - 2016-06-07 10:52:03 --> Output Class Initialized
INFO - 2016-06-07 10:52:03 --> Security Class Initialized
DEBUG - 2016-06-07 10:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:52:03 --> Input Class Initialized
INFO - 2016-06-07 10:52:03 --> Language Class Initialized
INFO - 2016-06-07 10:52:03 --> Loader Class Initialized
INFO - 2016-06-07 10:52:03 --> Helper loaded: form_helper
INFO - 2016-06-07 10:52:03 --> Database Driver Class Initialized
INFO - 2016-06-07 10:52:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:52:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:52:03 --> Email Class Initialized
INFO - 2016-06-07 10:52:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:52:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:52:03 --> Helper loaded: language_helper
INFO - 2016-06-07 10:52:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:52:03 --> Model Class Initialized
INFO - 2016-06-07 10:52:03 --> Helper loaded: date_helper
INFO - 2016-06-07 10:52:03 --> Controller Class Initialized
INFO - 2016-06-07 10:52:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:52:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:52:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:52:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:52:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:52:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:52:03 --> Model Class Initialized
INFO - 2016-06-07 10:52:03 --> Form Validation Class Initialized
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:52:03 --> Final output sent to browser
DEBUG - 2016-06-07 10:52:03 --> Total execution time: 0.1104
INFO - 2016-06-07 10:52:08 --> Config Class Initialized
INFO - 2016-06-07 10:52:08 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:52:08 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:52:08 --> Utf8 Class Initialized
INFO - 2016-06-07 10:52:08 --> URI Class Initialized
INFO - 2016-06-07 10:52:08 --> Router Class Initialized
INFO - 2016-06-07 10:52:08 --> Output Class Initialized
INFO - 2016-06-07 10:52:08 --> Security Class Initialized
DEBUG - 2016-06-07 10:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:52:08 --> Input Class Initialized
INFO - 2016-06-07 10:52:08 --> Language Class Initialized
INFO - 2016-06-07 10:52:08 --> Loader Class Initialized
INFO - 2016-06-07 10:52:08 --> Helper loaded: form_helper
INFO - 2016-06-07 10:52:08 --> Database Driver Class Initialized
INFO - 2016-06-07 10:52:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:52:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:52:08 --> Email Class Initialized
INFO - 2016-06-07 10:52:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:52:08 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:52:08 --> Helper loaded: language_helper
INFO - 2016-06-07 10:52:08 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:52:08 --> Model Class Initialized
INFO - 2016-06-07 10:52:08 --> Helper loaded: date_helper
INFO - 2016-06-07 10:52:08 --> Controller Class Initialized
INFO - 2016-06-07 10:52:08 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:52:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:52:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:52:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:52:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:52:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:52:08 --> Model Class Initialized
INFO - 2016-06-07 10:52:08 --> Form Validation Class Initialized
INFO - 2016-06-07 10:52:08 --> Final output sent to browser
DEBUG - 2016-06-07 10:52:08 --> Total execution time: 0.1021
INFO - 2016-06-07 10:53:11 --> Config Class Initialized
INFO - 2016-06-07 10:53:11 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:53:11 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:53:11 --> Utf8 Class Initialized
INFO - 2016-06-07 10:53:11 --> URI Class Initialized
INFO - 2016-06-07 10:53:11 --> Router Class Initialized
INFO - 2016-06-07 10:53:11 --> Output Class Initialized
INFO - 2016-06-07 10:53:11 --> Security Class Initialized
DEBUG - 2016-06-07 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:53:11 --> Input Class Initialized
INFO - 2016-06-07 10:53:11 --> Language Class Initialized
INFO - 2016-06-07 10:53:11 --> Loader Class Initialized
INFO - 2016-06-07 10:53:11 --> Helper loaded: form_helper
INFO - 2016-06-07 10:53:11 --> Database Driver Class Initialized
INFO - 2016-06-07 10:53:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:53:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:53:11 --> Email Class Initialized
INFO - 2016-06-07 10:53:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:53:11 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:53:11 --> Helper loaded: language_helper
INFO - 2016-06-07 10:53:11 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:53:11 --> Model Class Initialized
INFO - 2016-06-07 10:53:11 --> Helper loaded: date_helper
INFO - 2016-06-07 10:53:11 --> Controller Class Initialized
INFO - 2016-06-07 10:53:11 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:53:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:53:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:53:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:53:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:53:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:53:11 --> Model Class Initialized
INFO - 2016-06-07 10:53:11 --> Form Validation Class Initialized
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:53:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:53:11 --> Final output sent to browser
DEBUG - 2016-06-07 10:53:11 --> Total execution time: 0.1005
INFO - 2016-06-07 10:53:15 --> Config Class Initialized
INFO - 2016-06-07 10:53:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:53:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:53:15 --> Utf8 Class Initialized
INFO - 2016-06-07 10:53:15 --> URI Class Initialized
INFO - 2016-06-07 10:53:15 --> Router Class Initialized
INFO - 2016-06-07 10:53:15 --> Output Class Initialized
INFO - 2016-06-07 10:53:15 --> Security Class Initialized
DEBUG - 2016-06-07 10:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:53:15 --> Input Class Initialized
INFO - 2016-06-07 10:53:15 --> Language Class Initialized
INFO - 2016-06-07 10:53:15 --> Loader Class Initialized
INFO - 2016-06-07 10:53:15 --> Helper loaded: form_helper
INFO - 2016-06-07 10:53:15 --> Database Driver Class Initialized
INFO - 2016-06-07 10:53:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:53:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:53:16 --> Email Class Initialized
INFO - 2016-06-07 10:53:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:53:16 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:53:16 --> Helper loaded: language_helper
INFO - 2016-06-07 10:53:16 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:53:16 --> Model Class Initialized
INFO - 2016-06-07 10:53:16 --> Helper loaded: date_helper
INFO - 2016-06-07 10:53:16 --> Controller Class Initialized
INFO - 2016-06-07 10:53:16 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:53:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:53:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:53:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:53:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:53:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:53:16 --> Model Class Initialized
INFO - 2016-06-07 10:53:16 --> Form Validation Class Initialized
INFO - 2016-06-07 10:53:16 --> Final output sent to browser
DEBUG - 2016-06-07 10:53:16 --> Total execution time: 0.0853
INFO - 2016-06-07 10:54:23 --> Config Class Initialized
INFO - 2016-06-07 10:54:23 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:54:23 --> Utf8 Class Initialized
INFO - 2016-06-07 10:54:23 --> URI Class Initialized
INFO - 2016-06-07 10:54:23 --> Router Class Initialized
INFO - 2016-06-07 10:54:23 --> Output Class Initialized
INFO - 2016-06-07 10:54:23 --> Security Class Initialized
DEBUG - 2016-06-07 10:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:54:23 --> Input Class Initialized
INFO - 2016-06-07 10:54:23 --> Language Class Initialized
INFO - 2016-06-07 10:54:23 --> Loader Class Initialized
INFO - 2016-06-07 10:54:23 --> Helper loaded: form_helper
INFO - 2016-06-07 10:54:23 --> Database Driver Class Initialized
INFO - 2016-06-07 10:54:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:54:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:54:23 --> Email Class Initialized
INFO - 2016-06-07 10:54:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:54:23 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:54:23 --> Helper loaded: language_helper
INFO - 2016-06-07 10:54:23 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:54:23 --> Model Class Initialized
INFO - 2016-06-07 10:54:23 --> Helper loaded: date_helper
INFO - 2016-06-07 10:54:23 --> Controller Class Initialized
INFO - 2016-06-07 10:54:23 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:54:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:54:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:54:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:54:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:54:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:54:23 --> Model Class Initialized
INFO - 2016-06-07 10:54:23 --> Form Validation Class Initialized
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 10:54:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 10:54:24 --> Final output sent to browser
DEBUG - 2016-06-07 10:54:24 --> Total execution time: 0.0947
INFO - 2016-06-07 10:54:28 --> Config Class Initialized
INFO - 2016-06-07 10:54:28 --> Hooks Class Initialized
DEBUG - 2016-06-07 10:54:28 --> UTF-8 Support Enabled
INFO - 2016-06-07 10:54:28 --> Utf8 Class Initialized
INFO - 2016-06-07 10:54:28 --> URI Class Initialized
INFO - 2016-06-07 10:54:28 --> Router Class Initialized
INFO - 2016-06-07 10:54:28 --> Output Class Initialized
INFO - 2016-06-07 10:54:28 --> Security Class Initialized
DEBUG - 2016-06-07 10:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 10:54:28 --> Input Class Initialized
INFO - 2016-06-07 10:54:28 --> Language Class Initialized
INFO - 2016-06-07 10:54:28 --> Loader Class Initialized
INFO - 2016-06-07 10:54:28 --> Helper loaded: form_helper
INFO - 2016-06-07 10:54:28 --> Database Driver Class Initialized
INFO - 2016-06-07 10:54:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 10:54:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 10:54:28 --> Email Class Initialized
INFO - 2016-06-07 10:54:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 10:54:28 --> Helper loaded: cookie_helper
INFO - 2016-06-07 10:54:28 --> Helper loaded: language_helper
INFO - 2016-06-07 10:54:28 --> Helper loaded: url_helper
DEBUG - 2016-06-07 10:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 10:54:28 --> Model Class Initialized
INFO - 2016-06-07 10:54:28 --> Helper loaded: date_helper
INFO - 2016-06-07 10:54:28 --> Controller Class Initialized
INFO - 2016-06-07 10:54:28 --> Helper loaded: languages_helper
INFO - 2016-06-07 10:54:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 10:54:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 10:54:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 10:54:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 10:54:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 10:54:28 --> Model Class Initialized
INFO - 2016-06-07 10:54:28 --> Form Validation Class Initialized
INFO - 2016-06-07 10:54:28 --> Final output sent to browser
DEBUG - 2016-06-07 10:54:28 --> Total execution time: 0.0529
INFO - 2016-06-07 11:07:09 --> Config Class Initialized
INFO - 2016-06-07 11:07:09 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:07:09 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:07:09 --> Utf8 Class Initialized
INFO - 2016-06-07 11:07:09 --> URI Class Initialized
INFO - 2016-06-07 11:07:09 --> Router Class Initialized
INFO - 2016-06-07 11:07:09 --> Output Class Initialized
INFO - 2016-06-07 11:07:09 --> Security Class Initialized
DEBUG - 2016-06-07 11:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:07:09 --> Input Class Initialized
INFO - 2016-06-07 11:07:09 --> Language Class Initialized
INFO - 2016-06-07 11:07:09 --> Loader Class Initialized
INFO - 2016-06-07 11:07:09 --> Helper loaded: form_helper
INFO - 2016-06-07 11:07:09 --> Database Driver Class Initialized
INFO - 2016-06-07 11:07:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:07:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:07:09 --> Email Class Initialized
INFO - 2016-06-07 11:07:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:07:09 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:07:09 --> Helper loaded: language_helper
INFO - 2016-06-07 11:07:09 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:07:09 --> Model Class Initialized
INFO - 2016-06-07 11:07:09 --> Helper loaded: date_helper
INFO - 2016-06-07 11:07:09 --> Controller Class Initialized
INFO - 2016-06-07 11:07:09 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:07:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:07:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:07:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:07:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:07:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:07:09 --> Model Class Initialized
INFO - 2016-06-07 11:07:09 --> Form Validation Class Initialized
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:07:09 --> Final output sent to browser
DEBUG - 2016-06-07 11:07:09 --> Total execution time: 0.0702
INFO - 2016-06-07 11:07:14 --> Config Class Initialized
INFO - 2016-06-07 11:07:14 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:07:14 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:07:14 --> Utf8 Class Initialized
INFO - 2016-06-07 11:07:14 --> URI Class Initialized
INFO - 2016-06-07 11:07:14 --> Router Class Initialized
INFO - 2016-06-07 11:07:14 --> Output Class Initialized
INFO - 2016-06-07 11:07:14 --> Security Class Initialized
DEBUG - 2016-06-07 11:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:07:14 --> Input Class Initialized
INFO - 2016-06-07 11:07:14 --> Language Class Initialized
INFO - 2016-06-07 11:07:14 --> Loader Class Initialized
INFO - 2016-06-07 11:07:14 --> Helper loaded: form_helper
INFO - 2016-06-07 11:07:14 --> Database Driver Class Initialized
INFO - 2016-06-07 11:07:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:07:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:07:14 --> Email Class Initialized
INFO - 2016-06-07 11:07:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:07:14 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:07:14 --> Helper loaded: language_helper
INFO - 2016-06-07 11:07:14 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:07:14 --> Model Class Initialized
INFO - 2016-06-07 11:07:14 --> Helper loaded: date_helper
INFO - 2016-06-07 11:07:14 --> Controller Class Initialized
INFO - 2016-06-07 11:07:14 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:07:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:07:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:07:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:07:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:07:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:07:14 --> Model Class Initialized
INFO - 2016-06-07 11:07:14 --> Form Validation Class Initialized
INFO - 2016-06-07 11:07:14 --> Final output sent to browser
DEBUG - 2016-06-07 11:07:14 --> Total execution time: 0.0630
INFO - 2016-06-07 11:07:40 --> Config Class Initialized
INFO - 2016-06-07 11:07:40 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:07:40 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:07:40 --> Utf8 Class Initialized
INFO - 2016-06-07 11:07:40 --> URI Class Initialized
INFO - 2016-06-07 11:07:40 --> Router Class Initialized
INFO - 2016-06-07 11:07:40 --> Output Class Initialized
INFO - 2016-06-07 11:07:40 --> Security Class Initialized
DEBUG - 2016-06-07 11:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:07:40 --> Input Class Initialized
INFO - 2016-06-07 11:07:40 --> Language Class Initialized
INFO - 2016-06-07 11:07:40 --> Loader Class Initialized
INFO - 2016-06-07 11:07:40 --> Helper loaded: form_helper
INFO - 2016-06-07 11:07:40 --> Database Driver Class Initialized
INFO - 2016-06-07 11:07:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:07:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:07:40 --> Email Class Initialized
INFO - 2016-06-07 11:07:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:07:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:07:40 --> Helper loaded: language_helper
INFO - 2016-06-07 11:07:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:07:40 --> Model Class Initialized
INFO - 2016-06-07 11:07:40 --> Helper loaded: date_helper
INFO - 2016-06-07 11:07:40 --> Controller Class Initialized
INFO - 2016-06-07 11:07:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:07:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:07:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:07:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:07:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:07:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:07:40 --> Model Class Initialized
INFO - 2016-06-07 11:07:40 --> Form Validation Class Initialized
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:07:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:07:40 --> Final output sent to browser
DEBUG - 2016-06-07 11:07:40 --> Total execution time: 0.0625
INFO - 2016-06-07 11:07:45 --> Config Class Initialized
INFO - 2016-06-07 11:07:45 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:07:45 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:07:45 --> Utf8 Class Initialized
INFO - 2016-06-07 11:07:45 --> URI Class Initialized
INFO - 2016-06-07 11:07:45 --> Router Class Initialized
INFO - 2016-06-07 11:07:45 --> Output Class Initialized
INFO - 2016-06-07 11:07:45 --> Security Class Initialized
DEBUG - 2016-06-07 11:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:07:45 --> Input Class Initialized
INFO - 2016-06-07 11:07:45 --> Language Class Initialized
INFO - 2016-06-07 11:07:45 --> Loader Class Initialized
INFO - 2016-06-07 11:07:45 --> Helper loaded: form_helper
INFO - 2016-06-07 11:07:45 --> Database Driver Class Initialized
INFO - 2016-06-07 11:07:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:07:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:07:46 --> Email Class Initialized
INFO - 2016-06-07 11:07:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:07:46 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:07:46 --> Helper loaded: language_helper
INFO - 2016-06-07 11:07:46 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:07:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:07:46 --> Model Class Initialized
INFO - 2016-06-07 11:07:46 --> Helper loaded: date_helper
INFO - 2016-06-07 11:07:46 --> Controller Class Initialized
INFO - 2016-06-07 11:07:46 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:07:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:07:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:07:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:07:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:07:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:07:46 --> Model Class Initialized
INFO - 2016-06-07 11:07:46 --> Form Validation Class Initialized
INFO - 2016-06-07 11:07:46 --> Final output sent to browser
DEBUG - 2016-06-07 11:07:46 --> Total execution time: 0.0598
INFO - 2016-06-07 11:08:43 --> Config Class Initialized
INFO - 2016-06-07 11:08:43 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:08:43 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:08:43 --> Utf8 Class Initialized
INFO - 2016-06-07 11:08:43 --> URI Class Initialized
INFO - 2016-06-07 11:08:43 --> Router Class Initialized
INFO - 2016-06-07 11:08:43 --> Output Class Initialized
INFO - 2016-06-07 11:08:43 --> Security Class Initialized
DEBUG - 2016-06-07 11:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:08:43 --> Input Class Initialized
INFO - 2016-06-07 11:08:43 --> Language Class Initialized
INFO - 2016-06-07 11:08:43 --> Loader Class Initialized
INFO - 2016-06-07 11:08:43 --> Helper loaded: form_helper
INFO - 2016-06-07 11:08:43 --> Database Driver Class Initialized
INFO - 2016-06-07 11:08:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:08:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:08:43 --> Email Class Initialized
INFO - 2016-06-07 11:08:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:08:43 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:08:43 --> Helper loaded: language_helper
INFO - 2016-06-07 11:08:43 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:08:43 --> Model Class Initialized
INFO - 2016-06-07 11:08:43 --> Helper loaded: date_helper
INFO - 2016-06-07 11:08:44 --> Controller Class Initialized
INFO - 2016-06-07 11:08:44 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:08:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:08:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:08:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:08:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:08:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:08:44 --> Model Class Initialized
INFO - 2016-06-07 11:08:44 --> Form Validation Class Initialized
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:08:44 --> Final output sent to browser
DEBUG - 2016-06-07 11:08:44 --> Total execution time: 0.1515
INFO - 2016-06-07 11:08:47 --> Config Class Initialized
INFO - 2016-06-07 11:08:47 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:08:47 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:08:47 --> Utf8 Class Initialized
INFO - 2016-06-07 11:08:47 --> URI Class Initialized
INFO - 2016-06-07 11:08:47 --> Router Class Initialized
INFO - 2016-06-07 11:08:47 --> Output Class Initialized
INFO - 2016-06-07 11:08:47 --> Security Class Initialized
DEBUG - 2016-06-07 11:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:08:47 --> Input Class Initialized
INFO - 2016-06-07 11:08:47 --> Language Class Initialized
INFO - 2016-06-07 11:08:47 --> Loader Class Initialized
INFO - 2016-06-07 11:08:47 --> Helper loaded: form_helper
INFO - 2016-06-07 11:08:47 --> Database Driver Class Initialized
INFO - 2016-06-07 11:08:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:08:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:08:47 --> Email Class Initialized
INFO - 2016-06-07 11:08:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:08:47 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:08:47 --> Helper loaded: language_helper
INFO - 2016-06-07 11:08:47 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:08:47 --> Model Class Initialized
INFO - 2016-06-07 11:08:47 --> Helper loaded: date_helper
INFO - 2016-06-07 11:08:47 --> Controller Class Initialized
INFO - 2016-06-07 11:08:47 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:08:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:08:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:08:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:08:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:08:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:08:47 --> Model Class Initialized
INFO - 2016-06-07 11:08:47 --> Form Validation Class Initialized
INFO - 2016-06-07 11:08:47 --> Final output sent to browser
DEBUG - 2016-06-07 11:08:47 --> Total execution time: 0.1602
INFO - 2016-06-07 11:09:08 --> Config Class Initialized
INFO - 2016-06-07 11:09:08 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:09:08 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:09:08 --> Utf8 Class Initialized
INFO - 2016-06-07 11:09:08 --> URI Class Initialized
INFO - 2016-06-07 11:09:08 --> Router Class Initialized
INFO - 2016-06-07 11:09:08 --> Output Class Initialized
INFO - 2016-06-07 11:09:08 --> Security Class Initialized
DEBUG - 2016-06-07 11:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:09:08 --> Input Class Initialized
INFO - 2016-06-07 11:09:08 --> Language Class Initialized
INFO - 2016-06-07 11:09:08 --> Loader Class Initialized
INFO - 2016-06-07 11:09:08 --> Helper loaded: form_helper
INFO - 2016-06-07 11:09:08 --> Database Driver Class Initialized
INFO - 2016-06-07 11:09:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:09:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:09:08 --> Email Class Initialized
INFO - 2016-06-07 11:09:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:09:08 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:09:08 --> Helper loaded: language_helper
INFO - 2016-06-07 11:09:08 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:09:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:09:08 --> Model Class Initialized
INFO - 2016-06-07 11:09:08 --> Helper loaded: date_helper
INFO - 2016-06-07 11:09:08 --> Controller Class Initialized
INFO - 2016-06-07 11:09:08 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:09:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:09:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:09:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:09:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:09:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:09:08 --> Model Class Initialized
INFO - 2016-06-07 11:09:08 --> Form Validation Class Initialized
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:09:08 --> Final output sent to browser
DEBUG - 2016-06-07 11:09:08 --> Total execution time: 0.0801
INFO - 2016-06-07 11:09:12 --> Config Class Initialized
INFO - 2016-06-07 11:09:12 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:09:12 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:09:12 --> Utf8 Class Initialized
INFO - 2016-06-07 11:09:12 --> URI Class Initialized
INFO - 2016-06-07 11:09:12 --> Router Class Initialized
INFO - 2016-06-07 11:09:12 --> Output Class Initialized
INFO - 2016-06-07 11:09:12 --> Security Class Initialized
DEBUG - 2016-06-07 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:09:12 --> Input Class Initialized
INFO - 2016-06-07 11:09:12 --> Language Class Initialized
INFO - 2016-06-07 11:09:12 --> Loader Class Initialized
INFO - 2016-06-07 11:09:12 --> Helper loaded: form_helper
INFO - 2016-06-07 11:09:12 --> Database Driver Class Initialized
INFO - 2016-06-07 11:09:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:09:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:09:12 --> Email Class Initialized
INFO - 2016-06-07 11:09:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:09:13 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:09:13 --> Helper loaded: language_helper
INFO - 2016-06-07 11:09:13 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:09:13 --> Model Class Initialized
INFO - 2016-06-07 11:09:13 --> Helper loaded: date_helper
INFO - 2016-06-07 11:09:13 --> Controller Class Initialized
INFO - 2016-06-07 11:09:13 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:09:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:09:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:09:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:09:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:09:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:09:13 --> Model Class Initialized
INFO - 2016-06-07 11:09:13 --> Form Validation Class Initialized
INFO - 2016-06-07 11:09:13 --> Final output sent to browser
DEBUG - 2016-06-07 11:09:13 --> Total execution time: 0.0666
INFO - 2016-06-07 11:11:15 --> Config Class Initialized
INFO - 2016-06-07 11:11:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:11:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:11:15 --> Utf8 Class Initialized
INFO - 2016-06-07 11:11:15 --> URI Class Initialized
INFO - 2016-06-07 11:11:15 --> Router Class Initialized
INFO - 2016-06-07 11:11:15 --> Output Class Initialized
INFO - 2016-06-07 11:11:15 --> Security Class Initialized
DEBUG - 2016-06-07 11:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:11:15 --> Input Class Initialized
INFO - 2016-06-07 11:11:15 --> Language Class Initialized
INFO - 2016-06-07 11:11:15 --> Loader Class Initialized
INFO - 2016-06-07 11:11:15 --> Helper loaded: form_helper
INFO - 2016-06-07 11:11:15 --> Database Driver Class Initialized
INFO - 2016-06-07 11:11:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:11:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:11:15 --> Email Class Initialized
INFO - 2016-06-07 11:11:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:11:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:11:15 --> Helper loaded: language_helper
INFO - 2016-06-07 11:11:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:11:15 --> Model Class Initialized
INFO - 2016-06-07 11:11:15 --> Helper loaded: date_helper
INFO - 2016-06-07 11:11:15 --> Controller Class Initialized
INFO - 2016-06-07 11:11:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:11:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:11:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:11:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:11:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:11:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:11:15 --> Model Class Initialized
INFO - 2016-06-07 11:11:15 --> Form Validation Class Initialized
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:11:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:11:15 --> Final output sent to browser
DEBUG - 2016-06-07 11:11:15 --> Total execution time: 0.1233
INFO - 2016-06-07 11:11:24 --> Config Class Initialized
INFO - 2016-06-07 11:11:24 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:11:24 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:11:24 --> Utf8 Class Initialized
INFO - 2016-06-07 11:11:24 --> URI Class Initialized
INFO - 2016-06-07 11:11:24 --> Router Class Initialized
INFO - 2016-06-07 11:11:24 --> Output Class Initialized
INFO - 2016-06-07 11:11:24 --> Security Class Initialized
DEBUG - 2016-06-07 11:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:11:24 --> Input Class Initialized
INFO - 2016-06-07 11:11:24 --> Language Class Initialized
INFO - 2016-06-07 11:11:24 --> Loader Class Initialized
INFO - 2016-06-07 11:11:24 --> Helper loaded: form_helper
INFO - 2016-06-07 11:11:24 --> Database Driver Class Initialized
INFO - 2016-06-07 11:11:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:11:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:11:24 --> Email Class Initialized
INFO - 2016-06-07 11:11:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:11:24 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:11:24 --> Helper loaded: language_helper
INFO - 2016-06-07 11:11:24 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:11:24 --> Model Class Initialized
INFO - 2016-06-07 11:11:24 --> Helper loaded: date_helper
INFO - 2016-06-07 11:11:24 --> Controller Class Initialized
INFO - 2016-06-07 11:11:24 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:11:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:11:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:11:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:11:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:11:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:11:24 --> Model Class Initialized
INFO - 2016-06-07 11:11:24 --> Form Validation Class Initialized
INFO - 2016-06-07 11:11:24 --> Final output sent to browser
DEBUG - 2016-06-07 11:11:24 --> Total execution time: 0.1122
INFO - 2016-06-07 11:11:46 --> Config Class Initialized
INFO - 2016-06-07 11:11:46 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:11:46 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:11:46 --> Utf8 Class Initialized
INFO - 2016-06-07 11:11:46 --> URI Class Initialized
INFO - 2016-06-07 11:11:46 --> Router Class Initialized
INFO - 2016-06-07 11:11:46 --> Output Class Initialized
INFO - 2016-06-07 11:11:46 --> Security Class Initialized
DEBUG - 2016-06-07 11:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:11:46 --> Input Class Initialized
INFO - 2016-06-07 11:11:46 --> Language Class Initialized
INFO - 2016-06-07 11:11:46 --> Loader Class Initialized
INFO - 2016-06-07 11:11:46 --> Helper loaded: form_helper
INFO - 2016-06-07 11:11:46 --> Database Driver Class Initialized
INFO - 2016-06-07 11:11:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:11:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:11:46 --> Email Class Initialized
INFO - 2016-06-07 11:11:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:11:46 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:11:46 --> Helper loaded: language_helper
INFO - 2016-06-07 11:11:46 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:11:46 --> Model Class Initialized
INFO - 2016-06-07 11:11:46 --> Helper loaded: date_helper
INFO - 2016-06-07 11:11:46 --> Controller Class Initialized
INFO - 2016-06-07 11:11:46 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:11:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:11:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:11:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:11:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:11:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:11:46 --> Model Class Initialized
INFO - 2016-06-07 11:11:46 --> Form Validation Class Initialized
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:11:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:11:46 --> Final output sent to browser
DEBUG - 2016-06-07 11:11:46 --> Total execution time: 0.1214
INFO - 2016-06-07 11:11:52 --> Config Class Initialized
INFO - 2016-06-07 11:11:52 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:11:52 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:11:52 --> Utf8 Class Initialized
INFO - 2016-06-07 11:11:52 --> URI Class Initialized
INFO - 2016-06-07 11:11:52 --> Router Class Initialized
INFO - 2016-06-07 11:11:52 --> Output Class Initialized
INFO - 2016-06-07 11:11:52 --> Security Class Initialized
DEBUG - 2016-06-07 11:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:11:52 --> Input Class Initialized
INFO - 2016-06-07 11:11:52 --> Language Class Initialized
INFO - 2016-06-07 11:11:52 --> Loader Class Initialized
INFO - 2016-06-07 11:11:52 --> Helper loaded: form_helper
INFO - 2016-06-07 11:11:52 --> Database Driver Class Initialized
INFO - 2016-06-07 11:11:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:11:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:11:52 --> Email Class Initialized
INFO - 2016-06-07 11:11:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:11:52 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:11:52 --> Helper loaded: language_helper
INFO - 2016-06-07 11:11:52 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:11:52 --> Model Class Initialized
INFO - 2016-06-07 11:11:52 --> Helper loaded: date_helper
INFO - 2016-06-07 11:11:52 --> Controller Class Initialized
INFO - 2016-06-07 11:11:52 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:11:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:11:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:11:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:11:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:11:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:11:52 --> Model Class Initialized
INFO - 2016-06-07 11:11:52 --> Form Validation Class Initialized
INFO - 2016-06-07 11:11:52 --> Final output sent to browser
DEBUG - 2016-06-07 11:11:52 --> Total execution time: 0.1495
INFO - 2016-06-07 11:13:45 --> Config Class Initialized
INFO - 2016-06-07 11:13:45 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:13:45 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:13:45 --> Utf8 Class Initialized
INFO - 2016-06-07 11:13:45 --> URI Class Initialized
INFO - 2016-06-07 11:13:45 --> Router Class Initialized
INFO - 2016-06-07 11:13:45 --> Output Class Initialized
INFO - 2016-06-07 11:13:45 --> Security Class Initialized
DEBUG - 2016-06-07 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:13:45 --> Input Class Initialized
INFO - 2016-06-07 11:13:45 --> Language Class Initialized
INFO - 2016-06-07 11:13:45 --> Loader Class Initialized
INFO - 2016-06-07 11:13:45 --> Helper loaded: form_helper
INFO - 2016-06-07 11:13:45 --> Database Driver Class Initialized
INFO - 2016-06-07 11:13:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:13:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:13:45 --> Email Class Initialized
INFO - 2016-06-07 11:13:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:13:45 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:13:45 --> Helper loaded: language_helper
INFO - 2016-06-07 11:13:45 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:13:45 --> Model Class Initialized
INFO - 2016-06-07 11:13:45 --> Helper loaded: date_helper
INFO - 2016-06-07 11:13:45 --> Controller Class Initialized
INFO - 2016-06-07 11:13:45 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:13:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:13:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:13:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:13:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:13:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:13:45 --> Model Class Initialized
INFO - 2016-06-07 11:13:45 --> Form Validation Class Initialized
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:13:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:13:45 --> Final output sent to browser
DEBUG - 2016-06-07 11:13:45 --> Total execution time: 0.1231
INFO - 2016-06-07 11:15:10 --> Config Class Initialized
INFO - 2016-06-07 11:15:10 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:15:10 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:15:10 --> Utf8 Class Initialized
INFO - 2016-06-07 11:15:10 --> URI Class Initialized
INFO - 2016-06-07 11:15:10 --> Router Class Initialized
INFO - 2016-06-07 11:15:10 --> Output Class Initialized
INFO - 2016-06-07 11:15:10 --> Security Class Initialized
DEBUG - 2016-06-07 11:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:15:10 --> Input Class Initialized
INFO - 2016-06-07 11:15:10 --> Language Class Initialized
INFO - 2016-06-07 11:15:10 --> Loader Class Initialized
INFO - 2016-06-07 11:15:10 --> Helper loaded: form_helper
INFO - 2016-06-07 11:15:10 --> Database Driver Class Initialized
INFO - 2016-06-07 11:15:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:15:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:15:10 --> Email Class Initialized
INFO - 2016-06-07 11:15:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:15:10 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:15:10 --> Helper loaded: language_helper
INFO - 2016-06-07 11:15:10 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:15:10 --> Model Class Initialized
INFO - 2016-06-07 11:15:10 --> Helper loaded: date_helper
INFO - 2016-06-07 11:15:10 --> Controller Class Initialized
INFO - 2016-06-07 11:15:10 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:15:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:15:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:15:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:15:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:15:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:15:10 --> Model Class Initialized
INFO - 2016-06-07 11:15:10 --> Form Validation Class Initialized
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:15:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:15:10 --> Final output sent to browser
DEBUG - 2016-06-07 11:15:10 --> Total execution time: 0.0904
INFO - 2016-06-07 11:15:40 --> Config Class Initialized
INFO - 2016-06-07 11:15:40 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:15:40 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:15:40 --> Utf8 Class Initialized
INFO - 2016-06-07 11:15:40 --> URI Class Initialized
INFO - 2016-06-07 11:15:40 --> Router Class Initialized
INFO - 2016-06-07 11:15:40 --> Output Class Initialized
INFO - 2016-06-07 11:15:40 --> Security Class Initialized
DEBUG - 2016-06-07 11:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:15:40 --> Input Class Initialized
INFO - 2016-06-07 11:15:40 --> Language Class Initialized
INFO - 2016-06-07 11:15:40 --> Loader Class Initialized
INFO - 2016-06-07 11:15:40 --> Helper loaded: form_helper
INFO - 2016-06-07 11:15:40 --> Database Driver Class Initialized
INFO - 2016-06-07 11:15:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:15:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:15:40 --> Email Class Initialized
INFO - 2016-06-07 11:15:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:15:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:15:40 --> Helper loaded: language_helper
INFO - 2016-06-07 11:15:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:15:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:15:40 --> Model Class Initialized
INFO - 2016-06-07 11:15:40 --> Helper loaded: date_helper
INFO - 2016-06-07 11:15:40 --> Controller Class Initialized
INFO - 2016-06-07 11:15:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:15:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:15:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:15:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:15:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:15:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:15:40 --> Model Class Initialized
INFO - 2016-06-07 11:15:40 --> Form Validation Class Initialized
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:15:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:15:40 --> Final output sent to browser
DEBUG - 2016-06-07 11:15:40 --> Total execution time: 0.0761
INFO - 2016-06-07 11:15:47 --> Config Class Initialized
INFO - 2016-06-07 11:15:47 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:15:47 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:15:47 --> Utf8 Class Initialized
INFO - 2016-06-07 11:15:47 --> URI Class Initialized
INFO - 2016-06-07 11:15:47 --> Router Class Initialized
INFO - 2016-06-07 11:15:47 --> Output Class Initialized
INFO - 2016-06-07 11:15:47 --> Security Class Initialized
DEBUG - 2016-06-07 11:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:15:47 --> Input Class Initialized
INFO - 2016-06-07 11:15:47 --> Language Class Initialized
INFO - 2016-06-07 11:15:47 --> Loader Class Initialized
INFO - 2016-06-07 11:15:47 --> Helper loaded: form_helper
INFO - 2016-06-07 11:15:47 --> Database Driver Class Initialized
INFO - 2016-06-07 11:15:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:15:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:15:47 --> Email Class Initialized
INFO - 2016-06-07 11:15:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:15:47 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:15:47 --> Helper loaded: language_helper
INFO - 2016-06-07 11:15:47 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:15:47 --> Model Class Initialized
INFO - 2016-06-07 11:15:47 --> Helper loaded: date_helper
INFO - 2016-06-07 11:15:47 --> Controller Class Initialized
INFO - 2016-06-07 11:15:47 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:15:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:15:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:15:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:15:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:15:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:15:47 --> Model Class Initialized
INFO - 2016-06-07 11:15:47 --> Form Validation Class Initialized
INFO - 2016-06-07 11:15:47 --> Final output sent to browser
DEBUG - 2016-06-07 11:15:47 --> Total execution time: 0.0489
INFO - 2016-06-07 11:18:52 --> Config Class Initialized
INFO - 2016-06-07 11:18:52 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:18:52 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:18:52 --> Utf8 Class Initialized
INFO - 2016-06-07 11:18:52 --> URI Class Initialized
INFO - 2016-06-07 11:18:52 --> Router Class Initialized
INFO - 2016-06-07 11:18:52 --> Output Class Initialized
INFO - 2016-06-07 11:18:52 --> Security Class Initialized
DEBUG - 2016-06-07 11:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:18:52 --> Input Class Initialized
INFO - 2016-06-07 11:18:52 --> Language Class Initialized
INFO - 2016-06-07 11:18:52 --> Loader Class Initialized
INFO - 2016-06-07 11:18:52 --> Helper loaded: form_helper
INFO - 2016-06-07 11:18:52 --> Database Driver Class Initialized
INFO - 2016-06-07 11:18:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:18:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:18:52 --> Email Class Initialized
INFO - 2016-06-07 11:18:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:18:52 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:18:52 --> Helper loaded: language_helper
INFO - 2016-06-07 11:18:52 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:18:52 --> Model Class Initialized
INFO - 2016-06-07 11:18:52 --> Helper loaded: date_helper
INFO - 2016-06-07 11:18:52 --> Controller Class Initialized
INFO - 2016-06-07 11:18:52 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:18:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:18:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:18:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:18:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:18:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:18:52 --> Model Class Initialized
INFO - 2016-06-07 11:18:52 --> Form Validation Class Initialized
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:18:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:18:52 --> Final output sent to browser
DEBUG - 2016-06-07 11:18:52 --> Total execution time: 0.1296
INFO - 2016-06-07 11:18:57 --> Config Class Initialized
INFO - 2016-06-07 11:18:57 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:18:57 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:18:57 --> Utf8 Class Initialized
INFO - 2016-06-07 11:18:57 --> URI Class Initialized
INFO - 2016-06-07 11:18:57 --> Router Class Initialized
INFO - 2016-06-07 11:18:57 --> Output Class Initialized
INFO - 2016-06-07 11:18:57 --> Security Class Initialized
DEBUG - 2016-06-07 11:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:18:57 --> Input Class Initialized
INFO - 2016-06-07 11:18:57 --> Language Class Initialized
INFO - 2016-06-07 11:18:57 --> Loader Class Initialized
INFO - 2016-06-07 11:18:57 --> Helper loaded: form_helper
INFO - 2016-06-07 11:18:57 --> Database Driver Class Initialized
INFO - 2016-06-07 11:18:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:18:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:18:57 --> Email Class Initialized
INFO - 2016-06-07 11:18:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:18:57 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:18:57 --> Helper loaded: language_helper
INFO - 2016-06-07 11:18:57 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:18:57 --> Model Class Initialized
INFO - 2016-06-07 11:18:57 --> Helper loaded: date_helper
INFO - 2016-06-07 11:18:57 --> Controller Class Initialized
INFO - 2016-06-07 11:18:57 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:18:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:18:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:18:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:18:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:18:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:18:57 --> Model Class Initialized
INFO - 2016-06-07 11:18:57 --> Form Validation Class Initialized
INFO - 2016-06-07 11:18:57 --> Final output sent to browser
DEBUG - 2016-06-07 11:18:57 --> Total execution time: 0.0165
INFO - 2016-06-07 11:19:15 --> Config Class Initialized
INFO - 2016-06-07 11:19:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:19:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:19:15 --> Utf8 Class Initialized
INFO - 2016-06-07 11:19:15 --> URI Class Initialized
INFO - 2016-06-07 11:19:15 --> Router Class Initialized
INFO - 2016-06-07 11:19:15 --> Output Class Initialized
INFO - 2016-06-07 11:19:15 --> Security Class Initialized
DEBUG - 2016-06-07 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:19:15 --> Input Class Initialized
INFO - 2016-06-07 11:19:15 --> Language Class Initialized
INFO - 2016-06-07 11:19:15 --> Loader Class Initialized
INFO - 2016-06-07 11:19:15 --> Helper loaded: form_helper
INFO - 2016-06-07 11:19:15 --> Database Driver Class Initialized
INFO - 2016-06-07 11:19:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:19:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:19:15 --> Email Class Initialized
INFO - 2016-06-07 11:19:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:19:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:19:15 --> Helper loaded: language_helper
INFO - 2016-06-07 11:19:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:19:15 --> Model Class Initialized
INFO - 2016-06-07 11:19:15 --> Helper loaded: date_helper
INFO - 2016-06-07 11:19:15 --> Controller Class Initialized
INFO - 2016-06-07 11:19:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:19:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:19:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:19:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:19:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:19:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:19:15 --> Model Class Initialized
INFO - 2016-06-07 11:19:15 --> Form Validation Class Initialized
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:19:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:19:15 --> Final output sent to browser
DEBUG - 2016-06-07 11:19:15 --> Total execution time: 0.1403
INFO - 2016-06-07 11:19:21 --> Config Class Initialized
INFO - 2016-06-07 11:19:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:19:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:19:21 --> Utf8 Class Initialized
INFO - 2016-06-07 11:19:21 --> URI Class Initialized
INFO - 2016-06-07 11:19:21 --> Router Class Initialized
INFO - 2016-06-07 11:19:21 --> Output Class Initialized
INFO - 2016-06-07 11:19:21 --> Security Class Initialized
DEBUG - 2016-06-07 11:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:19:21 --> Input Class Initialized
INFO - 2016-06-07 11:19:21 --> Language Class Initialized
INFO - 2016-06-07 11:19:21 --> Loader Class Initialized
INFO - 2016-06-07 11:19:21 --> Helper loaded: form_helper
INFO - 2016-06-07 11:19:21 --> Database Driver Class Initialized
INFO - 2016-06-07 11:19:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:19:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:19:21 --> Email Class Initialized
INFO - 2016-06-07 11:19:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:19:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:19:21 --> Helper loaded: language_helper
INFO - 2016-06-07 11:19:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:19:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:19:21 --> Model Class Initialized
INFO - 2016-06-07 11:19:21 --> Helper loaded: date_helper
INFO - 2016-06-07 11:19:21 --> Controller Class Initialized
INFO - 2016-06-07 11:19:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:19:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:19:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:19:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:19:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:19:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:19:21 --> Model Class Initialized
INFO - 2016-06-07 11:19:21 --> Form Validation Class Initialized
INFO - 2016-06-07 11:19:21 --> Final output sent to browser
DEBUG - 2016-06-07 11:19:21 --> Total execution time: 0.0229
INFO - 2016-06-07 11:20:15 --> Config Class Initialized
INFO - 2016-06-07 11:20:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:20:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:20:15 --> Utf8 Class Initialized
INFO - 2016-06-07 11:20:15 --> URI Class Initialized
INFO - 2016-06-07 11:20:15 --> Router Class Initialized
INFO - 2016-06-07 11:20:15 --> Output Class Initialized
INFO - 2016-06-07 11:20:15 --> Security Class Initialized
DEBUG - 2016-06-07 11:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:20:15 --> Input Class Initialized
INFO - 2016-06-07 11:20:15 --> Language Class Initialized
INFO - 2016-06-07 11:20:15 --> Loader Class Initialized
INFO - 2016-06-07 11:20:15 --> Helper loaded: form_helper
INFO - 2016-06-07 11:20:15 --> Database Driver Class Initialized
INFO - 2016-06-07 11:20:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:20:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:20:15 --> Email Class Initialized
INFO - 2016-06-07 11:20:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:20:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:20:15 --> Helper loaded: language_helper
INFO - 2016-06-07 11:20:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:20:15 --> Model Class Initialized
INFO - 2016-06-07 11:20:15 --> Helper loaded: date_helper
INFO - 2016-06-07 11:20:15 --> Controller Class Initialized
INFO - 2016-06-07 11:20:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:20:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:20:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:20:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:20:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:20:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:20:15 --> Model Class Initialized
INFO - 2016-06-07 11:20:15 --> Form Validation Class Initialized
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:20:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:20:15 --> Final output sent to browser
DEBUG - 2016-06-07 11:20:15 --> Total execution time: 0.1057
INFO - 2016-06-07 11:20:19 --> Config Class Initialized
INFO - 2016-06-07 11:20:19 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:20:19 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:20:19 --> Utf8 Class Initialized
INFO - 2016-06-07 11:20:19 --> URI Class Initialized
INFO - 2016-06-07 11:20:19 --> Router Class Initialized
INFO - 2016-06-07 11:20:19 --> Output Class Initialized
INFO - 2016-06-07 11:20:19 --> Security Class Initialized
DEBUG - 2016-06-07 11:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:20:19 --> Input Class Initialized
INFO - 2016-06-07 11:20:19 --> Language Class Initialized
INFO - 2016-06-07 11:20:19 --> Loader Class Initialized
INFO - 2016-06-07 11:20:19 --> Helper loaded: form_helper
INFO - 2016-06-07 11:20:19 --> Database Driver Class Initialized
INFO - 2016-06-07 11:20:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:20:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:20:19 --> Email Class Initialized
INFO - 2016-06-07 11:20:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:20:19 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:20:19 --> Helper loaded: language_helper
INFO - 2016-06-07 11:20:19 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:20:19 --> Model Class Initialized
INFO - 2016-06-07 11:20:19 --> Helper loaded: date_helper
INFO - 2016-06-07 11:20:19 --> Controller Class Initialized
INFO - 2016-06-07 11:20:19 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:20:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:20:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:20:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:20:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:20:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:20:19 --> Model Class Initialized
INFO - 2016-06-07 11:20:19 --> Form Validation Class Initialized
INFO - 2016-06-07 11:20:19 --> Final output sent to browser
DEBUG - 2016-06-07 11:20:19 --> Total execution time: 0.0904
INFO - 2016-06-07 11:20:33 --> Config Class Initialized
INFO - 2016-06-07 11:20:33 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:20:33 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:20:33 --> Utf8 Class Initialized
INFO - 2016-06-07 11:20:33 --> URI Class Initialized
INFO - 2016-06-07 11:20:33 --> Router Class Initialized
INFO - 2016-06-07 11:20:33 --> Output Class Initialized
INFO - 2016-06-07 11:20:33 --> Security Class Initialized
DEBUG - 2016-06-07 11:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:20:33 --> Input Class Initialized
INFO - 2016-06-07 11:20:33 --> Language Class Initialized
INFO - 2016-06-07 11:20:33 --> Loader Class Initialized
INFO - 2016-06-07 11:20:33 --> Helper loaded: form_helper
INFO - 2016-06-07 11:20:33 --> Database Driver Class Initialized
INFO - 2016-06-07 11:20:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:20:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:20:33 --> Email Class Initialized
INFO - 2016-06-07 11:20:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:20:33 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:20:33 --> Helper loaded: language_helper
INFO - 2016-06-07 11:20:33 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:20:33 --> Model Class Initialized
INFO - 2016-06-07 11:20:33 --> Helper loaded: date_helper
INFO - 2016-06-07 11:20:33 --> Controller Class Initialized
INFO - 2016-06-07 11:20:33 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:20:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:20:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:20:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:20:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:20:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:20:33 --> Model Class Initialized
INFO - 2016-06-07 11:20:33 --> Form Validation Class Initialized
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:20:33 --> Final output sent to browser
DEBUG - 2016-06-07 11:20:33 --> Total execution time: 0.0759
INFO - 2016-06-07 11:20:38 --> Config Class Initialized
INFO - 2016-06-07 11:20:38 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:20:38 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:20:38 --> Utf8 Class Initialized
INFO - 2016-06-07 11:20:38 --> URI Class Initialized
INFO - 2016-06-07 11:20:38 --> Router Class Initialized
INFO - 2016-06-07 11:20:38 --> Output Class Initialized
INFO - 2016-06-07 11:20:38 --> Security Class Initialized
DEBUG - 2016-06-07 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:20:38 --> Input Class Initialized
INFO - 2016-06-07 11:20:38 --> Language Class Initialized
INFO - 2016-06-07 11:20:38 --> Loader Class Initialized
INFO - 2016-06-07 11:20:38 --> Helper loaded: form_helper
INFO - 2016-06-07 11:20:38 --> Database Driver Class Initialized
INFO - 2016-06-07 11:20:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:20:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:20:38 --> Email Class Initialized
INFO - 2016-06-07 11:20:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:20:38 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:20:38 --> Helper loaded: language_helper
INFO - 2016-06-07 11:20:38 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:20:38 --> Model Class Initialized
INFO - 2016-06-07 11:20:38 --> Helper loaded: date_helper
INFO - 2016-06-07 11:20:38 --> Controller Class Initialized
INFO - 2016-06-07 11:20:38 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:20:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:20:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:20:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:20:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:20:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:20:38 --> Model Class Initialized
INFO - 2016-06-07 11:20:38 --> Form Validation Class Initialized
INFO - 2016-06-07 11:20:38 --> Final output sent to browser
DEBUG - 2016-06-07 11:20:38 --> Total execution time: 0.0960
INFO - 2016-06-07 11:22:18 --> Config Class Initialized
INFO - 2016-06-07 11:22:18 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:22:18 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:22:18 --> Utf8 Class Initialized
INFO - 2016-06-07 11:22:18 --> URI Class Initialized
INFO - 2016-06-07 11:22:18 --> Router Class Initialized
INFO - 2016-06-07 11:22:18 --> Output Class Initialized
INFO - 2016-06-07 11:22:18 --> Security Class Initialized
DEBUG - 2016-06-07 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:22:18 --> Input Class Initialized
INFO - 2016-06-07 11:22:18 --> Language Class Initialized
INFO - 2016-06-07 11:22:18 --> Loader Class Initialized
INFO - 2016-06-07 11:22:18 --> Helper loaded: form_helper
INFO - 2016-06-07 11:22:18 --> Database Driver Class Initialized
INFO - 2016-06-07 11:22:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:22:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:22:18 --> Email Class Initialized
INFO - 2016-06-07 11:22:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:22:18 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:22:18 --> Helper loaded: language_helper
INFO - 2016-06-07 11:22:18 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:22:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:22:18 --> Model Class Initialized
INFO - 2016-06-07 11:22:18 --> Helper loaded: date_helper
INFO - 2016-06-07 11:22:18 --> Controller Class Initialized
INFO - 2016-06-07 11:22:18 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:22:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:22:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:22:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:22:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:22:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:22:18 --> Model Class Initialized
INFO - 2016-06-07 11:22:18 --> Form Validation Class Initialized
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:22:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:22:18 --> Final output sent to browser
DEBUG - 2016-06-07 11:22:18 --> Total execution time: 0.0740
INFO - 2016-06-07 11:22:25 --> Config Class Initialized
INFO - 2016-06-07 11:22:25 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:22:25 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:22:25 --> Utf8 Class Initialized
INFO - 2016-06-07 11:22:25 --> URI Class Initialized
INFO - 2016-06-07 11:22:25 --> Router Class Initialized
INFO - 2016-06-07 11:22:25 --> Output Class Initialized
INFO - 2016-06-07 11:22:25 --> Security Class Initialized
DEBUG - 2016-06-07 11:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:22:25 --> Input Class Initialized
INFO - 2016-06-07 11:22:25 --> Language Class Initialized
INFO - 2016-06-07 11:22:25 --> Loader Class Initialized
INFO - 2016-06-07 11:22:25 --> Helper loaded: form_helper
INFO - 2016-06-07 11:22:25 --> Database Driver Class Initialized
INFO - 2016-06-07 11:22:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:22:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:22:25 --> Email Class Initialized
INFO - 2016-06-07 11:22:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:22:25 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:22:25 --> Helper loaded: language_helper
INFO - 2016-06-07 11:22:25 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:22:25 --> Model Class Initialized
INFO - 2016-06-07 11:22:25 --> Helper loaded: date_helper
INFO - 2016-06-07 11:22:25 --> Controller Class Initialized
INFO - 2016-06-07 11:22:25 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:22:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:22:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:22:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:22:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:22:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:22:25 --> Model Class Initialized
INFO - 2016-06-07 11:22:25 --> Form Validation Class Initialized
INFO - 2016-06-07 11:22:25 --> Final output sent to browser
DEBUG - 2016-06-07 11:22:25 --> Total execution time: 0.0855
INFO - 2016-06-07 11:22:50 --> Config Class Initialized
INFO - 2016-06-07 11:22:50 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:22:50 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:22:50 --> Utf8 Class Initialized
INFO - 2016-06-07 11:22:50 --> URI Class Initialized
INFO - 2016-06-07 11:22:50 --> Router Class Initialized
INFO - 2016-06-07 11:22:50 --> Output Class Initialized
INFO - 2016-06-07 11:22:50 --> Security Class Initialized
DEBUG - 2016-06-07 11:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:22:50 --> Input Class Initialized
INFO - 2016-06-07 11:22:50 --> Language Class Initialized
INFO - 2016-06-07 11:22:50 --> Loader Class Initialized
INFO - 2016-06-07 11:22:50 --> Helper loaded: form_helper
INFO - 2016-06-07 11:22:50 --> Database Driver Class Initialized
INFO - 2016-06-07 11:22:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:22:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:22:50 --> Email Class Initialized
INFO - 2016-06-07 11:22:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:22:50 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:22:50 --> Helper loaded: language_helper
INFO - 2016-06-07 11:22:50 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:22:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:22:50 --> Model Class Initialized
INFO - 2016-06-07 11:22:50 --> Helper loaded: date_helper
INFO - 2016-06-07 11:22:50 --> Controller Class Initialized
INFO - 2016-06-07 11:22:50 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:22:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:22:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:22:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:22:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:22:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:22:50 --> Model Class Initialized
INFO - 2016-06-07 11:22:50 --> Form Validation Class Initialized
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:22:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:22:50 --> Final output sent to browser
DEBUG - 2016-06-07 11:22:50 --> Total execution time: 0.0903
INFO - 2016-06-07 11:22:57 --> Config Class Initialized
INFO - 2016-06-07 11:22:57 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:22:57 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:22:57 --> Utf8 Class Initialized
INFO - 2016-06-07 11:22:57 --> URI Class Initialized
INFO - 2016-06-07 11:22:57 --> Router Class Initialized
INFO - 2016-06-07 11:22:57 --> Output Class Initialized
INFO - 2016-06-07 11:22:57 --> Security Class Initialized
DEBUG - 2016-06-07 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:22:57 --> Input Class Initialized
INFO - 2016-06-07 11:22:57 --> Language Class Initialized
INFO - 2016-06-07 11:22:57 --> Loader Class Initialized
INFO - 2016-06-07 11:22:57 --> Helper loaded: form_helper
INFO - 2016-06-07 11:22:57 --> Database Driver Class Initialized
INFO - 2016-06-07 11:22:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:22:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:22:57 --> Email Class Initialized
INFO - 2016-06-07 11:22:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:22:57 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:22:57 --> Helper loaded: language_helper
INFO - 2016-06-07 11:22:57 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:22:57 --> Model Class Initialized
INFO - 2016-06-07 11:22:57 --> Helper loaded: date_helper
INFO - 2016-06-07 11:22:57 --> Controller Class Initialized
INFO - 2016-06-07 11:22:57 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:22:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:22:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:22:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:22:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:22:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:22:57 --> Model Class Initialized
INFO - 2016-06-07 11:22:57 --> Form Validation Class Initialized
INFO - 2016-06-07 11:22:57 --> Final output sent to browser
DEBUG - 2016-06-07 11:22:57 --> Total execution time: 0.0782
INFO - 2016-06-07 11:23:15 --> Config Class Initialized
INFO - 2016-06-07 11:23:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:23:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:23:15 --> Utf8 Class Initialized
INFO - 2016-06-07 11:23:15 --> URI Class Initialized
INFO - 2016-06-07 11:23:15 --> Router Class Initialized
INFO - 2016-06-07 11:23:15 --> Output Class Initialized
INFO - 2016-06-07 11:23:15 --> Security Class Initialized
DEBUG - 2016-06-07 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:23:15 --> Input Class Initialized
INFO - 2016-06-07 11:23:15 --> Language Class Initialized
INFO - 2016-06-07 11:23:15 --> Loader Class Initialized
INFO - 2016-06-07 11:23:15 --> Helper loaded: form_helper
INFO - 2016-06-07 11:23:15 --> Database Driver Class Initialized
INFO - 2016-06-07 11:23:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:23:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:23:15 --> Email Class Initialized
INFO - 2016-06-07 11:23:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:23:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:23:15 --> Helper loaded: language_helper
INFO - 2016-06-07 11:23:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:23:15 --> Model Class Initialized
INFO - 2016-06-07 11:23:15 --> Helper loaded: date_helper
INFO - 2016-06-07 11:23:15 --> Controller Class Initialized
INFO - 2016-06-07 11:23:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:23:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:23:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:23:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:23:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:23:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:23:15 --> Model Class Initialized
INFO - 2016-06-07 11:23:15 --> Form Validation Class Initialized
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:23:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:23:15 --> Final output sent to browser
DEBUG - 2016-06-07 11:23:15 --> Total execution time: 0.1164
INFO - 2016-06-07 11:23:21 --> Config Class Initialized
INFO - 2016-06-07 11:23:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:23:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:23:21 --> Utf8 Class Initialized
INFO - 2016-06-07 11:23:21 --> URI Class Initialized
INFO - 2016-06-07 11:23:21 --> Router Class Initialized
INFO - 2016-06-07 11:23:21 --> Output Class Initialized
INFO - 2016-06-07 11:23:21 --> Security Class Initialized
DEBUG - 2016-06-07 11:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:23:21 --> Input Class Initialized
INFO - 2016-06-07 11:23:21 --> Language Class Initialized
INFO - 2016-06-07 11:23:21 --> Loader Class Initialized
INFO - 2016-06-07 11:23:21 --> Helper loaded: form_helper
INFO - 2016-06-07 11:23:21 --> Database Driver Class Initialized
INFO - 2016-06-07 11:23:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:23:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:23:21 --> Email Class Initialized
INFO - 2016-06-07 11:23:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:23:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:23:21 --> Helper loaded: language_helper
INFO - 2016-06-07 11:23:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:23:21 --> Model Class Initialized
INFO - 2016-06-07 11:23:21 --> Helper loaded: date_helper
INFO - 2016-06-07 11:23:21 --> Controller Class Initialized
INFO - 2016-06-07 11:23:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:23:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:23:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:23:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:23:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:23:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:23:21 --> Model Class Initialized
INFO - 2016-06-07 11:23:21 --> Form Validation Class Initialized
INFO - 2016-06-07 11:23:21 --> Final output sent to browser
DEBUG - 2016-06-07 11:23:21 --> Total execution time: 0.0255
INFO - 2016-06-07 11:23:32 --> Config Class Initialized
INFO - 2016-06-07 11:23:32 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:23:32 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:23:32 --> Utf8 Class Initialized
INFO - 2016-06-07 11:23:32 --> URI Class Initialized
INFO - 2016-06-07 11:23:32 --> Router Class Initialized
INFO - 2016-06-07 11:23:32 --> Output Class Initialized
INFO - 2016-06-07 11:23:32 --> Security Class Initialized
DEBUG - 2016-06-07 11:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:23:32 --> Input Class Initialized
INFO - 2016-06-07 11:23:32 --> Language Class Initialized
INFO - 2016-06-07 11:23:32 --> Loader Class Initialized
INFO - 2016-06-07 11:23:32 --> Helper loaded: form_helper
INFO - 2016-06-07 11:23:32 --> Database Driver Class Initialized
INFO - 2016-06-07 11:23:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:23:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:23:32 --> Email Class Initialized
INFO - 2016-06-07 11:23:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:23:32 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:23:32 --> Helper loaded: language_helper
INFO - 2016-06-07 11:23:32 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:23:32 --> Model Class Initialized
INFO - 2016-06-07 11:23:32 --> Helper loaded: date_helper
INFO - 2016-06-07 11:23:32 --> Controller Class Initialized
INFO - 2016-06-07 11:23:32 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:23:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:23:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:23:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:23:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:23:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:23:32 --> Model Class Initialized
INFO - 2016-06-07 11:23:32 --> Form Validation Class Initialized
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:23:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:23:32 --> Final output sent to browser
DEBUG - 2016-06-07 11:23:32 --> Total execution time: 0.0729
INFO - 2016-06-07 11:23:39 --> Config Class Initialized
INFO - 2016-06-07 11:23:39 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:23:39 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:23:39 --> Utf8 Class Initialized
INFO - 2016-06-07 11:23:39 --> URI Class Initialized
INFO - 2016-06-07 11:23:39 --> Router Class Initialized
INFO - 2016-06-07 11:23:39 --> Output Class Initialized
INFO - 2016-06-07 11:23:39 --> Security Class Initialized
DEBUG - 2016-06-07 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:23:39 --> Input Class Initialized
INFO - 2016-06-07 11:23:39 --> Language Class Initialized
INFO - 2016-06-07 11:23:39 --> Loader Class Initialized
INFO - 2016-06-07 11:23:39 --> Helper loaded: form_helper
INFO - 2016-06-07 11:23:39 --> Database Driver Class Initialized
INFO - 2016-06-07 11:23:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:23:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:23:39 --> Email Class Initialized
INFO - 2016-06-07 11:23:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:23:39 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:23:39 --> Helper loaded: language_helper
INFO - 2016-06-07 11:23:39 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:23:39 --> Model Class Initialized
INFO - 2016-06-07 11:23:39 --> Helper loaded: date_helper
INFO - 2016-06-07 11:23:39 --> Controller Class Initialized
INFO - 2016-06-07 11:23:39 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:23:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:23:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:23:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:23:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:23:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:23:39 --> Model Class Initialized
INFO - 2016-06-07 11:23:39 --> Form Validation Class Initialized
INFO - 2016-06-07 11:23:39 --> Final output sent to browser
DEBUG - 2016-06-07 11:23:39 --> Total execution time: 0.0951
INFO - 2016-06-07 11:23:59 --> Config Class Initialized
INFO - 2016-06-07 11:23:59 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:23:59 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:23:59 --> Utf8 Class Initialized
INFO - 2016-06-07 11:23:59 --> URI Class Initialized
INFO - 2016-06-07 11:23:59 --> Router Class Initialized
INFO - 2016-06-07 11:23:59 --> Output Class Initialized
INFO - 2016-06-07 11:23:59 --> Security Class Initialized
DEBUG - 2016-06-07 11:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:23:59 --> Input Class Initialized
INFO - 2016-06-07 11:23:59 --> Language Class Initialized
INFO - 2016-06-07 11:23:59 --> Loader Class Initialized
INFO - 2016-06-07 11:23:59 --> Helper loaded: form_helper
INFO - 2016-06-07 11:23:59 --> Database Driver Class Initialized
INFO - 2016-06-07 11:23:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:23:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:23:59 --> Email Class Initialized
INFO - 2016-06-07 11:23:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:23:59 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:23:59 --> Helper loaded: language_helper
INFO - 2016-06-07 11:23:59 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:23:59 --> Model Class Initialized
INFO - 2016-06-07 11:23:59 --> Helper loaded: date_helper
INFO - 2016-06-07 11:23:59 --> Controller Class Initialized
INFO - 2016-06-07 11:23:59 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:23:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:23:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:23:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:23:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:23:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:23:59 --> Model Class Initialized
INFO - 2016-06-07 11:23:59 --> Form Validation Class Initialized
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:23:59 --> Final output sent to browser
DEBUG - 2016-06-07 11:23:59 --> Total execution time: 0.0847
INFO - 2016-06-07 11:24:04 --> Config Class Initialized
INFO - 2016-06-07 11:24:04 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:24:04 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:24:04 --> Utf8 Class Initialized
INFO - 2016-06-07 11:24:04 --> URI Class Initialized
INFO - 2016-06-07 11:24:04 --> Router Class Initialized
INFO - 2016-06-07 11:24:04 --> Output Class Initialized
INFO - 2016-06-07 11:24:04 --> Security Class Initialized
DEBUG - 2016-06-07 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:24:04 --> Input Class Initialized
INFO - 2016-06-07 11:24:04 --> Language Class Initialized
INFO - 2016-06-07 11:24:04 --> Loader Class Initialized
INFO - 2016-06-07 11:24:04 --> Helper loaded: form_helper
INFO - 2016-06-07 11:24:04 --> Database Driver Class Initialized
INFO - 2016-06-07 11:24:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:24:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:24:04 --> Email Class Initialized
INFO - 2016-06-07 11:24:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:24:04 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:24:04 --> Helper loaded: language_helper
INFO - 2016-06-07 11:24:04 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:24:04 --> Model Class Initialized
INFO - 2016-06-07 11:24:04 --> Helper loaded: date_helper
INFO - 2016-06-07 11:24:04 --> Controller Class Initialized
INFO - 2016-06-07 11:24:04 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:24:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:24:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:24:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:24:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:24:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:24:04 --> Model Class Initialized
INFO - 2016-06-07 11:24:04 --> Form Validation Class Initialized
INFO - 2016-06-07 11:24:04 --> Final output sent to browser
DEBUG - 2016-06-07 11:24:04 --> Total execution time: 0.0553
INFO - 2016-06-07 11:24:56 --> Config Class Initialized
INFO - 2016-06-07 11:24:56 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:24:56 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:24:56 --> Utf8 Class Initialized
INFO - 2016-06-07 11:24:56 --> URI Class Initialized
INFO - 2016-06-07 11:24:56 --> Router Class Initialized
INFO - 2016-06-07 11:24:56 --> Output Class Initialized
INFO - 2016-06-07 11:24:56 --> Security Class Initialized
DEBUG - 2016-06-07 11:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:24:56 --> Input Class Initialized
INFO - 2016-06-07 11:24:56 --> Language Class Initialized
INFO - 2016-06-07 11:24:56 --> Loader Class Initialized
INFO - 2016-06-07 11:24:56 --> Helper loaded: form_helper
INFO - 2016-06-07 11:24:56 --> Database Driver Class Initialized
INFO - 2016-06-07 11:24:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:24:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:24:56 --> Email Class Initialized
INFO - 2016-06-07 11:24:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:24:56 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:24:56 --> Helper loaded: language_helper
INFO - 2016-06-07 11:24:56 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:24:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:24:56 --> Model Class Initialized
INFO - 2016-06-07 11:24:56 --> Helper loaded: date_helper
INFO - 2016-06-07 11:24:56 --> Controller Class Initialized
INFO - 2016-06-07 11:24:56 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:24:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:24:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:24:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:24:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:24:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:24:56 --> Model Class Initialized
INFO - 2016-06-07 11:24:56 --> Form Validation Class Initialized
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:24:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:24:57 --> Final output sent to browser
DEBUG - 2016-06-07 11:24:57 --> Total execution time: 0.2439
INFO - 2016-06-07 11:25:03 --> Config Class Initialized
INFO - 2016-06-07 11:25:03 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:25:03 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:25:03 --> Utf8 Class Initialized
INFO - 2016-06-07 11:25:03 --> URI Class Initialized
INFO - 2016-06-07 11:25:03 --> Router Class Initialized
INFO - 2016-06-07 11:25:03 --> Output Class Initialized
INFO - 2016-06-07 11:25:03 --> Security Class Initialized
DEBUG - 2016-06-07 11:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:25:03 --> Input Class Initialized
INFO - 2016-06-07 11:25:03 --> Language Class Initialized
INFO - 2016-06-07 11:25:03 --> Loader Class Initialized
INFO - 2016-06-07 11:25:03 --> Helper loaded: form_helper
INFO - 2016-06-07 11:25:03 --> Database Driver Class Initialized
INFO - 2016-06-07 11:25:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:25:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:25:03 --> Email Class Initialized
INFO - 2016-06-07 11:25:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:25:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:25:03 --> Helper loaded: language_helper
INFO - 2016-06-07 11:25:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:25:03 --> Model Class Initialized
INFO - 2016-06-07 11:25:03 --> Helper loaded: date_helper
INFO - 2016-06-07 11:25:03 --> Controller Class Initialized
INFO - 2016-06-07 11:25:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:25:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:25:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:25:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:25:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:25:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:25:03 --> Model Class Initialized
INFO - 2016-06-07 11:25:03 --> Form Validation Class Initialized
INFO - 2016-06-07 11:25:03 --> Final output sent to browser
DEBUG - 2016-06-07 11:25:03 --> Total execution time: 0.0803
INFO - 2016-06-07 11:25:18 --> Config Class Initialized
INFO - 2016-06-07 11:25:18 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:25:18 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:25:18 --> Utf8 Class Initialized
INFO - 2016-06-07 11:25:18 --> URI Class Initialized
INFO - 2016-06-07 11:25:18 --> Router Class Initialized
INFO - 2016-06-07 11:25:18 --> Output Class Initialized
INFO - 2016-06-07 11:25:18 --> Security Class Initialized
DEBUG - 2016-06-07 11:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:25:18 --> Input Class Initialized
INFO - 2016-06-07 11:25:18 --> Language Class Initialized
INFO - 2016-06-07 11:25:18 --> Loader Class Initialized
INFO - 2016-06-07 11:25:18 --> Helper loaded: form_helper
INFO - 2016-06-07 11:25:18 --> Database Driver Class Initialized
INFO - 2016-06-07 11:25:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:25:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:25:18 --> Email Class Initialized
INFO - 2016-06-07 11:25:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:25:18 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:25:18 --> Helper loaded: language_helper
INFO - 2016-06-07 11:25:18 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:25:18 --> Model Class Initialized
INFO - 2016-06-07 11:25:18 --> Helper loaded: date_helper
INFO - 2016-06-07 11:25:18 --> Controller Class Initialized
INFO - 2016-06-07 11:25:18 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:25:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:25:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:25:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:25:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:25:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:25:18 --> Model Class Initialized
INFO - 2016-06-07 11:25:18 --> Form Validation Class Initialized
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:25:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:25:18 --> Final output sent to browser
DEBUG - 2016-06-07 11:25:18 --> Total execution time: 0.0617
INFO - 2016-06-07 11:25:25 --> Config Class Initialized
INFO - 2016-06-07 11:25:25 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:25:25 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:25:25 --> Utf8 Class Initialized
INFO - 2016-06-07 11:25:25 --> URI Class Initialized
INFO - 2016-06-07 11:25:25 --> Router Class Initialized
INFO - 2016-06-07 11:25:25 --> Output Class Initialized
INFO - 2016-06-07 11:25:25 --> Security Class Initialized
DEBUG - 2016-06-07 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:25:25 --> Input Class Initialized
INFO - 2016-06-07 11:25:25 --> Language Class Initialized
INFO - 2016-06-07 11:25:25 --> Loader Class Initialized
INFO - 2016-06-07 11:25:25 --> Helper loaded: form_helper
INFO - 2016-06-07 11:25:25 --> Database Driver Class Initialized
INFO - 2016-06-07 11:25:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:25:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:25:25 --> Email Class Initialized
INFO - 2016-06-07 11:25:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:25:25 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:25:25 --> Helper loaded: language_helper
INFO - 2016-06-07 11:25:25 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:25:25 --> Model Class Initialized
INFO - 2016-06-07 11:25:25 --> Helper loaded: date_helper
INFO - 2016-06-07 11:25:25 --> Controller Class Initialized
INFO - 2016-06-07 11:25:25 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:25:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:25:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:25:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:25:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:25:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:25:25 --> Model Class Initialized
INFO - 2016-06-07 11:25:25 --> Form Validation Class Initialized
INFO - 2016-06-07 11:25:25 --> Final output sent to browser
DEBUG - 2016-06-07 11:25:25 --> Total execution time: 0.0522
INFO - 2016-06-07 11:28:25 --> Config Class Initialized
INFO - 2016-06-07 11:28:25 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:28:25 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:28:25 --> Utf8 Class Initialized
INFO - 2016-06-07 11:28:25 --> URI Class Initialized
INFO - 2016-06-07 11:28:25 --> Router Class Initialized
INFO - 2016-06-07 11:28:25 --> Output Class Initialized
INFO - 2016-06-07 11:28:25 --> Security Class Initialized
DEBUG - 2016-06-07 11:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:28:25 --> Input Class Initialized
INFO - 2016-06-07 11:28:25 --> Language Class Initialized
INFO - 2016-06-07 11:28:25 --> Loader Class Initialized
INFO - 2016-06-07 11:28:25 --> Helper loaded: form_helper
INFO - 2016-06-07 11:28:25 --> Database Driver Class Initialized
INFO - 2016-06-07 11:28:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:28:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:28:25 --> Email Class Initialized
INFO - 2016-06-07 11:28:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:28:25 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:28:25 --> Helper loaded: language_helper
INFO - 2016-06-07 11:28:25 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:28:25 --> Model Class Initialized
INFO - 2016-06-07 11:28:25 --> Helper loaded: date_helper
INFO - 2016-06-07 11:28:25 --> Controller Class Initialized
INFO - 2016-06-07 11:28:25 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:28:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:28:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:28:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:28:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:28:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:28:25 --> Model Class Initialized
INFO - 2016-06-07 11:28:25 --> Form Validation Class Initialized
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:28:25 --> Final output sent to browser
DEBUG - 2016-06-07 11:28:25 --> Total execution time: 0.0994
INFO - 2016-06-07 11:28:46 --> Config Class Initialized
INFO - 2016-06-07 11:28:46 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:28:46 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:28:46 --> Utf8 Class Initialized
INFO - 2016-06-07 11:28:46 --> URI Class Initialized
INFO - 2016-06-07 11:28:46 --> Router Class Initialized
INFO - 2016-06-07 11:28:46 --> Output Class Initialized
INFO - 2016-06-07 11:28:46 --> Security Class Initialized
DEBUG - 2016-06-07 11:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:28:46 --> Input Class Initialized
INFO - 2016-06-07 11:28:46 --> Language Class Initialized
INFO - 2016-06-07 11:28:46 --> Loader Class Initialized
INFO - 2016-06-07 11:28:46 --> Helper loaded: form_helper
INFO - 2016-06-07 11:28:46 --> Database Driver Class Initialized
INFO - 2016-06-07 11:28:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:28:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:28:47 --> Email Class Initialized
INFO - 2016-06-07 11:28:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:28:47 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:28:47 --> Helper loaded: language_helper
INFO - 2016-06-07 11:28:47 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:28:47 --> Model Class Initialized
INFO - 2016-06-07 11:28:47 --> Helper loaded: date_helper
INFO - 2016-06-07 11:28:47 --> Controller Class Initialized
INFO - 2016-06-07 11:28:47 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:28:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:28:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:28:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:28:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:28:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:28:47 --> Model Class Initialized
INFO - 2016-06-07 11:28:47 --> Form Validation Class Initialized
INFO - 2016-06-07 11:28:47 --> Final output sent to browser
DEBUG - 2016-06-07 11:28:47 --> Total execution time: 0.0946
INFO - 2016-06-07 11:30:15 --> Config Class Initialized
INFO - 2016-06-07 11:30:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:30:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:30:15 --> Utf8 Class Initialized
INFO - 2016-06-07 11:30:15 --> URI Class Initialized
INFO - 2016-06-07 11:30:15 --> Router Class Initialized
INFO - 2016-06-07 11:30:15 --> Output Class Initialized
INFO - 2016-06-07 11:30:15 --> Security Class Initialized
DEBUG - 2016-06-07 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:30:15 --> Input Class Initialized
INFO - 2016-06-07 11:30:15 --> Language Class Initialized
INFO - 2016-06-07 11:30:15 --> Loader Class Initialized
INFO - 2016-06-07 11:30:15 --> Helper loaded: form_helper
INFO - 2016-06-07 11:30:15 --> Database Driver Class Initialized
INFO - 2016-06-07 11:30:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:30:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:30:15 --> Email Class Initialized
INFO - 2016-06-07 11:30:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:30:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:30:15 --> Helper loaded: language_helper
INFO - 2016-06-07 11:30:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:30:15 --> Model Class Initialized
INFO - 2016-06-07 11:30:15 --> Helper loaded: date_helper
INFO - 2016-06-07 11:30:15 --> Controller Class Initialized
INFO - 2016-06-07 11:30:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:30:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:30:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:30:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:30:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:30:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:30:15 --> Model Class Initialized
INFO - 2016-06-07 11:30:15 --> Form Validation Class Initialized
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:30:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:30:15 --> Final output sent to browser
DEBUG - 2016-06-07 11:30:15 --> Total execution time: 0.1188
INFO - 2016-06-07 11:30:21 --> Config Class Initialized
INFO - 2016-06-07 11:30:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:30:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:30:21 --> Utf8 Class Initialized
INFO - 2016-06-07 11:30:21 --> URI Class Initialized
INFO - 2016-06-07 11:30:21 --> Router Class Initialized
INFO - 2016-06-07 11:30:21 --> Output Class Initialized
INFO - 2016-06-07 11:30:21 --> Security Class Initialized
DEBUG - 2016-06-07 11:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:30:21 --> Input Class Initialized
INFO - 2016-06-07 11:30:21 --> Language Class Initialized
INFO - 2016-06-07 11:30:21 --> Loader Class Initialized
INFO - 2016-06-07 11:30:21 --> Helper loaded: form_helper
INFO - 2016-06-07 11:30:21 --> Database Driver Class Initialized
INFO - 2016-06-07 11:30:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:30:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:30:21 --> Email Class Initialized
INFO - 2016-06-07 11:30:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:30:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:30:21 --> Helper loaded: language_helper
INFO - 2016-06-07 11:30:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:30:21 --> Model Class Initialized
INFO - 2016-06-07 11:30:21 --> Helper loaded: date_helper
INFO - 2016-06-07 11:30:21 --> Controller Class Initialized
INFO - 2016-06-07 11:30:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:30:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:30:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:30:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:30:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:30:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:30:21 --> Model Class Initialized
INFO - 2016-06-07 11:30:21 --> Form Validation Class Initialized
INFO - 2016-06-07 11:30:21 --> Final output sent to browser
DEBUG - 2016-06-07 11:30:21 --> Total execution time: 0.0209
INFO - 2016-06-07 11:30:55 --> Config Class Initialized
INFO - 2016-06-07 11:30:55 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:30:55 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:30:55 --> Utf8 Class Initialized
INFO - 2016-06-07 11:30:55 --> URI Class Initialized
INFO - 2016-06-07 11:30:55 --> Router Class Initialized
INFO - 2016-06-07 11:30:55 --> Output Class Initialized
INFO - 2016-06-07 11:30:55 --> Security Class Initialized
DEBUG - 2016-06-07 11:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:30:55 --> Input Class Initialized
INFO - 2016-06-07 11:30:55 --> Language Class Initialized
INFO - 2016-06-07 11:30:55 --> Loader Class Initialized
INFO - 2016-06-07 11:30:55 --> Helper loaded: form_helper
INFO - 2016-06-07 11:30:55 --> Database Driver Class Initialized
INFO - 2016-06-07 11:30:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:30:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:30:55 --> Email Class Initialized
INFO - 2016-06-07 11:30:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:30:55 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:30:55 --> Helper loaded: language_helper
INFO - 2016-06-07 11:30:55 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:30:55 --> Model Class Initialized
INFO - 2016-06-07 11:30:55 --> Helper loaded: date_helper
INFO - 2016-06-07 11:30:55 --> Controller Class Initialized
INFO - 2016-06-07 11:30:55 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:30:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:30:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:30:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:30:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:30:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:30:55 --> Model Class Initialized
INFO - 2016-06-07 11:30:55 --> Form Validation Class Initialized
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:30:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:30:55 --> Final output sent to browser
DEBUG - 2016-06-07 11:30:55 --> Total execution time: 0.1414
INFO - 2016-06-07 11:31:01 --> Config Class Initialized
INFO - 2016-06-07 11:31:01 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:31:01 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:31:01 --> Utf8 Class Initialized
INFO - 2016-06-07 11:31:01 --> URI Class Initialized
INFO - 2016-06-07 11:31:01 --> Router Class Initialized
INFO - 2016-06-07 11:31:01 --> Output Class Initialized
INFO - 2016-06-07 11:31:01 --> Security Class Initialized
DEBUG - 2016-06-07 11:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:31:01 --> Input Class Initialized
INFO - 2016-06-07 11:31:01 --> Language Class Initialized
INFO - 2016-06-07 11:31:01 --> Loader Class Initialized
INFO - 2016-06-07 11:31:01 --> Helper loaded: form_helper
INFO - 2016-06-07 11:31:01 --> Database Driver Class Initialized
INFO - 2016-06-07 11:31:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:31:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:31:01 --> Email Class Initialized
INFO - 2016-06-07 11:31:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:31:01 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:31:01 --> Helper loaded: language_helper
INFO - 2016-06-07 11:31:01 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:31:01 --> Model Class Initialized
INFO - 2016-06-07 11:31:01 --> Helper loaded: date_helper
INFO - 2016-06-07 11:31:01 --> Controller Class Initialized
INFO - 2016-06-07 11:31:01 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:31:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:31:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:31:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:31:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:31:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:31:01 --> Model Class Initialized
INFO - 2016-06-07 11:31:01 --> Form Validation Class Initialized
INFO - 2016-06-07 11:31:01 --> Final output sent to browser
DEBUG - 2016-06-07 11:31:01 --> Total execution time: 0.0675
INFO - 2016-06-07 11:31:13 --> Config Class Initialized
INFO - 2016-06-07 11:31:13 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:31:13 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:31:13 --> Utf8 Class Initialized
INFO - 2016-06-07 11:31:13 --> URI Class Initialized
INFO - 2016-06-07 11:31:13 --> Router Class Initialized
INFO - 2016-06-07 11:31:13 --> Output Class Initialized
INFO - 2016-06-07 11:31:13 --> Security Class Initialized
DEBUG - 2016-06-07 11:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:31:13 --> Input Class Initialized
INFO - 2016-06-07 11:31:13 --> Language Class Initialized
INFO - 2016-06-07 11:31:13 --> Loader Class Initialized
INFO - 2016-06-07 11:31:13 --> Helper loaded: form_helper
INFO - 2016-06-07 11:31:13 --> Database Driver Class Initialized
INFO - 2016-06-07 11:31:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:31:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:31:13 --> Email Class Initialized
INFO - 2016-06-07 11:31:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:31:13 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:31:13 --> Helper loaded: language_helper
INFO - 2016-06-07 11:31:13 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:31:13 --> Model Class Initialized
INFO - 2016-06-07 11:31:13 --> Helper loaded: date_helper
INFO - 2016-06-07 11:31:13 --> Controller Class Initialized
INFO - 2016-06-07 11:31:13 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:31:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:31:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:31:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:31:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:31:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:31:13 --> Model Class Initialized
INFO - 2016-06-07 11:31:13 --> Form Validation Class Initialized
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:31:13 --> Final output sent to browser
DEBUG - 2016-06-07 11:31:13 --> Total execution time: 0.0724
INFO - 2016-06-07 11:31:22 --> Config Class Initialized
INFO - 2016-06-07 11:31:22 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:31:22 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:31:22 --> Utf8 Class Initialized
INFO - 2016-06-07 11:31:22 --> URI Class Initialized
INFO - 2016-06-07 11:31:22 --> Router Class Initialized
INFO - 2016-06-07 11:31:22 --> Output Class Initialized
INFO - 2016-06-07 11:31:22 --> Security Class Initialized
DEBUG - 2016-06-07 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:31:22 --> Input Class Initialized
INFO - 2016-06-07 11:31:22 --> Language Class Initialized
INFO - 2016-06-07 11:31:22 --> Loader Class Initialized
INFO - 2016-06-07 11:31:22 --> Helper loaded: form_helper
INFO - 2016-06-07 11:31:22 --> Database Driver Class Initialized
INFO - 2016-06-07 11:31:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:31:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:31:22 --> Email Class Initialized
INFO - 2016-06-07 11:31:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:31:22 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:31:22 --> Helper loaded: language_helper
INFO - 2016-06-07 11:31:22 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:31:22 --> Model Class Initialized
INFO - 2016-06-07 11:31:22 --> Helper loaded: date_helper
INFO - 2016-06-07 11:31:22 --> Controller Class Initialized
INFO - 2016-06-07 11:31:22 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:31:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:31:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:31:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:31:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:31:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:31:22 --> Model Class Initialized
INFO - 2016-06-07 11:31:22 --> Form Validation Class Initialized
INFO - 2016-06-07 11:31:22 --> Final output sent to browser
DEBUG - 2016-06-07 11:31:22 --> Total execution time: 0.1301
INFO - 2016-06-07 11:33:13 --> Config Class Initialized
INFO - 2016-06-07 11:33:13 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:33:13 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:33:13 --> Utf8 Class Initialized
INFO - 2016-06-07 11:33:13 --> URI Class Initialized
DEBUG - 2016-06-07 11:33:13 --> No URI present. Default controller set.
INFO - 2016-06-07 11:33:13 --> Router Class Initialized
INFO - 2016-06-07 11:33:13 --> Output Class Initialized
INFO - 2016-06-07 11:33:13 --> Security Class Initialized
DEBUG - 2016-06-07 11:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:33:13 --> Input Class Initialized
INFO - 2016-06-07 11:33:13 --> Language Class Initialized
INFO - 2016-06-07 11:33:13 --> Loader Class Initialized
INFO - 2016-06-07 11:33:13 --> Helper loaded: form_helper
INFO - 2016-06-07 11:33:13 --> Database Driver Class Initialized
INFO - 2016-06-07 11:33:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:33:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:33:13 --> Email Class Initialized
INFO - 2016-06-07 11:33:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:33:13 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:33:13 --> Helper loaded: language_helper
INFO - 2016-06-07 11:33:13 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:13 --> Model Class Initialized
INFO - 2016-06-07 11:33:13 --> Helper loaded: date_helper
INFO - 2016-06-07 11:33:13 --> Controller Class Initialized
INFO - 2016-06-07 11:33:13 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:33:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:33:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:33:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:33:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:33:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:33:17 --> Config Class Initialized
INFO - 2016-06-07 11:33:17 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:33:17 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:33:17 --> Utf8 Class Initialized
INFO - 2016-06-07 11:33:17 --> URI Class Initialized
INFO - 2016-06-07 11:33:17 --> Router Class Initialized
INFO - 2016-06-07 11:33:17 --> Output Class Initialized
INFO - 2016-06-07 11:33:17 --> Security Class Initialized
DEBUG - 2016-06-07 11:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:33:17 --> Input Class Initialized
INFO - 2016-06-07 11:33:17 --> Language Class Initialized
INFO - 2016-06-07 11:33:17 --> Loader Class Initialized
INFO - 2016-06-07 11:33:17 --> Helper loaded: form_helper
INFO - 2016-06-07 11:33:17 --> Database Driver Class Initialized
INFO - 2016-06-07 11:33:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:33:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:33:17 --> Email Class Initialized
INFO - 2016-06-07 11:33:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:33:17 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:33:17 --> Helper loaded: language_helper
INFO - 2016-06-07 11:33:17 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:33:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:17 --> Model Class Initialized
INFO - 2016-06-07 11:33:17 --> Helper loaded: date_helper
INFO - 2016-06-07 11:33:17 --> Controller Class Initialized
INFO - 2016-06-07 11:33:17 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:33:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:33:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:33:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:33:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:33:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:33:17 --> Model Class Initialized
INFO - 2016-06-07 11:33:17 --> Form Validation Class Initialized
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:33:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:33:17 --> Final output sent to browser
DEBUG - 2016-06-07 11:33:17 --> Total execution time: 0.0777
INFO - 2016-06-07 11:33:21 --> Config Class Initialized
INFO - 2016-06-07 11:33:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:33:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:33:21 --> Utf8 Class Initialized
INFO - 2016-06-07 11:33:21 --> URI Class Initialized
INFO - 2016-06-07 11:33:21 --> Router Class Initialized
INFO - 2016-06-07 11:33:21 --> Output Class Initialized
INFO - 2016-06-07 11:33:21 --> Security Class Initialized
DEBUG - 2016-06-07 11:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:33:21 --> Input Class Initialized
INFO - 2016-06-07 11:33:21 --> Language Class Initialized
INFO - 2016-06-07 11:33:21 --> Loader Class Initialized
INFO - 2016-06-07 11:33:21 --> Helper loaded: form_helper
INFO - 2016-06-07 11:33:21 --> Database Driver Class Initialized
INFO - 2016-06-07 11:33:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:33:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:33:21 --> Email Class Initialized
INFO - 2016-06-07 11:33:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:33:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:33:21 --> Helper loaded: language_helper
INFO - 2016-06-07 11:33:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:21 --> Model Class Initialized
INFO - 2016-06-07 11:33:21 --> Helper loaded: date_helper
INFO - 2016-06-07 11:33:21 --> Controller Class Initialized
INFO - 2016-06-07 11:33:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:33:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:33:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:33:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:33:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:33:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:33:21 --> Model Class Initialized
INFO - 2016-06-07 11:33:21 --> Form Validation Class Initialized
INFO - 2016-06-07 11:33:21 --> Final output sent to browser
DEBUG - 2016-06-07 11:33:21 --> Total execution time: 0.0601
INFO - 2016-06-07 11:33:22 --> Config Class Initialized
INFO - 2016-06-07 11:33:22 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:33:22 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:33:22 --> Utf8 Class Initialized
INFO - 2016-06-07 11:33:22 --> URI Class Initialized
INFO - 2016-06-07 11:33:22 --> Router Class Initialized
INFO - 2016-06-07 11:33:22 --> Output Class Initialized
INFO - 2016-06-07 11:33:22 --> Security Class Initialized
DEBUG - 2016-06-07 11:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:33:22 --> Input Class Initialized
INFO - 2016-06-07 11:33:22 --> Language Class Initialized
INFO - 2016-06-07 11:33:22 --> Loader Class Initialized
INFO - 2016-06-07 11:33:22 --> Helper loaded: form_helper
INFO - 2016-06-07 11:33:22 --> Database Driver Class Initialized
INFO - 2016-06-07 11:33:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:33:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:33:22 --> Email Class Initialized
INFO - 2016-06-07 11:33:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:33:22 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:33:22 --> Helper loaded: language_helper
INFO - 2016-06-07 11:33:22 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:22 --> Model Class Initialized
INFO - 2016-06-07 11:33:22 --> Helper loaded: date_helper
INFO - 2016-06-07 11:33:22 --> Controller Class Initialized
INFO - 2016-06-07 11:33:22 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:33:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:33:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:33:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:33:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:33:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 11:33:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:22 --> Form Validation Class Initialized
INFO - 2016-06-07 11:33:23 --> Config Class Initialized
INFO - 2016-06-07 11:33:23 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:33:23 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:33:23 --> Utf8 Class Initialized
INFO - 2016-06-07 11:33:23 --> URI Class Initialized
INFO - 2016-06-07 11:33:23 --> Router Class Initialized
INFO - 2016-06-07 11:33:23 --> Output Class Initialized
INFO - 2016-06-07 11:33:23 --> Security Class Initialized
DEBUG - 2016-06-07 11:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:33:23 --> Input Class Initialized
INFO - 2016-06-07 11:33:23 --> Language Class Initialized
INFO - 2016-06-07 11:33:23 --> Loader Class Initialized
INFO - 2016-06-07 11:33:23 --> Helper loaded: form_helper
INFO - 2016-06-07 11:33:23 --> Database Driver Class Initialized
INFO - 2016-06-07 11:33:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:33:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:33:23 --> Email Class Initialized
INFO - 2016-06-07 11:33:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:33:23 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:33:23 --> Helper loaded: language_helper
INFO - 2016-06-07 11:33:23 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:33:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:23 --> Model Class Initialized
INFO - 2016-06-07 11:33:23 --> Helper loaded: date_helper
INFO - 2016-06-07 11:33:23 --> Controller Class Initialized
INFO - 2016-06-07 11:33:23 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:33:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:33:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:33:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:33:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:33:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 11:33:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:23 --> Form Validation Class Initialized
DEBUG - 2016-06-07 11:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:33:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-07 11:33:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-07 11:33:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-07 11:33:23 --> Final output sent to browser
DEBUG - 2016-06-07 11:33:23 --> Total execution time: 0.0621
INFO - 2016-06-07 11:34:08 --> Config Class Initialized
INFO - 2016-06-07 11:34:08 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:34:08 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:34:08 --> Utf8 Class Initialized
INFO - 2016-06-07 11:34:08 --> URI Class Initialized
INFO - 2016-06-07 11:34:08 --> Router Class Initialized
INFO - 2016-06-07 11:34:08 --> Output Class Initialized
INFO - 2016-06-07 11:34:08 --> Security Class Initialized
DEBUG - 2016-06-07 11:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:34:08 --> Input Class Initialized
INFO - 2016-06-07 11:34:08 --> Language Class Initialized
INFO - 2016-06-07 11:34:08 --> Loader Class Initialized
INFO - 2016-06-07 11:34:08 --> Helper loaded: form_helper
INFO - 2016-06-07 11:34:08 --> Database Driver Class Initialized
INFO - 2016-06-07 11:34:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:34:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:34:08 --> Email Class Initialized
INFO - 2016-06-07 11:34:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:34:08 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:34:08 --> Helper loaded: language_helper
INFO - 2016-06-07 11:34:08 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:09 --> Model Class Initialized
INFO - 2016-06-07 11:34:09 --> Helper loaded: date_helper
INFO - 2016-06-07 11:34:09 --> Controller Class Initialized
INFO - 2016-06-07 11:34:09 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:34:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:34:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:34:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:34:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:34:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:34:09 --> Model Class Initialized
INFO - 2016-06-07 11:34:09 --> Form Validation Class Initialized
INFO - 2016-06-07 11:34:10 --> Config Class Initialized
INFO - 2016-06-07 11:34:10 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:34:10 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:34:10 --> Utf8 Class Initialized
INFO - 2016-06-07 11:34:10 --> URI Class Initialized
INFO - 2016-06-07 11:34:10 --> Router Class Initialized
INFO - 2016-06-07 11:34:10 --> Output Class Initialized
INFO - 2016-06-07 11:34:10 --> Security Class Initialized
DEBUG - 2016-06-07 11:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:34:10 --> Input Class Initialized
INFO - 2016-06-07 11:34:10 --> Language Class Initialized
INFO - 2016-06-07 11:34:10 --> Loader Class Initialized
INFO - 2016-06-07 11:34:10 --> Helper loaded: form_helper
INFO - 2016-06-07 11:34:10 --> Database Driver Class Initialized
INFO - 2016-06-07 11:34:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:34:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:34:10 --> Email Class Initialized
INFO - 2016-06-07 11:34:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:34:10 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:34:10 --> Helper loaded: language_helper
INFO - 2016-06-07 11:34:10 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:34:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:10 --> Model Class Initialized
INFO - 2016-06-07 11:34:10 --> Helper loaded: date_helper
INFO - 2016-06-07 11:34:10 --> Controller Class Initialized
INFO - 2016-06-07 11:34:10 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:34:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:34:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:34:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:34:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:34:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 11:34:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:10 --> Form Validation Class Initialized
DEBUG - 2016-06-07 11:34:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-07 11:34:10 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-07 11:34:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-07 11:34:10 --> Final output sent to browser
DEBUG - 2016-06-07 11:34:10 --> Total execution time: 0.0263
INFO - 2016-06-07 11:34:30 --> Config Class Initialized
INFO - 2016-06-07 11:34:30 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:34:30 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:34:30 --> Utf8 Class Initialized
INFO - 2016-06-07 11:34:30 --> URI Class Initialized
INFO - 2016-06-07 11:34:30 --> Router Class Initialized
INFO - 2016-06-07 11:34:30 --> Output Class Initialized
INFO - 2016-06-07 11:34:30 --> Security Class Initialized
DEBUG - 2016-06-07 11:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:34:30 --> Input Class Initialized
INFO - 2016-06-07 11:34:30 --> Language Class Initialized
INFO - 2016-06-07 11:34:30 --> Loader Class Initialized
INFO - 2016-06-07 11:34:30 --> Helper loaded: form_helper
INFO - 2016-06-07 11:34:30 --> Database Driver Class Initialized
INFO - 2016-06-07 11:34:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:34:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:34:30 --> Email Class Initialized
INFO - 2016-06-07 11:34:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:34:30 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:34:30 --> Helper loaded: language_helper
INFO - 2016-06-07 11:34:30 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:30 --> Model Class Initialized
INFO - 2016-06-07 11:34:30 --> Helper loaded: date_helper
INFO - 2016-06-07 11:34:30 --> Controller Class Initialized
INFO - 2016-06-07 11:34:30 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:34:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:34:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:34:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:34:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:34:30 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 11:34:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:30 --> Form Validation Class Initialized
DEBUG - 2016-06-07 11:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:34 --> Config Class Initialized
INFO - 2016-06-07 11:34:34 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:34:34 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:34:34 --> Utf8 Class Initialized
INFO - 2016-06-07 11:34:34 --> URI Class Initialized
DEBUG - 2016-06-07 11:34:34 --> No URI present. Default controller set.
INFO - 2016-06-07 11:34:34 --> Router Class Initialized
INFO - 2016-06-07 11:34:34 --> Output Class Initialized
INFO - 2016-06-07 11:34:34 --> Security Class Initialized
DEBUG - 2016-06-07 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:34:34 --> Input Class Initialized
INFO - 2016-06-07 11:34:34 --> Language Class Initialized
INFO - 2016-06-07 11:34:34 --> Loader Class Initialized
INFO - 2016-06-07 11:34:34 --> Helper loaded: form_helper
INFO - 2016-06-07 11:34:34 --> Database Driver Class Initialized
INFO - 2016-06-07 11:34:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:34:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:34:34 --> Email Class Initialized
INFO - 2016-06-07 11:34:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:34:34 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:34:34 --> Helper loaded: language_helper
INFO - 2016-06-07 11:34:34 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:34 --> Model Class Initialized
INFO - 2016-06-07 11:34:34 --> Helper loaded: date_helper
INFO - 2016-06-07 11:34:34 --> Controller Class Initialized
INFO - 2016-06-07 11:34:34 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:34:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:34:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:34:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:34:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:34:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:34:35 --> Config Class Initialized
INFO - 2016-06-07 11:34:35 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:34:35 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:34:35 --> Utf8 Class Initialized
INFO - 2016-06-07 11:34:35 --> URI Class Initialized
INFO - 2016-06-07 11:34:35 --> Router Class Initialized
INFO - 2016-06-07 11:34:35 --> Output Class Initialized
INFO - 2016-06-07 11:34:35 --> Security Class Initialized
DEBUG - 2016-06-07 11:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:34:35 --> Input Class Initialized
INFO - 2016-06-07 11:34:35 --> Language Class Initialized
INFO - 2016-06-07 11:34:35 --> Loader Class Initialized
INFO - 2016-06-07 11:34:35 --> Helper loaded: form_helper
INFO - 2016-06-07 11:34:35 --> Database Driver Class Initialized
INFO - 2016-06-07 11:34:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:34:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:34:35 --> Email Class Initialized
INFO - 2016-06-07 11:34:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:34:35 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:34:35 --> Helper loaded: language_helper
INFO - 2016-06-07 11:34:35 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:35 --> Model Class Initialized
INFO - 2016-06-07 11:34:35 --> Helper loaded: date_helper
INFO - 2016-06-07 11:34:35 --> Controller Class Initialized
INFO - 2016-06-07 11:34:35 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:34:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:34:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:34:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:34:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:34:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:34:35 --> Model Class Initialized
INFO - 2016-06-07 11:34:35 --> Form Validation Class Initialized
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:34:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:34:35 --> Final output sent to browser
DEBUG - 2016-06-07 11:34:35 --> Total execution time: 0.0269
INFO - 2016-06-07 11:34:40 --> Config Class Initialized
INFO - 2016-06-07 11:34:40 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:34:40 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:34:40 --> Utf8 Class Initialized
INFO - 2016-06-07 11:34:40 --> URI Class Initialized
INFO - 2016-06-07 11:34:40 --> Router Class Initialized
INFO - 2016-06-07 11:34:40 --> Output Class Initialized
INFO - 2016-06-07 11:34:40 --> Security Class Initialized
DEBUG - 2016-06-07 11:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:34:40 --> Input Class Initialized
INFO - 2016-06-07 11:34:40 --> Language Class Initialized
INFO - 2016-06-07 11:34:40 --> Loader Class Initialized
INFO - 2016-06-07 11:34:40 --> Helper loaded: form_helper
INFO - 2016-06-07 11:34:40 --> Database Driver Class Initialized
INFO - 2016-06-07 11:34:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:34:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:34:40 --> Email Class Initialized
INFO - 2016-06-07 11:34:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:34:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:34:40 --> Helper loaded: language_helper
INFO - 2016-06-07 11:34:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:40 --> Model Class Initialized
INFO - 2016-06-07 11:34:40 --> Helper loaded: date_helper
INFO - 2016-06-07 11:34:40 --> Controller Class Initialized
INFO - 2016-06-07 11:34:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:34:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:34:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:34:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:34:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:34:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:34:40 --> Model Class Initialized
INFO - 2016-06-07 11:34:40 --> Form Validation Class Initialized
INFO - 2016-06-07 11:34:40 --> Final output sent to browser
DEBUG - 2016-06-07 11:34:40 --> Total execution time: 0.0481
INFO - 2016-06-07 11:34:54 --> Config Class Initialized
INFO - 2016-06-07 11:34:54 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:34:54 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:34:54 --> Utf8 Class Initialized
INFO - 2016-06-07 11:34:54 --> URI Class Initialized
INFO - 2016-06-07 11:34:54 --> Router Class Initialized
INFO - 2016-06-07 11:34:54 --> Output Class Initialized
INFO - 2016-06-07 11:34:54 --> Security Class Initialized
DEBUG - 2016-06-07 11:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:34:54 --> Input Class Initialized
INFO - 2016-06-07 11:34:54 --> Language Class Initialized
INFO - 2016-06-07 11:34:54 --> Loader Class Initialized
INFO - 2016-06-07 11:34:54 --> Helper loaded: form_helper
INFO - 2016-06-07 11:34:54 --> Database Driver Class Initialized
INFO - 2016-06-07 11:34:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:34:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:34:54 --> Email Class Initialized
INFO - 2016-06-07 11:34:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:34:54 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:34:54 --> Helper loaded: language_helper
INFO - 2016-06-07 11:34:54 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:34:54 --> Model Class Initialized
INFO - 2016-06-07 11:34:54 --> Helper loaded: date_helper
INFO - 2016-06-07 11:34:54 --> Controller Class Initialized
INFO - 2016-06-07 11:34:54 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:34:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:34:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:34:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:34:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:34:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:34:54 --> Model Class Initialized
INFO - 2016-06-07 11:34:54 --> Form Validation Class Initialized
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 11:34:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 11:34:54 --> Final output sent to browser
DEBUG - 2016-06-07 11:34:54 --> Total execution time: 0.0541
INFO - 2016-06-07 11:35:02 --> Config Class Initialized
INFO - 2016-06-07 11:35:02 --> Hooks Class Initialized
DEBUG - 2016-06-07 11:35:02 --> UTF-8 Support Enabled
INFO - 2016-06-07 11:35:02 --> Utf8 Class Initialized
INFO - 2016-06-07 11:35:02 --> URI Class Initialized
INFO - 2016-06-07 11:35:02 --> Router Class Initialized
INFO - 2016-06-07 11:35:02 --> Output Class Initialized
INFO - 2016-06-07 11:35:02 --> Security Class Initialized
DEBUG - 2016-06-07 11:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 11:35:02 --> Input Class Initialized
INFO - 2016-06-07 11:35:02 --> Language Class Initialized
INFO - 2016-06-07 11:35:02 --> Loader Class Initialized
INFO - 2016-06-07 11:35:02 --> Helper loaded: form_helper
INFO - 2016-06-07 11:35:02 --> Database Driver Class Initialized
INFO - 2016-06-07 11:35:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 11:35:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 11:35:02 --> Email Class Initialized
INFO - 2016-06-07 11:35:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 11:35:02 --> Helper loaded: cookie_helper
INFO - 2016-06-07 11:35:02 --> Helper loaded: language_helper
INFO - 2016-06-07 11:35:02 --> Helper loaded: url_helper
DEBUG - 2016-06-07 11:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 11:35:02 --> Model Class Initialized
INFO - 2016-06-07 11:35:02 --> Helper loaded: date_helper
INFO - 2016-06-07 11:35:02 --> Controller Class Initialized
INFO - 2016-06-07 11:35:02 --> Helper loaded: languages_helper
INFO - 2016-06-07 11:35:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 11:35:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 11:35:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 11:35:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 11:35:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 11:35:02 --> Model Class Initialized
INFO - 2016-06-07 11:35:02 --> Form Validation Class Initialized
INFO - 2016-06-07 11:35:02 --> Final output sent to browser
DEBUG - 2016-06-07 11:35:02 --> Total execution time: 0.0198
INFO - 2016-06-07 12:40:29 --> Config Class Initialized
INFO - 2016-06-07 12:40:29 --> Hooks Class Initialized
DEBUG - 2016-06-07 12:40:29 --> UTF-8 Support Enabled
INFO - 2016-06-07 12:40:29 --> Utf8 Class Initialized
INFO - 2016-06-07 12:40:29 --> URI Class Initialized
INFO - 2016-06-07 12:40:29 --> Router Class Initialized
INFO - 2016-06-07 12:40:29 --> Output Class Initialized
INFO - 2016-06-07 12:40:29 --> Security Class Initialized
DEBUG - 2016-06-07 12:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 12:40:29 --> Input Class Initialized
INFO - 2016-06-07 12:40:29 --> Language Class Initialized
INFO - 2016-06-07 12:40:29 --> Loader Class Initialized
INFO - 2016-06-07 12:40:29 --> Helper loaded: form_helper
INFO - 2016-06-07 12:40:29 --> Database Driver Class Initialized
INFO - 2016-06-07 12:40:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 12:40:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 12:40:29 --> Email Class Initialized
INFO - 2016-06-07 12:40:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 12:40:29 --> Helper loaded: cookie_helper
INFO - 2016-06-07 12:40:29 --> Helper loaded: language_helper
INFO - 2016-06-07 12:40:29 --> Helper loaded: url_helper
DEBUG - 2016-06-07 12:40:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 12:40:29 --> Model Class Initialized
INFO - 2016-06-07 12:40:29 --> Helper loaded: date_helper
INFO - 2016-06-07 12:40:29 --> Controller Class Initialized
INFO - 2016-06-07 12:40:29 --> Helper loaded: languages_helper
INFO - 2016-06-07 12:40:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 12:40:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 12:40:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 12:40:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 12:40:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 12:40:29 --> Model Class Initialized
INFO - 2016-06-07 12:40:29 --> Form Validation Class Initialized
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 12:40:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 12:40:29 --> Final output sent to browser
DEBUG - 2016-06-07 12:40:29 --> Total execution time: 0.0958
INFO - 2016-06-07 12:40:35 --> Config Class Initialized
INFO - 2016-06-07 12:40:35 --> Hooks Class Initialized
DEBUG - 2016-06-07 12:40:35 --> UTF-8 Support Enabled
INFO - 2016-06-07 12:40:35 --> Utf8 Class Initialized
INFO - 2016-06-07 12:40:35 --> URI Class Initialized
INFO - 2016-06-07 12:40:35 --> Router Class Initialized
INFO - 2016-06-07 12:40:35 --> Output Class Initialized
INFO - 2016-06-07 12:40:35 --> Security Class Initialized
DEBUG - 2016-06-07 12:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 12:40:35 --> Input Class Initialized
INFO - 2016-06-07 12:40:35 --> Language Class Initialized
INFO - 2016-06-07 12:40:35 --> Loader Class Initialized
INFO - 2016-06-07 12:40:35 --> Helper loaded: form_helper
INFO - 2016-06-07 12:40:35 --> Database Driver Class Initialized
INFO - 2016-06-07 12:40:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 12:40:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 12:40:35 --> Email Class Initialized
INFO - 2016-06-07 12:40:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 12:40:35 --> Helper loaded: cookie_helper
INFO - 2016-06-07 12:40:35 --> Helper loaded: language_helper
INFO - 2016-06-07 12:40:35 --> Helper loaded: url_helper
DEBUG - 2016-06-07 12:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 12:40:35 --> Model Class Initialized
INFO - 2016-06-07 12:40:35 --> Helper loaded: date_helper
INFO - 2016-06-07 12:40:35 --> Controller Class Initialized
INFO - 2016-06-07 12:40:35 --> Helper loaded: languages_helper
INFO - 2016-06-07 12:40:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 12:40:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 12:40:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 12:40:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 12:40:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 12:40:35 --> Model Class Initialized
INFO - 2016-06-07 12:40:35 --> Form Validation Class Initialized
INFO - 2016-06-07 12:40:35 --> Final output sent to browser
DEBUG - 2016-06-07 12:40:35 --> Total execution time: 0.0377
INFO - 2016-06-07 12:41:23 --> Config Class Initialized
INFO - 2016-06-07 12:41:23 --> Hooks Class Initialized
DEBUG - 2016-06-07 12:41:23 --> UTF-8 Support Enabled
INFO - 2016-06-07 12:41:23 --> Utf8 Class Initialized
INFO - 2016-06-07 12:41:23 --> URI Class Initialized
INFO - 2016-06-07 12:41:23 --> Router Class Initialized
INFO - 2016-06-07 12:41:23 --> Output Class Initialized
INFO - 2016-06-07 12:41:23 --> Security Class Initialized
DEBUG - 2016-06-07 12:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 12:41:23 --> Input Class Initialized
INFO - 2016-06-07 12:41:23 --> Language Class Initialized
INFO - 2016-06-07 12:41:23 --> Loader Class Initialized
INFO - 2016-06-07 12:41:23 --> Helper loaded: form_helper
INFO - 2016-06-07 12:41:23 --> Database Driver Class Initialized
INFO - 2016-06-07 12:41:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 12:41:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 12:41:23 --> Email Class Initialized
INFO - 2016-06-07 12:41:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 12:41:23 --> Helper loaded: cookie_helper
INFO - 2016-06-07 12:41:23 --> Helper loaded: language_helper
INFO - 2016-06-07 12:41:23 --> Helper loaded: url_helper
DEBUG - 2016-06-07 12:41:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 12:41:23 --> Model Class Initialized
INFO - 2016-06-07 12:41:23 --> Helper loaded: date_helper
INFO - 2016-06-07 12:41:23 --> Controller Class Initialized
INFO - 2016-06-07 12:41:23 --> Helper loaded: languages_helper
INFO - 2016-06-07 12:41:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 12:41:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 12:41:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 12:41:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 12:41:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 12:41:23 --> Model Class Initialized
INFO - 2016-06-07 12:41:23 --> Form Validation Class Initialized
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 12:41:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 12:41:23 --> Final output sent to browser
DEBUG - 2016-06-07 12:41:23 --> Total execution time: 0.0524
INFO - 2016-06-07 12:41:33 --> Config Class Initialized
INFO - 2016-06-07 12:41:33 --> Hooks Class Initialized
DEBUG - 2016-06-07 12:41:33 --> UTF-8 Support Enabled
INFO - 2016-06-07 12:41:33 --> Utf8 Class Initialized
INFO - 2016-06-07 12:41:33 --> URI Class Initialized
INFO - 2016-06-07 12:41:33 --> Router Class Initialized
INFO - 2016-06-07 12:41:33 --> Output Class Initialized
INFO - 2016-06-07 12:41:33 --> Security Class Initialized
DEBUG - 2016-06-07 12:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 12:41:33 --> Input Class Initialized
INFO - 2016-06-07 12:41:33 --> Language Class Initialized
INFO - 2016-06-07 12:41:33 --> Loader Class Initialized
INFO - 2016-06-07 12:41:33 --> Helper loaded: form_helper
INFO - 2016-06-07 12:41:33 --> Database Driver Class Initialized
INFO - 2016-06-07 12:41:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 12:41:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 12:41:33 --> Email Class Initialized
INFO - 2016-06-07 12:41:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 12:41:33 --> Helper loaded: cookie_helper
INFO - 2016-06-07 12:41:33 --> Helper loaded: language_helper
INFO - 2016-06-07 12:41:33 --> Helper loaded: url_helper
DEBUG - 2016-06-07 12:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 12:41:33 --> Model Class Initialized
INFO - 2016-06-07 12:41:33 --> Helper loaded: date_helper
INFO - 2016-06-07 12:41:33 --> Controller Class Initialized
INFO - 2016-06-07 12:41:33 --> Helper loaded: languages_helper
INFO - 2016-06-07 12:41:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 12:41:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 12:41:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 12:41:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 12:41:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 12:41:33 --> Model Class Initialized
INFO - 2016-06-07 12:41:33 --> Form Validation Class Initialized
INFO - 2016-06-07 12:41:33 --> Final output sent to browser
DEBUG - 2016-06-07 12:41:33 --> Total execution time: 0.0488
INFO - 2016-06-07 12:47:01 --> Config Class Initialized
INFO - 2016-06-07 12:47:01 --> Hooks Class Initialized
DEBUG - 2016-06-07 12:47:01 --> UTF-8 Support Enabled
INFO - 2016-06-07 12:47:01 --> Utf8 Class Initialized
INFO - 2016-06-07 12:47:01 --> URI Class Initialized
INFO - 2016-06-07 12:47:01 --> Router Class Initialized
INFO - 2016-06-07 12:47:01 --> Output Class Initialized
INFO - 2016-06-07 12:47:01 --> Security Class Initialized
DEBUG - 2016-06-07 12:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 12:47:01 --> Input Class Initialized
INFO - 2016-06-07 12:47:01 --> Language Class Initialized
INFO - 2016-06-07 12:47:01 --> Loader Class Initialized
INFO - 2016-06-07 12:47:01 --> Helper loaded: form_helper
INFO - 2016-06-07 12:47:01 --> Database Driver Class Initialized
INFO - 2016-06-07 12:47:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 12:47:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 12:47:01 --> Email Class Initialized
INFO - 2016-06-07 12:47:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 12:47:01 --> Helper loaded: cookie_helper
INFO - 2016-06-07 12:47:01 --> Helper loaded: language_helper
INFO - 2016-06-07 12:47:01 --> Helper loaded: url_helper
DEBUG - 2016-06-07 12:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 12:47:01 --> Model Class Initialized
INFO - 2016-06-07 12:47:01 --> Helper loaded: date_helper
INFO - 2016-06-07 12:47:01 --> Controller Class Initialized
INFO - 2016-06-07 12:47:01 --> Helper loaded: languages_helper
INFO - 2016-06-07 12:47:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 12:47:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 12:47:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 12:47:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 12:47:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 12:47:01 --> Model Class Initialized
INFO - 2016-06-07 12:47:01 --> Form Validation Class Initialized
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 12:47:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 12:47:02 --> Final output sent to browser
DEBUG - 2016-06-07 12:47:02 --> Total execution time: 0.0883
INFO - 2016-06-07 12:47:07 --> Config Class Initialized
INFO - 2016-06-07 12:47:07 --> Hooks Class Initialized
DEBUG - 2016-06-07 12:47:07 --> UTF-8 Support Enabled
INFO - 2016-06-07 12:47:07 --> Utf8 Class Initialized
INFO - 2016-06-07 12:47:07 --> URI Class Initialized
INFO - 2016-06-07 12:47:07 --> Router Class Initialized
INFO - 2016-06-07 12:47:07 --> Output Class Initialized
INFO - 2016-06-07 12:47:07 --> Security Class Initialized
DEBUG - 2016-06-07 12:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 12:47:07 --> Input Class Initialized
INFO - 2016-06-07 12:47:07 --> Language Class Initialized
INFO - 2016-06-07 12:47:07 --> Loader Class Initialized
INFO - 2016-06-07 12:47:07 --> Helper loaded: form_helper
INFO - 2016-06-07 12:47:07 --> Database Driver Class Initialized
INFO - 2016-06-07 12:47:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 12:47:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 12:47:07 --> Email Class Initialized
INFO - 2016-06-07 12:47:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 12:47:07 --> Helper loaded: cookie_helper
INFO - 2016-06-07 12:47:07 --> Helper loaded: language_helper
INFO - 2016-06-07 12:47:07 --> Helper loaded: url_helper
DEBUG - 2016-06-07 12:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 12:47:07 --> Model Class Initialized
INFO - 2016-06-07 12:47:07 --> Helper loaded: date_helper
INFO - 2016-06-07 12:47:07 --> Controller Class Initialized
INFO - 2016-06-07 12:47:07 --> Helper loaded: languages_helper
INFO - 2016-06-07 12:47:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 12:47:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 12:47:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 12:47:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 12:47:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 12:47:07 --> Model Class Initialized
INFO - 2016-06-07 12:47:07 --> Form Validation Class Initialized
INFO - 2016-06-07 12:47:07 --> Final output sent to browser
DEBUG - 2016-06-07 12:47:07 --> Total execution time: 0.1547
INFO - 2016-06-07 13:06:27 --> Config Class Initialized
INFO - 2016-06-07 13:06:27 --> Hooks Class Initialized
DEBUG - 2016-06-07 13:06:27 --> UTF-8 Support Enabled
INFO - 2016-06-07 13:06:27 --> Utf8 Class Initialized
INFO - 2016-06-07 13:06:27 --> URI Class Initialized
INFO - 2016-06-07 13:06:27 --> Router Class Initialized
INFO - 2016-06-07 13:06:27 --> Output Class Initialized
INFO - 2016-06-07 13:06:27 --> Security Class Initialized
DEBUG - 2016-06-07 13:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 13:06:27 --> Input Class Initialized
INFO - 2016-06-07 13:06:27 --> Language Class Initialized
INFO - 2016-06-07 13:06:27 --> Loader Class Initialized
INFO - 2016-06-07 13:06:27 --> Helper loaded: form_helper
INFO - 2016-06-07 13:06:27 --> Database Driver Class Initialized
INFO - 2016-06-07 13:06:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 13:06:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 13:06:27 --> Email Class Initialized
INFO - 2016-06-07 13:06:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 13:06:27 --> Helper loaded: cookie_helper
INFO - 2016-06-07 13:06:27 --> Helper loaded: language_helper
INFO - 2016-06-07 13:06:27 --> Helper loaded: url_helper
DEBUG - 2016-06-07 13:06:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 13:06:27 --> Model Class Initialized
INFO - 2016-06-07 13:06:27 --> Helper loaded: date_helper
INFO - 2016-06-07 13:06:27 --> Controller Class Initialized
INFO - 2016-06-07 13:06:27 --> Helper loaded: languages_helper
INFO - 2016-06-07 13:06:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 13:06:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 13:06:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 13:06:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 13:06:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 13:06:27 --> Model Class Initialized
INFO - 2016-06-07 13:06:27 --> Form Validation Class Initialized
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 13:06:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 13:06:27 --> Final output sent to browser
DEBUG - 2016-06-07 13:06:27 --> Total execution time: 0.1414
INFO - 2016-06-07 13:06:43 --> Config Class Initialized
INFO - 2016-06-07 13:06:43 --> Hooks Class Initialized
DEBUG - 2016-06-07 13:06:43 --> UTF-8 Support Enabled
INFO - 2016-06-07 13:06:43 --> Utf8 Class Initialized
INFO - 2016-06-07 13:06:43 --> URI Class Initialized
INFO - 2016-06-07 13:06:43 --> Router Class Initialized
INFO - 2016-06-07 13:06:43 --> Output Class Initialized
INFO - 2016-06-07 13:06:43 --> Security Class Initialized
DEBUG - 2016-06-07 13:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 13:06:43 --> Input Class Initialized
INFO - 2016-06-07 13:06:43 --> Language Class Initialized
INFO - 2016-06-07 13:06:43 --> Loader Class Initialized
INFO - 2016-06-07 13:06:43 --> Helper loaded: form_helper
INFO - 2016-06-07 13:06:43 --> Database Driver Class Initialized
INFO - 2016-06-07 13:06:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 13:06:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 13:06:43 --> Email Class Initialized
INFO - 2016-06-07 13:06:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 13:06:43 --> Helper loaded: cookie_helper
INFO - 2016-06-07 13:06:43 --> Helper loaded: language_helper
INFO - 2016-06-07 13:06:43 --> Helper loaded: url_helper
DEBUG - 2016-06-07 13:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 13:06:43 --> Model Class Initialized
INFO - 2016-06-07 13:06:43 --> Helper loaded: date_helper
INFO - 2016-06-07 13:06:43 --> Controller Class Initialized
INFO - 2016-06-07 13:06:43 --> Helper loaded: languages_helper
INFO - 2016-06-07 13:06:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 13:06:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 13:06:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 13:06:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 13:06:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 13:06:43 --> Model Class Initialized
INFO - 2016-06-07 13:06:43 --> Form Validation Class Initialized
INFO - 2016-06-07 13:06:43 --> Final output sent to browser
DEBUG - 2016-06-07 13:06:43 --> Total execution time: 0.0561
INFO - 2016-06-07 13:07:03 --> Config Class Initialized
INFO - 2016-06-07 13:07:03 --> Hooks Class Initialized
DEBUG - 2016-06-07 13:07:03 --> UTF-8 Support Enabled
INFO - 2016-06-07 13:07:03 --> Utf8 Class Initialized
INFO - 2016-06-07 13:07:03 --> URI Class Initialized
INFO - 2016-06-07 13:07:03 --> Router Class Initialized
INFO - 2016-06-07 13:07:03 --> Output Class Initialized
INFO - 2016-06-07 13:07:03 --> Security Class Initialized
DEBUG - 2016-06-07 13:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 13:07:03 --> Input Class Initialized
INFO - 2016-06-07 13:07:03 --> Language Class Initialized
INFO - 2016-06-07 13:07:03 --> Loader Class Initialized
INFO - 2016-06-07 13:07:03 --> Helper loaded: form_helper
INFO - 2016-06-07 13:07:03 --> Database Driver Class Initialized
INFO - 2016-06-07 13:07:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 13:07:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 13:07:03 --> Email Class Initialized
INFO - 2016-06-07 13:07:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 13:07:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 13:07:03 --> Helper loaded: language_helper
INFO - 2016-06-07 13:07:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 13:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 13:07:03 --> Model Class Initialized
INFO - 2016-06-07 13:07:03 --> Helper loaded: date_helper
INFO - 2016-06-07 13:07:03 --> Controller Class Initialized
INFO - 2016-06-07 13:07:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 13:07:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 13:07:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 13:07:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 13:07:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 13:07:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 13:07:03 --> Model Class Initialized
INFO - 2016-06-07 13:07:03 --> Form Validation Class Initialized
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 13:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 13:07:04 --> Final output sent to browser
DEBUG - 2016-06-07 13:07:04 --> Total execution time: 0.0782
INFO - 2016-06-07 13:07:14 --> Config Class Initialized
INFO - 2016-06-07 13:07:14 --> Hooks Class Initialized
DEBUG - 2016-06-07 13:07:14 --> UTF-8 Support Enabled
INFO - 2016-06-07 13:07:14 --> Utf8 Class Initialized
INFO - 2016-06-07 13:07:14 --> URI Class Initialized
INFO - 2016-06-07 13:07:14 --> Router Class Initialized
INFO - 2016-06-07 13:07:14 --> Output Class Initialized
INFO - 2016-06-07 13:07:14 --> Security Class Initialized
DEBUG - 2016-06-07 13:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 13:07:14 --> Input Class Initialized
INFO - 2016-06-07 13:07:14 --> Language Class Initialized
INFO - 2016-06-07 13:07:14 --> Loader Class Initialized
INFO - 2016-06-07 13:07:14 --> Helper loaded: form_helper
INFO - 2016-06-07 13:07:14 --> Database Driver Class Initialized
INFO - 2016-06-07 13:07:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 13:07:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 13:07:14 --> Email Class Initialized
INFO - 2016-06-07 13:07:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 13:07:14 --> Helper loaded: cookie_helper
INFO - 2016-06-07 13:07:14 --> Helper loaded: language_helper
INFO - 2016-06-07 13:07:14 --> Helper loaded: url_helper
DEBUG - 2016-06-07 13:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 13:07:14 --> Model Class Initialized
INFO - 2016-06-07 13:07:14 --> Helper loaded: date_helper
INFO - 2016-06-07 13:07:14 --> Controller Class Initialized
INFO - 2016-06-07 13:07:14 --> Helper loaded: languages_helper
INFO - 2016-06-07 13:07:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 13:07:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 13:07:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 13:07:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 13:07:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 13:07:14 --> Model Class Initialized
INFO - 2016-06-07 13:07:14 --> Form Validation Class Initialized
INFO - 2016-06-07 13:07:14 --> Final output sent to browser
DEBUG - 2016-06-07 13:07:14 --> Total execution time: 0.0758
INFO - 2016-06-07 14:11:37 --> Config Class Initialized
INFO - 2016-06-07 14:11:37 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:11:37 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:11:37 --> Utf8 Class Initialized
INFO - 2016-06-07 14:11:37 --> URI Class Initialized
INFO - 2016-06-07 14:11:37 --> Router Class Initialized
INFO - 2016-06-07 14:11:37 --> Output Class Initialized
INFO - 2016-06-07 14:11:37 --> Security Class Initialized
DEBUG - 2016-06-07 14:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:11:37 --> Input Class Initialized
INFO - 2016-06-07 14:11:37 --> Language Class Initialized
INFO - 2016-06-07 14:11:37 --> Loader Class Initialized
INFO - 2016-06-07 14:11:37 --> Helper loaded: form_helper
INFO - 2016-06-07 14:11:37 --> Database Driver Class Initialized
INFO - 2016-06-07 14:11:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:11:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:11:37 --> Email Class Initialized
INFO - 2016-06-07 14:11:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:11:37 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:11:37 --> Helper loaded: language_helper
INFO - 2016-06-07 14:11:37 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:11:37 --> Model Class Initialized
INFO - 2016-06-07 14:11:37 --> Helper loaded: date_helper
INFO - 2016-06-07 14:11:37 --> Controller Class Initialized
INFO - 2016-06-07 14:11:37 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:11:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:11:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:11:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:11:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:11:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:11:37 --> Model Class Initialized
INFO - 2016-06-07 14:11:37 --> Form Validation Class Initialized
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:11:37 --> Final output sent to browser
DEBUG - 2016-06-07 14:11:37 --> Total execution time: 0.0750
INFO - 2016-06-07 14:11:46 --> Config Class Initialized
INFO - 2016-06-07 14:11:46 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:11:46 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:11:46 --> Utf8 Class Initialized
INFO - 2016-06-07 14:11:46 --> URI Class Initialized
INFO - 2016-06-07 14:11:46 --> Router Class Initialized
INFO - 2016-06-07 14:11:46 --> Output Class Initialized
INFO - 2016-06-07 14:11:46 --> Security Class Initialized
DEBUG - 2016-06-07 14:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:11:46 --> Input Class Initialized
INFO - 2016-06-07 14:11:46 --> Language Class Initialized
INFO - 2016-06-07 14:11:46 --> Loader Class Initialized
INFO - 2016-06-07 14:11:46 --> Helper loaded: form_helper
INFO - 2016-06-07 14:11:46 --> Database Driver Class Initialized
INFO - 2016-06-07 14:11:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:11:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:11:46 --> Email Class Initialized
INFO - 2016-06-07 14:11:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:11:46 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:11:46 --> Helper loaded: language_helper
INFO - 2016-06-07 14:11:46 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:11:46 --> Model Class Initialized
INFO - 2016-06-07 14:11:46 --> Helper loaded: date_helper
INFO - 2016-06-07 14:11:46 --> Controller Class Initialized
INFO - 2016-06-07 14:11:46 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:11:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:11:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:11:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:11:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:11:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:11:46 --> Model Class Initialized
INFO - 2016-06-07 14:11:46 --> Form Validation Class Initialized
INFO - 2016-06-07 14:11:46 --> Final output sent to browser
DEBUG - 2016-06-07 14:11:46 --> Total execution time: 0.0450
INFO - 2016-06-07 14:29:05 --> Config Class Initialized
INFO - 2016-06-07 14:29:05 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:29:05 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:29:05 --> Utf8 Class Initialized
INFO - 2016-06-07 14:29:05 --> URI Class Initialized
INFO - 2016-06-07 14:29:05 --> Router Class Initialized
INFO - 2016-06-07 14:29:05 --> Output Class Initialized
INFO - 2016-06-07 14:29:05 --> Security Class Initialized
DEBUG - 2016-06-07 14:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:29:05 --> Input Class Initialized
INFO - 2016-06-07 14:29:05 --> Language Class Initialized
INFO - 2016-06-07 14:29:05 --> Loader Class Initialized
INFO - 2016-06-07 14:29:05 --> Helper loaded: form_helper
INFO - 2016-06-07 14:29:05 --> Database Driver Class Initialized
INFO - 2016-06-07 14:29:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:29:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:29:05 --> Email Class Initialized
INFO - 2016-06-07 14:29:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:29:05 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:29:05 --> Helper loaded: language_helper
INFO - 2016-06-07 14:29:05 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:29:05 --> Model Class Initialized
INFO - 2016-06-07 14:29:05 --> Helper loaded: date_helper
INFO - 2016-06-07 14:29:05 --> Controller Class Initialized
INFO - 2016-06-07 14:29:05 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:29:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:29:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:29:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:29:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:29:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:29:05 --> Model Class Initialized
INFO - 2016-06-07 14:29:05 --> Form Validation Class Initialized
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:29:05 --> Final output sent to browser
DEBUG - 2016-06-07 14:29:05 --> Total execution time: 0.0427
INFO - 2016-06-07 14:29:15 --> Config Class Initialized
INFO - 2016-06-07 14:29:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:29:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:29:15 --> Utf8 Class Initialized
INFO - 2016-06-07 14:29:15 --> URI Class Initialized
INFO - 2016-06-07 14:29:15 --> Router Class Initialized
INFO - 2016-06-07 14:29:15 --> Output Class Initialized
INFO - 2016-06-07 14:29:15 --> Security Class Initialized
DEBUG - 2016-06-07 14:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:29:15 --> Input Class Initialized
INFO - 2016-06-07 14:29:15 --> Language Class Initialized
INFO - 2016-06-07 14:29:15 --> Loader Class Initialized
INFO - 2016-06-07 14:29:15 --> Helper loaded: form_helper
INFO - 2016-06-07 14:29:15 --> Database Driver Class Initialized
INFO - 2016-06-07 14:29:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:29:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:29:15 --> Email Class Initialized
INFO - 2016-06-07 14:29:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:29:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:29:15 --> Helper loaded: language_helper
INFO - 2016-06-07 14:29:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:29:15 --> Model Class Initialized
INFO - 2016-06-07 14:29:15 --> Helper loaded: date_helper
INFO - 2016-06-07 14:29:15 --> Controller Class Initialized
INFO - 2016-06-07 14:29:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:29:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:29:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:29:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:29:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:29:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:29:15 --> Model Class Initialized
INFO - 2016-06-07 14:29:15 --> Form Validation Class Initialized
INFO - 2016-06-07 14:29:15 --> Final output sent to browser
DEBUG - 2016-06-07 14:29:15 --> Total execution time: 0.0191
INFO - 2016-06-07 14:31:09 --> Config Class Initialized
INFO - 2016-06-07 14:31:09 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:31:09 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:31:09 --> Utf8 Class Initialized
INFO - 2016-06-07 14:31:09 --> URI Class Initialized
INFO - 2016-06-07 14:31:09 --> Router Class Initialized
INFO - 2016-06-07 14:31:09 --> Output Class Initialized
INFO - 2016-06-07 14:31:09 --> Security Class Initialized
DEBUG - 2016-06-07 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:31:09 --> Input Class Initialized
INFO - 2016-06-07 14:31:09 --> Language Class Initialized
INFO - 2016-06-07 14:31:09 --> Loader Class Initialized
INFO - 2016-06-07 14:31:09 --> Helper loaded: form_helper
INFO - 2016-06-07 14:31:09 --> Database Driver Class Initialized
INFO - 2016-06-07 14:31:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:31:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:31:09 --> Email Class Initialized
INFO - 2016-06-07 14:31:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:31:09 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:31:09 --> Helper loaded: language_helper
INFO - 2016-06-07 14:31:09 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:31:09 --> Model Class Initialized
INFO - 2016-06-07 14:31:09 --> Helper loaded: date_helper
INFO - 2016-06-07 14:31:09 --> Controller Class Initialized
INFO - 2016-06-07 14:31:09 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:31:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:31:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:31:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:31:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:31:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:31:09 --> Model Class Initialized
INFO - 2016-06-07 14:31:09 --> Form Validation Class Initialized
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:31:09 --> Final output sent to browser
DEBUG - 2016-06-07 14:31:09 --> Total execution time: 0.0647
INFO - 2016-06-07 14:31:21 --> Config Class Initialized
INFO - 2016-06-07 14:31:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:31:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:31:21 --> Utf8 Class Initialized
INFO - 2016-06-07 14:31:21 --> URI Class Initialized
INFO - 2016-06-07 14:31:21 --> Router Class Initialized
INFO - 2016-06-07 14:31:21 --> Output Class Initialized
INFO - 2016-06-07 14:31:21 --> Security Class Initialized
DEBUG - 2016-06-07 14:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:31:21 --> Input Class Initialized
INFO - 2016-06-07 14:31:21 --> Language Class Initialized
INFO - 2016-06-07 14:31:21 --> Loader Class Initialized
INFO - 2016-06-07 14:31:21 --> Helper loaded: form_helper
INFO - 2016-06-07 14:31:21 --> Database Driver Class Initialized
INFO - 2016-06-07 14:31:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:31:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:31:21 --> Email Class Initialized
INFO - 2016-06-07 14:31:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:31:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:31:21 --> Helper loaded: language_helper
INFO - 2016-06-07 14:31:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:31:21 --> Model Class Initialized
INFO - 2016-06-07 14:31:21 --> Helper loaded: date_helper
INFO - 2016-06-07 14:31:21 --> Controller Class Initialized
INFO - 2016-06-07 14:31:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:31:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:31:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:31:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:31:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:31:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:31:21 --> Model Class Initialized
INFO - 2016-06-07 14:31:21 --> Form Validation Class Initialized
INFO - 2016-06-07 14:31:21 --> Final output sent to browser
DEBUG - 2016-06-07 14:31:21 --> Total execution time: 0.2353
INFO - 2016-06-07 14:32:38 --> Config Class Initialized
INFO - 2016-06-07 14:32:38 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:32:38 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:32:38 --> Utf8 Class Initialized
INFO - 2016-06-07 14:32:38 --> URI Class Initialized
INFO - 2016-06-07 14:32:38 --> Router Class Initialized
INFO - 2016-06-07 14:32:38 --> Output Class Initialized
INFO - 2016-06-07 14:32:38 --> Security Class Initialized
DEBUG - 2016-06-07 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:32:38 --> Input Class Initialized
INFO - 2016-06-07 14:32:38 --> Language Class Initialized
INFO - 2016-06-07 14:32:38 --> Loader Class Initialized
INFO - 2016-06-07 14:32:38 --> Helper loaded: form_helper
INFO - 2016-06-07 14:32:38 --> Database Driver Class Initialized
INFO - 2016-06-07 14:32:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:32:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:32:38 --> Email Class Initialized
INFO - 2016-06-07 14:32:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:32:38 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:32:38 --> Helper loaded: language_helper
INFO - 2016-06-07 14:32:38 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:32:38 --> Model Class Initialized
INFO - 2016-06-07 14:32:38 --> Helper loaded: date_helper
INFO - 2016-06-07 14:32:38 --> Controller Class Initialized
INFO - 2016-06-07 14:32:38 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:32:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:32:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:32:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:32:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:32:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:32:38 --> Model Class Initialized
INFO - 2016-06-07 14:32:38 --> Form Validation Class Initialized
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:32:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:32:38 --> Final output sent to browser
DEBUG - 2016-06-07 14:32:38 --> Total execution time: 0.0945
INFO - 2016-06-07 14:32:44 --> Config Class Initialized
INFO - 2016-06-07 14:32:44 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:32:44 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:32:44 --> Utf8 Class Initialized
INFO - 2016-06-07 14:32:44 --> URI Class Initialized
INFO - 2016-06-07 14:32:44 --> Router Class Initialized
INFO - 2016-06-07 14:32:44 --> Output Class Initialized
INFO - 2016-06-07 14:32:44 --> Security Class Initialized
DEBUG - 2016-06-07 14:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:32:44 --> Input Class Initialized
INFO - 2016-06-07 14:32:44 --> Language Class Initialized
INFO - 2016-06-07 14:32:44 --> Loader Class Initialized
INFO - 2016-06-07 14:32:44 --> Helper loaded: form_helper
INFO - 2016-06-07 14:32:44 --> Database Driver Class Initialized
INFO - 2016-06-07 14:32:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:32:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:32:44 --> Email Class Initialized
INFO - 2016-06-07 14:32:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:32:44 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:32:44 --> Helper loaded: language_helper
INFO - 2016-06-07 14:32:44 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:32:44 --> Model Class Initialized
INFO - 2016-06-07 14:32:44 --> Helper loaded: date_helper
INFO - 2016-06-07 14:32:44 --> Controller Class Initialized
INFO - 2016-06-07 14:32:44 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:32:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:32:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:32:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:32:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:32:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:32:44 --> Model Class Initialized
INFO - 2016-06-07 14:32:44 --> Form Validation Class Initialized
INFO - 2016-06-07 14:32:44 --> Final output sent to browser
DEBUG - 2016-06-07 14:32:44 --> Total execution time: 0.0268
INFO - 2016-06-07 14:33:41 --> Config Class Initialized
INFO - 2016-06-07 14:33:41 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:33:41 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:33:41 --> Utf8 Class Initialized
INFO - 2016-06-07 14:33:41 --> URI Class Initialized
INFO - 2016-06-07 14:33:41 --> Router Class Initialized
INFO - 2016-06-07 14:33:41 --> Output Class Initialized
INFO - 2016-06-07 14:33:41 --> Security Class Initialized
DEBUG - 2016-06-07 14:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:33:41 --> Input Class Initialized
INFO - 2016-06-07 14:33:41 --> Language Class Initialized
INFO - 2016-06-07 14:33:41 --> Loader Class Initialized
INFO - 2016-06-07 14:33:41 --> Helper loaded: form_helper
INFO - 2016-06-07 14:33:41 --> Database Driver Class Initialized
INFO - 2016-06-07 14:33:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:33:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:33:41 --> Email Class Initialized
INFO - 2016-06-07 14:33:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:33:41 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:33:41 --> Helper loaded: language_helper
INFO - 2016-06-07 14:33:41 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:33:41 --> Model Class Initialized
INFO - 2016-06-07 14:33:41 --> Helper loaded: date_helper
INFO - 2016-06-07 14:33:41 --> Controller Class Initialized
INFO - 2016-06-07 14:33:41 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:33:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:33:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:33:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:33:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:33:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:33:41 --> Model Class Initialized
INFO - 2016-06-07 14:33:41 --> Form Validation Class Initialized
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:33:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:33:41 --> Final output sent to browser
DEBUG - 2016-06-07 14:33:41 --> Total execution time: 0.0849
INFO - 2016-06-07 14:33:52 --> Config Class Initialized
INFO - 2016-06-07 14:33:52 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:33:52 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:33:52 --> Utf8 Class Initialized
INFO - 2016-06-07 14:33:52 --> URI Class Initialized
INFO - 2016-06-07 14:33:52 --> Router Class Initialized
INFO - 2016-06-07 14:33:52 --> Output Class Initialized
INFO - 2016-06-07 14:33:52 --> Security Class Initialized
DEBUG - 2016-06-07 14:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:33:52 --> Input Class Initialized
INFO - 2016-06-07 14:33:52 --> Language Class Initialized
INFO - 2016-06-07 14:33:52 --> Loader Class Initialized
INFO - 2016-06-07 14:33:52 --> Helper loaded: form_helper
INFO - 2016-06-07 14:33:52 --> Database Driver Class Initialized
INFO - 2016-06-07 14:33:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:33:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:33:52 --> Email Class Initialized
INFO - 2016-06-07 14:33:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:33:52 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:33:52 --> Helper loaded: language_helper
INFO - 2016-06-07 14:33:52 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:33:52 --> Model Class Initialized
INFO - 2016-06-07 14:33:52 --> Helper loaded: date_helper
INFO - 2016-06-07 14:33:52 --> Controller Class Initialized
INFO - 2016-06-07 14:33:52 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:33:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:33:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:33:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:33:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:33:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:33:52 --> Model Class Initialized
INFO - 2016-06-07 14:33:52 --> Form Validation Class Initialized
INFO - 2016-06-07 14:33:52 --> Final output sent to browser
DEBUG - 2016-06-07 14:33:52 --> Total execution time: 0.0416
INFO - 2016-06-07 14:38:59 --> Config Class Initialized
INFO - 2016-06-07 14:38:59 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:38:59 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:38:59 --> Utf8 Class Initialized
INFO - 2016-06-07 14:38:59 --> URI Class Initialized
INFO - 2016-06-07 14:38:59 --> Router Class Initialized
INFO - 2016-06-07 14:38:59 --> Output Class Initialized
INFO - 2016-06-07 14:38:59 --> Security Class Initialized
DEBUG - 2016-06-07 14:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:38:59 --> Input Class Initialized
INFO - 2016-06-07 14:38:59 --> Language Class Initialized
INFO - 2016-06-07 14:38:59 --> Loader Class Initialized
INFO - 2016-06-07 14:38:59 --> Helper loaded: form_helper
INFO - 2016-06-07 14:38:59 --> Database Driver Class Initialized
INFO - 2016-06-07 14:38:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:38:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:38:59 --> Email Class Initialized
INFO - 2016-06-07 14:38:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:38:59 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:38:59 --> Helper loaded: language_helper
INFO - 2016-06-07 14:38:59 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:38:59 --> Model Class Initialized
INFO - 2016-06-07 14:38:59 --> Helper loaded: date_helper
INFO - 2016-06-07 14:38:59 --> Controller Class Initialized
INFO - 2016-06-07 14:38:59 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:38:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:38:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:38:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:38:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:38:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:38:59 --> Model Class Initialized
INFO - 2016-06-07 14:38:59 --> Form Validation Class Initialized
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:38:59 --> Final output sent to browser
DEBUG - 2016-06-07 14:38:59 --> Total execution time: 0.0439
INFO - 2016-06-07 14:39:09 --> Config Class Initialized
INFO - 2016-06-07 14:39:09 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:39:09 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:39:09 --> Utf8 Class Initialized
INFO - 2016-06-07 14:39:09 --> URI Class Initialized
INFO - 2016-06-07 14:39:09 --> Router Class Initialized
INFO - 2016-06-07 14:39:09 --> Output Class Initialized
INFO - 2016-06-07 14:39:09 --> Security Class Initialized
DEBUG - 2016-06-07 14:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:39:09 --> Input Class Initialized
INFO - 2016-06-07 14:39:09 --> Language Class Initialized
INFO - 2016-06-07 14:39:09 --> Loader Class Initialized
INFO - 2016-06-07 14:39:09 --> Helper loaded: form_helper
INFO - 2016-06-07 14:39:09 --> Database Driver Class Initialized
INFO - 2016-06-07 14:39:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:39:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:39:09 --> Email Class Initialized
INFO - 2016-06-07 14:39:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:39:09 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:39:09 --> Helper loaded: language_helper
INFO - 2016-06-07 14:39:09 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:39:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:39:09 --> Model Class Initialized
INFO - 2016-06-07 14:39:09 --> Helper loaded: date_helper
INFO - 2016-06-07 14:39:09 --> Controller Class Initialized
INFO - 2016-06-07 14:39:09 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:39:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:39:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:39:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:39:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:39:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:39:09 --> Model Class Initialized
INFO - 2016-06-07 14:39:09 --> Form Validation Class Initialized
INFO - 2016-06-07 14:39:09 --> Final output sent to browser
DEBUG - 2016-06-07 14:39:09 --> Total execution time: 0.0439
INFO - 2016-06-07 14:39:31 --> Config Class Initialized
INFO - 2016-06-07 14:39:31 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:39:31 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:39:31 --> Utf8 Class Initialized
INFO - 2016-06-07 14:39:31 --> URI Class Initialized
INFO - 2016-06-07 14:39:31 --> Router Class Initialized
INFO - 2016-06-07 14:39:31 --> Output Class Initialized
INFO - 2016-06-07 14:39:31 --> Security Class Initialized
DEBUG - 2016-06-07 14:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:39:31 --> Input Class Initialized
INFO - 2016-06-07 14:39:31 --> Language Class Initialized
INFO - 2016-06-07 14:39:31 --> Loader Class Initialized
INFO - 2016-06-07 14:39:31 --> Helper loaded: form_helper
INFO - 2016-06-07 14:39:31 --> Database Driver Class Initialized
INFO - 2016-06-07 14:39:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:39:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:39:31 --> Email Class Initialized
INFO - 2016-06-07 14:39:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:39:31 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:39:31 --> Helper loaded: language_helper
INFO - 2016-06-07 14:39:31 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:39:31 --> Model Class Initialized
INFO - 2016-06-07 14:39:31 --> Helper loaded: date_helper
INFO - 2016-06-07 14:39:31 --> Controller Class Initialized
INFO - 2016-06-07 14:39:31 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:39:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:39:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:39:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:39:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:39:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:39:31 --> Model Class Initialized
INFO - 2016-06-07 14:39:31 --> Form Validation Class Initialized
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:39:31 --> Final output sent to browser
DEBUG - 2016-06-07 14:39:31 --> Total execution time: 0.0499
INFO - 2016-06-07 14:39:41 --> Config Class Initialized
INFO - 2016-06-07 14:39:41 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:39:41 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:39:41 --> Utf8 Class Initialized
INFO - 2016-06-07 14:39:41 --> URI Class Initialized
INFO - 2016-06-07 14:39:41 --> Router Class Initialized
INFO - 2016-06-07 14:39:41 --> Output Class Initialized
INFO - 2016-06-07 14:39:41 --> Security Class Initialized
DEBUG - 2016-06-07 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:39:41 --> Input Class Initialized
INFO - 2016-06-07 14:39:41 --> Language Class Initialized
INFO - 2016-06-07 14:39:41 --> Loader Class Initialized
INFO - 2016-06-07 14:39:41 --> Helper loaded: form_helper
INFO - 2016-06-07 14:39:41 --> Database Driver Class Initialized
INFO - 2016-06-07 14:39:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:39:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:39:41 --> Email Class Initialized
INFO - 2016-06-07 14:39:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:39:41 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:39:41 --> Helper loaded: language_helper
INFO - 2016-06-07 14:39:41 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:39:41 --> Model Class Initialized
INFO - 2016-06-07 14:39:41 --> Helper loaded: date_helper
INFO - 2016-06-07 14:39:41 --> Controller Class Initialized
INFO - 2016-06-07 14:39:41 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:39:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:39:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:39:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:39:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:39:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:39:41 --> Model Class Initialized
INFO - 2016-06-07 14:39:41 --> Form Validation Class Initialized
INFO - 2016-06-07 14:39:41 --> Final output sent to browser
DEBUG - 2016-06-07 14:39:41 --> Total execution time: 0.0402
INFO - 2016-06-07 14:40:01 --> Config Class Initialized
INFO - 2016-06-07 14:40:01 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:40:01 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:40:01 --> Utf8 Class Initialized
INFO - 2016-06-07 14:40:01 --> URI Class Initialized
INFO - 2016-06-07 14:40:01 --> Router Class Initialized
INFO - 2016-06-07 14:40:01 --> Output Class Initialized
INFO - 2016-06-07 14:40:01 --> Security Class Initialized
DEBUG - 2016-06-07 14:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:40:01 --> Input Class Initialized
INFO - 2016-06-07 14:40:01 --> Language Class Initialized
INFO - 2016-06-07 14:40:01 --> Loader Class Initialized
INFO - 2016-06-07 14:40:01 --> Helper loaded: form_helper
INFO - 2016-06-07 14:40:01 --> Database Driver Class Initialized
INFO - 2016-06-07 14:40:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:40:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:40:01 --> Email Class Initialized
INFO - 2016-06-07 14:40:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:40:01 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:40:01 --> Helper loaded: language_helper
INFO - 2016-06-07 14:40:01 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:40:01 --> Model Class Initialized
INFO - 2016-06-07 14:40:01 --> Helper loaded: date_helper
INFO - 2016-06-07 14:40:01 --> Controller Class Initialized
INFO - 2016-06-07 14:40:01 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:40:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:40:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:40:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:40:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:40:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:40:01 --> Model Class Initialized
INFO - 2016-06-07 14:40:01 --> Form Validation Class Initialized
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:40:01 --> Final output sent to browser
DEBUG - 2016-06-07 14:40:01 --> Total execution time: 0.1171
INFO - 2016-06-07 14:40:13 --> Config Class Initialized
INFO - 2016-06-07 14:40:13 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:40:13 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:40:13 --> Utf8 Class Initialized
INFO - 2016-06-07 14:40:13 --> URI Class Initialized
INFO - 2016-06-07 14:40:13 --> Router Class Initialized
INFO - 2016-06-07 14:40:13 --> Output Class Initialized
INFO - 2016-06-07 14:40:13 --> Security Class Initialized
DEBUG - 2016-06-07 14:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:40:13 --> Input Class Initialized
INFO - 2016-06-07 14:40:13 --> Language Class Initialized
INFO - 2016-06-07 14:40:13 --> Loader Class Initialized
INFO - 2016-06-07 14:40:13 --> Helper loaded: form_helper
INFO - 2016-06-07 14:40:13 --> Database Driver Class Initialized
INFO - 2016-06-07 14:40:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:40:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:40:13 --> Email Class Initialized
INFO - 2016-06-07 14:40:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:40:13 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:40:13 --> Helper loaded: language_helper
INFO - 2016-06-07 14:40:13 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:40:13 --> Model Class Initialized
INFO - 2016-06-07 14:40:13 --> Helper loaded: date_helper
INFO - 2016-06-07 14:40:13 --> Controller Class Initialized
INFO - 2016-06-07 14:40:13 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:40:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:40:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:40:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:40:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:40:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:40:13 --> Model Class Initialized
INFO - 2016-06-07 14:40:13 --> Form Validation Class Initialized
INFO - 2016-06-07 14:40:13 --> Final output sent to browser
DEBUG - 2016-06-07 14:40:13 --> Total execution time: 0.0894
INFO - 2016-06-07 14:49:21 --> Config Class Initialized
INFO - 2016-06-07 14:49:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:49:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:49:21 --> Utf8 Class Initialized
INFO - 2016-06-07 14:49:21 --> URI Class Initialized
INFO - 2016-06-07 14:49:21 --> Router Class Initialized
INFO - 2016-06-07 14:49:21 --> Output Class Initialized
INFO - 2016-06-07 14:49:21 --> Security Class Initialized
DEBUG - 2016-06-07 14:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:49:21 --> Input Class Initialized
INFO - 2016-06-07 14:49:21 --> Language Class Initialized
INFO - 2016-06-07 14:49:21 --> Loader Class Initialized
INFO - 2016-06-07 14:49:21 --> Helper loaded: form_helper
INFO - 2016-06-07 14:49:21 --> Database Driver Class Initialized
INFO - 2016-06-07 14:49:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:49:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:49:21 --> Email Class Initialized
INFO - 2016-06-07 14:49:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:49:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:49:21 --> Helper loaded: language_helper
INFO - 2016-06-07 14:49:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:49:21 --> Model Class Initialized
INFO - 2016-06-07 14:49:21 --> Helper loaded: date_helper
INFO - 2016-06-07 14:49:21 --> Controller Class Initialized
INFO - 2016-06-07 14:49:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:49:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:49:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:49:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:49:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:49:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:49:21 --> Model Class Initialized
INFO - 2016-06-07 14:49:21 --> Form Validation Class Initialized
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:49:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:49:21 --> Final output sent to browser
DEBUG - 2016-06-07 14:49:21 --> Total execution time: 0.0809
INFO - 2016-06-07 14:49:27 --> Config Class Initialized
INFO - 2016-06-07 14:49:27 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:49:27 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:49:27 --> Utf8 Class Initialized
INFO - 2016-06-07 14:49:27 --> URI Class Initialized
INFO - 2016-06-07 14:49:27 --> Router Class Initialized
INFO - 2016-06-07 14:49:27 --> Output Class Initialized
INFO - 2016-06-07 14:49:27 --> Security Class Initialized
DEBUG - 2016-06-07 14:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:49:27 --> Input Class Initialized
INFO - 2016-06-07 14:49:27 --> Language Class Initialized
INFO - 2016-06-07 14:49:27 --> Loader Class Initialized
INFO - 2016-06-07 14:49:27 --> Helper loaded: form_helper
INFO - 2016-06-07 14:49:27 --> Database Driver Class Initialized
INFO - 2016-06-07 14:49:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:49:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:49:27 --> Email Class Initialized
INFO - 2016-06-07 14:49:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:49:27 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:49:27 --> Helper loaded: language_helper
INFO - 2016-06-07 14:49:27 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:49:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:49:27 --> Model Class Initialized
INFO - 2016-06-07 14:49:27 --> Helper loaded: date_helper
INFO - 2016-06-07 14:49:27 --> Controller Class Initialized
INFO - 2016-06-07 14:49:27 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:49:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:49:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:49:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:49:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:49:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:49:27 --> Model Class Initialized
INFO - 2016-06-07 14:49:27 --> Form Validation Class Initialized
INFO - 2016-06-07 14:49:27 --> Final output sent to browser
DEBUG - 2016-06-07 14:49:27 --> Total execution time: 0.0558
INFO - 2016-06-07 14:49:38 --> Config Class Initialized
INFO - 2016-06-07 14:49:38 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:49:38 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:49:38 --> Utf8 Class Initialized
INFO - 2016-06-07 14:49:38 --> URI Class Initialized
INFO - 2016-06-07 14:49:38 --> Router Class Initialized
INFO - 2016-06-07 14:49:38 --> Output Class Initialized
INFO - 2016-06-07 14:49:38 --> Security Class Initialized
DEBUG - 2016-06-07 14:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:49:38 --> Input Class Initialized
INFO - 2016-06-07 14:49:38 --> Language Class Initialized
INFO - 2016-06-07 14:49:38 --> Loader Class Initialized
INFO - 2016-06-07 14:49:38 --> Helper loaded: form_helper
INFO - 2016-06-07 14:49:38 --> Database Driver Class Initialized
INFO - 2016-06-07 14:49:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:49:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:49:38 --> Email Class Initialized
INFO - 2016-06-07 14:49:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:49:38 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:49:38 --> Helper loaded: language_helper
INFO - 2016-06-07 14:49:38 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:49:38 --> Model Class Initialized
INFO - 2016-06-07 14:49:38 --> Helper loaded: date_helper
INFO - 2016-06-07 14:49:38 --> Controller Class Initialized
INFO - 2016-06-07 14:49:38 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:49:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:49:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:49:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:49:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:49:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:49:38 --> Model Class Initialized
INFO - 2016-06-07 14:49:38 --> Form Validation Class Initialized
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:49:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:49:38 --> Final output sent to browser
DEBUG - 2016-06-07 14:49:38 --> Total execution time: 0.0537
INFO - 2016-06-07 14:49:42 --> Config Class Initialized
INFO - 2016-06-07 14:49:42 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:49:42 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:49:42 --> Utf8 Class Initialized
INFO - 2016-06-07 14:49:42 --> URI Class Initialized
INFO - 2016-06-07 14:49:42 --> Router Class Initialized
INFO - 2016-06-07 14:49:42 --> Output Class Initialized
INFO - 2016-06-07 14:49:42 --> Security Class Initialized
DEBUG - 2016-06-07 14:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:49:42 --> Input Class Initialized
INFO - 2016-06-07 14:49:42 --> Language Class Initialized
INFO - 2016-06-07 14:49:42 --> Loader Class Initialized
INFO - 2016-06-07 14:49:42 --> Helper loaded: form_helper
INFO - 2016-06-07 14:49:42 --> Database Driver Class Initialized
INFO - 2016-06-07 14:49:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:49:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:49:42 --> Email Class Initialized
INFO - 2016-06-07 14:49:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:49:42 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:49:42 --> Helper loaded: language_helper
INFO - 2016-06-07 14:49:42 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:49:42 --> Model Class Initialized
INFO - 2016-06-07 14:49:42 --> Helper loaded: date_helper
INFO - 2016-06-07 14:49:42 --> Controller Class Initialized
INFO - 2016-06-07 14:49:42 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:49:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:49:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:49:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:49:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:49:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:49:42 --> Model Class Initialized
INFO - 2016-06-07 14:49:42 --> Form Validation Class Initialized
INFO - 2016-06-07 14:49:42 --> Final output sent to browser
DEBUG - 2016-06-07 14:49:42 --> Total execution time: 0.0185
INFO - 2016-06-07 14:49:53 --> Config Class Initialized
INFO - 2016-06-07 14:49:53 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:49:53 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:49:53 --> Utf8 Class Initialized
INFO - 2016-06-07 14:49:53 --> URI Class Initialized
INFO - 2016-06-07 14:49:53 --> Router Class Initialized
INFO - 2016-06-07 14:49:53 --> Output Class Initialized
INFO - 2016-06-07 14:49:53 --> Security Class Initialized
DEBUG - 2016-06-07 14:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:49:53 --> Input Class Initialized
INFO - 2016-06-07 14:49:53 --> Language Class Initialized
INFO - 2016-06-07 14:49:53 --> Loader Class Initialized
INFO - 2016-06-07 14:49:53 --> Helper loaded: form_helper
INFO - 2016-06-07 14:49:53 --> Database Driver Class Initialized
INFO - 2016-06-07 14:49:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:49:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:49:53 --> Email Class Initialized
INFO - 2016-06-07 14:49:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:49:53 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:49:53 --> Helper loaded: language_helper
INFO - 2016-06-07 14:49:53 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:49:53 --> Model Class Initialized
INFO - 2016-06-07 14:49:53 --> Helper loaded: date_helper
INFO - 2016-06-07 14:49:53 --> Controller Class Initialized
INFO - 2016-06-07 14:49:53 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:49:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:49:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:49:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:49:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:49:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:49:53 --> Model Class Initialized
INFO - 2016-06-07 14:49:53 --> Form Validation Class Initialized
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:49:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:49:53 --> Final output sent to browser
DEBUG - 2016-06-07 14:49:53 --> Total execution time: 0.0277
INFO - 2016-06-07 14:50:02 --> Config Class Initialized
INFO - 2016-06-07 14:50:02 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:50:02 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:50:02 --> Utf8 Class Initialized
INFO - 2016-06-07 14:50:02 --> URI Class Initialized
INFO - 2016-06-07 14:50:02 --> Router Class Initialized
INFO - 2016-06-07 14:50:02 --> Output Class Initialized
INFO - 2016-06-07 14:50:02 --> Security Class Initialized
DEBUG - 2016-06-07 14:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:50:02 --> Input Class Initialized
INFO - 2016-06-07 14:50:02 --> Language Class Initialized
INFO - 2016-06-07 14:50:02 --> Loader Class Initialized
INFO - 2016-06-07 14:50:02 --> Helper loaded: form_helper
INFO - 2016-06-07 14:50:02 --> Database Driver Class Initialized
INFO - 2016-06-07 14:50:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:50:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:50:02 --> Email Class Initialized
INFO - 2016-06-07 14:50:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:50:02 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:50:02 --> Helper loaded: language_helper
INFO - 2016-06-07 14:50:02 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:50:02 --> Model Class Initialized
INFO - 2016-06-07 14:50:02 --> Helper loaded: date_helper
INFO - 2016-06-07 14:50:02 --> Controller Class Initialized
INFO - 2016-06-07 14:50:02 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:50:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:50:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:50:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:50:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:50:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:50:02 --> Model Class Initialized
INFO - 2016-06-07 14:50:02 --> Form Validation Class Initialized
INFO - 2016-06-07 14:50:02 --> Final output sent to browser
DEBUG - 2016-06-07 14:50:02 --> Total execution time: 0.0423
INFO - 2016-06-07 14:51:28 --> Config Class Initialized
INFO - 2016-06-07 14:51:28 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:51:28 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:51:28 --> Utf8 Class Initialized
INFO - 2016-06-07 14:51:28 --> URI Class Initialized
INFO - 2016-06-07 14:51:28 --> Router Class Initialized
INFO - 2016-06-07 14:51:28 --> Output Class Initialized
INFO - 2016-06-07 14:51:28 --> Security Class Initialized
DEBUG - 2016-06-07 14:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:51:28 --> Input Class Initialized
INFO - 2016-06-07 14:51:28 --> Language Class Initialized
INFO - 2016-06-07 14:51:28 --> Loader Class Initialized
INFO - 2016-06-07 14:51:28 --> Helper loaded: form_helper
INFO - 2016-06-07 14:51:28 --> Database Driver Class Initialized
INFO - 2016-06-07 14:51:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:51:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:51:28 --> Email Class Initialized
INFO - 2016-06-07 14:51:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:51:28 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:51:28 --> Helper loaded: language_helper
INFO - 2016-06-07 14:51:28 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:51:28 --> Model Class Initialized
INFO - 2016-06-07 14:51:28 --> Helper loaded: date_helper
INFO - 2016-06-07 14:51:28 --> Controller Class Initialized
INFO - 2016-06-07 14:51:28 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:51:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:51:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:51:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:51:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:51:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:51:28 --> Model Class Initialized
INFO - 2016-06-07 14:51:28 --> Form Validation Class Initialized
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:51:28 --> Final output sent to browser
DEBUG - 2016-06-07 14:51:28 --> Total execution time: 0.1118
INFO - 2016-06-07 14:51:37 --> Config Class Initialized
INFO - 2016-06-07 14:51:37 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:51:37 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:51:37 --> Utf8 Class Initialized
INFO - 2016-06-07 14:51:37 --> URI Class Initialized
INFO - 2016-06-07 14:51:37 --> Router Class Initialized
INFO - 2016-06-07 14:51:37 --> Output Class Initialized
INFO - 2016-06-07 14:51:37 --> Security Class Initialized
DEBUG - 2016-06-07 14:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:51:37 --> Input Class Initialized
INFO - 2016-06-07 14:51:37 --> Language Class Initialized
INFO - 2016-06-07 14:51:37 --> Loader Class Initialized
INFO - 2016-06-07 14:51:37 --> Helper loaded: form_helper
INFO - 2016-06-07 14:51:37 --> Database Driver Class Initialized
INFO - 2016-06-07 14:51:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:51:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:51:37 --> Email Class Initialized
INFO - 2016-06-07 14:51:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:51:37 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:51:37 --> Helper loaded: language_helper
INFO - 2016-06-07 14:51:37 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:51:37 --> Model Class Initialized
INFO - 2016-06-07 14:51:37 --> Helper loaded: date_helper
INFO - 2016-06-07 14:51:37 --> Controller Class Initialized
INFO - 2016-06-07 14:51:37 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:51:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:51:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:51:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:51:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:51:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:51:37 --> Model Class Initialized
INFO - 2016-06-07 14:51:37 --> Form Validation Class Initialized
INFO - 2016-06-07 14:51:37 --> Final output sent to browser
DEBUG - 2016-06-07 14:51:37 --> Total execution time: 0.0487
INFO - 2016-06-07 14:54:17 --> Config Class Initialized
INFO - 2016-06-07 14:54:17 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:54:17 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:54:17 --> Utf8 Class Initialized
INFO - 2016-06-07 14:54:17 --> URI Class Initialized
INFO - 2016-06-07 14:54:17 --> Router Class Initialized
INFO - 2016-06-07 14:54:17 --> Output Class Initialized
INFO - 2016-06-07 14:54:17 --> Security Class Initialized
DEBUG - 2016-06-07 14:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:54:17 --> Input Class Initialized
INFO - 2016-06-07 14:54:17 --> Language Class Initialized
INFO - 2016-06-07 14:54:17 --> Loader Class Initialized
INFO - 2016-06-07 14:54:17 --> Helper loaded: form_helper
INFO - 2016-06-07 14:54:17 --> Database Driver Class Initialized
INFO - 2016-06-07 14:54:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:54:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:54:18 --> Email Class Initialized
INFO - 2016-06-07 14:54:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:54:18 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:54:18 --> Helper loaded: language_helper
INFO - 2016-06-07 14:54:18 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:54:18 --> Model Class Initialized
INFO - 2016-06-07 14:54:18 --> Helper loaded: date_helper
INFO - 2016-06-07 14:54:18 --> Controller Class Initialized
INFO - 2016-06-07 14:54:18 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:54:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:54:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:54:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:54:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:54:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:54:18 --> Model Class Initialized
INFO - 2016-06-07 14:54:18 --> Form Validation Class Initialized
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 14:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 14:54:18 --> Final output sent to browser
DEBUG - 2016-06-07 14:54:18 --> Total execution time: 0.1990
INFO - 2016-06-07 14:54:24 --> Config Class Initialized
INFO - 2016-06-07 14:54:24 --> Hooks Class Initialized
DEBUG - 2016-06-07 14:54:24 --> UTF-8 Support Enabled
INFO - 2016-06-07 14:54:24 --> Utf8 Class Initialized
INFO - 2016-06-07 14:54:24 --> URI Class Initialized
INFO - 2016-06-07 14:54:24 --> Router Class Initialized
INFO - 2016-06-07 14:54:24 --> Output Class Initialized
INFO - 2016-06-07 14:54:24 --> Security Class Initialized
DEBUG - 2016-06-07 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 14:54:24 --> Input Class Initialized
INFO - 2016-06-07 14:54:24 --> Language Class Initialized
INFO - 2016-06-07 14:54:24 --> Loader Class Initialized
INFO - 2016-06-07 14:54:24 --> Helper loaded: form_helper
INFO - 2016-06-07 14:54:24 --> Database Driver Class Initialized
INFO - 2016-06-07 14:54:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 14:54:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 14:54:24 --> Email Class Initialized
INFO - 2016-06-07 14:54:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 14:54:24 --> Helper loaded: cookie_helper
INFO - 2016-06-07 14:54:24 --> Helper loaded: language_helper
INFO - 2016-06-07 14:54:24 --> Helper loaded: url_helper
DEBUG - 2016-06-07 14:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 14:54:24 --> Model Class Initialized
INFO - 2016-06-07 14:54:24 --> Helper loaded: date_helper
INFO - 2016-06-07 14:54:24 --> Controller Class Initialized
INFO - 2016-06-07 14:54:24 --> Helper loaded: languages_helper
INFO - 2016-06-07 14:54:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 14:54:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 14:54:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 14:54:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 14:54:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 14:54:24 --> Model Class Initialized
INFO - 2016-06-07 14:54:24 --> Form Validation Class Initialized
INFO - 2016-06-07 14:54:24 --> Final output sent to browser
DEBUG - 2016-06-07 14:54:24 --> Total execution time: 0.0457
INFO - 2016-06-07 15:03:30 --> Config Class Initialized
INFO - 2016-06-07 15:03:30 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:03:30 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:03:30 --> Utf8 Class Initialized
INFO - 2016-06-07 15:03:30 --> URI Class Initialized
INFO - 2016-06-07 15:03:30 --> Router Class Initialized
INFO - 2016-06-07 15:03:30 --> Output Class Initialized
INFO - 2016-06-07 15:03:30 --> Security Class Initialized
DEBUG - 2016-06-07 15:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:03:30 --> Input Class Initialized
INFO - 2016-06-07 15:03:30 --> Language Class Initialized
INFO - 2016-06-07 15:03:30 --> Loader Class Initialized
INFO - 2016-06-07 15:03:30 --> Helper loaded: form_helper
INFO - 2016-06-07 15:03:30 --> Database Driver Class Initialized
INFO - 2016-06-07 15:03:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:03:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:03:30 --> Email Class Initialized
INFO - 2016-06-07 15:03:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:03:30 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:03:30 --> Helper loaded: language_helper
INFO - 2016-06-07 15:03:30 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:03:30 --> Model Class Initialized
INFO - 2016-06-07 15:03:30 --> Helper loaded: date_helper
INFO - 2016-06-07 15:03:30 --> Controller Class Initialized
INFO - 2016-06-07 15:03:30 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:03:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:03:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:03:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:03:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:03:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:03:30 --> Model Class Initialized
INFO - 2016-06-07 15:03:30 --> Form Validation Class Initialized
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:03:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:03:31 --> Final output sent to browser
DEBUG - 2016-06-07 15:03:31 --> Total execution time: 0.0761
INFO - 2016-06-07 15:03:40 --> Config Class Initialized
INFO - 2016-06-07 15:03:40 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:03:40 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:03:40 --> Utf8 Class Initialized
INFO - 2016-06-07 15:03:40 --> URI Class Initialized
INFO - 2016-06-07 15:03:40 --> Router Class Initialized
INFO - 2016-06-07 15:03:40 --> Output Class Initialized
INFO - 2016-06-07 15:03:40 --> Security Class Initialized
DEBUG - 2016-06-07 15:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:03:40 --> Input Class Initialized
INFO - 2016-06-07 15:03:40 --> Language Class Initialized
INFO - 2016-06-07 15:03:40 --> Loader Class Initialized
INFO - 2016-06-07 15:03:40 --> Helper loaded: form_helper
INFO - 2016-06-07 15:03:40 --> Database Driver Class Initialized
INFO - 2016-06-07 15:03:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:03:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:03:40 --> Email Class Initialized
INFO - 2016-06-07 15:03:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:03:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:03:40 --> Helper loaded: language_helper
INFO - 2016-06-07 15:03:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:03:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:03:40 --> Model Class Initialized
INFO - 2016-06-07 15:03:40 --> Helper loaded: date_helper
INFO - 2016-06-07 15:03:40 --> Controller Class Initialized
INFO - 2016-06-07 15:03:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:03:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:03:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:03:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:03:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:03:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:03:40 --> Model Class Initialized
INFO - 2016-06-07 15:03:40 --> Form Validation Class Initialized
INFO - 2016-06-07 15:03:40 --> Final output sent to browser
DEBUG - 2016-06-07 15:03:40 --> Total execution time: 0.0767
INFO - 2016-06-07 15:05:15 --> Config Class Initialized
INFO - 2016-06-07 15:05:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:05:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:05:15 --> Utf8 Class Initialized
INFO - 2016-06-07 15:05:15 --> URI Class Initialized
INFO - 2016-06-07 15:05:15 --> Router Class Initialized
INFO - 2016-06-07 15:05:15 --> Output Class Initialized
INFO - 2016-06-07 15:05:15 --> Security Class Initialized
DEBUG - 2016-06-07 15:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:05:15 --> Input Class Initialized
INFO - 2016-06-07 15:05:15 --> Language Class Initialized
ERROR - 2016-06-07 15:05:15 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) /home/demis/www/platformadiabet/application/controllers/Diabet.php 405
INFO - 2016-06-07 15:05:41 --> Config Class Initialized
INFO - 2016-06-07 15:05:41 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:05:41 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:05:41 --> Utf8 Class Initialized
INFO - 2016-06-07 15:05:41 --> URI Class Initialized
INFO - 2016-06-07 15:05:41 --> Router Class Initialized
INFO - 2016-06-07 15:05:41 --> Output Class Initialized
INFO - 2016-06-07 15:05:41 --> Security Class Initialized
DEBUG - 2016-06-07 15:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:05:41 --> Input Class Initialized
INFO - 2016-06-07 15:05:41 --> Language Class Initialized
INFO - 2016-06-07 15:05:41 --> Loader Class Initialized
INFO - 2016-06-07 15:05:41 --> Helper loaded: form_helper
INFO - 2016-06-07 15:05:41 --> Database Driver Class Initialized
INFO - 2016-06-07 15:05:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:05:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:05:41 --> Email Class Initialized
INFO - 2016-06-07 15:05:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:05:41 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:05:41 --> Helper loaded: language_helper
INFO - 2016-06-07 15:05:41 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:05:41 --> Model Class Initialized
INFO - 2016-06-07 15:05:41 --> Helper loaded: date_helper
INFO - 2016-06-07 15:05:41 --> Controller Class Initialized
INFO - 2016-06-07 15:05:41 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:05:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:05:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:05:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:05:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:05:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:05:41 --> Model Class Initialized
INFO - 2016-06-07 15:05:41 --> Form Validation Class Initialized
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:05:41 --> Final output sent to browser
DEBUG - 2016-06-07 15:05:41 --> Total execution time: 0.0575
INFO - 2016-06-07 15:05:52 --> Config Class Initialized
INFO - 2016-06-07 15:05:52 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:05:52 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:05:52 --> Utf8 Class Initialized
INFO - 2016-06-07 15:05:52 --> URI Class Initialized
INFO - 2016-06-07 15:05:52 --> Router Class Initialized
INFO - 2016-06-07 15:05:52 --> Output Class Initialized
INFO - 2016-06-07 15:05:52 --> Security Class Initialized
DEBUG - 2016-06-07 15:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:05:52 --> Input Class Initialized
INFO - 2016-06-07 15:05:52 --> Language Class Initialized
INFO - 2016-06-07 15:05:52 --> Loader Class Initialized
INFO - 2016-06-07 15:05:52 --> Helper loaded: form_helper
INFO - 2016-06-07 15:05:52 --> Database Driver Class Initialized
INFO - 2016-06-07 15:05:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:05:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:05:52 --> Email Class Initialized
INFO - 2016-06-07 15:05:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:05:52 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:05:52 --> Helper loaded: language_helper
INFO - 2016-06-07 15:05:52 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:05:52 --> Model Class Initialized
INFO - 2016-06-07 15:05:52 --> Helper loaded: date_helper
INFO - 2016-06-07 15:05:52 --> Controller Class Initialized
INFO - 2016-06-07 15:05:52 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:05:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:05:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:05:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:05:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:05:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:05:52 --> Model Class Initialized
INFO - 2016-06-07 15:05:52 --> Form Validation Class Initialized
INFO - 2016-06-07 15:11:33 --> Config Class Initialized
INFO - 2016-06-07 15:11:33 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:11:33 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:11:33 --> Utf8 Class Initialized
INFO - 2016-06-07 15:11:33 --> URI Class Initialized
INFO - 2016-06-07 15:11:33 --> Router Class Initialized
INFO - 2016-06-07 15:11:33 --> Output Class Initialized
INFO - 2016-06-07 15:11:33 --> Security Class Initialized
DEBUG - 2016-06-07 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:11:33 --> Input Class Initialized
INFO - 2016-06-07 15:11:33 --> Language Class Initialized
INFO - 2016-06-07 15:11:33 --> Loader Class Initialized
INFO - 2016-06-07 15:11:33 --> Helper loaded: form_helper
INFO - 2016-06-07 15:11:33 --> Database Driver Class Initialized
INFO - 2016-06-07 15:11:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:11:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:11:33 --> Email Class Initialized
INFO - 2016-06-07 15:11:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:11:33 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:11:33 --> Helper loaded: language_helper
INFO - 2016-06-07 15:11:33 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:11:33 --> Model Class Initialized
INFO - 2016-06-07 15:11:33 --> Helper loaded: date_helper
INFO - 2016-06-07 15:11:33 --> Controller Class Initialized
INFO - 2016-06-07 15:11:33 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:11:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:11:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:11:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:11:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:11:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:11:33 --> Model Class Initialized
INFO - 2016-06-07 15:11:33 --> Form Validation Class Initialized
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:11:33 --> Final output sent to browser
DEBUG - 2016-06-07 15:11:33 --> Total execution time: 0.1046
INFO - 2016-06-07 15:11:46 --> Config Class Initialized
INFO - 2016-06-07 15:11:46 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:11:46 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:11:46 --> Utf8 Class Initialized
INFO - 2016-06-07 15:11:46 --> URI Class Initialized
INFO - 2016-06-07 15:11:46 --> Router Class Initialized
INFO - 2016-06-07 15:11:46 --> Output Class Initialized
INFO - 2016-06-07 15:11:46 --> Security Class Initialized
DEBUG - 2016-06-07 15:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:11:46 --> Input Class Initialized
INFO - 2016-06-07 15:11:46 --> Language Class Initialized
INFO - 2016-06-07 15:11:46 --> Loader Class Initialized
INFO - 2016-06-07 15:11:46 --> Helper loaded: form_helper
INFO - 2016-06-07 15:11:46 --> Database Driver Class Initialized
INFO - 2016-06-07 15:11:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:11:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:11:46 --> Email Class Initialized
INFO - 2016-06-07 15:11:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:11:46 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:11:46 --> Helper loaded: language_helper
INFO - 2016-06-07 15:11:46 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:11:46 --> Model Class Initialized
INFO - 2016-06-07 15:11:46 --> Helper loaded: date_helper
INFO - 2016-06-07 15:11:46 --> Controller Class Initialized
INFO - 2016-06-07 15:11:46 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:11:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:11:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:11:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:11:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:11:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:11:46 --> Model Class Initialized
INFO - 2016-06-07 15:11:46 --> Form Validation Class Initialized
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hipoglicemiei"
ERROR - 2016-06-07 15:11:46 --> Could not find the language line "hiperglicemiei"
INFO - 2016-06-07 15:14:54 --> Config Class Initialized
INFO - 2016-06-07 15:14:54 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:14:54 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:14:54 --> Utf8 Class Initialized
INFO - 2016-06-07 15:14:54 --> URI Class Initialized
INFO - 2016-06-07 15:14:54 --> Router Class Initialized
INFO - 2016-06-07 15:14:54 --> Output Class Initialized
INFO - 2016-06-07 15:14:54 --> Security Class Initialized
DEBUG - 2016-06-07 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:14:54 --> Input Class Initialized
INFO - 2016-06-07 15:14:54 --> Language Class Initialized
INFO - 2016-06-07 15:14:54 --> Loader Class Initialized
INFO - 2016-06-07 15:14:54 --> Helper loaded: form_helper
INFO - 2016-06-07 15:14:54 --> Database Driver Class Initialized
INFO - 2016-06-07 15:14:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:14:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:14:54 --> Email Class Initialized
INFO - 2016-06-07 15:14:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:14:54 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:14:54 --> Helper loaded: language_helper
INFO - 2016-06-07 15:14:54 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:14:54 --> Model Class Initialized
INFO - 2016-06-07 15:14:54 --> Helper loaded: date_helper
INFO - 2016-06-07 15:14:54 --> Controller Class Initialized
INFO - 2016-06-07 15:14:54 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:14:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:14:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:14:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:14:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:14:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:14:54 --> Model Class Initialized
INFO - 2016-06-07 15:14:54 --> Form Validation Class Initialized
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:14:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:14:54 --> Final output sent to browser
DEBUG - 2016-06-07 15:14:54 --> Total execution time: 0.0928
INFO - 2016-06-07 15:15:01 --> Config Class Initialized
INFO - 2016-06-07 15:15:01 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:15:01 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:15:01 --> Utf8 Class Initialized
INFO - 2016-06-07 15:15:01 --> URI Class Initialized
INFO - 2016-06-07 15:15:01 --> Router Class Initialized
INFO - 2016-06-07 15:15:01 --> Output Class Initialized
INFO - 2016-06-07 15:15:01 --> Security Class Initialized
DEBUG - 2016-06-07 15:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:15:01 --> Input Class Initialized
INFO - 2016-06-07 15:15:01 --> Language Class Initialized
INFO - 2016-06-07 15:15:01 --> Loader Class Initialized
INFO - 2016-06-07 15:15:01 --> Helper loaded: form_helper
INFO - 2016-06-07 15:15:01 --> Database Driver Class Initialized
INFO - 2016-06-07 15:15:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:15:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:15:01 --> Email Class Initialized
INFO - 2016-06-07 15:15:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:15:01 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:15:01 --> Helper loaded: language_helper
INFO - 2016-06-07 15:15:01 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:15:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:15:01 --> Model Class Initialized
INFO - 2016-06-07 15:15:01 --> Helper loaded: date_helper
INFO - 2016-06-07 15:15:01 --> Controller Class Initialized
INFO - 2016-06-07 15:15:01 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:15:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:15:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:15:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:15:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:15:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:15:01 --> Model Class Initialized
INFO - 2016-06-07 15:15:01 --> Form Validation Class Initialized
INFO - 2016-06-07 15:18:38 --> Config Class Initialized
INFO - 2016-06-07 15:18:38 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:18:38 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:18:38 --> Utf8 Class Initialized
INFO - 2016-06-07 15:18:38 --> URI Class Initialized
INFO - 2016-06-07 15:18:38 --> Router Class Initialized
INFO - 2016-06-07 15:18:38 --> Output Class Initialized
INFO - 2016-06-07 15:18:38 --> Security Class Initialized
DEBUG - 2016-06-07 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:18:38 --> Input Class Initialized
INFO - 2016-06-07 15:18:38 --> Language Class Initialized
INFO - 2016-06-07 15:18:38 --> Loader Class Initialized
INFO - 2016-06-07 15:18:38 --> Helper loaded: form_helper
INFO - 2016-06-07 15:18:38 --> Database Driver Class Initialized
INFO - 2016-06-07 15:18:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:18:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:18:38 --> Email Class Initialized
INFO - 2016-06-07 15:18:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:18:38 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:18:38 --> Helper loaded: language_helper
INFO - 2016-06-07 15:18:38 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:18:38 --> Model Class Initialized
INFO - 2016-06-07 15:18:38 --> Helper loaded: date_helper
INFO - 2016-06-07 15:18:38 --> Controller Class Initialized
INFO - 2016-06-07 15:18:38 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:18:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:18:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:18:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:18:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:18:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:18:38 --> Model Class Initialized
INFO - 2016-06-07 15:18:38 --> Form Validation Class Initialized
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:18:38 --> Final output sent to browser
DEBUG - 2016-06-07 15:18:38 --> Total execution time: 0.0698
INFO - 2016-06-07 15:18:45 --> Config Class Initialized
INFO - 2016-06-07 15:18:45 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:18:45 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:18:45 --> Utf8 Class Initialized
INFO - 2016-06-07 15:18:45 --> URI Class Initialized
INFO - 2016-06-07 15:18:45 --> Router Class Initialized
INFO - 2016-06-07 15:18:45 --> Output Class Initialized
INFO - 2016-06-07 15:18:45 --> Security Class Initialized
DEBUG - 2016-06-07 15:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:18:45 --> Input Class Initialized
INFO - 2016-06-07 15:18:45 --> Language Class Initialized
INFO - 2016-06-07 15:18:45 --> Loader Class Initialized
INFO - 2016-06-07 15:18:45 --> Helper loaded: form_helper
INFO - 2016-06-07 15:18:45 --> Database Driver Class Initialized
INFO - 2016-06-07 15:18:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:18:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:18:45 --> Email Class Initialized
INFO - 2016-06-07 15:18:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:18:45 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:18:45 --> Helper loaded: language_helper
INFO - 2016-06-07 15:18:45 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:18:45 --> Model Class Initialized
INFO - 2016-06-07 15:18:45 --> Helper loaded: date_helper
INFO - 2016-06-07 15:18:45 --> Controller Class Initialized
INFO - 2016-06-07 15:18:45 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:18:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:18:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:18:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:18:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:18:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:18:45 --> Model Class Initialized
INFO - 2016-06-07 15:18:45 --> Form Validation Class Initialized
ERROR - 2016-06-07 15:18:45 --> Severity: Notice --> Undefined offset: 4 /home/demis/www/platformadiabet/application/controllers/Diabet.php 414
INFO - 2016-06-07 15:19:23 --> Config Class Initialized
INFO - 2016-06-07 15:19:23 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:19:23 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:19:23 --> Utf8 Class Initialized
INFO - 2016-06-07 15:19:23 --> URI Class Initialized
INFO - 2016-06-07 15:19:23 --> Router Class Initialized
INFO - 2016-06-07 15:19:23 --> Output Class Initialized
INFO - 2016-06-07 15:19:23 --> Security Class Initialized
DEBUG - 2016-06-07 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:19:23 --> Input Class Initialized
INFO - 2016-06-07 15:19:23 --> Language Class Initialized
INFO - 2016-06-07 15:19:23 --> Loader Class Initialized
INFO - 2016-06-07 15:19:23 --> Helper loaded: form_helper
INFO - 2016-06-07 15:19:23 --> Database Driver Class Initialized
INFO - 2016-06-07 15:19:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:19:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:19:23 --> Email Class Initialized
INFO - 2016-06-07 15:19:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:19:23 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:19:23 --> Helper loaded: language_helper
INFO - 2016-06-07 15:19:23 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:19:23 --> Model Class Initialized
INFO - 2016-06-07 15:19:23 --> Helper loaded: date_helper
INFO - 2016-06-07 15:19:23 --> Controller Class Initialized
INFO - 2016-06-07 15:19:23 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:19:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:19:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:19:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:19:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:19:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:19:23 --> Model Class Initialized
INFO - 2016-06-07 15:19:23 --> Form Validation Class Initialized
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:19:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:19:23 --> Final output sent to browser
DEBUG - 2016-06-07 15:19:23 --> Total execution time: 0.0597
INFO - 2016-06-07 15:19:30 --> Config Class Initialized
INFO - 2016-06-07 15:19:30 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:19:30 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:19:30 --> Utf8 Class Initialized
INFO - 2016-06-07 15:19:30 --> URI Class Initialized
INFO - 2016-06-07 15:19:30 --> Router Class Initialized
INFO - 2016-06-07 15:19:30 --> Output Class Initialized
INFO - 2016-06-07 15:19:30 --> Security Class Initialized
DEBUG - 2016-06-07 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:19:30 --> Input Class Initialized
INFO - 2016-06-07 15:19:30 --> Language Class Initialized
INFO - 2016-06-07 15:19:30 --> Loader Class Initialized
INFO - 2016-06-07 15:19:30 --> Helper loaded: form_helper
INFO - 2016-06-07 15:19:30 --> Database Driver Class Initialized
INFO - 2016-06-07 15:19:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:19:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:19:30 --> Email Class Initialized
INFO - 2016-06-07 15:19:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:19:30 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:19:30 --> Helper loaded: language_helper
INFO - 2016-06-07 15:19:30 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:19:30 --> Model Class Initialized
INFO - 2016-06-07 15:19:30 --> Helper loaded: date_helper
INFO - 2016-06-07 15:19:30 --> Controller Class Initialized
INFO - 2016-06-07 15:19:30 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:19:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:19:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:19:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:19:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:19:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:19:30 --> Model Class Initialized
INFO - 2016-06-07 15:19:30 --> Form Validation Class Initialized
INFO - 2016-06-07 15:19:55 --> Config Class Initialized
INFO - 2016-06-07 15:19:55 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:19:55 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:19:55 --> Utf8 Class Initialized
INFO - 2016-06-07 15:19:55 --> URI Class Initialized
INFO - 2016-06-07 15:19:55 --> Router Class Initialized
INFO - 2016-06-07 15:19:55 --> Output Class Initialized
INFO - 2016-06-07 15:19:55 --> Security Class Initialized
DEBUG - 2016-06-07 15:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:19:55 --> Input Class Initialized
INFO - 2016-06-07 15:19:55 --> Language Class Initialized
INFO - 2016-06-07 15:19:55 --> Loader Class Initialized
INFO - 2016-06-07 15:19:55 --> Helper loaded: form_helper
INFO - 2016-06-07 15:19:55 --> Database Driver Class Initialized
INFO - 2016-06-07 15:19:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:19:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:19:55 --> Email Class Initialized
INFO - 2016-06-07 15:19:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:19:55 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:19:55 --> Helper loaded: language_helper
INFO - 2016-06-07 15:19:55 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:19:55 --> Model Class Initialized
INFO - 2016-06-07 15:19:55 --> Helper loaded: date_helper
INFO - 2016-06-07 15:19:55 --> Controller Class Initialized
INFO - 2016-06-07 15:19:55 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:19:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:19:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:19:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:19:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:19:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:19:55 --> Model Class Initialized
INFO - 2016-06-07 15:19:55 --> Form Validation Class Initialized
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:19:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:19:55 --> Final output sent to browser
DEBUG - 2016-06-07 15:19:55 --> Total execution time: 0.0611
INFO - 2016-06-07 15:20:04 --> Config Class Initialized
INFO - 2016-06-07 15:20:04 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:20:04 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:20:04 --> Utf8 Class Initialized
INFO - 2016-06-07 15:20:04 --> URI Class Initialized
INFO - 2016-06-07 15:20:04 --> Router Class Initialized
INFO - 2016-06-07 15:20:04 --> Output Class Initialized
INFO - 2016-06-07 15:20:04 --> Security Class Initialized
DEBUG - 2016-06-07 15:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:20:04 --> Input Class Initialized
INFO - 2016-06-07 15:20:04 --> Language Class Initialized
INFO - 2016-06-07 15:20:04 --> Loader Class Initialized
INFO - 2016-06-07 15:20:04 --> Helper loaded: form_helper
INFO - 2016-06-07 15:20:04 --> Database Driver Class Initialized
INFO - 2016-06-07 15:20:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:20:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:20:04 --> Email Class Initialized
INFO - 2016-06-07 15:20:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:20:04 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:20:04 --> Helper loaded: language_helper
INFO - 2016-06-07 15:20:04 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:20:04 --> Model Class Initialized
INFO - 2016-06-07 15:20:04 --> Helper loaded: date_helper
INFO - 2016-06-07 15:20:04 --> Controller Class Initialized
INFO - 2016-06-07 15:20:04 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:20:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:20:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:20:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:20:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:20:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:20:04 --> Model Class Initialized
INFO - 2016-06-07 15:20:04 --> Form Validation Class Initialized
INFO - 2016-06-07 15:20:04 --> Final output sent to browser
DEBUG - 2016-06-07 15:20:04 --> Total execution time: 0.0609
INFO - 2016-06-07 15:20:58 --> Config Class Initialized
INFO - 2016-06-07 15:20:58 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:20:58 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:20:58 --> Utf8 Class Initialized
INFO - 2016-06-07 15:20:58 --> URI Class Initialized
INFO - 2016-06-07 15:20:58 --> Router Class Initialized
INFO - 2016-06-07 15:20:58 --> Output Class Initialized
INFO - 2016-06-07 15:20:58 --> Security Class Initialized
DEBUG - 2016-06-07 15:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:20:58 --> Input Class Initialized
INFO - 2016-06-07 15:20:58 --> Language Class Initialized
INFO - 2016-06-07 15:20:58 --> Loader Class Initialized
INFO - 2016-06-07 15:20:58 --> Helper loaded: form_helper
INFO - 2016-06-07 15:20:58 --> Database Driver Class Initialized
INFO - 2016-06-07 15:20:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:20:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:20:58 --> Email Class Initialized
INFO - 2016-06-07 15:20:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:20:58 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:20:58 --> Helper loaded: language_helper
INFO - 2016-06-07 15:20:58 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:20:58 --> Model Class Initialized
INFO - 2016-06-07 15:20:58 --> Helper loaded: date_helper
INFO - 2016-06-07 15:20:58 --> Controller Class Initialized
INFO - 2016-06-07 15:20:58 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:20:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:20:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:20:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:20:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:20:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:20:58 --> Model Class Initialized
INFO - 2016-06-07 15:20:58 --> Form Validation Class Initialized
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:20:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:20:58 --> Final output sent to browser
DEBUG - 2016-06-07 15:20:58 --> Total execution time: 0.0514
INFO - 2016-06-07 15:21:29 --> Config Class Initialized
INFO - 2016-06-07 15:21:29 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:21:29 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:21:29 --> Utf8 Class Initialized
INFO - 2016-06-07 15:21:29 --> URI Class Initialized
INFO - 2016-06-07 15:21:29 --> Router Class Initialized
INFO - 2016-06-07 15:21:29 --> Output Class Initialized
INFO - 2016-06-07 15:21:29 --> Security Class Initialized
DEBUG - 2016-06-07 15:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:21:29 --> Input Class Initialized
INFO - 2016-06-07 15:21:29 --> Language Class Initialized
INFO - 2016-06-07 15:21:29 --> Loader Class Initialized
INFO - 2016-06-07 15:21:29 --> Helper loaded: form_helper
INFO - 2016-06-07 15:21:29 --> Database Driver Class Initialized
INFO - 2016-06-07 15:21:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:21:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:21:29 --> Email Class Initialized
INFO - 2016-06-07 15:21:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:21:29 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:21:29 --> Helper loaded: language_helper
INFO - 2016-06-07 15:21:29 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:21:29 --> Model Class Initialized
INFO - 2016-06-07 15:21:29 --> Helper loaded: date_helper
INFO - 2016-06-07 15:21:29 --> Controller Class Initialized
INFO - 2016-06-07 15:21:29 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:21:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:21:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:21:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:21:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:21:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:21:29 --> Model Class Initialized
INFO - 2016-06-07 15:21:29 --> Form Validation Class Initialized
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:21:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:21:29 --> Final output sent to browser
DEBUG - 2016-06-07 15:21:29 --> Total execution time: 0.0582
INFO - 2016-06-07 15:21:37 --> Config Class Initialized
INFO - 2016-06-07 15:21:37 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:21:37 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:21:37 --> Utf8 Class Initialized
INFO - 2016-06-07 15:21:37 --> URI Class Initialized
INFO - 2016-06-07 15:21:37 --> Router Class Initialized
INFO - 2016-06-07 15:21:37 --> Output Class Initialized
INFO - 2016-06-07 15:21:37 --> Security Class Initialized
DEBUG - 2016-06-07 15:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:21:37 --> Input Class Initialized
INFO - 2016-06-07 15:21:37 --> Language Class Initialized
INFO - 2016-06-07 15:21:37 --> Loader Class Initialized
INFO - 2016-06-07 15:21:37 --> Helper loaded: form_helper
INFO - 2016-06-07 15:21:37 --> Database Driver Class Initialized
INFO - 2016-06-07 15:21:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:21:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:21:37 --> Email Class Initialized
INFO - 2016-06-07 15:21:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:21:37 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:21:37 --> Helper loaded: language_helper
INFO - 2016-06-07 15:21:37 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:21:37 --> Model Class Initialized
INFO - 2016-06-07 15:21:37 --> Helper loaded: date_helper
INFO - 2016-06-07 15:21:37 --> Controller Class Initialized
INFO - 2016-06-07 15:21:37 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:21:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:21:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:21:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:21:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:21:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:21:37 --> Model Class Initialized
INFO - 2016-06-07 15:21:37 --> Form Validation Class Initialized
INFO - 2016-06-07 15:21:37 --> Final output sent to browser
DEBUG - 2016-06-07 15:21:37 --> Total execution time: 0.0601
INFO - 2016-06-07 15:21:57 --> Config Class Initialized
INFO - 2016-06-07 15:21:57 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:21:57 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:21:57 --> Utf8 Class Initialized
INFO - 2016-06-07 15:21:57 --> URI Class Initialized
INFO - 2016-06-07 15:21:57 --> Router Class Initialized
INFO - 2016-06-07 15:21:57 --> Output Class Initialized
INFO - 2016-06-07 15:21:57 --> Security Class Initialized
DEBUG - 2016-06-07 15:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:21:57 --> Input Class Initialized
INFO - 2016-06-07 15:21:57 --> Language Class Initialized
INFO - 2016-06-07 15:21:57 --> Loader Class Initialized
INFO - 2016-06-07 15:21:57 --> Helper loaded: form_helper
INFO - 2016-06-07 15:21:57 --> Database Driver Class Initialized
INFO - 2016-06-07 15:21:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:21:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:21:57 --> Email Class Initialized
INFO - 2016-06-07 15:21:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:21:57 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:21:57 --> Helper loaded: language_helper
INFO - 2016-06-07 15:21:57 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:21:57 --> Model Class Initialized
INFO - 2016-06-07 15:21:57 --> Helper loaded: date_helper
INFO - 2016-06-07 15:21:57 --> Controller Class Initialized
INFO - 2016-06-07 15:21:57 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:21:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:21:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:21:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:21:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:21:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:21:57 --> Model Class Initialized
INFO - 2016-06-07 15:21:57 --> Form Validation Class Initialized
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:21:57 --> Final output sent to browser
DEBUG - 2016-06-07 15:21:57 --> Total execution time: 0.0983
INFO - 2016-06-07 15:22:06 --> Config Class Initialized
INFO - 2016-06-07 15:22:06 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:22:06 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:22:06 --> Utf8 Class Initialized
INFO - 2016-06-07 15:22:06 --> URI Class Initialized
INFO - 2016-06-07 15:22:06 --> Router Class Initialized
INFO - 2016-06-07 15:22:06 --> Output Class Initialized
INFO - 2016-06-07 15:22:06 --> Security Class Initialized
DEBUG - 2016-06-07 15:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:22:06 --> Input Class Initialized
INFO - 2016-06-07 15:22:06 --> Language Class Initialized
INFO - 2016-06-07 15:22:06 --> Loader Class Initialized
INFO - 2016-06-07 15:22:06 --> Helper loaded: form_helper
INFO - 2016-06-07 15:22:06 --> Database Driver Class Initialized
INFO - 2016-06-07 15:22:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:22:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:22:06 --> Email Class Initialized
INFO - 2016-06-07 15:22:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:22:06 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:22:06 --> Helper loaded: language_helper
INFO - 2016-06-07 15:22:06 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:22:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:22:06 --> Model Class Initialized
INFO - 2016-06-07 15:22:06 --> Helper loaded: date_helper
INFO - 2016-06-07 15:22:06 --> Controller Class Initialized
INFO - 2016-06-07 15:22:06 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:22:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:22:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:22:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:22:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:22:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:22:06 --> Model Class Initialized
INFO - 2016-06-07 15:22:06 --> Form Validation Class Initialized
INFO - 2016-06-07 15:22:06 --> Final output sent to browser
DEBUG - 2016-06-07 15:22:06 --> Total execution time: 0.0307
INFO - 2016-06-07 15:22:30 --> Config Class Initialized
INFO - 2016-06-07 15:22:30 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:22:30 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:22:30 --> Utf8 Class Initialized
INFO - 2016-06-07 15:22:30 --> URI Class Initialized
INFO - 2016-06-07 15:22:30 --> Router Class Initialized
INFO - 2016-06-07 15:22:30 --> Output Class Initialized
INFO - 2016-06-07 15:22:30 --> Security Class Initialized
DEBUG - 2016-06-07 15:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:22:30 --> Input Class Initialized
INFO - 2016-06-07 15:22:30 --> Language Class Initialized
INFO - 2016-06-07 15:22:30 --> Loader Class Initialized
INFO - 2016-06-07 15:22:30 --> Helper loaded: form_helper
INFO - 2016-06-07 15:22:30 --> Database Driver Class Initialized
INFO - 2016-06-07 15:22:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:22:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:22:30 --> Email Class Initialized
INFO - 2016-06-07 15:22:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:22:30 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:22:30 --> Helper loaded: language_helper
INFO - 2016-06-07 15:22:30 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:22:30 --> Model Class Initialized
INFO - 2016-06-07 15:22:30 --> Helper loaded: date_helper
INFO - 2016-06-07 15:22:30 --> Controller Class Initialized
INFO - 2016-06-07 15:22:30 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:22:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:22:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:22:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:22:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:22:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:22:30 --> Model Class Initialized
INFO - 2016-06-07 15:22:30 --> Form Validation Class Initialized
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:22:30 --> Final output sent to browser
DEBUG - 2016-06-07 15:22:30 --> Total execution time: 0.0533
INFO - 2016-06-07 15:22:40 --> Config Class Initialized
INFO - 2016-06-07 15:22:40 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:22:40 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:22:40 --> Utf8 Class Initialized
INFO - 2016-06-07 15:22:40 --> URI Class Initialized
INFO - 2016-06-07 15:22:40 --> Router Class Initialized
INFO - 2016-06-07 15:22:40 --> Output Class Initialized
INFO - 2016-06-07 15:22:40 --> Security Class Initialized
DEBUG - 2016-06-07 15:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:22:40 --> Input Class Initialized
INFO - 2016-06-07 15:22:40 --> Language Class Initialized
INFO - 2016-06-07 15:22:40 --> Loader Class Initialized
INFO - 2016-06-07 15:22:40 --> Helper loaded: form_helper
INFO - 2016-06-07 15:22:40 --> Database Driver Class Initialized
INFO - 2016-06-07 15:22:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:22:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:22:40 --> Email Class Initialized
INFO - 2016-06-07 15:22:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:22:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:22:40 --> Helper loaded: language_helper
INFO - 2016-06-07 15:22:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:22:40 --> Model Class Initialized
INFO - 2016-06-07 15:22:40 --> Helper loaded: date_helper
INFO - 2016-06-07 15:22:40 --> Controller Class Initialized
INFO - 2016-06-07 15:22:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:22:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:22:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:22:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:22:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:22:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:22:40 --> Model Class Initialized
INFO - 2016-06-07 15:22:40 --> Form Validation Class Initialized
INFO - 2016-06-07 15:22:40 --> Final output sent to browser
DEBUG - 2016-06-07 15:22:40 --> Total execution time: 0.0796
INFO - 2016-06-07 15:24:02 --> Config Class Initialized
INFO - 2016-06-07 15:24:02 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:24:02 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:24:02 --> Utf8 Class Initialized
INFO - 2016-06-07 15:24:02 --> URI Class Initialized
INFO - 2016-06-07 15:24:02 --> Router Class Initialized
INFO - 2016-06-07 15:24:02 --> Output Class Initialized
INFO - 2016-06-07 15:24:02 --> Security Class Initialized
DEBUG - 2016-06-07 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:24:02 --> Input Class Initialized
INFO - 2016-06-07 15:24:02 --> Language Class Initialized
INFO - 2016-06-07 15:24:02 --> Loader Class Initialized
INFO - 2016-06-07 15:24:02 --> Helper loaded: form_helper
INFO - 2016-06-07 15:24:02 --> Database Driver Class Initialized
INFO - 2016-06-07 15:24:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:24:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:24:02 --> Email Class Initialized
INFO - 2016-06-07 15:24:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:24:02 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:24:02 --> Helper loaded: language_helper
INFO - 2016-06-07 15:24:02 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:24:02 --> Model Class Initialized
INFO - 2016-06-07 15:24:02 --> Helper loaded: date_helper
INFO - 2016-06-07 15:24:02 --> Controller Class Initialized
INFO - 2016-06-07 15:24:02 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:24:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:24:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:24:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:24:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:24:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:24:02 --> Model Class Initialized
INFO - 2016-06-07 15:24:02 --> Form Validation Class Initialized
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:24:02 --> Final output sent to browser
DEBUG - 2016-06-07 15:24:02 --> Total execution time: 0.0563
INFO - 2016-06-07 15:24:08 --> Config Class Initialized
INFO - 2016-06-07 15:24:08 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:24:08 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:24:08 --> Utf8 Class Initialized
INFO - 2016-06-07 15:24:08 --> URI Class Initialized
INFO - 2016-06-07 15:24:08 --> Router Class Initialized
INFO - 2016-06-07 15:24:08 --> Output Class Initialized
INFO - 2016-06-07 15:24:08 --> Security Class Initialized
DEBUG - 2016-06-07 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:24:08 --> Input Class Initialized
INFO - 2016-06-07 15:24:08 --> Language Class Initialized
INFO - 2016-06-07 15:24:08 --> Loader Class Initialized
INFO - 2016-06-07 15:24:08 --> Helper loaded: form_helper
INFO - 2016-06-07 15:24:08 --> Database Driver Class Initialized
INFO - 2016-06-07 15:24:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:24:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:24:08 --> Email Class Initialized
INFO - 2016-06-07 15:24:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:24:08 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:24:08 --> Helper loaded: language_helper
INFO - 2016-06-07 15:24:08 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:24:08 --> Model Class Initialized
INFO - 2016-06-07 15:24:08 --> Helper loaded: date_helper
INFO - 2016-06-07 15:24:08 --> Controller Class Initialized
INFO - 2016-06-07 15:24:08 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:24:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:24:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:24:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:24:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:24:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:24:08 --> Model Class Initialized
INFO - 2016-06-07 15:24:08 --> Form Validation Class Initialized
INFO - 2016-06-07 15:24:08 --> Final output sent to browser
DEBUG - 2016-06-07 15:24:08 --> Total execution time: 0.0436
INFO - 2016-06-07 15:31:58 --> Config Class Initialized
INFO - 2016-06-07 15:31:58 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:31:58 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:31:58 --> Utf8 Class Initialized
INFO - 2016-06-07 15:31:58 --> URI Class Initialized
INFO - 2016-06-07 15:31:58 --> Router Class Initialized
INFO - 2016-06-07 15:31:58 --> Output Class Initialized
INFO - 2016-06-07 15:31:58 --> Security Class Initialized
DEBUG - 2016-06-07 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:31:58 --> Input Class Initialized
INFO - 2016-06-07 15:31:58 --> Language Class Initialized
INFO - 2016-06-07 15:31:58 --> Loader Class Initialized
INFO - 2016-06-07 15:31:58 --> Helper loaded: form_helper
INFO - 2016-06-07 15:31:58 --> Database Driver Class Initialized
INFO - 2016-06-07 15:31:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:31:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:31:58 --> Email Class Initialized
INFO - 2016-06-07 15:31:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:31:58 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:31:58 --> Helper loaded: language_helper
INFO - 2016-06-07 15:31:58 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:31:58 --> Model Class Initialized
INFO - 2016-06-07 15:31:58 --> Helper loaded: date_helper
INFO - 2016-06-07 15:31:58 --> Controller Class Initialized
INFO - 2016-06-07 15:31:58 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:31:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:31:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:31:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:31:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:31:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:31:58 --> Model Class Initialized
INFO - 2016-06-07 15:31:58 --> Form Validation Class Initialized
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:31:58 --> Final output sent to browser
DEBUG - 2016-06-07 15:31:58 --> Total execution time: 0.0756
INFO - 2016-06-07 15:32:07 --> Config Class Initialized
INFO - 2016-06-07 15:32:07 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:32:07 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:32:07 --> Utf8 Class Initialized
INFO - 2016-06-07 15:32:07 --> URI Class Initialized
INFO - 2016-06-07 15:32:07 --> Router Class Initialized
INFO - 2016-06-07 15:32:07 --> Output Class Initialized
INFO - 2016-06-07 15:32:07 --> Security Class Initialized
DEBUG - 2016-06-07 15:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:32:07 --> Input Class Initialized
INFO - 2016-06-07 15:32:07 --> Language Class Initialized
INFO - 2016-06-07 15:32:07 --> Loader Class Initialized
INFO - 2016-06-07 15:32:07 --> Helper loaded: form_helper
INFO - 2016-06-07 15:32:07 --> Database Driver Class Initialized
INFO - 2016-06-07 15:32:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:32:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:32:08 --> Email Class Initialized
INFO - 2016-06-07 15:32:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:32:08 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:32:08 --> Helper loaded: language_helper
INFO - 2016-06-07 15:32:08 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:32:08 --> Model Class Initialized
INFO - 2016-06-07 15:32:08 --> Helper loaded: date_helper
INFO - 2016-06-07 15:32:08 --> Controller Class Initialized
INFO - 2016-06-07 15:32:08 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:32:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:32:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:32:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:32:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:32:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:32:08 --> Model Class Initialized
INFO - 2016-06-07 15:32:08 --> Form Validation Class Initialized
INFO - 2016-06-07 15:32:08 --> Final output sent to browser
DEBUG - 2016-06-07 15:32:08 --> Total execution time: 0.1639
INFO - 2016-06-07 15:54:24 --> Config Class Initialized
INFO - 2016-06-07 15:54:24 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:54:24 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:54:24 --> Utf8 Class Initialized
INFO - 2016-06-07 15:54:24 --> URI Class Initialized
INFO - 2016-06-07 15:54:24 --> Router Class Initialized
INFO - 2016-06-07 15:54:24 --> Output Class Initialized
INFO - 2016-06-07 15:54:24 --> Security Class Initialized
DEBUG - 2016-06-07 15:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:54:24 --> Input Class Initialized
INFO - 2016-06-07 15:54:24 --> Language Class Initialized
INFO - 2016-06-07 15:54:24 --> Loader Class Initialized
INFO - 2016-06-07 15:54:24 --> Helper loaded: form_helper
INFO - 2016-06-07 15:54:24 --> Database Driver Class Initialized
INFO - 2016-06-07 15:54:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:54:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:54:24 --> Email Class Initialized
INFO - 2016-06-07 15:54:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:54:24 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:54:25 --> Helper loaded: language_helper
INFO - 2016-06-07 15:54:25 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:54:25 --> Model Class Initialized
INFO - 2016-06-07 15:54:25 --> Helper loaded: date_helper
INFO - 2016-06-07 15:54:25 --> Controller Class Initialized
INFO - 2016-06-07 15:54:25 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:54:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:54:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:54:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:54:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:54:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:54:25 --> Model Class Initialized
INFO - 2016-06-07 15:54:25 --> Form Validation Class Initialized
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-07 15:54:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:54:25 --> Final output sent to browser
DEBUG - 2016-06-07 15:54:25 --> Total execution time: 0.1077
INFO - 2016-06-07 15:54:29 --> Config Class Initialized
INFO - 2016-06-07 15:54:29 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:54:29 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:54:29 --> Utf8 Class Initialized
INFO - 2016-06-07 15:54:29 --> URI Class Initialized
INFO - 2016-06-07 15:54:29 --> Router Class Initialized
INFO - 2016-06-07 15:54:29 --> Output Class Initialized
INFO - 2016-06-07 15:54:29 --> Security Class Initialized
DEBUG - 2016-06-07 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:54:29 --> Input Class Initialized
INFO - 2016-06-07 15:54:29 --> Language Class Initialized
INFO - 2016-06-07 15:54:29 --> Loader Class Initialized
INFO - 2016-06-07 15:54:29 --> Helper loaded: form_helper
INFO - 2016-06-07 15:54:29 --> Database Driver Class Initialized
INFO - 2016-06-07 15:54:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:54:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:54:29 --> Email Class Initialized
INFO - 2016-06-07 15:54:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:54:29 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:54:29 --> Helper loaded: language_helper
INFO - 2016-06-07 15:54:29 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:54:29 --> Model Class Initialized
INFO - 2016-06-07 15:54:29 --> Helper loaded: date_helper
INFO - 2016-06-07 15:54:29 --> Controller Class Initialized
INFO - 2016-06-07 15:54:29 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:54:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:54:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:54:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:54:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:54:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:54:29 --> Model Class Initialized
INFO - 2016-06-07 15:54:29 --> Form Validation Class Initialized
INFO - 2016-06-07 15:54:29 --> Final output sent to browser
DEBUG - 2016-06-07 15:54:29 --> Total execution time: 0.0532
INFO - 2016-06-07 15:57:06 --> Config Class Initialized
INFO - 2016-06-07 15:57:06 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:57:06 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:57:06 --> Utf8 Class Initialized
INFO - 2016-06-07 15:57:06 --> URI Class Initialized
INFO - 2016-06-07 15:57:06 --> Router Class Initialized
INFO - 2016-06-07 15:57:06 --> Output Class Initialized
INFO - 2016-06-07 15:57:06 --> Security Class Initialized
DEBUG - 2016-06-07 15:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:57:06 --> Input Class Initialized
INFO - 2016-06-07 15:57:06 --> Language Class Initialized
INFO - 2016-06-07 15:57:06 --> Loader Class Initialized
INFO - 2016-06-07 15:57:06 --> Helper loaded: form_helper
INFO - 2016-06-07 15:57:06 --> Database Driver Class Initialized
INFO - 2016-06-07 15:57:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:57:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:57:06 --> Email Class Initialized
INFO - 2016-06-07 15:57:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:57:06 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:57:06 --> Helper loaded: language_helper
INFO - 2016-06-07 15:57:06 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:06 --> Model Class Initialized
INFO - 2016-06-07 15:57:06 --> Helper loaded: date_helper
INFO - 2016-06-07 15:57:06 --> Controller Class Initialized
INFO - 2016-06-07 15:57:06 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:57:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:57:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:57:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:57:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:57:06 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 15:57:06 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:06 --> Form Validation Class Initialized
INFO - 2016-06-07 15:57:07 --> Config Class Initialized
INFO - 2016-06-07 15:57:07 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:57:07 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:57:07 --> Utf8 Class Initialized
INFO - 2016-06-07 15:57:07 --> URI Class Initialized
INFO - 2016-06-07 15:57:07 --> Router Class Initialized
INFO - 2016-06-07 15:57:07 --> Output Class Initialized
INFO - 2016-06-07 15:57:07 --> Security Class Initialized
DEBUG - 2016-06-07 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:57:07 --> Input Class Initialized
INFO - 2016-06-07 15:57:07 --> Language Class Initialized
INFO - 2016-06-07 15:57:07 --> Loader Class Initialized
INFO - 2016-06-07 15:57:07 --> Helper loaded: form_helper
INFO - 2016-06-07 15:57:07 --> Database Driver Class Initialized
INFO - 2016-06-07 15:57:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:57:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:57:07 --> Email Class Initialized
INFO - 2016-06-07 15:57:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:57:07 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:57:07 --> Helper loaded: language_helper
INFO - 2016-06-07 15:57:07 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:07 --> Model Class Initialized
INFO - 2016-06-07 15:57:07 --> Helper loaded: date_helper
INFO - 2016-06-07 15:57:07 --> Controller Class Initialized
INFO - 2016-06-07 15:57:07 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:57:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:57:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:57:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:57:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:57:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 15:57:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:07 --> Form Validation Class Initialized
DEBUG - 2016-06-07 15:57:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-07 15:57:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-07 15:57:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-07 15:57:07 --> Final output sent to browser
DEBUG - 2016-06-07 15:57:07 --> Total execution time: 0.0133
INFO - 2016-06-07 15:57:23 --> Config Class Initialized
INFO - 2016-06-07 15:57:23 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:57:23 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:57:23 --> Utf8 Class Initialized
INFO - 2016-06-07 15:57:23 --> URI Class Initialized
INFO - 2016-06-07 15:57:23 --> Router Class Initialized
INFO - 2016-06-07 15:57:23 --> Output Class Initialized
INFO - 2016-06-07 15:57:23 --> Security Class Initialized
DEBUG - 2016-06-07 15:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:57:23 --> Input Class Initialized
INFO - 2016-06-07 15:57:23 --> Language Class Initialized
INFO - 2016-06-07 15:57:23 --> Loader Class Initialized
INFO - 2016-06-07 15:57:23 --> Helper loaded: form_helper
INFO - 2016-06-07 15:57:23 --> Database Driver Class Initialized
INFO - 2016-06-07 15:57:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:57:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:57:23 --> Email Class Initialized
INFO - 2016-06-07 15:57:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:57:23 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:57:23 --> Helper loaded: language_helper
INFO - 2016-06-07 15:57:23 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:57:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:23 --> Model Class Initialized
INFO - 2016-06-07 15:57:23 --> Helper loaded: date_helper
INFO - 2016-06-07 15:57:23 --> Controller Class Initialized
INFO - 2016-06-07 15:57:23 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:57:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:57:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:57:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:57:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:57:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 15:57:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:23 --> Form Validation Class Initialized
DEBUG - 2016-06-07 15:57:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:29 --> Config Class Initialized
INFO - 2016-06-07 15:57:29 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:57:29 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:57:29 --> Utf8 Class Initialized
INFO - 2016-06-07 15:57:29 --> URI Class Initialized
DEBUG - 2016-06-07 15:57:29 --> No URI present. Default controller set.
INFO - 2016-06-07 15:57:29 --> Router Class Initialized
INFO - 2016-06-07 15:57:29 --> Output Class Initialized
INFO - 2016-06-07 15:57:29 --> Security Class Initialized
DEBUG - 2016-06-07 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:57:29 --> Input Class Initialized
INFO - 2016-06-07 15:57:29 --> Language Class Initialized
INFO - 2016-06-07 15:57:29 --> Loader Class Initialized
INFO - 2016-06-07 15:57:29 --> Helper loaded: form_helper
INFO - 2016-06-07 15:57:29 --> Database Driver Class Initialized
INFO - 2016-06-07 15:57:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:57:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:57:29 --> Email Class Initialized
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:57:29 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:57:29 --> Helper loaded: language_helper
INFO - 2016-06-07 15:57:29 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:29 --> Model Class Initialized
INFO - 2016-06-07 15:57:29 --> Helper loaded: date_helper
INFO - 2016-06-07 15:57:29 --> Controller Class Initialized
INFO - 2016-06-07 15:57:29 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:57:29 --> Config Class Initialized
INFO - 2016-06-07 15:57:29 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:57:29 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:57:29 --> Utf8 Class Initialized
INFO - 2016-06-07 15:57:29 --> URI Class Initialized
INFO - 2016-06-07 15:57:29 --> Router Class Initialized
INFO - 2016-06-07 15:57:29 --> Output Class Initialized
INFO - 2016-06-07 15:57:29 --> Security Class Initialized
DEBUG - 2016-06-07 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:57:29 --> Input Class Initialized
INFO - 2016-06-07 15:57:29 --> Language Class Initialized
INFO - 2016-06-07 15:57:29 --> Loader Class Initialized
INFO - 2016-06-07 15:57:29 --> Helper loaded: form_helper
INFO - 2016-06-07 15:57:29 --> Database Driver Class Initialized
INFO - 2016-06-07 15:57:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:57:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:57:29 --> Email Class Initialized
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:57:29 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:57:29 --> Helper loaded: language_helper
INFO - 2016-06-07 15:57:29 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:57:29 --> Model Class Initialized
INFO - 2016-06-07 15:57:29 --> Helper loaded: date_helper
INFO - 2016-06-07 15:57:29 --> Controller Class Initialized
INFO - 2016-06-07 15:57:29 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:57:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 15:57:29 --> Model Class Initialized
INFO - 2016-06-07 15:57:29 --> Form Validation Class Initialized
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-07 15:57:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:57:29 --> Final output sent to browser
DEBUG - 2016-06-07 15:57:29 --> Total execution time: 0.0605
INFO - 2016-06-07 15:59:22 --> Config Class Initialized
INFO - 2016-06-07 15:59:22 --> Hooks Class Initialized
DEBUG - 2016-06-07 15:59:22 --> UTF-8 Support Enabled
INFO - 2016-06-07 15:59:22 --> Utf8 Class Initialized
INFO - 2016-06-07 15:59:22 --> URI Class Initialized
INFO - 2016-06-07 15:59:22 --> Router Class Initialized
INFO - 2016-06-07 15:59:22 --> Output Class Initialized
INFO - 2016-06-07 15:59:22 --> Security Class Initialized
DEBUG - 2016-06-07 15:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 15:59:22 --> Input Class Initialized
INFO - 2016-06-07 15:59:22 --> Language Class Initialized
INFO - 2016-06-07 15:59:22 --> Loader Class Initialized
INFO - 2016-06-07 15:59:22 --> Helper loaded: form_helper
INFO - 2016-06-07 15:59:22 --> Database Driver Class Initialized
INFO - 2016-06-07 15:59:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 15:59:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 15:59:22 --> Email Class Initialized
INFO - 2016-06-07 15:59:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 15:59:22 --> Helper loaded: cookie_helper
INFO - 2016-06-07 15:59:22 --> Helper loaded: language_helper
INFO - 2016-06-07 15:59:22 --> Helper loaded: url_helper
DEBUG - 2016-06-07 15:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:59:22 --> Model Class Initialized
INFO - 2016-06-07 15:59:22 --> Helper loaded: date_helper
INFO - 2016-06-07 15:59:22 --> Controller Class Initialized
INFO - 2016-06-07 15:59:22 --> Helper loaded: languages_helper
INFO - 2016-06-07 15:59:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 15:59:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 15:59:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 15:59:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 15:59:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-07 15:59:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-07 15:59:22 --> Form Validation Class Initialized
INFO - 2016-06-07 15:59:22 --> Helper loaded: string_helper
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-06-07 15:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 15:59:22 --> Final output sent to browser
DEBUG - 2016-06-07 15:59:22 --> Total execution time: 0.0704
INFO - 2016-06-07 16:00:23 --> Config Class Initialized
INFO - 2016-06-07 16:00:23 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:00:23 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:00:23 --> Utf8 Class Initialized
INFO - 2016-06-07 16:00:23 --> URI Class Initialized
INFO - 2016-06-07 16:00:23 --> Router Class Initialized
INFO - 2016-06-07 16:00:23 --> Output Class Initialized
INFO - 2016-06-07 16:00:23 --> Security Class Initialized
DEBUG - 2016-06-07 16:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:00:23 --> Input Class Initialized
INFO - 2016-06-07 16:00:23 --> Language Class Initialized
INFO - 2016-06-07 16:00:23 --> Loader Class Initialized
INFO - 2016-06-07 16:00:23 --> Helper loaded: form_helper
INFO - 2016-06-07 16:00:23 --> Database Driver Class Initialized
INFO - 2016-06-07 16:00:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:00:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:00:23 --> Email Class Initialized
INFO - 2016-06-07 16:00:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:00:23 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:00:23 --> Helper loaded: language_helper
INFO - 2016-06-07 16:00:23 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:00:23 --> Model Class Initialized
INFO - 2016-06-07 16:00:23 --> Helper loaded: date_helper
INFO - 2016-06-07 16:00:23 --> Controller Class Initialized
INFO - 2016-06-07 16:00:23 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:00:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:00:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:00:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:00:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:00:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:00:23 --> Model Class Initialized
INFO - 2016-06-07 16:00:23 --> Form Validation Class Initialized
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-07 16:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:00:23 --> Final output sent to browser
DEBUG - 2016-06-07 16:00:23 --> Total execution time: 0.1274
INFO - 2016-06-07 16:00:46 --> Config Class Initialized
INFO - 2016-06-07 16:00:46 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:00:46 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:00:46 --> Utf8 Class Initialized
INFO - 2016-06-07 16:00:46 --> URI Class Initialized
INFO - 2016-06-07 16:00:46 --> Router Class Initialized
INFO - 2016-06-07 16:00:46 --> Output Class Initialized
INFO - 2016-06-07 16:00:46 --> Security Class Initialized
DEBUG - 2016-06-07 16:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:00:46 --> Input Class Initialized
INFO - 2016-06-07 16:00:46 --> Language Class Initialized
INFO - 2016-06-07 16:00:46 --> Loader Class Initialized
INFO - 2016-06-07 16:00:46 --> Helper loaded: form_helper
INFO - 2016-06-07 16:00:46 --> Database Driver Class Initialized
INFO - 2016-06-07 16:00:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:00:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:00:46 --> Email Class Initialized
INFO - 2016-06-07 16:00:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:00:46 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:00:46 --> Helper loaded: language_helper
INFO - 2016-06-07 16:00:46 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:00:46 --> Model Class Initialized
INFO - 2016-06-07 16:00:46 --> Helper loaded: date_helper
INFO - 2016-06-07 16:00:46 --> Controller Class Initialized
INFO - 2016-06-07 16:00:46 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:00:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:00:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:00:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:00:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:00:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:00:46 --> Model Class Initialized
INFO - 2016-06-07 16:00:46 --> Form Validation Class Initialized
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-07 16:00:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:00:46 --> Final output sent to browser
DEBUG - 2016-06-07 16:00:46 --> Total execution time: 0.0553
INFO - 2016-06-07 16:00:59 --> Config Class Initialized
INFO - 2016-06-07 16:00:59 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:00:59 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:00:59 --> Utf8 Class Initialized
INFO - 2016-06-07 16:00:59 --> URI Class Initialized
INFO - 2016-06-07 16:00:59 --> Router Class Initialized
INFO - 2016-06-07 16:00:59 --> Output Class Initialized
INFO - 2016-06-07 16:00:59 --> Security Class Initialized
DEBUG - 2016-06-07 16:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:00:59 --> Input Class Initialized
INFO - 2016-06-07 16:00:59 --> Language Class Initialized
INFO - 2016-06-07 16:00:59 --> Loader Class Initialized
INFO - 2016-06-07 16:00:59 --> Helper loaded: form_helper
INFO - 2016-06-07 16:00:59 --> Database Driver Class Initialized
INFO - 2016-06-07 16:00:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:00:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:00:59 --> Email Class Initialized
INFO - 2016-06-07 16:00:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:00:59 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:00:59 --> Helper loaded: language_helper
INFO - 2016-06-07 16:00:59 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:00:59 --> Model Class Initialized
INFO - 2016-06-07 16:00:59 --> Helper loaded: date_helper
INFO - 2016-06-07 16:00:59 --> Controller Class Initialized
INFO - 2016-06-07 16:00:59 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:00:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:00:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:00:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:00:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:00:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:00:59 --> Model Class Initialized
INFO - 2016-06-07 16:00:59 --> Form Validation Class Initialized
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-07 16:00:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:00:59 --> Final output sent to browser
DEBUG - 2016-06-07 16:00:59 --> Total execution time: 0.3020
INFO - 2016-06-07 16:01:29 --> Config Class Initialized
INFO - 2016-06-07 16:01:29 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:01:29 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:01:29 --> Utf8 Class Initialized
INFO - 2016-06-07 16:01:29 --> URI Class Initialized
INFO - 2016-06-07 16:01:29 --> Router Class Initialized
INFO - 2016-06-07 16:01:29 --> Output Class Initialized
INFO - 2016-06-07 16:01:29 --> Security Class Initialized
DEBUG - 2016-06-07 16:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:01:29 --> Input Class Initialized
INFO - 2016-06-07 16:01:29 --> Language Class Initialized
INFO - 2016-06-07 16:01:29 --> Loader Class Initialized
INFO - 2016-06-07 16:01:29 --> Helper loaded: form_helper
INFO - 2016-06-07 16:01:29 --> Database Driver Class Initialized
INFO - 2016-06-07 16:01:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:01:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:01:29 --> Email Class Initialized
INFO - 2016-06-07 16:01:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:01:29 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:01:29 --> Helper loaded: language_helper
INFO - 2016-06-07 16:01:29 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:01:29 --> Model Class Initialized
INFO - 2016-06-07 16:01:29 --> Helper loaded: date_helper
INFO - 2016-06-07 16:01:29 --> Controller Class Initialized
INFO - 2016-06-07 16:01:29 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:01:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:01:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:01:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:01:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:01:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:01:29 --> Model Class Initialized
INFO - 2016-06-07 16:01:29 --> Form Validation Class Initialized
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-07 16:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:01:29 --> Final output sent to browser
DEBUG - 2016-06-07 16:01:29 --> Total execution time: 0.0604
INFO - 2016-06-07 16:01:39 --> Config Class Initialized
INFO - 2016-06-07 16:01:39 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:01:39 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:01:39 --> Utf8 Class Initialized
INFO - 2016-06-07 16:01:39 --> URI Class Initialized
DEBUG - 2016-06-07 16:01:39 --> No URI present. Default controller set.
INFO - 2016-06-07 16:01:39 --> Router Class Initialized
INFO - 2016-06-07 16:01:39 --> Output Class Initialized
INFO - 2016-06-07 16:01:39 --> Security Class Initialized
DEBUG - 2016-06-07 16:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:01:39 --> Input Class Initialized
INFO - 2016-06-07 16:01:39 --> Language Class Initialized
INFO - 2016-06-07 16:01:39 --> Loader Class Initialized
INFO - 2016-06-07 16:01:39 --> Helper loaded: form_helper
INFO - 2016-06-07 16:01:39 --> Database Driver Class Initialized
INFO - 2016-06-07 16:01:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:01:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:01:39 --> Email Class Initialized
INFO - 2016-06-07 16:01:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:01:39 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:01:39 --> Helper loaded: language_helper
INFO - 2016-06-07 16:01:39 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:01:39 --> Model Class Initialized
INFO - 2016-06-07 16:01:39 --> Helper loaded: date_helper
INFO - 2016-06-07 16:01:39 --> Controller Class Initialized
INFO - 2016-06-07 16:01:39 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:01:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:01:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:01:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:01:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:01:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:01:40 --> Config Class Initialized
INFO - 2016-06-07 16:01:40 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:01:40 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:01:40 --> Utf8 Class Initialized
INFO - 2016-06-07 16:01:40 --> URI Class Initialized
INFO - 2016-06-07 16:01:40 --> Router Class Initialized
INFO - 2016-06-07 16:01:40 --> Output Class Initialized
INFO - 2016-06-07 16:01:40 --> Security Class Initialized
DEBUG - 2016-06-07 16:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:01:40 --> Input Class Initialized
INFO - 2016-06-07 16:01:40 --> Language Class Initialized
INFO - 2016-06-07 16:01:40 --> Loader Class Initialized
INFO - 2016-06-07 16:01:40 --> Helper loaded: form_helper
INFO - 2016-06-07 16:01:40 --> Database Driver Class Initialized
INFO - 2016-06-07 16:01:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:01:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:01:40 --> Email Class Initialized
INFO - 2016-06-07 16:01:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:01:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:01:40 --> Helper loaded: language_helper
INFO - 2016-06-07 16:01:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:01:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:01:40 --> Model Class Initialized
INFO - 2016-06-07 16:01:40 --> Helper loaded: date_helper
INFO - 2016-06-07 16:01:40 --> Controller Class Initialized
INFO - 2016-06-07 16:01:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:01:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:01:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:01:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:01:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:01:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:01:40 --> Model Class Initialized
INFO - 2016-06-07 16:01:40 --> Form Validation Class Initialized
INFO - 2016-06-07 16:01:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:01:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:01:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-07 16:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:01:41 --> Final output sent to browser
DEBUG - 2016-06-07 16:01:41 --> Total execution time: 0.0246
INFO - 2016-06-07 16:04:07 --> Config Class Initialized
INFO - 2016-06-07 16:04:07 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:04:07 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:04:07 --> Utf8 Class Initialized
INFO - 2016-06-07 16:04:07 --> URI Class Initialized
INFO - 2016-06-07 16:04:07 --> Router Class Initialized
INFO - 2016-06-07 16:04:07 --> Output Class Initialized
INFO - 2016-06-07 16:04:07 --> Security Class Initialized
DEBUG - 2016-06-07 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:04:07 --> Input Class Initialized
INFO - 2016-06-07 16:04:07 --> Language Class Initialized
INFO - 2016-06-07 16:04:07 --> Loader Class Initialized
INFO - 2016-06-07 16:04:07 --> Helper loaded: form_helper
INFO - 2016-06-07 16:04:07 --> Database Driver Class Initialized
INFO - 2016-06-07 16:04:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:04:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:04:07 --> Email Class Initialized
INFO - 2016-06-07 16:04:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:04:07 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:04:07 --> Helper loaded: language_helper
INFO - 2016-06-07 16:04:07 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:04:07 --> Model Class Initialized
INFO - 2016-06-07 16:04:07 --> Helper loaded: date_helper
INFO - 2016-06-07 16:04:07 --> Controller Class Initialized
INFO - 2016-06-07 16:04:07 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:04:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:04:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:04:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:04:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:04:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:04:07 --> Model Class Initialized
INFO - 2016-06-07 16:04:07 --> Form Validation Class Initialized
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-07 16:04:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:04:07 --> Final output sent to browser
DEBUG - 2016-06-07 16:04:07 --> Total execution time: 0.0527
INFO - 2016-06-07 16:08:21 --> Config Class Initialized
INFO - 2016-06-07 16:08:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:08:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:08:21 --> Utf8 Class Initialized
INFO - 2016-06-07 16:08:21 --> URI Class Initialized
INFO - 2016-06-07 16:08:21 --> Router Class Initialized
INFO - 2016-06-07 16:08:21 --> Output Class Initialized
INFO - 2016-06-07 16:08:21 --> Security Class Initialized
DEBUG - 2016-06-07 16:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:08:21 --> Input Class Initialized
INFO - 2016-06-07 16:08:21 --> Language Class Initialized
INFO - 2016-06-07 16:08:21 --> Loader Class Initialized
INFO - 2016-06-07 16:08:21 --> Helper loaded: form_helper
INFO - 2016-06-07 16:08:21 --> Database Driver Class Initialized
INFO - 2016-06-07 16:08:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:08:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:08:21 --> Email Class Initialized
INFO - 2016-06-07 16:08:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:08:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:08:21 --> Helper loaded: language_helper
INFO - 2016-06-07 16:08:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:08:21 --> Model Class Initialized
INFO - 2016-06-07 16:08:21 --> Helper loaded: date_helper
INFO - 2016-06-07 16:08:21 --> Controller Class Initialized
INFO - 2016-06-07 16:08:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:08:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:08:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:08:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:08:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:08:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:08:21 --> Model Class Initialized
INFO - 2016-06-07 16:08:21 --> Form Validation Class Initialized
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-07 16:08:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:08:21 --> Final output sent to browser
DEBUG - 2016-06-07 16:08:21 --> Total execution time: 0.0633
INFO - 2016-06-07 16:08:28 --> Config Class Initialized
INFO - 2016-06-07 16:08:28 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:08:28 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:08:28 --> Utf8 Class Initialized
INFO - 2016-06-07 16:08:28 --> URI Class Initialized
INFO - 2016-06-07 16:08:28 --> Router Class Initialized
INFO - 2016-06-07 16:08:28 --> Output Class Initialized
INFO - 2016-06-07 16:08:28 --> Security Class Initialized
DEBUG - 2016-06-07 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:08:28 --> Input Class Initialized
INFO - 2016-06-07 16:08:28 --> Language Class Initialized
INFO - 2016-06-07 16:08:28 --> Loader Class Initialized
INFO - 2016-06-07 16:08:28 --> Helper loaded: form_helper
INFO - 2016-06-07 16:08:28 --> Database Driver Class Initialized
INFO - 2016-06-07 16:08:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:08:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:08:28 --> Email Class Initialized
INFO - 2016-06-07 16:08:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:08:28 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:08:28 --> Helper loaded: language_helper
INFO - 2016-06-07 16:08:28 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:08:28 --> Model Class Initialized
INFO - 2016-06-07 16:08:28 --> Helper loaded: date_helper
INFO - 2016-06-07 16:08:28 --> Controller Class Initialized
INFO - 2016-06-07 16:08:28 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:08:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:08:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:08:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:08:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:08:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:08:28 --> Model Class Initialized
INFO - 2016-06-07 16:08:28 --> Form Validation Class Initialized
ERROR - 2016-06-07 16:08:28 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/controllers/Diabet.php 458
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:08:28 --> Final output sent to browser
DEBUG - 2016-06-07 16:08:28 --> Total execution time: 0.0760
INFO - 2016-06-07 16:08:57 --> Config Class Initialized
INFO - 2016-06-07 16:08:57 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:08:57 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:08:57 --> Utf8 Class Initialized
INFO - 2016-06-07 16:08:57 --> URI Class Initialized
INFO - 2016-06-07 16:08:57 --> Router Class Initialized
INFO - 2016-06-07 16:08:57 --> Output Class Initialized
INFO - 2016-06-07 16:08:57 --> Security Class Initialized
DEBUG - 2016-06-07 16:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:08:57 --> Input Class Initialized
INFO - 2016-06-07 16:08:57 --> Language Class Initialized
INFO - 2016-06-07 16:08:57 --> Loader Class Initialized
INFO - 2016-06-07 16:08:57 --> Helper loaded: form_helper
INFO - 2016-06-07 16:08:57 --> Database Driver Class Initialized
INFO - 2016-06-07 16:08:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:08:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:08:57 --> Email Class Initialized
INFO - 2016-06-07 16:08:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:08:57 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:08:57 --> Helper loaded: language_helper
INFO - 2016-06-07 16:08:57 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:08:57 --> Model Class Initialized
INFO - 2016-06-07 16:08:57 --> Helper loaded: date_helper
INFO - 2016-06-07 16:08:57 --> Controller Class Initialized
INFO - 2016-06-07 16:08:57 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:08:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:08:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:08:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:08:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:08:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:08:57 --> Model Class Initialized
INFO - 2016-06-07 16:08:57 --> Form Validation Class Initialized
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:08:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:08:57 --> Final output sent to browser
DEBUG - 2016-06-07 16:08:57 --> Total execution time: 0.0627
INFO - 2016-06-07 16:19:54 --> Config Class Initialized
INFO - 2016-06-07 16:19:54 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:19:54 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:19:54 --> Utf8 Class Initialized
INFO - 2016-06-07 16:19:54 --> URI Class Initialized
INFO - 2016-06-07 16:19:54 --> Router Class Initialized
INFO - 2016-06-07 16:19:54 --> Output Class Initialized
INFO - 2016-06-07 16:19:54 --> Security Class Initialized
DEBUG - 2016-06-07 16:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:19:54 --> Input Class Initialized
INFO - 2016-06-07 16:19:54 --> Language Class Initialized
INFO - 2016-06-07 16:19:54 --> Loader Class Initialized
INFO - 2016-06-07 16:19:54 --> Helper loaded: form_helper
INFO - 2016-06-07 16:19:54 --> Database Driver Class Initialized
INFO - 2016-06-07 16:19:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:19:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:19:54 --> Email Class Initialized
INFO - 2016-06-07 16:19:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:19:54 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:19:54 --> Helper loaded: language_helper
INFO - 2016-06-07 16:19:54 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:19:54 --> Model Class Initialized
INFO - 2016-06-07 16:19:54 --> Helper loaded: date_helper
INFO - 2016-06-07 16:19:54 --> Controller Class Initialized
INFO - 2016-06-07 16:19:54 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:19:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:19:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:19:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:19:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:19:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:19:54 --> Model Class Initialized
INFO - 2016-06-07 16:19:54 --> Form Validation Class Initialized
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:19:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:19:54 --> Final output sent to browser
DEBUG - 2016-06-07 16:19:54 --> Total execution time: 0.0532
INFO - 2016-06-07 16:20:21 --> Config Class Initialized
INFO - 2016-06-07 16:20:21 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:20:21 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:20:21 --> Utf8 Class Initialized
INFO - 2016-06-07 16:20:21 --> URI Class Initialized
INFO - 2016-06-07 16:20:21 --> Router Class Initialized
INFO - 2016-06-07 16:20:21 --> Output Class Initialized
INFO - 2016-06-07 16:20:21 --> Security Class Initialized
DEBUG - 2016-06-07 16:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:20:21 --> Input Class Initialized
INFO - 2016-06-07 16:20:21 --> Language Class Initialized
INFO - 2016-06-07 16:20:21 --> Loader Class Initialized
INFO - 2016-06-07 16:20:21 --> Helper loaded: form_helper
INFO - 2016-06-07 16:20:21 --> Database Driver Class Initialized
INFO - 2016-06-07 16:20:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:20:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:20:21 --> Email Class Initialized
INFO - 2016-06-07 16:20:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:20:21 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:20:21 --> Helper loaded: language_helper
INFO - 2016-06-07 16:20:21 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:20:21 --> Model Class Initialized
INFO - 2016-06-07 16:20:21 --> Helper loaded: date_helper
INFO - 2016-06-07 16:20:21 --> Controller Class Initialized
INFO - 2016-06-07 16:20:21 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:20:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:20:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:20:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:20:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:20:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:20:21 --> Model Class Initialized
INFO - 2016-06-07 16:20:21 --> Form Validation Class Initialized
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:20:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:20:21 --> Final output sent to browser
DEBUG - 2016-06-07 16:20:21 --> Total execution time: 0.0370
INFO - 2016-06-07 16:20:43 --> Config Class Initialized
INFO - 2016-06-07 16:20:43 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:20:43 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:20:43 --> Utf8 Class Initialized
INFO - 2016-06-07 16:20:43 --> URI Class Initialized
INFO - 2016-06-07 16:20:43 --> Router Class Initialized
INFO - 2016-06-07 16:20:43 --> Output Class Initialized
INFO - 2016-06-07 16:20:43 --> Security Class Initialized
DEBUG - 2016-06-07 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:20:43 --> Input Class Initialized
INFO - 2016-06-07 16:20:43 --> Language Class Initialized
INFO - 2016-06-07 16:20:43 --> Loader Class Initialized
INFO - 2016-06-07 16:20:43 --> Helper loaded: form_helper
INFO - 2016-06-07 16:20:43 --> Database Driver Class Initialized
INFO - 2016-06-07 16:20:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:20:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:20:43 --> Email Class Initialized
INFO - 2016-06-07 16:20:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:20:43 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:20:43 --> Helper loaded: language_helper
INFO - 2016-06-07 16:20:43 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:20:43 --> Model Class Initialized
INFO - 2016-06-07 16:20:43 --> Helper loaded: date_helper
INFO - 2016-06-07 16:20:43 --> Controller Class Initialized
INFO - 2016-06-07 16:20:43 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:20:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:20:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:20:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:20:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:20:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:20:43 --> Model Class Initialized
INFO - 2016-06-07 16:20:43 --> Form Validation Class Initialized
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:20:43 --> Final output sent to browser
DEBUG - 2016-06-07 16:20:43 --> Total execution time: 0.0236
INFO - 2016-06-07 16:28:32 --> Config Class Initialized
INFO - 2016-06-07 16:28:32 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:28:32 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:28:32 --> Utf8 Class Initialized
INFO - 2016-06-07 16:28:32 --> URI Class Initialized
INFO - 2016-06-07 16:28:32 --> Router Class Initialized
INFO - 2016-06-07 16:28:32 --> Output Class Initialized
INFO - 2016-06-07 16:28:32 --> Security Class Initialized
DEBUG - 2016-06-07 16:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:28:32 --> Input Class Initialized
INFO - 2016-06-07 16:28:32 --> Language Class Initialized
INFO - 2016-06-07 16:28:32 --> Loader Class Initialized
INFO - 2016-06-07 16:28:32 --> Helper loaded: form_helper
INFO - 2016-06-07 16:28:32 --> Database Driver Class Initialized
INFO - 2016-06-07 16:28:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:28:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:28:32 --> Email Class Initialized
INFO - 2016-06-07 16:28:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:28:32 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:28:32 --> Helper loaded: language_helper
INFO - 2016-06-07 16:28:32 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:28:32 --> Model Class Initialized
INFO - 2016-06-07 16:28:32 --> Helper loaded: date_helper
INFO - 2016-06-07 16:28:32 --> Controller Class Initialized
INFO - 2016-06-07 16:28:32 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:28:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:28:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:28:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:28:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:28:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:28:32 --> Model Class Initialized
INFO - 2016-06-07 16:28:32 --> Form Validation Class Initialized
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:28:32 --> Final output sent to browser
DEBUG - 2016-06-07 16:28:32 --> Total execution time: 0.0647
INFO - 2016-06-07 16:38:15 --> Config Class Initialized
INFO - 2016-06-07 16:38:15 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:38:15 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:38:15 --> Utf8 Class Initialized
INFO - 2016-06-07 16:38:15 --> URI Class Initialized
INFO - 2016-06-07 16:38:15 --> Router Class Initialized
INFO - 2016-06-07 16:38:15 --> Output Class Initialized
INFO - 2016-06-07 16:38:15 --> Security Class Initialized
DEBUG - 2016-06-07 16:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:38:15 --> Input Class Initialized
INFO - 2016-06-07 16:38:15 --> Language Class Initialized
INFO - 2016-06-07 16:38:15 --> Loader Class Initialized
INFO - 2016-06-07 16:38:15 --> Helper loaded: form_helper
INFO - 2016-06-07 16:38:15 --> Database Driver Class Initialized
INFO - 2016-06-07 16:38:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:38:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:38:15 --> Email Class Initialized
INFO - 2016-06-07 16:38:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:38:15 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:38:15 --> Helper loaded: language_helper
INFO - 2016-06-07 16:38:15 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:38:15 --> Model Class Initialized
INFO - 2016-06-07 16:38:15 --> Helper loaded: date_helper
INFO - 2016-06-07 16:38:15 --> Controller Class Initialized
INFO - 2016-06-07 16:38:15 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:38:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:38:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:38:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:38:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:38:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:38:15 --> Model Class Initialized
INFO - 2016-06-07 16:38:15 --> Form Validation Class Initialized
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:38:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:38:15 --> Final output sent to browser
DEBUG - 2016-06-07 16:38:15 --> Total execution time: 0.1007
INFO - 2016-06-07 16:40:50 --> Config Class Initialized
INFO - 2016-06-07 16:40:50 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:40:50 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:40:50 --> Utf8 Class Initialized
INFO - 2016-06-07 16:40:50 --> URI Class Initialized
INFO - 2016-06-07 16:40:50 --> Router Class Initialized
INFO - 2016-06-07 16:40:50 --> Output Class Initialized
INFO - 2016-06-07 16:40:50 --> Security Class Initialized
DEBUG - 2016-06-07 16:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:40:50 --> Input Class Initialized
INFO - 2016-06-07 16:40:50 --> Language Class Initialized
INFO - 2016-06-07 16:40:50 --> Loader Class Initialized
INFO - 2016-06-07 16:40:50 --> Helper loaded: form_helper
INFO - 2016-06-07 16:40:50 --> Database Driver Class Initialized
INFO - 2016-06-07 16:40:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:40:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:40:50 --> Email Class Initialized
INFO - 2016-06-07 16:40:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:40:50 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:40:50 --> Helper loaded: language_helper
INFO - 2016-06-07 16:40:50 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:40:50 --> Model Class Initialized
INFO - 2016-06-07 16:40:50 --> Helper loaded: date_helper
INFO - 2016-06-07 16:40:50 --> Controller Class Initialized
INFO - 2016-06-07 16:40:50 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:40:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:40:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:40:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:40:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:40:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:40:50 --> Model Class Initialized
INFO - 2016-06-07 16:40:50 --> Form Validation Class Initialized
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:40:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:40:50 --> Final output sent to browser
DEBUG - 2016-06-07 16:40:50 --> Total execution time: 0.0672
INFO - 2016-06-07 16:41:28 --> Config Class Initialized
INFO - 2016-06-07 16:41:28 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:41:28 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:41:28 --> Utf8 Class Initialized
INFO - 2016-06-07 16:41:28 --> URI Class Initialized
INFO - 2016-06-07 16:41:28 --> Router Class Initialized
INFO - 2016-06-07 16:41:28 --> Output Class Initialized
INFO - 2016-06-07 16:41:28 --> Security Class Initialized
DEBUG - 2016-06-07 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:41:28 --> Input Class Initialized
INFO - 2016-06-07 16:41:28 --> Language Class Initialized
INFO - 2016-06-07 16:41:28 --> Loader Class Initialized
INFO - 2016-06-07 16:41:28 --> Helper loaded: form_helper
INFO - 2016-06-07 16:41:28 --> Database Driver Class Initialized
INFO - 2016-06-07 16:41:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:41:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:41:28 --> Email Class Initialized
INFO - 2016-06-07 16:41:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:41:28 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:41:28 --> Helper loaded: language_helper
INFO - 2016-06-07 16:41:28 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:41:28 --> Model Class Initialized
INFO - 2016-06-07 16:41:28 --> Helper loaded: date_helper
INFO - 2016-06-07 16:41:28 --> Controller Class Initialized
INFO - 2016-06-07 16:41:28 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:41:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:41:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:41:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:41:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:41:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:41:28 --> Model Class Initialized
INFO - 2016-06-07 16:41:28 --> Form Validation Class Initialized
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:41:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:41:28 --> Final output sent to browser
DEBUG - 2016-06-07 16:41:28 --> Total execution time: 0.0383
INFO - 2016-06-07 16:41:46 --> Config Class Initialized
INFO - 2016-06-07 16:41:46 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:41:46 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:41:46 --> Utf8 Class Initialized
INFO - 2016-06-07 16:41:46 --> URI Class Initialized
INFO - 2016-06-07 16:41:46 --> Router Class Initialized
INFO - 2016-06-07 16:41:46 --> Output Class Initialized
INFO - 2016-06-07 16:41:46 --> Security Class Initialized
DEBUG - 2016-06-07 16:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:41:46 --> Input Class Initialized
INFO - 2016-06-07 16:41:46 --> Language Class Initialized
INFO - 2016-06-07 16:41:46 --> Loader Class Initialized
INFO - 2016-06-07 16:41:46 --> Helper loaded: form_helper
INFO - 2016-06-07 16:41:46 --> Database Driver Class Initialized
INFO - 2016-06-07 16:41:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:41:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:41:46 --> Email Class Initialized
INFO - 2016-06-07 16:41:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:41:46 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:41:46 --> Helper loaded: language_helper
INFO - 2016-06-07 16:41:46 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:41:46 --> Model Class Initialized
INFO - 2016-06-07 16:41:46 --> Helper loaded: date_helper
INFO - 2016-06-07 16:41:46 --> Controller Class Initialized
INFO - 2016-06-07 16:41:46 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:41:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:41:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:41:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:41:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:41:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:41:46 --> Model Class Initialized
INFO - 2016-06-07 16:41:46 --> Form Validation Class Initialized
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:41:46 --> Final output sent to browser
DEBUG - 2016-06-07 16:41:46 --> Total execution time: 0.0576
INFO - 2016-06-07 16:42:10 --> Config Class Initialized
INFO - 2016-06-07 16:42:10 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:42:10 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:42:10 --> Utf8 Class Initialized
INFO - 2016-06-07 16:42:10 --> URI Class Initialized
INFO - 2016-06-07 16:42:10 --> Router Class Initialized
INFO - 2016-06-07 16:42:10 --> Output Class Initialized
INFO - 2016-06-07 16:42:10 --> Security Class Initialized
DEBUG - 2016-06-07 16:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:42:10 --> Input Class Initialized
INFO - 2016-06-07 16:42:10 --> Language Class Initialized
INFO - 2016-06-07 16:42:10 --> Loader Class Initialized
INFO - 2016-06-07 16:42:10 --> Helper loaded: form_helper
INFO - 2016-06-07 16:42:10 --> Database Driver Class Initialized
INFO - 2016-06-07 16:42:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:42:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:42:11 --> Email Class Initialized
INFO - 2016-06-07 16:42:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:42:11 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:42:11 --> Helper loaded: language_helper
INFO - 2016-06-07 16:42:11 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:42:11 --> Model Class Initialized
INFO - 2016-06-07 16:42:11 --> Helper loaded: date_helper
INFO - 2016-06-07 16:42:11 --> Controller Class Initialized
INFO - 2016-06-07 16:42:11 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:42:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:42:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:42:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:42:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:42:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:42:11 --> Model Class Initialized
INFO - 2016-06-07 16:42:11 --> Form Validation Class Initialized
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:42:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:42:11 --> Final output sent to browser
DEBUG - 2016-06-07 16:42:11 --> Total execution time: 0.0717
INFO - 2016-06-07 16:44:44 --> Config Class Initialized
INFO - 2016-06-07 16:44:44 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:44:44 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:44:44 --> Utf8 Class Initialized
INFO - 2016-06-07 16:44:44 --> URI Class Initialized
INFO - 2016-06-07 16:44:44 --> Router Class Initialized
INFO - 2016-06-07 16:44:44 --> Output Class Initialized
INFO - 2016-06-07 16:44:44 --> Security Class Initialized
DEBUG - 2016-06-07 16:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:44:44 --> Input Class Initialized
INFO - 2016-06-07 16:44:44 --> Language Class Initialized
INFO - 2016-06-07 16:44:44 --> Loader Class Initialized
INFO - 2016-06-07 16:44:44 --> Helper loaded: form_helper
INFO - 2016-06-07 16:44:44 --> Database Driver Class Initialized
INFO - 2016-06-07 16:44:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:44:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:44:44 --> Email Class Initialized
INFO - 2016-06-07 16:44:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:44:44 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:44:44 --> Helper loaded: language_helper
INFO - 2016-06-07 16:44:44 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:44:44 --> Model Class Initialized
INFO - 2016-06-07 16:44:44 --> Helper loaded: date_helper
INFO - 2016-06-07 16:44:44 --> Controller Class Initialized
INFO - 2016-06-07 16:44:44 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:44:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:44:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:44:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:44:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:44:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:44:44 --> Model Class Initialized
INFO - 2016-06-07 16:44:44 --> Form Validation Class Initialized
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-07 16:44:44 --> Could not find the language line "dashboard_title_label"
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:44:44 --> Final output sent to browser
DEBUG - 2016-06-07 16:44:44 --> Total execution time: 0.0675
INFO - 2016-06-07 16:45:03 --> Config Class Initialized
INFO - 2016-06-07 16:45:03 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:45:03 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:45:03 --> Utf8 Class Initialized
INFO - 2016-06-07 16:45:03 --> URI Class Initialized
INFO - 2016-06-07 16:45:03 --> Router Class Initialized
INFO - 2016-06-07 16:45:03 --> Output Class Initialized
INFO - 2016-06-07 16:45:03 --> Security Class Initialized
DEBUG - 2016-06-07 16:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:45:03 --> Input Class Initialized
INFO - 2016-06-07 16:45:03 --> Language Class Initialized
INFO - 2016-06-07 16:45:03 --> Loader Class Initialized
INFO - 2016-06-07 16:45:03 --> Helper loaded: form_helper
INFO - 2016-06-07 16:45:03 --> Database Driver Class Initialized
INFO - 2016-06-07 16:45:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:45:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:45:03 --> Email Class Initialized
INFO - 2016-06-07 16:45:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:45:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:45:03 --> Helper loaded: language_helper
INFO - 2016-06-07 16:45:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:45:03 --> Model Class Initialized
INFO - 2016-06-07 16:45:03 --> Helper loaded: date_helper
INFO - 2016-06-07 16:45:03 --> Controller Class Initialized
INFO - 2016-06-07 16:45:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:45:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:45:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:45:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:45:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:45:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:45:03 --> Model Class Initialized
INFO - 2016-06-07 16:45:03 --> Form Validation Class Initialized
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:45:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:45:03 --> Final output sent to browser
DEBUG - 2016-06-07 16:45:03 --> Total execution time: 0.0942
INFO - 2016-06-07 16:49:13 --> Config Class Initialized
INFO - 2016-06-07 16:49:13 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:49:13 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:49:13 --> Utf8 Class Initialized
INFO - 2016-06-07 16:49:13 --> URI Class Initialized
INFO - 2016-06-07 16:49:13 --> Router Class Initialized
INFO - 2016-06-07 16:49:13 --> Output Class Initialized
INFO - 2016-06-07 16:49:13 --> Security Class Initialized
DEBUG - 2016-06-07 16:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:49:13 --> Input Class Initialized
INFO - 2016-06-07 16:49:13 --> Language Class Initialized
INFO - 2016-06-07 16:49:13 --> Loader Class Initialized
INFO - 2016-06-07 16:49:13 --> Helper loaded: form_helper
INFO - 2016-06-07 16:49:13 --> Database Driver Class Initialized
INFO - 2016-06-07 16:49:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:49:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:49:13 --> Email Class Initialized
INFO - 2016-06-07 16:49:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:49:13 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:49:13 --> Helper loaded: language_helper
INFO - 2016-06-07 16:49:13 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:49:13 --> Model Class Initialized
INFO - 2016-06-07 16:49:13 --> Helper loaded: date_helper
INFO - 2016-06-07 16:49:13 --> Controller Class Initialized
INFO - 2016-06-07 16:49:13 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:49:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:49:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:49:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:49:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:49:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:49:13 --> Model Class Initialized
INFO - 2016-06-07 16:49:13 --> Form Validation Class Initialized
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:49:13 --> Final output sent to browser
DEBUG - 2016-06-07 16:49:13 --> Total execution time: 0.0546
INFO - 2016-06-07 16:52:53 --> Config Class Initialized
INFO - 2016-06-07 16:52:53 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:52:53 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:52:53 --> Utf8 Class Initialized
INFO - 2016-06-07 16:52:53 --> URI Class Initialized
INFO - 2016-06-07 16:52:53 --> Router Class Initialized
INFO - 2016-06-07 16:52:53 --> Output Class Initialized
INFO - 2016-06-07 16:52:53 --> Security Class Initialized
DEBUG - 2016-06-07 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:52:53 --> Input Class Initialized
INFO - 2016-06-07 16:52:53 --> Language Class Initialized
INFO - 2016-06-07 16:52:53 --> Loader Class Initialized
INFO - 2016-06-07 16:52:53 --> Helper loaded: form_helper
INFO - 2016-06-07 16:52:53 --> Database Driver Class Initialized
INFO - 2016-06-07 16:52:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:52:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:52:53 --> Email Class Initialized
INFO - 2016-06-07 16:52:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:52:53 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:52:53 --> Helper loaded: language_helper
INFO - 2016-06-07 16:52:53 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:52:53 --> Model Class Initialized
INFO - 2016-06-07 16:52:53 --> Helper loaded: date_helper
INFO - 2016-06-07 16:52:53 --> Controller Class Initialized
INFO - 2016-06-07 16:52:53 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:52:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:52:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:52:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:52:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:52:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:52:53 --> Model Class Initialized
INFO - 2016-06-07 16:52:53 --> Form Validation Class Initialized
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:52:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:52:53 --> Final output sent to browser
DEBUG - 2016-06-07 16:52:53 --> Total execution time: 0.0825
INFO - 2016-06-07 16:54:03 --> Config Class Initialized
INFO - 2016-06-07 16:54:03 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:54:03 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:54:03 --> Utf8 Class Initialized
INFO - 2016-06-07 16:54:03 --> URI Class Initialized
INFO - 2016-06-07 16:54:03 --> Router Class Initialized
INFO - 2016-06-07 16:54:03 --> Output Class Initialized
INFO - 2016-06-07 16:54:03 --> Security Class Initialized
DEBUG - 2016-06-07 16:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:54:03 --> Input Class Initialized
INFO - 2016-06-07 16:54:03 --> Language Class Initialized
INFO - 2016-06-07 16:54:03 --> Loader Class Initialized
INFO - 2016-06-07 16:54:03 --> Helper loaded: form_helper
INFO - 2016-06-07 16:54:03 --> Database Driver Class Initialized
INFO - 2016-06-07 16:54:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:54:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:54:03 --> Email Class Initialized
INFO - 2016-06-07 16:54:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:54:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:54:03 --> Helper loaded: language_helper
INFO - 2016-06-07 16:54:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:54:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:54:03 --> Model Class Initialized
INFO - 2016-06-07 16:54:03 --> Helper loaded: date_helper
INFO - 2016-06-07 16:54:03 --> Controller Class Initialized
INFO - 2016-06-07 16:54:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:54:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:54:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:54:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:54:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:54:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:54:03 --> Model Class Initialized
INFO - 2016-06-07 16:54:03 --> Form Validation Class Initialized
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:54:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:54:03 --> Final output sent to browser
DEBUG - 2016-06-07 16:54:03 --> Total execution time: 0.0742
INFO - 2016-06-07 16:54:30 --> Config Class Initialized
INFO - 2016-06-07 16:54:30 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:54:30 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:54:30 --> Utf8 Class Initialized
INFO - 2016-06-07 16:54:30 --> URI Class Initialized
INFO - 2016-06-07 16:54:30 --> Router Class Initialized
INFO - 2016-06-07 16:54:30 --> Output Class Initialized
INFO - 2016-06-07 16:54:30 --> Security Class Initialized
DEBUG - 2016-06-07 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:54:30 --> Input Class Initialized
INFO - 2016-06-07 16:54:30 --> Language Class Initialized
INFO - 2016-06-07 16:54:30 --> Loader Class Initialized
INFO - 2016-06-07 16:54:30 --> Helper loaded: form_helper
INFO - 2016-06-07 16:54:30 --> Database Driver Class Initialized
INFO - 2016-06-07 16:54:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:54:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:54:30 --> Email Class Initialized
INFO - 2016-06-07 16:54:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:54:30 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:54:30 --> Helper loaded: language_helper
INFO - 2016-06-07 16:54:30 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:54:30 --> Model Class Initialized
INFO - 2016-06-07 16:54:30 --> Helper loaded: date_helper
INFO - 2016-06-07 16:54:30 --> Controller Class Initialized
INFO - 2016-06-07 16:54:30 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:54:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:54:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:54:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:54:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:54:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:54:30 --> Model Class Initialized
INFO - 2016-06-07 16:54:30 --> Form Validation Class Initialized
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:54:30 --> Final output sent to browser
DEBUG - 2016-06-07 16:54:30 --> Total execution time: 0.0553
INFO - 2016-06-07 16:55:02 --> Config Class Initialized
INFO - 2016-06-07 16:55:02 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:55:02 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:55:02 --> Utf8 Class Initialized
INFO - 2016-06-07 16:55:02 --> URI Class Initialized
INFO - 2016-06-07 16:55:02 --> Router Class Initialized
INFO - 2016-06-07 16:55:02 --> Output Class Initialized
INFO - 2016-06-07 16:55:02 --> Security Class Initialized
DEBUG - 2016-06-07 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:55:02 --> Input Class Initialized
INFO - 2016-06-07 16:55:02 --> Language Class Initialized
INFO - 2016-06-07 16:55:02 --> Loader Class Initialized
INFO - 2016-06-07 16:55:02 --> Helper loaded: form_helper
INFO - 2016-06-07 16:55:02 --> Database Driver Class Initialized
INFO - 2016-06-07 16:55:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:55:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:55:02 --> Email Class Initialized
INFO - 2016-06-07 16:55:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:55:02 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:55:02 --> Helper loaded: language_helper
INFO - 2016-06-07 16:55:02 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:55:02 --> Model Class Initialized
INFO - 2016-06-07 16:55:02 --> Helper loaded: date_helper
INFO - 2016-06-07 16:55:02 --> Controller Class Initialized
INFO - 2016-06-07 16:55:02 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:55:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:55:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:55:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:55:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:55:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:55:02 --> Model Class Initialized
INFO - 2016-06-07 16:55:02 --> Form Validation Class Initialized
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:55:02 --> Final output sent to browser
DEBUG - 2016-06-07 16:55:02 --> Total execution time: 0.0506
INFO - 2016-06-07 16:55:13 --> Config Class Initialized
INFO - 2016-06-07 16:55:13 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:55:13 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:55:13 --> Utf8 Class Initialized
INFO - 2016-06-07 16:55:13 --> URI Class Initialized
INFO - 2016-06-07 16:55:13 --> Router Class Initialized
INFO - 2016-06-07 16:55:13 --> Output Class Initialized
INFO - 2016-06-07 16:55:13 --> Security Class Initialized
DEBUG - 2016-06-07 16:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:55:13 --> Input Class Initialized
INFO - 2016-06-07 16:55:13 --> Language Class Initialized
INFO - 2016-06-07 16:55:13 --> Loader Class Initialized
INFO - 2016-06-07 16:55:13 --> Helper loaded: form_helper
INFO - 2016-06-07 16:55:13 --> Database Driver Class Initialized
INFO - 2016-06-07 16:55:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:55:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:55:13 --> Email Class Initialized
INFO - 2016-06-07 16:55:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:55:13 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:55:13 --> Helper loaded: language_helper
INFO - 2016-06-07 16:55:13 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:55:13 --> Model Class Initialized
INFO - 2016-06-07 16:55:13 --> Helper loaded: date_helper
INFO - 2016-06-07 16:55:13 --> Controller Class Initialized
INFO - 2016-06-07 16:55:13 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:55:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:55:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:55:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:55:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:55:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:55:13 --> Model Class Initialized
INFO - 2016-06-07 16:55:13 --> Form Validation Class Initialized
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:55:13 --> Final output sent to browser
DEBUG - 2016-06-07 16:55:13 --> Total execution time: 0.0652
INFO - 2016-06-07 16:56:05 --> Config Class Initialized
INFO - 2016-06-07 16:56:05 --> Hooks Class Initialized
DEBUG - 2016-06-07 16:56:05 --> UTF-8 Support Enabled
INFO - 2016-06-07 16:56:05 --> Utf8 Class Initialized
INFO - 2016-06-07 16:56:05 --> URI Class Initialized
INFO - 2016-06-07 16:56:05 --> Router Class Initialized
INFO - 2016-06-07 16:56:05 --> Output Class Initialized
INFO - 2016-06-07 16:56:05 --> Security Class Initialized
DEBUG - 2016-06-07 16:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 16:56:05 --> Input Class Initialized
INFO - 2016-06-07 16:56:05 --> Language Class Initialized
INFO - 2016-06-07 16:56:05 --> Loader Class Initialized
INFO - 2016-06-07 16:56:05 --> Helper loaded: form_helper
INFO - 2016-06-07 16:56:05 --> Database Driver Class Initialized
INFO - 2016-06-07 16:56:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 16:56:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 16:56:05 --> Email Class Initialized
INFO - 2016-06-07 16:56:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 16:56:05 --> Helper loaded: cookie_helper
INFO - 2016-06-07 16:56:05 --> Helper loaded: language_helper
INFO - 2016-06-07 16:56:05 --> Helper loaded: url_helper
DEBUG - 2016-06-07 16:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 16:56:05 --> Model Class Initialized
INFO - 2016-06-07 16:56:05 --> Helper loaded: date_helper
INFO - 2016-06-07 16:56:05 --> Controller Class Initialized
INFO - 2016-06-07 16:56:05 --> Helper loaded: languages_helper
INFO - 2016-06-07 16:56:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 16:56:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 16:56:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 16:56:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 16:56:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 16:56:05 --> Model Class Initialized
INFO - 2016-06-07 16:56:05 --> Form Validation Class Initialized
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 16:56:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 16:56:05 --> Final output sent to browser
DEBUG - 2016-06-07 16:56:05 --> Total execution time: 0.0816
INFO - 2016-06-07 17:10:03 --> Config Class Initialized
INFO - 2016-06-07 17:10:03 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:10:03 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:10:03 --> Utf8 Class Initialized
INFO - 2016-06-07 17:10:03 --> URI Class Initialized
INFO - 2016-06-07 17:10:03 --> Router Class Initialized
INFO - 2016-06-07 17:10:03 --> Output Class Initialized
INFO - 2016-06-07 17:10:03 --> Security Class Initialized
DEBUG - 2016-06-07 17:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:10:03 --> Input Class Initialized
INFO - 2016-06-07 17:10:03 --> Language Class Initialized
INFO - 2016-06-07 17:10:03 --> Loader Class Initialized
INFO - 2016-06-07 17:10:03 --> Helper loaded: form_helper
INFO - 2016-06-07 17:10:03 --> Database Driver Class Initialized
INFO - 2016-06-07 17:10:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:10:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:10:03 --> Email Class Initialized
INFO - 2016-06-07 17:10:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:10:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:10:03 --> Helper loaded: language_helper
INFO - 2016-06-07 17:10:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:10:03 --> Model Class Initialized
INFO - 2016-06-07 17:10:03 --> Helper loaded: date_helper
INFO - 2016-06-07 17:10:03 --> Controller Class Initialized
INFO - 2016-06-07 17:10:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:10:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:10:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:10:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:10:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:10:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:10:03 --> Model Class Initialized
INFO - 2016-06-07 17:10:03 --> Form Validation Class Initialized
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:10:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:10:03 --> Final output sent to browser
DEBUG - 2016-06-07 17:10:03 --> Total execution time: 0.0478
INFO - 2016-06-07 17:15:13 --> Config Class Initialized
INFO - 2016-06-07 17:15:13 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:15:13 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:15:13 --> Utf8 Class Initialized
INFO - 2016-06-07 17:15:13 --> URI Class Initialized
INFO - 2016-06-07 17:15:13 --> Router Class Initialized
INFO - 2016-06-07 17:15:13 --> Output Class Initialized
INFO - 2016-06-07 17:15:13 --> Security Class Initialized
DEBUG - 2016-06-07 17:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:15:13 --> Input Class Initialized
INFO - 2016-06-07 17:15:13 --> Language Class Initialized
INFO - 2016-06-07 17:15:13 --> Loader Class Initialized
INFO - 2016-06-07 17:15:13 --> Helper loaded: form_helper
INFO - 2016-06-07 17:15:13 --> Database Driver Class Initialized
INFO - 2016-06-07 17:15:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:15:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:15:13 --> Email Class Initialized
INFO - 2016-06-07 17:15:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:15:13 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:15:13 --> Helper loaded: language_helper
INFO - 2016-06-07 17:15:13 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:15:13 --> Model Class Initialized
INFO - 2016-06-07 17:15:13 --> Helper loaded: date_helper
INFO - 2016-06-07 17:15:13 --> Controller Class Initialized
INFO - 2016-06-07 17:15:13 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:15:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:15:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:15:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:15:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:15:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:15:13 --> Model Class Initialized
INFO - 2016-06-07 17:15:13 --> Form Validation Class Initialized
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:15:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:15:13 --> Final output sent to browser
DEBUG - 2016-06-07 17:15:13 --> Total execution time: 0.0621
INFO - 2016-06-07 17:23:28 --> Config Class Initialized
INFO - 2016-06-07 17:23:28 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:23:28 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:23:28 --> Utf8 Class Initialized
INFO - 2016-06-07 17:23:28 --> URI Class Initialized
INFO - 2016-06-07 17:23:28 --> Router Class Initialized
INFO - 2016-06-07 17:23:28 --> Output Class Initialized
INFO - 2016-06-07 17:23:28 --> Security Class Initialized
DEBUG - 2016-06-07 17:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:23:28 --> Input Class Initialized
INFO - 2016-06-07 17:23:28 --> Language Class Initialized
INFO - 2016-06-07 17:23:28 --> Loader Class Initialized
INFO - 2016-06-07 17:23:28 --> Helper loaded: form_helper
INFO - 2016-06-07 17:23:28 --> Database Driver Class Initialized
INFO - 2016-06-07 17:23:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:23:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:23:28 --> Email Class Initialized
INFO - 2016-06-07 17:23:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:23:28 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:23:28 --> Helper loaded: language_helper
INFO - 2016-06-07 17:23:28 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:23:28 --> Model Class Initialized
INFO - 2016-06-07 17:23:28 --> Helper loaded: date_helper
INFO - 2016-06-07 17:23:28 --> Controller Class Initialized
INFO - 2016-06-07 17:23:28 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:23:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:23:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:23:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:23:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:23:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:23:28 --> Model Class Initialized
INFO - 2016-06-07 17:23:28 --> Form Validation Class Initialized
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:23:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:23:28 --> Final output sent to browser
DEBUG - 2016-06-07 17:23:28 --> Total execution time: 0.0640
INFO - 2016-06-07 17:31:30 --> Config Class Initialized
INFO - 2016-06-07 17:31:30 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:31:30 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:31:30 --> Utf8 Class Initialized
INFO - 2016-06-07 17:31:30 --> URI Class Initialized
INFO - 2016-06-07 17:31:30 --> Router Class Initialized
INFO - 2016-06-07 17:31:30 --> Output Class Initialized
INFO - 2016-06-07 17:31:30 --> Security Class Initialized
DEBUG - 2016-06-07 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:31:30 --> Input Class Initialized
INFO - 2016-06-07 17:31:30 --> Language Class Initialized
INFO - 2016-06-07 17:31:30 --> Loader Class Initialized
INFO - 2016-06-07 17:31:30 --> Helper loaded: form_helper
INFO - 2016-06-07 17:31:30 --> Database Driver Class Initialized
INFO - 2016-06-07 17:31:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:31:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:31:30 --> Email Class Initialized
INFO - 2016-06-07 17:31:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:31:30 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:31:30 --> Helper loaded: language_helper
INFO - 2016-06-07 17:31:30 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:31:30 --> Model Class Initialized
INFO - 2016-06-07 17:31:30 --> Helper loaded: date_helper
INFO - 2016-06-07 17:31:30 --> Controller Class Initialized
INFO - 2016-06-07 17:31:30 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:31:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:31:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:31:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:31:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:31:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:31:30 --> Model Class Initialized
INFO - 2016-06-07 17:31:30 --> Form Validation Class Initialized
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:31:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:31:30 --> Final output sent to browser
DEBUG - 2016-06-07 17:31:30 --> Total execution time: 0.0445
INFO - 2016-06-07 17:32:47 --> Config Class Initialized
INFO - 2016-06-07 17:32:47 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:32:47 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:32:47 --> Utf8 Class Initialized
INFO - 2016-06-07 17:32:47 --> URI Class Initialized
INFO - 2016-06-07 17:32:47 --> Router Class Initialized
INFO - 2016-06-07 17:32:47 --> Output Class Initialized
INFO - 2016-06-07 17:32:47 --> Security Class Initialized
DEBUG - 2016-06-07 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:32:47 --> Input Class Initialized
INFO - 2016-06-07 17:32:47 --> Language Class Initialized
INFO - 2016-06-07 17:32:47 --> Loader Class Initialized
INFO - 2016-06-07 17:32:47 --> Helper loaded: form_helper
INFO - 2016-06-07 17:32:47 --> Database Driver Class Initialized
INFO - 2016-06-07 17:32:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:32:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:32:47 --> Email Class Initialized
INFO - 2016-06-07 17:32:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:32:47 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:32:47 --> Helper loaded: language_helper
INFO - 2016-06-07 17:32:47 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:32:47 --> Model Class Initialized
INFO - 2016-06-07 17:32:47 --> Helper loaded: date_helper
INFO - 2016-06-07 17:32:47 --> Controller Class Initialized
INFO - 2016-06-07 17:32:47 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:32:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:32:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:32:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:32:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:32:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:32:47 --> Model Class Initialized
INFO - 2016-06-07 17:32:47 --> Form Validation Class Initialized
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:32:47 --> Final output sent to browser
DEBUG - 2016-06-07 17:32:47 --> Total execution time: 0.1170
INFO - 2016-06-07 17:42:39 --> Config Class Initialized
INFO - 2016-06-07 17:42:39 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:42:39 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:42:39 --> Utf8 Class Initialized
INFO - 2016-06-07 17:42:39 --> URI Class Initialized
INFO - 2016-06-07 17:42:39 --> Router Class Initialized
INFO - 2016-06-07 17:42:39 --> Output Class Initialized
INFO - 2016-06-07 17:42:39 --> Security Class Initialized
DEBUG - 2016-06-07 17:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:42:39 --> Input Class Initialized
INFO - 2016-06-07 17:42:39 --> Language Class Initialized
INFO - 2016-06-07 17:42:39 --> Loader Class Initialized
INFO - 2016-06-07 17:42:39 --> Helper loaded: form_helper
INFO - 2016-06-07 17:42:39 --> Database Driver Class Initialized
INFO - 2016-06-07 17:42:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:42:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:42:39 --> Email Class Initialized
INFO - 2016-06-07 17:42:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:42:39 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:42:39 --> Helper loaded: language_helper
INFO - 2016-06-07 17:42:39 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:42:39 --> Model Class Initialized
INFO - 2016-06-07 17:42:39 --> Helper loaded: date_helper
INFO - 2016-06-07 17:42:39 --> Controller Class Initialized
INFO - 2016-06-07 17:42:39 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:42:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:42:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:42:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:42:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:42:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:42:39 --> Model Class Initialized
INFO - 2016-06-07 17:42:39 --> Form Validation Class Initialized
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:42:39 --> Final output sent to browser
DEBUG - 2016-06-07 17:42:39 --> Total execution time: 0.0502
INFO - 2016-06-07 17:43:40 --> Config Class Initialized
INFO - 2016-06-07 17:43:40 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:43:40 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:43:40 --> Utf8 Class Initialized
INFO - 2016-06-07 17:43:40 --> URI Class Initialized
INFO - 2016-06-07 17:43:40 --> Router Class Initialized
INFO - 2016-06-07 17:43:40 --> Output Class Initialized
INFO - 2016-06-07 17:43:40 --> Security Class Initialized
DEBUG - 2016-06-07 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:43:40 --> Input Class Initialized
INFO - 2016-06-07 17:43:40 --> Language Class Initialized
INFO - 2016-06-07 17:43:40 --> Loader Class Initialized
INFO - 2016-06-07 17:43:40 --> Helper loaded: form_helper
INFO - 2016-06-07 17:43:40 --> Database Driver Class Initialized
INFO - 2016-06-07 17:43:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:43:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:43:40 --> Email Class Initialized
INFO - 2016-06-07 17:43:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:43:40 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:43:40 --> Helper loaded: language_helper
INFO - 2016-06-07 17:43:40 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:43:40 --> Model Class Initialized
INFO - 2016-06-07 17:43:40 --> Helper loaded: date_helper
INFO - 2016-06-07 17:43:40 --> Controller Class Initialized
INFO - 2016-06-07 17:43:40 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:43:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:43:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:43:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:43:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:43:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:43:40 --> Model Class Initialized
INFO - 2016-06-07 17:43:40 --> Form Validation Class Initialized
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:43:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:43:40 --> Final output sent to browser
DEBUG - 2016-06-07 17:43:40 --> Total execution time: 0.0811
INFO - 2016-06-07 17:46:09 --> Config Class Initialized
INFO - 2016-06-07 17:46:09 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:46:09 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:46:09 --> Utf8 Class Initialized
INFO - 2016-06-07 17:46:09 --> URI Class Initialized
INFO - 2016-06-07 17:46:09 --> Router Class Initialized
INFO - 2016-06-07 17:46:09 --> Output Class Initialized
INFO - 2016-06-07 17:46:09 --> Security Class Initialized
DEBUG - 2016-06-07 17:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:46:09 --> Input Class Initialized
INFO - 2016-06-07 17:46:09 --> Language Class Initialized
INFO - 2016-06-07 17:46:09 --> Loader Class Initialized
INFO - 2016-06-07 17:46:09 --> Helper loaded: form_helper
INFO - 2016-06-07 17:46:09 --> Database Driver Class Initialized
INFO - 2016-06-07 17:46:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:46:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:46:09 --> Email Class Initialized
INFO - 2016-06-07 17:46:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:46:09 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:46:09 --> Helper loaded: language_helper
INFO - 2016-06-07 17:46:09 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:46:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:46:09 --> Model Class Initialized
INFO - 2016-06-07 17:46:09 --> Helper loaded: date_helper
INFO - 2016-06-07 17:46:09 --> Controller Class Initialized
INFO - 2016-06-07 17:46:09 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:46:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:46:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:46:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:46:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:46:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:46:09 --> Model Class Initialized
INFO - 2016-06-07 17:46:09 --> Form Validation Class Initialized
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:46:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:46:09 --> Final output sent to browser
DEBUG - 2016-06-07 17:46:09 --> Total execution time: 0.0701
INFO - 2016-06-07 17:48:12 --> Config Class Initialized
INFO - 2016-06-07 17:48:12 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:48:12 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:48:12 --> Utf8 Class Initialized
INFO - 2016-06-07 17:48:12 --> URI Class Initialized
INFO - 2016-06-07 17:48:12 --> Router Class Initialized
INFO - 2016-06-07 17:48:12 --> Output Class Initialized
INFO - 2016-06-07 17:48:12 --> Security Class Initialized
DEBUG - 2016-06-07 17:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:48:12 --> Input Class Initialized
INFO - 2016-06-07 17:48:12 --> Language Class Initialized
INFO - 2016-06-07 17:48:12 --> Loader Class Initialized
INFO - 2016-06-07 17:48:12 --> Helper loaded: form_helper
INFO - 2016-06-07 17:48:12 --> Database Driver Class Initialized
INFO - 2016-06-07 17:48:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:48:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:48:12 --> Email Class Initialized
INFO - 2016-06-07 17:48:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:48:12 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:48:12 --> Helper loaded: language_helper
INFO - 2016-06-07 17:48:12 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:48:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:48:12 --> Model Class Initialized
INFO - 2016-06-07 17:48:12 --> Helper loaded: date_helper
INFO - 2016-06-07 17:48:12 --> Controller Class Initialized
INFO - 2016-06-07 17:48:12 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:48:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:48:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:48:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:48:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:48:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:48:12 --> Model Class Initialized
INFO - 2016-06-07 17:48:12 --> Form Validation Class Initialized
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:48:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:48:12 --> Final output sent to browser
DEBUG - 2016-06-07 17:48:12 --> Total execution time: 0.0760
INFO - 2016-06-07 17:50:57 --> Config Class Initialized
INFO - 2016-06-07 17:50:57 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:50:57 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:50:57 --> Utf8 Class Initialized
INFO - 2016-06-07 17:50:57 --> URI Class Initialized
INFO - 2016-06-07 17:50:57 --> Router Class Initialized
INFO - 2016-06-07 17:50:57 --> Output Class Initialized
INFO - 2016-06-07 17:50:57 --> Security Class Initialized
DEBUG - 2016-06-07 17:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:50:57 --> Input Class Initialized
INFO - 2016-06-07 17:50:57 --> Language Class Initialized
INFO - 2016-06-07 17:50:57 --> Loader Class Initialized
INFO - 2016-06-07 17:50:57 --> Helper loaded: form_helper
INFO - 2016-06-07 17:50:57 --> Database Driver Class Initialized
INFO - 2016-06-07 17:50:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:50:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:50:57 --> Email Class Initialized
INFO - 2016-06-07 17:50:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:50:57 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:50:57 --> Helper loaded: language_helper
INFO - 2016-06-07 17:50:57 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:50:57 --> Model Class Initialized
INFO - 2016-06-07 17:50:57 --> Helper loaded: date_helper
INFO - 2016-06-07 17:50:57 --> Controller Class Initialized
INFO - 2016-06-07 17:50:57 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:50:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:50:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:50:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:50:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:50:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:50:57 --> Model Class Initialized
INFO - 2016-06-07 17:50:57 --> Form Validation Class Initialized
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:50:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:50:57 --> Final output sent to browser
DEBUG - 2016-06-07 17:50:57 --> Total execution time: 0.0619
INFO - 2016-06-07 17:51:10 --> Config Class Initialized
INFO - 2016-06-07 17:51:10 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:51:10 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:51:10 --> Utf8 Class Initialized
INFO - 2016-06-07 17:51:10 --> URI Class Initialized
INFO - 2016-06-07 17:51:10 --> Router Class Initialized
INFO - 2016-06-07 17:51:10 --> Output Class Initialized
INFO - 2016-06-07 17:51:10 --> Security Class Initialized
DEBUG - 2016-06-07 17:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:51:10 --> Input Class Initialized
INFO - 2016-06-07 17:51:10 --> Language Class Initialized
INFO - 2016-06-07 17:51:10 --> Loader Class Initialized
INFO - 2016-06-07 17:51:10 --> Helper loaded: form_helper
INFO - 2016-06-07 17:51:10 --> Database Driver Class Initialized
INFO - 2016-06-07 17:51:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:51:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:51:10 --> Email Class Initialized
INFO - 2016-06-07 17:51:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:51:10 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:51:10 --> Helper loaded: language_helper
INFO - 2016-06-07 17:51:10 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:51:10 --> Model Class Initialized
INFO - 2016-06-07 17:51:10 --> Helper loaded: date_helper
INFO - 2016-06-07 17:51:10 --> Controller Class Initialized
INFO - 2016-06-07 17:51:10 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:51:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:51:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:51:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:51:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:51:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:51:10 --> Model Class Initialized
INFO - 2016-06-07 17:51:10 --> Form Validation Class Initialized
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:51:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:51:10 --> Final output sent to browser
DEBUG - 2016-06-07 17:51:10 --> Total execution time: 0.0820
INFO - 2016-06-07 17:56:28 --> Config Class Initialized
INFO - 2016-06-07 17:56:28 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:56:28 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:56:28 --> Utf8 Class Initialized
INFO - 2016-06-07 17:56:28 --> URI Class Initialized
INFO - 2016-06-07 17:56:28 --> Router Class Initialized
INFO - 2016-06-07 17:56:28 --> Output Class Initialized
INFO - 2016-06-07 17:56:28 --> Security Class Initialized
DEBUG - 2016-06-07 17:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:56:28 --> Input Class Initialized
INFO - 2016-06-07 17:56:28 --> Language Class Initialized
INFO - 2016-06-07 17:56:28 --> Loader Class Initialized
INFO - 2016-06-07 17:56:28 --> Helper loaded: form_helper
INFO - 2016-06-07 17:56:28 --> Database Driver Class Initialized
INFO - 2016-06-07 17:56:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:56:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:56:28 --> Email Class Initialized
INFO - 2016-06-07 17:56:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:56:28 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:56:28 --> Helper loaded: language_helper
INFO - 2016-06-07 17:56:28 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:56:28 --> Model Class Initialized
INFO - 2016-06-07 17:56:28 --> Helper loaded: date_helper
INFO - 2016-06-07 17:56:28 --> Controller Class Initialized
INFO - 2016-06-07 17:56:28 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:56:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:56:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:56:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:56:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:56:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:56:28 --> Model Class Initialized
INFO - 2016-06-07 17:56:28 --> Form Validation Class Initialized
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:56:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:56:28 --> Final output sent to browser
DEBUG - 2016-06-07 17:56:28 --> Total execution time: 0.0785
INFO - 2016-06-07 17:57:49 --> Config Class Initialized
INFO - 2016-06-07 17:57:49 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:57:49 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:57:49 --> Utf8 Class Initialized
INFO - 2016-06-07 17:57:49 --> URI Class Initialized
INFO - 2016-06-07 17:57:49 --> Router Class Initialized
INFO - 2016-06-07 17:57:49 --> Output Class Initialized
INFO - 2016-06-07 17:57:49 --> Security Class Initialized
DEBUG - 2016-06-07 17:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:57:49 --> Input Class Initialized
INFO - 2016-06-07 17:57:49 --> Language Class Initialized
INFO - 2016-06-07 17:57:49 --> Loader Class Initialized
INFO - 2016-06-07 17:57:49 --> Helper loaded: form_helper
INFO - 2016-06-07 17:57:49 --> Database Driver Class Initialized
INFO - 2016-06-07 17:57:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:57:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:57:49 --> Email Class Initialized
INFO - 2016-06-07 17:57:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:57:49 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:57:49 --> Helper loaded: language_helper
INFO - 2016-06-07 17:57:49 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:57:49 --> Model Class Initialized
INFO - 2016-06-07 17:57:49 --> Helper loaded: date_helper
INFO - 2016-06-07 17:57:49 --> Controller Class Initialized
INFO - 2016-06-07 17:57:49 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:57:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:57:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:57:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:57:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:57:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:57:49 --> Model Class Initialized
INFO - 2016-06-07 17:57:49 --> Form Validation Class Initialized
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 17:57:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 17:57:49 --> Final output sent to browser
DEBUG - 2016-06-07 17:57:49 --> Total execution time: 0.0664
INFO - 2016-06-07 17:58:02 --> Config Class Initialized
INFO - 2016-06-07 17:58:02 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:58:02 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:58:02 --> Utf8 Class Initialized
INFO - 2016-06-07 17:58:02 --> URI Class Initialized
INFO - 2016-06-07 17:58:02 --> Router Class Initialized
INFO - 2016-06-07 17:58:02 --> Output Class Initialized
INFO - 2016-06-07 17:58:02 --> Security Class Initialized
DEBUG - 2016-06-07 17:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:58:02 --> Input Class Initialized
INFO - 2016-06-07 17:58:02 --> Language Class Initialized
INFO - 2016-06-07 17:58:02 --> Loader Class Initialized
INFO - 2016-06-07 17:58:02 --> Helper loaded: form_helper
INFO - 2016-06-07 17:58:02 --> Database Driver Class Initialized
INFO - 2016-06-07 17:58:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:58:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:58:03 --> Email Class Initialized
INFO - 2016-06-07 17:58:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:58:03 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:58:03 --> Helper loaded: language_helper
INFO - 2016-06-07 17:58:03 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:58:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:58:03 --> Model Class Initialized
INFO - 2016-06-07 17:58:03 --> Helper loaded: date_helper
INFO - 2016-06-07 17:58:03 --> Controller Class Initialized
INFO - 2016-06-07 17:58:03 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:58:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:58:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:58:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:58:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:58:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:58:03 --> Model Class Initialized
INFO - 2016-06-07 17:58:03 --> Form Validation Class Initialized
INFO - 2016-06-07 17:58:03 --> Final output sent to browser
DEBUG - 2016-06-07 17:58:03 --> Total execution time: 0.0604
INFO - 2016-06-07 17:58:09 --> Config Class Initialized
INFO - 2016-06-07 17:58:09 --> Hooks Class Initialized
DEBUG - 2016-06-07 17:58:09 --> UTF-8 Support Enabled
INFO - 2016-06-07 17:58:09 --> Utf8 Class Initialized
INFO - 2016-06-07 17:58:09 --> URI Class Initialized
INFO - 2016-06-07 17:58:09 --> Router Class Initialized
INFO - 2016-06-07 17:58:09 --> Output Class Initialized
INFO - 2016-06-07 17:58:09 --> Security Class Initialized
DEBUG - 2016-06-07 17:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 17:58:09 --> Input Class Initialized
INFO - 2016-06-07 17:58:09 --> Language Class Initialized
INFO - 2016-06-07 17:58:10 --> Loader Class Initialized
INFO - 2016-06-07 17:58:10 --> Helper loaded: form_helper
INFO - 2016-06-07 17:58:10 --> Database Driver Class Initialized
INFO - 2016-06-07 17:58:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 17:58:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 17:58:10 --> Email Class Initialized
INFO - 2016-06-07 17:58:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 17:58:10 --> Helper loaded: cookie_helper
INFO - 2016-06-07 17:58:10 --> Helper loaded: language_helper
INFO - 2016-06-07 17:58:10 --> Helper loaded: url_helper
DEBUG - 2016-06-07 17:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 17:58:10 --> Model Class Initialized
INFO - 2016-06-07 17:58:10 --> Helper loaded: date_helper
INFO - 2016-06-07 17:58:10 --> Controller Class Initialized
INFO - 2016-06-07 17:58:10 --> Helper loaded: languages_helper
INFO - 2016-06-07 17:58:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 17:58:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 17:58:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 17:58:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 17:58:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 17:58:10 --> Model Class Initialized
INFO - 2016-06-07 17:58:10 --> Form Validation Class Initialized
INFO - 2016-06-07 17:58:10 --> Final output sent to browser
DEBUG - 2016-06-07 17:58:10 --> Total execution time: 0.0643
INFO - 2016-06-07 18:01:49 --> Config Class Initialized
INFO - 2016-06-07 18:01:49 --> Hooks Class Initialized
DEBUG - 2016-06-07 18:01:49 --> UTF-8 Support Enabled
INFO - 2016-06-07 18:01:49 --> Utf8 Class Initialized
INFO - 2016-06-07 18:01:49 --> URI Class Initialized
INFO - 2016-06-07 18:01:49 --> Router Class Initialized
INFO - 2016-06-07 18:01:49 --> Output Class Initialized
INFO - 2016-06-07 18:01:49 --> Security Class Initialized
DEBUG - 2016-06-07 18:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 18:01:49 --> Input Class Initialized
INFO - 2016-06-07 18:01:49 --> Language Class Initialized
INFO - 2016-06-07 18:01:49 --> Loader Class Initialized
INFO - 2016-06-07 18:01:49 --> Helper loaded: form_helper
INFO - 2016-06-07 18:01:49 --> Database Driver Class Initialized
INFO - 2016-06-07 18:01:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 18:01:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 18:01:49 --> Email Class Initialized
INFO - 2016-06-07 18:01:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 18:01:49 --> Helper loaded: cookie_helper
INFO - 2016-06-07 18:01:49 --> Helper loaded: language_helper
INFO - 2016-06-07 18:01:49 --> Helper loaded: url_helper
DEBUG - 2016-06-07 18:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 18:01:49 --> Model Class Initialized
INFO - 2016-06-07 18:01:49 --> Helper loaded: date_helper
INFO - 2016-06-07 18:01:49 --> Controller Class Initialized
INFO - 2016-06-07 18:01:49 --> Helper loaded: languages_helper
INFO - 2016-06-07 18:01:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 18:01:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 18:01:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 18:01:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 18:01:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 18:01:49 --> Model Class Initialized
INFO - 2016-06-07 18:01:49 --> Form Validation Class Initialized
INFO - 2016-06-07 18:01:49 --> Final output sent to browser
DEBUG - 2016-06-07 18:01:49 --> Total execution time: 0.0484
INFO - 2016-06-07 18:03:08 --> Config Class Initialized
INFO - 2016-06-07 18:03:08 --> Hooks Class Initialized
DEBUG - 2016-06-07 18:03:08 --> UTF-8 Support Enabled
INFO - 2016-06-07 18:03:08 --> Utf8 Class Initialized
INFO - 2016-06-07 18:03:08 --> URI Class Initialized
INFO - 2016-06-07 18:03:08 --> Router Class Initialized
INFO - 2016-06-07 18:03:08 --> Output Class Initialized
INFO - 2016-06-07 18:03:08 --> Security Class Initialized
DEBUG - 2016-06-07 18:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 18:03:08 --> Input Class Initialized
INFO - 2016-06-07 18:03:08 --> Language Class Initialized
INFO - 2016-06-07 18:03:08 --> Loader Class Initialized
INFO - 2016-06-07 18:03:08 --> Helper loaded: form_helper
INFO - 2016-06-07 18:03:08 --> Database Driver Class Initialized
INFO - 2016-06-07 18:03:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 18:03:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 18:03:08 --> Email Class Initialized
INFO - 2016-06-07 18:03:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 18:03:08 --> Helper loaded: cookie_helper
INFO - 2016-06-07 18:03:08 --> Helper loaded: language_helper
INFO - 2016-06-07 18:03:08 --> Helper loaded: url_helper
DEBUG - 2016-06-07 18:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 18:03:08 --> Model Class Initialized
INFO - 2016-06-07 18:03:08 --> Helper loaded: date_helper
INFO - 2016-06-07 18:03:08 --> Controller Class Initialized
INFO - 2016-06-07 18:03:08 --> Helper loaded: languages_helper
INFO - 2016-06-07 18:03:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 18:03:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 18:03:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 18:03:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 18:03:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 18:03:08 --> Model Class Initialized
INFO - 2016-06-07 18:03:08 --> Form Validation Class Initialized
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 18:03:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 18:03:08 --> Final output sent to browser
DEBUG - 2016-06-07 18:03:08 --> Total execution time: 0.0564
INFO - 2016-06-07 18:11:20 --> Config Class Initialized
INFO - 2016-06-07 18:11:20 --> Hooks Class Initialized
DEBUG - 2016-06-07 18:11:20 --> UTF-8 Support Enabled
INFO - 2016-06-07 18:11:20 --> Utf8 Class Initialized
INFO - 2016-06-07 18:11:20 --> URI Class Initialized
INFO - 2016-06-07 18:11:20 --> Router Class Initialized
INFO - 2016-06-07 18:11:20 --> Output Class Initialized
INFO - 2016-06-07 18:11:20 --> Security Class Initialized
DEBUG - 2016-06-07 18:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 18:11:20 --> Input Class Initialized
INFO - 2016-06-07 18:11:20 --> Language Class Initialized
INFO - 2016-06-07 18:11:20 --> Loader Class Initialized
INFO - 2016-06-07 18:11:20 --> Helper loaded: form_helper
INFO - 2016-06-07 18:11:20 --> Database Driver Class Initialized
INFO - 2016-06-07 18:11:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 18:11:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 18:11:20 --> Email Class Initialized
INFO - 2016-06-07 18:11:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 18:11:20 --> Helper loaded: cookie_helper
INFO - 2016-06-07 18:11:20 --> Helper loaded: language_helper
INFO - 2016-06-07 18:11:20 --> Helper loaded: url_helper
DEBUG - 2016-06-07 18:11:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 18:11:20 --> Model Class Initialized
INFO - 2016-06-07 18:11:20 --> Helper loaded: date_helper
INFO - 2016-06-07 18:11:20 --> Controller Class Initialized
INFO - 2016-06-07 18:11:20 --> Helper loaded: languages_helper
INFO - 2016-06-07 18:11:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 18:11:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 18:11:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 18:11:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 18:11:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 18:11:20 --> Model Class Initialized
INFO - 2016-06-07 18:11:20 --> Form Validation Class Initialized
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 18:11:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 18:11:20 --> Final output sent to browser
DEBUG - 2016-06-07 18:11:20 --> Total execution time: 0.0584
INFO - 2016-06-07 18:12:02 --> Config Class Initialized
INFO - 2016-06-07 18:12:02 --> Hooks Class Initialized
DEBUG - 2016-06-07 18:12:02 --> UTF-8 Support Enabled
INFO - 2016-06-07 18:12:02 --> Utf8 Class Initialized
INFO - 2016-06-07 18:12:02 --> URI Class Initialized
INFO - 2016-06-07 18:12:02 --> Router Class Initialized
INFO - 2016-06-07 18:12:02 --> Output Class Initialized
INFO - 2016-06-07 18:12:02 --> Security Class Initialized
DEBUG - 2016-06-07 18:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 18:12:02 --> Input Class Initialized
INFO - 2016-06-07 18:12:02 --> Language Class Initialized
INFO - 2016-06-07 18:12:02 --> Loader Class Initialized
INFO - 2016-06-07 18:12:02 --> Helper loaded: form_helper
INFO - 2016-06-07 18:12:02 --> Database Driver Class Initialized
INFO - 2016-06-07 18:12:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 18:12:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 18:12:02 --> Email Class Initialized
INFO - 2016-06-07 18:12:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 18:12:02 --> Helper loaded: cookie_helper
INFO - 2016-06-07 18:12:02 --> Helper loaded: language_helper
INFO - 2016-06-07 18:12:02 --> Helper loaded: url_helper
DEBUG - 2016-06-07 18:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 18:12:02 --> Model Class Initialized
INFO - 2016-06-07 18:12:02 --> Helper loaded: date_helper
INFO - 2016-06-07 18:12:02 --> Controller Class Initialized
INFO - 2016-06-07 18:12:02 --> Helper loaded: languages_helper
INFO - 2016-06-07 18:12:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 18:12:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 18:12:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 18:12:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 18:12:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 18:12:02 --> Model Class Initialized
INFO - 2016-06-07 18:12:02 --> Form Validation Class Initialized
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 18:12:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 18:12:02 --> Final output sent to browser
DEBUG - 2016-06-07 18:12:02 --> Total execution time: 0.1112
INFO - 2016-06-07 18:13:24 --> Config Class Initialized
INFO - 2016-06-07 18:13:24 --> Hooks Class Initialized
DEBUG - 2016-06-07 18:13:24 --> UTF-8 Support Enabled
INFO - 2016-06-07 18:13:24 --> Utf8 Class Initialized
INFO - 2016-06-07 18:13:24 --> URI Class Initialized
INFO - 2016-06-07 18:13:24 --> Router Class Initialized
INFO - 2016-06-07 18:13:24 --> Output Class Initialized
INFO - 2016-06-07 18:13:24 --> Security Class Initialized
DEBUG - 2016-06-07 18:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 18:13:24 --> Input Class Initialized
INFO - 2016-06-07 18:13:24 --> Language Class Initialized
INFO - 2016-06-07 18:13:24 --> Loader Class Initialized
INFO - 2016-06-07 18:13:24 --> Helper loaded: form_helper
INFO - 2016-06-07 18:13:24 --> Database Driver Class Initialized
INFO - 2016-06-07 18:13:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 18:13:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 18:13:24 --> Email Class Initialized
INFO - 2016-06-07 18:13:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 18:13:24 --> Helper loaded: cookie_helper
INFO - 2016-06-07 18:13:24 --> Helper loaded: language_helper
INFO - 2016-06-07 18:13:24 --> Helper loaded: url_helper
DEBUG - 2016-06-07 18:13:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 18:13:24 --> Model Class Initialized
INFO - 2016-06-07 18:13:24 --> Helper loaded: date_helper
INFO - 2016-06-07 18:13:24 --> Controller Class Initialized
INFO - 2016-06-07 18:13:24 --> Helper loaded: languages_helper
INFO - 2016-06-07 18:13:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 18:13:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 18:13:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 18:13:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 18:13:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 18:13:24 --> Model Class Initialized
INFO - 2016-06-07 18:13:24 --> Form Validation Class Initialized
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-07 18:13:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-07 18:13:24 --> Final output sent to browser
DEBUG - 2016-06-07 18:13:24 --> Total execution time: 0.0980
INFO - 2016-06-07 18:14:09 --> Config Class Initialized
INFO - 2016-06-07 18:14:09 --> Hooks Class Initialized
DEBUG - 2016-06-07 18:14:09 --> UTF-8 Support Enabled
INFO - 2016-06-07 18:14:09 --> Utf8 Class Initialized
INFO - 2016-06-07 18:14:09 --> URI Class Initialized
INFO - 2016-06-07 18:14:09 --> Router Class Initialized
INFO - 2016-06-07 18:14:09 --> Output Class Initialized
INFO - 2016-06-07 18:14:09 --> Security Class Initialized
DEBUG - 2016-06-07 18:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 18:14:09 --> Input Class Initialized
INFO - 2016-06-07 18:14:09 --> Language Class Initialized
INFO - 2016-06-07 18:14:09 --> Loader Class Initialized
INFO - 2016-06-07 18:14:09 --> Helper loaded: form_helper
INFO - 2016-06-07 18:14:09 --> Database Driver Class Initialized
INFO - 2016-06-07 18:14:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 18:14:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 18:14:09 --> Email Class Initialized
INFO - 2016-06-07 18:14:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 18:14:09 --> Helper loaded: cookie_helper
INFO - 2016-06-07 18:14:09 --> Helper loaded: language_helper
INFO - 2016-06-07 18:14:09 --> Helper loaded: url_helper
DEBUG - 2016-06-07 18:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 18:14:09 --> Model Class Initialized
INFO - 2016-06-07 18:14:09 --> Helper loaded: date_helper
INFO - 2016-06-07 18:14:09 --> Controller Class Initialized
INFO - 2016-06-07 18:14:09 --> Helper loaded: languages_helper
INFO - 2016-06-07 18:14:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 18:14:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 18:14:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 18:14:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 18:14:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 18:14:09 --> Model Class Initialized
INFO - 2016-06-07 18:14:09 --> Form Validation Class Initialized
INFO - 2016-06-07 18:14:09 --> Final output sent to browser
DEBUG - 2016-06-07 18:14:09 --> Total execution time: 0.0450
INFO - 2016-06-07 18:14:49 --> Config Class Initialized
INFO - 2016-06-07 18:14:49 --> Hooks Class Initialized
DEBUG - 2016-06-07 18:14:49 --> UTF-8 Support Enabled
INFO - 2016-06-07 18:14:49 --> Utf8 Class Initialized
INFO - 2016-06-07 18:14:49 --> URI Class Initialized
INFO - 2016-06-07 18:14:49 --> Router Class Initialized
INFO - 2016-06-07 18:14:49 --> Output Class Initialized
INFO - 2016-06-07 18:14:49 --> Security Class Initialized
DEBUG - 2016-06-07 18:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-07 18:14:49 --> Input Class Initialized
INFO - 2016-06-07 18:14:49 --> Language Class Initialized
INFO - 2016-06-07 18:14:49 --> Loader Class Initialized
INFO - 2016-06-07 18:14:49 --> Helper loaded: form_helper
INFO - 2016-06-07 18:14:49 --> Database Driver Class Initialized
INFO - 2016-06-07 18:14:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-07 18:14:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-07 18:14:49 --> Email Class Initialized
INFO - 2016-06-07 18:14:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-07 18:14:49 --> Helper loaded: cookie_helper
INFO - 2016-06-07 18:14:49 --> Helper loaded: language_helper
INFO - 2016-06-07 18:14:49 --> Helper loaded: url_helper
DEBUG - 2016-06-07 18:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-07 18:14:49 --> Model Class Initialized
INFO - 2016-06-07 18:14:49 --> Helper loaded: date_helper
INFO - 2016-06-07 18:14:49 --> Controller Class Initialized
INFO - 2016-06-07 18:14:49 --> Helper loaded: languages_helper
INFO - 2016-06-07 18:14:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-07 18:14:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-07 18:14:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-07 18:14:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-07 18:14:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-07 18:14:49 --> Model Class Initialized
INFO - 2016-06-07 18:14:49 --> Form Validation Class Initialized
INFO - 2016-06-07 18:14:49 --> Final output sent to browser
DEBUG - 2016-06-07 18:14:49 --> Total execution time: 0.0267
