<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-10 10:43:58 --> Config Class Initialized
INFO - 2016-06-10 10:43:58 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:43:58 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:43:58 --> Utf8 Class Initialized
INFO - 2016-06-10 10:43:58 --> URI Class Initialized
DEBUG - 2016-06-10 10:43:58 --> No URI present. Default controller set.
INFO - 2016-06-10 10:43:58 --> Router Class Initialized
INFO - 2016-06-10 10:43:58 --> Output Class Initialized
INFO - 2016-06-10 10:43:58 --> Security Class Initialized
DEBUG - 2016-06-10 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:43:58 --> Input Class Initialized
INFO - 2016-06-10 10:43:58 --> Language Class Initialized
INFO - 2016-06-10 10:43:58 --> Loader Class Initialized
INFO - 2016-06-10 10:43:58 --> Helper loaded: form_helper
INFO - 2016-06-10 10:43:58 --> Database Driver Class Initialized
INFO - 2016-06-10 10:43:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:43:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:43:58 --> Email Class Initialized
INFO - 2016-06-10 10:43:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:43:59 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:43:59 --> Helper loaded: language_helper
INFO - 2016-06-10 10:43:59 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:43:59 --> Model Class Initialized
INFO - 2016-06-10 10:43:59 --> Helper loaded: date_helper
INFO - 2016-06-10 10:43:59 --> Controller Class Initialized
INFO - 2016-06-10 10:43:59 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:43:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:43:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:43:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:43:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:43:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:43:59 --> Model Class Initialized
INFO - 2016-06-10 10:43:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 10:43:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 10:43:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 10:43:59 --> Final output sent to browser
DEBUG - 2016-06-10 10:43:59 --> Total execution time: 0.8583
INFO - 2016-06-10 10:44:01 --> Config Class Initialized
INFO - 2016-06-10 10:44:01 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:44:01 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:44:01 --> Utf8 Class Initialized
INFO - 2016-06-10 10:44:01 --> URI Class Initialized
INFO - 2016-06-10 10:44:01 --> Router Class Initialized
INFO - 2016-06-10 10:44:01 --> Output Class Initialized
INFO - 2016-06-10 10:44:01 --> Security Class Initialized
DEBUG - 2016-06-10 10:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:44:01 --> Input Class Initialized
INFO - 2016-06-10 10:44:01 --> Language Class Initialized
ERROR - 2016-06-10 10:44:01 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-10 10:44:04 --> Config Class Initialized
INFO - 2016-06-10 10:44:04 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:44:04 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:44:04 --> Utf8 Class Initialized
INFO - 2016-06-10 10:44:04 --> URI Class Initialized
INFO - 2016-06-10 10:44:04 --> Router Class Initialized
INFO - 2016-06-10 10:44:04 --> Output Class Initialized
INFO - 2016-06-10 10:44:04 --> Security Class Initialized
DEBUG - 2016-06-10 10:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:44:04 --> Input Class Initialized
INFO - 2016-06-10 10:44:04 --> Language Class Initialized
INFO - 2016-06-10 10:44:04 --> Loader Class Initialized
INFO - 2016-06-10 10:44:04 --> Helper loaded: form_helper
INFO - 2016-06-10 10:44:04 --> Database Driver Class Initialized
INFO - 2016-06-10 10:44:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:44:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:44:04 --> Email Class Initialized
INFO - 2016-06-10 10:44:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:44:04 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:44:04 --> Helper loaded: language_helper
INFO - 2016-06-10 10:44:04 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:04 --> Model Class Initialized
INFO - 2016-06-10 10:44:04 --> Helper loaded: date_helper
INFO - 2016-06-10 10:44:04 --> Controller Class Initialized
INFO - 2016-06-10 10:44:04 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:44:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:44:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:44:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:44:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:44:04 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 10:44:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:04 --> Form Validation Class Initialized
DEBUG - 2016-06-10 10:44:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 10:44:04 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 10:44:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 10:44:04 --> Final output sent to browser
DEBUG - 2016-06-10 10:44:04 --> Total execution time: 0.0848
INFO - 2016-06-10 10:44:12 --> Config Class Initialized
INFO - 2016-06-10 10:44:12 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:44:12 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:44:12 --> Utf8 Class Initialized
INFO - 2016-06-10 10:44:12 --> URI Class Initialized
INFO - 2016-06-10 10:44:12 --> Router Class Initialized
INFO - 2016-06-10 10:44:12 --> Output Class Initialized
INFO - 2016-06-10 10:44:12 --> Security Class Initialized
DEBUG - 2016-06-10 10:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:44:12 --> Input Class Initialized
INFO - 2016-06-10 10:44:12 --> Language Class Initialized
INFO - 2016-06-10 10:44:12 --> Loader Class Initialized
INFO - 2016-06-10 10:44:12 --> Helper loaded: form_helper
INFO - 2016-06-10 10:44:12 --> Database Driver Class Initialized
INFO - 2016-06-10 10:44:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:44:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:44:12 --> Email Class Initialized
INFO - 2016-06-10 10:44:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:44:12 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:44:12 --> Helper loaded: language_helper
INFO - 2016-06-10 10:44:12 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:12 --> Model Class Initialized
INFO - 2016-06-10 10:44:12 --> Helper loaded: date_helper
INFO - 2016-06-10 10:44:12 --> Controller Class Initialized
INFO - 2016-06-10 10:44:12 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:44:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:44:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:44:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:44:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:44:12 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 10:44:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:12 --> Form Validation Class Initialized
DEBUG - 2016-06-10 10:44:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 10:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 10:44:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 10:44:12 --> Final output sent to browser
DEBUG - 2016-06-10 10:44:12 --> Total execution time: 0.0424
INFO - 2016-06-10 10:44:27 --> Config Class Initialized
INFO - 2016-06-10 10:44:27 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:44:27 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:44:27 --> Utf8 Class Initialized
INFO - 2016-06-10 10:44:27 --> URI Class Initialized
INFO - 2016-06-10 10:44:27 --> Router Class Initialized
INFO - 2016-06-10 10:44:27 --> Output Class Initialized
INFO - 2016-06-10 10:44:27 --> Security Class Initialized
DEBUG - 2016-06-10 10:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:44:27 --> Input Class Initialized
INFO - 2016-06-10 10:44:27 --> Language Class Initialized
INFO - 2016-06-10 10:44:27 --> Loader Class Initialized
INFO - 2016-06-10 10:44:27 --> Helper loaded: form_helper
INFO - 2016-06-10 10:44:27 --> Database Driver Class Initialized
INFO - 2016-06-10 10:44:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:44:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:44:27 --> Email Class Initialized
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:44:27 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:44:27 --> Helper loaded: language_helper
INFO - 2016-06-10 10:44:27 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:27 --> Model Class Initialized
INFO - 2016-06-10 10:44:27 --> Helper loaded: date_helper
INFO - 2016-06-10 10:44:27 --> Controller Class Initialized
INFO - 2016-06-10 10:44:27 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 10:44:27 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:27 --> Form Validation Class Initialized
DEBUG - 2016-06-10 10:44:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:27 --> Config Class Initialized
INFO - 2016-06-10 10:44:27 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:44:27 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:44:27 --> Utf8 Class Initialized
INFO - 2016-06-10 10:44:27 --> URI Class Initialized
DEBUG - 2016-06-10 10:44:27 --> No URI present. Default controller set.
INFO - 2016-06-10 10:44:27 --> Router Class Initialized
INFO - 2016-06-10 10:44:27 --> Output Class Initialized
INFO - 2016-06-10 10:44:27 --> Security Class Initialized
DEBUG - 2016-06-10 10:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:44:27 --> Input Class Initialized
INFO - 2016-06-10 10:44:27 --> Language Class Initialized
INFO - 2016-06-10 10:44:27 --> Loader Class Initialized
INFO - 2016-06-10 10:44:27 --> Helper loaded: form_helper
INFO - 2016-06-10 10:44:27 --> Database Driver Class Initialized
INFO - 2016-06-10 10:44:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:44:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:44:27 --> Email Class Initialized
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:44:27 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:44:27 --> Helper loaded: language_helper
INFO - 2016-06-10 10:44:27 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:27 --> Model Class Initialized
INFO - 2016-06-10 10:44:27 --> Helper loaded: date_helper
INFO - 2016-06-10 10:44:27 --> Controller Class Initialized
INFO - 2016-06-10 10:44:27 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:44:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:44:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:44:28 --> Config Class Initialized
INFO - 2016-06-10 10:44:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:44:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:44:28 --> Utf8 Class Initialized
INFO - 2016-06-10 10:44:28 --> URI Class Initialized
INFO - 2016-06-10 10:44:28 --> Router Class Initialized
INFO - 2016-06-10 10:44:28 --> Output Class Initialized
INFO - 2016-06-10 10:44:28 --> Security Class Initialized
DEBUG - 2016-06-10 10:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:44:28 --> Input Class Initialized
INFO - 2016-06-10 10:44:28 --> Language Class Initialized
INFO - 2016-06-10 10:44:28 --> Loader Class Initialized
INFO - 2016-06-10 10:44:28 --> Helper loaded: form_helper
INFO - 2016-06-10 10:44:28 --> Database Driver Class Initialized
INFO - 2016-06-10 10:44:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:44:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:44:28 --> Email Class Initialized
INFO - 2016-06-10 10:44:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:44:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:44:28 --> Helper loaded: language_helper
INFO - 2016-06-10 10:44:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:28 --> Model Class Initialized
INFO - 2016-06-10 10:44:28 --> Helper loaded: date_helper
INFO - 2016-06-10 10:44:28 --> Controller Class Initialized
INFO - 2016-06-10 10:44:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:44:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:44:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:44:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:44:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:44:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:44:28 --> Model Class Initialized
INFO - 2016-06-10 10:44:28 --> Form Validation Class Initialized
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 10:44:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 10:44:28 --> Final output sent to browser
DEBUG - 2016-06-10 10:44:28 --> Total execution time: 0.2715
INFO - 2016-06-10 10:44:30 --> Config Class Initialized
INFO - 2016-06-10 10:44:30 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:44:31 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:44:31 --> Utf8 Class Initialized
INFO - 2016-06-10 10:44:31 --> URI Class Initialized
INFO - 2016-06-10 10:44:31 --> Router Class Initialized
INFO - 2016-06-10 10:44:31 --> Output Class Initialized
INFO - 2016-06-10 10:44:31 --> Security Class Initialized
DEBUG - 2016-06-10 10:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:44:31 --> Input Class Initialized
INFO - 2016-06-10 10:44:31 --> Language Class Initialized
INFO - 2016-06-10 10:44:31 --> Loader Class Initialized
INFO - 2016-06-10 10:44:31 --> Helper loaded: form_helper
INFO - 2016-06-10 10:44:31 --> Database Driver Class Initialized
INFO - 2016-06-10 10:44:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:44:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:44:31 --> Email Class Initialized
INFO - 2016-06-10 10:44:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:44:31 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:44:31 --> Helper loaded: language_helper
INFO - 2016-06-10 10:44:31 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:44:31 --> Model Class Initialized
INFO - 2016-06-10 10:44:31 --> Helper loaded: date_helper
INFO - 2016-06-10 10:44:31 --> Controller Class Initialized
INFO - 2016-06-10 10:44:31 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:44:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:44:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:44:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:44:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:44:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:44:31 --> Model Class Initialized
INFO - 2016-06-10 10:44:31 --> Form Validation Class Initialized
INFO - 2016-06-10 10:44:31 --> Final output sent to browser
DEBUG - 2016-06-10 10:44:31 --> Total execution time: 0.0172
INFO - 2016-06-10 10:47:08 --> Config Class Initialized
INFO - 2016-06-10 10:47:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:47:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:47:08 --> Utf8 Class Initialized
INFO - 2016-06-10 10:47:08 --> URI Class Initialized
INFO - 2016-06-10 10:47:08 --> Router Class Initialized
INFO - 2016-06-10 10:47:08 --> Output Class Initialized
INFO - 2016-06-10 10:47:08 --> Security Class Initialized
DEBUG - 2016-06-10 10:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:47:08 --> Input Class Initialized
INFO - 2016-06-10 10:47:08 --> Language Class Initialized
INFO - 2016-06-10 10:47:08 --> Loader Class Initialized
INFO - 2016-06-10 10:47:08 --> Helper loaded: form_helper
INFO - 2016-06-10 10:47:08 --> Database Driver Class Initialized
INFO - 2016-06-10 10:47:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:47:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:47:08 --> Email Class Initialized
INFO - 2016-06-10 10:47:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:47:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:47:08 --> Helper loaded: language_helper
INFO - 2016-06-10 10:47:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:47:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:47:08 --> Model Class Initialized
INFO - 2016-06-10 10:47:08 --> Helper loaded: date_helper
INFO - 2016-06-10 10:47:08 --> Controller Class Initialized
INFO - 2016-06-10 10:47:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:47:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:47:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:47:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:47:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:47:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:47:08 --> Model Class Initialized
INFO - 2016-06-10 10:47:08 --> Form Validation Class Initialized
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 10:47:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 10:47:08 --> Final output sent to browser
DEBUG - 2016-06-10 10:47:08 --> Total execution time: 0.1514
INFO - 2016-06-10 10:47:14 --> Config Class Initialized
INFO - 2016-06-10 10:47:14 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:47:14 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:47:14 --> Utf8 Class Initialized
INFO - 2016-06-10 10:47:14 --> URI Class Initialized
INFO - 2016-06-10 10:47:14 --> Router Class Initialized
INFO - 2016-06-10 10:47:14 --> Output Class Initialized
INFO - 2016-06-10 10:47:14 --> Security Class Initialized
DEBUG - 2016-06-10 10:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:47:14 --> Input Class Initialized
INFO - 2016-06-10 10:47:14 --> Language Class Initialized
INFO - 2016-06-10 10:47:14 --> Loader Class Initialized
INFO - 2016-06-10 10:47:14 --> Helper loaded: form_helper
INFO - 2016-06-10 10:47:14 --> Database Driver Class Initialized
INFO - 2016-06-10 10:47:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:47:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:47:14 --> Email Class Initialized
INFO - 2016-06-10 10:47:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:47:14 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:47:14 --> Helper loaded: language_helper
INFO - 2016-06-10 10:47:14 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:47:14 --> Model Class Initialized
INFO - 2016-06-10 10:47:14 --> Helper loaded: date_helper
INFO - 2016-06-10 10:47:14 --> Controller Class Initialized
INFO - 2016-06-10 10:47:14 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:47:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:47:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:47:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:47:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:47:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:47:14 --> Model Class Initialized
INFO - 2016-06-10 10:47:14 --> Form Validation Class Initialized
INFO - 2016-06-10 10:47:14 --> Final output sent to browser
DEBUG - 2016-06-10 10:47:14 --> Total execution time: 0.0562
INFO - 2016-06-10 10:49:50 --> Config Class Initialized
INFO - 2016-06-10 10:49:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:49:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:49:50 --> Utf8 Class Initialized
INFO - 2016-06-10 10:49:50 --> URI Class Initialized
INFO - 2016-06-10 10:49:50 --> Router Class Initialized
INFO - 2016-06-10 10:49:50 --> Output Class Initialized
INFO - 2016-06-10 10:49:50 --> Security Class Initialized
DEBUG - 2016-06-10 10:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:49:50 --> Input Class Initialized
INFO - 2016-06-10 10:49:50 --> Language Class Initialized
INFO - 2016-06-10 10:49:50 --> Loader Class Initialized
INFO - 2016-06-10 10:49:50 --> Helper loaded: form_helper
INFO - 2016-06-10 10:49:50 --> Database Driver Class Initialized
INFO - 2016-06-10 10:49:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:49:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:49:50 --> Email Class Initialized
INFO - 2016-06-10 10:49:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:49:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:49:50 --> Helper loaded: language_helper
INFO - 2016-06-10 10:49:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:49:50 --> Model Class Initialized
INFO - 2016-06-10 10:49:50 --> Helper loaded: date_helper
INFO - 2016-06-10 10:49:50 --> Controller Class Initialized
INFO - 2016-06-10 10:49:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:49:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:49:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:49:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:49:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:49:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:49:50 --> Model Class Initialized
INFO - 2016-06-10 10:49:50 --> Form Validation Class Initialized
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 10:49:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 10:49:50 --> Final output sent to browser
DEBUG - 2016-06-10 10:49:50 --> Total execution time: 0.0402
INFO - 2016-06-10 10:49:55 --> Config Class Initialized
INFO - 2016-06-10 10:49:55 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:49:55 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:49:55 --> Utf8 Class Initialized
INFO - 2016-06-10 10:49:55 --> URI Class Initialized
INFO - 2016-06-10 10:49:55 --> Router Class Initialized
INFO - 2016-06-10 10:49:55 --> Output Class Initialized
INFO - 2016-06-10 10:49:55 --> Security Class Initialized
DEBUG - 2016-06-10 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:49:55 --> Input Class Initialized
INFO - 2016-06-10 10:49:55 --> Language Class Initialized
INFO - 2016-06-10 10:49:55 --> Loader Class Initialized
INFO - 2016-06-10 10:49:55 --> Helper loaded: form_helper
INFO - 2016-06-10 10:49:55 --> Database Driver Class Initialized
INFO - 2016-06-10 10:49:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:49:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:49:55 --> Email Class Initialized
INFO - 2016-06-10 10:49:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:49:55 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:49:55 --> Helper loaded: language_helper
INFO - 2016-06-10 10:49:55 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:49:55 --> Model Class Initialized
INFO - 2016-06-10 10:49:55 --> Helper loaded: date_helper
INFO - 2016-06-10 10:49:55 --> Controller Class Initialized
INFO - 2016-06-10 10:49:55 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:49:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:49:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:49:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:49:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:49:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:49:55 --> Model Class Initialized
INFO - 2016-06-10 10:49:55 --> Form Validation Class Initialized
INFO - 2016-06-10 10:49:55 --> Final output sent to browser
DEBUG - 2016-06-10 10:49:55 --> Total execution time: 0.0267
INFO - 2016-06-10 10:51:15 --> Config Class Initialized
INFO - 2016-06-10 10:51:15 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:51:15 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:51:15 --> Utf8 Class Initialized
INFO - 2016-06-10 10:51:15 --> URI Class Initialized
INFO - 2016-06-10 10:51:15 --> Router Class Initialized
INFO - 2016-06-10 10:51:15 --> Output Class Initialized
INFO - 2016-06-10 10:51:15 --> Security Class Initialized
DEBUG - 2016-06-10 10:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:51:15 --> Input Class Initialized
INFO - 2016-06-10 10:51:15 --> Language Class Initialized
INFO - 2016-06-10 10:51:15 --> Loader Class Initialized
INFO - 2016-06-10 10:51:15 --> Helper loaded: form_helper
INFO - 2016-06-10 10:51:15 --> Database Driver Class Initialized
INFO - 2016-06-10 10:51:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:51:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:51:15 --> Email Class Initialized
INFO - 2016-06-10 10:51:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:51:15 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:51:15 --> Helper loaded: language_helper
INFO - 2016-06-10 10:51:15 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:51:15 --> Model Class Initialized
INFO - 2016-06-10 10:51:15 --> Helper loaded: date_helper
INFO - 2016-06-10 10:51:15 --> Controller Class Initialized
INFO - 2016-06-10 10:51:15 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:51:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:51:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:51:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:51:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:51:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:51:15 --> Model Class Initialized
INFO - 2016-06-10 10:51:15 --> Form Validation Class Initialized
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 10:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 10:51:15 --> Final output sent to browser
DEBUG - 2016-06-10 10:51:15 --> Total execution time: 0.2172
INFO - 2016-06-10 10:51:20 --> Config Class Initialized
INFO - 2016-06-10 10:51:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:51:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:51:20 --> Utf8 Class Initialized
INFO - 2016-06-10 10:51:20 --> URI Class Initialized
INFO - 2016-06-10 10:51:20 --> Router Class Initialized
INFO - 2016-06-10 10:51:20 --> Output Class Initialized
INFO - 2016-06-10 10:51:20 --> Security Class Initialized
DEBUG - 2016-06-10 10:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:51:20 --> Input Class Initialized
INFO - 2016-06-10 10:51:20 --> Language Class Initialized
INFO - 2016-06-10 10:51:20 --> Loader Class Initialized
INFO - 2016-06-10 10:51:20 --> Helper loaded: form_helper
INFO - 2016-06-10 10:51:20 --> Database Driver Class Initialized
INFO - 2016-06-10 10:51:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:51:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:51:20 --> Email Class Initialized
INFO - 2016-06-10 10:51:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:51:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:51:20 --> Helper loaded: language_helper
INFO - 2016-06-10 10:51:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:51:20 --> Model Class Initialized
INFO - 2016-06-10 10:51:20 --> Helper loaded: date_helper
INFO - 2016-06-10 10:51:20 --> Controller Class Initialized
INFO - 2016-06-10 10:51:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:51:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:51:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:51:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:51:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:51:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:51:20 --> Model Class Initialized
INFO - 2016-06-10 10:51:20 --> Form Validation Class Initialized
INFO - 2016-06-10 10:51:20 --> Final output sent to browser
DEBUG - 2016-06-10 10:51:20 --> Total execution time: 0.0374
INFO - 2016-06-10 10:52:21 --> Config Class Initialized
INFO - 2016-06-10 10:52:21 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:52:21 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:52:21 --> Utf8 Class Initialized
INFO - 2016-06-10 10:52:21 --> URI Class Initialized
INFO - 2016-06-10 10:52:21 --> Router Class Initialized
INFO - 2016-06-10 10:52:21 --> Output Class Initialized
INFO - 2016-06-10 10:52:21 --> Security Class Initialized
DEBUG - 2016-06-10 10:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:52:21 --> Input Class Initialized
INFO - 2016-06-10 10:52:21 --> Language Class Initialized
INFO - 2016-06-10 10:52:21 --> Loader Class Initialized
INFO - 2016-06-10 10:52:21 --> Helper loaded: form_helper
INFO - 2016-06-10 10:52:21 --> Database Driver Class Initialized
INFO - 2016-06-10 10:52:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:52:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:52:21 --> Email Class Initialized
INFO - 2016-06-10 10:52:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:52:21 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:52:21 --> Helper loaded: language_helper
INFO - 2016-06-10 10:52:21 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:52:21 --> Model Class Initialized
INFO - 2016-06-10 10:52:21 --> Helper loaded: date_helper
INFO - 2016-06-10 10:52:21 --> Controller Class Initialized
INFO - 2016-06-10 10:52:21 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:52:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:52:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:52:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:52:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:52:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:52:21 --> Model Class Initialized
INFO - 2016-06-10 10:52:21 --> Form Validation Class Initialized
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 10:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 10:52:21 --> Final output sent to browser
DEBUG - 2016-06-10 10:52:21 --> Total execution time: 0.0721
INFO - 2016-06-10 10:52:26 --> Config Class Initialized
INFO - 2016-06-10 10:52:26 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:52:26 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:52:26 --> Utf8 Class Initialized
INFO - 2016-06-10 10:52:26 --> URI Class Initialized
INFO - 2016-06-10 10:52:26 --> Router Class Initialized
INFO - 2016-06-10 10:52:26 --> Output Class Initialized
INFO - 2016-06-10 10:52:26 --> Security Class Initialized
DEBUG - 2016-06-10 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:52:26 --> Input Class Initialized
INFO - 2016-06-10 10:52:26 --> Language Class Initialized
INFO - 2016-06-10 10:52:26 --> Loader Class Initialized
INFO - 2016-06-10 10:52:26 --> Helper loaded: form_helper
INFO - 2016-06-10 10:52:26 --> Database Driver Class Initialized
INFO - 2016-06-10 10:52:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:52:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:52:26 --> Email Class Initialized
INFO - 2016-06-10 10:52:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:52:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:52:26 --> Helper loaded: language_helper
INFO - 2016-06-10 10:52:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:52:26 --> Model Class Initialized
INFO - 2016-06-10 10:52:26 --> Helper loaded: date_helper
INFO - 2016-06-10 10:52:26 --> Controller Class Initialized
INFO - 2016-06-10 10:52:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:52:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:52:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:52:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:52:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:52:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:52:26 --> Model Class Initialized
INFO - 2016-06-10 10:52:26 --> Form Validation Class Initialized
INFO - 2016-06-10 10:55:17 --> Config Class Initialized
INFO - 2016-06-10 10:55:17 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:55:17 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:55:17 --> Utf8 Class Initialized
INFO - 2016-06-10 10:55:17 --> URI Class Initialized
INFO - 2016-06-10 10:55:17 --> Router Class Initialized
INFO - 2016-06-10 10:55:17 --> Output Class Initialized
INFO - 2016-06-10 10:55:17 --> Security Class Initialized
DEBUG - 2016-06-10 10:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:55:17 --> Input Class Initialized
INFO - 2016-06-10 10:55:17 --> Language Class Initialized
ERROR - 2016-06-10 10:55:17 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /home/demis/www/platformadiabet/application/controllers/Diabet.php 396
INFO - 2016-06-10 10:55:40 --> Config Class Initialized
INFO - 2016-06-10 10:55:40 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:55:40 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:55:40 --> Utf8 Class Initialized
INFO - 2016-06-10 10:55:40 --> URI Class Initialized
INFO - 2016-06-10 10:55:40 --> Router Class Initialized
INFO - 2016-06-10 10:55:40 --> Output Class Initialized
INFO - 2016-06-10 10:55:40 --> Security Class Initialized
DEBUG - 2016-06-10 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:55:40 --> Input Class Initialized
INFO - 2016-06-10 10:55:40 --> Language Class Initialized
ERROR - 2016-06-10 10:55:40 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /home/demis/www/platformadiabet/application/controllers/Diabet.php 396
INFO - 2016-06-10 10:57:52 --> Config Class Initialized
INFO - 2016-06-10 10:57:52 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:57:52 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:57:52 --> Utf8 Class Initialized
INFO - 2016-06-10 10:57:52 --> URI Class Initialized
INFO - 2016-06-10 10:57:52 --> Router Class Initialized
INFO - 2016-06-10 10:57:52 --> Output Class Initialized
INFO - 2016-06-10 10:57:52 --> Security Class Initialized
DEBUG - 2016-06-10 10:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:57:52 --> Input Class Initialized
INFO - 2016-06-10 10:57:52 --> Language Class Initialized
INFO - 2016-06-10 10:57:52 --> Loader Class Initialized
INFO - 2016-06-10 10:57:52 --> Helper loaded: form_helper
INFO - 2016-06-10 10:57:52 --> Database Driver Class Initialized
INFO - 2016-06-10 10:57:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:57:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:57:52 --> Email Class Initialized
INFO - 2016-06-10 10:57:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:57:52 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:57:52 --> Helper loaded: language_helper
INFO - 2016-06-10 10:57:52 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:57:52 --> Model Class Initialized
INFO - 2016-06-10 10:57:52 --> Helper loaded: date_helper
INFO - 2016-06-10 10:57:52 --> Controller Class Initialized
INFO - 2016-06-10 10:57:52 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:57:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:57:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:57:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:57:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:57:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:57:52 --> Model Class Initialized
INFO - 2016-06-10 10:57:52 --> Form Validation Class Initialized
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 10:57:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 10:57:52 --> Final output sent to browser
DEBUG - 2016-06-10 10:57:52 --> Total execution time: 0.4335
INFO - 2016-06-10 10:57:57 --> Config Class Initialized
INFO - 2016-06-10 10:57:57 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:57:57 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:57:57 --> Utf8 Class Initialized
INFO - 2016-06-10 10:57:57 --> URI Class Initialized
INFO - 2016-06-10 10:57:57 --> Router Class Initialized
INFO - 2016-06-10 10:57:57 --> Output Class Initialized
INFO - 2016-06-10 10:57:57 --> Security Class Initialized
DEBUG - 2016-06-10 10:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:57:57 --> Input Class Initialized
INFO - 2016-06-10 10:57:57 --> Language Class Initialized
INFO - 2016-06-10 10:57:57 --> Loader Class Initialized
INFO - 2016-06-10 10:57:57 --> Helper loaded: form_helper
INFO - 2016-06-10 10:57:57 --> Database Driver Class Initialized
INFO - 2016-06-10 10:57:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:57:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:57:57 --> Email Class Initialized
INFO - 2016-06-10 10:57:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:57:57 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:57:57 --> Helper loaded: language_helper
INFO - 2016-06-10 10:57:57 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:57:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:57:57 --> Model Class Initialized
INFO - 2016-06-10 10:57:57 --> Helper loaded: date_helper
INFO - 2016-06-10 10:57:57 --> Controller Class Initialized
INFO - 2016-06-10 10:57:57 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:57:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:57:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:57:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:57:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:57:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:57:57 --> Model Class Initialized
INFO - 2016-06-10 10:57:57 --> Form Validation Class Initialized
ERROR - 2016-06-10 10:57:57 --> Could not find the language line "hipoglicemiei"
INFO - 2016-06-10 10:59:47 --> Config Class Initialized
INFO - 2016-06-10 10:59:47 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:59:47 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:59:47 --> Utf8 Class Initialized
INFO - 2016-06-10 10:59:47 --> URI Class Initialized
INFO - 2016-06-10 10:59:47 --> Router Class Initialized
INFO - 2016-06-10 10:59:47 --> Output Class Initialized
INFO - 2016-06-10 10:59:47 --> Security Class Initialized
DEBUG - 2016-06-10 10:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:59:47 --> Input Class Initialized
INFO - 2016-06-10 10:59:47 --> Language Class Initialized
INFO - 2016-06-10 10:59:47 --> Loader Class Initialized
INFO - 2016-06-10 10:59:48 --> Helper loaded: form_helper
INFO - 2016-06-10 10:59:48 --> Database Driver Class Initialized
INFO - 2016-06-10 10:59:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:59:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:59:48 --> Email Class Initialized
INFO - 2016-06-10 10:59:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:59:48 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:59:48 --> Helper loaded: language_helper
INFO - 2016-06-10 10:59:48 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:59:48 --> Model Class Initialized
INFO - 2016-06-10 10:59:48 --> Helper loaded: date_helper
INFO - 2016-06-10 10:59:48 --> Controller Class Initialized
INFO - 2016-06-10 10:59:48 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:59:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:59:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:59:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:59:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:59:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:59:48 --> Model Class Initialized
INFO - 2016-06-10 10:59:48 --> Form Validation Class Initialized
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 10:59:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 10:59:48 --> Final output sent to browser
DEBUG - 2016-06-10 10:59:48 --> Total execution time: 0.4963
INFO - 2016-06-10 10:59:54 --> Config Class Initialized
INFO - 2016-06-10 10:59:54 --> Hooks Class Initialized
DEBUG - 2016-06-10 10:59:54 --> UTF-8 Support Enabled
INFO - 2016-06-10 10:59:54 --> Utf8 Class Initialized
INFO - 2016-06-10 10:59:54 --> URI Class Initialized
INFO - 2016-06-10 10:59:54 --> Router Class Initialized
INFO - 2016-06-10 10:59:54 --> Output Class Initialized
INFO - 2016-06-10 10:59:54 --> Security Class Initialized
DEBUG - 2016-06-10 10:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 10:59:54 --> Input Class Initialized
INFO - 2016-06-10 10:59:54 --> Language Class Initialized
INFO - 2016-06-10 10:59:54 --> Loader Class Initialized
INFO - 2016-06-10 10:59:54 --> Helper loaded: form_helper
INFO - 2016-06-10 10:59:54 --> Database Driver Class Initialized
INFO - 2016-06-10 10:59:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 10:59:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 10:59:54 --> Email Class Initialized
INFO - 2016-06-10 10:59:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 10:59:54 --> Helper loaded: cookie_helper
INFO - 2016-06-10 10:59:54 --> Helper loaded: language_helper
INFO - 2016-06-10 10:59:54 --> Helper loaded: url_helper
DEBUG - 2016-06-10 10:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 10:59:54 --> Model Class Initialized
INFO - 2016-06-10 10:59:54 --> Helper loaded: date_helper
INFO - 2016-06-10 10:59:54 --> Controller Class Initialized
INFO - 2016-06-10 10:59:54 --> Helper loaded: languages_helper
INFO - 2016-06-10 10:59:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 10:59:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 10:59:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 10:59:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 10:59:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 10:59:54 --> Model Class Initialized
INFO - 2016-06-10 10:59:54 --> Form Validation Class Initialized
ERROR - 2016-06-10 10:59:54 --> Could not find the language line "hipoglicemiei"
INFO - 2016-06-10 11:00:36 --> Config Class Initialized
INFO - 2016-06-10 11:00:36 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:00:36 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:00:36 --> Utf8 Class Initialized
INFO - 2016-06-10 11:00:36 --> URI Class Initialized
INFO - 2016-06-10 11:00:36 --> Router Class Initialized
INFO - 2016-06-10 11:00:36 --> Output Class Initialized
INFO - 2016-06-10 11:00:36 --> Security Class Initialized
DEBUG - 2016-06-10 11:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:00:36 --> Input Class Initialized
INFO - 2016-06-10 11:00:36 --> Language Class Initialized
INFO - 2016-06-10 11:00:36 --> Loader Class Initialized
INFO - 2016-06-10 11:00:36 --> Helper loaded: form_helper
INFO - 2016-06-10 11:00:36 --> Database Driver Class Initialized
INFO - 2016-06-10 11:00:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:00:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:00:36 --> Email Class Initialized
INFO - 2016-06-10 11:00:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:00:36 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:00:36 --> Helper loaded: language_helper
INFO - 2016-06-10 11:00:36 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:00:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:00:36 --> Model Class Initialized
INFO - 2016-06-10 11:00:36 --> Helper loaded: date_helper
INFO - 2016-06-10 11:00:36 --> Controller Class Initialized
INFO - 2016-06-10 11:00:36 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:00:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:00:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:00:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:00:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:00:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:00:36 --> Model Class Initialized
INFO - 2016-06-10 11:00:36 --> Form Validation Class Initialized
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:00:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:00:36 --> Final output sent to browser
DEBUG - 2016-06-10 11:00:36 --> Total execution time: 0.1415
INFO - 2016-06-10 11:00:43 --> Config Class Initialized
INFO - 2016-06-10 11:00:43 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:00:43 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:00:43 --> Utf8 Class Initialized
INFO - 2016-06-10 11:00:43 --> URI Class Initialized
INFO - 2016-06-10 11:00:43 --> Router Class Initialized
INFO - 2016-06-10 11:00:43 --> Output Class Initialized
INFO - 2016-06-10 11:00:43 --> Security Class Initialized
DEBUG - 2016-06-10 11:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:00:43 --> Input Class Initialized
INFO - 2016-06-10 11:00:43 --> Language Class Initialized
INFO - 2016-06-10 11:00:43 --> Loader Class Initialized
INFO - 2016-06-10 11:00:43 --> Helper loaded: form_helper
INFO - 2016-06-10 11:00:43 --> Database Driver Class Initialized
INFO - 2016-06-10 11:00:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:00:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:00:43 --> Email Class Initialized
INFO - 2016-06-10 11:00:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:00:43 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:00:43 --> Helper loaded: language_helper
INFO - 2016-06-10 11:00:43 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:00:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:00:43 --> Model Class Initialized
INFO - 2016-06-10 11:00:43 --> Helper loaded: date_helper
INFO - 2016-06-10 11:00:43 --> Controller Class Initialized
INFO - 2016-06-10 11:00:43 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:00:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:00:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:00:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:00:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:00:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:00:43 --> Model Class Initialized
INFO - 2016-06-10 11:00:43 --> Form Validation Class Initialized
INFO - 2016-06-10 11:03:51 --> Config Class Initialized
INFO - 2016-06-10 11:03:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:03:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:03:51 --> Utf8 Class Initialized
INFO - 2016-06-10 11:03:51 --> URI Class Initialized
INFO - 2016-06-10 11:03:51 --> Router Class Initialized
INFO - 2016-06-10 11:03:51 --> Output Class Initialized
INFO - 2016-06-10 11:03:51 --> Security Class Initialized
DEBUG - 2016-06-10 11:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:03:51 --> Input Class Initialized
INFO - 2016-06-10 11:03:51 --> Language Class Initialized
ERROR - 2016-06-10 11:03:51 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /home/demis/www/platformadiabet/application/controllers/Diabet.php 404
INFO - 2016-06-10 11:04:02 --> Config Class Initialized
INFO - 2016-06-10 11:04:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:04:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:04:02 --> Utf8 Class Initialized
INFO - 2016-06-10 11:04:02 --> URI Class Initialized
INFO - 2016-06-10 11:04:02 --> Router Class Initialized
INFO - 2016-06-10 11:04:02 --> Output Class Initialized
INFO - 2016-06-10 11:04:02 --> Security Class Initialized
DEBUG - 2016-06-10 11:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:04:02 --> Input Class Initialized
INFO - 2016-06-10 11:04:02 --> Language Class Initialized
INFO - 2016-06-10 11:04:02 --> Loader Class Initialized
INFO - 2016-06-10 11:04:02 --> Helper loaded: form_helper
INFO - 2016-06-10 11:04:02 --> Database Driver Class Initialized
INFO - 2016-06-10 11:04:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:04:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:04:02 --> Email Class Initialized
INFO - 2016-06-10 11:04:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:04:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:04:02 --> Helper loaded: language_helper
INFO - 2016-06-10 11:04:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:04:02 --> Model Class Initialized
INFO - 2016-06-10 11:04:02 --> Helper loaded: date_helper
INFO - 2016-06-10 11:04:02 --> Controller Class Initialized
INFO - 2016-06-10 11:04:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:04:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:04:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:04:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:04:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:04:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:04:02 --> Model Class Initialized
INFO - 2016-06-10 11:04:02 --> Form Validation Class Initialized
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:04:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:04:02 --> Final output sent to browser
DEBUG - 2016-06-10 11:04:02 --> Total execution time: 0.1126
INFO - 2016-06-10 11:04:09 --> Config Class Initialized
INFO - 2016-06-10 11:04:09 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:04:09 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:04:09 --> Utf8 Class Initialized
INFO - 2016-06-10 11:04:09 --> URI Class Initialized
INFO - 2016-06-10 11:04:09 --> Router Class Initialized
INFO - 2016-06-10 11:04:09 --> Output Class Initialized
INFO - 2016-06-10 11:04:09 --> Security Class Initialized
DEBUG - 2016-06-10 11:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:04:09 --> Input Class Initialized
INFO - 2016-06-10 11:04:09 --> Language Class Initialized
INFO - 2016-06-10 11:04:09 --> Loader Class Initialized
INFO - 2016-06-10 11:04:09 --> Helper loaded: form_helper
INFO - 2016-06-10 11:04:09 --> Database Driver Class Initialized
INFO - 2016-06-10 11:04:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:04:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:04:09 --> Email Class Initialized
INFO - 2016-06-10 11:04:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:04:09 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:04:09 --> Helper loaded: language_helper
INFO - 2016-06-10 11:04:09 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:04:09 --> Model Class Initialized
INFO - 2016-06-10 11:04:09 --> Helper loaded: date_helper
INFO - 2016-06-10 11:04:09 --> Controller Class Initialized
INFO - 2016-06-10 11:04:09 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:04:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:04:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:04:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:04:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:04:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:04:09 --> Model Class Initialized
INFO - 2016-06-10 11:04:09 --> Form Validation Class Initialized
INFO - 2016-06-10 11:04:09 --> Final output sent to browser
DEBUG - 2016-06-10 11:04:09 --> Total execution time: 0.1273
INFO - 2016-06-10 11:07:24 --> Config Class Initialized
INFO - 2016-06-10 11:07:24 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:07:24 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:07:24 --> Utf8 Class Initialized
INFO - 2016-06-10 11:07:24 --> URI Class Initialized
INFO - 2016-06-10 11:07:24 --> Router Class Initialized
INFO - 2016-06-10 11:07:24 --> Output Class Initialized
INFO - 2016-06-10 11:07:24 --> Security Class Initialized
DEBUG - 2016-06-10 11:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:07:24 --> Input Class Initialized
INFO - 2016-06-10 11:07:24 --> Language Class Initialized
ERROR - 2016-06-10 11:07:24 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) /home/demis/www/platformadiabet/application/controllers/Diabet.php 397
INFO - 2016-06-10 11:07:43 --> Config Class Initialized
INFO - 2016-06-10 11:07:43 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:07:43 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:07:43 --> Utf8 Class Initialized
INFO - 2016-06-10 11:07:43 --> URI Class Initialized
INFO - 2016-06-10 11:07:43 --> Router Class Initialized
INFO - 2016-06-10 11:07:43 --> Output Class Initialized
INFO - 2016-06-10 11:07:43 --> Security Class Initialized
DEBUG - 2016-06-10 11:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:07:43 --> Input Class Initialized
INFO - 2016-06-10 11:07:43 --> Language Class Initialized
INFO - 2016-06-10 11:07:43 --> Loader Class Initialized
INFO - 2016-06-10 11:07:43 --> Helper loaded: form_helper
INFO - 2016-06-10 11:07:43 --> Database Driver Class Initialized
INFO - 2016-06-10 11:07:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:07:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:07:43 --> Email Class Initialized
INFO - 2016-06-10 11:07:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:07:43 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:07:43 --> Helper loaded: language_helper
INFO - 2016-06-10 11:07:43 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:07:43 --> Model Class Initialized
INFO - 2016-06-10 11:07:43 --> Helper loaded: date_helper
INFO - 2016-06-10 11:07:43 --> Controller Class Initialized
INFO - 2016-06-10 11:07:43 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:07:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:07:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:07:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:07:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:07:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:07:43 --> Model Class Initialized
INFO - 2016-06-10 11:07:43 --> Form Validation Class Initialized
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:07:43 --> Final output sent to browser
DEBUG - 2016-06-10 11:07:43 --> Total execution time: 0.0610
INFO - 2016-06-10 11:07:50 --> Config Class Initialized
INFO - 2016-06-10 11:07:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:07:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:07:50 --> Utf8 Class Initialized
INFO - 2016-06-10 11:07:50 --> URI Class Initialized
INFO - 2016-06-10 11:07:50 --> Router Class Initialized
INFO - 2016-06-10 11:07:50 --> Output Class Initialized
INFO - 2016-06-10 11:07:50 --> Security Class Initialized
DEBUG - 2016-06-10 11:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:07:50 --> Input Class Initialized
INFO - 2016-06-10 11:07:50 --> Language Class Initialized
INFO - 2016-06-10 11:07:50 --> Loader Class Initialized
INFO - 2016-06-10 11:07:50 --> Helper loaded: form_helper
INFO - 2016-06-10 11:07:50 --> Database Driver Class Initialized
INFO - 2016-06-10 11:07:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:07:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:07:50 --> Email Class Initialized
INFO - 2016-06-10 11:07:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:07:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:07:50 --> Helper loaded: language_helper
INFO - 2016-06-10 11:07:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:07:50 --> Model Class Initialized
INFO - 2016-06-10 11:07:50 --> Helper loaded: date_helper
INFO - 2016-06-10 11:07:50 --> Controller Class Initialized
INFO - 2016-06-10 11:07:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:07:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:07:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:07:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:07:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:07:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:07:50 --> Model Class Initialized
INFO - 2016-06-10 11:07:50 --> Form Validation Class Initialized
INFO - 2016-06-10 11:08:44 --> Config Class Initialized
INFO - 2016-06-10 11:08:44 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:08:44 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:08:44 --> Utf8 Class Initialized
INFO - 2016-06-10 11:08:44 --> URI Class Initialized
INFO - 2016-06-10 11:08:44 --> Router Class Initialized
INFO - 2016-06-10 11:08:44 --> Output Class Initialized
INFO - 2016-06-10 11:08:44 --> Security Class Initialized
DEBUG - 2016-06-10 11:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:08:44 --> Input Class Initialized
INFO - 2016-06-10 11:08:44 --> Language Class Initialized
INFO - 2016-06-10 11:08:44 --> Loader Class Initialized
INFO - 2016-06-10 11:08:44 --> Helper loaded: form_helper
INFO - 2016-06-10 11:08:44 --> Database Driver Class Initialized
INFO - 2016-06-10 11:08:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:08:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:08:44 --> Email Class Initialized
INFO - 2016-06-10 11:08:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:08:44 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:08:44 --> Helper loaded: language_helper
INFO - 2016-06-10 11:08:44 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:08:44 --> Model Class Initialized
INFO - 2016-06-10 11:08:44 --> Helper loaded: date_helper
INFO - 2016-06-10 11:08:44 --> Controller Class Initialized
INFO - 2016-06-10 11:08:44 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:08:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:08:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:08:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:08:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:08:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:08:44 --> Model Class Initialized
INFO - 2016-06-10 11:08:44 --> Form Validation Class Initialized
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:08:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:08:44 --> Final output sent to browser
DEBUG - 2016-06-10 11:08:44 --> Total execution time: 0.1510
INFO - 2016-06-10 11:08:49 --> Config Class Initialized
INFO - 2016-06-10 11:08:49 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:08:49 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:08:49 --> Utf8 Class Initialized
INFO - 2016-06-10 11:08:49 --> URI Class Initialized
INFO - 2016-06-10 11:08:49 --> Router Class Initialized
INFO - 2016-06-10 11:08:49 --> Output Class Initialized
INFO - 2016-06-10 11:08:49 --> Security Class Initialized
DEBUG - 2016-06-10 11:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:08:49 --> Input Class Initialized
INFO - 2016-06-10 11:08:49 --> Language Class Initialized
INFO - 2016-06-10 11:08:49 --> Loader Class Initialized
INFO - 2016-06-10 11:08:49 --> Helper loaded: form_helper
INFO - 2016-06-10 11:08:49 --> Database Driver Class Initialized
INFO - 2016-06-10 11:08:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:08:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:08:49 --> Email Class Initialized
INFO - 2016-06-10 11:08:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:08:49 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:08:49 --> Helper loaded: language_helper
INFO - 2016-06-10 11:08:49 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:08:49 --> Model Class Initialized
INFO - 2016-06-10 11:08:49 --> Helper loaded: date_helper
INFO - 2016-06-10 11:08:49 --> Controller Class Initialized
INFO - 2016-06-10 11:08:49 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:08:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:08:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:08:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:08:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:08:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:08:49 --> Model Class Initialized
INFO - 2016-06-10 11:08:49 --> Form Validation Class Initialized
INFO - 2016-06-10 11:09:06 --> Config Class Initialized
INFO - 2016-06-10 11:09:06 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:09:06 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:09:06 --> Utf8 Class Initialized
INFO - 2016-06-10 11:09:06 --> URI Class Initialized
INFO - 2016-06-10 11:09:06 --> Router Class Initialized
INFO - 2016-06-10 11:09:06 --> Output Class Initialized
INFO - 2016-06-10 11:09:06 --> Security Class Initialized
DEBUG - 2016-06-10 11:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:09:06 --> Input Class Initialized
INFO - 2016-06-10 11:09:06 --> Language Class Initialized
INFO - 2016-06-10 11:09:06 --> Loader Class Initialized
INFO - 2016-06-10 11:09:06 --> Helper loaded: form_helper
INFO - 2016-06-10 11:09:06 --> Database Driver Class Initialized
INFO - 2016-06-10 11:09:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:09:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:09:06 --> Email Class Initialized
INFO - 2016-06-10 11:09:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:09:06 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:09:06 --> Helper loaded: language_helper
INFO - 2016-06-10 11:09:06 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:09:06 --> Model Class Initialized
INFO - 2016-06-10 11:09:06 --> Helper loaded: date_helper
INFO - 2016-06-10 11:09:06 --> Controller Class Initialized
INFO - 2016-06-10 11:09:06 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:09:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:09:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:09:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:09:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:09:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:09:06 --> Model Class Initialized
INFO - 2016-06-10 11:09:06 --> Form Validation Class Initialized
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:09:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:09:06 --> Final output sent to browser
DEBUG - 2016-06-10 11:09:06 --> Total execution time: 0.1776
INFO - 2016-06-10 11:09:12 --> Config Class Initialized
INFO - 2016-06-10 11:09:12 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:09:12 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:09:12 --> Utf8 Class Initialized
INFO - 2016-06-10 11:09:12 --> URI Class Initialized
INFO - 2016-06-10 11:09:12 --> Router Class Initialized
INFO - 2016-06-10 11:09:12 --> Output Class Initialized
INFO - 2016-06-10 11:09:12 --> Security Class Initialized
DEBUG - 2016-06-10 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:09:12 --> Input Class Initialized
INFO - 2016-06-10 11:09:12 --> Language Class Initialized
INFO - 2016-06-10 11:09:12 --> Loader Class Initialized
INFO - 2016-06-10 11:09:12 --> Helper loaded: form_helper
INFO - 2016-06-10 11:09:12 --> Database Driver Class Initialized
INFO - 2016-06-10 11:09:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:09:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:09:12 --> Email Class Initialized
INFO - 2016-06-10 11:09:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:09:12 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:09:12 --> Helper loaded: language_helper
INFO - 2016-06-10 11:09:12 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:09:12 --> Model Class Initialized
INFO - 2016-06-10 11:09:12 --> Helper loaded: date_helper
INFO - 2016-06-10 11:09:12 --> Controller Class Initialized
INFO - 2016-06-10 11:09:12 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:09:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:09:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:09:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:09:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:09:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:09:12 --> Model Class Initialized
INFO - 2016-06-10 11:09:12 --> Form Validation Class Initialized
INFO - 2016-06-10 11:09:12 --> Final output sent to browser
DEBUG - 2016-06-10 11:09:12 --> Total execution time: 0.0529
INFO - 2016-06-10 11:12:35 --> Config Class Initialized
INFO - 2016-06-10 11:12:35 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:12:35 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:12:35 --> Utf8 Class Initialized
INFO - 2016-06-10 11:12:35 --> URI Class Initialized
INFO - 2016-06-10 11:12:35 --> Router Class Initialized
INFO - 2016-06-10 11:12:35 --> Output Class Initialized
INFO - 2016-06-10 11:12:35 --> Security Class Initialized
DEBUG - 2016-06-10 11:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:12:35 --> Input Class Initialized
INFO - 2016-06-10 11:12:35 --> Language Class Initialized
INFO - 2016-06-10 11:12:35 --> Loader Class Initialized
INFO - 2016-06-10 11:12:35 --> Helper loaded: form_helper
INFO - 2016-06-10 11:12:35 --> Database Driver Class Initialized
INFO - 2016-06-10 11:12:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:12:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:12:35 --> Email Class Initialized
INFO - 2016-06-10 11:12:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:12:35 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:12:35 --> Helper loaded: language_helper
INFO - 2016-06-10 11:12:35 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:12:35 --> Model Class Initialized
INFO - 2016-06-10 11:12:35 --> Helper loaded: date_helper
INFO - 2016-06-10 11:12:35 --> Controller Class Initialized
INFO - 2016-06-10 11:12:35 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:12:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:12:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:12:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:12:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:12:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:12:35 --> Model Class Initialized
INFO - 2016-06-10 11:12:35 --> Form Validation Class Initialized
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:12:35 --> Final output sent to browser
DEBUG - 2016-06-10 11:12:35 --> Total execution time: 0.1509
INFO - 2016-06-10 11:12:40 --> Config Class Initialized
INFO - 2016-06-10 11:12:40 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:12:40 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:12:40 --> Utf8 Class Initialized
INFO - 2016-06-10 11:12:40 --> URI Class Initialized
INFO - 2016-06-10 11:12:40 --> Router Class Initialized
INFO - 2016-06-10 11:12:40 --> Output Class Initialized
INFO - 2016-06-10 11:12:40 --> Security Class Initialized
DEBUG - 2016-06-10 11:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:12:40 --> Input Class Initialized
INFO - 2016-06-10 11:12:40 --> Language Class Initialized
INFO - 2016-06-10 11:12:40 --> Loader Class Initialized
INFO - 2016-06-10 11:12:40 --> Helper loaded: form_helper
INFO - 2016-06-10 11:12:40 --> Database Driver Class Initialized
INFO - 2016-06-10 11:12:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:12:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:12:40 --> Email Class Initialized
INFO - 2016-06-10 11:12:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:12:40 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:12:40 --> Helper loaded: language_helper
INFO - 2016-06-10 11:12:40 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:12:40 --> Model Class Initialized
INFO - 2016-06-10 11:12:40 --> Helper loaded: date_helper
INFO - 2016-06-10 11:12:40 --> Controller Class Initialized
INFO - 2016-06-10 11:12:40 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:12:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:12:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:12:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:12:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:12:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:12:40 --> Model Class Initialized
INFO - 2016-06-10 11:12:40 --> Form Validation Class Initialized
INFO - 2016-06-10 11:12:40 --> Final output sent to browser
DEBUG - 2016-06-10 11:12:40 --> Total execution time: 0.0723
INFO - 2016-06-10 11:13:50 --> Config Class Initialized
INFO - 2016-06-10 11:13:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:13:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:13:50 --> Utf8 Class Initialized
INFO - 2016-06-10 11:13:50 --> URI Class Initialized
INFO - 2016-06-10 11:13:50 --> Router Class Initialized
INFO - 2016-06-10 11:13:50 --> Output Class Initialized
INFO - 2016-06-10 11:13:50 --> Security Class Initialized
DEBUG - 2016-06-10 11:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:13:50 --> Input Class Initialized
INFO - 2016-06-10 11:13:50 --> Language Class Initialized
INFO - 2016-06-10 11:13:50 --> Loader Class Initialized
INFO - 2016-06-10 11:13:50 --> Helper loaded: form_helper
INFO - 2016-06-10 11:13:50 --> Database Driver Class Initialized
INFO - 2016-06-10 11:13:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:13:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:13:50 --> Email Class Initialized
INFO - 2016-06-10 11:13:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:13:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:13:50 --> Helper loaded: language_helper
INFO - 2016-06-10 11:13:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:13:51 --> Model Class Initialized
INFO - 2016-06-10 11:13:51 --> Helper loaded: date_helper
INFO - 2016-06-10 11:13:51 --> Controller Class Initialized
INFO - 2016-06-10 11:13:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:13:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:13:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:13:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:13:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:13:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:13:51 --> Model Class Initialized
INFO - 2016-06-10 11:13:51 --> Form Validation Class Initialized
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:13:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:13:51 --> Final output sent to browser
DEBUG - 2016-06-10 11:13:51 --> Total execution time: 0.2705
INFO - 2016-06-10 11:13:56 --> Config Class Initialized
INFO - 2016-06-10 11:13:56 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:13:56 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:13:56 --> Utf8 Class Initialized
INFO - 2016-06-10 11:13:56 --> URI Class Initialized
INFO - 2016-06-10 11:13:56 --> Router Class Initialized
INFO - 2016-06-10 11:13:56 --> Output Class Initialized
INFO - 2016-06-10 11:13:56 --> Security Class Initialized
DEBUG - 2016-06-10 11:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:13:56 --> Input Class Initialized
INFO - 2016-06-10 11:13:56 --> Language Class Initialized
INFO - 2016-06-10 11:13:56 --> Loader Class Initialized
INFO - 2016-06-10 11:13:56 --> Helper loaded: form_helper
INFO - 2016-06-10 11:13:56 --> Database Driver Class Initialized
INFO - 2016-06-10 11:13:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:13:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:13:56 --> Email Class Initialized
INFO - 2016-06-10 11:13:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:13:56 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:13:56 --> Helper loaded: language_helper
INFO - 2016-06-10 11:13:56 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:13:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:13:56 --> Model Class Initialized
INFO - 2016-06-10 11:13:56 --> Helper loaded: date_helper
INFO - 2016-06-10 11:13:56 --> Controller Class Initialized
INFO - 2016-06-10 11:13:56 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:13:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:13:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:13:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:13:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:13:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:13:56 --> Model Class Initialized
INFO - 2016-06-10 11:13:56 --> Form Validation Class Initialized
INFO - 2016-06-10 11:13:56 --> Final output sent to browser
DEBUG - 2016-06-10 11:13:56 --> Total execution time: 0.0956
INFO - 2016-06-10 11:17:08 --> Config Class Initialized
INFO - 2016-06-10 11:17:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:17:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:17:08 --> Utf8 Class Initialized
INFO - 2016-06-10 11:17:08 --> URI Class Initialized
INFO - 2016-06-10 11:17:08 --> Router Class Initialized
INFO - 2016-06-10 11:17:08 --> Output Class Initialized
INFO - 2016-06-10 11:17:08 --> Security Class Initialized
DEBUG - 2016-06-10 11:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:17:08 --> Input Class Initialized
INFO - 2016-06-10 11:17:08 --> Language Class Initialized
INFO - 2016-06-10 11:17:08 --> Loader Class Initialized
INFO - 2016-06-10 11:17:08 --> Helper loaded: form_helper
INFO - 2016-06-10 11:17:08 --> Database Driver Class Initialized
INFO - 2016-06-10 11:17:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:17:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:17:08 --> Email Class Initialized
INFO - 2016-06-10 11:17:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:17:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:17:08 --> Helper loaded: language_helper
INFO - 2016-06-10 11:17:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:17:08 --> Model Class Initialized
INFO - 2016-06-10 11:17:08 --> Helper loaded: date_helper
INFO - 2016-06-10 11:17:08 --> Controller Class Initialized
INFO - 2016-06-10 11:17:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:17:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:17:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:17:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:17:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:17:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:17:08 --> Model Class Initialized
INFO - 2016-06-10 11:17:08 --> Form Validation Class Initialized
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:17:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:17:08 --> Final output sent to browser
DEBUG - 2016-06-10 11:17:08 --> Total execution time: 0.0481
INFO - 2016-06-10 11:17:15 --> Config Class Initialized
INFO - 2016-06-10 11:17:15 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:17:15 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:17:15 --> Utf8 Class Initialized
INFO - 2016-06-10 11:17:15 --> URI Class Initialized
INFO - 2016-06-10 11:17:15 --> Router Class Initialized
INFO - 2016-06-10 11:17:15 --> Output Class Initialized
INFO - 2016-06-10 11:17:15 --> Security Class Initialized
DEBUG - 2016-06-10 11:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:17:15 --> Input Class Initialized
INFO - 2016-06-10 11:17:15 --> Language Class Initialized
INFO - 2016-06-10 11:17:15 --> Loader Class Initialized
INFO - 2016-06-10 11:17:15 --> Helper loaded: form_helper
INFO - 2016-06-10 11:17:15 --> Database Driver Class Initialized
INFO - 2016-06-10 11:17:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:17:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:17:15 --> Email Class Initialized
INFO - 2016-06-10 11:17:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:17:15 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:17:15 --> Helper loaded: language_helper
INFO - 2016-06-10 11:17:15 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:17:15 --> Model Class Initialized
INFO - 2016-06-10 11:17:15 --> Helper loaded: date_helper
INFO - 2016-06-10 11:17:15 --> Controller Class Initialized
INFO - 2016-06-10 11:17:15 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:17:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:17:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:17:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:17:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:17:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:17:15 --> Model Class Initialized
INFO - 2016-06-10 11:17:15 --> Form Validation Class Initialized
INFO - 2016-06-10 11:17:15 --> Final output sent to browser
DEBUG - 2016-06-10 11:17:15 --> Total execution time: 0.0921
INFO - 2016-06-10 11:17:22 --> Config Class Initialized
INFO - 2016-06-10 11:17:22 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:17:22 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:17:22 --> Utf8 Class Initialized
INFO - 2016-06-10 11:17:22 --> URI Class Initialized
INFO - 2016-06-10 11:17:22 --> Router Class Initialized
INFO - 2016-06-10 11:17:22 --> Output Class Initialized
INFO - 2016-06-10 11:17:22 --> Security Class Initialized
DEBUG - 2016-06-10 11:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:17:22 --> Input Class Initialized
INFO - 2016-06-10 11:17:22 --> Language Class Initialized
INFO - 2016-06-10 11:17:22 --> Loader Class Initialized
INFO - 2016-06-10 11:17:22 --> Helper loaded: form_helper
INFO - 2016-06-10 11:17:22 --> Database Driver Class Initialized
INFO - 2016-06-10 11:17:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:17:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:17:22 --> Email Class Initialized
INFO - 2016-06-10 11:17:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:17:22 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:17:22 --> Helper loaded: language_helper
INFO - 2016-06-10 11:17:22 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:17:22 --> Model Class Initialized
INFO - 2016-06-10 11:17:22 --> Helper loaded: date_helper
INFO - 2016-06-10 11:17:22 --> Controller Class Initialized
INFO - 2016-06-10 11:17:22 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:17:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:17:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:17:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:17:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:17:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:17:22 --> Model Class Initialized
INFO - 2016-06-10 11:17:22 --> Form Validation Class Initialized
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:17:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:17:22 --> Final output sent to browser
DEBUG - 2016-06-10 11:17:22 --> Total execution time: 0.0761
INFO - 2016-06-10 11:17:29 --> Config Class Initialized
INFO - 2016-06-10 11:17:29 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:17:29 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:17:29 --> Utf8 Class Initialized
INFO - 2016-06-10 11:17:29 --> URI Class Initialized
INFO - 2016-06-10 11:17:29 --> Router Class Initialized
INFO - 2016-06-10 11:17:29 --> Output Class Initialized
INFO - 2016-06-10 11:17:29 --> Security Class Initialized
DEBUG - 2016-06-10 11:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:17:29 --> Input Class Initialized
INFO - 2016-06-10 11:17:29 --> Language Class Initialized
INFO - 2016-06-10 11:17:29 --> Loader Class Initialized
INFO - 2016-06-10 11:17:29 --> Helper loaded: form_helper
INFO - 2016-06-10 11:17:29 --> Database Driver Class Initialized
INFO - 2016-06-10 11:17:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:17:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:17:29 --> Email Class Initialized
INFO - 2016-06-10 11:17:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:17:29 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:17:29 --> Helper loaded: language_helper
INFO - 2016-06-10 11:17:29 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:17:29 --> Model Class Initialized
INFO - 2016-06-10 11:17:29 --> Helper loaded: date_helper
INFO - 2016-06-10 11:17:29 --> Controller Class Initialized
INFO - 2016-06-10 11:17:29 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:17:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:17:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:17:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:17:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:17:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:17:29 --> Model Class Initialized
INFO - 2016-06-10 11:17:29 --> Form Validation Class Initialized
INFO - 2016-06-10 11:17:29 --> Final output sent to browser
DEBUG - 2016-06-10 11:17:29 --> Total execution time: 0.0785
INFO - 2016-06-10 11:24:50 --> Config Class Initialized
INFO - 2016-06-10 11:24:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:24:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:24:50 --> Utf8 Class Initialized
INFO - 2016-06-10 11:24:50 --> URI Class Initialized
INFO - 2016-06-10 11:24:50 --> Router Class Initialized
INFO - 2016-06-10 11:24:50 --> Output Class Initialized
INFO - 2016-06-10 11:24:50 --> Security Class Initialized
DEBUG - 2016-06-10 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:24:50 --> Input Class Initialized
INFO - 2016-06-10 11:24:50 --> Language Class Initialized
INFO - 2016-06-10 11:24:50 --> Loader Class Initialized
INFO - 2016-06-10 11:24:50 --> Helper loaded: form_helper
INFO - 2016-06-10 11:24:50 --> Database Driver Class Initialized
INFO - 2016-06-10 11:24:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:24:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:24:50 --> Email Class Initialized
INFO - 2016-06-10 11:24:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:24:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:24:50 --> Helper loaded: language_helper
INFO - 2016-06-10 11:24:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:24:50 --> Model Class Initialized
INFO - 2016-06-10 11:24:50 --> Helper loaded: date_helper
INFO - 2016-06-10 11:24:50 --> Controller Class Initialized
INFO - 2016-06-10 11:24:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:24:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:24:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:24:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:24:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:24:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:24:50 --> Model Class Initialized
INFO - 2016-06-10 11:24:50 --> Form Validation Class Initialized
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:24:50 --> Final output sent to browser
DEBUG - 2016-06-10 11:24:50 --> Total execution time: 0.0862
INFO - 2016-06-10 11:25:00 --> Config Class Initialized
INFO - 2016-06-10 11:25:00 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:25:00 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:25:00 --> Utf8 Class Initialized
INFO - 2016-06-10 11:25:00 --> URI Class Initialized
INFO - 2016-06-10 11:25:00 --> Router Class Initialized
INFO - 2016-06-10 11:25:00 --> Output Class Initialized
INFO - 2016-06-10 11:25:00 --> Security Class Initialized
DEBUG - 2016-06-10 11:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:25:00 --> Input Class Initialized
INFO - 2016-06-10 11:25:00 --> Language Class Initialized
INFO - 2016-06-10 11:25:00 --> Loader Class Initialized
INFO - 2016-06-10 11:25:00 --> Helper loaded: form_helper
INFO - 2016-06-10 11:25:00 --> Database Driver Class Initialized
INFO - 2016-06-10 11:25:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:25:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:25:00 --> Email Class Initialized
INFO - 2016-06-10 11:25:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:25:00 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:25:00 --> Helper loaded: language_helper
INFO - 2016-06-10 11:25:00 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:25:00 --> Model Class Initialized
INFO - 2016-06-10 11:25:00 --> Helper loaded: date_helper
INFO - 2016-06-10 11:25:00 --> Controller Class Initialized
INFO - 2016-06-10 11:25:00 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:25:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:25:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:25:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:25:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:25:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:25:00 --> Model Class Initialized
INFO - 2016-06-10 11:25:00 --> Form Validation Class Initialized
INFO - 2016-06-10 11:25:00 --> Final output sent to browser
DEBUG - 2016-06-10 11:25:00 --> Total execution time: 0.0793
INFO - 2016-06-10 11:25:58 --> Config Class Initialized
INFO - 2016-06-10 11:25:58 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:25:58 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:25:58 --> Utf8 Class Initialized
INFO - 2016-06-10 11:25:58 --> URI Class Initialized
INFO - 2016-06-10 11:25:58 --> Router Class Initialized
INFO - 2016-06-10 11:25:58 --> Output Class Initialized
INFO - 2016-06-10 11:25:58 --> Security Class Initialized
DEBUG - 2016-06-10 11:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:25:58 --> Input Class Initialized
INFO - 2016-06-10 11:25:58 --> Language Class Initialized
INFO - 2016-06-10 11:25:58 --> Loader Class Initialized
INFO - 2016-06-10 11:25:58 --> Helper loaded: form_helper
INFO - 2016-06-10 11:25:58 --> Database Driver Class Initialized
INFO - 2016-06-10 11:25:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:25:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:25:58 --> Email Class Initialized
INFO - 2016-06-10 11:25:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:25:58 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:25:58 --> Helper loaded: language_helper
INFO - 2016-06-10 11:25:58 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:25:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:25:58 --> Model Class Initialized
INFO - 2016-06-10 11:25:58 --> Helper loaded: date_helper
INFO - 2016-06-10 11:25:58 --> Controller Class Initialized
INFO - 2016-06-10 11:25:58 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:25:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:25:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:25:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:25:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:25:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:25:58 --> Model Class Initialized
INFO - 2016-06-10 11:25:58 --> Form Validation Class Initialized
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:25:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:25:58 --> Final output sent to browser
DEBUG - 2016-06-10 11:25:58 --> Total execution time: 0.1376
INFO - 2016-06-10 11:26:04 --> Config Class Initialized
INFO - 2016-06-10 11:26:04 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:26:04 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:26:04 --> Utf8 Class Initialized
INFO - 2016-06-10 11:26:04 --> URI Class Initialized
INFO - 2016-06-10 11:26:04 --> Router Class Initialized
INFO - 2016-06-10 11:26:04 --> Output Class Initialized
INFO - 2016-06-10 11:26:04 --> Security Class Initialized
DEBUG - 2016-06-10 11:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:26:04 --> Input Class Initialized
INFO - 2016-06-10 11:26:04 --> Language Class Initialized
INFO - 2016-06-10 11:26:04 --> Loader Class Initialized
INFO - 2016-06-10 11:26:04 --> Helper loaded: form_helper
INFO - 2016-06-10 11:26:04 --> Database Driver Class Initialized
INFO - 2016-06-10 11:26:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:26:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:26:04 --> Email Class Initialized
INFO - 2016-06-10 11:26:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:26:04 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:26:04 --> Helper loaded: language_helper
INFO - 2016-06-10 11:26:04 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:26:04 --> Model Class Initialized
INFO - 2016-06-10 11:26:04 --> Helper loaded: date_helper
INFO - 2016-06-10 11:26:04 --> Controller Class Initialized
INFO - 2016-06-10 11:26:04 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:26:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:26:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:26:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:26:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:26:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:26:04 --> Model Class Initialized
INFO - 2016-06-10 11:26:04 --> Form Validation Class Initialized
INFO - 2016-06-10 11:26:40 --> Config Class Initialized
INFO - 2016-06-10 11:26:40 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:26:40 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:26:40 --> Utf8 Class Initialized
INFO - 2016-06-10 11:26:40 --> URI Class Initialized
INFO - 2016-06-10 11:26:40 --> Router Class Initialized
INFO - 2016-06-10 11:26:40 --> Output Class Initialized
INFO - 2016-06-10 11:26:40 --> Security Class Initialized
DEBUG - 2016-06-10 11:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:26:40 --> Input Class Initialized
INFO - 2016-06-10 11:26:40 --> Language Class Initialized
INFO - 2016-06-10 11:26:40 --> Loader Class Initialized
INFO - 2016-06-10 11:26:40 --> Helper loaded: form_helper
INFO - 2016-06-10 11:26:40 --> Database Driver Class Initialized
INFO - 2016-06-10 11:26:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:26:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:26:40 --> Email Class Initialized
INFO - 2016-06-10 11:26:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:26:40 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:26:40 --> Helper loaded: language_helper
INFO - 2016-06-10 11:26:40 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:26:40 --> Model Class Initialized
INFO - 2016-06-10 11:26:40 --> Helper loaded: date_helper
INFO - 2016-06-10 11:26:40 --> Controller Class Initialized
INFO - 2016-06-10 11:26:40 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:26:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:26:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:26:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:26:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:26:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:26:40 --> Model Class Initialized
INFO - 2016-06-10 11:26:40 --> Form Validation Class Initialized
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:26:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:26:40 --> Final output sent to browser
DEBUG - 2016-06-10 11:26:40 --> Total execution time: 0.0547
INFO - 2016-06-10 11:26:46 --> Config Class Initialized
INFO - 2016-06-10 11:26:46 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:26:46 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:26:46 --> Utf8 Class Initialized
INFO - 2016-06-10 11:26:46 --> URI Class Initialized
INFO - 2016-06-10 11:26:46 --> Router Class Initialized
INFO - 2016-06-10 11:26:46 --> Output Class Initialized
INFO - 2016-06-10 11:26:46 --> Security Class Initialized
DEBUG - 2016-06-10 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:26:46 --> Input Class Initialized
INFO - 2016-06-10 11:26:46 --> Language Class Initialized
INFO - 2016-06-10 11:26:46 --> Loader Class Initialized
INFO - 2016-06-10 11:26:46 --> Helper loaded: form_helper
INFO - 2016-06-10 11:26:46 --> Database Driver Class Initialized
INFO - 2016-06-10 11:26:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:26:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:26:46 --> Email Class Initialized
INFO - 2016-06-10 11:26:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:26:46 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:26:46 --> Helper loaded: language_helper
INFO - 2016-06-10 11:26:46 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:26:46 --> Model Class Initialized
INFO - 2016-06-10 11:26:46 --> Helper loaded: date_helper
INFO - 2016-06-10 11:26:46 --> Controller Class Initialized
INFO - 2016-06-10 11:26:46 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:26:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:26:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:26:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:26:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:26:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:26:46 --> Model Class Initialized
INFO - 2016-06-10 11:26:46 --> Form Validation Class Initialized
INFO - 2016-06-10 11:27:28 --> Config Class Initialized
INFO - 2016-06-10 11:27:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:27:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:27:28 --> Utf8 Class Initialized
INFO - 2016-06-10 11:27:28 --> URI Class Initialized
INFO - 2016-06-10 11:27:28 --> Router Class Initialized
INFO - 2016-06-10 11:27:28 --> Output Class Initialized
INFO - 2016-06-10 11:27:28 --> Security Class Initialized
DEBUG - 2016-06-10 11:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:27:28 --> Input Class Initialized
INFO - 2016-06-10 11:27:28 --> Language Class Initialized
INFO - 2016-06-10 11:27:28 --> Loader Class Initialized
INFO - 2016-06-10 11:27:28 --> Helper loaded: form_helper
INFO - 2016-06-10 11:27:28 --> Database Driver Class Initialized
INFO - 2016-06-10 11:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:27:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:27:28 --> Email Class Initialized
INFO - 2016-06-10 11:27:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:27:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:27:28 --> Helper loaded: language_helper
INFO - 2016-06-10 11:27:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:27:28 --> Model Class Initialized
INFO - 2016-06-10 11:27:28 --> Helper loaded: date_helper
INFO - 2016-06-10 11:27:28 --> Controller Class Initialized
INFO - 2016-06-10 11:27:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:27:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:27:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:27:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:27:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:27:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:27:28 --> Model Class Initialized
INFO - 2016-06-10 11:27:28 --> Form Validation Class Initialized
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:27:28 --> Final output sent to browser
DEBUG - 2016-06-10 11:27:28 --> Total execution time: 0.0660
INFO - 2016-06-10 11:27:33 --> Config Class Initialized
INFO - 2016-06-10 11:27:33 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:27:33 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:27:33 --> Utf8 Class Initialized
INFO - 2016-06-10 11:27:33 --> URI Class Initialized
INFO - 2016-06-10 11:27:33 --> Router Class Initialized
INFO - 2016-06-10 11:27:33 --> Output Class Initialized
INFO - 2016-06-10 11:27:33 --> Security Class Initialized
DEBUG - 2016-06-10 11:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:27:33 --> Input Class Initialized
INFO - 2016-06-10 11:27:33 --> Language Class Initialized
INFO - 2016-06-10 11:27:33 --> Loader Class Initialized
INFO - 2016-06-10 11:27:33 --> Helper loaded: form_helper
INFO - 2016-06-10 11:27:33 --> Database Driver Class Initialized
INFO - 2016-06-10 11:27:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:27:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:27:33 --> Email Class Initialized
INFO - 2016-06-10 11:27:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:27:33 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:27:33 --> Helper loaded: language_helper
INFO - 2016-06-10 11:27:33 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:27:33 --> Model Class Initialized
INFO - 2016-06-10 11:27:33 --> Helper loaded: date_helper
INFO - 2016-06-10 11:27:33 --> Controller Class Initialized
INFO - 2016-06-10 11:27:33 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:27:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:27:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:27:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:27:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:27:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:27:33 --> Model Class Initialized
INFO - 2016-06-10 11:27:33 --> Form Validation Class Initialized
INFO - 2016-06-10 11:27:52 --> Config Class Initialized
INFO - 2016-06-10 11:27:52 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:27:52 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:27:52 --> Utf8 Class Initialized
INFO - 2016-06-10 11:27:52 --> URI Class Initialized
INFO - 2016-06-10 11:27:52 --> Router Class Initialized
INFO - 2016-06-10 11:27:52 --> Output Class Initialized
INFO - 2016-06-10 11:27:52 --> Security Class Initialized
DEBUG - 2016-06-10 11:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:27:52 --> Input Class Initialized
INFO - 2016-06-10 11:27:52 --> Language Class Initialized
INFO - 2016-06-10 11:27:52 --> Loader Class Initialized
INFO - 2016-06-10 11:27:52 --> Helper loaded: form_helper
INFO - 2016-06-10 11:27:52 --> Database Driver Class Initialized
INFO - 2016-06-10 11:27:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:27:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:27:52 --> Email Class Initialized
INFO - 2016-06-10 11:27:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:27:52 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:27:52 --> Helper loaded: language_helper
INFO - 2016-06-10 11:27:52 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:27:52 --> Model Class Initialized
INFO - 2016-06-10 11:27:52 --> Helper loaded: date_helper
INFO - 2016-06-10 11:27:52 --> Controller Class Initialized
INFO - 2016-06-10 11:27:52 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:27:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:27:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:27:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:27:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:27:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:27:52 --> Model Class Initialized
INFO - 2016-06-10 11:27:52 --> Form Validation Class Initialized
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:27:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:27:52 --> Final output sent to browser
DEBUG - 2016-06-10 11:27:52 --> Total execution time: 0.1006
INFO - 2016-06-10 11:27:56 --> Config Class Initialized
INFO - 2016-06-10 11:27:56 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:27:56 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:27:56 --> Utf8 Class Initialized
INFO - 2016-06-10 11:27:57 --> URI Class Initialized
INFO - 2016-06-10 11:27:57 --> Router Class Initialized
INFO - 2016-06-10 11:27:57 --> Output Class Initialized
INFO - 2016-06-10 11:27:57 --> Security Class Initialized
DEBUG - 2016-06-10 11:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:27:57 --> Input Class Initialized
INFO - 2016-06-10 11:27:57 --> Language Class Initialized
INFO - 2016-06-10 11:27:57 --> Loader Class Initialized
INFO - 2016-06-10 11:27:57 --> Helper loaded: form_helper
INFO - 2016-06-10 11:27:57 --> Database Driver Class Initialized
INFO - 2016-06-10 11:27:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:27:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:27:57 --> Email Class Initialized
INFO - 2016-06-10 11:27:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:27:57 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:27:57 --> Helper loaded: language_helper
INFO - 2016-06-10 11:27:57 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:27:57 --> Model Class Initialized
INFO - 2016-06-10 11:27:57 --> Helper loaded: date_helper
INFO - 2016-06-10 11:27:57 --> Controller Class Initialized
INFO - 2016-06-10 11:27:57 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:27:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:27:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:27:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:27:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:27:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:27:57 --> Model Class Initialized
INFO - 2016-06-10 11:27:57 --> Form Validation Class Initialized
INFO - 2016-06-10 11:29:08 --> Config Class Initialized
INFO - 2016-06-10 11:29:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:29:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:29:08 --> Utf8 Class Initialized
INFO - 2016-06-10 11:29:08 --> URI Class Initialized
INFO - 2016-06-10 11:29:08 --> Router Class Initialized
INFO - 2016-06-10 11:29:08 --> Output Class Initialized
INFO - 2016-06-10 11:29:08 --> Security Class Initialized
DEBUG - 2016-06-10 11:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:29:08 --> Input Class Initialized
INFO - 2016-06-10 11:29:08 --> Language Class Initialized
INFO - 2016-06-10 11:29:08 --> Loader Class Initialized
INFO - 2016-06-10 11:29:08 --> Helper loaded: form_helper
INFO - 2016-06-10 11:29:08 --> Database Driver Class Initialized
INFO - 2016-06-10 11:29:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:29:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:29:09 --> Email Class Initialized
INFO - 2016-06-10 11:29:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:29:09 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:29:09 --> Helper loaded: language_helper
INFO - 2016-06-10 11:29:09 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:29:09 --> Model Class Initialized
INFO - 2016-06-10 11:29:09 --> Helper loaded: date_helper
INFO - 2016-06-10 11:29:09 --> Controller Class Initialized
INFO - 2016-06-10 11:29:09 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:29:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:29:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:29:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:29:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:29:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:29:09 --> Model Class Initialized
INFO - 2016-06-10 11:29:09 --> Form Validation Class Initialized
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:29:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:29:09 --> Final output sent to browser
DEBUG - 2016-06-10 11:29:09 --> Total execution time: 0.0905
INFO - 2016-06-10 11:29:13 --> Config Class Initialized
INFO - 2016-06-10 11:29:13 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:29:13 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:29:13 --> Utf8 Class Initialized
INFO - 2016-06-10 11:29:13 --> URI Class Initialized
INFO - 2016-06-10 11:29:13 --> Router Class Initialized
INFO - 2016-06-10 11:29:13 --> Output Class Initialized
INFO - 2016-06-10 11:29:13 --> Security Class Initialized
DEBUG - 2016-06-10 11:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:29:13 --> Input Class Initialized
INFO - 2016-06-10 11:29:13 --> Language Class Initialized
INFO - 2016-06-10 11:29:13 --> Loader Class Initialized
INFO - 2016-06-10 11:29:13 --> Helper loaded: form_helper
INFO - 2016-06-10 11:29:13 --> Database Driver Class Initialized
INFO - 2016-06-10 11:29:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:29:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:29:13 --> Email Class Initialized
INFO - 2016-06-10 11:29:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:29:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:29:13 --> Helper loaded: language_helper
INFO - 2016-06-10 11:29:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:29:13 --> Model Class Initialized
INFO - 2016-06-10 11:29:13 --> Helper loaded: date_helper
INFO - 2016-06-10 11:29:13 --> Controller Class Initialized
INFO - 2016-06-10 11:29:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:29:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:29:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:29:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:29:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:29:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:29:13 --> Model Class Initialized
INFO - 2016-06-10 11:29:13 --> Form Validation Class Initialized
INFO - 2016-06-10 11:31:20 --> Config Class Initialized
INFO - 2016-06-10 11:31:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:31:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:31:20 --> Utf8 Class Initialized
INFO - 2016-06-10 11:31:20 --> URI Class Initialized
INFO - 2016-06-10 11:31:20 --> Router Class Initialized
INFO - 2016-06-10 11:31:20 --> Output Class Initialized
INFO - 2016-06-10 11:31:20 --> Security Class Initialized
DEBUG - 2016-06-10 11:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:31:20 --> Input Class Initialized
INFO - 2016-06-10 11:31:20 --> Language Class Initialized
INFO - 2016-06-10 11:31:20 --> Loader Class Initialized
INFO - 2016-06-10 11:31:20 --> Helper loaded: form_helper
INFO - 2016-06-10 11:31:20 --> Database Driver Class Initialized
INFO - 2016-06-10 11:31:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:31:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:31:20 --> Email Class Initialized
INFO - 2016-06-10 11:31:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:31:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:31:20 --> Helper loaded: language_helper
INFO - 2016-06-10 11:31:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:31:20 --> Model Class Initialized
INFO - 2016-06-10 11:31:20 --> Helper loaded: date_helper
INFO - 2016-06-10 11:31:20 --> Controller Class Initialized
INFO - 2016-06-10 11:31:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:31:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:31:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:31:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:31:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:31:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:31:20 --> Model Class Initialized
INFO - 2016-06-10 11:31:20 --> Form Validation Class Initialized
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:31:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:31:20 --> Final output sent to browser
DEBUG - 2016-06-10 11:31:20 --> Total execution time: 0.0614
INFO - 2016-06-10 11:31:26 --> Config Class Initialized
INFO - 2016-06-10 11:31:26 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:31:26 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:31:26 --> Utf8 Class Initialized
INFO - 2016-06-10 11:31:26 --> URI Class Initialized
INFO - 2016-06-10 11:31:26 --> Router Class Initialized
INFO - 2016-06-10 11:31:26 --> Output Class Initialized
INFO - 2016-06-10 11:31:26 --> Security Class Initialized
DEBUG - 2016-06-10 11:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:31:26 --> Input Class Initialized
INFO - 2016-06-10 11:31:26 --> Language Class Initialized
INFO - 2016-06-10 11:31:26 --> Loader Class Initialized
INFO - 2016-06-10 11:31:26 --> Helper loaded: form_helper
INFO - 2016-06-10 11:31:26 --> Database Driver Class Initialized
INFO - 2016-06-10 11:31:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:31:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:31:26 --> Email Class Initialized
INFO - 2016-06-10 11:31:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:31:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:31:26 --> Helper loaded: language_helper
INFO - 2016-06-10 11:31:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:31:26 --> Model Class Initialized
INFO - 2016-06-10 11:31:26 --> Helper loaded: date_helper
INFO - 2016-06-10 11:31:26 --> Controller Class Initialized
INFO - 2016-06-10 11:31:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:31:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:31:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:31:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:31:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:31:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:31:26 --> Model Class Initialized
INFO - 2016-06-10 11:31:26 --> Form Validation Class Initialized
INFO - 2016-06-10 11:32:15 --> Config Class Initialized
INFO - 2016-06-10 11:32:15 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:32:15 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:32:15 --> Utf8 Class Initialized
INFO - 2016-06-10 11:32:15 --> URI Class Initialized
INFO - 2016-06-10 11:32:15 --> Router Class Initialized
INFO - 2016-06-10 11:32:15 --> Output Class Initialized
INFO - 2016-06-10 11:32:15 --> Security Class Initialized
DEBUG - 2016-06-10 11:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:32:15 --> Input Class Initialized
INFO - 2016-06-10 11:32:15 --> Language Class Initialized
INFO - 2016-06-10 11:32:15 --> Loader Class Initialized
INFO - 2016-06-10 11:32:15 --> Helper loaded: form_helper
INFO - 2016-06-10 11:32:15 --> Database Driver Class Initialized
INFO - 2016-06-10 11:32:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:32:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:32:15 --> Email Class Initialized
INFO - 2016-06-10 11:32:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:32:15 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:32:15 --> Helper loaded: language_helper
INFO - 2016-06-10 11:32:15 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:32:15 --> Model Class Initialized
INFO - 2016-06-10 11:32:15 --> Helper loaded: date_helper
INFO - 2016-06-10 11:32:15 --> Controller Class Initialized
INFO - 2016-06-10 11:32:15 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:32:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:32:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:32:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:32:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:32:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:32:15 --> Model Class Initialized
INFO - 2016-06-10 11:32:15 --> Form Validation Class Initialized
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:32:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:32:16 --> Final output sent to browser
DEBUG - 2016-06-10 11:32:16 --> Total execution time: 0.2227
INFO - 2016-06-10 11:32:20 --> Config Class Initialized
INFO - 2016-06-10 11:32:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:32:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:32:20 --> Utf8 Class Initialized
INFO - 2016-06-10 11:32:20 --> URI Class Initialized
INFO - 2016-06-10 11:32:20 --> Router Class Initialized
INFO - 2016-06-10 11:32:20 --> Output Class Initialized
INFO - 2016-06-10 11:32:20 --> Security Class Initialized
DEBUG - 2016-06-10 11:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:32:20 --> Input Class Initialized
INFO - 2016-06-10 11:32:20 --> Language Class Initialized
INFO - 2016-06-10 11:32:20 --> Loader Class Initialized
INFO - 2016-06-10 11:32:20 --> Helper loaded: form_helper
INFO - 2016-06-10 11:32:20 --> Database Driver Class Initialized
INFO - 2016-06-10 11:32:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:32:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:32:20 --> Email Class Initialized
INFO - 2016-06-10 11:32:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:32:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:32:20 --> Helper loaded: language_helper
INFO - 2016-06-10 11:32:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:32:20 --> Model Class Initialized
INFO - 2016-06-10 11:32:20 --> Helper loaded: date_helper
INFO - 2016-06-10 11:32:20 --> Controller Class Initialized
INFO - 2016-06-10 11:32:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:32:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:32:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:32:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:32:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:32:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:32:20 --> Model Class Initialized
INFO - 2016-06-10 11:32:20 --> Form Validation Class Initialized
INFO - 2016-06-10 11:33:49 --> Config Class Initialized
INFO - 2016-06-10 11:33:49 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:33:49 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:33:49 --> Utf8 Class Initialized
INFO - 2016-06-10 11:33:49 --> URI Class Initialized
INFO - 2016-06-10 11:33:49 --> Router Class Initialized
INFO - 2016-06-10 11:33:49 --> Output Class Initialized
INFO - 2016-06-10 11:33:49 --> Security Class Initialized
DEBUG - 2016-06-10 11:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:33:49 --> Input Class Initialized
INFO - 2016-06-10 11:33:49 --> Language Class Initialized
ERROR - 2016-06-10 11:33:49 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) /home/demis/www/platformadiabet/application/controllers/Diabet.php 407
INFO - 2016-06-10 11:33:57 --> Config Class Initialized
INFO - 2016-06-10 11:33:57 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:33:57 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:33:57 --> Utf8 Class Initialized
INFO - 2016-06-10 11:33:57 --> URI Class Initialized
INFO - 2016-06-10 11:33:57 --> Router Class Initialized
INFO - 2016-06-10 11:33:57 --> Output Class Initialized
INFO - 2016-06-10 11:33:57 --> Security Class Initialized
DEBUG - 2016-06-10 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:33:57 --> Input Class Initialized
INFO - 2016-06-10 11:33:57 --> Language Class Initialized
ERROR - 2016-06-10 11:33:57 --> Severity: Parsing Error --> syntax error, unexpected ')' /home/demis/www/platformadiabet/application/controllers/Diabet.php 421
INFO - 2016-06-10 11:34:02 --> Config Class Initialized
INFO - 2016-06-10 11:34:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:34:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:34:02 --> Utf8 Class Initialized
INFO - 2016-06-10 11:34:02 --> URI Class Initialized
INFO - 2016-06-10 11:34:02 --> Router Class Initialized
INFO - 2016-06-10 11:34:02 --> Output Class Initialized
INFO - 2016-06-10 11:34:02 --> Security Class Initialized
DEBUG - 2016-06-10 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:34:02 --> Input Class Initialized
INFO - 2016-06-10 11:34:02 --> Language Class Initialized
INFO - 2016-06-10 11:34:02 --> Loader Class Initialized
INFO - 2016-06-10 11:34:02 --> Helper loaded: form_helper
INFO - 2016-06-10 11:34:02 --> Database Driver Class Initialized
INFO - 2016-06-10 11:34:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:34:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:34:02 --> Email Class Initialized
INFO - 2016-06-10 11:34:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:34:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:34:02 --> Helper loaded: language_helper
INFO - 2016-06-10 11:34:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:34:02 --> Model Class Initialized
INFO - 2016-06-10 11:34:02 --> Helper loaded: date_helper
INFO - 2016-06-10 11:34:02 --> Controller Class Initialized
INFO - 2016-06-10 11:34:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:34:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:34:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:34:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:34:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:34:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:34:02 --> Model Class Initialized
INFO - 2016-06-10 11:34:02 --> Form Validation Class Initialized
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:34:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:34:02 --> Final output sent to browser
DEBUG - 2016-06-10 11:34:02 --> Total execution time: 0.0720
INFO - 2016-06-10 11:34:07 --> Config Class Initialized
INFO - 2016-06-10 11:34:07 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:34:07 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:34:07 --> Utf8 Class Initialized
INFO - 2016-06-10 11:34:07 --> URI Class Initialized
INFO - 2016-06-10 11:34:07 --> Router Class Initialized
INFO - 2016-06-10 11:34:07 --> Output Class Initialized
INFO - 2016-06-10 11:34:07 --> Security Class Initialized
DEBUG - 2016-06-10 11:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:34:07 --> Input Class Initialized
INFO - 2016-06-10 11:34:07 --> Language Class Initialized
INFO - 2016-06-10 11:34:07 --> Loader Class Initialized
INFO - 2016-06-10 11:34:07 --> Helper loaded: form_helper
INFO - 2016-06-10 11:34:07 --> Database Driver Class Initialized
INFO - 2016-06-10 11:34:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:34:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:34:07 --> Email Class Initialized
INFO - 2016-06-10 11:34:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:34:07 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:34:07 --> Helper loaded: language_helper
INFO - 2016-06-10 11:34:07 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:34:07 --> Model Class Initialized
INFO - 2016-06-10 11:34:07 --> Helper loaded: date_helper
INFO - 2016-06-10 11:34:07 --> Controller Class Initialized
INFO - 2016-06-10 11:34:07 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:34:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:34:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:34:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:34:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:34:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:34:07 --> Model Class Initialized
INFO - 2016-06-10 11:34:07 --> Form Validation Class Initialized
INFO - 2016-06-10 11:34:17 --> Config Class Initialized
INFO - 2016-06-10 11:34:17 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:34:17 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:34:17 --> Utf8 Class Initialized
INFO - 2016-06-10 11:34:17 --> URI Class Initialized
INFO - 2016-06-10 11:34:17 --> Router Class Initialized
INFO - 2016-06-10 11:34:17 --> Output Class Initialized
INFO - 2016-06-10 11:34:17 --> Security Class Initialized
DEBUG - 2016-06-10 11:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:34:17 --> Input Class Initialized
INFO - 2016-06-10 11:34:17 --> Language Class Initialized
INFO - 2016-06-10 11:34:17 --> Loader Class Initialized
INFO - 2016-06-10 11:34:17 --> Helper loaded: form_helper
INFO - 2016-06-10 11:34:17 --> Database Driver Class Initialized
INFO - 2016-06-10 11:34:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:34:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:34:17 --> Email Class Initialized
INFO - 2016-06-10 11:34:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:34:17 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:34:17 --> Helper loaded: language_helper
INFO - 2016-06-10 11:34:17 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:34:17 --> Model Class Initialized
INFO - 2016-06-10 11:34:17 --> Helper loaded: date_helper
INFO - 2016-06-10 11:34:17 --> Controller Class Initialized
INFO - 2016-06-10 11:34:17 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:34:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:34:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:34:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:34:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:34:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:34:17 --> Model Class Initialized
INFO - 2016-06-10 11:34:17 --> Form Validation Class Initialized
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:34:17 --> Final output sent to browser
DEBUG - 2016-06-10 11:34:17 --> Total execution time: 0.1223
INFO - 2016-06-10 11:34:23 --> Config Class Initialized
INFO - 2016-06-10 11:34:23 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:34:23 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:34:23 --> Utf8 Class Initialized
INFO - 2016-06-10 11:34:23 --> URI Class Initialized
INFO - 2016-06-10 11:34:23 --> Router Class Initialized
INFO - 2016-06-10 11:34:23 --> Output Class Initialized
INFO - 2016-06-10 11:34:23 --> Security Class Initialized
DEBUG - 2016-06-10 11:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:34:23 --> Input Class Initialized
INFO - 2016-06-10 11:34:23 --> Language Class Initialized
INFO - 2016-06-10 11:34:23 --> Loader Class Initialized
INFO - 2016-06-10 11:34:23 --> Helper loaded: form_helper
INFO - 2016-06-10 11:34:23 --> Database Driver Class Initialized
INFO - 2016-06-10 11:34:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:34:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:34:23 --> Email Class Initialized
INFO - 2016-06-10 11:34:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:34:23 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:34:23 --> Helper loaded: language_helper
INFO - 2016-06-10 11:34:23 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:34:23 --> Model Class Initialized
INFO - 2016-06-10 11:34:23 --> Helper loaded: date_helper
INFO - 2016-06-10 11:34:23 --> Controller Class Initialized
INFO - 2016-06-10 11:34:23 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:34:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:34:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:34:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:34:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:34:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:34:23 --> Model Class Initialized
INFO - 2016-06-10 11:34:23 --> Form Validation Class Initialized
INFO - 2016-06-10 11:34:25 --> Config Class Initialized
INFO - 2016-06-10 11:34:25 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:34:25 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:34:25 --> Utf8 Class Initialized
INFO - 2016-06-10 11:34:25 --> URI Class Initialized
INFO - 2016-06-10 11:34:25 --> Router Class Initialized
INFO - 2016-06-10 11:34:25 --> Output Class Initialized
INFO - 2016-06-10 11:34:25 --> Security Class Initialized
DEBUG - 2016-06-10 11:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:34:25 --> Input Class Initialized
INFO - 2016-06-10 11:34:25 --> Language Class Initialized
INFO - 2016-06-10 11:34:26 --> Loader Class Initialized
INFO - 2016-06-10 11:34:26 --> Helper loaded: form_helper
INFO - 2016-06-10 11:34:26 --> Database Driver Class Initialized
INFO - 2016-06-10 11:34:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:34:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:34:26 --> Email Class Initialized
INFO - 2016-06-10 11:34:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:34:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:34:26 --> Helper loaded: language_helper
INFO - 2016-06-10 11:34:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:34:26 --> Model Class Initialized
INFO - 2016-06-10 11:34:26 --> Helper loaded: date_helper
INFO - 2016-06-10 11:34:26 --> Controller Class Initialized
INFO - 2016-06-10 11:34:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:34:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:34:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:34:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:34:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:34:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:34:26 --> Model Class Initialized
INFO - 2016-06-10 11:34:26 --> Form Validation Class Initialized
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:34:26 --> Final output sent to browser
DEBUG - 2016-06-10 11:34:26 --> Total execution time: 0.1022
INFO - 2016-06-10 11:34:33 --> Config Class Initialized
INFO - 2016-06-10 11:34:33 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:34:33 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:34:33 --> Utf8 Class Initialized
INFO - 2016-06-10 11:34:33 --> URI Class Initialized
INFO - 2016-06-10 11:34:33 --> Router Class Initialized
INFO - 2016-06-10 11:34:33 --> Output Class Initialized
INFO - 2016-06-10 11:34:33 --> Security Class Initialized
DEBUG - 2016-06-10 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:34:33 --> Input Class Initialized
INFO - 2016-06-10 11:34:33 --> Language Class Initialized
INFO - 2016-06-10 11:34:33 --> Loader Class Initialized
INFO - 2016-06-10 11:34:33 --> Helper loaded: form_helper
INFO - 2016-06-10 11:34:33 --> Database Driver Class Initialized
INFO - 2016-06-10 11:34:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:34:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:34:33 --> Email Class Initialized
INFO - 2016-06-10 11:34:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:34:33 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:34:33 --> Helper loaded: language_helper
INFO - 2016-06-10 11:34:33 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:34:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:34:33 --> Model Class Initialized
INFO - 2016-06-10 11:34:33 --> Helper loaded: date_helper
INFO - 2016-06-10 11:34:33 --> Controller Class Initialized
INFO - 2016-06-10 11:34:33 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:34:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:34:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:34:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:34:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:34:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:34:33 --> Model Class Initialized
INFO - 2016-06-10 11:34:33 --> Form Validation Class Initialized
INFO - 2016-06-10 11:34:33 --> Final output sent to browser
DEBUG - 2016-06-10 11:34:33 --> Total execution time: 0.0561
INFO - 2016-06-10 11:36:59 --> Config Class Initialized
INFO - 2016-06-10 11:36:59 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:36:59 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:36:59 --> Utf8 Class Initialized
INFO - 2016-06-10 11:36:59 --> URI Class Initialized
INFO - 2016-06-10 11:36:59 --> Router Class Initialized
INFO - 2016-06-10 11:36:59 --> Output Class Initialized
INFO - 2016-06-10 11:36:59 --> Security Class Initialized
DEBUG - 2016-06-10 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:36:59 --> Input Class Initialized
INFO - 2016-06-10 11:36:59 --> Language Class Initialized
INFO - 2016-06-10 11:36:59 --> Loader Class Initialized
INFO - 2016-06-10 11:36:59 --> Helper loaded: form_helper
INFO - 2016-06-10 11:36:59 --> Database Driver Class Initialized
INFO - 2016-06-10 11:36:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:36:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:36:59 --> Email Class Initialized
INFO - 2016-06-10 11:36:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:36:59 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:36:59 --> Helper loaded: language_helper
INFO - 2016-06-10 11:36:59 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:36:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:36:59 --> Model Class Initialized
INFO - 2016-06-10 11:36:59 --> Helper loaded: date_helper
INFO - 2016-06-10 11:36:59 --> Controller Class Initialized
INFO - 2016-06-10 11:36:59 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:36:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:36:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:36:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:36:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:36:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:36:59 --> Model Class Initialized
INFO - 2016-06-10 11:36:59 --> Form Validation Class Initialized
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:36:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:36:59 --> Final output sent to browser
DEBUG - 2016-06-10 11:36:59 --> Total execution time: 0.0724
INFO - 2016-06-10 11:37:05 --> Config Class Initialized
INFO - 2016-06-10 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:37:05 --> Utf8 Class Initialized
INFO - 2016-06-10 11:37:05 --> URI Class Initialized
INFO - 2016-06-10 11:37:05 --> Router Class Initialized
INFO - 2016-06-10 11:37:05 --> Output Class Initialized
INFO - 2016-06-10 11:37:05 --> Security Class Initialized
DEBUG - 2016-06-10 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:37:05 --> Input Class Initialized
INFO - 2016-06-10 11:37:05 --> Language Class Initialized
INFO - 2016-06-10 11:37:05 --> Loader Class Initialized
INFO - 2016-06-10 11:37:05 --> Helper loaded: form_helper
INFO - 2016-06-10 11:37:05 --> Database Driver Class Initialized
INFO - 2016-06-10 11:37:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:37:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:37:05 --> Email Class Initialized
INFO - 2016-06-10 11:37:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:37:05 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:37:05 --> Helper loaded: language_helper
INFO - 2016-06-10 11:37:05 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:37:05 --> Model Class Initialized
INFO - 2016-06-10 11:37:05 --> Helper loaded: date_helper
INFO - 2016-06-10 11:37:05 --> Controller Class Initialized
INFO - 2016-06-10 11:37:05 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:37:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:37:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:37:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:37:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:37:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:37:05 --> Model Class Initialized
INFO - 2016-06-10 11:37:05 --> Form Validation Class Initialized
INFO - 2016-06-10 11:37:05 --> Final output sent to browser
DEBUG - 2016-06-10 11:37:05 --> Total execution time: 0.0447
INFO - 2016-06-10 11:45:49 --> Config Class Initialized
INFO - 2016-06-10 11:45:49 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:45:49 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:45:49 --> Utf8 Class Initialized
INFO - 2016-06-10 11:45:49 --> URI Class Initialized
INFO - 2016-06-10 11:45:49 --> Router Class Initialized
INFO - 2016-06-10 11:45:49 --> Output Class Initialized
INFO - 2016-06-10 11:45:49 --> Security Class Initialized
DEBUG - 2016-06-10 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:45:49 --> Input Class Initialized
INFO - 2016-06-10 11:45:49 --> Language Class Initialized
INFO - 2016-06-10 11:45:49 --> Loader Class Initialized
INFO - 2016-06-10 11:45:49 --> Helper loaded: form_helper
INFO - 2016-06-10 11:45:49 --> Database Driver Class Initialized
INFO - 2016-06-10 11:45:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:45:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:45:49 --> Email Class Initialized
INFO - 2016-06-10 11:45:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:45:49 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:45:49 --> Helper loaded: language_helper
INFO - 2016-06-10 11:45:49 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:45:49 --> Model Class Initialized
INFO - 2016-06-10 11:45:49 --> Helper loaded: date_helper
INFO - 2016-06-10 11:45:49 --> Controller Class Initialized
INFO - 2016-06-10 11:45:49 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:45:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:45:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:45:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:45:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:45:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:45:49 --> Model Class Initialized
INFO - 2016-06-10 11:45:49 --> Form Validation Class Initialized
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:45:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:45:49 --> Final output sent to browser
DEBUG - 2016-06-10 11:45:49 --> Total execution time: 0.0994
INFO - 2016-06-10 11:46:03 --> Config Class Initialized
INFO - 2016-06-10 11:46:03 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:46:03 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:46:03 --> Utf8 Class Initialized
INFO - 2016-06-10 11:46:03 --> URI Class Initialized
INFO - 2016-06-10 11:46:03 --> Router Class Initialized
INFO - 2016-06-10 11:46:03 --> Output Class Initialized
INFO - 2016-06-10 11:46:03 --> Security Class Initialized
DEBUG - 2016-06-10 11:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:46:03 --> Input Class Initialized
INFO - 2016-06-10 11:46:03 --> Language Class Initialized
INFO - 2016-06-10 11:46:03 --> Loader Class Initialized
INFO - 2016-06-10 11:46:03 --> Helper loaded: form_helper
INFO - 2016-06-10 11:46:03 --> Database Driver Class Initialized
INFO - 2016-06-10 11:46:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:46:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:46:03 --> Email Class Initialized
INFO - 2016-06-10 11:46:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:46:03 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:46:03 --> Helper loaded: language_helper
INFO - 2016-06-10 11:46:03 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:46:03 --> Model Class Initialized
INFO - 2016-06-10 11:46:03 --> Helper loaded: date_helper
INFO - 2016-06-10 11:46:03 --> Controller Class Initialized
INFO - 2016-06-10 11:46:03 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:46:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:46:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:46:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:46:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:46:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:46:03 --> Model Class Initialized
INFO - 2016-06-10 11:46:03 --> Form Validation Class Initialized
INFO - 2016-06-10 11:46:03 --> Final output sent to browser
DEBUG - 2016-06-10 11:46:03 --> Total execution time: 0.0833
INFO - 2016-06-10 11:46:21 --> Config Class Initialized
INFO - 2016-06-10 11:46:21 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:46:21 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:46:21 --> Utf8 Class Initialized
INFO - 2016-06-10 11:46:21 --> URI Class Initialized
INFO - 2016-06-10 11:46:21 --> Router Class Initialized
INFO - 2016-06-10 11:46:21 --> Output Class Initialized
INFO - 2016-06-10 11:46:21 --> Security Class Initialized
DEBUG - 2016-06-10 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:46:21 --> Input Class Initialized
INFO - 2016-06-10 11:46:21 --> Language Class Initialized
INFO - 2016-06-10 11:46:21 --> Loader Class Initialized
INFO - 2016-06-10 11:46:21 --> Helper loaded: form_helper
INFO - 2016-06-10 11:46:21 --> Database Driver Class Initialized
INFO - 2016-06-10 11:46:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:46:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:46:21 --> Email Class Initialized
INFO - 2016-06-10 11:46:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:46:21 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:46:21 --> Helper loaded: language_helper
INFO - 2016-06-10 11:46:21 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:46:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:46:21 --> Model Class Initialized
INFO - 2016-06-10 11:46:21 --> Helper loaded: date_helper
INFO - 2016-06-10 11:46:21 --> Controller Class Initialized
INFO - 2016-06-10 11:46:21 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:46:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:46:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:46:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:46:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:46:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:46:21 --> Model Class Initialized
INFO - 2016-06-10 11:46:21 --> Form Validation Class Initialized
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:46:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:46:21 --> Final output sent to browser
DEBUG - 2016-06-10 11:46:21 --> Total execution time: 0.0744
INFO - 2016-06-10 11:46:26 --> Config Class Initialized
INFO - 2016-06-10 11:46:26 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:46:26 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:46:26 --> Utf8 Class Initialized
INFO - 2016-06-10 11:46:26 --> URI Class Initialized
INFO - 2016-06-10 11:46:26 --> Router Class Initialized
INFO - 2016-06-10 11:46:26 --> Output Class Initialized
INFO - 2016-06-10 11:46:26 --> Security Class Initialized
DEBUG - 2016-06-10 11:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:46:26 --> Input Class Initialized
INFO - 2016-06-10 11:46:26 --> Language Class Initialized
INFO - 2016-06-10 11:46:26 --> Loader Class Initialized
INFO - 2016-06-10 11:46:26 --> Helper loaded: form_helper
INFO - 2016-06-10 11:46:26 --> Database Driver Class Initialized
INFO - 2016-06-10 11:46:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:46:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:46:26 --> Email Class Initialized
INFO - 2016-06-10 11:46:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:46:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:46:26 --> Helper loaded: language_helper
INFO - 2016-06-10 11:46:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:46:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:46:26 --> Model Class Initialized
INFO - 2016-06-10 11:46:26 --> Helper loaded: date_helper
INFO - 2016-06-10 11:46:26 --> Controller Class Initialized
INFO - 2016-06-10 11:46:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:46:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:46:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:46:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:46:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:46:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:46:26 --> Model Class Initialized
INFO - 2016-06-10 11:46:26 --> Form Validation Class Initialized
INFO - 2016-06-10 11:46:26 --> Final output sent to browser
DEBUG - 2016-06-10 11:46:26 --> Total execution time: 0.0800
INFO - 2016-06-10 11:46:57 --> Config Class Initialized
INFO - 2016-06-10 11:46:57 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:46:57 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:46:57 --> Utf8 Class Initialized
INFO - 2016-06-10 11:46:57 --> URI Class Initialized
INFO - 2016-06-10 11:46:57 --> Router Class Initialized
INFO - 2016-06-10 11:46:57 --> Output Class Initialized
INFO - 2016-06-10 11:46:57 --> Security Class Initialized
DEBUG - 2016-06-10 11:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:46:57 --> Input Class Initialized
INFO - 2016-06-10 11:46:57 --> Language Class Initialized
INFO - 2016-06-10 11:46:57 --> Loader Class Initialized
INFO - 2016-06-10 11:46:57 --> Helper loaded: form_helper
INFO - 2016-06-10 11:46:57 --> Database Driver Class Initialized
INFO - 2016-06-10 11:46:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:46:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:46:57 --> Email Class Initialized
INFO - 2016-06-10 11:46:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:46:57 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:46:57 --> Helper loaded: language_helper
INFO - 2016-06-10 11:46:57 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:46:57 --> Model Class Initialized
INFO - 2016-06-10 11:46:57 --> Helper loaded: date_helper
INFO - 2016-06-10 11:46:57 --> Controller Class Initialized
INFO - 2016-06-10 11:46:57 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:46:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:46:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:46:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:46:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:46:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:46:57 --> Model Class Initialized
INFO - 2016-06-10 11:46:57 --> Form Validation Class Initialized
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:46:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:46:57 --> Final output sent to browser
DEBUG - 2016-06-10 11:46:57 --> Total execution time: 0.1166
INFO - 2016-06-10 11:47:03 --> Config Class Initialized
INFO - 2016-06-10 11:47:03 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:47:03 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:47:03 --> Utf8 Class Initialized
INFO - 2016-06-10 11:47:03 --> URI Class Initialized
INFO - 2016-06-10 11:47:03 --> Router Class Initialized
INFO - 2016-06-10 11:47:03 --> Output Class Initialized
INFO - 2016-06-10 11:47:03 --> Security Class Initialized
DEBUG - 2016-06-10 11:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:47:03 --> Input Class Initialized
INFO - 2016-06-10 11:47:03 --> Language Class Initialized
INFO - 2016-06-10 11:47:03 --> Loader Class Initialized
INFO - 2016-06-10 11:47:03 --> Helper loaded: form_helper
INFO - 2016-06-10 11:47:03 --> Database Driver Class Initialized
INFO - 2016-06-10 11:47:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:47:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:47:03 --> Email Class Initialized
INFO - 2016-06-10 11:47:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:47:03 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:47:03 --> Helper loaded: language_helper
INFO - 2016-06-10 11:47:03 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:47:03 --> Model Class Initialized
INFO - 2016-06-10 11:47:03 --> Helper loaded: date_helper
INFO - 2016-06-10 11:47:03 --> Controller Class Initialized
INFO - 2016-06-10 11:47:03 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:47:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:47:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:47:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:47:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:47:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:47:03 --> Model Class Initialized
INFO - 2016-06-10 11:47:03 --> Form Validation Class Initialized
INFO - 2016-06-10 11:47:03 --> Final output sent to browser
DEBUG - 2016-06-10 11:47:03 --> Total execution time: 0.0545
INFO - 2016-06-10 11:47:09 --> Config Class Initialized
INFO - 2016-06-10 11:47:09 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:47:09 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:47:09 --> Utf8 Class Initialized
INFO - 2016-06-10 11:47:09 --> URI Class Initialized
INFO - 2016-06-10 11:47:09 --> Router Class Initialized
INFO - 2016-06-10 11:47:09 --> Output Class Initialized
INFO - 2016-06-10 11:47:09 --> Security Class Initialized
DEBUG - 2016-06-10 11:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:47:09 --> Input Class Initialized
INFO - 2016-06-10 11:47:09 --> Language Class Initialized
INFO - 2016-06-10 11:47:09 --> Loader Class Initialized
INFO - 2016-06-10 11:47:09 --> Helper loaded: form_helper
INFO - 2016-06-10 11:47:09 --> Database Driver Class Initialized
INFO - 2016-06-10 11:47:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:47:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:47:09 --> Email Class Initialized
INFO - 2016-06-10 11:47:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:47:09 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:47:09 --> Helper loaded: language_helper
INFO - 2016-06-10 11:47:09 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:47:09 --> Model Class Initialized
INFO - 2016-06-10 11:47:10 --> Helper loaded: date_helper
INFO - 2016-06-10 11:47:10 --> Controller Class Initialized
INFO - 2016-06-10 11:47:10 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:47:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:47:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:47:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:47:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:47:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:47:10 --> Model Class Initialized
INFO - 2016-06-10 11:47:10 --> Form Validation Class Initialized
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:47:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:47:10 --> Final output sent to browser
DEBUG - 2016-06-10 11:47:10 --> Total execution time: 0.0649
INFO - 2016-06-10 11:47:15 --> Config Class Initialized
INFO - 2016-06-10 11:47:15 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:47:15 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:47:15 --> Utf8 Class Initialized
INFO - 2016-06-10 11:47:15 --> URI Class Initialized
INFO - 2016-06-10 11:47:15 --> Router Class Initialized
INFO - 2016-06-10 11:47:15 --> Output Class Initialized
INFO - 2016-06-10 11:47:15 --> Security Class Initialized
DEBUG - 2016-06-10 11:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:47:15 --> Input Class Initialized
INFO - 2016-06-10 11:47:15 --> Language Class Initialized
INFO - 2016-06-10 11:47:15 --> Loader Class Initialized
INFO - 2016-06-10 11:47:15 --> Helper loaded: form_helper
INFO - 2016-06-10 11:47:15 --> Database Driver Class Initialized
INFO - 2016-06-10 11:47:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:47:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:47:15 --> Email Class Initialized
INFO - 2016-06-10 11:47:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:47:15 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:47:15 --> Helper loaded: language_helper
INFO - 2016-06-10 11:47:15 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:47:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:47:15 --> Model Class Initialized
INFO - 2016-06-10 11:47:15 --> Helper loaded: date_helper
INFO - 2016-06-10 11:47:15 --> Controller Class Initialized
INFO - 2016-06-10 11:47:15 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:47:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:47:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:47:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:47:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:47:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:47:15 --> Model Class Initialized
INFO - 2016-06-10 11:47:15 --> Form Validation Class Initialized
INFO - 2016-06-10 11:47:15 --> Final output sent to browser
DEBUG - 2016-06-10 11:47:15 --> Total execution time: 0.0644
INFO - 2016-06-10 11:53:51 --> Config Class Initialized
INFO - 2016-06-10 11:53:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:53:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:53:51 --> Utf8 Class Initialized
INFO - 2016-06-10 11:53:51 --> URI Class Initialized
INFO - 2016-06-10 11:53:51 --> Router Class Initialized
INFO - 2016-06-10 11:53:51 --> Output Class Initialized
INFO - 2016-06-10 11:53:51 --> Security Class Initialized
DEBUG - 2016-06-10 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:53:51 --> Input Class Initialized
INFO - 2016-06-10 11:53:51 --> Language Class Initialized
INFO - 2016-06-10 11:53:51 --> Loader Class Initialized
INFO - 2016-06-10 11:53:51 --> Helper loaded: form_helper
INFO - 2016-06-10 11:53:51 --> Database Driver Class Initialized
INFO - 2016-06-10 11:53:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:53:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:53:51 --> Email Class Initialized
INFO - 2016-06-10 11:53:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:53:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:53:51 --> Helper loaded: language_helper
INFO - 2016-06-10 11:53:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:53:51 --> Model Class Initialized
INFO - 2016-06-10 11:53:51 --> Helper loaded: date_helper
INFO - 2016-06-10 11:53:51 --> Controller Class Initialized
INFO - 2016-06-10 11:53:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:53:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:53:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:53:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:53:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:53:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:53:51 --> Model Class Initialized
INFO - 2016-06-10 11:53:51 --> Form Validation Class Initialized
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:53:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:53:51 --> Final output sent to browser
DEBUG - 2016-06-10 11:53:51 --> Total execution time: 0.1139
INFO - 2016-06-10 11:54:00 --> Config Class Initialized
INFO - 2016-06-10 11:54:00 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:54:00 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:54:00 --> Utf8 Class Initialized
INFO - 2016-06-10 11:54:00 --> URI Class Initialized
INFO - 2016-06-10 11:54:00 --> Router Class Initialized
INFO - 2016-06-10 11:54:00 --> Output Class Initialized
INFO - 2016-06-10 11:54:00 --> Security Class Initialized
DEBUG - 2016-06-10 11:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:54:00 --> Input Class Initialized
INFO - 2016-06-10 11:54:00 --> Language Class Initialized
INFO - 2016-06-10 11:54:00 --> Loader Class Initialized
INFO - 2016-06-10 11:54:00 --> Helper loaded: form_helper
INFO - 2016-06-10 11:54:00 --> Database Driver Class Initialized
INFO - 2016-06-10 11:54:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:54:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:54:00 --> Email Class Initialized
INFO - 2016-06-10 11:54:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:54:00 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:54:00 --> Helper loaded: language_helper
INFO - 2016-06-10 11:54:00 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:54:00 --> Model Class Initialized
INFO - 2016-06-10 11:54:00 --> Helper loaded: date_helper
INFO - 2016-06-10 11:54:00 --> Controller Class Initialized
INFO - 2016-06-10 11:54:00 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:54:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:54:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:54:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:54:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:54:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:54:01 --> Model Class Initialized
INFO - 2016-06-10 11:54:01 --> Form Validation Class Initialized
INFO - 2016-06-10 11:54:01 --> Final output sent to browser
DEBUG - 2016-06-10 11:54:01 --> Total execution time: 0.0925
INFO - 2016-06-10 11:59:50 --> Config Class Initialized
INFO - 2016-06-10 11:59:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:59:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:59:50 --> Utf8 Class Initialized
INFO - 2016-06-10 11:59:50 --> URI Class Initialized
INFO - 2016-06-10 11:59:50 --> Router Class Initialized
INFO - 2016-06-10 11:59:50 --> Output Class Initialized
INFO - 2016-06-10 11:59:50 --> Security Class Initialized
DEBUG - 2016-06-10 11:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:59:50 --> Input Class Initialized
INFO - 2016-06-10 11:59:50 --> Language Class Initialized
INFO - 2016-06-10 11:59:50 --> Loader Class Initialized
INFO - 2016-06-10 11:59:50 --> Helper loaded: form_helper
INFO - 2016-06-10 11:59:50 --> Database Driver Class Initialized
INFO - 2016-06-10 11:59:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:59:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:59:50 --> Email Class Initialized
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:59:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:59:50 --> Helper loaded: language_helper
INFO - 2016-06-10 11:59:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:59:50 --> Model Class Initialized
INFO - 2016-06-10 11:59:50 --> Helper loaded: date_helper
INFO - 2016-06-10 11:59:50 --> Controller Class Initialized
INFO - 2016-06-10 11:59:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:59:50 --> Model Class Initialized
INFO - 2016-06-10 11:59:50 --> Form Validation Class Initialized
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:59:50 --> Final output sent to browser
DEBUG - 2016-06-10 11:59:50 --> Total execution time: 0.1141
INFO - 2016-06-10 11:59:50 --> Config Class Initialized
INFO - 2016-06-10 11:59:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:59:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:59:50 --> Utf8 Class Initialized
INFO - 2016-06-10 11:59:50 --> URI Class Initialized
INFO - 2016-06-10 11:59:50 --> Router Class Initialized
INFO - 2016-06-10 11:59:50 --> Output Class Initialized
INFO - 2016-06-10 11:59:50 --> Security Class Initialized
DEBUG - 2016-06-10 11:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:59:50 --> Input Class Initialized
INFO - 2016-06-10 11:59:50 --> Language Class Initialized
INFO - 2016-06-10 11:59:50 --> Loader Class Initialized
INFO - 2016-06-10 11:59:50 --> Helper loaded: form_helper
INFO - 2016-06-10 11:59:50 --> Database Driver Class Initialized
INFO - 2016-06-10 11:59:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:59:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:59:50 --> Email Class Initialized
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:59:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:59:50 --> Helper loaded: language_helper
INFO - 2016-06-10 11:59:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:59:50 --> Model Class Initialized
INFO - 2016-06-10 11:59:50 --> Helper loaded: date_helper
INFO - 2016-06-10 11:59:50 --> Controller Class Initialized
INFO - 2016-06-10 11:59:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:59:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:59:50 --> Model Class Initialized
INFO - 2016-06-10 11:59:50 --> Form Validation Class Initialized
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 11:59:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 11:59:50 --> Final output sent to browser
DEBUG - 2016-06-10 11:59:50 --> Total execution time: 0.3937
INFO - 2016-06-10 11:59:56 --> Config Class Initialized
INFO - 2016-06-10 11:59:56 --> Hooks Class Initialized
DEBUG - 2016-06-10 11:59:56 --> UTF-8 Support Enabled
INFO - 2016-06-10 11:59:56 --> Utf8 Class Initialized
INFO - 2016-06-10 11:59:56 --> URI Class Initialized
INFO - 2016-06-10 11:59:56 --> Router Class Initialized
INFO - 2016-06-10 11:59:56 --> Output Class Initialized
INFO - 2016-06-10 11:59:56 --> Security Class Initialized
DEBUG - 2016-06-10 11:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 11:59:56 --> Input Class Initialized
INFO - 2016-06-10 11:59:56 --> Language Class Initialized
INFO - 2016-06-10 11:59:56 --> Loader Class Initialized
INFO - 2016-06-10 11:59:56 --> Helper loaded: form_helper
INFO - 2016-06-10 11:59:56 --> Database Driver Class Initialized
INFO - 2016-06-10 11:59:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 11:59:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 11:59:56 --> Email Class Initialized
INFO - 2016-06-10 11:59:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 11:59:56 --> Helper loaded: cookie_helper
INFO - 2016-06-10 11:59:56 --> Helper loaded: language_helper
INFO - 2016-06-10 11:59:56 --> Helper loaded: url_helper
DEBUG - 2016-06-10 11:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 11:59:56 --> Model Class Initialized
INFO - 2016-06-10 11:59:56 --> Helper loaded: date_helper
INFO - 2016-06-10 11:59:56 --> Controller Class Initialized
INFO - 2016-06-10 11:59:56 --> Helper loaded: languages_helper
INFO - 2016-06-10 11:59:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 11:59:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 11:59:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 11:59:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 11:59:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 11:59:56 --> Model Class Initialized
INFO - 2016-06-10 11:59:56 --> Form Validation Class Initialized
INFO - 2016-06-10 11:59:56 --> Final output sent to browser
DEBUG - 2016-06-10 11:59:56 --> Total execution time: 0.0662
INFO - 2016-06-10 12:01:00 --> Config Class Initialized
INFO - 2016-06-10 12:01:00 --> Hooks Class Initialized
DEBUG - 2016-06-10 12:01:00 --> UTF-8 Support Enabled
INFO - 2016-06-10 12:01:00 --> Utf8 Class Initialized
INFO - 2016-06-10 12:01:00 --> URI Class Initialized
INFO - 2016-06-10 12:01:00 --> Router Class Initialized
INFO - 2016-06-10 12:01:00 --> Output Class Initialized
INFO - 2016-06-10 12:01:00 --> Security Class Initialized
DEBUG - 2016-06-10 12:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 12:01:00 --> Input Class Initialized
INFO - 2016-06-10 12:01:00 --> Language Class Initialized
INFO - 2016-06-10 12:01:00 --> Loader Class Initialized
INFO - 2016-06-10 12:01:00 --> Helper loaded: form_helper
INFO - 2016-06-10 12:01:00 --> Database Driver Class Initialized
INFO - 2016-06-10 12:01:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 12:01:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 12:01:00 --> Email Class Initialized
INFO - 2016-06-10 12:01:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 12:01:00 --> Helper loaded: cookie_helper
INFO - 2016-06-10 12:01:00 --> Helper loaded: language_helper
INFO - 2016-06-10 12:01:00 --> Helper loaded: url_helper
DEBUG - 2016-06-10 12:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 12:01:00 --> Model Class Initialized
INFO - 2016-06-10 12:01:00 --> Helper loaded: date_helper
INFO - 2016-06-10 12:01:00 --> Controller Class Initialized
INFO - 2016-06-10 12:01:00 --> Helper loaded: languages_helper
INFO - 2016-06-10 12:01:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 12:01:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 12:01:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 12:01:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 12:01:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 12:01:00 --> Model Class Initialized
INFO - 2016-06-10 12:01:00 --> Form Validation Class Initialized
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 12:01:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 12:01:00 --> Final output sent to browser
DEBUG - 2016-06-10 12:01:00 --> Total execution time: 0.0870
INFO - 2016-06-10 12:01:05 --> Config Class Initialized
INFO - 2016-06-10 12:01:05 --> Hooks Class Initialized
DEBUG - 2016-06-10 12:01:05 --> UTF-8 Support Enabled
INFO - 2016-06-10 12:01:05 --> Utf8 Class Initialized
INFO - 2016-06-10 12:01:05 --> URI Class Initialized
INFO - 2016-06-10 12:01:05 --> Router Class Initialized
INFO - 2016-06-10 12:01:05 --> Output Class Initialized
INFO - 2016-06-10 12:01:05 --> Security Class Initialized
DEBUG - 2016-06-10 12:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 12:01:05 --> Input Class Initialized
INFO - 2016-06-10 12:01:05 --> Language Class Initialized
INFO - 2016-06-10 12:01:05 --> Loader Class Initialized
INFO - 2016-06-10 12:01:05 --> Helper loaded: form_helper
INFO - 2016-06-10 12:01:05 --> Database Driver Class Initialized
INFO - 2016-06-10 12:01:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 12:01:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 12:01:05 --> Email Class Initialized
INFO - 2016-06-10 12:01:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 12:01:05 --> Helper loaded: cookie_helper
INFO - 2016-06-10 12:01:05 --> Helper loaded: language_helper
INFO - 2016-06-10 12:01:05 --> Helper loaded: url_helper
DEBUG - 2016-06-10 12:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 12:01:05 --> Model Class Initialized
INFO - 2016-06-10 12:01:05 --> Helper loaded: date_helper
INFO - 2016-06-10 12:01:05 --> Controller Class Initialized
INFO - 2016-06-10 12:01:05 --> Helper loaded: languages_helper
INFO - 2016-06-10 12:01:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 12:01:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 12:01:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 12:01:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 12:01:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 12:01:05 --> Model Class Initialized
INFO - 2016-06-10 12:01:05 --> Form Validation Class Initialized
INFO - 2016-06-10 12:01:05 --> Final output sent to browser
DEBUG - 2016-06-10 12:01:05 --> Total execution time: 0.0450
INFO - 2016-06-10 13:46:54 --> Config Class Initialized
INFO - 2016-06-10 13:46:54 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:46:54 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:46:54 --> Utf8 Class Initialized
INFO - 2016-06-10 13:46:54 --> URI Class Initialized
INFO - 2016-06-10 13:46:54 --> Router Class Initialized
INFO - 2016-06-10 13:46:54 --> Output Class Initialized
INFO - 2016-06-10 13:46:54 --> Security Class Initialized
DEBUG - 2016-06-10 13:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:46:54 --> Input Class Initialized
INFO - 2016-06-10 13:46:54 --> Language Class Initialized
INFO - 2016-06-10 13:46:54 --> Loader Class Initialized
INFO - 2016-06-10 13:46:54 --> Helper loaded: form_helper
INFO - 2016-06-10 13:46:54 --> Database Driver Class Initialized
INFO - 2016-06-10 13:46:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:46:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:46:54 --> Email Class Initialized
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:46:54 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:46:54 --> Helper loaded: language_helper
INFO - 2016-06-10 13:46:54 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:46:54 --> Model Class Initialized
INFO - 2016-06-10 13:46:54 --> Helper loaded: date_helper
INFO - 2016-06-10 13:46:54 --> Controller Class Initialized
INFO - 2016-06-10 13:46:54 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 13:46:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:46:54 --> Form Validation Class Initialized
INFO - 2016-06-10 13:46:54 --> Config Class Initialized
INFO - 2016-06-10 13:46:54 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:46:54 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:46:54 --> Utf8 Class Initialized
INFO - 2016-06-10 13:46:54 --> URI Class Initialized
INFO - 2016-06-10 13:46:54 --> Router Class Initialized
INFO - 2016-06-10 13:46:54 --> Output Class Initialized
INFO - 2016-06-10 13:46:54 --> Security Class Initialized
DEBUG - 2016-06-10 13:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:46:54 --> Input Class Initialized
INFO - 2016-06-10 13:46:54 --> Language Class Initialized
INFO - 2016-06-10 13:46:54 --> Loader Class Initialized
INFO - 2016-06-10 13:46:54 --> Helper loaded: form_helper
INFO - 2016-06-10 13:46:54 --> Database Driver Class Initialized
INFO - 2016-06-10 13:46:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:46:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:46:54 --> Email Class Initialized
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:46:54 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:46:54 --> Helper loaded: language_helper
INFO - 2016-06-10 13:46:54 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:46:54 --> Model Class Initialized
INFO - 2016-06-10 13:46:54 --> Helper loaded: date_helper
INFO - 2016-06-10 13:46:54 --> Controller Class Initialized
INFO - 2016-06-10 13:46:54 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:46:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 13:46:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:46:54 --> Form Validation Class Initialized
DEBUG - 2016-06-10 13:46:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:46:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 13:46:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 13:46:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 13:46:54 --> Final output sent to browser
DEBUG - 2016-06-10 13:46:54 --> Total execution time: 0.1258
INFO - 2016-06-10 13:49:02 --> Config Class Initialized
INFO - 2016-06-10 13:49:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:49:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:49:02 --> Utf8 Class Initialized
INFO - 2016-06-10 13:49:02 --> URI Class Initialized
INFO - 2016-06-10 13:49:02 --> Router Class Initialized
INFO - 2016-06-10 13:49:02 --> Output Class Initialized
INFO - 2016-06-10 13:49:02 --> Security Class Initialized
DEBUG - 2016-06-10 13:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:49:02 --> Input Class Initialized
INFO - 2016-06-10 13:49:02 --> Language Class Initialized
INFO - 2016-06-10 13:49:02 --> Loader Class Initialized
INFO - 2016-06-10 13:49:02 --> Helper loaded: form_helper
INFO - 2016-06-10 13:49:02 --> Database Driver Class Initialized
INFO - 2016-06-10 13:49:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:49:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:49:02 --> Email Class Initialized
INFO - 2016-06-10 13:49:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:49:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:49:02 --> Helper loaded: language_helper
INFO - 2016-06-10 13:49:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:49:02 --> Model Class Initialized
INFO - 2016-06-10 13:49:02 --> Helper loaded: date_helper
INFO - 2016-06-10 13:49:02 --> Controller Class Initialized
INFO - 2016-06-10 13:49:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:49:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:49:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:49:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:49:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:49:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 13:49:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:49:02 --> Form Validation Class Initialized
DEBUG - 2016-06-10 13:49:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:49:04 --> Config Class Initialized
INFO - 2016-06-10 13:49:04 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:49:04 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:49:04 --> Utf8 Class Initialized
INFO - 2016-06-10 13:49:04 --> URI Class Initialized
DEBUG - 2016-06-10 13:49:04 --> No URI present. Default controller set.
INFO - 2016-06-10 13:49:04 --> Router Class Initialized
INFO - 2016-06-10 13:49:04 --> Output Class Initialized
INFO - 2016-06-10 13:49:04 --> Security Class Initialized
DEBUG - 2016-06-10 13:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:49:04 --> Input Class Initialized
INFO - 2016-06-10 13:49:04 --> Language Class Initialized
INFO - 2016-06-10 13:49:04 --> Loader Class Initialized
INFO - 2016-06-10 13:49:04 --> Helper loaded: form_helper
INFO - 2016-06-10 13:49:04 --> Database Driver Class Initialized
INFO - 2016-06-10 13:49:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:49:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:49:04 --> Email Class Initialized
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:49:04 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:49:04 --> Helper loaded: language_helper
INFO - 2016-06-10 13:49:04 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:49:04 --> Model Class Initialized
INFO - 2016-06-10 13:49:04 --> Helper loaded: date_helper
INFO - 2016-06-10 13:49:04 --> Controller Class Initialized
INFO - 2016-06-10 13:49:04 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 13:49:04 --> Config Class Initialized
INFO - 2016-06-10 13:49:04 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:49:04 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:49:04 --> Utf8 Class Initialized
INFO - 2016-06-10 13:49:04 --> URI Class Initialized
INFO - 2016-06-10 13:49:04 --> Router Class Initialized
INFO - 2016-06-10 13:49:04 --> Output Class Initialized
INFO - 2016-06-10 13:49:04 --> Security Class Initialized
DEBUG - 2016-06-10 13:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:49:04 --> Input Class Initialized
INFO - 2016-06-10 13:49:04 --> Language Class Initialized
INFO - 2016-06-10 13:49:04 --> Loader Class Initialized
INFO - 2016-06-10 13:49:04 --> Helper loaded: form_helper
INFO - 2016-06-10 13:49:04 --> Database Driver Class Initialized
INFO - 2016-06-10 13:49:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:49:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:49:04 --> Email Class Initialized
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:49:04 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:49:04 --> Helper loaded: language_helper
INFO - 2016-06-10 13:49:04 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:49:04 --> Model Class Initialized
INFO - 2016-06-10 13:49:04 --> Helper loaded: date_helper
INFO - 2016-06-10 13:49:04 --> Controller Class Initialized
INFO - 2016-06-10 13:49:04 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:49:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 13:49:04 --> Model Class Initialized
INFO - 2016-06-10 13:49:04 --> Form Validation Class Initialized
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 13:49:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 13:49:04 --> Final output sent to browser
DEBUG - 2016-06-10 13:49:04 --> Total execution time: 0.1102
INFO - 2016-06-10 13:49:09 --> Config Class Initialized
INFO - 2016-06-10 13:49:09 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:49:09 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:49:09 --> Utf8 Class Initialized
INFO - 2016-06-10 13:49:09 --> URI Class Initialized
INFO - 2016-06-10 13:49:09 --> Router Class Initialized
INFO - 2016-06-10 13:49:09 --> Output Class Initialized
INFO - 2016-06-10 13:49:09 --> Security Class Initialized
DEBUG - 2016-06-10 13:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:49:09 --> Input Class Initialized
INFO - 2016-06-10 13:49:09 --> Language Class Initialized
INFO - 2016-06-10 13:49:09 --> Loader Class Initialized
INFO - 2016-06-10 13:49:09 --> Helper loaded: form_helper
INFO - 2016-06-10 13:49:09 --> Database Driver Class Initialized
INFO - 2016-06-10 13:49:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:49:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:49:09 --> Email Class Initialized
INFO - 2016-06-10 13:49:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:49:09 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:49:09 --> Helper loaded: language_helper
INFO - 2016-06-10 13:49:09 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:49:09 --> Model Class Initialized
INFO - 2016-06-10 13:49:09 --> Helper loaded: date_helper
INFO - 2016-06-10 13:49:09 --> Controller Class Initialized
INFO - 2016-06-10 13:49:09 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:49:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:49:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:49:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:49:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:49:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 13:49:09 --> Model Class Initialized
INFO - 2016-06-10 13:49:09 --> Form Validation Class Initialized
INFO - 2016-06-10 13:49:09 --> Final output sent to browser
DEBUG - 2016-06-10 13:49:09 --> Total execution time: 0.0828
INFO - 2016-06-10 13:56:20 --> Config Class Initialized
INFO - 2016-06-10 13:56:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:56:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:56:20 --> Utf8 Class Initialized
INFO - 2016-06-10 13:56:20 --> URI Class Initialized
INFO - 2016-06-10 13:56:20 --> Router Class Initialized
INFO - 2016-06-10 13:56:20 --> Output Class Initialized
INFO - 2016-06-10 13:56:20 --> Security Class Initialized
DEBUG - 2016-06-10 13:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:56:20 --> Input Class Initialized
INFO - 2016-06-10 13:56:20 --> Language Class Initialized
INFO - 2016-06-10 13:56:20 --> Loader Class Initialized
INFO - 2016-06-10 13:56:20 --> Helper loaded: form_helper
INFO - 2016-06-10 13:56:20 --> Database Driver Class Initialized
INFO - 2016-06-10 13:56:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:56:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:56:20 --> Email Class Initialized
INFO - 2016-06-10 13:56:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:56:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:56:20 --> Helper loaded: language_helper
INFO - 2016-06-10 13:56:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:56:20 --> Model Class Initialized
INFO - 2016-06-10 13:56:20 --> Helper loaded: date_helper
INFO - 2016-06-10 13:56:20 --> Controller Class Initialized
INFO - 2016-06-10 13:56:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:56:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:56:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:56:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:56:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:56:20 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 13:56:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:56:20 --> Form Validation Class Initialized
INFO - 2016-06-10 13:56:24 --> Config Class Initialized
INFO - 2016-06-10 13:56:24 --> Hooks Class Initialized
DEBUG - 2016-06-10 13:56:24 --> UTF-8 Support Enabled
INFO - 2016-06-10 13:56:24 --> Utf8 Class Initialized
INFO - 2016-06-10 13:56:24 --> URI Class Initialized
INFO - 2016-06-10 13:56:24 --> Router Class Initialized
INFO - 2016-06-10 13:56:24 --> Output Class Initialized
INFO - 2016-06-10 13:56:24 --> Security Class Initialized
DEBUG - 2016-06-10 13:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 13:56:24 --> Input Class Initialized
INFO - 2016-06-10 13:56:24 --> Language Class Initialized
INFO - 2016-06-10 13:56:24 --> Loader Class Initialized
INFO - 2016-06-10 13:56:24 --> Helper loaded: form_helper
INFO - 2016-06-10 13:56:24 --> Database Driver Class Initialized
INFO - 2016-06-10 13:56:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 13:56:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 13:56:24 --> Email Class Initialized
INFO - 2016-06-10 13:56:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 13:56:24 --> Helper loaded: cookie_helper
INFO - 2016-06-10 13:56:24 --> Helper loaded: language_helper
INFO - 2016-06-10 13:56:24 --> Helper loaded: url_helper
DEBUG - 2016-06-10 13:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:56:24 --> Model Class Initialized
INFO - 2016-06-10 13:56:24 --> Helper loaded: date_helper
INFO - 2016-06-10 13:56:24 --> Controller Class Initialized
INFO - 2016-06-10 13:56:24 --> Helper loaded: languages_helper
INFO - 2016-06-10 13:56:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 13:56:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 13:56:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 13:56:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 13:56:24 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 13:56:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:56:24 --> Form Validation Class Initialized
DEBUG - 2016-06-10 13:56:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 13:56:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 13:56:24 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 13:56:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 13:56:24 --> Final output sent to browser
DEBUG - 2016-06-10 13:56:24 --> Total execution time: 0.0192
INFO - 2016-06-10 14:01:38 --> Config Class Initialized
INFO - 2016-06-10 14:01:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:01:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:01:38 --> Utf8 Class Initialized
INFO - 2016-06-10 14:01:38 --> URI Class Initialized
INFO - 2016-06-10 14:01:38 --> Router Class Initialized
INFO - 2016-06-10 14:01:38 --> Output Class Initialized
INFO - 2016-06-10 14:01:38 --> Security Class Initialized
DEBUG - 2016-06-10 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:01:38 --> Input Class Initialized
INFO - 2016-06-10 14:01:38 --> Language Class Initialized
INFO - 2016-06-10 14:01:38 --> Loader Class Initialized
INFO - 2016-06-10 14:01:38 --> Helper loaded: form_helper
INFO - 2016-06-10 14:01:38 --> Database Driver Class Initialized
INFO - 2016-06-10 14:01:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:01:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:01:38 --> Email Class Initialized
INFO - 2016-06-10 14:01:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:01:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:01:38 --> Helper loaded: language_helper
INFO - 2016-06-10 14:01:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:01:38 --> Model Class Initialized
INFO - 2016-06-10 14:01:38 --> Helper loaded: date_helper
INFO - 2016-06-10 14:01:38 --> Controller Class Initialized
INFO - 2016-06-10 14:01:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:01:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:01:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:01:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:01:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:01:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:01:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:01:38 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:01:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:01:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:01:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:01:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:01:38 --> Final output sent to browser
DEBUG - 2016-06-10 14:01:38 --> Total execution time: 0.0743
INFO - 2016-06-10 14:02:03 --> Config Class Initialized
INFO - 2016-06-10 14:02:03 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:02:03 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:02:03 --> Utf8 Class Initialized
INFO - 2016-06-10 14:02:03 --> URI Class Initialized
INFO - 2016-06-10 14:02:03 --> Router Class Initialized
INFO - 2016-06-10 14:02:03 --> Output Class Initialized
INFO - 2016-06-10 14:02:03 --> Security Class Initialized
DEBUG - 2016-06-10 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:02:03 --> Input Class Initialized
INFO - 2016-06-10 14:02:03 --> Language Class Initialized
INFO - 2016-06-10 14:02:03 --> Loader Class Initialized
INFO - 2016-06-10 14:02:03 --> Helper loaded: form_helper
INFO - 2016-06-10 14:02:03 --> Database Driver Class Initialized
INFO - 2016-06-10 14:02:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:02:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:02:03 --> Email Class Initialized
INFO - 2016-06-10 14:02:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:02:03 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:02:03 --> Helper loaded: language_helper
INFO - 2016-06-10 14:02:03 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:02:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:02:03 --> Model Class Initialized
INFO - 2016-06-10 14:02:03 --> Helper loaded: date_helper
INFO - 2016-06-10 14:02:03 --> Controller Class Initialized
INFO - 2016-06-10 14:02:03 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:02:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:02:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:02:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:02:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:02:03 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:02:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:02:03 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:02:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:02:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:02:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:02:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:02:03 --> Final output sent to browser
DEBUG - 2016-06-10 14:02:03 --> Total execution time: 0.0452
INFO - 2016-06-10 14:02:30 --> Config Class Initialized
INFO - 2016-06-10 14:02:30 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:02:30 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:02:30 --> Utf8 Class Initialized
INFO - 2016-06-10 14:02:30 --> URI Class Initialized
INFO - 2016-06-10 14:02:30 --> Router Class Initialized
INFO - 2016-06-10 14:02:30 --> Output Class Initialized
INFO - 2016-06-10 14:02:30 --> Security Class Initialized
DEBUG - 2016-06-10 14:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:02:30 --> Input Class Initialized
INFO - 2016-06-10 14:02:30 --> Language Class Initialized
INFO - 2016-06-10 14:02:30 --> Loader Class Initialized
INFO - 2016-06-10 14:02:30 --> Helper loaded: form_helper
INFO - 2016-06-10 14:02:30 --> Database Driver Class Initialized
INFO - 2016-06-10 14:02:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:02:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:02:30 --> Email Class Initialized
INFO - 2016-06-10 14:02:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:02:30 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:02:30 --> Helper loaded: language_helper
INFO - 2016-06-10 14:02:30 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:02:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:02:30 --> Model Class Initialized
INFO - 2016-06-10 14:02:30 --> Helper loaded: date_helper
INFO - 2016-06-10 14:02:30 --> Controller Class Initialized
INFO - 2016-06-10 14:02:30 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:02:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:02:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:02:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:02:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:02:30 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:02:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:02:30 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:02:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:02:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:02:30 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:02:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:02:30 --> Final output sent to browser
DEBUG - 2016-06-10 14:02:30 --> Total execution time: 0.0380
INFO - 2016-06-10 14:03:50 --> Config Class Initialized
INFO - 2016-06-10 14:03:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:03:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:03:50 --> Utf8 Class Initialized
INFO - 2016-06-10 14:03:50 --> URI Class Initialized
INFO - 2016-06-10 14:03:50 --> Router Class Initialized
INFO - 2016-06-10 14:03:50 --> Output Class Initialized
INFO - 2016-06-10 14:03:50 --> Security Class Initialized
DEBUG - 2016-06-10 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:03:50 --> Input Class Initialized
INFO - 2016-06-10 14:03:50 --> Language Class Initialized
INFO - 2016-06-10 14:03:50 --> Loader Class Initialized
INFO - 2016-06-10 14:03:50 --> Helper loaded: form_helper
INFO - 2016-06-10 14:03:50 --> Database Driver Class Initialized
INFO - 2016-06-10 14:03:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:03:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:03:50 --> Email Class Initialized
INFO - 2016-06-10 14:03:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:03:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:03:50 --> Helper loaded: language_helper
INFO - 2016-06-10 14:03:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:03:50 --> Model Class Initialized
INFO - 2016-06-10 14:03:50 --> Helper loaded: date_helper
INFO - 2016-06-10 14:03:50 --> Controller Class Initialized
INFO - 2016-06-10 14:03:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:03:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:03:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:03:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:03:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:03:50 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:03:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:03:50 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:03:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:03:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:03:50 --> Final output sent to browser
DEBUG - 2016-06-10 14:03:50 --> Total execution time: 0.0437
INFO - 2016-06-10 14:04:18 --> Config Class Initialized
INFO - 2016-06-10 14:04:18 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:04:18 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:04:18 --> Utf8 Class Initialized
INFO - 2016-06-10 14:04:18 --> URI Class Initialized
INFO - 2016-06-10 14:04:18 --> Router Class Initialized
INFO - 2016-06-10 14:04:18 --> Output Class Initialized
INFO - 2016-06-10 14:04:18 --> Security Class Initialized
DEBUG - 2016-06-10 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:04:18 --> Input Class Initialized
INFO - 2016-06-10 14:04:18 --> Language Class Initialized
INFO - 2016-06-10 14:04:18 --> Loader Class Initialized
INFO - 2016-06-10 14:04:18 --> Helper loaded: form_helper
INFO - 2016-06-10 14:04:18 --> Database Driver Class Initialized
INFO - 2016-06-10 14:04:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:04:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:04:18 --> Email Class Initialized
INFO - 2016-06-10 14:04:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:04:18 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:04:18 --> Helper loaded: language_helper
INFO - 2016-06-10 14:04:18 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:04:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:18 --> Model Class Initialized
INFO - 2016-06-10 14:04:18 --> Helper loaded: date_helper
INFO - 2016-06-10 14:04:18 --> Controller Class Initialized
INFO - 2016-06-10 14:04:18 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:04:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:04:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:04:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:04:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:04:18 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:04:18 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:18 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:04:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:04:18 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:04:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:04:18 --> Final output sent to browser
DEBUG - 2016-06-10 14:04:18 --> Total execution time: 0.0344
INFO - 2016-06-10 14:04:29 --> Config Class Initialized
INFO - 2016-06-10 14:04:29 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:04:29 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:04:29 --> Utf8 Class Initialized
INFO - 2016-06-10 14:04:29 --> URI Class Initialized
INFO - 2016-06-10 14:04:29 --> Router Class Initialized
INFO - 2016-06-10 14:04:29 --> Output Class Initialized
INFO - 2016-06-10 14:04:29 --> Security Class Initialized
DEBUG - 2016-06-10 14:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:04:29 --> Input Class Initialized
INFO - 2016-06-10 14:04:29 --> Language Class Initialized
INFO - 2016-06-10 14:04:29 --> Loader Class Initialized
INFO - 2016-06-10 14:04:29 --> Helper loaded: form_helper
INFO - 2016-06-10 14:04:29 --> Database Driver Class Initialized
INFO - 2016-06-10 14:04:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:04:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:04:29 --> Email Class Initialized
INFO - 2016-06-10 14:04:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:04:29 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:04:29 --> Helper loaded: language_helper
INFO - 2016-06-10 14:04:29 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:29 --> Model Class Initialized
INFO - 2016-06-10 14:04:29 --> Helper loaded: date_helper
INFO - 2016-06-10 14:04:29 --> Controller Class Initialized
INFO - 2016-06-10 14:04:29 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:04:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:04:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:04:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:04:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:04:29 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:04:29 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:29 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:04:29 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:04:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:04:29 --> Final output sent to browser
DEBUG - 2016-06-10 14:04:29 --> Total execution time: 0.0623
INFO - 2016-06-10 14:04:57 --> Config Class Initialized
INFO - 2016-06-10 14:04:57 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:04:57 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:04:57 --> Utf8 Class Initialized
INFO - 2016-06-10 14:04:57 --> URI Class Initialized
INFO - 2016-06-10 14:04:57 --> Router Class Initialized
INFO - 2016-06-10 14:04:57 --> Output Class Initialized
INFO - 2016-06-10 14:04:57 --> Security Class Initialized
DEBUG - 2016-06-10 14:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:04:57 --> Input Class Initialized
INFO - 2016-06-10 14:04:57 --> Language Class Initialized
INFO - 2016-06-10 14:04:57 --> Loader Class Initialized
INFO - 2016-06-10 14:04:57 --> Helper loaded: form_helper
INFO - 2016-06-10 14:04:57 --> Database Driver Class Initialized
INFO - 2016-06-10 14:04:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:04:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:04:57 --> Email Class Initialized
INFO - 2016-06-10 14:04:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:04:57 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:04:57 --> Helper loaded: language_helper
INFO - 2016-06-10 14:04:57 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:04:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:57 --> Model Class Initialized
INFO - 2016-06-10 14:04:57 --> Helper loaded: date_helper
INFO - 2016-06-10 14:04:57 --> Controller Class Initialized
INFO - 2016-06-10 14:04:57 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:04:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:04:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:04:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:04:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:04:57 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:04:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:57 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:04:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:04:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:04:57 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:04:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:04:57 --> Final output sent to browser
DEBUG - 2016-06-10 14:04:57 --> Total execution time: 0.0439
INFO - 2016-06-10 14:05:32 --> Config Class Initialized
INFO - 2016-06-10 14:05:32 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:05:32 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:05:32 --> Utf8 Class Initialized
INFO - 2016-06-10 14:05:32 --> URI Class Initialized
INFO - 2016-06-10 14:05:32 --> Router Class Initialized
INFO - 2016-06-10 14:05:32 --> Output Class Initialized
INFO - 2016-06-10 14:05:32 --> Security Class Initialized
DEBUG - 2016-06-10 14:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:05:32 --> Input Class Initialized
INFO - 2016-06-10 14:05:32 --> Language Class Initialized
INFO - 2016-06-10 14:05:32 --> Loader Class Initialized
INFO - 2016-06-10 14:05:32 --> Helper loaded: form_helper
INFO - 2016-06-10 14:05:32 --> Database Driver Class Initialized
INFO - 2016-06-10 14:05:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:05:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:05:32 --> Email Class Initialized
INFO - 2016-06-10 14:05:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:05:32 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:05:32 --> Helper loaded: language_helper
INFO - 2016-06-10 14:05:32 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:05:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:05:32 --> Model Class Initialized
INFO - 2016-06-10 14:05:32 --> Helper loaded: date_helper
INFO - 2016-06-10 14:05:32 --> Controller Class Initialized
INFO - 2016-06-10 14:05:32 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:05:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:05:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:05:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:05:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:05:32 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:05:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:05:32 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:05:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:05:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:05:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:05:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:05:32 --> Final output sent to browser
DEBUG - 2016-06-10 14:05:32 --> Total execution time: 0.1105
INFO - 2016-06-10 14:06:32 --> Config Class Initialized
INFO - 2016-06-10 14:06:32 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:06:32 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:06:32 --> Utf8 Class Initialized
INFO - 2016-06-10 14:06:32 --> URI Class Initialized
INFO - 2016-06-10 14:06:32 --> Router Class Initialized
INFO - 2016-06-10 14:06:32 --> Output Class Initialized
INFO - 2016-06-10 14:06:32 --> Security Class Initialized
DEBUG - 2016-06-10 14:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:06:32 --> Input Class Initialized
INFO - 2016-06-10 14:06:32 --> Language Class Initialized
INFO - 2016-06-10 14:06:32 --> Loader Class Initialized
INFO - 2016-06-10 14:06:32 --> Helper loaded: form_helper
INFO - 2016-06-10 14:06:32 --> Database Driver Class Initialized
INFO - 2016-06-10 14:06:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:06:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:06:32 --> Email Class Initialized
INFO - 2016-06-10 14:06:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:06:32 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:06:32 --> Helper loaded: language_helper
INFO - 2016-06-10 14:06:32 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:06:32 --> Model Class Initialized
INFO - 2016-06-10 14:06:32 --> Helper loaded: date_helper
INFO - 2016-06-10 14:06:32 --> Controller Class Initialized
INFO - 2016-06-10 14:06:32 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:06:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:06:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:06:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:06:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:06:32 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:06:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:06:32 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:06:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:06:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:06:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:06:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:06:32 --> Final output sent to browser
DEBUG - 2016-06-10 14:06:32 --> Total execution time: 0.0472
INFO - 2016-06-10 14:07:36 --> Config Class Initialized
INFO - 2016-06-10 14:07:36 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:07:36 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:07:36 --> Utf8 Class Initialized
INFO - 2016-06-10 14:07:36 --> URI Class Initialized
INFO - 2016-06-10 14:07:36 --> Router Class Initialized
INFO - 2016-06-10 14:07:36 --> Output Class Initialized
INFO - 2016-06-10 14:07:36 --> Security Class Initialized
DEBUG - 2016-06-10 14:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:07:36 --> Input Class Initialized
INFO - 2016-06-10 14:07:36 --> Language Class Initialized
INFO - 2016-06-10 14:07:36 --> Loader Class Initialized
INFO - 2016-06-10 14:07:36 --> Helper loaded: form_helper
INFO - 2016-06-10 14:07:36 --> Database Driver Class Initialized
INFO - 2016-06-10 14:07:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:07:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:07:36 --> Email Class Initialized
INFO - 2016-06-10 14:07:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:07:36 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:07:36 --> Helper loaded: language_helper
INFO - 2016-06-10 14:07:36 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:07:36 --> Model Class Initialized
INFO - 2016-06-10 14:07:36 --> Helper loaded: date_helper
INFO - 2016-06-10 14:07:36 --> Controller Class Initialized
INFO - 2016-06-10 14:07:36 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:07:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:07:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:07:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:07:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:07:36 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:07:36 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:07:36 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:07:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:07:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:07:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:07:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:07:36 --> Final output sent to browser
DEBUG - 2016-06-10 14:07:36 --> Total execution time: 0.0584
INFO - 2016-06-10 14:08:28 --> Config Class Initialized
INFO - 2016-06-10 14:08:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:08:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:08:28 --> Utf8 Class Initialized
INFO - 2016-06-10 14:08:28 --> URI Class Initialized
INFO - 2016-06-10 14:08:28 --> Router Class Initialized
INFO - 2016-06-10 14:08:28 --> Output Class Initialized
INFO - 2016-06-10 14:08:28 --> Security Class Initialized
DEBUG - 2016-06-10 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:08:28 --> Input Class Initialized
INFO - 2016-06-10 14:08:28 --> Language Class Initialized
INFO - 2016-06-10 14:08:28 --> Loader Class Initialized
INFO - 2016-06-10 14:08:28 --> Helper loaded: form_helper
INFO - 2016-06-10 14:08:28 --> Database Driver Class Initialized
INFO - 2016-06-10 14:08:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:08:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:08:28 --> Email Class Initialized
INFO - 2016-06-10 14:08:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:08:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:08:28 --> Helper loaded: language_helper
INFO - 2016-06-10 14:08:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:08:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:08:28 --> Model Class Initialized
INFO - 2016-06-10 14:08:28 --> Helper loaded: date_helper
INFO - 2016-06-10 14:08:28 --> Controller Class Initialized
INFO - 2016-06-10 14:08:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:08:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:08:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:08:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:08:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:08:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:08:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:08:28 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:08:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:08:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:08:28 --> Final output sent to browser
DEBUG - 2016-06-10 14:08:28 --> Total execution time: 0.0524
INFO - 2016-06-10 14:08:56 --> Config Class Initialized
INFO - 2016-06-10 14:08:56 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:08:56 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:08:56 --> Utf8 Class Initialized
INFO - 2016-06-10 14:08:56 --> URI Class Initialized
INFO - 2016-06-10 14:08:56 --> Router Class Initialized
INFO - 2016-06-10 14:08:56 --> Output Class Initialized
INFO - 2016-06-10 14:08:56 --> Security Class Initialized
DEBUG - 2016-06-10 14:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:08:56 --> Input Class Initialized
INFO - 2016-06-10 14:08:56 --> Language Class Initialized
INFO - 2016-06-10 14:08:56 --> Loader Class Initialized
INFO - 2016-06-10 14:08:56 --> Helper loaded: form_helper
INFO - 2016-06-10 14:08:56 --> Database Driver Class Initialized
INFO - 2016-06-10 14:08:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:08:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:08:56 --> Email Class Initialized
INFO - 2016-06-10 14:08:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:08:56 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:08:56 --> Helper loaded: language_helper
INFO - 2016-06-10 14:08:56 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:08:56 --> Model Class Initialized
INFO - 2016-06-10 14:08:56 --> Helper loaded: date_helper
INFO - 2016-06-10 14:08:56 --> Controller Class Initialized
INFO - 2016-06-10 14:08:56 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:08:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:08:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:08:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:08:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:08:56 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:08:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:08:56 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:08:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:08:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:08:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:08:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:08:56 --> Final output sent to browser
DEBUG - 2016-06-10 14:08:56 --> Total execution time: 0.0655
INFO - 2016-06-10 14:10:12 --> Config Class Initialized
INFO - 2016-06-10 14:10:12 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:10:12 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:10:12 --> Utf8 Class Initialized
INFO - 2016-06-10 14:10:12 --> URI Class Initialized
INFO - 2016-06-10 14:10:12 --> Router Class Initialized
INFO - 2016-06-10 14:10:12 --> Output Class Initialized
INFO - 2016-06-10 14:10:12 --> Security Class Initialized
DEBUG - 2016-06-10 14:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:10:12 --> Input Class Initialized
INFO - 2016-06-10 14:10:12 --> Language Class Initialized
INFO - 2016-06-10 14:10:12 --> Loader Class Initialized
INFO - 2016-06-10 14:10:12 --> Helper loaded: form_helper
INFO - 2016-06-10 14:10:12 --> Database Driver Class Initialized
INFO - 2016-06-10 14:10:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:10:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:10:12 --> Email Class Initialized
INFO - 2016-06-10 14:10:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:10:12 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:10:12 --> Helper loaded: language_helper
INFO - 2016-06-10 14:10:12 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:10:12 --> Model Class Initialized
INFO - 2016-06-10 14:10:12 --> Helper loaded: date_helper
INFO - 2016-06-10 14:10:12 --> Controller Class Initialized
INFO - 2016-06-10 14:10:12 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:10:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:10:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:10:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:10:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:10:12 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:10:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:10:12 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:10:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:10:12 --> Final output sent to browser
DEBUG - 2016-06-10 14:10:12 --> Total execution time: 0.0641
INFO - 2016-06-10 14:10:56 --> Config Class Initialized
INFO - 2016-06-10 14:10:56 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:10:56 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:10:56 --> Utf8 Class Initialized
INFO - 2016-06-10 14:10:56 --> URI Class Initialized
INFO - 2016-06-10 14:10:56 --> Router Class Initialized
INFO - 2016-06-10 14:10:56 --> Output Class Initialized
INFO - 2016-06-10 14:10:56 --> Security Class Initialized
DEBUG - 2016-06-10 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:10:56 --> Input Class Initialized
INFO - 2016-06-10 14:10:56 --> Language Class Initialized
INFO - 2016-06-10 14:10:56 --> Loader Class Initialized
INFO - 2016-06-10 14:10:56 --> Helper loaded: form_helper
INFO - 2016-06-10 14:10:56 --> Database Driver Class Initialized
INFO - 2016-06-10 14:10:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:10:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:10:56 --> Email Class Initialized
INFO - 2016-06-10 14:10:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:10:56 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:10:56 --> Helper loaded: language_helper
INFO - 2016-06-10 14:10:56 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:10:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:10:56 --> Model Class Initialized
INFO - 2016-06-10 14:10:56 --> Helper loaded: date_helper
INFO - 2016-06-10 14:10:56 --> Controller Class Initialized
INFO - 2016-06-10 14:10:56 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:10:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:10:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:10:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:10:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:10:56 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:10:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:10:56 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:10:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:10:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:10:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:10:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:10:56 --> Final output sent to browser
DEBUG - 2016-06-10 14:10:56 --> Total execution time: 0.0443
INFO - 2016-06-10 14:17:13 --> Config Class Initialized
INFO - 2016-06-10 14:17:13 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:17:13 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:17:13 --> Utf8 Class Initialized
INFO - 2016-06-10 14:17:13 --> URI Class Initialized
INFO - 2016-06-10 14:17:13 --> Router Class Initialized
INFO - 2016-06-10 14:17:13 --> Output Class Initialized
INFO - 2016-06-10 14:17:13 --> Security Class Initialized
DEBUG - 2016-06-10 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:17:13 --> Input Class Initialized
INFO - 2016-06-10 14:17:13 --> Language Class Initialized
INFO - 2016-06-10 14:17:13 --> Loader Class Initialized
INFO - 2016-06-10 14:17:13 --> Helper loaded: form_helper
INFO - 2016-06-10 14:17:13 --> Database Driver Class Initialized
INFO - 2016-06-10 14:17:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:17:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:17:13 --> Email Class Initialized
INFO - 2016-06-10 14:17:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:17:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:17:13 --> Helper loaded: language_helper
INFO - 2016-06-10 14:17:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:17:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:17:13 --> Model Class Initialized
INFO - 2016-06-10 14:17:13 --> Helper loaded: date_helper
INFO - 2016-06-10 14:17:13 --> Controller Class Initialized
INFO - 2016-06-10 14:17:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:17:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:17:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:17:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:17:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:17:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:17:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:17:13 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:17:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:17:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:17:13 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:17:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:17:13 --> Final output sent to browser
DEBUG - 2016-06-10 14:17:13 --> Total execution time: 0.0402
INFO - 2016-06-10 14:17:54 --> Config Class Initialized
INFO - 2016-06-10 14:17:54 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:17:54 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:17:54 --> Utf8 Class Initialized
INFO - 2016-06-10 14:17:54 --> URI Class Initialized
INFO - 2016-06-10 14:17:54 --> Router Class Initialized
INFO - 2016-06-10 14:17:54 --> Output Class Initialized
INFO - 2016-06-10 14:17:54 --> Security Class Initialized
DEBUG - 2016-06-10 14:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:17:54 --> Input Class Initialized
INFO - 2016-06-10 14:17:54 --> Language Class Initialized
INFO - 2016-06-10 14:17:54 --> Loader Class Initialized
INFO - 2016-06-10 14:17:54 --> Helper loaded: form_helper
INFO - 2016-06-10 14:17:54 --> Database Driver Class Initialized
INFO - 2016-06-10 14:17:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:17:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:17:54 --> Email Class Initialized
INFO - 2016-06-10 14:17:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:17:54 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:17:54 --> Helper loaded: language_helper
INFO - 2016-06-10 14:17:54 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:17:54 --> Model Class Initialized
INFO - 2016-06-10 14:17:54 --> Helper loaded: date_helper
INFO - 2016-06-10 14:17:54 --> Controller Class Initialized
INFO - 2016-06-10 14:17:54 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:17:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:17:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:17:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:17:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:17:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:17:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:17:54 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:17:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:17:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:17:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:17:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:17:54 --> Final output sent to browser
DEBUG - 2016-06-10 14:17:54 --> Total execution time: 0.0526
INFO - 2016-06-10 14:19:46 --> Config Class Initialized
INFO - 2016-06-10 14:19:46 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:19:46 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:19:46 --> Utf8 Class Initialized
INFO - 2016-06-10 14:19:46 --> URI Class Initialized
INFO - 2016-06-10 14:19:46 --> Router Class Initialized
INFO - 2016-06-10 14:19:46 --> Output Class Initialized
INFO - 2016-06-10 14:19:46 --> Security Class Initialized
DEBUG - 2016-06-10 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:19:46 --> Input Class Initialized
INFO - 2016-06-10 14:19:46 --> Language Class Initialized
INFO - 2016-06-10 14:19:46 --> Loader Class Initialized
INFO - 2016-06-10 14:19:46 --> Helper loaded: form_helper
INFO - 2016-06-10 14:19:46 --> Database Driver Class Initialized
INFO - 2016-06-10 14:19:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:19:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:19:46 --> Email Class Initialized
INFO - 2016-06-10 14:19:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:19:46 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:19:46 --> Helper loaded: language_helper
INFO - 2016-06-10 14:19:46 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:19:46 --> Model Class Initialized
INFO - 2016-06-10 14:19:46 --> Helper loaded: date_helper
INFO - 2016-06-10 14:19:46 --> Controller Class Initialized
INFO - 2016-06-10 14:19:46 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:19:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:19:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:19:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:19:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:19:46 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:19:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:19:46 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:19:46 --> Final output sent to browser
DEBUG - 2016-06-10 14:19:46 --> Total execution time: 0.0486
INFO - 2016-06-10 14:21:11 --> Config Class Initialized
INFO - 2016-06-10 14:21:11 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:21:11 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:21:11 --> Utf8 Class Initialized
INFO - 2016-06-10 14:21:11 --> URI Class Initialized
INFO - 2016-06-10 14:21:11 --> Router Class Initialized
INFO - 2016-06-10 14:21:11 --> Output Class Initialized
INFO - 2016-06-10 14:21:11 --> Security Class Initialized
DEBUG - 2016-06-10 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:21:11 --> Input Class Initialized
INFO - 2016-06-10 14:21:11 --> Language Class Initialized
INFO - 2016-06-10 14:21:11 --> Loader Class Initialized
INFO - 2016-06-10 14:21:11 --> Helper loaded: form_helper
INFO - 2016-06-10 14:21:11 --> Database Driver Class Initialized
INFO - 2016-06-10 14:21:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:21:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:21:11 --> Email Class Initialized
INFO - 2016-06-10 14:21:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:21:11 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:21:11 --> Helper loaded: language_helper
INFO - 2016-06-10 14:21:11 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:11 --> Model Class Initialized
INFO - 2016-06-10 14:21:11 --> Helper loaded: date_helper
INFO - 2016-06-10 14:21:11 --> Controller Class Initialized
INFO - 2016-06-10 14:21:11 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:21:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:21:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:21:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:21:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:21:11 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:21:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:11 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:21:11 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:21:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:21:11 --> Final output sent to browser
DEBUG - 2016-06-10 14:21:11 --> Total execution time: 0.0336
INFO - 2016-06-10 14:21:39 --> Config Class Initialized
INFO - 2016-06-10 14:21:39 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:21:39 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:21:39 --> Utf8 Class Initialized
INFO - 2016-06-10 14:21:39 --> URI Class Initialized
INFO - 2016-06-10 14:21:39 --> Router Class Initialized
INFO - 2016-06-10 14:21:39 --> Output Class Initialized
INFO - 2016-06-10 14:21:39 --> Security Class Initialized
DEBUG - 2016-06-10 14:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:21:39 --> Input Class Initialized
INFO - 2016-06-10 14:21:39 --> Language Class Initialized
INFO - 2016-06-10 14:21:39 --> Loader Class Initialized
INFO - 2016-06-10 14:21:39 --> Helper loaded: form_helper
INFO - 2016-06-10 14:21:39 --> Database Driver Class Initialized
INFO - 2016-06-10 14:21:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:21:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:21:39 --> Email Class Initialized
INFO - 2016-06-10 14:21:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:21:39 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:21:39 --> Helper loaded: language_helper
INFO - 2016-06-10 14:21:39 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:39 --> Model Class Initialized
INFO - 2016-06-10 14:21:39 --> Helper loaded: date_helper
INFO - 2016-06-10 14:21:39 --> Controller Class Initialized
INFO - 2016-06-10 14:21:39 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:21:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:21:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:21:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:21:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:21:39 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:21:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:39 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:21:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:21:39 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:21:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:21:39 --> Final output sent to browser
DEBUG - 2016-06-10 14:21:39 --> Total execution time: 0.0131
INFO - 2016-06-10 14:21:51 --> Config Class Initialized
INFO - 2016-06-10 14:21:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:21:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:21:51 --> Utf8 Class Initialized
INFO - 2016-06-10 14:21:51 --> URI Class Initialized
INFO - 2016-06-10 14:21:51 --> Router Class Initialized
INFO - 2016-06-10 14:21:51 --> Output Class Initialized
INFO - 2016-06-10 14:21:51 --> Security Class Initialized
DEBUG - 2016-06-10 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:21:51 --> Input Class Initialized
INFO - 2016-06-10 14:21:51 --> Language Class Initialized
INFO - 2016-06-10 14:21:51 --> Loader Class Initialized
INFO - 2016-06-10 14:21:51 --> Helper loaded: form_helper
INFO - 2016-06-10 14:21:51 --> Database Driver Class Initialized
INFO - 2016-06-10 14:21:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:21:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:21:51 --> Email Class Initialized
INFO - 2016-06-10 14:21:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:21:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:21:51 --> Helper loaded: language_helper
INFO - 2016-06-10 14:21:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:51 --> Model Class Initialized
INFO - 2016-06-10 14:21:51 --> Helper loaded: date_helper
INFO - 2016-06-10 14:21:51 --> Controller Class Initialized
INFO - 2016-06-10 14:21:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:21:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:21:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:21:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:21:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:21:51 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:21:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:51 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:21:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:21:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:21:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:21:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:21:51 --> Final output sent to browser
DEBUG - 2016-06-10 14:21:51 --> Total execution time: 0.0437
INFO - 2016-06-10 14:23:00 --> Config Class Initialized
INFO - 2016-06-10 14:23:00 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:23:00 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:23:00 --> Utf8 Class Initialized
INFO - 2016-06-10 14:23:00 --> URI Class Initialized
INFO - 2016-06-10 14:23:00 --> Router Class Initialized
INFO - 2016-06-10 14:23:00 --> Output Class Initialized
INFO - 2016-06-10 14:23:00 --> Security Class Initialized
DEBUG - 2016-06-10 14:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:23:00 --> Input Class Initialized
INFO - 2016-06-10 14:23:00 --> Language Class Initialized
INFO - 2016-06-10 14:23:00 --> Loader Class Initialized
INFO - 2016-06-10 14:23:00 --> Helper loaded: form_helper
INFO - 2016-06-10 14:23:00 --> Database Driver Class Initialized
INFO - 2016-06-10 14:23:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:23:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:23:00 --> Email Class Initialized
INFO - 2016-06-10 14:23:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:23:00 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:23:00 --> Helper loaded: language_helper
INFO - 2016-06-10 14:23:00 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:23:00 --> Model Class Initialized
INFO - 2016-06-10 14:23:00 --> Helper loaded: date_helper
INFO - 2016-06-10 14:23:00 --> Controller Class Initialized
INFO - 2016-06-10 14:23:00 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:23:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:23:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:23:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:23:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:23:00 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:23:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:23:00 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:23:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:23:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:23:00 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:23:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:23:00 --> Final output sent to browser
DEBUG - 2016-06-10 14:23:00 --> Total execution time: 0.0221
INFO - 2016-06-10 14:23:58 --> Config Class Initialized
INFO - 2016-06-10 14:23:58 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:23:58 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:23:58 --> Utf8 Class Initialized
INFO - 2016-06-10 14:23:58 --> URI Class Initialized
INFO - 2016-06-10 14:23:58 --> Router Class Initialized
INFO - 2016-06-10 14:23:58 --> Output Class Initialized
INFO - 2016-06-10 14:23:58 --> Security Class Initialized
DEBUG - 2016-06-10 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:23:58 --> Input Class Initialized
INFO - 2016-06-10 14:23:58 --> Language Class Initialized
INFO - 2016-06-10 14:23:58 --> Loader Class Initialized
INFO - 2016-06-10 14:23:58 --> Helper loaded: form_helper
INFO - 2016-06-10 14:23:58 --> Database Driver Class Initialized
INFO - 2016-06-10 14:23:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:23:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:23:58 --> Email Class Initialized
INFO - 2016-06-10 14:23:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:23:58 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:23:58 --> Helper loaded: language_helper
INFO - 2016-06-10 14:23:58 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:23:58 --> Model Class Initialized
INFO - 2016-06-10 14:23:58 --> Helper loaded: date_helper
INFO - 2016-06-10 14:23:58 --> Controller Class Initialized
INFO - 2016-06-10 14:23:58 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:23:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:23:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:23:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:23:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:23:58 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:23:58 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:23:58 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:23:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:23:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:23:58 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:23:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:23:58 --> Final output sent to browser
DEBUG - 2016-06-10 14:23:58 --> Total execution time: 0.0120
INFO - 2016-06-10 14:24:13 --> Config Class Initialized
INFO - 2016-06-10 14:24:13 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:24:13 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:24:13 --> Utf8 Class Initialized
INFO - 2016-06-10 14:24:13 --> URI Class Initialized
INFO - 2016-06-10 14:24:13 --> Router Class Initialized
INFO - 2016-06-10 14:24:13 --> Output Class Initialized
INFO - 2016-06-10 14:24:13 --> Security Class Initialized
DEBUG - 2016-06-10 14:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:24:13 --> Input Class Initialized
INFO - 2016-06-10 14:24:13 --> Language Class Initialized
INFO - 2016-06-10 14:24:13 --> Loader Class Initialized
INFO - 2016-06-10 14:24:13 --> Helper loaded: form_helper
INFO - 2016-06-10 14:24:13 --> Database Driver Class Initialized
INFO - 2016-06-10 14:24:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:24:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:24:13 --> Email Class Initialized
INFO - 2016-06-10 14:24:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:24:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:24:13 --> Helper loaded: language_helper
INFO - 2016-06-10 14:24:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:24:13 --> Model Class Initialized
INFO - 2016-06-10 14:24:13 --> Helper loaded: date_helper
INFO - 2016-06-10 14:24:13 --> Controller Class Initialized
INFO - 2016-06-10 14:24:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:24:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:24:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:24:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:24:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:24:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:24:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:24:13 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:24:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:24:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:24:13 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:24:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:24:13 --> Final output sent to browser
DEBUG - 2016-06-10 14:24:13 --> Total execution time: 0.0205
INFO - 2016-06-10 14:25:35 --> Config Class Initialized
INFO - 2016-06-10 14:25:35 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:25:35 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:25:35 --> Utf8 Class Initialized
INFO - 2016-06-10 14:25:35 --> URI Class Initialized
INFO - 2016-06-10 14:25:35 --> Router Class Initialized
INFO - 2016-06-10 14:25:35 --> Output Class Initialized
INFO - 2016-06-10 14:25:35 --> Security Class Initialized
DEBUG - 2016-06-10 14:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:25:35 --> Input Class Initialized
INFO - 2016-06-10 14:25:35 --> Language Class Initialized
INFO - 2016-06-10 14:25:35 --> Loader Class Initialized
INFO - 2016-06-10 14:25:35 --> Helper loaded: form_helper
INFO - 2016-06-10 14:25:35 --> Database Driver Class Initialized
INFO - 2016-06-10 14:25:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:25:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:25:35 --> Email Class Initialized
INFO - 2016-06-10 14:25:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:25:35 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:25:35 --> Helper loaded: language_helper
INFO - 2016-06-10 14:25:35 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:25:35 --> Model Class Initialized
INFO - 2016-06-10 14:25:35 --> Helper loaded: date_helper
INFO - 2016-06-10 14:25:35 --> Controller Class Initialized
INFO - 2016-06-10 14:25:35 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:25:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:25:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:25:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:25:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:25:35 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:25:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:25:35 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:25:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:25:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:25:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:25:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:25:35 --> Final output sent to browser
DEBUG - 2016-06-10 14:25:35 --> Total execution time: 0.0323
INFO - 2016-06-10 14:34:59 --> Config Class Initialized
INFO - 2016-06-10 14:34:59 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:34:59 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:34:59 --> Utf8 Class Initialized
INFO - 2016-06-10 14:34:59 --> URI Class Initialized
INFO - 2016-06-10 14:34:59 --> Router Class Initialized
INFO - 2016-06-10 14:34:59 --> Output Class Initialized
INFO - 2016-06-10 14:34:59 --> Security Class Initialized
DEBUG - 2016-06-10 14:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:34:59 --> Input Class Initialized
INFO - 2016-06-10 14:34:59 --> Language Class Initialized
INFO - 2016-06-10 14:34:59 --> Loader Class Initialized
INFO - 2016-06-10 14:34:59 --> Helper loaded: form_helper
INFO - 2016-06-10 14:34:59 --> Database Driver Class Initialized
INFO - 2016-06-10 14:34:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:34:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:34:59 --> Email Class Initialized
INFO - 2016-06-10 14:34:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:34:59 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:34:59 --> Helper loaded: language_helper
INFO - 2016-06-10 14:34:59 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:34:59 --> Model Class Initialized
INFO - 2016-06-10 14:34:59 --> Helper loaded: date_helper
INFO - 2016-06-10 14:34:59 --> Controller Class Initialized
INFO - 2016-06-10 14:34:59 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:34:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:34:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:34:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:34:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:34:59 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:34:59 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:34:59 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:34:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:34:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:34:59 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:34:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:34:59 --> Final output sent to browser
DEBUG - 2016-06-10 14:34:59 --> Total execution time: 0.0152
INFO - 2016-06-10 14:35:13 --> Config Class Initialized
INFO - 2016-06-10 14:35:13 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:35:13 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:35:13 --> Utf8 Class Initialized
INFO - 2016-06-10 14:35:13 --> URI Class Initialized
INFO - 2016-06-10 14:35:13 --> Router Class Initialized
INFO - 2016-06-10 14:35:13 --> Output Class Initialized
INFO - 2016-06-10 14:35:13 --> Security Class Initialized
DEBUG - 2016-06-10 14:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:35:13 --> Input Class Initialized
INFO - 2016-06-10 14:35:13 --> Language Class Initialized
INFO - 2016-06-10 14:35:13 --> Loader Class Initialized
INFO - 2016-06-10 14:35:13 --> Helper loaded: form_helper
INFO - 2016-06-10 14:35:13 --> Database Driver Class Initialized
INFO - 2016-06-10 14:35:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:35:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:35:13 --> Email Class Initialized
INFO - 2016-06-10 14:35:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:35:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:35:13 --> Helper loaded: language_helper
INFO - 2016-06-10 14:35:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:35:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:35:13 --> Model Class Initialized
INFO - 2016-06-10 14:35:13 --> Helper loaded: date_helper
INFO - 2016-06-10 14:35:13 --> Controller Class Initialized
INFO - 2016-06-10 14:35:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:35:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:35:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:35:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:35:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:35:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:35:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:35:13 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:35:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:35:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:35:13 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:35:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:35:13 --> Final output sent to browser
DEBUG - 2016-06-10 14:35:13 --> Total execution time: 0.0148
INFO - 2016-06-10 14:36:58 --> Config Class Initialized
INFO - 2016-06-10 14:36:58 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:36:58 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:36:58 --> Utf8 Class Initialized
INFO - 2016-06-10 14:36:58 --> URI Class Initialized
INFO - 2016-06-10 14:36:58 --> Router Class Initialized
INFO - 2016-06-10 14:36:58 --> Output Class Initialized
INFO - 2016-06-10 14:36:58 --> Security Class Initialized
DEBUG - 2016-06-10 14:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:36:58 --> Input Class Initialized
INFO - 2016-06-10 14:36:58 --> Language Class Initialized
INFO - 2016-06-10 14:36:58 --> Loader Class Initialized
INFO - 2016-06-10 14:36:58 --> Helper loaded: form_helper
INFO - 2016-06-10 14:36:58 --> Database Driver Class Initialized
INFO - 2016-06-10 14:36:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:36:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:36:58 --> Email Class Initialized
INFO - 2016-06-10 14:36:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:36:58 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:36:58 --> Helper loaded: language_helper
INFO - 2016-06-10 14:36:58 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:36:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:36:58 --> Model Class Initialized
INFO - 2016-06-10 14:36:58 --> Helper loaded: date_helper
INFO - 2016-06-10 14:36:58 --> Controller Class Initialized
INFO - 2016-06-10 14:36:58 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:36:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:36:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:36:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:36:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:36:58 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:36:58 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:36:58 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:36:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:36:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:36:58 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:36:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:36:58 --> Final output sent to browser
DEBUG - 2016-06-10 14:36:58 --> Total execution time: 0.0330
INFO - 2016-06-10 14:37:33 --> Config Class Initialized
INFO - 2016-06-10 14:37:33 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:37:33 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:37:33 --> Utf8 Class Initialized
INFO - 2016-06-10 14:37:33 --> URI Class Initialized
INFO - 2016-06-10 14:37:33 --> Router Class Initialized
INFO - 2016-06-10 14:37:33 --> Output Class Initialized
INFO - 2016-06-10 14:37:33 --> Security Class Initialized
DEBUG - 2016-06-10 14:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:37:33 --> Input Class Initialized
INFO - 2016-06-10 14:37:33 --> Language Class Initialized
INFO - 2016-06-10 14:37:33 --> Loader Class Initialized
INFO - 2016-06-10 14:37:33 --> Helper loaded: form_helper
INFO - 2016-06-10 14:37:33 --> Database Driver Class Initialized
INFO - 2016-06-10 14:37:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:37:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:37:33 --> Email Class Initialized
INFO - 2016-06-10 14:37:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:37:33 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:37:33 --> Helper loaded: language_helper
INFO - 2016-06-10 14:37:33 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:37:33 --> Model Class Initialized
INFO - 2016-06-10 14:37:33 --> Helper loaded: date_helper
INFO - 2016-06-10 14:37:33 --> Controller Class Initialized
INFO - 2016-06-10 14:37:33 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:37:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:37:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:37:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:37:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:37:33 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:37:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:37:33 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:37:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:37:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:37:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:37:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:37:33 --> Final output sent to browser
DEBUG - 2016-06-10 14:37:33 --> Total execution time: 0.0527
INFO - 2016-06-10 14:38:41 --> Config Class Initialized
INFO - 2016-06-10 14:38:41 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:38:41 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:38:41 --> Utf8 Class Initialized
INFO - 2016-06-10 14:38:41 --> URI Class Initialized
INFO - 2016-06-10 14:38:41 --> Router Class Initialized
INFO - 2016-06-10 14:38:41 --> Output Class Initialized
INFO - 2016-06-10 14:38:41 --> Security Class Initialized
DEBUG - 2016-06-10 14:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:38:41 --> Input Class Initialized
INFO - 2016-06-10 14:38:41 --> Language Class Initialized
INFO - 2016-06-10 14:38:41 --> Loader Class Initialized
INFO - 2016-06-10 14:38:41 --> Helper loaded: form_helper
INFO - 2016-06-10 14:38:41 --> Database Driver Class Initialized
INFO - 2016-06-10 14:38:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:38:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:38:41 --> Email Class Initialized
INFO - 2016-06-10 14:38:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:38:41 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:38:41 --> Helper loaded: language_helper
INFO - 2016-06-10 14:38:41 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:38:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:38:41 --> Model Class Initialized
INFO - 2016-06-10 14:38:41 --> Helper loaded: date_helper
INFO - 2016-06-10 14:38:41 --> Controller Class Initialized
INFO - 2016-06-10 14:38:41 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:38:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:38:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:38:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:38:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:38:41 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:38:41 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:38:41 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:38:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:38:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:38:41 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:38:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:38:41 --> Final output sent to browser
DEBUG - 2016-06-10 14:38:41 --> Total execution time: 0.0510
INFO - 2016-06-10 14:41:27 --> Config Class Initialized
INFO - 2016-06-10 14:41:27 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:41:27 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:41:27 --> Utf8 Class Initialized
INFO - 2016-06-10 14:41:27 --> URI Class Initialized
INFO - 2016-06-10 14:41:27 --> Router Class Initialized
INFO - 2016-06-10 14:41:27 --> Output Class Initialized
INFO - 2016-06-10 14:41:27 --> Security Class Initialized
DEBUG - 2016-06-10 14:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:41:27 --> Input Class Initialized
INFO - 2016-06-10 14:41:27 --> Language Class Initialized
INFO - 2016-06-10 14:41:27 --> Loader Class Initialized
INFO - 2016-06-10 14:41:27 --> Helper loaded: form_helper
INFO - 2016-06-10 14:41:27 --> Database Driver Class Initialized
INFO - 2016-06-10 14:41:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:41:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:41:27 --> Email Class Initialized
INFO - 2016-06-10 14:41:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:41:27 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:41:27 --> Helper loaded: language_helper
INFO - 2016-06-10 14:41:27 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:41:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:41:27 --> Model Class Initialized
INFO - 2016-06-10 14:41:27 --> Helper loaded: date_helper
INFO - 2016-06-10 14:41:27 --> Controller Class Initialized
INFO - 2016-06-10 14:41:27 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:41:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:41:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:41:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:41:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:41:27 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:41:27 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:41:27 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:41:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:41:27 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:41:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:41:27 --> Final output sent to browser
DEBUG - 2016-06-10 14:41:27 --> Total execution time: 0.0181
INFO - 2016-06-10 14:45:07 --> Config Class Initialized
INFO - 2016-06-10 14:45:07 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:45:07 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:45:07 --> Utf8 Class Initialized
INFO - 2016-06-10 14:45:07 --> URI Class Initialized
INFO - 2016-06-10 14:45:07 --> Router Class Initialized
INFO - 2016-06-10 14:45:07 --> Output Class Initialized
INFO - 2016-06-10 14:45:07 --> Security Class Initialized
DEBUG - 2016-06-10 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:45:07 --> Input Class Initialized
INFO - 2016-06-10 14:45:07 --> Language Class Initialized
INFO - 2016-06-10 14:45:07 --> Loader Class Initialized
INFO - 2016-06-10 14:45:07 --> Helper loaded: form_helper
INFO - 2016-06-10 14:45:07 --> Database Driver Class Initialized
INFO - 2016-06-10 14:45:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:45:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:45:07 --> Email Class Initialized
INFO - 2016-06-10 14:45:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:45:07 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:45:07 --> Helper loaded: language_helper
INFO - 2016-06-10 14:45:07 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:45:07 --> Model Class Initialized
INFO - 2016-06-10 14:45:07 --> Helper loaded: date_helper
INFO - 2016-06-10 14:45:07 --> Controller Class Initialized
INFO - 2016-06-10 14:45:07 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:45:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:45:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:45:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:45:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:45:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:45:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:45:07 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:45:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:45:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:45:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:45:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:45:07 --> Final output sent to browser
DEBUG - 2016-06-10 14:45:07 --> Total execution time: 0.0527
INFO - 2016-06-10 14:45:37 --> Config Class Initialized
INFO - 2016-06-10 14:45:37 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:45:37 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:45:37 --> Utf8 Class Initialized
INFO - 2016-06-10 14:45:37 --> URI Class Initialized
INFO - 2016-06-10 14:45:37 --> Router Class Initialized
INFO - 2016-06-10 14:45:37 --> Output Class Initialized
INFO - 2016-06-10 14:45:37 --> Security Class Initialized
DEBUG - 2016-06-10 14:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:45:37 --> Input Class Initialized
INFO - 2016-06-10 14:45:37 --> Language Class Initialized
INFO - 2016-06-10 14:45:37 --> Loader Class Initialized
INFO - 2016-06-10 14:45:37 --> Helper loaded: form_helper
INFO - 2016-06-10 14:45:37 --> Database Driver Class Initialized
INFO - 2016-06-10 14:45:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:45:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:45:37 --> Email Class Initialized
INFO - 2016-06-10 14:45:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:45:37 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:45:37 --> Helper loaded: language_helper
INFO - 2016-06-10 14:45:37 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:45:37 --> Model Class Initialized
INFO - 2016-06-10 14:45:37 --> Helper loaded: date_helper
INFO - 2016-06-10 14:45:37 --> Controller Class Initialized
INFO - 2016-06-10 14:45:37 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:45:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:45:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:45:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:45:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:45:37 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:45:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:45:37 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:45:37 --> Final output sent to browser
DEBUG - 2016-06-10 14:45:37 --> Total execution time: 0.0152
INFO - 2016-06-10 14:46:14 --> Config Class Initialized
INFO - 2016-06-10 14:46:14 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:46:14 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:46:14 --> Utf8 Class Initialized
INFO - 2016-06-10 14:46:14 --> URI Class Initialized
INFO - 2016-06-10 14:46:14 --> Router Class Initialized
INFO - 2016-06-10 14:46:14 --> Output Class Initialized
INFO - 2016-06-10 14:46:14 --> Security Class Initialized
DEBUG - 2016-06-10 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:46:14 --> Input Class Initialized
INFO - 2016-06-10 14:46:14 --> Language Class Initialized
INFO - 2016-06-10 14:46:14 --> Loader Class Initialized
INFO - 2016-06-10 14:46:14 --> Helper loaded: form_helper
INFO - 2016-06-10 14:46:14 --> Database Driver Class Initialized
INFO - 2016-06-10 14:46:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:46:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:46:14 --> Email Class Initialized
INFO - 2016-06-10 14:46:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:46:14 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:46:14 --> Helper loaded: language_helper
INFO - 2016-06-10 14:46:14 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:46:14 --> Model Class Initialized
INFO - 2016-06-10 14:46:14 --> Helper loaded: date_helper
INFO - 2016-06-10 14:46:14 --> Controller Class Initialized
INFO - 2016-06-10 14:46:14 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:46:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:46:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:46:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:46:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:46:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:46:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:46:14 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:46:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:46:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:46:14 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:46:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:46:14 --> Final output sent to browser
DEBUG - 2016-06-10 14:46:14 --> Total execution time: 0.0342
INFO - 2016-06-10 14:46:30 --> Config Class Initialized
INFO - 2016-06-10 14:46:30 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:46:30 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:46:30 --> Utf8 Class Initialized
INFO - 2016-06-10 14:46:30 --> URI Class Initialized
DEBUG - 2016-06-10 14:46:30 --> No URI present. Default controller set.
INFO - 2016-06-10 14:46:30 --> Router Class Initialized
INFO - 2016-06-10 14:46:30 --> Output Class Initialized
INFO - 2016-06-10 14:46:30 --> Security Class Initialized
DEBUG - 2016-06-10 14:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:46:30 --> Input Class Initialized
INFO - 2016-06-10 14:46:30 --> Language Class Initialized
INFO - 2016-06-10 14:46:30 --> Loader Class Initialized
INFO - 2016-06-10 14:46:30 --> Helper loaded: form_helper
INFO - 2016-06-10 14:46:30 --> Database Driver Class Initialized
INFO - 2016-06-10 14:46:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:46:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:46:30 --> Email Class Initialized
INFO - 2016-06-10 14:46:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:46:30 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:46:30 --> Helper loaded: language_helper
INFO - 2016-06-10 14:46:30 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:46:30 --> Model Class Initialized
INFO - 2016-06-10 14:46:30 --> Helper loaded: date_helper
INFO - 2016-06-10 14:46:30 --> Controller Class Initialized
INFO - 2016-06-10 14:46:30 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:46:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:46:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:46:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:46:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:46:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:46:30 --> Model Class Initialized
INFO - 2016-06-10 14:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 14:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:46:31 --> Final output sent to browser
DEBUG - 2016-06-10 14:46:31 --> Total execution time: 0.0629
INFO - 2016-06-10 14:47:16 --> Config Class Initialized
INFO - 2016-06-10 14:47:16 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:47:16 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:47:16 --> Utf8 Class Initialized
INFO - 2016-06-10 14:47:16 --> URI Class Initialized
DEBUG - 2016-06-10 14:47:16 --> No URI present. Default controller set.
INFO - 2016-06-10 14:47:16 --> Router Class Initialized
INFO - 2016-06-10 14:47:16 --> Output Class Initialized
INFO - 2016-06-10 14:47:16 --> Security Class Initialized
DEBUG - 2016-06-10 14:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:47:16 --> Input Class Initialized
INFO - 2016-06-10 14:47:16 --> Language Class Initialized
INFO - 2016-06-10 14:47:16 --> Loader Class Initialized
INFO - 2016-06-10 14:47:16 --> Helper loaded: form_helper
INFO - 2016-06-10 14:47:16 --> Database Driver Class Initialized
INFO - 2016-06-10 14:47:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:47:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:47:16 --> Email Class Initialized
INFO - 2016-06-10 14:47:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:47:16 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:47:16 --> Helper loaded: language_helper
INFO - 2016-06-10 14:47:16 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:47:16 --> Model Class Initialized
INFO - 2016-06-10 14:47:16 --> Helper loaded: date_helper
INFO - 2016-06-10 14:47:16 --> Controller Class Initialized
INFO - 2016-06-10 14:47:16 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:47:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:47:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:47:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:47:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:47:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:47:16 --> Model Class Initialized
INFO - 2016-06-10 14:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 14:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:47:16 --> Final output sent to browser
DEBUG - 2016-06-10 14:47:16 --> Total execution time: 0.0291
INFO - 2016-06-10 14:52:00 --> Config Class Initialized
INFO - 2016-06-10 14:52:00 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:52:00 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:52:00 --> Utf8 Class Initialized
INFO - 2016-06-10 14:52:00 --> URI Class Initialized
DEBUG - 2016-06-10 14:52:00 --> No URI present. Default controller set.
INFO - 2016-06-10 14:52:00 --> Router Class Initialized
INFO - 2016-06-10 14:52:00 --> Output Class Initialized
INFO - 2016-06-10 14:52:00 --> Security Class Initialized
DEBUG - 2016-06-10 14:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:52:00 --> Input Class Initialized
INFO - 2016-06-10 14:52:00 --> Language Class Initialized
INFO - 2016-06-10 14:52:00 --> Loader Class Initialized
INFO - 2016-06-10 14:52:00 --> Helper loaded: form_helper
INFO - 2016-06-10 14:52:00 --> Database Driver Class Initialized
INFO - 2016-06-10 14:52:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:52:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:52:00 --> Email Class Initialized
INFO - 2016-06-10 14:52:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:52:00 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:52:00 --> Helper loaded: language_helper
INFO - 2016-06-10 14:52:00 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:52:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:52:00 --> Model Class Initialized
INFO - 2016-06-10 14:52:00 --> Helper loaded: date_helper
INFO - 2016-06-10 14:52:00 --> Controller Class Initialized
INFO - 2016-06-10 14:52:00 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:52:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:52:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:52:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:52:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:52:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:52:00 --> Model Class Initialized
INFO - 2016-06-10 14:52:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
ERROR - 2016-06-10 14:52:00 --> Severity: Parsing Error --> syntax error, unexpected 'exit' (T_EXIT) /home/demis/www/platformadiabet/application/views/public/home.php 8
INFO - 2016-06-10 14:52:08 --> Config Class Initialized
INFO - 2016-06-10 14:52:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:52:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:52:08 --> Utf8 Class Initialized
INFO - 2016-06-10 14:52:08 --> URI Class Initialized
DEBUG - 2016-06-10 14:52:08 --> No URI present. Default controller set.
INFO - 2016-06-10 14:52:08 --> Router Class Initialized
INFO - 2016-06-10 14:52:08 --> Output Class Initialized
INFO - 2016-06-10 14:52:08 --> Security Class Initialized
DEBUG - 2016-06-10 14:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:52:08 --> Input Class Initialized
INFO - 2016-06-10 14:52:08 --> Language Class Initialized
INFO - 2016-06-10 14:52:08 --> Loader Class Initialized
INFO - 2016-06-10 14:52:08 --> Helper loaded: form_helper
INFO - 2016-06-10 14:52:08 --> Database Driver Class Initialized
INFO - 2016-06-10 14:52:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:52:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:52:08 --> Email Class Initialized
INFO - 2016-06-10 14:52:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:52:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:52:08 --> Helper loaded: language_helper
INFO - 2016-06-10 14:52:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:52:08 --> Model Class Initialized
INFO - 2016-06-10 14:52:08 --> Helper loaded: date_helper
INFO - 2016-06-10 14:52:08 --> Controller Class Initialized
INFO - 2016-06-10 14:52:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:52:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:52:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:52:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:52:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:52:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:52:08 --> Model Class Initialized
INFO - 2016-06-10 14:52:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
ERROR - 2016-06-10 14:52:08 --> Severity: Warning --> print_r() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/public/home.php 7
INFO - 2016-06-10 14:52:44 --> Config Class Initialized
INFO - 2016-06-10 14:52:44 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:52:44 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:52:44 --> Utf8 Class Initialized
INFO - 2016-06-10 14:52:44 --> URI Class Initialized
DEBUG - 2016-06-10 14:52:44 --> No URI present. Default controller set.
INFO - 2016-06-10 14:52:44 --> Router Class Initialized
INFO - 2016-06-10 14:52:44 --> Output Class Initialized
INFO - 2016-06-10 14:52:44 --> Security Class Initialized
DEBUG - 2016-06-10 14:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:52:44 --> Input Class Initialized
INFO - 2016-06-10 14:52:44 --> Language Class Initialized
INFO - 2016-06-10 14:52:44 --> Loader Class Initialized
INFO - 2016-06-10 14:52:44 --> Helper loaded: form_helper
INFO - 2016-06-10 14:52:44 --> Database Driver Class Initialized
INFO - 2016-06-10 14:52:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:52:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:52:44 --> Email Class Initialized
INFO - 2016-06-10 14:52:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:52:44 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:52:44 --> Helper loaded: language_helper
INFO - 2016-06-10 14:52:44 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:52:44 --> Model Class Initialized
INFO - 2016-06-10 14:52:44 --> Helper loaded: date_helper
INFO - 2016-06-10 14:52:44 --> Controller Class Initialized
INFO - 2016-06-10 14:52:44 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:52:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:52:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:52:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:52:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:52:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:52:44 --> Model Class Initialized
INFO - 2016-06-10 14:52:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:53:30 --> Config Class Initialized
INFO - 2016-06-10 14:53:30 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:53:30 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:53:30 --> Utf8 Class Initialized
INFO - 2016-06-10 14:53:30 --> URI Class Initialized
DEBUG - 2016-06-10 14:53:30 --> No URI present. Default controller set.
INFO - 2016-06-10 14:53:30 --> Router Class Initialized
INFO - 2016-06-10 14:53:30 --> Output Class Initialized
INFO - 2016-06-10 14:53:30 --> Security Class Initialized
DEBUG - 2016-06-10 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:53:30 --> Input Class Initialized
INFO - 2016-06-10 14:53:30 --> Language Class Initialized
INFO - 2016-06-10 14:53:30 --> Loader Class Initialized
INFO - 2016-06-10 14:53:30 --> Helper loaded: form_helper
INFO - 2016-06-10 14:53:30 --> Database Driver Class Initialized
INFO - 2016-06-10 14:53:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:53:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:53:30 --> Email Class Initialized
INFO - 2016-06-10 14:53:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:53:30 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:53:30 --> Helper loaded: language_helper
INFO - 2016-06-10 14:53:30 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:53:30 --> Model Class Initialized
INFO - 2016-06-10 14:53:30 --> Helper loaded: date_helper
INFO - 2016-06-10 14:53:30 --> Controller Class Initialized
INFO - 2016-06-10 14:53:30 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:53:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:53:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:53:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:53:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:53:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:53:30 --> Model Class Initialized
INFO - 2016-06-10 14:53:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:53:49 --> Config Class Initialized
INFO - 2016-06-10 14:53:49 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:53:49 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:53:49 --> Utf8 Class Initialized
INFO - 2016-06-10 14:53:49 --> URI Class Initialized
DEBUG - 2016-06-10 14:53:49 --> No URI present. Default controller set.
INFO - 2016-06-10 14:53:49 --> Router Class Initialized
INFO - 2016-06-10 14:53:49 --> Output Class Initialized
INFO - 2016-06-10 14:53:49 --> Security Class Initialized
DEBUG - 2016-06-10 14:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:53:49 --> Input Class Initialized
INFO - 2016-06-10 14:53:49 --> Language Class Initialized
INFO - 2016-06-10 14:53:49 --> Loader Class Initialized
INFO - 2016-06-10 14:53:49 --> Helper loaded: form_helper
INFO - 2016-06-10 14:53:49 --> Database Driver Class Initialized
INFO - 2016-06-10 14:53:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:53:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:53:49 --> Email Class Initialized
INFO - 2016-06-10 14:53:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:53:49 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:53:49 --> Helper loaded: language_helper
INFO - 2016-06-10 14:53:49 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:53:49 --> Model Class Initialized
INFO - 2016-06-10 14:53:49 --> Helper loaded: date_helper
INFO - 2016-06-10 14:53:49 --> Controller Class Initialized
INFO - 2016-06-10 14:53:49 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:53:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:53:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:53:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:53:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:53:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:53:49 --> Model Class Initialized
INFO - 2016-06-10 14:53:49 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:54:05 --> Config Class Initialized
INFO - 2016-06-10 14:54:05 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:54:05 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:54:05 --> Utf8 Class Initialized
INFO - 2016-06-10 14:54:05 --> URI Class Initialized
DEBUG - 2016-06-10 14:54:05 --> No URI present. Default controller set.
INFO - 2016-06-10 14:54:05 --> Router Class Initialized
INFO - 2016-06-10 14:54:05 --> Output Class Initialized
INFO - 2016-06-10 14:54:05 --> Security Class Initialized
DEBUG - 2016-06-10 14:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:54:05 --> Input Class Initialized
INFO - 2016-06-10 14:54:05 --> Language Class Initialized
INFO - 2016-06-10 14:54:05 --> Loader Class Initialized
INFO - 2016-06-10 14:54:05 --> Helper loaded: form_helper
INFO - 2016-06-10 14:54:05 --> Database Driver Class Initialized
INFO - 2016-06-10 14:54:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:54:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:54:05 --> Email Class Initialized
INFO - 2016-06-10 14:54:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:54:05 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:54:05 --> Helper loaded: language_helper
INFO - 2016-06-10 14:54:05 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:54:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:54:05 --> Model Class Initialized
INFO - 2016-06-10 14:54:05 --> Helper loaded: date_helper
INFO - 2016-06-10 14:54:05 --> Controller Class Initialized
INFO - 2016-06-10 14:54:05 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:54:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:54:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:54:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:54:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:54:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:54:05 --> Model Class Initialized
INFO - 2016-06-10 14:54:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:54:53 --> Config Class Initialized
INFO - 2016-06-10 14:54:53 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:54:53 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:54:53 --> Utf8 Class Initialized
INFO - 2016-06-10 14:54:53 --> URI Class Initialized
DEBUG - 2016-06-10 14:54:53 --> No URI present. Default controller set.
INFO - 2016-06-10 14:54:53 --> Router Class Initialized
INFO - 2016-06-10 14:54:53 --> Output Class Initialized
INFO - 2016-06-10 14:54:53 --> Security Class Initialized
DEBUG - 2016-06-10 14:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:54:53 --> Input Class Initialized
INFO - 2016-06-10 14:54:53 --> Language Class Initialized
INFO - 2016-06-10 14:54:53 --> Loader Class Initialized
INFO - 2016-06-10 14:54:53 --> Helper loaded: form_helper
INFO - 2016-06-10 14:54:53 --> Database Driver Class Initialized
INFO - 2016-06-10 14:54:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:54:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:54:53 --> Email Class Initialized
INFO - 2016-06-10 14:54:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:54:53 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:54:53 --> Helper loaded: language_helper
INFO - 2016-06-10 14:54:53 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:54:53 --> Model Class Initialized
INFO - 2016-06-10 14:54:53 --> Helper loaded: date_helper
INFO - 2016-06-10 14:54:53 --> Controller Class Initialized
INFO - 2016-06-10 14:54:53 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:54:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:54:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:54:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:54:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:54:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:54:53 --> Model Class Initialized
INFO - 2016-06-10 14:54:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:54:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 14:54:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:54:53 --> Final output sent to browser
DEBUG - 2016-06-10 14:54:53 --> Total execution time: 0.0558
INFO - 2016-06-10 14:55:02 --> Config Class Initialized
INFO - 2016-06-10 14:55:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:02 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:02 --> URI Class Initialized
INFO - 2016-06-10 14:55:02 --> Router Class Initialized
INFO - 2016-06-10 14:55:02 --> Output Class Initialized
INFO - 2016-06-10 14:55:02 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:02 --> Input Class Initialized
INFO - 2016-06-10 14:55:02 --> Language Class Initialized
INFO - 2016-06-10 14:55:02 --> Loader Class Initialized
INFO - 2016-06-10 14:55:02 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:02 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:02 --> Email Class Initialized
INFO - 2016-06-10 14:55:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:02 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:02 --> Model Class Initialized
INFO - 2016-06-10 14:55:02 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:02 --> Controller Class Initialized
INFO - 2016-06-10 14:55:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:55:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:02 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:55:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:55:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:55:02 --> Final output sent to browser
DEBUG - 2016-06-10 14:55:02 --> Total execution time: 0.0906
INFO - 2016-06-10 14:55:19 --> Config Class Initialized
INFO - 2016-06-10 14:55:19 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:19 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:19 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:19 --> URI Class Initialized
INFO - 2016-06-10 14:55:19 --> Router Class Initialized
INFO - 2016-06-10 14:55:19 --> Output Class Initialized
INFO - 2016-06-10 14:55:19 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:19 --> Input Class Initialized
INFO - 2016-06-10 14:55:19 --> Language Class Initialized
INFO - 2016-06-10 14:55:19 --> Loader Class Initialized
INFO - 2016-06-10 14:55:19 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:19 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:20 --> Email Class Initialized
INFO - 2016-06-10 14:55:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:20 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:20 --> Model Class Initialized
INFO - 2016-06-10 14:55:20 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:20 --> Controller Class Initialized
INFO - 2016-06-10 14:55:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:20 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:55:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:20 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:55:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:24 --> Config Class Initialized
INFO - 2016-06-10 14:55:24 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:24 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:24 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:24 --> URI Class Initialized
DEBUG - 2016-06-10 14:55:24 --> No URI present. Default controller set.
INFO - 2016-06-10 14:55:24 --> Router Class Initialized
INFO - 2016-06-10 14:55:24 --> Output Class Initialized
INFO - 2016-06-10 14:55:24 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:24 --> Input Class Initialized
INFO - 2016-06-10 14:55:24 --> Language Class Initialized
INFO - 2016-06-10 14:55:24 --> Loader Class Initialized
INFO - 2016-06-10 14:55:24 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:24 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:24 --> Email Class Initialized
INFO - 2016-06-10 14:55:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:24 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:24 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:24 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:24 --> Model Class Initialized
INFO - 2016-06-10 14:55:24 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:24 --> Controller Class Initialized
INFO - 2016-06-10 14:55:24 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:55:25 --> Config Class Initialized
INFO - 2016-06-10 14:55:25 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:25 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:25 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:25 --> URI Class Initialized
INFO - 2016-06-10 14:55:25 --> Router Class Initialized
INFO - 2016-06-10 14:55:25 --> Output Class Initialized
INFO - 2016-06-10 14:55:25 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:25 --> Input Class Initialized
INFO - 2016-06-10 14:55:25 --> Language Class Initialized
INFO - 2016-06-10 14:55:25 --> Loader Class Initialized
INFO - 2016-06-10 14:55:25 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:25 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:25 --> Email Class Initialized
INFO - 2016-06-10 14:55:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:25 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:25 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:25 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:25 --> Model Class Initialized
INFO - 2016-06-10 14:55:25 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:25 --> Controller Class Initialized
INFO - 2016-06-10 14:55:25 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:55:25 --> Model Class Initialized
INFO - 2016-06-10 14:55:25 --> Form Validation Class Initialized
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 14:55:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:55:25 --> Final output sent to browser
DEBUG - 2016-06-10 14:55:25 --> Total execution time: 0.1106
INFO - 2016-06-10 14:55:29 --> Config Class Initialized
INFO - 2016-06-10 14:55:29 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:29 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:29 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:29 --> URI Class Initialized
INFO - 2016-06-10 14:55:29 --> Router Class Initialized
INFO - 2016-06-10 14:55:29 --> Output Class Initialized
INFO - 2016-06-10 14:55:29 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:29 --> Input Class Initialized
INFO - 2016-06-10 14:55:29 --> Language Class Initialized
INFO - 2016-06-10 14:55:29 --> Loader Class Initialized
INFO - 2016-06-10 14:55:29 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:29 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:29 --> Email Class Initialized
INFO - 2016-06-10 14:55:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:29 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:29 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:29 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:29 --> Model Class Initialized
INFO - 2016-06-10 14:55:29 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:29 --> Controller Class Initialized
INFO - 2016-06-10 14:55:29 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:55:29 --> Model Class Initialized
INFO - 2016-06-10 14:55:29 --> Form Validation Class Initialized
INFO - 2016-06-10 14:55:29 --> Final output sent to browser
DEBUG - 2016-06-10 14:55:29 --> Total execution time: 0.0393
INFO - 2016-06-10 14:55:33 --> Config Class Initialized
INFO - 2016-06-10 14:55:33 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:33 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:33 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:33 --> URI Class Initialized
INFO - 2016-06-10 14:55:33 --> Router Class Initialized
INFO - 2016-06-10 14:55:33 --> Output Class Initialized
INFO - 2016-06-10 14:55:33 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:33 --> Input Class Initialized
INFO - 2016-06-10 14:55:33 --> Language Class Initialized
INFO - 2016-06-10 14:55:33 --> Loader Class Initialized
INFO - 2016-06-10 14:55:33 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:33 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:33 --> Email Class Initialized
INFO - 2016-06-10 14:55:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:33 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:33 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:33 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:33 --> Model Class Initialized
INFO - 2016-06-10 14:55:33 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:33 --> Controller Class Initialized
INFO - 2016-06-10 14:55:33 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:33 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:55:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:33 --> Form Validation Class Initialized
INFO - 2016-06-10 14:55:38 --> Config Class Initialized
INFO - 2016-06-10 14:55:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:38 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:38 --> URI Class Initialized
INFO - 2016-06-10 14:55:38 --> Router Class Initialized
INFO - 2016-06-10 14:55:38 --> Output Class Initialized
INFO - 2016-06-10 14:55:38 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:38 --> Input Class Initialized
INFO - 2016-06-10 14:55:38 --> Language Class Initialized
INFO - 2016-06-10 14:55:38 --> Loader Class Initialized
INFO - 2016-06-10 14:55:38 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:38 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:38 --> Email Class Initialized
INFO - 2016-06-10 14:55:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:38 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:38 --> Model Class Initialized
INFO - 2016-06-10 14:55:38 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:38 --> Controller Class Initialized
INFO - 2016-06-10 14:55:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:55:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:38 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:55:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 14:55:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 14:55:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 14:55:38 --> Final output sent to browser
DEBUG - 2016-06-10 14:55:38 --> Total execution time: 0.0620
INFO - 2016-06-10 14:55:57 --> Config Class Initialized
INFO - 2016-06-10 14:55:57 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:55:57 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:55:57 --> Utf8 Class Initialized
INFO - 2016-06-10 14:55:57 --> URI Class Initialized
INFO - 2016-06-10 14:55:57 --> Router Class Initialized
INFO - 2016-06-10 14:55:57 --> Output Class Initialized
INFO - 2016-06-10 14:55:57 --> Security Class Initialized
DEBUG - 2016-06-10 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:55:57 --> Input Class Initialized
INFO - 2016-06-10 14:55:57 --> Language Class Initialized
INFO - 2016-06-10 14:55:57 --> Loader Class Initialized
INFO - 2016-06-10 14:55:57 --> Helper loaded: form_helper
INFO - 2016-06-10 14:55:57 --> Database Driver Class Initialized
INFO - 2016-06-10 14:55:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:55:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:55:57 --> Email Class Initialized
INFO - 2016-06-10 14:55:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:55:57 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:55:57 --> Helper loaded: language_helper
INFO - 2016-06-10 14:55:57 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:57 --> Model Class Initialized
INFO - 2016-06-10 14:55:57 --> Helper loaded: date_helper
INFO - 2016-06-10 14:55:57 --> Controller Class Initialized
INFO - 2016-06-10 14:55:57 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:55:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:55:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:55:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:55:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:55:57 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 14:55:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:55:57 --> Form Validation Class Initialized
DEBUG - 2016-06-10 14:55:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:56:01 --> Config Class Initialized
INFO - 2016-06-10 14:56:01 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:56:01 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:56:01 --> Utf8 Class Initialized
INFO - 2016-06-10 14:56:01 --> URI Class Initialized
DEBUG - 2016-06-10 14:56:01 --> No URI present. Default controller set.
INFO - 2016-06-10 14:56:01 --> Router Class Initialized
INFO - 2016-06-10 14:56:01 --> Output Class Initialized
INFO - 2016-06-10 14:56:01 --> Security Class Initialized
DEBUG - 2016-06-10 14:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:56:01 --> Input Class Initialized
INFO - 2016-06-10 14:56:01 --> Language Class Initialized
INFO - 2016-06-10 14:56:01 --> Loader Class Initialized
INFO - 2016-06-10 14:56:01 --> Helper loaded: form_helper
INFO - 2016-06-10 14:56:01 --> Database Driver Class Initialized
INFO - 2016-06-10 14:56:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:56:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:56:01 --> Email Class Initialized
INFO - 2016-06-10 14:56:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:56:01 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:56:01 --> Helper loaded: language_helper
INFO - 2016-06-10 14:56:01 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:56:01 --> Model Class Initialized
INFO - 2016-06-10 14:56:01 --> Helper loaded: date_helper
INFO - 2016-06-10 14:56:01 --> Controller Class Initialized
INFO - 2016-06-10 14:56:01 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:56:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:56:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:56:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:56:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:56:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:56:02 --> Config Class Initialized
INFO - 2016-06-10 14:56:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:56:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:56:02 --> Utf8 Class Initialized
INFO - 2016-06-10 14:56:02 --> URI Class Initialized
INFO - 2016-06-10 14:56:02 --> Router Class Initialized
INFO - 2016-06-10 14:56:02 --> Output Class Initialized
INFO - 2016-06-10 14:56:02 --> Security Class Initialized
DEBUG - 2016-06-10 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:56:02 --> Input Class Initialized
INFO - 2016-06-10 14:56:02 --> Language Class Initialized
INFO - 2016-06-10 14:56:02 --> Loader Class Initialized
INFO - 2016-06-10 14:56:02 --> Helper loaded: form_helper
INFO - 2016-06-10 14:56:02 --> Database Driver Class Initialized
INFO - 2016-06-10 14:56:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:56:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:56:02 --> Email Class Initialized
INFO - 2016-06-10 14:56:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:56:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:56:02 --> Helper loaded: language_helper
INFO - 2016-06-10 14:56:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:56:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:56:02 --> Model Class Initialized
INFO - 2016-06-10 14:56:02 --> Helper loaded: date_helper
INFO - 2016-06-10 14:56:02 --> Controller Class Initialized
INFO - 2016-06-10 14:56:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:56:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:56:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:56:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:56:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:56:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:56:02 --> Model Class Initialized
INFO - 2016-06-10 14:56:02 --> Form Validation Class Initialized
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-10 14:56:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:56:03 --> Final output sent to browser
DEBUG - 2016-06-10 14:56:03 --> Total execution time: 1.4448
INFO - 2016-06-10 14:56:10 --> Config Class Initialized
INFO - 2016-06-10 14:56:10 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:56:10 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:56:10 --> Utf8 Class Initialized
INFO - 2016-06-10 14:56:10 --> URI Class Initialized
INFO - 2016-06-10 14:56:10 --> Router Class Initialized
INFO - 2016-06-10 14:56:10 --> Output Class Initialized
INFO - 2016-06-10 14:56:10 --> Security Class Initialized
DEBUG - 2016-06-10 14:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:56:10 --> Input Class Initialized
INFO - 2016-06-10 14:56:10 --> Language Class Initialized
INFO - 2016-06-10 14:56:10 --> Loader Class Initialized
INFO - 2016-06-10 14:56:10 --> Helper loaded: form_helper
INFO - 2016-06-10 14:56:10 --> Database Driver Class Initialized
INFO - 2016-06-10 14:56:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:56:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:56:10 --> Email Class Initialized
INFO - 2016-06-10 14:56:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:56:10 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:56:10 --> Helper loaded: language_helper
INFO - 2016-06-10 14:56:10 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:56:10 --> Model Class Initialized
INFO - 2016-06-10 14:56:10 --> Helper loaded: date_helper
INFO - 2016-06-10 14:56:10 --> Controller Class Initialized
INFO - 2016-06-10 14:56:10 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:56:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:56:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:56:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:56:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:56:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:56:10 --> Model Class Initialized
INFO - 2016-06-10 14:56:10 --> Form Validation Class Initialized
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 14:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:56:10 --> Final output sent to browser
DEBUG - 2016-06-10 14:56:10 --> Total execution time: 0.0892
INFO - 2016-06-10 14:56:20 --> Config Class Initialized
INFO - 2016-06-10 14:56:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:56:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:56:20 --> Utf8 Class Initialized
INFO - 2016-06-10 14:56:20 --> URI Class Initialized
INFO - 2016-06-10 14:56:20 --> Router Class Initialized
INFO - 2016-06-10 14:56:20 --> Output Class Initialized
INFO - 2016-06-10 14:56:20 --> Security Class Initialized
DEBUG - 2016-06-10 14:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:56:20 --> Input Class Initialized
INFO - 2016-06-10 14:56:20 --> Language Class Initialized
INFO - 2016-06-10 14:56:20 --> Loader Class Initialized
INFO - 2016-06-10 14:56:20 --> Helper loaded: form_helper
INFO - 2016-06-10 14:56:20 --> Database Driver Class Initialized
INFO - 2016-06-10 14:56:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:56:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:56:20 --> Email Class Initialized
INFO - 2016-06-10 14:56:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:56:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:56:20 --> Helper loaded: language_helper
INFO - 2016-06-10 14:56:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:56:20 --> Model Class Initialized
INFO - 2016-06-10 14:56:20 --> Helper loaded: date_helper
INFO - 2016-06-10 14:56:20 --> Controller Class Initialized
INFO - 2016-06-10 14:56:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:56:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:56:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:56:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:56:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:56:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:56:20 --> Model Class Initialized
INFO - 2016-06-10 14:56:20 --> Form Validation Class Initialized
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-10 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:56:20 --> Final output sent to browser
DEBUG - 2016-06-10 14:56:20 --> Total execution time: 0.1212
INFO - 2016-06-10 14:58:19 --> Config Class Initialized
INFO - 2016-06-10 14:58:19 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:58:19 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:58:19 --> Utf8 Class Initialized
INFO - 2016-06-10 14:58:19 --> URI Class Initialized
INFO - 2016-06-10 14:58:19 --> Router Class Initialized
INFO - 2016-06-10 14:58:19 --> Output Class Initialized
INFO - 2016-06-10 14:58:19 --> Security Class Initialized
DEBUG - 2016-06-10 14:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:58:19 --> Input Class Initialized
INFO - 2016-06-10 14:58:19 --> Language Class Initialized
INFO - 2016-06-10 14:58:19 --> Loader Class Initialized
INFO - 2016-06-10 14:58:19 --> Helper loaded: form_helper
INFO - 2016-06-10 14:58:19 --> Database Driver Class Initialized
INFO - 2016-06-10 14:58:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:58:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:58:19 --> Email Class Initialized
INFO - 2016-06-10 14:58:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:58:19 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:58:19 --> Helper loaded: language_helper
INFO - 2016-06-10 14:58:19 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:58:19 --> Model Class Initialized
INFO - 2016-06-10 14:58:19 --> Helper loaded: date_helper
INFO - 2016-06-10 14:58:19 --> Controller Class Initialized
INFO - 2016-06-10 14:58:19 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:58:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:58:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:58:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:58:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:58:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:58:19 --> Model Class Initialized
INFO - 2016-06-10 14:58:19 --> Form Validation Class Initialized
INFO - 2016-06-10 14:58:19 --> Final output sent to browser
DEBUG - 2016-06-10 14:58:19 --> Total execution time: 0.1998
INFO - 2016-06-10 14:58:20 --> Config Class Initialized
INFO - 2016-06-10 14:58:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:58:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:58:20 --> Utf8 Class Initialized
INFO - 2016-06-10 14:58:20 --> URI Class Initialized
INFO - 2016-06-10 14:58:20 --> Router Class Initialized
INFO - 2016-06-10 14:58:20 --> Output Class Initialized
INFO - 2016-06-10 14:58:20 --> Security Class Initialized
DEBUG - 2016-06-10 14:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:58:20 --> Input Class Initialized
INFO - 2016-06-10 14:58:20 --> Language Class Initialized
INFO - 2016-06-10 14:58:20 --> Loader Class Initialized
INFO - 2016-06-10 14:58:20 --> Helper loaded: form_helper
INFO - 2016-06-10 14:58:20 --> Database Driver Class Initialized
INFO - 2016-06-10 14:58:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:58:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:58:20 --> Email Class Initialized
INFO - 2016-06-10 14:58:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:58:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:58:20 --> Helper loaded: language_helper
INFO - 2016-06-10 14:58:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:58:20 --> Model Class Initialized
INFO - 2016-06-10 14:58:20 --> Helper loaded: date_helper
INFO - 2016-06-10 14:58:20 --> Controller Class Initialized
INFO - 2016-06-10 14:58:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:58:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:58:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:58:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:58:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:58:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:58:20 --> Model Class Initialized
INFO - 2016-06-10 14:58:20 --> Form Validation Class Initialized
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 14:58:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:58:20 --> Final output sent to browser
DEBUG - 2016-06-10 14:58:20 --> Total execution time: 0.1171
INFO - 2016-06-10 14:59:12 --> Config Class Initialized
INFO - 2016-06-10 14:59:12 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:59:12 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:59:12 --> Utf8 Class Initialized
INFO - 2016-06-10 14:59:12 --> URI Class Initialized
INFO - 2016-06-10 14:59:12 --> Router Class Initialized
INFO - 2016-06-10 14:59:12 --> Output Class Initialized
INFO - 2016-06-10 14:59:12 --> Security Class Initialized
DEBUG - 2016-06-10 14:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:59:12 --> Input Class Initialized
INFO - 2016-06-10 14:59:12 --> Language Class Initialized
INFO - 2016-06-10 14:59:12 --> Loader Class Initialized
INFO - 2016-06-10 14:59:12 --> Helper loaded: form_helper
INFO - 2016-06-10 14:59:12 --> Database Driver Class Initialized
INFO - 2016-06-10 14:59:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:59:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:59:12 --> Email Class Initialized
INFO - 2016-06-10 14:59:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:59:12 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:59:12 --> Helper loaded: language_helper
INFO - 2016-06-10 14:59:12 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:59:12 --> Model Class Initialized
INFO - 2016-06-10 14:59:12 --> Helper loaded: date_helper
INFO - 2016-06-10 14:59:12 --> Controller Class Initialized
INFO - 2016-06-10 14:59:12 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:59:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:59:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:59:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:59:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:59:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:59:12 --> Model Class Initialized
INFO - 2016-06-10 14:59:12 --> Form Validation Class Initialized
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-10 14:59:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:59:12 --> Final output sent to browser
DEBUG - 2016-06-10 14:59:12 --> Total execution time: 0.0565
INFO - 2016-06-10 14:59:29 --> Config Class Initialized
INFO - 2016-06-10 14:59:29 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:59:29 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:59:29 --> Utf8 Class Initialized
INFO - 2016-06-10 14:59:29 --> URI Class Initialized
INFO - 2016-06-10 14:59:29 --> Router Class Initialized
INFO - 2016-06-10 14:59:29 --> Output Class Initialized
INFO - 2016-06-10 14:59:29 --> Security Class Initialized
DEBUG - 2016-06-10 14:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:59:29 --> Input Class Initialized
INFO - 2016-06-10 14:59:29 --> Language Class Initialized
INFO - 2016-06-10 14:59:29 --> Loader Class Initialized
INFO - 2016-06-10 14:59:29 --> Helper loaded: form_helper
INFO - 2016-06-10 14:59:29 --> Database Driver Class Initialized
INFO - 2016-06-10 14:59:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:59:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:59:29 --> Email Class Initialized
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:59:29 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:59:29 --> Helper loaded: language_helper
INFO - 2016-06-10 14:59:29 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:59:29 --> Model Class Initialized
INFO - 2016-06-10 14:59:29 --> Helper loaded: date_helper
INFO - 2016-06-10 14:59:29 --> Controller Class Initialized
INFO - 2016-06-10 14:59:29 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:59:29 --> Model Class Initialized
INFO - 2016-06-10 14:59:29 --> Form Validation Class Initialized
INFO - 2016-06-10 14:59:29 --> Final output sent to browser
DEBUG - 2016-06-10 14:59:29 --> Total execution time: 0.1331
INFO - 2016-06-10 14:59:29 --> Config Class Initialized
INFO - 2016-06-10 14:59:29 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:59:29 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:59:29 --> Utf8 Class Initialized
INFO - 2016-06-10 14:59:29 --> URI Class Initialized
INFO - 2016-06-10 14:59:29 --> Router Class Initialized
INFO - 2016-06-10 14:59:29 --> Output Class Initialized
INFO - 2016-06-10 14:59:29 --> Security Class Initialized
DEBUG - 2016-06-10 14:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:59:29 --> Input Class Initialized
INFO - 2016-06-10 14:59:29 --> Language Class Initialized
INFO - 2016-06-10 14:59:29 --> Loader Class Initialized
INFO - 2016-06-10 14:59:29 --> Helper loaded: form_helper
INFO - 2016-06-10 14:59:29 --> Database Driver Class Initialized
INFO - 2016-06-10 14:59:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:59:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:59:29 --> Email Class Initialized
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:59:29 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:59:29 --> Helper loaded: language_helper
INFO - 2016-06-10 14:59:29 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:59:29 --> Model Class Initialized
INFO - 2016-06-10 14:59:29 --> Helper loaded: date_helper
INFO - 2016-06-10 14:59:29 --> Controller Class Initialized
INFO - 2016-06-10 14:59:29 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:59:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:59:29 --> Model Class Initialized
INFO - 2016-06-10 14:59:29 --> Form Validation Class Initialized
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 14:59:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:59:29 --> Final output sent to browser
DEBUG - 2016-06-10 14:59:29 --> Total execution time: 0.0708
INFO - 2016-06-10 14:59:51 --> Config Class Initialized
INFO - 2016-06-10 14:59:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 14:59:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 14:59:51 --> Utf8 Class Initialized
INFO - 2016-06-10 14:59:51 --> URI Class Initialized
INFO - 2016-06-10 14:59:51 --> Router Class Initialized
INFO - 2016-06-10 14:59:51 --> Output Class Initialized
INFO - 2016-06-10 14:59:51 --> Security Class Initialized
DEBUG - 2016-06-10 14:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 14:59:51 --> Input Class Initialized
INFO - 2016-06-10 14:59:51 --> Language Class Initialized
INFO - 2016-06-10 14:59:51 --> Loader Class Initialized
INFO - 2016-06-10 14:59:51 --> Helper loaded: form_helper
INFO - 2016-06-10 14:59:51 --> Database Driver Class Initialized
INFO - 2016-06-10 14:59:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 14:59:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 14:59:51 --> Email Class Initialized
INFO - 2016-06-10 14:59:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 14:59:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 14:59:51 --> Helper loaded: language_helper
INFO - 2016-06-10 14:59:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 14:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 14:59:51 --> Model Class Initialized
INFO - 2016-06-10 14:59:51 --> Helper loaded: date_helper
INFO - 2016-06-10 14:59:51 --> Controller Class Initialized
INFO - 2016-06-10 14:59:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 14:59:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 14:59:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 14:59:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 14:59:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 14:59:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 14:59:51 --> Model Class Initialized
INFO - 2016-06-10 14:59:51 --> Form Validation Class Initialized
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-10 14:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 14:59:51 --> Final output sent to browser
DEBUG - 2016-06-10 14:59:51 --> Total execution time: 0.0921
INFO - 2016-06-10 15:02:07 --> Config Class Initialized
INFO - 2016-06-10 15:02:07 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:02:07 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:02:07 --> Utf8 Class Initialized
INFO - 2016-06-10 15:02:07 --> URI Class Initialized
INFO - 2016-06-10 15:02:07 --> Router Class Initialized
INFO - 2016-06-10 15:02:07 --> Output Class Initialized
INFO - 2016-06-10 15:02:07 --> Security Class Initialized
DEBUG - 2016-06-10 15:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:02:07 --> Input Class Initialized
INFO - 2016-06-10 15:02:07 --> Language Class Initialized
INFO - 2016-06-10 15:02:07 --> Loader Class Initialized
INFO - 2016-06-10 15:02:07 --> Helper loaded: form_helper
INFO - 2016-06-10 15:02:07 --> Database Driver Class Initialized
INFO - 2016-06-10 15:02:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:02:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:02:07 --> Email Class Initialized
INFO - 2016-06-10 15:02:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:02:07 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:02:07 --> Helper loaded: language_helper
INFO - 2016-06-10 15:02:07 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:07 --> Model Class Initialized
INFO - 2016-06-10 15:02:07 --> Helper loaded: date_helper
INFO - 2016-06-10 15:02:07 --> Controller Class Initialized
INFO - 2016-06-10 15:02:07 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:02:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:02:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:02:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:02:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:02:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:02:07 --> Model Class Initialized
INFO - 2016-06-10 15:02:07 --> Form Validation Class Initialized
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 15:02:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:02:07 --> Final output sent to browser
DEBUG - 2016-06-10 15:02:07 --> Total execution time: 0.0752
INFO - 2016-06-10 15:02:33 --> Config Class Initialized
INFO - 2016-06-10 15:02:33 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:02:33 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:02:33 --> Utf8 Class Initialized
INFO - 2016-06-10 15:02:33 --> URI Class Initialized
DEBUG - 2016-06-10 15:02:33 --> No URI present. Default controller set.
INFO - 2016-06-10 15:02:33 --> Router Class Initialized
INFO - 2016-06-10 15:02:33 --> Output Class Initialized
INFO - 2016-06-10 15:02:33 --> Security Class Initialized
DEBUG - 2016-06-10 15:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:02:33 --> Input Class Initialized
INFO - 2016-06-10 15:02:33 --> Language Class Initialized
INFO - 2016-06-10 15:02:33 --> Loader Class Initialized
INFO - 2016-06-10 15:02:33 --> Helper loaded: form_helper
INFO - 2016-06-10 15:02:33 --> Database Driver Class Initialized
INFO - 2016-06-10 15:02:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:02:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:02:33 --> Email Class Initialized
INFO - 2016-06-10 15:02:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:02:33 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:02:33 --> Helper loaded: language_helper
INFO - 2016-06-10 15:02:33 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:33 --> Model Class Initialized
INFO - 2016-06-10 15:02:33 --> Helper loaded: date_helper
INFO - 2016-06-10 15:02:33 --> Controller Class Initialized
INFO - 2016-06-10 15:02:33 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:02:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:02:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:02:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:02:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:02:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:02:34 --> Config Class Initialized
INFO - 2016-06-10 15:02:34 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:02:34 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:02:34 --> Utf8 Class Initialized
INFO - 2016-06-10 15:02:34 --> URI Class Initialized
INFO - 2016-06-10 15:02:34 --> Router Class Initialized
INFO - 2016-06-10 15:02:34 --> Output Class Initialized
INFO - 2016-06-10 15:02:34 --> Security Class Initialized
DEBUG - 2016-06-10 15:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:02:34 --> Input Class Initialized
INFO - 2016-06-10 15:02:34 --> Language Class Initialized
INFO - 2016-06-10 15:02:34 --> Loader Class Initialized
INFO - 2016-06-10 15:02:34 --> Helper loaded: form_helper
INFO - 2016-06-10 15:02:34 --> Database Driver Class Initialized
INFO - 2016-06-10 15:02:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:02:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:02:34 --> Email Class Initialized
INFO - 2016-06-10 15:02:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:02:34 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:02:34 --> Helper loaded: language_helper
INFO - 2016-06-10 15:02:34 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:34 --> Model Class Initialized
INFO - 2016-06-10 15:02:34 --> Helper loaded: date_helper
INFO - 2016-06-10 15:02:34 --> Controller Class Initialized
INFO - 2016-06-10 15:02:34 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:02:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:02:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:02:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:02:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:02:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:02:34 --> Model Class Initialized
INFO - 2016-06-10 15:02:34 --> Form Validation Class Initialized
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-10 15:02:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:02:34 --> Final output sent to browser
DEBUG - 2016-06-10 15:02:34 --> Total execution time: 0.0636
INFO - 2016-06-10 15:02:38 --> Config Class Initialized
INFO - 2016-06-10 15:02:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:02:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:02:38 --> Utf8 Class Initialized
INFO - 2016-06-10 15:02:38 --> URI Class Initialized
INFO - 2016-06-10 15:02:38 --> Router Class Initialized
INFO - 2016-06-10 15:02:38 --> Output Class Initialized
INFO - 2016-06-10 15:02:38 --> Security Class Initialized
DEBUG - 2016-06-10 15:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:02:38 --> Input Class Initialized
INFO - 2016-06-10 15:02:38 --> Language Class Initialized
INFO - 2016-06-10 15:02:38 --> Loader Class Initialized
INFO - 2016-06-10 15:02:38 --> Helper loaded: form_helper
INFO - 2016-06-10 15:02:38 --> Database Driver Class Initialized
INFO - 2016-06-10 15:02:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:02:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:02:38 --> Email Class Initialized
INFO - 2016-06-10 15:02:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:02:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:02:38 --> Helper loaded: language_helper
INFO - 2016-06-10 15:02:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:38 --> Model Class Initialized
INFO - 2016-06-10 15:02:38 --> Helper loaded: date_helper
INFO - 2016-06-10 15:02:38 --> Controller Class Initialized
INFO - 2016-06-10 15:02:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:02:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:02:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:02:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:02:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:02:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:02:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:39 --> Form Validation Class Initialized
INFO - 2016-06-10 15:02:39 --> Config Class Initialized
INFO - 2016-06-10 15:02:39 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:02:39 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:02:39 --> Utf8 Class Initialized
INFO - 2016-06-10 15:02:39 --> URI Class Initialized
INFO - 2016-06-10 15:02:39 --> Router Class Initialized
INFO - 2016-06-10 15:02:39 --> Output Class Initialized
INFO - 2016-06-10 15:02:39 --> Security Class Initialized
DEBUG - 2016-06-10 15:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:02:39 --> Input Class Initialized
INFO - 2016-06-10 15:02:39 --> Language Class Initialized
INFO - 2016-06-10 15:02:39 --> Loader Class Initialized
INFO - 2016-06-10 15:02:39 --> Helper loaded: form_helper
INFO - 2016-06-10 15:02:39 --> Database Driver Class Initialized
INFO - 2016-06-10 15:02:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:02:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:02:39 --> Email Class Initialized
INFO - 2016-06-10 15:02:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:02:39 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:02:39 --> Helper loaded: language_helper
INFO - 2016-06-10 15:02:39 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:39 --> Model Class Initialized
INFO - 2016-06-10 15:02:39 --> Helper loaded: date_helper
INFO - 2016-06-10 15:02:39 --> Controller Class Initialized
INFO - 2016-06-10 15:02:39 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:02:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:02:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:02:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:02:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:02:39 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:02:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:39 --> Form Validation Class Initialized
DEBUG - 2016-06-10 15:02:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:02:39 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 15:02:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:02:39 --> Final output sent to browser
DEBUG - 2016-06-10 15:02:39 --> Total execution time: 0.0477
INFO - 2016-06-10 15:02:51 --> Config Class Initialized
INFO - 2016-06-10 15:02:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:02:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:02:51 --> Utf8 Class Initialized
INFO - 2016-06-10 15:02:51 --> URI Class Initialized
DEBUG - 2016-06-10 15:02:51 --> No URI present. Default controller set.
INFO - 2016-06-10 15:02:51 --> Router Class Initialized
INFO - 2016-06-10 15:02:51 --> Output Class Initialized
INFO - 2016-06-10 15:02:51 --> Security Class Initialized
DEBUG - 2016-06-10 15:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:02:51 --> Input Class Initialized
INFO - 2016-06-10 15:02:51 --> Language Class Initialized
INFO - 2016-06-10 15:02:51 --> Loader Class Initialized
INFO - 2016-06-10 15:02:51 --> Helper loaded: form_helper
INFO - 2016-06-10 15:02:51 --> Database Driver Class Initialized
INFO - 2016-06-10 15:02:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:02:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:02:51 --> Email Class Initialized
INFO - 2016-06-10 15:02:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:02:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:02:51 --> Helper loaded: language_helper
INFO - 2016-06-10 15:02:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:02:51 --> Model Class Initialized
INFO - 2016-06-10 15:02:51 --> Helper loaded: date_helper
INFO - 2016-06-10 15:02:51 --> Controller Class Initialized
INFO - 2016-06-10 15:02:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:02:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:02:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:02:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:02:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:02:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:02:51 --> Model Class Initialized
INFO - 2016-06-10 15:02:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:02:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:02:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:02:51 --> Final output sent to browser
DEBUG - 2016-06-10 15:02:51 --> Total execution time: 0.0722
INFO - 2016-06-10 15:08:39 --> Config Class Initialized
INFO - 2016-06-10 15:08:39 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:08:39 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:08:39 --> Utf8 Class Initialized
INFO - 2016-06-10 15:08:39 --> URI Class Initialized
DEBUG - 2016-06-10 15:08:39 --> No URI present. Default controller set.
INFO - 2016-06-10 15:08:39 --> Router Class Initialized
INFO - 2016-06-10 15:08:39 --> Output Class Initialized
INFO - 2016-06-10 15:08:39 --> Security Class Initialized
DEBUG - 2016-06-10 15:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:08:39 --> Input Class Initialized
INFO - 2016-06-10 15:08:39 --> Language Class Initialized
INFO - 2016-06-10 15:08:39 --> Loader Class Initialized
INFO - 2016-06-10 15:08:39 --> Helper loaded: form_helper
INFO - 2016-06-10 15:08:39 --> Database Driver Class Initialized
INFO - 2016-06-10 15:08:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:08:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:08:39 --> Email Class Initialized
INFO - 2016-06-10 15:08:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:08:39 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:08:39 --> Helper loaded: language_helper
INFO - 2016-06-10 15:08:39 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:08:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:08:39 --> Model Class Initialized
INFO - 2016-06-10 15:08:39 --> Helper loaded: date_helper
INFO - 2016-06-10 15:08:39 --> Controller Class Initialized
INFO - 2016-06-10 15:08:39 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:08:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:08:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:08:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:08:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:08:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:08:39 --> Model Class Initialized
INFO - 2016-06-10 15:08:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:08:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:08:39 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:08:39 --> Final output sent to browser
DEBUG - 2016-06-10 15:08:39 --> Total execution time: 0.0669
INFO - 2016-06-10 15:09:28 --> Config Class Initialized
INFO - 2016-06-10 15:09:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:09:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:09:28 --> Utf8 Class Initialized
INFO - 2016-06-10 15:09:28 --> URI Class Initialized
DEBUG - 2016-06-10 15:09:28 --> No URI present. Default controller set.
INFO - 2016-06-10 15:09:28 --> Router Class Initialized
INFO - 2016-06-10 15:09:28 --> Output Class Initialized
INFO - 2016-06-10 15:09:28 --> Security Class Initialized
DEBUG - 2016-06-10 15:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:09:28 --> Input Class Initialized
INFO - 2016-06-10 15:09:28 --> Language Class Initialized
INFO - 2016-06-10 15:09:28 --> Loader Class Initialized
INFO - 2016-06-10 15:09:28 --> Helper loaded: form_helper
INFO - 2016-06-10 15:09:28 --> Database Driver Class Initialized
INFO - 2016-06-10 15:09:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:09:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:09:28 --> Email Class Initialized
INFO - 2016-06-10 15:09:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:09:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:09:28 --> Helper loaded: language_helper
INFO - 2016-06-10 15:09:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:09:28 --> Model Class Initialized
INFO - 2016-06-10 15:09:28 --> Helper loaded: date_helper
INFO - 2016-06-10 15:09:28 --> Controller Class Initialized
INFO - 2016-06-10 15:09:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:09:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:09:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:09:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:09:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:09:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:09:28 --> Model Class Initialized
INFO - 2016-06-10 15:09:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:09:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:09:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:09:28 --> Final output sent to browser
DEBUG - 2016-06-10 15:09:28 --> Total execution time: 0.0569
INFO - 2016-06-10 15:10:02 --> Config Class Initialized
INFO - 2016-06-10 15:10:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:10:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:10:02 --> Utf8 Class Initialized
INFO - 2016-06-10 15:10:02 --> URI Class Initialized
DEBUG - 2016-06-10 15:10:02 --> No URI present. Default controller set.
INFO - 2016-06-10 15:10:02 --> Router Class Initialized
INFO - 2016-06-10 15:10:02 --> Output Class Initialized
INFO - 2016-06-10 15:10:02 --> Security Class Initialized
DEBUG - 2016-06-10 15:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:10:02 --> Input Class Initialized
INFO - 2016-06-10 15:10:02 --> Language Class Initialized
INFO - 2016-06-10 15:10:02 --> Loader Class Initialized
INFO - 2016-06-10 15:10:02 --> Helper loaded: form_helper
INFO - 2016-06-10 15:10:02 --> Database Driver Class Initialized
INFO - 2016-06-10 15:10:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:10:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:10:02 --> Email Class Initialized
INFO - 2016-06-10 15:10:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:10:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:10:02 --> Helper loaded: language_helper
INFO - 2016-06-10 15:10:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:10:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:10:02 --> Model Class Initialized
INFO - 2016-06-10 15:10:02 --> Helper loaded: date_helper
INFO - 2016-06-10 15:10:02 --> Controller Class Initialized
INFO - 2016-06-10 15:10:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:10:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:10:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:10:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:10:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:10:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:10:02 --> Model Class Initialized
INFO - 2016-06-10 15:10:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:10:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:10:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:10:02 --> Final output sent to browser
DEBUG - 2016-06-10 15:10:02 --> Total execution time: 0.0536
INFO - 2016-06-10 15:10:19 --> Config Class Initialized
INFO - 2016-06-10 15:10:19 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:10:19 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:10:19 --> Utf8 Class Initialized
INFO - 2016-06-10 15:10:19 --> URI Class Initialized
DEBUG - 2016-06-10 15:10:19 --> No URI present. Default controller set.
INFO - 2016-06-10 15:10:19 --> Router Class Initialized
INFO - 2016-06-10 15:10:19 --> Output Class Initialized
INFO - 2016-06-10 15:10:19 --> Security Class Initialized
DEBUG - 2016-06-10 15:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:10:19 --> Input Class Initialized
INFO - 2016-06-10 15:10:19 --> Language Class Initialized
INFO - 2016-06-10 15:10:19 --> Loader Class Initialized
INFO - 2016-06-10 15:10:19 --> Helper loaded: form_helper
INFO - 2016-06-10 15:10:19 --> Database Driver Class Initialized
INFO - 2016-06-10 15:10:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:10:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:10:19 --> Email Class Initialized
INFO - 2016-06-10 15:10:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:10:19 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:10:19 --> Helper loaded: language_helper
INFO - 2016-06-10 15:10:19 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:10:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:10:19 --> Model Class Initialized
INFO - 2016-06-10 15:10:19 --> Helper loaded: date_helper
INFO - 2016-06-10 15:10:19 --> Controller Class Initialized
INFO - 2016-06-10 15:10:19 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:10:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:10:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:10:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:10:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:10:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:10:19 --> Model Class Initialized
INFO - 2016-06-10 15:10:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:10:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:10:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:10:19 --> Final output sent to browser
DEBUG - 2016-06-10 15:10:19 --> Total execution time: 0.0406
INFO - 2016-06-10 15:16:53 --> Config Class Initialized
INFO - 2016-06-10 15:16:53 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:16:53 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:16:53 --> Utf8 Class Initialized
INFO - 2016-06-10 15:16:53 --> URI Class Initialized
DEBUG - 2016-06-10 15:16:53 --> No URI present. Default controller set.
INFO - 2016-06-10 15:16:53 --> Router Class Initialized
INFO - 2016-06-10 15:16:53 --> Output Class Initialized
INFO - 2016-06-10 15:16:53 --> Security Class Initialized
DEBUG - 2016-06-10 15:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:16:53 --> Input Class Initialized
INFO - 2016-06-10 15:16:53 --> Language Class Initialized
INFO - 2016-06-10 15:16:53 --> Loader Class Initialized
INFO - 2016-06-10 15:16:53 --> Helper loaded: form_helper
INFO - 2016-06-10 15:16:53 --> Database Driver Class Initialized
INFO - 2016-06-10 15:16:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:16:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:16:53 --> Email Class Initialized
INFO - 2016-06-10 15:16:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:16:53 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:16:53 --> Helper loaded: language_helper
INFO - 2016-06-10 15:16:53 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:16:53 --> Model Class Initialized
INFO - 2016-06-10 15:16:53 --> Helper loaded: date_helper
INFO - 2016-06-10 15:16:53 --> Controller Class Initialized
INFO - 2016-06-10 15:16:53 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:16:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:16:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:16:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:16:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:16:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:16:53 --> Model Class Initialized
INFO - 2016-06-10 15:16:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:16:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:16:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:16:53 --> Final output sent to browser
DEBUG - 2016-06-10 15:16:53 --> Total execution time: 0.0505
INFO - 2016-06-10 15:17:26 --> Config Class Initialized
INFO - 2016-06-10 15:17:26 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:17:26 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:17:26 --> Utf8 Class Initialized
INFO - 2016-06-10 15:17:26 --> URI Class Initialized
DEBUG - 2016-06-10 15:17:26 --> No URI present. Default controller set.
INFO - 2016-06-10 15:17:26 --> Router Class Initialized
INFO - 2016-06-10 15:17:26 --> Output Class Initialized
INFO - 2016-06-10 15:17:26 --> Security Class Initialized
DEBUG - 2016-06-10 15:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:17:26 --> Input Class Initialized
INFO - 2016-06-10 15:17:26 --> Language Class Initialized
INFO - 2016-06-10 15:17:26 --> Loader Class Initialized
INFO - 2016-06-10 15:17:26 --> Helper loaded: form_helper
INFO - 2016-06-10 15:17:26 --> Database Driver Class Initialized
INFO - 2016-06-10 15:17:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:17:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:17:26 --> Email Class Initialized
INFO - 2016-06-10 15:17:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:17:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:17:26 --> Helper loaded: language_helper
INFO - 2016-06-10 15:17:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:17:26 --> Model Class Initialized
INFO - 2016-06-10 15:17:26 --> Helper loaded: date_helper
INFO - 2016-06-10 15:17:26 --> Controller Class Initialized
INFO - 2016-06-10 15:17:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:17:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:17:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:17:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:17:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:17:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:17:26 --> Model Class Initialized
INFO - 2016-06-10 15:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:17:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:17:26 --> Final output sent to browser
DEBUG - 2016-06-10 15:17:26 --> Total execution time: 0.0381
INFO - 2016-06-10 15:17:54 --> Config Class Initialized
INFO - 2016-06-10 15:17:54 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:17:54 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:17:54 --> Utf8 Class Initialized
INFO - 2016-06-10 15:17:54 --> URI Class Initialized
DEBUG - 2016-06-10 15:17:54 --> No URI present. Default controller set.
INFO - 2016-06-10 15:17:54 --> Router Class Initialized
INFO - 2016-06-10 15:17:54 --> Output Class Initialized
INFO - 2016-06-10 15:17:54 --> Security Class Initialized
DEBUG - 2016-06-10 15:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:17:54 --> Input Class Initialized
INFO - 2016-06-10 15:17:54 --> Language Class Initialized
INFO - 2016-06-10 15:17:54 --> Loader Class Initialized
INFO - 2016-06-10 15:17:54 --> Helper loaded: form_helper
INFO - 2016-06-10 15:17:54 --> Database Driver Class Initialized
INFO - 2016-06-10 15:17:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:17:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:17:54 --> Email Class Initialized
INFO - 2016-06-10 15:17:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:17:54 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:17:54 --> Helper loaded: language_helper
INFO - 2016-06-10 15:17:54 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:17:54 --> Model Class Initialized
INFO - 2016-06-10 15:17:54 --> Helper loaded: date_helper
INFO - 2016-06-10 15:17:54 --> Controller Class Initialized
INFO - 2016-06-10 15:17:54 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:17:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:17:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:17:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:17:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:17:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:17:54 --> Model Class Initialized
INFO - 2016-06-10 15:17:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:17:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:17:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:17:54 --> Final output sent to browser
DEBUG - 2016-06-10 15:17:54 --> Total execution time: 0.0569
INFO - 2016-06-10 15:18:11 --> Config Class Initialized
INFO - 2016-06-10 15:18:11 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:18:11 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:18:11 --> Utf8 Class Initialized
INFO - 2016-06-10 15:18:11 --> URI Class Initialized
DEBUG - 2016-06-10 15:18:11 --> No URI present. Default controller set.
INFO - 2016-06-10 15:18:11 --> Router Class Initialized
INFO - 2016-06-10 15:18:11 --> Output Class Initialized
INFO - 2016-06-10 15:18:11 --> Security Class Initialized
DEBUG - 2016-06-10 15:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:18:11 --> Input Class Initialized
INFO - 2016-06-10 15:18:11 --> Language Class Initialized
INFO - 2016-06-10 15:18:11 --> Loader Class Initialized
INFO - 2016-06-10 15:18:11 --> Helper loaded: form_helper
INFO - 2016-06-10 15:18:11 --> Database Driver Class Initialized
INFO - 2016-06-10 15:18:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:18:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:18:11 --> Email Class Initialized
INFO - 2016-06-10 15:18:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:18:11 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:18:11 --> Helper loaded: language_helper
INFO - 2016-06-10 15:18:11 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:18:11 --> Model Class Initialized
INFO - 2016-06-10 15:18:11 --> Helper loaded: date_helper
INFO - 2016-06-10 15:18:11 --> Controller Class Initialized
INFO - 2016-06-10 15:18:11 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:18:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:18:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:18:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:18:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:18:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:18:11 --> Model Class Initialized
INFO - 2016-06-10 15:18:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:18:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:18:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:18:11 --> Final output sent to browser
DEBUG - 2016-06-10 15:18:11 --> Total execution time: 0.0599
INFO - 2016-06-10 15:20:46 --> Config Class Initialized
INFO - 2016-06-10 15:20:46 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:20:46 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:20:46 --> Utf8 Class Initialized
INFO - 2016-06-10 15:20:46 --> URI Class Initialized
DEBUG - 2016-06-10 15:20:46 --> No URI present. Default controller set.
INFO - 2016-06-10 15:20:46 --> Router Class Initialized
INFO - 2016-06-10 15:20:46 --> Output Class Initialized
INFO - 2016-06-10 15:20:46 --> Security Class Initialized
DEBUG - 2016-06-10 15:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:20:46 --> Input Class Initialized
INFO - 2016-06-10 15:20:46 --> Language Class Initialized
INFO - 2016-06-10 15:20:46 --> Loader Class Initialized
INFO - 2016-06-10 15:20:46 --> Helper loaded: form_helper
INFO - 2016-06-10 15:20:46 --> Database Driver Class Initialized
INFO - 2016-06-10 15:20:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:20:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:20:46 --> Email Class Initialized
INFO - 2016-06-10 15:20:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:20:46 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:20:46 --> Helper loaded: language_helper
INFO - 2016-06-10 15:20:46 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:20:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:20:46 --> Model Class Initialized
INFO - 2016-06-10 15:20:46 --> Helper loaded: date_helper
INFO - 2016-06-10 15:20:46 --> Controller Class Initialized
INFO - 2016-06-10 15:20:46 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:20:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:20:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:20:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:20:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:20:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:20:46 --> Model Class Initialized
INFO - 2016-06-10 15:20:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:20:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:20:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:20:46 --> Final output sent to browser
DEBUG - 2016-06-10 15:20:46 --> Total execution time: 0.0650
INFO - 2016-06-10 15:21:12 --> Config Class Initialized
INFO - 2016-06-10 15:21:12 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:21:12 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:21:12 --> Utf8 Class Initialized
INFO - 2016-06-10 15:21:12 --> URI Class Initialized
DEBUG - 2016-06-10 15:21:12 --> No URI present. Default controller set.
INFO - 2016-06-10 15:21:12 --> Router Class Initialized
INFO - 2016-06-10 15:21:12 --> Output Class Initialized
INFO - 2016-06-10 15:21:12 --> Security Class Initialized
DEBUG - 2016-06-10 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:21:12 --> Input Class Initialized
INFO - 2016-06-10 15:21:12 --> Language Class Initialized
INFO - 2016-06-10 15:21:12 --> Loader Class Initialized
INFO - 2016-06-10 15:21:12 --> Helper loaded: form_helper
INFO - 2016-06-10 15:21:12 --> Database Driver Class Initialized
INFO - 2016-06-10 15:21:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:21:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:21:13 --> Email Class Initialized
INFO - 2016-06-10 15:21:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:21:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:21:13 --> Helper loaded: language_helper
INFO - 2016-06-10 15:21:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:21:13 --> Model Class Initialized
INFO - 2016-06-10 15:21:13 --> Helper loaded: date_helper
INFO - 2016-06-10 15:21:13 --> Controller Class Initialized
INFO - 2016-06-10 15:21:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:21:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:21:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:21:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:21:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:21:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:21:13 --> Model Class Initialized
INFO - 2016-06-10 15:21:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:21:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:21:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:21:13 --> Final output sent to browser
DEBUG - 2016-06-10 15:21:13 --> Total execution time: 0.0401
INFO - 2016-06-10 15:24:44 --> Config Class Initialized
INFO - 2016-06-10 15:24:44 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:24:44 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:24:44 --> Utf8 Class Initialized
INFO - 2016-06-10 15:24:44 --> URI Class Initialized
INFO - 2016-06-10 15:24:44 --> Router Class Initialized
INFO - 2016-06-10 15:24:44 --> Output Class Initialized
INFO - 2016-06-10 15:24:44 --> Security Class Initialized
DEBUG - 2016-06-10 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:24:44 --> Input Class Initialized
INFO - 2016-06-10 15:24:44 --> Language Class Initialized
INFO - 2016-06-10 15:24:44 --> Loader Class Initialized
INFO - 2016-06-10 15:24:44 --> Helper loaded: form_helper
INFO - 2016-06-10 15:24:44 --> Database Driver Class Initialized
INFO - 2016-06-10 15:24:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:24:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:24:44 --> Email Class Initialized
INFO - 2016-06-10 15:24:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:24:44 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:24:44 --> Helper loaded: language_helper
INFO - 2016-06-10 15:24:44 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:24:44 --> Model Class Initialized
INFO - 2016-06-10 15:24:44 --> Helper loaded: date_helper
INFO - 2016-06-10 15:24:44 --> Controller Class Initialized
INFO - 2016-06-10 15:24:44 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:24:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:24:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:24:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:24:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:24:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:24:44 --> Model Class Initialized
INFO - 2016-06-10 15:24:44 --> Form Validation Class Initialized
INFO - 2016-06-10 15:24:49 --> Config Class Initialized
INFO - 2016-06-10 15:24:49 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:24:49 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:24:49 --> Utf8 Class Initialized
INFO - 2016-06-10 15:24:49 --> URI Class Initialized
INFO - 2016-06-10 15:24:49 --> Router Class Initialized
INFO - 2016-06-10 15:24:49 --> Output Class Initialized
INFO - 2016-06-10 15:24:49 --> Security Class Initialized
DEBUG - 2016-06-10 15:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:24:49 --> Input Class Initialized
INFO - 2016-06-10 15:24:49 --> Language Class Initialized
INFO - 2016-06-10 15:24:49 --> Loader Class Initialized
INFO - 2016-06-10 15:24:49 --> Helper loaded: form_helper
INFO - 2016-06-10 15:24:49 --> Database Driver Class Initialized
INFO - 2016-06-10 15:24:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:24:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:24:49 --> Email Class Initialized
INFO - 2016-06-10 15:24:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:24:49 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:24:49 --> Helper loaded: language_helper
INFO - 2016-06-10 15:24:49 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:24:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:24:49 --> Model Class Initialized
INFO - 2016-06-10 15:24:49 --> Helper loaded: date_helper
INFO - 2016-06-10 15:24:49 --> Controller Class Initialized
INFO - 2016-06-10 15:24:49 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:24:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:24:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:24:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:24:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:24:49 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:24:49 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:24:49 --> Form Validation Class Initialized
DEBUG - 2016-06-10 15:24:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:24:49 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:24:49 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 15:24:49 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:24:49 --> Final output sent to browser
DEBUG - 2016-06-10 15:24:49 --> Total execution time: 0.0674
INFO - 2016-06-10 15:24:58 --> Config Class Initialized
INFO - 2016-06-10 15:24:58 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:24:58 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:24:58 --> Utf8 Class Initialized
INFO - 2016-06-10 15:24:58 --> URI Class Initialized
DEBUG - 2016-06-10 15:24:58 --> No URI present. Default controller set.
INFO - 2016-06-10 15:24:58 --> Router Class Initialized
INFO - 2016-06-10 15:24:58 --> Output Class Initialized
INFO - 2016-06-10 15:24:58 --> Security Class Initialized
DEBUG - 2016-06-10 15:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:24:58 --> Input Class Initialized
INFO - 2016-06-10 15:24:58 --> Language Class Initialized
INFO - 2016-06-10 15:24:58 --> Loader Class Initialized
INFO - 2016-06-10 15:24:58 --> Helper loaded: form_helper
INFO - 2016-06-10 15:24:58 --> Database Driver Class Initialized
INFO - 2016-06-10 15:24:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:24:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:24:58 --> Email Class Initialized
INFO - 2016-06-10 15:24:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:24:58 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:24:58 --> Helper loaded: language_helper
INFO - 2016-06-10 15:24:58 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:24:58 --> Model Class Initialized
INFO - 2016-06-10 15:24:58 --> Helper loaded: date_helper
INFO - 2016-06-10 15:24:58 --> Controller Class Initialized
INFO - 2016-06-10 15:24:58 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:24:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:24:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:24:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:24:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:24:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:24:58 --> Model Class Initialized
INFO - 2016-06-10 15:24:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:24:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:24:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:24:58 --> Final output sent to browser
DEBUG - 2016-06-10 15:24:58 --> Total execution time: 0.0503
INFO - 2016-06-10 15:25:17 --> Config Class Initialized
INFO - 2016-06-10 15:25:17 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:25:17 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:25:17 --> Utf8 Class Initialized
INFO - 2016-06-10 15:25:17 --> URI Class Initialized
INFO - 2016-06-10 15:25:17 --> Router Class Initialized
INFO - 2016-06-10 15:25:17 --> Output Class Initialized
INFO - 2016-06-10 15:25:17 --> Security Class Initialized
DEBUG - 2016-06-10 15:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:25:17 --> Input Class Initialized
INFO - 2016-06-10 15:25:17 --> Language Class Initialized
INFO - 2016-06-10 15:25:17 --> Loader Class Initialized
INFO - 2016-06-10 15:25:17 --> Helper loaded: form_helper
INFO - 2016-06-10 15:25:17 --> Database Driver Class Initialized
INFO - 2016-06-10 15:25:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:25:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:25:17 --> Email Class Initialized
INFO - 2016-06-10 15:25:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:25:17 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:25:17 --> Helper loaded: language_helper
INFO - 2016-06-10 15:25:17 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:17 --> Model Class Initialized
INFO - 2016-06-10 15:25:17 --> Helper loaded: date_helper
INFO - 2016-06-10 15:25:17 --> Controller Class Initialized
INFO - 2016-06-10 15:25:17 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:25:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:25:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:25:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:25:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:25:17 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:25:17 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:17 --> Form Validation Class Initialized
DEBUG - 2016-06-10 15:25:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:17 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:25:17 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 15:25:17 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:25:17 --> Final output sent to browser
DEBUG - 2016-06-10 15:25:17 --> Total execution time: 0.0622
INFO - 2016-06-10 15:25:36 --> Config Class Initialized
INFO - 2016-06-10 15:25:36 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:25:36 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:25:36 --> Utf8 Class Initialized
INFO - 2016-06-10 15:25:36 --> URI Class Initialized
INFO - 2016-06-10 15:25:36 --> Router Class Initialized
INFO - 2016-06-10 15:25:36 --> Output Class Initialized
INFO - 2016-06-10 15:25:36 --> Security Class Initialized
DEBUG - 2016-06-10 15:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:25:36 --> Input Class Initialized
INFO - 2016-06-10 15:25:36 --> Language Class Initialized
INFO - 2016-06-10 15:25:36 --> Loader Class Initialized
INFO - 2016-06-10 15:25:36 --> Helper loaded: form_helper
INFO - 2016-06-10 15:25:36 --> Database Driver Class Initialized
INFO - 2016-06-10 15:25:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:25:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:25:36 --> Email Class Initialized
INFO - 2016-06-10 15:25:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:25:36 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:25:36 --> Helper loaded: language_helper
INFO - 2016-06-10 15:25:36 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:36 --> Model Class Initialized
INFO - 2016-06-10 15:25:36 --> Helper loaded: date_helper
INFO - 2016-06-10 15:25:36 --> Controller Class Initialized
INFO - 2016-06-10 15:25:36 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:25:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:25:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:25:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:25:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:25:36 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:25:36 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:36 --> Form Validation Class Initialized
DEBUG - 2016-06-10 15:25:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:42 --> Config Class Initialized
INFO - 2016-06-10 15:25:42 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:25:42 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:25:42 --> Utf8 Class Initialized
INFO - 2016-06-10 15:25:42 --> URI Class Initialized
DEBUG - 2016-06-10 15:25:42 --> No URI present. Default controller set.
INFO - 2016-06-10 15:25:42 --> Router Class Initialized
INFO - 2016-06-10 15:25:42 --> Output Class Initialized
INFO - 2016-06-10 15:25:42 --> Security Class Initialized
DEBUG - 2016-06-10 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:25:42 --> Input Class Initialized
INFO - 2016-06-10 15:25:42 --> Language Class Initialized
INFO - 2016-06-10 15:25:42 --> Loader Class Initialized
INFO - 2016-06-10 15:25:42 --> Helper loaded: form_helper
INFO - 2016-06-10 15:25:42 --> Database Driver Class Initialized
INFO - 2016-06-10 15:25:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:25:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:25:42 --> Email Class Initialized
INFO - 2016-06-10 15:25:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:25:42 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:25:42 --> Helper loaded: language_helper
INFO - 2016-06-10 15:25:42 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:25:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:42 --> Model Class Initialized
INFO - 2016-06-10 15:25:42 --> Helper loaded: date_helper
INFO - 2016-06-10 15:25:42 --> Controller Class Initialized
INFO - 2016-06-10 15:25:42 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:25:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:25:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:25:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:25:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:25:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:25:43 --> Config Class Initialized
INFO - 2016-06-10 15:25:43 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:25:43 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:25:43 --> Utf8 Class Initialized
INFO - 2016-06-10 15:25:43 --> URI Class Initialized
INFO - 2016-06-10 15:25:43 --> Router Class Initialized
INFO - 2016-06-10 15:25:43 --> Output Class Initialized
INFO - 2016-06-10 15:25:43 --> Security Class Initialized
DEBUG - 2016-06-10 15:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:25:43 --> Input Class Initialized
INFO - 2016-06-10 15:25:43 --> Language Class Initialized
INFO - 2016-06-10 15:25:43 --> Loader Class Initialized
INFO - 2016-06-10 15:25:43 --> Helper loaded: form_helper
INFO - 2016-06-10 15:25:43 --> Database Driver Class Initialized
INFO - 2016-06-10 15:25:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:25:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:25:43 --> Email Class Initialized
INFO - 2016-06-10 15:25:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:25:43 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:25:43 --> Helper loaded: language_helper
INFO - 2016-06-10 15:25:43 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:43 --> Model Class Initialized
INFO - 2016-06-10 15:25:43 --> Helper loaded: date_helper
INFO - 2016-06-10 15:25:43 --> Controller Class Initialized
INFO - 2016-06-10 15:25:43 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:25:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:25:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:25:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:25:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:25:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:25:43 --> Model Class Initialized
INFO - 2016-06-10 15:25:43 --> Form Validation Class Initialized
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-10 15:25:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:25:43 --> Final output sent to browser
DEBUG - 2016-06-10 15:25:43 --> Total execution time: 0.0384
INFO - 2016-06-10 15:25:51 --> Config Class Initialized
INFO - 2016-06-10 15:25:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:25:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:25:51 --> Utf8 Class Initialized
INFO - 2016-06-10 15:25:51 --> URI Class Initialized
INFO - 2016-06-10 15:25:51 --> Router Class Initialized
INFO - 2016-06-10 15:25:51 --> Output Class Initialized
INFO - 2016-06-10 15:25:51 --> Security Class Initialized
DEBUG - 2016-06-10 15:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:25:51 --> Input Class Initialized
INFO - 2016-06-10 15:25:51 --> Language Class Initialized
INFO - 2016-06-10 15:25:51 --> Loader Class Initialized
INFO - 2016-06-10 15:25:51 --> Helper loaded: form_helper
INFO - 2016-06-10 15:25:51 --> Database Driver Class Initialized
INFO - 2016-06-10 15:25:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:25:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:25:51 --> Email Class Initialized
INFO - 2016-06-10 15:25:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:25:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:25:51 --> Helper loaded: language_helper
INFO - 2016-06-10 15:25:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:25:51 --> Model Class Initialized
INFO - 2016-06-10 15:25:51 --> Helper loaded: date_helper
INFO - 2016-06-10 15:25:51 --> Controller Class Initialized
INFO - 2016-06-10 15:25:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:25:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:25:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:25:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:25:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:25:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:25:51 --> Model Class Initialized
INFO - 2016-06-10 15:25:51 --> Form Validation Class Initialized
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 15:25:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:25:51 --> Final output sent to browser
DEBUG - 2016-06-10 15:25:51 --> Total execution time: 0.0742
INFO - 2016-06-10 15:26:19 --> Config Class Initialized
INFO - 2016-06-10 15:26:19 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:26:19 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:26:19 --> Utf8 Class Initialized
INFO - 2016-06-10 15:26:19 --> URI Class Initialized
INFO - 2016-06-10 15:26:19 --> Router Class Initialized
INFO - 2016-06-10 15:26:19 --> Output Class Initialized
INFO - 2016-06-10 15:26:19 --> Security Class Initialized
DEBUG - 2016-06-10 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:26:19 --> Input Class Initialized
INFO - 2016-06-10 15:26:19 --> Language Class Initialized
INFO - 2016-06-10 15:26:19 --> Loader Class Initialized
INFO - 2016-06-10 15:26:19 --> Helper loaded: form_helper
INFO - 2016-06-10 15:26:19 --> Database Driver Class Initialized
INFO - 2016-06-10 15:26:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:26:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:26:19 --> Email Class Initialized
INFO - 2016-06-10 15:26:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:26:19 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:26:19 --> Helper loaded: language_helper
INFO - 2016-06-10 15:26:19 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:26:19 --> Model Class Initialized
INFO - 2016-06-10 15:26:19 --> Helper loaded: date_helper
INFO - 2016-06-10 15:26:19 --> Controller Class Initialized
INFO - 2016-06-10 15:26:19 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:26:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:26:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:26:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:26:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:26:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:26:19 --> Model Class Initialized
INFO - 2016-06-10 15:26:19 --> Form Validation Class Initialized
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-10 15:26:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:26:19 --> Final output sent to browser
DEBUG - 2016-06-10 15:26:19 --> Total execution time: 0.0893
INFO - 2016-06-10 15:26:37 --> Config Class Initialized
INFO - 2016-06-10 15:26:37 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:26:37 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:26:37 --> Utf8 Class Initialized
INFO - 2016-06-10 15:26:37 --> URI Class Initialized
INFO - 2016-06-10 15:26:37 --> Router Class Initialized
INFO - 2016-06-10 15:26:37 --> Output Class Initialized
INFO - 2016-06-10 15:26:37 --> Security Class Initialized
DEBUG - 2016-06-10 15:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:26:37 --> Input Class Initialized
INFO - 2016-06-10 15:26:37 --> Language Class Initialized
INFO - 2016-06-10 15:26:37 --> Loader Class Initialized
INFO - 2016-06-10 15:26:37 --> Helper loaded: form_helper
INFO - 2016-06-10 15:26:37 --> Database Driver Class Initialized
INFO - 2016-06-10 15:26:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:26:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:26:37 --> Email Class Initialized
INFO - 2016-06-10 15:26:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:26:37 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:26:37 --> Helper loaded: language_helper
INFO - 2016-06-10 15:26:37 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:26:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:26:37 --> Model Class Initialized
INFO - 2016-06-10 15:26:37 --> Helper loaded: date_helper
INFO - 2016-06-10 15:26:37 --> Controller Class Initialized
INFO - 2016-06-10 15:26:37 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:26:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:26:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:26:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:26:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:26:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:26:37 --> Model Class Initialized
INFO - 2016-06-10 15:26:37 --> Form Validation Class Initialized
INFO - 2016-06-10 15:26:37 --> Final output sent to browser
DEBUG - 2016-06-10 15:26:37 --> Total execution time: 0.1124
INFO - 2016-06-10 15:26:38 --> Config Class Initialized
INFO - 2016-06-10 15:26:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:26:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:26:38 --> Utf8 Class Initialized
INFO - 2016-06-10 15:26:38 --> URI Class Initialized
INFO - 2016-06-10 15:26:38 --> Router Class Initialized
INFO - 2016-06-10 15:26:38 --> Output Class Initialized
INFO - 2016-06-10 15:26:38 --> Security Class Initialized
DEBUG - 2016-06-10 15:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:26:38 --> Input Class Initialized
INFO - 2016-06-10 15:26:38 --> Language Class Initialized
INFO - 2016-06-10 15:26:38 --> Loader Class Initialized
INFO - 2016-06-10 15:26:38 --> Helper loaded: form_helper
INFO - 2016-06-10 15:26:38 --> Database Driver Class Initialized
INFO - 2016-06-10 15:26:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:26:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:26:38 --> Email Class Initialized
INFO - 2016-06-10 15:26:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:26:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:26:38 --> Helper loaded: language_helper
INFO - 2016-06-10 15:26:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:26:38 --> Model Class Initialized
INFO - 2016-06-10 15:26:38 --> Helper loaded: date_helper
INFO - 2016-06-10 15:26:38 --> Controller Class Initialized
INFO - 2016-06-10 15:26:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:26:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:26:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:26:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:26:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:26:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:26:38 --> Model Class Initialized
INFO - 2016-06-10 15:26:38 --> Form Validation Class Initialized
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 15:26:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:26:38 --> Final output sent to browser
DEBUG - 2016-06-10 15:26:38 --> Total execution time: 0.0920
INFO - 2016-06-10 15:27:02 --> Config Class Initialized
INFO - 2016-06-10 15:27:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:27:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:27:02 --> Utf8 Class Initialized
INFO - 2016-06-10 15:27:02 --> URI Class Initialized
INFO - 2016-06-10 15:27:02 --> Router Class Initialized
INFO - 2016-06-10 15:27:02 --> Output Class Initialized
INFO - 2016-06-10 15:27:02 --> Security Class Initialized
DEBUG - 2016-06-10 15:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:27:02 --> Input Class Initialized
INFO - 2016-06-10 15:27:02 --> Language Class Initialized
INFO - 2016-06-10 15:27:02 --> Loader Class Initialized
INFO - 2016-06-10 15:27:02 --> Helper loaded: form_helper
INFO - 2016-06-10 15:27:02 --> Database Driver Class Initialized
INFO - 2016-06-10 15:27:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:27:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:27:02 --> Email Class Initialized
INFO - 2016-06-10 15:27:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:27:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:27:02 --> Helper loaded: language_helper
INFO - 2016-06-10 15:27:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:27:02 --> Model Class Initialized
INFO - 2016-06-10 15:27:02 --> Helper loaded: date_helper
INFO - 2016-06-10 15:27:02 --> Controller Class Initialized
INFO - 2016-06-10 15:27:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:27:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:27:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:27:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:27:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:27:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:27:02 --> Model Class Initialized
INFO - 2016-06-10 15:27:02 --> Form Validation Class Initialized
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-10 15:27:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:27:02 --> Final output sent to browser
DEBUG - 2016-06-10 15:27:02 --> Total execution time: 0.1510
INFO - 2016-06-10 15:27:28 --> Config Class Initialized
INFO - 2016-06-10 15:27:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:27:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:27:28 --> Utf8 Class Initialized
INFO - 2016-06-10 15:27:28 --> URI Class Initialized
INFO - 2016-06-10 15:27:28 --> Router Class Initialized
INFO - 2016-06-10 15:27:28 --> Output Class Initialized
INFO - 2016-06-10 15:27:28 --> Security Class Initialized
DEBUG - 2016-06-10 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:27:28 --> Input Class Initialized
INFO - 2016-06-10 15:27:28 --> Language Class Initialized
INFO - 2016-06-10 15:27:28 --> Loader Class Initialized
INFO - 2016-06-10 15:27:28 --> Helper loaded: form_helper
INFO - 2016-06-10 15:27:28 --> Database Driver Class Initialized
INFO - 2016-06-10 15:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:27:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:27:28 --> Email Class Initialized
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:27:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:27:28 --> Helper loaded: language_helper
INFO - 2016-06-10 15:27:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:27:28 --> Model Class Initialized
INFO - 2016-06-10 15:27:28 --> Helper loaded: date_helper
INFO - 2016-06-10 15:27:28 --> Controller Class Initialized
INFO - 2016-06-10 15:27:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:27:28 --> Model Class Initialized
INFO - 2016-06-10 15:27:28 --> Form Validation Class Initialized
INFO - 2016-06-10 15:27:28 --> Final output sent to browser
DEBUG - 2016-06-10 15:27:28 --> Total execution time: 0.0760
INFO - 2016-06-10 15:27:28 --> Config Class Initialized
INFO - 2016-06-10 15:27:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:27:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:27:28 --> Utf8 Class Initialized
INFO - 2016-06-10 15:27:28 --> URI Class Initialized
INFO - 2016-06-10 15:27:28 --> Router Class Initialized
INFO - 2016-06-10 15:27:28 --> Output Class Initialized
INFO - 2016-06-10 15:27:28 --> Security Class Initialized
DEBUG - 2016-06-10 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:27:28 --> Input Class Initialized
INFO - 2016-06-10 15:27:28 --> Language Class Initialized
INFO - 2016-06-10 15:27:28 --> Loader Class Initialized
INFO - 2016-06-10 15:27:28 --> Helper loaded: form_helper
INFO - 2016-06-10 15:27:28 --> Database Driver Class Initialized
INFO - 2016-06-10 15:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:27:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:27:28 --> Email Class Initialized
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:27:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:27:28 --> Helper loaded: language_helper
INFO - 2016-06-10 15:27:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:27:28 --> Model Class Initialized
INFO - 2016-06-10 15:27:28 --> Helper loaded: date_helper
INFO - 2016-06-10 15:27:28 --> Controller Class Initialized
INFO - 2016-06-10 15:27:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:27:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:27:28 --> Model Class Initialized
INFO - 2016-06-10 15:27:28 --> Form Validation Class Initialized
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 15:27:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:27:28 --> Final output sent to browser
DEBUG - 2016-06-10 15:27:28 --> Total execution time: 0.0636
INFO - 2016-06-10 15:28:01 --> Config Class Initialized
INFO - 2016-06-10 15:28:01 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:28:01 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:28:01 --> Utf8 Class Initialized
INFO - 2016-06-10 15:28:01 --> URI Class Initialized
INFO - 2016-06-10 15:28:01 --> Router Class Initialized
INFO - 2016-06-10 15:28:01 --> Output Class Initialized
INFO - 2016-06-10 15:28:01 --> Security Class Initialized
DEBUG - 2016-06-10 15:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:28:01 --> Input Class Initialized
INFO - 2016-06-10 15:28:01 --> Language Class Initialized
INFO - 2016-06-10 15:28:01 --> Loader Class Initialized
INFO - 2016-06-10 15:28:01 --> Helper loaded: form_helper
INFO - 2016-06-10 15:28:01 --> Database Driver Class Initialized
INFO - 2016-06-10 15:28:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:28:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:28:01 --> Email Class Initialized
INFO - 2016-06-10 15:28:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:28:01 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:28:01 --> Helper loaded: language_helper
INFO - 2016-06-10 15:28:01 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:28:01 --> Model Class Initialized
INFO - 2016-06-10 15:28:01 --> Helper loaded: date_helper
INFO - 2016-06-10 15:28:01 --> Controller Class Initialized
INFO - 2016-06-10 15:28:01 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:28:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:28:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:28:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:28:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:28:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:28:01 --> Model Class Initialized
INFO - 2016-06-10 15:28:01 --> Form Validation Class Initialized
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 15:28:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:28:01 --> Final output sent to browser
DEBUG - 2016-06-10 15:28:01 --> Total execution time: 0.0591
INFO - 2016-06-10 15:28:23 --> Config Class Initialized
INFO - 2016-06-10 15:28:23 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:28:23 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:28:23 --> Utf8 Class Initialized
INFO - 2016-06-10 15:28:23 --> URI Class Initialized
INFO - 2016-06-10 15:28:23 --> Router Class Initialized
INFO - 2016-06-10 15:28:23 --> Output Class Initialized
INFO - 2016-06-10 15:28:23 --> Security Class Initialized
DEBUG - 2016-06-10 15:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:28:23 --> Input Class Initialized
INFO - 2016-06-10 15:28:23 --> Language Class Initialized
INFO - 2016-06-10 15:28:23 --> Loader Class Initialized
INFO - 2016-06-10 15:28:23 --> Helper loaded: form_helper
INFO - 2016-06-10 15:28:23 --> Database Driver Class Initialized
INFO - 2016-06-10 15:28:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:28:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:28:23 --> Email Class Initialized
INFO - 2016-06-10 15:28:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:28:23 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:28:23 --> Helper loaded: language_helper
INFO - 2016-06-10 15:28:23 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:28:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:28:23 --> Model Class Initialized
INFO - 2016-06-10 15:28:23 --> Helper loaded: date_helper
INFO - 2016-06-10 15:28:23 --> Controller Class Initialized
INFO - 2016-06-10 15:28:23 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:28:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:28:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:28:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:28:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:28:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:28:23 --> Model Class Initialized
INFO - 2016-06-10 15:28:23 --> Form Validation Class Initialized
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 15:28:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:28:23 --> Final output sent to browser
DEBUG - 2016-06-10 15:28:23 --> Total execution time: 0.0488
INFO - 2016-06-10 15:29:44 --> Config Class Initialized
INFO - 2016-06-10 15:29:44 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:29:44 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:29:44 --> Utf8 Class Initialized
INFO - 2016-06-10 15:29:44 --> URI Class Initialized
INFO - 2016-06-10 15:29:44 --> Router Class Initialized
INFO - 2016-06-10 15:29:44 --> Output Class Initialized
INFO - 2016-06-10 15:29:44 --> Security Class Initialized
DEBUG - 2016-06-10 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:29:44 --> Input Class Initialized
INFO - 2016-06-10 15:29:44 --> Language Class Initialized
INFO - 2016-06-10 15:29:44 --> Loader Class Initialized
INFO - 2016-06-10 15:29:44 --> Helper loaded: form_helper
INFO - 2016-06-10 15:29:44 --> Database Driver Class Initialized
INFO - 2016-06-10 15:29:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:29:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:29:44 --> Email Class Initialized
INFO - 2016-06-10 15:29:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:29:44 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:29:44 --> Helper loaded: language_helper
INFO - 2016-06-10 15:29:44 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:29:44 --> Model Class Initialized
INFO - 2016-06-10 15:29:44 --> Helper loaded: date_helper
INFO - 2016-06-10 15:29:44 --> Controller Class Initialized
INFO - 2016-06-10 15:29:44 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:29:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:29:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:29:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:29:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:29:44 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:29:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:29:44 --> Form Validation Class Initialized
INFO - 2016-06-10 15:29:50 --> Config Class Initialized
INFO - 2016-06-10 15:29:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:29:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:29:50 --> Utf8 Class Initialized
INFO - 2016-06-10 15:29:50 --> URI Class Initialized
INFO - 2016-06-10 15:29:50 --> Router Class Initialized
INFO - 2016-06-10 15:29:50 --> Output Class Initialized
INFO - 2016-06-10 15:29:50 --> Security Class Initialized
DEBUG - 2016-06-10 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:29:50 --> Input Class Initialized
INFO - 2016-06-10 15:29:50 --> Language Class Initialized
INFO - 2016-06-10 15:29:50 --> Loader Class Initialized
INFO - 2016-06-10 15:29:50 --> Helper loaded: form_helper
INFO - 2016-06-10 15:29:50 --> Database Driver Class Initialized
INFO - 2016-06-10 15:29:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:29:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:29:50 --> Email Class Initialized
INFO - 2016-06-10 15:29:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:29:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:29:50 --> Helper loaded: language_helper
INFO - 2016-06-10 15:29:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:29:50 --> Model Class Initialized
INFO - 2016-06-10 15:29:50 --> Helper loaded: date_helper
INFO - 2016-06-10 15:29:50 --> Controller Class Initialized
INFO - 2016-06-10 15:29:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:29:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:29:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:29:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:29:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:29:50 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:29:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:29:50 --> Form Validation Class Initialized
DEBUG - 2016-06-10 15:29:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:29:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:29:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 15:29:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:29:50 --> Final output sent to browser
DEBUG - 2016-06-10 15:29:50 --> Total execution time: 0.0485
INFO - 2016-06-10 15:29:57 --> Config Class Initialized
INFO - 2016-06-10 15:29:57 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:29:57 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:29:57 --> Utf8 Class Initialized
INFO - 2016-06-10 15:29:57 --> URI Class Initialized
DEBUG - 2016-06-10 15:29:57 --> No URI present. Default controller set.
INFO - 2016-06-10 15:29:57 --> Router Class Initialized
INFO - 2016-06-10 15:29:57 --> Output Class Initialized
INFO - 2016-06-10 15:29:57 --> Security Class Initialized
DEBUG - 2016-06-10 15:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:29:57 --> Input Class Initialized
INFO - 2016-06-10 15:29:57 --> Language Class Initialized
INFO - 2016-06-10 15:29:57 --> Loader Class Initialized
INFO - 2016-06-10 15:29:57 --> Helper loaded: form_helper
INFO - 2016-06-10 15:29:57 --> Database Driver Class Initialized
INFO - 2016-06-10 15:29:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:29:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:29:57 --> Email Class Initialized
INFO - 2016-06-10 15:29:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:29:57 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:29:57 --> Helper loaded: language_helper
INFO - 2016-06-10 15:29:57 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:29:57 --> Model Class Initialized
INFO - 2016-06-10 15:29:57 --> Helper loaded: date_helper
INFO - 2016-06-10 15:29:57 --> Controller Class Initialized
INFO - 2016-06-10 15:29:57 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:29:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:29:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:29:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:29:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:29:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:29:57 --> Model Class Initialized
INFO - 2016-06-10 15:29:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:29:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:29:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:29:57 --> Final output sent to browser
DEBUG - 2016-06-10 15:29:57 --> Total execution time: 0.0522
INFO - 2016-06-10 15:30:48 --> Config Class Initialized
INFO - 2016-06-10 15:30:48 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:30:48 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:30:48 --> Utf8 Class Initialized
INFO - 2016-06-10 15:30:48 --> URI Class Initialized
DEBUG - 2016-06-10 15:30:48 --> No URI present. Default controller set.
INFO - 2016-06-10 15:30:48 --> Router Class Initialized
INFO - 2016-06-10 15:30:48 --> Output Class Initialized
INFO - 2016-06-10 15:30:48 --> Security Class Initialized
DEBUG - 2016-06-10 15:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:30:48 --> Input Class Initialized
INFO - 2016-06-10 15:30:48 --> Language Class Initialized
INFO - 2016-06-10 15:30:48 --> Loader Class Initialized
INFO - 2016-06-10 15:30:48 --> Helper loaded: form_helper
INFO - 2016-06-10 15:30:48 --> Database Driver Class Initialized
INFO - 2016-06-10 15:30:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:30:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:30:48 --> Email Class Initialized
INFO - 2016-06-10 15:30:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:30:48 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:30:48 --> Helper loaded: language_helper
INFO - 2016-06-10 15:30:48 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:30:48 --> Model Class Initialized
INFO - 2016-06-10 15:30:48 --> Helper loaded: date_helper
INFO - 2016-06-10 15:30:48 --> Controller Class Initialized
INFO - 2016-06-10 15:30:48 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:30:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:30:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:30:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:30:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:30:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:30:48 --> Model Class Initialized
INFO - 2016-06-10 15:30:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:30:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 15:30:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:30:48 --> Final output sent to browser
DEBUG - 2016-06-10 15:30:48 --> Total execution time: 0.0502
INFO - 2016-06-10 15:33:58 --> Config Class Initialized
INFO - 2016-06-10 15:33:58 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:33:58 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:33:58 --> Utf8 Class Initialized
INFO - 2016-06-10 15:33:58 --> URI Class Initialized
DEBUG - 2016-06-10 15:33:58 --> No URI present. Default controller set.
INFO - 2016-06-10 15:33:58 --> Router Class Initialized
INFO - 2016-06-10 15:33:58 --> Output Class Initialized
INFO - 2016-06-10 15:33:58 --> Security Class Initialized
DEBUG - 2016-06-10 15:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:33:58 --> Input Class Initialized
INFO - 2016-06-10 15:33:58 --> Language Class Initialized
INFO - 2016-06-10 15:33:58 --> Loader Class Initialized
INFO - 2016-06-10 15:33:58 --> Helper loaded: form_helper
INFO - 2016-06-10 15:33:58 --> Database Driver Class Initialized
INFO - 2016-06-10 15:33:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:33:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:33:58 --> Email Class Initialized
INFO - 2016-06-10 15:33:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:33:58 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:33:58 --> Helper loaded: language_helper
INFO - 2016-06-10 15:33:58 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:33:58 --> Model Class Initialized
INFO - 2016-06-10 15:33:58 --> Helper loaded: date_helper
INFO - 2016-06-10 15:33:58 --> Controller Class Initialized
INFO - 2016-06-10 15:33:58 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:33:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:33:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:33:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:33:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:33:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:33:58 --> Model Class Initialized
INFO - 2016-06-10 15:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:34:17 --> Config Class Initialized
INFO - 2016-06-10 15:34:17 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:34:17 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:34:17 --> Utf8 Class Initialized
INFO - 2016-06-10 15:34:17 --> URI Class Initialized
DEBUG - 2016-06-10 15:34:17 --> No URI present. Default controller set.
INFO - 2016-06-10 15:34:17 --> Router Class Initialized
INFO - 2016-06-10 15:34:17 --> Output Class Initialized
INFO - 2016-06-10 15:34:17 --> Security Class Initialized
DEBUG - 2016-06-10 15:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:34:17 --> Input Class Initialized
INFO - 2016-06-10 15:34:17 --> Language Class Initialized
INFO - 2016-06-10 15:34:17 --> Loader Class Initialized
INFO - 2016-06-10 15:34:17 --> Helper loaded: form_helper
INFO - 2016-06-10 15:34:17 --> Database Driver Class Initialized
INFO - 2016-06-10 15:34:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:34:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:34:17 --> Email Class Initialized
INFO - 2016-06-10 15:34:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:34:17 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:34:17 --> Helper loaded: language_helper
INFO - 2016-06-10 15:34:17 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:34:17 --> Model Class Initialized
INFO - 2016-06-10 15:34:17 --> Helper loaded: date_helper
INFO - 2016-06-10 15:34:17 --> Controller Class Initialized
INFO - 2016-06-10 15:34:17 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:34:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:34:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:34:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:34:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:34:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:34:17 --> Model Class Initialized
INFO - 2016-06-10 15:34:17 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:34:53 --> Config Class Initialized
INFO - 2016-06-10 15:34:53 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:34:53 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:34:53 --> Utf8 Class Initialized
INFO - 2016-06-10 15:34:53 --> URI Class Initialized
DEBUG - 2016-06-10 15:34:53 --> No URI present. Default controller set.
INFO - 2016-06-10 15:34:53 --> Router Class Initialized
INFO - 2016-06-10 15:34:53 --> Output Class Initialized
INFO - 2016-06-10 15:34:53 --> Security Class Initialized
DEBUG - 2016-06-10 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:34:53 --> Input Class Initialized
INFO - 2016-06-10 15:34:53 --> Language Class Initialized
INFO - 2016-06-10 15:34:53 --> Loader Class Initialized
INFO - 2016-06-10 15:34:53 --> Helper loaded: form_helper
INFO - 2016-06-10 15:34:53 --> Database Driver Class Initialized
INFO - 2016-06-10 15:34:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:34:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:34:53 --> Email Class Initialized
INFO - 2016-06-10 15:34:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:34:53 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:34:53 --> Helper loaded: language_helper
INFO - 2016-06-10 15:34:53 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:34:53 --> Model Class Initialized
INFO - 2016-06-10 15:34:53 --> Helper loaded: date_helper
INFO - 2016-06-10 15:34:53 --> Controller Class Initialized
INFO - 2016-06-10 15:34:53 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:34:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:34:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:34:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:34:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:34:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:34:53 --> Model Class Initialized
INFO - 2016-06-10 15:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:35:03 --> Config Class Initialized
INFO - 2016-06-10 15:35:03 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:35:03 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:35:03 --> Utf8 Class Initialized
INFO - 2016-06-10 15:35:03 --> URI Class Initialized
INFO - 2016-06-10 15:35:03 --> Router Class Initialized
INFO - 2016-06-10 15:35:03 --> Output Class Initialized
INFO - 2016-06-10 15:35:03 --> Security Class Initialized
DEBUG - 2016-06-10 15:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:35:03 --> Input Class Initialized
INFO - 2016-06-10 15:35:03 --> Language Class Initialized
INFO - 2016-06-10 15:35:03 --> Loader Class Initialized
INFO - 2016-06-10 15:35:03 --> Helper loaded: form_helper
INFO - 2016-06-10 15:35:03 --> Database Driver Class Initialized
INFO - 2016-06-10 15:35:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:35:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:35:03 --> Email Class Initialized
INFO - 2016-06-10 15:35:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:35:03 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:35:03 --> Helper loaded: language_helper
INFO - 2016-06-10 15:35:03 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:35:03 --> Model Class Initialized
INFO - 2016-06-10 15:35:03 --> Helper loaded: date_helper
INFO - 2016-06-10 15:35:03 --> Controller Class Initialized
INFO - 2016-06-10 15:35:03 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:35:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:35:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:35:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:35:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:35:03 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:35:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:35:03 --> Form Validation Class Initialized
DEBUG - 2016-06-10 15:35:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:35:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 15:35:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 15:35:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 15:35:03 --> Final output sent to browser
DEBUG - 2016-06-10 15:35:03 --> Total execution time: 0.0478
INFO - 2016-06-10 15:49:44 --> Config Class Initialized
INFO - 2016-06-10 15:49:44 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:49:44 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:49:44 --> Utf8 Class Initialized
INFO - 2016-06-10 15:49:44 --> URI Class Initialized
INFO - 2016-06-10 15:49:44 --> Router Class Initialized
INFO - 2016-06-10 15:49:44 --> Output Class Initialized
INFO - 2016-06-10 15:49:44 --> Security Class Initialized
DEBUG - 2016-06-10 15:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:49:44 --> Input Class Initialized
INFO - 2016-06-10 15:49:44 --> Language Class Initialized
INFO - 2016-06-10 15:49:44 --> Loader Class Initialized
INFO - 2016-06-10 15:49:44 --> Helper loaded: form_helper
INFO - 2016-06-10 15:49:44 --> Database Driver Class Initialized
INFO - 2016-06-10 15:49:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:49:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:49:44 --> Email Class Initialized
INFO - 2016-06-10 15:49:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:49:44 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:49:44 --> Helper loaded: language_helper
INFO - 2016-06-10 15:49:44 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:49:44 --> Model Class Initialized
INFO - 2016-06-10 15:49:44 --> Helper loaded: date_helper
INFO - 2016-06-10 15:49:44 --> Controller Class Initialized
INFO - 2016-06-10 15:49:44 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:49:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:49:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:49:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:49:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:49:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 15:49:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:49:45 --> Form Validation Class Initialized
DEBUG - 2016-06-10 15:49:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:49:50 --> Config Class Initialized
INFO - 2016-06-10 15:49:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:49:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:49:50 --> Utf8 Class Initialized
INFO - 2016-06-10 15:49:50 --> URI Class Initialized
DEBUG - 2016-06-10 15:49:50 --> No URI present. Default controller set.
INFO - 2016-06-10 15:49:50 --> Router Class Initialized
INFO - 2016-06-10 15:49:50 --> Output Class Initialized
INFO - 2016-06-10 15:49:50 --> Security Class Initialized
DEBUG - 2016-06-10 15:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:49:50 --> Input Class Initialized
INFO - 2016-06-10 15:49:50 --> Language Class Initialized
INFO - 2016-06-10 15:49:50 --> Loader Class Initialized
INFO - 2016-06-10 15:49:50 --> Helper loaded: form_helper
INFO - 2016-06-10 15:49:50 --> Database Driver Class Initialized
INFO - 2016-06-10 15:49:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:49:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:49:50 --> Email Class Initialized
INFO - 2016-06-10 15:49:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:49:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:49:50 --> Helper loaded: language_helper
INFO - 2016-06-10 15:49:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:49:50 --> Model Class Initialized
INFO - 2016-06-10 15:49:50 --> Helper loaded: date_helper
INFO - 2016-06-10 15:49:50 --> Controller Class Initialized
INFO - 2016-06-10 15:49:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:49:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:49:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:49:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:49:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:49:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:49:51 --> Config Class Initialized
INFO - 2016-06-10 15:49:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:49:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:49:51 --> Utf8 Class Initialized
INFO - 2016-06-10 15:49:51 --> URI Class Initialized
INFO - 2016-06-10 15:49:51 --> Router Class Initialized
INFO - 2016-06-10 15:49:51 --> Output Class Initialized
INFO - 2016-06-10 15:49:51 --> Security Class Initialized
DEBUG - 2016-06-10 15:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:49:51 --> Input Class Initialized
INFO - 2016-06-10 15:49:51 --> Language Class Initialized
INFO - 2016-06-10 15:49:51 --> Loader Class Initialized
INFO - 2016-06-10 15:49:51 --> Helper loaded: form_helper
INFO - 2016-06-10 15:49:51 --> Database Driver Class Initialized
INFO - 2016-06-10 15:49:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:49:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:49:51 --> Email Class Initialized
INFO - 2016-06-10 15:49:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:49:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:49:51 --> Helper loaded: language_helper
INFO - 2016-06-10 15:49:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:49:51 --> Model Class Initialized
INFO - 2016-06-10 15:49:51 --> Helper loaded: date_helper
INFO - 2016-06-10 15:49:51 --> Controller Class Initialized
INFO - 2016-06-10 15:49:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:49:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:49:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:49:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:49:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:49:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:49:51 --> Model Class Initialized
INFO - 2016-06-10 15:49:51 --> Form Validation Class Initialized
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:49:51 --> Final output sent to browser
DEBUG - 2016-06-10 15:49:51 --> Total execution time: 0.1203
INFO - 2016-06-10 15:49:56 --> Config Class Initialized
INFO - 2016-06-10 15:49:56 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:49:56 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:49:56 --> Utf8 Class Initialized
INFO - 2016-06-10 15:49:56 --> URI Class Initialized
INFO - 2016-06-10 15:49:56 --> Router Class Initialized
INFO - 2016-06-10 15:49:56 --> Output Class Initialized
INFO - 2016-06-10 15:49:56 --> Security Class Initialized
DEBUG - 2016-06-10 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:49:56 --> Input Class Initialized
INFO - 2016-06-10 15:49:56 --> Language Class Initialized
INFO - 2016-06-10 15:49:56 --> Loader Class Initialized
INFO - 2016-06-10 15:49:56 --> Helper loaded: form_helper
INFO - 2016-06-10 15:49:56 --> Database Driver Class Initialized
INFO - 2016-06-10 15:49:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:49:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:49:56 --> Email Class Initialized
INFO - 2016-06-10 15:49:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:49:56 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:49:56 --> Helper loaded: language_helper
INFO - 2016-06-10 15:49:56 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:49:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:49:56 --> Model Class Initialized
INFO - 2016-06-10 15:49:56 --> Helper loaded: date_helper
INFO - 2016-06-10 15:49:56 --> Controller Class Initialized
INFO - 2016-06-10 15:49:56 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:49:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:49:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:49:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:49:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:49:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:49:56 --> Model Class Initialized
INFO - 2016-06-10 15:49:56 --> Form Validation Class Initialized
INFO - 2016-06-10 15:49:56 --> Final output sent to browser
DEBUG - 2016-06-10 15:49:56 --> Total execution time: 0.2769
INFO - 2016-06-10 15:56:13 --> Config Class Initialized
INFO - 2016-06-10 15:56:13 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:56:13 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:56:13 --> Utf8 Class Initialized
INFO - 2016-06-10 15:56:13 --> URI Class Initialized
INFO - 2016-06-10 15:56:13 --> Router Class Initialized
INFO - 2016-06-10 15:56:13 --> Output Class Initialized
INFO - 2016-06-10 15:56:13 --> Security Class Initialized
DEBUG - 2016-06-10 15:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:56:13 --> Input Class Initialized
INFO - 2016-06-10 15:56:13 --> Language Class Initialized
INFO - 2016-06-10 15:56:13 --> Loader Class Initialized
INFO - 2016-06-10 15:56:13 --> Helper loaded: form_helper
INFO - 2016-06-10 15:56:13 --> Database Driver Class Initialized
INFO - 2016-06-10 15:56:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:56:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:56:13 --> Email Class Initialized
INFO - 2016-06-10 15:56:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:56:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:56:13 --> Helper loaded: language_helper
INFO - 2016-06-10 15:56:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:56:13 --> Model Class Initialized
INFO - 2016-06-10 15:56:13 --> Helper loaded: date_helper
INFO - 2016-06-10 15:56:13 --> Controller Class Initialized
INFO - 2016-06-10 15:56:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:56:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:56:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:56:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:56:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:56:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:56:13 --> Model Class Initialized
INFO - 2016-06-10 15:56:13 --> Form Validation Class Initialized
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:56:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:56:13 --> Final output sent to browser
DEBUG - 2016-06-10 15:56:13 --> Total execution time: 0.0719
INFO - 2016-06-10 15:56:24 --> Config Class Initialized
INFO - 2016-06-10 15:56:24 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:56:24 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:56:24 --> Utf8 Class Initialized
INFO - 2016-06-10 15:56:24 --> URI Class Initialized
INFO - 2016-06-10 15:56:24 --> Router Class Initialized
INFO - 2016-06-10 15:56:24 --> Output Class Initialized
INFO - 2016-06-10 15:56:24 --> Security Class Initialized
DEBUG - 2016-06-10 15:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:56:24 --> Input Class Initialized
INFO - 2016-06-10 15:56:24 --> Language Class Initialized
INFO - 2016-06-10 15:56:24 --> Loader Class Initialized
INFO - 2016-06-10 15:56:24 --> Helper loaded: form_helper
INFO - 2016-06-10 15:56:24 --> Database Driver Class Initialized
INFO - 2016-06-10 15:56:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:56:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:56:24 --> Email Class Initialized
INFO - 2016-06-10 15:56:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:56:24 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:56:24 --> Helper loaded: language_helper
INFO - 2016-06-10 15:56:24 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:56:24 --> Model Class Initialized
INFO - 2016-06-10 15:56:24 --> Helper loaded: date_helper
INFO - 2016-06-10 15:56:24 --> Controller Class Initialized
INFO - 2016-06-10 15:56:24 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:56:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:56:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:56:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:56:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:56:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:56:24 --> Model Class Initialized
INFO - 2016-06-10 15:56:24 --> Form Validation Class Initialized
INFO - 2016-06-10 15:56:24 --> Final output sent to browser
DEBUG - 2016-06-10 15:56:24 --> Total execution time: 0.0422
INFO - 2016-06-10 15:56:40 --> Config Class Initialized
INFO - 2016-06-10 15:56:40 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:56:40 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:56:40 --> Utf8 Class Initialized
INFO - 2016-06-10 15:56:40 --> URI Class Initialized
INFO - 2016-06-10 15:56:40 --> Router Class Initialized
INFO - 2016-06-10 15:56:40 --> Output Class Initialized
INFO - 2016-06-10 15:56:40 --> Security Class Initialized
DEBUG - 2016-06-10 15:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:56:40 --> Input Class Initialized
INFO - 2016-06-10 15:56:40 --> Language Class Initialized
INFO - 2016-06-10 15:56:40 --> Loader Class Initialized
INFO - 2016-06-10 15:56:40 --> Helper loaded: form_helper
INFO - 2016-06-10 15:56:40 --> Database Driver Class Initialized
INFO - 2016-06-10 15:56:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:56:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:56:40 --> Email Class Initialized
INFO - 2016-06-10 15:56:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:56:40 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:56:40 --> Helper loaded: language_helper
INFO - 2016-06-10 15:56:40 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:56:40 --> Model Class Initialized
INFO - 2016-06-10 15:56:40 --> Helper loaded: date_helper
INFO - 2016-06-10 15:56:40 --> Controller Class Initialized
INFO - 2016-06-10 15:56:40 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:56:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:56:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:56:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:56:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:56:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:56:40 --> Model Class Initialized
INFO - 2016-06-10 15:56:40 --> Form Validation Class Initialized
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:56:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:56:40 --> Final output sent to browser
DEBUG - 2016-06-10 15:56:40 --> Total execution time: 0.0728
INFO - 2016-06-10 15:56:53 --> Config Class Initialized
INFO - 2016-06-10 15:56:53 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:56:53 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:56:53 --> Utf8 Class Initialized
INFO - 2016-06-10 15:56:53 --> URI Class Initialized
INFO - 2016-06-10 15:56:53 --> Router Class Initialized
INFO - 2016-06-10 15:56:53 --> Output Class Initialized
INFO - 2016-06-10 15:56:53 --> Security Class Initialized
DEBUG - 2016-06-10 15:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:56:53 --> Input Class Initialized
INFO - 2016-06-10 15:56:53 --> Language Class Initialized
INFO - 2016-06-10 15:56:53 --> Loader Class Initialized
INFO - 2016-06-10 15:56:53 --> Helper loaded: form_helper
INFO - 2016-06-10 15:56:53 --> Database Driver Class Initialized
INFO - 2016-06-10 15:56:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:56:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:56:53 --> Email Class Initialized
INFO - 2016-06-10 15:56:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:56:53 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:56:53 --> Helper loaded: language_helper
INFO - 2016-06-10 15:56:53 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:56:53 --> Model Class Initialized
INFO - 2016-06-10 15:56:53 --> Helper loaded: date_helper
INFO - 2016-06-10 15:56:53 --> Controller Class Initialized
INFO - 2016-06-10 15:56:53 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:56:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:56:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:56:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:56:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:56:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:56:53 --> Model Class Initialized
INFO - 2016-06-10 15:56:53 --> Form Validation Class Initialized
INFO - 2016-06-10 15:56:53 --> Final output sent to browser
DEBUG - 2016-06-10 15:56:53 --> Total execution time: 0.0359
INFO - 2016-06-10 15:57:08 --> Config Class Initialized
INFO - 2016-06-10 15:57:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:57:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:57:08 --> Utf8 Class Initialized
INFO - 2016-06-10 15:57:08 --> URI Class Initialized
INFO - 2016-06-10 15:57:08 --> Router Class Initialized
INFO - 2016-06-10 15:57:08 --> Output Class Initialized
INFO - 2016-06-10 15:57:08 --> Security Class Initialized
DEBUG - 2016-06-10 15:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:57:08 --> Input Class Initialized
INFO - 2016-06-10 15:57:08 --> Language Class Initialized
INFO - 2016-06-10 15:57:08 --> Loader Class Initialized
INFO - 2016-06-10 15:57:08 --> Helper loaded: form_helper
INFO - 2016-06-10 15:57:08 --> Database Driver Class Initialized
INFO - 2016-06-10 15:57:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:57:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:57:08 --> Email Class Initialized
INFO - 2016-06-10 15:57:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:57:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:57:08 --> Helper loaded: language_helper
INFO - 2016-06-10 15:57:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:57:08 --> Model Class Initialized
INFO - 2016-06-10 15:57:08 --> Helper loaded: date_helper
INFO - 2016-06-10 15:57:08 --> Controller Class Initialized
INFO - 2016-06-10 15:57:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:57:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:57:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:57:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:57:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:57:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:57:08 --> Model Class Initialized
INFO - 2016-06-10 15:57:08 --> Form Validation Class Initialized
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:57:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:57:08 --> Final output sent to browser
DEBUG - 2016-06-10 15:57:08 --> Total execution time: 0.0733
INFO - 2016-06-10 15:57:20 --> Config Class Initialized
INFO - 2016-06-10 15:57:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:57:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:57:20 --> Utf8 Class Initialized
INFO - 2016-06-10 15:57:20 --> URI Class Initialized
INFO - 2016-06-10 15:57:20 --> Router Class Initialized
INFO - 2016-06-10 15:57:20 --> Output Class Initialized
INFO - 2016-06-10 15:57:20 --> Security Class Initialized
DEBUG - 2016-06-10 15:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:57:20 --> Input Class Initialized
INFO - 2016-06-10 15:57:20 --> Language Class Initialized
INFO - 2016-06-10 15:57:20 --> Loader Class Initialized
INFO - 2016-06-10 15:57:20 --> Helper loaded: form_helper
INFO - 2016-06-10 15:57:20 --> Database Driver Class Initialized
INFO - 2016-06-10 15:57:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:57:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:57:20 --> Email Class Initialized
INFO - 2016-06-10 15:57:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:57:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:57:20 --> Helper loaded: language_helper
INFO - 2016-06-10 15:57:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:57:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:57:20 --> Model Class Initialized
INFO - 2016-06-10 15:57:20 --> Helper loaded: date_helper
INFO - 2016-06-10 15:57:20 --> Controller Class Initialized
INFO - 2016-06-10 15:57:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:57:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:57:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:57:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:57:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:57:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:57:20 --> Model Class Initialized
INFO - 2016-06-10 15:57:20 --> Form Validation Class Initialized
INFO - 2016-06-10 15:57:20 --> Final output sent to browser
DEBUG - 2016-06-10 15:57:20 --> Total execution time: 0.0294
INFO - 2016-06-10 15:57:48 --> Config Class Initialized
INFO - 2016-06-10 15:57:48 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:57:48 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:57:48 --> Utf8 Class Initialized
INFO - 2016-06-10 15:57:48 --> URI Class Initialized
INFO - 2016-06-10 15:57:48 --> Router Class Initialized
INFO - 2016-06-10 15:57:48 --> Output Class Initialized
INFO - 2016-06-10 15:57:48 --> Security Class Initialized
DEBUG - 2016-06-10 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:57:48 --> Input Class Initialized
INFO - 2016-06-10 15:57:48 --> Language Class Initialized
INFO - 2016-06-10 15:57:48 --> Loader Class Initialized
INFO - 2016-06-10 15:57:48 --> Helper loaded: form_helper
INFO - 2016-06-10 15:57:48 --> Database Driver Class Initialized
INFO - 2016-06-10 15:57:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:57:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:57:48 --> Email Class Initialized
INFO - 2016-06-10 15:57:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:57:48 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:57:48 --> Helper loaded: language_helper
INFO - 2016-06-10 15:57:48 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:57:48 --> Model Class Initialized
INFO - 2016-06-10 15:57:48 --> Helper loaded: date_helper
INFO - 2016-06-10 15:57:48 --> Controller Class Initialized
INFO - 2016-06-10 15:57:48 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:57:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:57:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:57:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:57:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:57:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:57:48 --> Model Class Initialized
INFO - 2016-06-10 15:57:48 --> Form Validation Class Initialized
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:57:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:57:48 --> Final output sent to browser
DEBUG - 2016-06-10 15:57:48 --> Total execution time: 0.0341
INFO - 2016-06-10 15:58:01 --> Config Class Initialized
INFO - 2016-06-10 15:58:01 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:58:01 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:58:01 --> Utf8 Class Initialized
INFO - 2016-06-10 15:58:01 --> URI Class Initialized
INFO - 2016-06-10 15:58:01 --> Router Class Initialized
INFO - 2016-06-10 15:58:01 --> Output Class Initialized
INFO - 2016-06-10 15:58:01 --> Security Class Initialized
DEBUG - 2016-06-10 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:58:01 --> Input Class Initialized
INFO - 2016-06-10 15:58:01 --> Language Class Initialized
INFO - 2016-06-10 15:58:01 --> Loader Class Initialized
INFO - 2016-06-10 15:58:01 --> Helper loaded: form_helper
INFO - 2016-06-10 15:58:01 --> Database Driver Class Initialized
INFO - 2016-06-10 15:58:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:58:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:58:01 --> Email Class Initialized
INFO - 2016-06-10 15:58:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:58:01 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:58:01 --> Helper loaded: language_helper
INFO - 2016-06-10 15:58:01 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:58:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:58:01 --> Model Class Initialized
INFO - 2016-06-10 15:58:01 --> Helper loaded: date_helper
INFO - 2016-06-10 15:58:01 --> Controller Class Initialized
INFO - 2016-06-10 15:58:01 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:58:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:58:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:58:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:58:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:58:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:58:01 --> Model Class Initialized
INFO - 2016-06-10 15:58:01 --> Form Validation Class Initialized
INFO - 2016-06-10 15:58:01 --> Final output sent to browser
DEBUG - 2016-06-10 15:58:01 --> Total execution time: 0.0776
INFO - 2016-06-10 15:58:29 --> Config Class Initialized
INFO - 2016-06-10 15:58:29 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:58:29 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:58:29 --> Utf8 Class Initialized
INFO - 2016-06-10 15:58:29 --> URI Class Initialized
INFO - 2016-06-10 15:58:29 --> Router Class Initialized
INFO - 2016-06-10 15:58:29 --> Output Class Initialized
INFO - 2016-06-10 15:58:29 --> Security Class Initialized
DEBUG - 2016-06-10 15:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:58:29 --> Input Class Initialized
INFO - 2016-06-10 15:58:29 --> Language Class Initialized
INFO - 2016-06-10 15:58:29 --> Loader Class Initialized
INFO - 2016-06-10 15:58:29 --> Helper loaded: form_helper
INFO - 2016-06-10 15:58:29 --> Database Driver Class Initialized
INFO - 2016-06-10 15:58:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:58:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:58:29 --> Email Class Initialized
INFO - 2016-06-10 15:58:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:58:29 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:58:29 --> Helper loaded: language_helper
INFO - 2016-06-10 15:58:29 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:58:29 --> Model Class Initialized
INFO - 2016-06-10 15:58:29 --> Helper loaded: date_helper
INFO - 2016-06-10 15:58:29 --> Controller Class Initialized
INFO - 2016-06-10 15:58:29 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:58:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:58:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:58:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:58:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:58:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:58:29 --> Model Class Initialized
INFO - 2016-06-10 15:58:29 --> Form Validation Class Initialized
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:58:29 --> Final output sent to browser
DEBUG - 2016-06-10 15:58:29 --> Total execution time: 0.0625
INFO - 2016-06-10 15:58:41 --> Config Class Initialized
INFO - 2016-06-10 15:58:41 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:58:41 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:58:41 --> Utf8 Class Initialized
INFO - 2016-06-10 15:58:41 --> URI Class Initialized
INFO - 2016-06-10 15:58:41 --> Router Class Initialized
INFO - 2016-06-10 15:58:41 --> Output Class Initialized
INFO - 2016-06-10 15:58:41 --> Security Class Initialized
DEBUG - 2016-06-10 15:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:58:41 --> Input Class Initialized
INFO - 2016-06-10 15:58:41 --> Language Class Initialized
INFO - 2016-06-10 15:58:41 --> Loader Class Initialized
INFO - 2016-06-10 15:58:41 --> Helper loaded: form_helper
INFO - 2016-06-10 15:58:41 --> Database Driver Class Initialized
INFO - 2016-06-10 15:58:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:58:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:58:41 --> Email Class Initialized
INFO - 2016-06-10 15:58:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:58:41 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:58:41 --> Helper loaded: language_helper
INFO - 2016-06-10 15:58:41 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:58:41 --> Model Class Initialized
INFO - 2016-06-10 15:58:41 --> Helper loaded: date_helper
INFO - 2016-06-10 15:58:41 --> Controller Class Initialized
INFO - 2016-06-10 15:58:41 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:58:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:58:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:58:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:58:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:58:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:58:41 --> Model Class Initialized
INFO - 2016-06-10 15:58:41 --> Form Validation Class Initialized
INFO - 2016-06-10 15:58:41 --> Final output sent to browser
DEBUG - 2016-06-10 15:58:41 --> Total execution time: 0.0465
INFO - 2016-06-10 15:59:13 --> Config Class Initialized
INFO - 2016-06-10 15:59:13 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:59:13 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:59:13 --> Utf8 Class Initialized
INFO - 2016-06-10 15:59:13 --> URI Class Initialized
INFO - 2016-06-10 15:59:13 --> Router Class Initialized
INFO - 2016-06-10 15:59:13 --> Output Class Initialized
INFO - 2016-06-10 15:59:13 --> Security Class Initialized
DEBUG - 2016-06-10 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:59:13 --> Input Class Initialized
INFO - 2016-06-10 15:59:13 --> Language Class Initialized
INFO - 2016-06-10 15:59:13 --> Loader Class Initialized
INFO - 2016-06-10 15:59:13 --> Helper loaded: form_helper
INFO - 2016-06-10 15:59:13 --> Database Driver Class Initialized
INFO - 2016-06-10 15:59:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:59:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:59:13 --> Email Class Initialized
INFO - 2016-06-10 15:59:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:59:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:59:13 --> Helper loaded: language_helper
INFO - 2016-06-10 15:59:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:59:13 --> Model Class Initialized
INFO - 2016-06-10 15:59:13 --> Helper loaded: date_helper
INFO - 2016-06-10 15:59:13 --> Controller Class Initialized
INFO - 2016-06-10 15:59:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:59:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:59:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:59:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:59:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:59:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:59:13 --> Model Class Initialized
INFO - 2016-06-10 15:59:13 --> Form Validation Class Initialized
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:59:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:59:13 --> Final output sent to browser
DEBUG - 2016-06-10 15:59:13 --> Total execution time: 0.1213
INFO - 2016-06-10 15:59:25 --> Config Class Initialized
INFO - 2016-06-10 15:59:25 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:59:25 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:59:25 --> Utf8 Class Initialized
INFO - 2016-06-10 15:59:25 --> URI Class Initialized
INFO - 2016-06-10 15:59:25 --> Router Class Initialized
INFO - 2016-06-10 15:59:25 --> Output Class Initialized
INFO - 2016-06-10 15:59:25 --> Security Class Initialized
DEBUG - 2016-06-10 15:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:59:25 --> Input Class Initialized
INFO - 2016-06-10 15:59:25 --> Language Class Initialized
INFO - 2016-06-10 15:59:25 --> Loader Class Initialized
INFO - 2016-06-10 15:59:25 --> Helper loaded: form_helper
INFO - 2016-06-10 15:59:25 --> Database Driver Class Initialized
INFO - 2016-06-10 15:59:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:59:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:59:26 --> Email Class Initialized
INFO - 2016-06-10 15:59:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:59:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:59:26 --> Helper loaded: language_helper
INFO - 2016-06-10 15:59:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:59:26 --> Model Class Initialized
INFO - 2016-06-10 15:59:26 --> Helper loaded: date_helper
INFO - 2016-06-10 15:59:26 --> Controller Class Initialized
INFO - 2016-06-10 15:59:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:59:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:59:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:59:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:59:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:59:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:59:26 --> Model Class Initialized
INFO - 2016-06-10 15:59:26 --> Form Validation Class Initialized
INFO - 2016-06-10 15:59:26 --> Final output sent to browser
DEBUG - 2016-06-10 15:59:26 --> Total execution time: 0.0760
INFO - 2016-06-10 15:59:28 --> Config Class Initialized
INFO - 2016-06-10 15:59:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:59:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:59:28 --> Utf8 Class Initialized
INFO - 2016-06-10 15:59:28 --> URI Class Initialized
INFO - 2016-06-10 15:59:28 --> Router Class Initialized
INFO - 2016-06-10 15:59:28 --> Output Class Initialized
INFO - 2016-06-10 15:59:28 --> Security Class Initialized
DEBUG - 2016-06-10 15:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:59:28 --> Input Class Initialized
INFO - 2016-06-10 15:59:28 --> Language Class Initialized
INFO - 2016-06-10 15:59:28 --> Loader Class Initialized
INFO - 2016-06-10 15:59:28 --> Helper loaded: form_helper
INFO - 2016-06-10 15:59:28 --> Database Driver Class Initialized
INFO - 2016-06-10 15:59:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:59:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:59:28 --> Email Class Initialized
INFO - 2016-06-10 15:59:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:59:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:59:28 --> Helper loaded: language_helper
INFO - 2016-06-10 15:59:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:59:28 --> Model Class Initialized
INFO - 2016-06-10 15:59:28 --> Helper loaded: date_helper
INFO - 2016-06-10 15:59:28 --> Controller Class Initialized
INFO - 2016-06-10 15:59:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:59:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:59:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:59:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:59:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:59:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:59:28 --> Model Class Initialized
INFO - 2016-06-10 15:59:28 --> Form Validation Class Initialized
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 15:59:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 15:59:28 --> Final output sent to browser
DEBUG - 2016-06-10 15:59:28 --> Total execution time: 0.0296
INFO - 2016-06-10 15:59:42 --> Config Class Initialized
INFO - 2016-06-10 15:59:42 --> Hooks Class Initialized
DEBUG - 2016-06-10 15:59:42 --> UTF-8 Support Enabled
INFO - 2016-06-10 15:59:42 --> Utf8 Class Initialized
INFO - 2016-06-10 15:59:42 --> URI Class Initialized
INFO - 2016-06-10 15:59:42 --> Router Class Initialized
INFO - 2016-06-10 15:59:42 --> Output Class Initialized
INFO - 2016-06-10 15:59:42 --> Security Class Initialized
DEBUG - 2016-06-10 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 15:59:42 --> Input Class Initialized
INFO - 2016-06-10 15:59:42 --> Language Class Initialized
INFO - 2016-06-10 15:59:42 --> Loader Class Initialized
INFO - 2016-06-10 15:59:42 --> Helper loaded: form_helper
INFO - 2016-06-10 15:59:42 --> Database Driver Class Initialized
INFO - 2016-06-10 15:59:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 15:59:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 15:59:42 --> Email Class Initialized
INFO - 2016-06-10 15:59:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 15:59:42 --> Helper loaded: cookie_helper
INFO - 2016-06-10 15:59:42 --> Helper loaded: language_helper
INFO - 2016-06-10 15:59:42 --> Helper loaded: url_helper
DEBUG - 2016-06-10 15:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 15:59:42 --> Model Class Initialized
INFO - 2016-06-10 15:59:42 --> Helper loaded: date_helper
INFO - 2016-06-10 15:59:42 --> Controller Class Initialized
INFO - 2016-06-10 15:59:42 --> Helper loaded: languages_helper
INFO - 2016-06-10 15:59:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 15:59:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 15:59:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 15:59:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 15:59:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 15:59:42 --> Model Class Initialized
INFO - 2016-06-10 15:59:42 --> Form Validation Class Initialized
INFO - 2016-06-10 15:59:42 --> Final output sent to browser
DEBUG - 2016-06-10 15:59:42 --> Total execution time: 0.0515
INFO - 2016-06-10 16:02:00 --> Config Class Initialized
INFO - 2016-06-10 16:02:00 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:02:00 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:02:00 --> Utf8 Class Initialized
INFO - 2016-06-10 16:02:00 --> URI Class Initialized
INFO - 2016-06-10 16:02:00 --> Router Class Initialized
INFO - 2016-06-10 16:02:00 --> Output Class Initialized
INFO - 2016-06-10 16:02:00 --> Security Class Initialized
DEBUG - 2016-06-10 16:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:02:00 --> Input Class Initialized
INFO - 2016-06-10 16:02:00 --> Language Class Initialized
INFO - 2016-06-10 16:02:00 --> Loader Class Initialized
INFO - 2016-06-10 16:02:00 --> Helper loaded: form_helper
INFO - 2016-06-10 16:02:00 --> Database Driver Class Initialized
INFO - 2016-06-10 16:02:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:02:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:02:00 --> Email Class Initialized
INFO - 2016-06-10 16:02:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:02:00 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:02:00 --> Helper loaded: language_helper
INFO - 2016-06-10 16:02:00 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:02:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:02:00 --> Model Class Initialized
INFO - 2016-06-10 16:02:00 --> Helper loaded: date_helper
INFO - 2016-06-10 16:02:00 --> Controller Class Initialized
INFO - 2016-06-10 16:02:00 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:02:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:02:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:02:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:02:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:02:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:02:00 --> Model Class Initialized
INFO - 2016-06-10 16:02:00 --> Form Validation Class Initialized
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:02:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:02:00 --> Final output sent to browser
DEBUG - 2016-06-10 16:02:00 --> Total execution time: 0.0395
INFO - 2016-06-10 16:02:13 --> Config Class Initialized
INFO - 2016-06-10 16:02:13 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:02:13 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:02:13 --> Utf8 Class Initialized
INFO - 2016-06-10 16:02:13 --> URI Class Initialized
INFO - 2016-06-10 16:02:13 --> Router Class Initialized
INFO - 2016-06-10 16:02:13 --> Output Class Initialized
INFO - 2016-06-10 16:02:13 --> Security Class Initialized
DEBUG - 2016-06-10 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:02:13 --> Input Class Initialized
INFO - 2016-06-10 16:02:13 --> Language Class Initialized
INFO - 2016-06-10 16:02:13 --> Loader Class Initialized
INFO - 2016-06-10 16:02:13 --> Helper loaded: form_helper
INFO - 2016-06-10 16:02:13 --> Database Driver Class Initialized
INFO - 2016-06-10 16:02:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:02:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:02:13 --> Email Class Initialized
INFO - 2016-06-10 16:02:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:02:13 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:02:13 --> Helper loaded: language_helper
INFO - 2016-06-10 16:02:13 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:02:13 --> Model Class Initialized
INFO - 2016-06-10 16:02:13 --> Helper loaded: date_helper
INFO - 2016-06-10 16:02:13 --> Controller Class Initialized
INFO - 2016-06-10 16:02:13 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:02:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:02:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:02:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:02:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:02:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:02:13 --> Model Class Initialized
INFO - 2016-06-10 16:02:13 --> Form Validation Class Initialized
INFO - 2016-06-10 16:02:13 --> Final output sent to browser
DEBUG - 2016-06-10 16:02:13 --> Total execution time: 0.0493
INFO - 2016-06-10 16:02:31 --> Config Class Initialized
INFO - 2016-06-10 16:02:31 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:02:31 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:02:31 --> Utf8 Class Initialized
INFO - 2016-06-10 16:02:31 --> URI Class Initialized
INFO - 2016-06-10 16:02:31 --> Router Class Initialized
INFO - 2016-06-10 16:02:31 --> Output Class Initialized
INFO - 2016-06-10 16:02:31 --> Security Class Initialized
DEBUG - 2016-06-10 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:02:31 --> Input Class Initialized
INFO - 2016-06-10 16:02:31 --> Language Class Initialized
INFO - 2016-06-10 16:02:31 --> Loader Class Initialized
INFO - 2016-06-10 16:02:31 --> Helper loaded: form_helper
INFO - 2016-06-10 16:02:31 --> Database Driver Class Initialized
INFO - 2016-06-10 16:02:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:02:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:02:31 --> Email Class Initialized
INFO - 2016-06-10 16:02:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:02:31 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:02:31 --> Helper loaded: language_helper
INFO - 2016-06-10 16:02:31 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:02:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:02:31 --> Model Class Initialized
INFO - 2016-06-10 16:02:31 --> Helper loaded: date_helper
INFO - 2016-06-10 16:02:31 --> Controller Class Initialized
INFO - 2016-06-10 16:02:31 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:02:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:02:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:02:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:02:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:02:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:02:31 --> Model Class Initialized
INFO - 2016-06-10 16:02:31 --> Form Validation Class Initialized
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:02:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:02:31 --> Final output sent to browser
DEBUG - 2016-06-10 16:02:31 --> Total execution time: 0.0695
INFO - 2016-06-10 16:02:44 --> Config Class Initialized
INFO - 2016-06-10 16:02:44 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:02:44 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:02:44 --> Utf8 Class Initialized
INFO - 2016-06-10 16:02:44 --> URI Class Initialized
INFO - 2016-06-10 16:02:44 --> Router Class Initialized
INFO - 2016-06-10 16:02:44 --> Output Class Initialized
INFO - 2016-06-10 16:02:44 --> Security Class Initialized
DEBUG - 2016-06-10 16:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:02:44 --> Input Class Initialized
INFO - 2016-06-10 16:02:44 --> Language Class Initialized
INFO - 2016-06-10 16:02:44 --> Loader Class Initialized
INFO - 2016-06-10 16:02:44 --> Helper loaded: form_helper
INFO - 2016-06-10 16:02:44 --> Database Driver Class Initialized
INFO - 2016-06-10 16:02:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:02:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:02:44 --> Email Class Initialized
INFO - 2016-06-10 16:02:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:02:44 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:02:44 --> Helper loaded: language_helper
INFO - 2016-06-10 16:02:44 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:02:44 --> Model Class Initialized
INFO - 2016-06-10 16:02:44 --> Helper loaded: date_helper
INFO - 2016-06-10 16:02:44 --> Controller Class Initialized
INFO - 2016-06-10 16:02:44 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:02:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:02:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:02:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:02:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:02:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:02:44 --> Model Class Initialized
INFO - 2016-06-10 16:02:44 --> Form Validation Class Initialized
INFO - 2016-06-10 16:02:44 --> Final output sent to browser
DEBUG - 2016-06-10 16:02:44 --> Total execution time: 0.0398
INFO - 2016-06-10 16:04:52 --> Config Class Initialized
INFO - 2016-06-10 16:04:52 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:04:52 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:04:52 --> Utf8 Class Initialized
INFO - 2016-06-10 16:04:52 --> URI Class Initialized
INFO - 2016-06-10 16:04:52 --> Router Class Initialized
INFO - 2016-06-10 16:04:52 --> Output Class Initialized
INFO - 2016-06-10 16:04:52 --> Security Class Initialized
DEBUG - 2016-06-10 16:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:04:52 --> Input Class Initialized
INFO - 2016-06-10 16:04:52 --> Language Class Initialized
INFO - 2016-06-10 16:04:52 --> Loader Class Initialized
INFO - 2016-06-10 16:04:52 --> Helper loaded: form_helper
INFO - 2016-06-10 16:04:52 --> Database Driver Class Initialized
INFO - 2016-06-10 16:04:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:04:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:04:52 --> Email Class Initialized
INFO - 2016-06-10 16:04:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:04:52 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:04:52 --> Helper loaded: language_helper
INFO - 2016-06-10 16:04:52 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:04:52 --> Model Class Initialized
INFO - 2016-06-10 16:04:52 --> Helper loaded: date_helper
INFO - 2016-06-10 16:04:52 --> Controller Class Initialized
INFO - 2016-06-10 16:04:52 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:04:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:04:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:04:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:04:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:04:52 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 16:04:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:04:52 --> Form Validation Class Initialized
INFO - 2016-06-10 16:04:54 --> Config Class Initialized
INFO - 2016-06-10 16:04:54 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:04:54 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:04:54 --> Utf8 Class Initialized
INFO - 2016-06-10 16:04:54 --> URI Class Initialized
INFO - 2016-06-10 16:04:54 --> Router Class Initialized
INFO - 2016-06-10 16:04:54 --> Output Class Initialized
INFO - 2016-06-10 16:04:54 --> Security Class Initialized
DEBUG - 2016-06-10 16:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:04:54 --> Input Class Initialized
INFO - 2016-06-10 16:04:54 --> Language Class Initialized
INFO - 2016-06-10 16:04:54 --> Loader Class Initialized
INFO - 2016-06-10 16:04:54 --> Helper loaded: form_helper
INFO - 2016-06-10 16:04:54 --> Database Driver Class Initialized
INFO - 2016-06-10 16:04:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:04:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:04:54 --> Email Class Initialized
INFO - 2016-06-10 16:04:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:04:54 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:04:54 --> Helper loaded: language_helper
INFO - 2016-06-10 16:04:54 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:04:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:04:54 --> Model Class Initialized
INFO - 2016-06-10 16:04:54 --> Helper loaded: date_helper
INFO - 2016-06-10 16:04:54 --> Controller Class Initialized
INFO - 2016-06-10 16:04:54 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:04:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:04:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:04:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:04:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:04:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 16:04:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:04:54 --> Form Validation Class Initialized
DEBUG - 2016-06-10 16:04:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:04:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:04:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 16:04:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:04:54 --> Final output sent to browser
DEBUG - 2016-06-10 16:04:54 --> Total execution time: 0.0140
INFO - 2016-06-10 16:05:12 --> Config Class Initialized
INFO - 2016-06-10 16:05:12 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:05:12 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:05:12 --> Utf8 Class Initialized
INFO - 2016-06-10 16:05:12 --> URI Class Initialized
DEBUG - 2016-06-10 16:05:12 --> No URI present. Default controller set.
INFO - 2016-06-10 16:05:12 --> Router Class Initialized
INFO - 2016-06-10 16:05:12 --> Output Class Initialized
INFO - 2016-06-10 16:05:12 --> Security Class Initialized
DEBUG - 2016-06-10 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:05:12 --> Input Class Initialized
INFO - 2016-06-10 16:05:12 --> Language Class Initialized
INFO - 2016-06-10 16:05:12 --> Loader Class Initialized
INFO - 2016-06-10 16:05:12 --> Helper loaded: form_helper
INFO - 2016-06-10 16:05:12 --> Database Driver Class Initialized
INFO - 2016-06-10 16:05:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:05:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:05:12 --> Email Class Initialized
INFO - 2016-06-10 16:05:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:05:12 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:05:12 --> Helper loaded: language_helper
INFO - 2016-06-10 16:05:12 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:05:12 --> Model Class Initialized
INFO - 2016-06-10 16:05:12 --> Helper loaded: date_helper
INFO - 2016-06-10 16:05:12 --> Controller Class Initialized
INFO - 2016-06-10 16:05:12 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:05:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:05:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:05:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:05:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:05:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:05:12 --> Model Class Initialized
INFO - 2016-06-10 16:05:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:09:45 --> Config Class Initialized
INFO - 2016-06-10 16:09:45 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:09:45 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:09:45 --> Utf8 Class Initialized
INFO - 2016-06-10 16:09:45 --> URI Class Initialized
DEBUG - 2016-06-10 16:09:45 --> No URI present. Default controller set.
INFO - 2016-06-10 16:09:45 --> Router Class Initialized
INFO - 2016-06-10 16:09:45 --> Output Class Initialized
INFO - 2016-06-10 16:09:45 --> Security Class Initialized
DEBUG - 2016-06-10 16:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:09:45 --> Input Class Initialized
INFO - 2016-06-10 16:09:45 --> Language Class Initialized
INFO - 2016-06-10 16:09:45 --> Loader Class Initialized
INFO - 2016-06-10 16:09:45 --> Helper loaded: form_helper
INFO - 2016-06-10 16:09:45 --> Database Driver Class Initialized
INFO - 2016-06-10 16:09:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:09:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:09:45 --> Email Class Initialized
INFO - 2016-06-10 16:09:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:09:45 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:09:45 --> Helper loaded: language_helper
INFO - 2016-06-10 16:09:45 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:09:45 --> Model Class Initialized
INFO - 2016-06-10 16:09:45 --> Helper loaded: date_helper
INFO - 2016-06-10 16:09:45 --> Controller Class Initialized
INFO - 2016-06-10 16:09:45 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:09:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:09:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:09:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:09:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:09:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:09:45 --> Model Class Initialized
INFO - 2016-06-10 16:09:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:09:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:09:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:09:45 --> Final output sent to browser
DEBUG - 2016-06-10 16:09:45 --> Total execution time: 0.0880
INFO - 2016-06-10 16:10:08 --> Config Class Initialized
INFO - 2016-06-10 16:10:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:10:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:10:08 --> Utf8 Class Initialized
INFO - 2016-06-10 16:10:08 --> URI Class Initialized
DEBUG - 2016-06-10 16:10:08 --> No URI present. Default controller set.
INFO - 2016-06-10 16:10:08 --> Router Class Initialized
INFO - 2016-06-10 16:10:08 --> Output Class Initialized
INFO - 2016-06-10 16:10:08 --> Security Class Initialized
DEBUG - 2016-06-10 16:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:10:08 --> Input Class Initialized
INFO - 2016-06-10 16:10:08 --> Language Class Initialized
INFO - 2016-06-10 16:10:08 --> Loader Class Initialized
INFO - 2016-06-10 16:10:08 --> Helper loaded: form_helper
INFO - 2016-06-10 16:10:08 --> Database Driver Class Initialized
INFO - 2016-06-10 16:10:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:10:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:10:08 --> Email Class Initialized
INFO - 2016-06-10 16:10:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:10:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:10:08 --> Helper loaded: language_helper
INFO - 2016-06-10 16:10:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:10:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:10:08 --> Model Class Initialized
INFO - 2016-06-10 16:10:08 --> Helper loaded: date_helper
INFO - 2016-06-10 16:10:08 --> Controller Class Initialized
INFO - 2016-06-10 16:10:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:10:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:10:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:10:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:10:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:10:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:10:08 --> Model Class Initialized
INFO - 2016-06-10 16:10:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:10:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:10:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:10:08 --> Final output sent to browser
DEBUG - 2016-06-10 16:10:08 --> Total execution time: 0.0597
INFO - 2016-06-10 16:11:37 --> Config Class Initialized
INFO - 2016-06-10 16:11:37 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:11:37 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:11:37 --> Utf8 Class Initialized
INFO - 2016-06-10 16:11:37 --> URI Class Initialized
DEBUG - 2016-06-10 16:11:37 --> No URI present. Default controller set.
INFO - 2016-06-10 16:11:37 --> Router Class Initialized
INFO - 2016-06-10 16:11:37 --> Output Class Initialized
INFO - 2016-06-10 16:11:37 --> Security Class Initialized
DEBUG - 2016-06-10 16:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:11:37 --> Input Class Initialized
INFO - 2016-06-10 16:11:37 --> Language Class Initialized
INFO - 2016-06-10 16:11:37 --> Loader Class Initialized
INFO - 2016-06-10 16:11:37 --> Helper loaded: form_helper
INFO - 2016-06-10 16:11:37 --> Database Driver Class Initialized
INFO - 2016-06-10 16:11:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:11:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:11:37 --> Email Class Initialized
INFO - 2016-06-10 16:11:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:11:37 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:11:37 --> Helper loaded: language_helper
INFO - 2016-06-10 16:11:37 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:11:37 --> Model Class Initialized
INFO - 2016-06-10 16:11:37 --> Helper loaded: date_helper
INFO - 2016-06-10 16:11:37 --> Controller Class Initialized
INFO - 2016-06-10 16:11:37 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:11:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:11:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:11:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:11:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:11:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:11:37 --> Model Class Initialized
INFO - 2016-06-10 16:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:11:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:11:37 --> Final output sent to browser
DEBUG - 2016-06-10 16:11:37 --> Total execution time: 0.0744
INFO - 2016-06-10 16:24:53 --> Config Class Initialized
INFO - 2016-06-10 16:24:53 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:24:53 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:24:53 --> Utf8 Class Initialized
INFO - 2016-06-10 16:24:53 --> URI Class Initialized
DEBUG - 2016-06-10 16:24:53 --> No URI present. Default controller set.
INFO - 2016-06-10 16:24:53 --> Router Class Initialized
INFO - 2016-06-10 16:24:53 --> Output Class Initialized
INFO - 2016-06-10 16:24:53 --> Security Class Initialized
DEBUG - 2016-06-10 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:24:53 --> Input Class Initialized
INFO - 2016-06-10 16:24:53 --> Language Class Initialized
INFO - 2016-06-10 16:24:53 --> Loader Class Initialized
INFO - 2016-06-10 16:24:53 --> Helper loaded: form_helper
INFO - 2016-06-10 16:24:53 --> Database Driver Class Initialized
INFO - 2016-06-10 16:24:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:24:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:24:53 --> Email Class Initialized
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:24:53 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:24:53 --> Helper loaded: language_helper
INFO - 2016-06-10 16:24:53 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:24:53 --> Model Class Initialized
INFO - 2016-06-10 16:24:53 --> Helper loaded: date_helper
INFO - 2016-06-10 16:24:53 --> Controller Class Initialized
INFO - 2016-06-10 16:24:53 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:24:53 --> Model Class Initialized
INFO - 2016-06-10 16:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:24:53 --> Final output sent to browser
DEBUG - 2016-06-10 16:24:53 --> Total execution time: 0.0559
INFO - 2016-06-10 16:24:53 --> Config Class Initialized
INFO - 2016-06-10 16:24:53 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:24:53 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:24:53 --> Utf8 Class Initialized
INFO - 2016-06-10 16:24:53 --> URI Class Initialized
DEBUG - 2016-06-10 16:24:53 --> No URI present. Default controller set.
INFO - 2016-06-10 16:24:53 --> Router Class Initialized
INFO - 2016-06-10 16:24:53 --> Output Class Initialized
INFO - 2016-06-10 16:24:53 --> Security Class Initialized
DEBUG - 2016-06-10 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:24:53 --> Input Class Initialized
INFO - 2016-06-10 16:24:53 --> Language Class Initialized
INFO - 2016-06-10 16:24:53 --> Loader Class Initialized
INFO - 2016-06-10 16:24:53 --> Helper loaded: form_helper
INFO - 2016-06-10 16:24:53 --> Database Driver Class Initialized
INFO - 2016-06-10 16:24:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:24:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:24:53 --> Email Class Initialized
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:24:53 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:24:53 --> Helper loaded: language_helper
INFO - 2016-06-10 16:24:53 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:24:53 --> Model Class Initialized
INFO - 2016-06-10 16:24:53 --> Helper loaded: date_helper
INFO - 2016-06-10 16:24:53 --> Controller Class Initialized
INFO - 2016-06-10 16:24:53 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:24:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:24:53 --> Model Class Initialized
INFO - 2016-06-10 16:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:24:53 --> Final output sent to browser
DEBUG - 2016-06-10 16:24:53 --> Total execution time: 0.0958
INFO - 2016-06-10 16:25:05 --> Config Class Initialized
INFO - 2016-06-10 16:25:05 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:25:05 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:25:05 --> Utf8 Class Initialized
INFO - 2016-06-10 16:25:05 --> URI Class Initialized
INFO - 2016-06-10 16:25:05 --> Router Class Initialized
INFO - 2016-06-10 16:25:05 --> Output Class Initialized
INFO - 2016-06-10 16:25:05 --> Security Class Initialized
DEBUG - 2016-06-10 16:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:25:05 --> Input Class Initialized
INFO - 2016-06-10 16:25:05 --> Language Class Initialized
INFO - 2016-06-10 16:25:05 --> Loader Class Initialized
INFO - 2016-06-10 16:25:05 --> Helper loaded: form_helper
INFO - 2016-06-10 16:25:05 --> Database Driver Class Initialized
INFO - 2016-06-10 16:25:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:25:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:25:05 --> Email Class Initialized
INFO - 2016-06-10 16:25:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:25:05 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:25:05 --> Helper loaded: language_helper
INFO - 2016-06-10 16:25:05 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:25:05 --> Model Class Initialized
INFO - 2016-06-10 16:25:05 --> Helper loaded: date_helper
INFO - 2016-06-10 16:25:05 --> Controller Class Initialized
INFO - 2016-06-10 16:25:05 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:25:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:25:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:25:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:25:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:25:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:25:05 --> Model Class Initialized
INFO - 2016-06-10 16:25:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:25:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:25:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:25:06 --> Final output sent to browser
DEBUG - 2016-06-10 16:25:06 --> Total execution time: 0.0765
INFO - 2016-06-10 16:26:20 --> Config Class Initialized
INFO - 2016-06-10 16:26:20 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:26:20 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:26:20 --> Utf8 Class Initialized
INFO - 2016-06-10 16:26:20 --> URI Class Initialized
INFO - 2016-06-10 16:26:20 --> Router Class Initialized
INFO - 2016-06-10 16:26:20 --> Output Class Initialized
INFO - 2016-06-10 16:26:20 --> Security Class Initialized
DEBUG - 2016-06-10 16:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:26:20 --> Input Class Initialized
INFO - 2016-06-10 16:26:20 --> Language Class Initialized
INFO - 2016-06-10 16:26:20 --> Loader Class Initialized
INFO - 2016-06-10 16:26:20 --> Helper loaded: form_helper
INFO - 2016-06-10 16:26:20 --> Database Driver Class Initialized
INFO - 2016-06-10 16:26:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:26:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:26:20 --> Email Class Initialized
INFO - 2016-06-10 16:26:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:26:20 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:26:20 --> Helper loaded: language_helper
INFO - 2016-06-10 16:26:20 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:26:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:26:20 --> Model Class Initialized
INFO - 2016-06-10 16:26:20 --> Helper loaded: date_helper
INFO - 2016-06-10 16:26:20 --> Controller Class Initialized
INFO - 2016-06-10 16:26:20 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:26:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:26:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:26:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:26:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:26:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:26:20 --> Model Class Initialized
INFO - 2016-06-10 16:26:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:26:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:26:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:26:20 --> Final output sent to browser
DEBUG - 2016-06-10 16:26:20 --> Total execution time: 0.0570
INFO - 2016-06-10 16:26:45 --> Config Class Initialized
INFO - 2016-06-10 16:26:45 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:26:45 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:26:45 --> Utf8 Class Initialized
INFO - 2016-06-10 16:26:45 --> URI Class Initialized
INFO - 2016-06-10 16:26:45 --> Router Class Initialized
INFO - 2016-06-10 16:26:45 --> Output Class Initialized
INFO - 2016-06-10 16:26:45 --> Security Class Initialized
DEBUG - 2016-06-10 16:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:26:45 --> Input Class Initialized
INFO - 2016-06-10 16:26:45 --> Language Class Initialized
INFO - 2016-06-10 16:26:45 --> Loader Class Initialized
INFO - 2016-06-10 16:26:45 --> Helper loaded: form_helper
INFO - 2016-06-10 16:26:45 --> Database Driver Class Initialized
INFO - 2016-06-10 16:26:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:26:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:26:45 --> Email Class Initialized
INFO - 2016-06-10 16:26:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:26:45 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:26:45 --> Helper loaded: language_helper
INFO - 2016-06-10 16:26:45 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:26:45 --> Model Class Initialized
INFO - 2016-06-10 16:26:45 --> Helper loaded: date_helper
INFO - 2016-06-10 16:26:45 --> Controller Class Initialized
INFO - 2016-06-10 16:26:45 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:26:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:26:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:26:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:26:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:26:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:26:45 --> Model Class Initialized
INFO - 2016-06-10 16:26:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:26:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:26:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:26:46 --> Final output sent to browser
DEBUG - 2016-06-10 16:26:46 --> Total execution time: 0.0364
INFO - 2016-06-10 16:27:06 --> Config Class Initialized
INFO - 2016-06-10 16:27:06 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:27:06 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:27:06 --> Utf8 Class Initialized
INFO - 2016-06-10 16:27:06 --> URI Class Initialized
INFO - 2016-06-10 16:27:06 --> Router Class Initialized
INFO - 2016-06-10 16:27:06 --> Output Class Initialized
INFO - 2016-06-10 16:27:06 --> Security Class Initialized
DEBUG - 2016-06-10 16:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:27:06 --> Input Class Initialized
INFO - 2016-06-10 16:27:06 --> Language Class Initialized
INFO - 2016-06-10 16:27:06 --> Loader Class Initialized
INFO - 2016-06-10 16:27:06 --> Helper loaded: form_helper
INFO - 2016-06-10 16:27:06 --> Database Driver Class Initialized
INFO - 2016-06-10 16:27:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:27:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:27:06 --> Email Class Initialized
INFO - 2016-06-10 16:27:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:27:06 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:27:06 --> Helper loaded: language_helper
INFO - 2016-06-10 16:27:06 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:27:06 --> Model Class Initialized
INFO - 2016-06-10 16:27:06 --> Helper loaded: date_helper
INFO - 2016-06-10 16:27:06 --> Controller Class Initialized
INFO - 2016-06-10 16:27:06 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:27:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:27:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:27:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:27:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:27:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:27:06 --> Model Class Initialized
INFO - 2016-06-10 16:27:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:27:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:27:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:27:06 --> Final output sent to browser
DEBUG - 2016-06-10 16:27:06 --> Total execution time: 0.0637
INFO - 2016-06-10 16:27:26 --> Config Class Initialized
INFO - 2016-06-10 16:27:26 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:27:26 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:27:26 --> Utf8 Class Initialized
INFO - 2016-06-10 16:27:26 --> URI Class Initialized
INFO - 2016-06-10 16:27:26 --> Router Class Initialized
INFO - 2016-06-10 16:27:26 --> Output Class Initialized
INFO - 2016-06-10 16:27:26 --> Security Class Initialized
DEBUG - 2016-06-10 16:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:27:26 --> Input Class Initialized
INFO - 2016-06-10 16:27:26 --> Language Class Initialized
INFO - 2016-06-10 16:27:26 --> Loader Class Initialized
INFO - 2016-06-10 16:27:26 --> Helper loaded: form_helper
INFO - 2016-06-10 16:27:26 --> Database Driver Class Initialized
INFO - 2016-06-10 16:27:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:27:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:27:26 --> Email Class Initialized
INFO - 2016-06-10 16:27:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:27:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:27:26 --> Helper loaded: language_helper
INFO - 2016-06-10 16:27:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:27:26 --> Model Class Initialized
INFO - 2016-06-10 16:27:26 --> Helper loaded: date_helper
INFO - 2016-06-10 16:27:26 --> Controller Class Initialized
INFO - 2016-06-10 16:27:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:27:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:27:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:27:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:27:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:27:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:27:26 --> Model Class Initialized
INFO - 2016-06-10 16:27:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:27:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:27:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:27:26 --> Final output sent to browser
DEBUG - 2016-06-10 16:27:26 --> Total execution time: 0.0317
INFO - 2016-06-10 16:27:44 --> Config Class Initialized
INFO - 2016-06-10 16:27:44 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:27:44 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:27:44 --> Utf8 Class Initialized
INFO - 2016-06-10 16:27:44 --> URI Class Initialized
INFO - 2016-06-10 16:27:44 --> Router Class Initialized
INFO - 2016-06-10 16:27:44 --> Output Class Initialized
INFO - 2016-06-10 16:27:44 --> Security Class Initialized
DEBUG - 2016-06-10 16:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:27:44 --> Input Class Initialized
INFO - 2016-06-10 16:27:44 --> Language Class Initialized
INFO - 2016-06-10 16:27:44 --> Loader Class Initialized
INFO - 2016-06-10 16:27:44 --> Helper loaded: form_helper
INFO - 2016-06-10 16:27:44 --> Database Driver Class Initialized
INFO - 2016-06-10 16:27:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:27:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:27:44 --> Email Class Initialized
INFO - 2016-06-10 16:27:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:27:44 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:27:44 --> Helper loaded: language_helper
INFO - 2016-06-10 16:27:44 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:27:44 --> Model Class Initialized
INFO - 2016-06-10 16:27:44 --> Helper loaded: date_helper
INFO - 2016-06-10 16:27:44 --> Controller Class Initialized
INFO - 2016-06-10 16:27:44 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:27:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:27:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:27:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:27:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:27:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:27:44 --> Model Class Initialized
INFO - 2016-06-10 16:27:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:27:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:27:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:27:44 --> Final output sent to browser
DEBUG - 2016-06-10 16:27:44 --> Total execution time: 0.0518
INFO - 2016-06-10 16:28:38 --> Config Class Initialized
INFO - 2016-06-10 16:28:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:28:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:28:38 --> Utf8 Class Initialized
INFO - 2016-06-10 16:28:38 --> URI Class Initialized
INFO - 2016-06-10 16:28:38 --> Router Class Initialized
INFO - 2016-06-10 16:28:38 --> Output Class Initialized
INFO - 2016-06-10 16:28:38 --> Security Class Initialized
DEBUG - 2016-06-10 16:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:28:38 --> Input Class Initialized
INFO - 2016-06-10 16:28:38 --> Language Class Initialized
INFO - 2016-06-10 16:28:38 --> Loader Class Initialized
INFO - 2016-06-10 16:28:38 --> Helper loaded: form_helper
INFO - 2016-06-10 16:28:38 --> Database Driver Class Initialized
INFO - 2016-06-10 16:28:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:28:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:28:38 --> Email Class Initialized
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:28:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:28:38 --> Helper loaded: language_helper
INFO - 2016-06-10 16:28:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:28:38 --> Model Class Initialized
INFO - 2016-06-10 16:28:38 --> Helper loaded: date_helper
INFO - 2016-06-10 16:28:38 --> Controller Class Initialized
INFO - 2016-06-10 16:28:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:28:38 --> Model Class Initialized
INFO - 2016-06-10 16:28:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:28:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:28:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:28:38 --> Final output sent to browser
DEBUG - 2016-06-10 16:28:38 --> Total execution time: 0.0548
INFO - 2016-06-10 16:28:38 --> Config Class Initialized
INFO - 2016-06-10 16:28:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:28:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:28:38 --> Utf8 Class Initialized
INFO - 2016-06-10 16:28:38 --> URI Class Initialized
INFO - 2016-06-10 16:28:38 --> Router Class Initialized
INFO - 2016-06-10 16:28:38 --> Output Class Initialized
INFO - 2016-06-10 16:28:38 --> Security Class Initialized
DEBUG - 2016-06-10 16:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:28:38 --> Input Class Initialized
INFO - 2016-06-10 16:28:38 --> Language Class Initialized
INFO - 2016-06-10 16:28:38 --> Loader Class Initialized
INFO - 2016-06-10 16:28:38 --> Helper loaded: form_helper
INFO - 2016-06-10 16:28:38 --> Database Driver Class Initialized
INFO - 2016-06-10 16:28:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:28:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:28:38 --> Email Class Initialized
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:28:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:28:38 --> Helper loaded: language_helper
INFO - 2016-06-10 16:28:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:28:38 --> Model Class Initialized
INFO - 2016-06-10 16:28:38 --> Helper loaded: date_helper
INFO - 2016-06-10 16:28:38 --> Controller Class Initialized
INFO - 2016-06-10 16:28:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:28:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:28:38 --> Model Class Initialized
INFO - 2016-06-10 16:28:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:28:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:28:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:28:38 --> Final output sent to browser
DEBUG - 2016-06-10 16:28:38 --> Total execution time: 0.1366
INFO - 2016-06-10 16:29:26 --> Config Class Initialized
INFO - 2016-06-10 16:29:26 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:29:26 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:29:26 --> Utf8 Class Initialized
INFO - 2016-06-10 16:29:26 --> URI Class Initialized
INFO - 2016-06-10 16:29:26 --> Router Class Initialized
INFO - 2016-06-10 16:29:26 --> Output Class Initialized
INFO - 2016-06-10 16:29:26 --> Security Class Initialized
DEBUG - 2016-06-10 16:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:29:26 --> Input Class Initialized
INFO - 2016-06-10 16:29:26 --> Language Class Initialized
INFO - 2016-06-10 16:29:26 --> Loader Class Initialized
INFO - 2016-06-10 16:29:26 --> Helper loaded: form_helper
INFO - 2016-06-10 16:29:26 --> Database Driver Class Initialized
INFO - 2016-06-10 16:29:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:29:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:29:26 --> Email Class Initialized
INFO - 2016-06-10 16:29:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:29:26 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:29:26 --> Helper loaded: language_helper
INFO - 2016-06-10 16:29:26 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:29:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:29:26 --> Model Class Initialized
INFO - 2016-06-10 16:29:26 --> Helper loaded: date_helper
INFO - 2016-06-10 16:29:26 --> Controller Class Initialized
INFO - 2016-06-10 16:29:26 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:29:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:29:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:29:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:29:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:29:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:29:26 --> Model Class Initialized
INFO - 2016-06-10 16:29:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:29:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:29:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:29:26 --> Final output sent to browser
DEBUG - 2016-06-10 16:29:26 --> Total execution time: 0.0543
INFO - 2016-06-10 16:29:42 --> Config Class Initialized
INFO - 2016-06-10 16:29:42 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:29:42 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:29:42 --> Utf8 Class Initialized
INFO - 2016-06-10 16:29:42 --> URI Class Initialized
INFO - 2016-06-10 16:29:42 --> Router Class Initialized
INFO - 2016-06-10 16:29:42 --> Output Class Initialized
INFO - 2016-06-10 16:29:42 --> Security Class Initialized
DEBUG - 2016-06-10 16:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:29:42 --> Input Class Initialized
INFO - 2016-06-10 16:29:42 --> Language Class Initialized
INFO - 2016-06-10 16:29:42 --> Loader Class Initialized
INFO - 2016-06-10 16:29:42 --> Helper loaded: form_helper
INFO - 2016-06-10 16:29:42 --> Database Driver Class Initialized
INFO - 2016-06-10 16:29:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:29:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:29:42 --> Email Class Initialized
INFO - 2016-06-10 16:29:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:29:42 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:29:42 --> Helper loaded: language_helper
INFO - 2016-06-10 16:29:42 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:29:42 --> Model Class Initialized
INFO - 2016-06-10 16:29:42 --> Helper loaded: date_helper
INFO - 2016-06-10 16:29:42 --> Controller Class Initialized
INFO - 2016-06-10 16:29:42 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:29:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:29:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:29:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:29:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:29:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:29:42 --> Model Class Initialized
INFO - 2016-06-10 16:29:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:29:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:29:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:29:42 --> Final output sent to browser
DEBUG - 2016-06-10 16:29:42 --> Total execution time: 0.0412
INFO - 2016-06-10 16:30:27 --> Config Class Initialized
INFO - 2016-06-10 16:30:27 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:30:27 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:30:27 --> Utf8 Class Initialized
INFO - 2016-06-10 16:30:27 --> URI Class Initialized
INFO - 2016-06-10 16:30:27 --> Router Class Initialized
INFO - 2016-06-10 16:30:27 --> Output Class Initialized
INFO - 2016-06-10 16:30:27 --> Security Class Initialized
DEBUG - 2016-06-10 16:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:30:27 --> Input Class Initialized
INFO - 2016-06-10 16:30:27 --> Language Class Initialized
INFO - 2016-06-10 16:30:27 --> Loader Class Initialized
INFO - 2016-06-10 16:30:27 --> Helper loaded: form_helper
INFO - 2016-06-10 16:30:27 --> Database Driver Class Initialized
INFO - 2016-06-10 16:30:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:30:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:30:27 --> Email Class Initialized
INFO - 2016-06-10 16:30:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:30:27 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:30:27 --> Helper loaded: language_helper
INFO - 2016-06-10 16:30:27 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:30:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:30:27 --> Model Class Initialized
INFO - 2016-06-10 16:30:27 --> Helper loaded: date_helper
INFO - 2016-06-10 16:30:27 --> Controller Class Initialized
INFO - 2016-06-10 16:30:27 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:30:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:30:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:30:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:30:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:30:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:30:27 --> Model Class Initialized
INFO - 2016-06-10 16:30:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:30:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:30:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:30:27 --> Final output sent to browser
DEBUG - 2016-06-10 16:30:27 --> Total execution time: 0.0587
INFO - 2016-06-10 16:31:42 --> Config Class Initialized
INFO - 2016-06-10 16:31:42 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:31:42 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:31:42 --> Utf8 Class Initialized
INFO - 2016-06-10 16:31:42 --> URI Class Initialized
DEBUG - 2016-06-10 16:31:42 --> No URI present. Default controller set.
INFO - 2016-06-10 16:31:42 --> Router Class Initialized
INFO - 2016-06-10 16:31:42 --> Output Class Initialized
INFO - 2016-06-10 16:31:42 --> Security Class Initialized
DEBUG - 2016-06-10 16:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:31:42 --> Input Class Initialized
INFO - 2016-06-10 16:31:42 --> Language Class Initialized
INFO - 2016-06-10 16:31:42 --> Loader Class Initialized
INFO - 2016-06-10 16:31:42 --> Helper loaded: form_helper
INFO - 2016-06-10 16:31:42 --> Database Driver Class Initialized
INFO - 2016-06-10 16:31:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:31:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:31:42 --> Email Class Initialized
INFO - 2016-06-10 16:31:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:31:43 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:31:43 --> Helper loaded: language_helper
INFO - 2016-06-10 16:31:43 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:31:43 --> Model Class Initialized
INFO - 2016-06-10 16:31:43 --> Helper loaded: date_helper
INFO - 2016-06-10 16:31:43 --> Controller Class Initialized
INFO - 2016-06-10 16:31:43 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:31:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:31:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:31:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:31:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:31:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:31:43 --> Model Class Initialized
INFO - 2016-06-10 16:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:31:43 --> Final output sent to browser
DEBUG - 2016-06-10 16:31:43 --> Total execution time: 0.0630
INFO - 2016-06-10 16:33:22 --> Config Class Initialized
INFO - 2016-06-10 16:33:22 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:33:22 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:33:22 --> Utf8 Class Initialized
INFO - 2016-06-10 16:33:22 --> URI Class Initialized
DEBUG - 2016-06-10 16:33:22 --> No URI present. Default controller set.
INFO - 2016-06-10 16:33:22 --> Router Class Initialized
INFO - 2016-06-10 16:33:22 --> Output Class Initialized
INFO - 2016-06-10 16:33:22 --> Security Class Initialized
DEBUG - 2016-06-10 16:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:33:22 --> Input Class Initialized
INFO - 2016-06-10 16:33:22 --> Language Class Initialized
INFO - 2016-06-10 16:33:22 --> Loader Class Initialized
INFO - 2016-06-10 16:33:22 --> Helper loaded: form_helper
INFO - 2016-06-10 16:33:22 --> Database Driver Class Initialized
INFO - 2016-06-10 16:33:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:33:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:33:22 --> Email Class Initialized
INFO - 2016-06-10 16:33:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:33:22 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:33:22 --> Helper loaded: language_helper
INFO - 2016-06-10 16:33:22 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:33:22 --> Model Class Initialized
INFO - 2016-06-10 16:33:22 --> Helper loaded: date_helper
INFO - 2016-06-10 16:33:22 --> Controller Class Initialized
INFO - 2016-06-10 16:33:22 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:33:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:33:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:33:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:33:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:33:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:33:22 --> Model Class Initialized
INFO - 2016-06-10 16:33:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:33:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:33:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:33:22 --> Final output sent to browser
DEBUG - 2016-06-10 16:33:22 --> Total execution time: 0.0846
INFO - 2016-06-10 16:33:28 --> Config Class Initialized
INFO - 2016-06-10 16:33:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:33:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:33:28 --> Utf8 Class Initialized
INFO - 2016-06-10 16:33:28 --> URI Class Initialized
INFO - 2016-06-10 16:33:28 --> Router Class Initialized
INFO - 2016-06-10 16:33:28 --> Output Class Initialized
INFO - 2016-06-10 16:33:28 --> Security Class Initialized
DEBUG - 2016-06-10 16:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:33:28 --> Input Class Initialized
INFO - 2016-06-10 16:33:28 --> Language Class Initialized
INFO - 2016-06-10 16:33:28 --> Loader Class Initialized
INFO - 2016-06-10 16:33:28 --> Helper loaded: form_helper
INFO - 2016-06-10 16:33:28 --> Database Driver Class Initialized
INFO - 2016-06-10 16:33:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:33:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:33:28 --> Email Class Initialized
INFO - 2016-06-10 16:33:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:33:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:33:28 --> Helper loaded: language_helper
INFO - 2016-06-10 16:33:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:33:28 --> Model Class Initialized
INFO - 2016-06-10 16:33:28 --> Helper loaded: date_helper
INFO - 2016-06-10 16:33:28 --> Controller Class Initialized
INFO - 2016-06-10 16:33:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:33:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:33:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:33:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:33:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:33:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:33:28 --> Model Class Initialized
INFO - 2016-06-10 16:33:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:33:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:33:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:33:28 --> Final output sent to browser
DEBUG - 2016-06-10 16:33:28 --> Total execution time: 0.0319
INFO - 2016-06-10 16:33:57 --> Config Class Initialized
INFO - 2016-06-10 16:33:57 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:33:57 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:33:57 --> Utf8 Class Initialized
INFO - 2016-06-10 16:33:57 --> URI Class Initialized
INFO - 2016-06-10 16:33:57 --> Router Class Initialized
INFO - 2016-06-10 16:33:57 --> Output Class Initialized
INFO - 2016-06-10 16:33:57 --> Security Class Initialized
DEBUG - 2016-06-10 16:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:33:57 --> Input Class Initialized
INFO - 2016-06-10 16:33:57 --> Language Class Initialized
INFO - 2016-06-10 16:33:57 --> Loader Class Initialized
INFO - 2016-06-10 16:33:57 --> Helper loaded: form_helper
INFO - 2016-06-10 16:33:57 --> Database Driver Class Initialized
INFO - 2016-06-10 16:33:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:33:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:33:57 --> Email Class Initialized
INFO - 2016-06-10 16:33:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:33:57 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:33:57 --> Helper loaded: language_helper
INFO - 2016-06-10 16:33:57 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:33:57 --> Model Class Initialized
INFO - 2016-06-10 16:33:57 --> Helper loaded: date_helper
INFO - 2016-06-10 16:33:57 --> Controller Class Initialized
INFO - 2016-06-10 16:33:57 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:33:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:33:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:33:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:33:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:33:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:33:57 --> Model Class Initialized
INFO - 2016-06-10 16:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:33:57 --> Final output sent to browser
DEBUG - 2016-06-10 16:33:57 --> Total execution time: 0.0536
INFO - 2016-06-10 16:34:28 --> Config Class Initialized
INFO - 2016-06-10 16:34:28 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:34:28 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:34:28 --> Utf8 Class Initialized
INFO - 2016-06-10 16:34:28 --> URI Class Initialized
INFO - 2016-06-10 16:34:28 --> Router Class Initialized
INFO - 2016-06-10 16:34:28 --> Output Class Initialized
INFO - 2016-06-10 16:34:28 --> Security Class Initialized
DEBUG - 2016-06-10 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:34:28 --> Input Class Initialized
INFO - 2016-06-10 16:34:28 --> Language Class Initialized
INFO - 2016-06-10 16:34:28 --> Loader Class Initialized
INFO - 2016-06-10 16:34:28 --> Helper loaded: form_helper
INFO - 2016-06-10 16:34:28 --> Database Driver Class Initialized
INFO - 2016-06-10 16:34:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:34:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:34:28 --> Email Class Initialized
INFO - 2016-06-10 16:34:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:34:28 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:34:28 --> Helper loaded: language_helper
INFO - 2016-06-10 16:34:28 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:34:28 --> Model Class Initialized
INFO - 2016-06-10 16:34:28 --> Helper loaded: date_helper
INFO - 2016-06-10 16:34:28 --> Controller Class Initialized
INFO - 2016-06-10 16:34:28 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:34:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:34:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:34:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:34:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:34:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:34:28 --> Model Class Initialized
INFO - 2016-06-10 16:34:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:34:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:34:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:34:28 --> Final output sent to browser
DEBUG - 2016-06-10 16:34:28 --> Total execution time: 0.0606
INFO - 2016-06-10 16:35:10 --> Config Class Initialized
INFO - 2016-06-10 16:35:10 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:35:10 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:35:10 --> Utf8 Class Initialized
INFO - 2016-06-10 16:35:10 --> URI Class Initialized
DEBUG - 2016-06-10 16:35:10 --> No URI present. Default controller set.
INFO - 2016-06-10 16:35:10 --> Router Class Initialized
INFO - 2016-06-10 16:35:10 --> Output Class Initialized
INFO - 2016-06-10 16:35:10 --> Security Class Initialized
DEBUG - 2016-06-10 16:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:35:10 --> Input Class Initialized
INFO - 2016-06-10 16:35:10 --> Language Class Initialized
INFO - 2016-06-10 16:35:10 --> Loader Class Initialized
INFO - 2016-06-10 16:35:10 --> Helper loaded: form_helper
INFO - 2016-06-10 16:35:10 --> Database Driver Class Initialized
INFO - 2016-06-10 16:35:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:35:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:35:10 --> Email Class Initialized
INFO - 2016-06-10 16:35:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:35:10 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:35:10 --> Helper loaded: language_helper
INFO - 2016-06-10 16:35:10 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:35:10 --> Model Class Initialized
INFO - 2016-06-10 16:35:10 --> Helper loaded: date_helper
INFO - 2016-06-10 16:35:10 --> Controller Class Initialized
INFO - 2016-06-10 16:35:10 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:35:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:35:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:35:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:35:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:35:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:35:10 --> Model Class Initialized
INFO - 2016-06-10 16:35:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:35:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:35:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:35:10 --> Final output sent to browser
DEBUG - 2016-06-10 16:35:10 --> Total execution time: 0.0797
INFO - 2016-06-10 16:35:34 --> Config Class Initialized
INFO - 2016-06-10 16:35:34 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:35:34 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:35:34 --> Utf8 Class Initialized
INFO - 2016-06-10 16:35:34 --> URI Class Initialized
DEBUG - 2016-06-10 16:35:34 --> No URI present. Default controller set.
INFO - 2016-06-10 16:35:34 --> Router Class Initialized
INFO - 2016-06-10 16:35:34 --> Output Class Initialized
INFO - 2016-06-10 16:35:34 --> Security Class Initialized
DEBUG - 2016-06-10 16:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:35:34 --> Input Class Initialized
INFO - 2016-06-10 16:35:34 --> Language Class Initialized
INFO - 2016-06-10 16:35:34 --> Loader Class Initialized
INFO - 2016-06-10 16:35:34 --> Helper loaded: form_helper
INFO - 2016-06-10 16:35:34 --> Database Driver Class Initialized
INFO - 2016-06-10 16:35:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:35:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:35:34 --> Email Class Initialized
INFO - 2016-06-10 16:35:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:35:34 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:35:34 --> Helper loaded: language_helper
INFO - 2016-06-10 16:35:34 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:35:34 --> Model Class Initialized
INFO - 2016-06-10 16:35:34 --> Helper loaded: date_helper
INFO - 2016-06-10 16:35:34 --> Controller Class Initialized
INFO - 2016-06-10 16:35:34 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:35:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:35:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:35:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:35:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:35:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:35:34 --> Model Class Initialized
INFO - 2016-06-10 16:35:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:35:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:35:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:35:34 --> Final output sent to browser
DEBUG - 2016-06-10 16:35:34 --> Total execution time: 0.0280
INFO - 2016-06-10 16:36:05 --> Config Class Initialized
INFO - 2016-06-10 16:36:05 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:36:05 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:36:05 --> Utf8 Class Initialized
INFO - 2016-06-10 16:36:05 --> URI Class Initialized
INFO - 2016-06-10 16:36:05 --> Router Class Initialized
INFO - 2016-06-10 16:36:05 --> Output Class Initialized
INFO - 2016-06-10 16:36:05 --> Security Class Initialized
DEBUG - 2016-06-10 16:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:36:05 --> Input Class Initialized
INFO - 2016-06-10 16:36:05 --> Language Class Initialized
INFO - 2016-06-10 16:36:05 --> Loader Class Initialized
INFO - 2016-06-10 16:36:05 --> Helper loaded: form_helper
INFO - 2016-06-10 16:36:05 --> Database Driver Class Initialized
INFO - 2016-06-10 16:36:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:36:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:36:05 --> Email Class Initialized
INFO - 2016-06-10 16:36:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:36:05 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:36:05 --> Helper loaded: language_helper
INFO - 2016-06-10 16:36:05 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:36:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:36:05 --> Model Class Initialized
INFO - 2016-06-10 16:36:05 --> Helper loaded: date_helper
INFO - 2016-06-10 16:36:05 --> Controller Class Initialized
INFO - 2016-06-10 16:36:05 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:36:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:36:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:36:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:36:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:36:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:36:05 --> Model Class Initialized
INFO - 2016-06-10 16:36:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:36:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:36:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:36:05 --> Final output sent to browser
DEBUG - 2016-06-10 16:36:05 --> Total execution time: 0.0438
INFO - 2016-06-10 16:36:50 --> Config Class Initialized
INFO - 2016-06-10 16:36:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:36:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:36:50 --> Utf8 Class Initialized
INFO - 2016-06-10 16:36:50 --> URI Class Initialized
INFO - 2016-06-10 16:36:50 --> Router Class Initialized
INFO - 2016-06-10 16:36:50 --> Output Class Initialized
INFO - 2016-06-10 16:36:50 --> Security Class Initialized
DEBUG - 2016-06-10 16:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:36:50 --> Input Class Initialized
INFO - 2016-06-10 16:36:50 --> Language Class Initialized
INFO - 2016-06-10 16:36:50 --> Loader Class Initialized
INFO - 2016-06-10 16:36:50 --> Helper loaded: form_helper
INFO - 2016-06-10 16:36:50 --> Database Driver Class Initialized
INFO - 2016-06-10 16:36:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:36:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:36:50 --> Email Class Initialized
INFO - 2016-06-10 16:36:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:36:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:36:50 --> Helper loaded: language_helper
INFO - 2016-06-10 16:36:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:36:50 --> Model Class Initialized
INFO - 2016-06-10 16:36:50 --> Helper loaded: date_helper
INFO - 2016-06-10 16:36:50 --> Controller Class Initialized
INFO - 2016-06-10 16:36:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:36:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:36:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:36:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:36:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:36:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:36:50 --> Model Class Initialized
INFO - 2016-06-10 16:36:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:36:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:36:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:36:50 --> Final output sent to browser
DEBUG - 2016-06-10 16:36:50 --> Total execution time: 0.0428
INFO - 2016-06-10 16:37:05 --> Config Class Initialized
INFO - 2016-06-10 16:37:05 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:37:05 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:37:05 --> Utf8 Class Initialized
INFO - 2016-06-10 16:37:05 --> URI Class Initialized
INFO - 2016-06-10 16:37:05 --> Router Class Initialized
INFO - 2016-06-10 16:37:05 --> Output Class Initialized
INFO - 2016-06-10 16:37:05 --> Security Class Initialized
DEBUG - 2016-06-10 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:37:05 --> Input Class Initialized
INFO - 2016-06-10 16:37:05 --> Language Class Initialized
INFO - 2016-06-10 16:37:05 --> Loader Class Initialized
INFO - 2016-06-10 16:37:05 --> Helper loaded: form_helper
INFO - 2016-06-10 16:37:05 --> Database Driver Class Initialized
INFO - 2016-06-10 16:37:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:37:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:37:05 --> Email Class Initialized
INFO - 2016-06-10 16:37:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:37:05 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:37:05 --> Helper loaded: language_helper
INFO - 2016-06-10 16:37:05 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:37:05 --> Model Class Initialized
INFO - 2016-06-10 16:37:05 --> Helper loaded: date_helper
INFO - 2016-06-10 16:37:05 --> Controller Class Initialized
INFO - 2016-06-10 16:37:05 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:37:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:37:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:37:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:37:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:37:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:37:05 --> Model Class Initialized
INFO - 2016-06-10 16:37:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:37:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:37:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:37:05 --> Final output sent to browser
DEBUG - 2016-06-10 16:37:05 --> Total execution time: 0.1145
INFO - 2016-06-10 16:37:42 --> Config Class Initialized
INFO - 2016-06-10 16:37:42 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:37:42 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:37:42 --> Utf8 Class Initialized
INFO - 2016-06-10 16:37:42 --> URI Class Initialized
INFO - 2016-06-10 16:37:42 --> Router Class Initialized
INFO - 2016-06-10 16:37:42 --> Output Class Initialized
INFO - 2016-06-10 16:37:42 --> Security Class Initialized
DEBUG - 2016-06-10 16:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:37:42 --> Input Class Initialized
INFO - 2016-06-10 16:37:42 --> Language Class Initialized
INFO - 2016-06-10 16:37:42 --> Loader Class Initialized
INFO - 2016-06-10 16:37:42 --> Helper loaded: form_helper
INFO - 2016-06-10 16:37:42 --> Database Driver Class Initialized
INFO - 2016-06-10 16:37:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:37:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:37:43 --> Email Class Initialized
INFO - 2016-06-10 16:37:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:37:43 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:37:43 --> Helper loaded: language_helper
INFO - 2016-06-10 16:37:43 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:37:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:37:43 --> Model Class Initialized
INFO - 2016-06-10 16:37:43 --> Helper loaded: date_helper
INFO - 2016-06-10 16:37:43 --> Controller Class Initialized
INFO - 2016-06-10 16:37:43 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:37:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:37:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:37:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:37:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:37:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:37:43 --> Model Class Initialized
INFO - 2016-06-10 16:37:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:37:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/post_view.php
INFO - 2016-06-10 16:37:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:37:43 --> Final output sent to browser
DEBUG - 2016-06-10 16:37:43 --> Total execution time: 0.0664
INFO - 2016-06-10 16:38:02 --> Config Class Initialized
INFO - 2016-06-10 16:38:02 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:38:02 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:38:02 --> Utf8 Class Initialized
INFO - 2016-06-10 16:38:02 --> URI Class Initialized
DEBUG - 2016-06-10 16:38:02 --> No URI present. Default controller set.
INFO - 2016-06-10 16:38:02 --> Router Class Initialized
INFO - 2016-06-10 16:38:02 --> Output Class Initialized
INFO - 2016-06-10 16:38:02 --> Security Class Initialized
DEBUG - 2016-06-10 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:38:02 --> Input Class Initialized
INFO - 2016-06-10 16:38:02 --> Language Class Initialized
INFO - 2016-06-10 16:38:02 --> Loader Class Initialized
INFO - 2016-06-10 16:38:02 --> Helper loaded: form_helper
INFO - 2016-06-10 16:38:02 --> Database Driver Class Initialized
INFO - 2016-06-10 16:38:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:38:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:38:02 --> Email Class Initialized
INFO - 2016-06-10 16:38:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:38:02 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:38:02 --> Helper loaded: language_helper
INFO - 2016-06-10 16:38:02 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:38:02 --> Model Class Initialized
INFO - 2016-06-10 16:38:02 --> Helper loaded: date_helper
INFO - 2016-06-10 16:38:02 --> Controller Class Initialized
INFO - 2016-06-10 16:38:02 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:38:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:38:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:38:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:38:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:38:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:38:02 --> Model Class Initialized
INFO - 2016-06-10 16:38:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:38:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-10 16:38:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:38:02 --> Final output sent to browser
DEBUG - 2016-06-10 16:38:02 --> Total execution time: 0.0967
INFO - 2016-06-10 16:40:25 --> Config Class Initialized
INFO - 2016-06-10 16:40:25 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:40:25 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:40:25 --> Utf8 Class Initialized
INFO - 2016-06-10 16:40:25 --> URI Class Initialized
INFO - 2016-06-10 16:40:25 --> Router Class Initialized
INFO - 2016-06-10 16:40:25 --> Output Class Initialized
INFO - 2016-06-10 16:40:25 --> Security Class Initialized
DEBUG - 2016-06-10 16:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:40:25 --> Input Class Initialized
INFO - 2016-06-10 16:40:25 --> Language Class Initialized
INFO - 2016-06-10 16:40:25 --> Loader Class Initialized
INFO - 2016-06-10 16:40:25 --> Helper loaded: form_helper
INFO - 2016-06-10 16:40:25 --> Database Driver Class Initialized
INFO - 2016-06-10 16:40:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:40:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:40:25 --> Email Class Initialized
INFO - 2016-06-10 16:40:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:40:25 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:40:25 --> Helper loaded: language_helper
INFO - 2016-06-10 16:40:25 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:40:25 --> Model Class Initialized
INFO - 2016-06-10 16:40:25 --> Helper loaded: date_helper
INFO - 2016-06-10 16:40:25 --> Controller Class Initialized
INFO - 2016-06-10 16:40:25 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:40:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:40:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:40:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:40:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:40:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 16:40:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:40:25 --> Form Validation Class Initialized
DEBUG - 2016-06-10 16:40:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:40:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:40:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 16:40:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:40:25 --> Final output sent to browser
DEBUG - 2016-06-10 16:40:25 --> Total execution time: 0.0501
INFO - 2016-06-10 16:40:58 --> Config Class Initialized
INFO - 2016-06-10 16:40:58 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:40:58 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:40:58 --> Utf8 Class Initialized
INFO - 2016-06-10 16:40:58 --> URI Class Initialized
INFO - 2016-06-10 16:40:58 --> Router Class Initialized
INFO - 2016-06-10 16:40:58 --> Output Class Initialized
INFO - 2016-06-10 16:40:58 --> Security Class Initialized
DEBUG - 2016-06-10 16:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:40:58 --> Input Class Initialized
INFO - 2016-06-10 16:40:58 --> Language Class Initialized
INFO - 2016-06-10 16:40:58 --> Loader Class Initialized
INFO - 2016-06-10 16:40:58 --> Helper loaded: form_helper
INFO - 2016-06-10 16:40:58 --> Database Driver Class Initialized
INFO - 2016-06-10 16:40:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:40:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:40:58 --> Email Class Initialized
INFO - 2016-06-10 16:40:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:40:58 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:40:58 --> Helper loaded: language_helper
INFO - 2016-06-10 16:40:58 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:40:58 --> Model Class Initialized
INFO - 2016-06-10 16:40:58 --> Helper loaded: date_helper
INFO - 2016-06-10 16:40:58 --> Controller Class Initialized
INFO - 2016-06-10 16:40:58 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:40:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:40:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:40:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:40:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:40:58 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 16:40:58 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:40:58 --> Form Validation Class Initialized
DEBUG - 2016-06-10 16:40:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:41:07 --> Config Class Initialized
INFO - 2016-06-10 16:41:07 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:41:07 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:41:07 --> Utf8 Class Initialized
INFO - 2016-06-10 16:41:07 --> URI Class Initialized
DEBUG - 2016-06-10 16:41:07 --> No URI present. Default controller set.
INFO - 2016-06-10 16:41:07 --> Router Class Initialized
INFO - 2016-06-10 16:41:07 --> Output Class Initialized
INFO - 2016-06-10 16:41:07 --> Security Class Initialized
DEBUG - 2016-06-10 16:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:41:07 --> Input Class Initialized
INFO - 2016-06-10 16:41:07 --> Language Class Initialized
INFO - 2016-06-10 16:41:07 --> Loader Class Initialized
INFO - 2016-06-10 16:41:07 --> Helper loaded: form_helper
INFO - 2016-06-10 16:41:08 --> Database Driver Class Initialized
INFO - 2016-06-10 16:41:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:41:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:41:08 --> Email Class Initialized
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:41:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:41:08 --> Helper loaded: language_helper
INFO - 2016-06-10 16:41:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:41:08 --> Model Class Initialized
INFO - 2016-06-10 16:41:08 --> Helper loaded: date_helper
INFO - 2016-06-10 16:41:08 --> Controller Class Initialized
INFO - 2016-06-10 16:41:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:41:08 --> Config Class Initialized
INFO - 2016-06-10 16:41:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:41:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:41:08 --> Utf8 Class Initialized
INFO - 2016-06-10 16:41:08 --> URI Class Initialized
INFO - 2016-06-10 16:41:08 --> Router Class Initialized
INFO - 2016-06-10 16:41:08 --> Output Class Initialized
INFO - 2016-06-10 16:41:08 --> Security Class Initialized
DEBUG - 2016-06-10 16:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:41:08 --> Input Class Initialized
INFO - 2016-06-10 16:41:08 --> Language Class Initialized
INFO - 2016-06-10 16:41:08 --> Loader Class Initialized
INFO - 2016-06-10 16:41:08 --> Helper loaded: form_helper
INFO - 2016-06-10 16:41:08 --> Database Driver Class Initialized
INFO - 2016-06-10 16:41:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:41:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:41:08 --> Email Class Initialized
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:41:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:41:08 --> Helper loaded: language_helper
INFO - 2016-06-10 16:41:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:41:08 --> Model Class Initialized
INFO - 2016-06-10 16:41:08 --> Helper loaded: date_helper
INFO - 2016-06-10 16:41:08 --> Controller Class Initialized
INFO - 2016-06-10 16:41:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:41:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:41:08 --> Model Class Initialized
INFO - 2016-06-10 16:41:08 --> Form Validation Class Initialized
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-10 16:41:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:41:08 --> Final output sent to browser
DEBUG - 2016-06-10 16:41:09 --> Total execution time: 0.0929
INFO - 2016-06-10 16:41:14 --> Config Class Initialized
INFO - 2016-06-10 16:41:14 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:41:14 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:41:14 --> Utf8 Class Initialized
INFO - 2016-06-10 16:41:14 --> URI Class Initialized
INFO - 2016-06-10 16:41:14 --> Router Class Initialized
INFO - 2016-06-10 16:41:14 --> Output Class Initialized
INFO - 2016-06-10 16:41:14 --> Security Class Initialized
DEBUG - 2016-06-10 16:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:41:14 --> Input Class Initialized
INFO - 2016-06-10 16:41:14 --> Language Class Initialized
INFO - 2016-06-10 16:41:14 --> Loader Class Initialized
INFO - 2016-06-10 16:41:14 --> Helper loaded: form_helper
INFO - 2016-06-10 16:41:14 --> Database Driver Class Initialized
INFO - 2016-06-10 16:41:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:41:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:41:14 --> Email Class Initialized
INFO - 2016-06-10 16:41:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:41:14 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:41:14 --> Helper loaded: language_helper
INFO - 2016-06-10 16:41:14 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:41:14 --> Model Class Initialized
INFO - 2016-06-10 16:41:14 --> Helper loaded: date_helper
INFO - 2016-06-10 16:41:14 --> Controller Class Initialized
INFO - 2016-06-10 16:41:14 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:41:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:41:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:41:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:41:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:41:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:41:14 --> Model Class Initialized
INFO - 2016-06-10 16:41:14 --> Form Validation Class Initialized
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 16:41:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:41:14 --> Final output sent to browser
DEBUG - 2016-06-10 16:41:14 --> Total execution time: 0.0477
INFO - 2016-06-10 16:41:24 --> Config Class Initialized
INFO - 2016-06-10 16:41:24 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:41:24 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:41:24 --> Utf8 Class Initialized
INFO - 2016-06-10 16:41:24 --> URI Class Initialized
INFO - 2016-06-10 16:41:24 --> Router Class Initialized
INFO - 2016-06-10 16:41:24 --> Output Class Initialized
INFO - 2016-06-10 16:41:24 --> Security Class Initialized
DEBUG - 2016-06-10 16:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:41:24 --> Input Class Initialized
INFO - 2016-06-10 16:41:24 --> Language Class Initialized
INFO - 2016-06-10 16:41:24 --> Loader Class Initialized
INFO - 2016-06-10 16:41:24 --> Helper loaded: form_helper
INFO - 2016-06-10 16:41:24 --> Database Driver Class Initialized
INFO - 2016-06-10 16:41:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:41:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:41:24 --> Email Class Initialized
INFO - 2016-06-10 16:41:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:41:24 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:41:24 --> Helper loaded: language_helper
INFO - 2016-06-10 16:41:24 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:41:24 --> Model Class Initialized
INFO - 2016-06-10 16:41:24 --> Helper loaded: date_helper
INFO - 2016-06-10 16:41:24 --> Controller Class Initialized
INFO - 2016-06-10 16:41:24 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:41:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:41:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:41:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:41:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:41:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:41:24 --> Model Class Initialized
INFO - 2016-06-10 16:41:24 --> Form Validation Class Initialized
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-10 16:41:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:41:24 --> Final output sent to browser
DEBUG - 2016-06-10 16:41:24 --> Total execution time: 0.0714
INFO - 2016-06-10 16:41:42 --> Config Class Initialized
INFO - 2016-06-10 16:41:42 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:41:42 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:41:42 --> Utf8 Class Initialized
INFO - 2016-06-10 16:41:42 --> URI Class Initialized
INFO - 2016-06-10 16:41:42 --> Router Class Initialized
INFO - 2016-06-10 16:41:42 --> Output Class Initialized
INFO - 2016-06-10 16:41:42 --> Security Class Initialized
DEBUG - 2016-06-10 16:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:41:42 --> Input Class Initialized
INFO - 2016-06-10 16:41:42 --> Language Class Initialized
INFO - 2016-06-10 16:41:42 --> Loader Class Initialized
INFO - 2016-06-10 16:41:42 --> Helper loaded: form_helper
INFO - 2016-06-10 16:41:42 --> Database Driver Class Initialized
INFO - 2016-06-10 16:41:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:41:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:41:42 --> Email Class Initialized
INFO - 2016-06-10 16:41:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:41:42 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:41:42 --> Helper loaded: language_helper
INFO - 2016-06-10 16:41:42 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:41:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:41:42 --> Model Class Initialized
INFO - 2016-06-10 16:41:42 --> Helper loaded: date_helper
INFO - 2016-06-10 16:41:42 --> Controller Class Initialized
INFO - 2016-06-10 16:41:42 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:41:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:41:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:41:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:41:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:41:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:41:42 --> Model Class Initialized
INFO - 2016-06-10 16:41:42 --> Form Validation Class Initialized
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-10 16:41:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:41:42 --> Final output sent to browser
DEBUG - 2016-06-10 16:41:42 --> Total execution time: 0.0682
INFO - 2016-06-10 16:42:43 --> Config Class Initialized
INFO - 2016-06-10 16:42:43 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:42:43 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:42:43 --> Utf8 Class Initialized
INFO - 2016-06-10 16:42:43 --> URI Class Initialized
INFO - 2016-06-10 16:42:43 --> Router Class Initialized
INFO - 2016-06-10 16:42:43 --> Output Class Initialized
INFO - 2016-06-10 16:42:43 --> Security Class Initialized
DEBUG - 2016-06-10 16:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:42:43 --> Input Class Initialized
INFO - 2016-06-10 16:42:43 --> Language Class Initialized
INFO - 2016-06-10 16:42:43 --> Loader Class Initialized
INFO - 2016-06-10 16:42:43 --> Helper loaded: form_helper
INFO - 2016-06-10 16:42:43 --> Database Driver Class Initialized
INFO - 2016-06-10 16:42:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:42:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:42:43 --> Email Class Initialized
INFO - 2016-06-10 16:42:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:42:43 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:42:43 --> Helper loaded: language_helper
INFO - 2016-06-10 16:42:43 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:42:43 --> Model Class Initialized
INFO - 2016-06-10 16:42:43 --> Helper loaded: date_helper
INFO - 2016-06-10 16:42:43 --> Controller Class Initialized
INFO - 2016-06-10 16:42:43 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:42:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:42:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:42:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:42:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:42:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 16:42:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:42:43 --> Form Validation Class Initialized
INFO - 2016-06-10 16:42:52 --> Config Class Initialized
INFO - 2016-06-10 16:42:52 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:42:52 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:42:52 --> Utf8 Class Initialized
INFO - 2016-06-10 16:42:52 --> URI Class Initialized
INFO - 2016-06-10 16:42:52 --> Router Class Initialized
INFO - 2016-06-10 16:42:52 --> Output Class Initialized
INFO - 2016-06-10 16:42:52 --> Security Class Initialized
DEBUG - 2016-06-10 16:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:42:52 --> Input Class Initialized
INFO - 2016-06-10 16:42:52 --> Language Class Initialized
INFO - 2016-06-10 16:42:52 --> Loader Class Initialized
INFO - 2016-06-10 16:42:52 --> Helper loaded: form_helper
INFO - 2016-06-10 16:42:52 --> Database Driver Class Initialized
INFO - 2016-06-10 16:42:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:42:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:42:52 --> Email Class Initialized
INFO - 2016-06-10 16:42:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:42:52 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:42:52 --> Helper loaded: language_helper
INFO - 2016-06-10 16:42:52 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:42:52 --> Model Class Initialized
INFO - 2016-06-10 16:42:52 --> Helper loaded: date_helper
INFO - 2016-06-10 16:42:52 --> Controller Class Initialized
INFO - 2016-06-10 16:42:52 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:42:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:42:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:42:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:42:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:42:52 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 16:42:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:42:52 --> Form Validation Class Initialized
DEBUG - 2016-06-10 16:42:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:42:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 16:42:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 16:42:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 16:42:52 --> Final output sent to browser
DEBUG - 2016-06-10 16:42:52 --> Total execution time: 0.1166
INFO - 2016-06-10 16:43:10 --> Config Class Initialized
INFO - 2016-06-10 16:43:10 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:43:10 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:43:10 --> Utf8 Class Initialized
INFO - 2016-06-10 16:43:10 --> URI Class Initialized
INFO - 2016-06-10 16:43:10 --> Router Class Initialized
INFO - 2016-06-10 16:43:10 --> Output Class Initialized
INFO - 2016-06-10 16:43:10 --> Security Class Initialized
DEBUG - 2016-06-10 16:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:43:10 --> Input Class Initialized
INFO - 2016-06-10 16:43:10 --> Language Class Initialized
INFO - 2016-06-10 16:43:10 --> Loader Class Initialized
INFO - 2016-06-10 16:43:10 --> Helper loaded: form_helper
INFO - 2016-06-10 16:43:10 --> Database Driver Class Initialized
INFO - 2016-06-10 16:43:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:43:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:43:10 --> Email Class Initialized
INFO - 2016-06-10 16:43:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:43:10 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:43:10 --> Helper loaded: language_helper
INFO - 2016-06-10 16:43:10 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:43:10 --> Model Class Initialized
INFO - 2016-06-10 16:43:10 --> Helper loaded: date_helper
INFO - 2016-06-10 16:43:10 --> Controller Class Initialized
INFO - 2016-06-10 16:43:10 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:43:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:43:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:43:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:43:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:43:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 16:43:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:43:10 --> Form Validation Class Initialized
DEBUG - 2016-06-10 16:43:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:43:19 --> Config Class Initialized
INFO - 2016-06-10 16:43:19 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:43:19 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:43:19 --> Utf8 Class Initialized
INFO - 2016-06-10 16:43:19 --> URI Class Initialized
DEBUG - 2016-06-10 16:43:19 --> No URI present. Default controller set.
INFO - 2016-06-10 16:43:19 --> Router Class Initialized
INFO - 2016-06-10 16:43:19 --> Output Class Initialized
INFO - 2016-06-10 16:43:19 --> Security Class Initialized
DEBUG - 2016-06-10 16:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:43:19 --> Input Class Initialized
INFO - 2016-06-10 16:43:19 --> Language Class Initialized
INFO - 2016-06-10 16:43:19 --> Loader Class Initialized
INFO - 2016-06-10 16:43:19 --> Helper loaded: form_helper
INFO - 2016-06-10 16:43:19 --> Database Driver Class Initialized
INFO - 2016-06-10 16:43:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:43:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:43:19 --> Email Class Initialized
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:43:19 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:43:19 --> Helper loaded: language_helper
INFO - 2016-06-10 16:43:19 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:43:19 --> Model Class Initialized
INFO - 2016-06-10 16:43:19 --> Helper loaded: date_helper
INFO - 2016-06-10 16:43:19 --> Controller Class Initialized
INFO - 2016-06-10 16:43:19 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:43:19 --> Config Class Initialized
INFO - 2016-06-10 16:43:19 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:43:19 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:43:19 --> Utf8 Class Initialized
INFO - 2016-06-10 16:43:19 --> URI Class Initialized
INFO - 2016-06-10 16:43:19 --> Router Class Initialized
INFO - 2016-06-10 16:43:19 --> Output Class Initialized
INFO - 2016-06-10 16:43:19 --> Security Class Initialized
DEBUG - 2016-06-10 16:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:43:19 --> Input Class Initialized
INFO - 2016-06-10 16:43:19 --> Language Class Initialized
INFO - 2016-06-10 16:43:19 --> Loader Class Initialized
INFO - 2016-06-10 16:43:19 --> Helper loaded: form_helper
INFO - 2016-06-10 16:43:19 --> Database Driver Class Initialized
INFO - 2016-06-10 16:43:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:43:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:43:19 --> Email Class Initialized
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:43:19 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:43:19 --> Helper loaded: language_helper
INFO - 2016-06-10 16:43:19 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:43:19 --> Model Class Initialized
INFO - 2016-06-10 16:43:19 --> Helper loaded: date_helper
INFO - 2016-06-10 16:43:19 --> Controller Class Initialized
INFO - 2016-06-10 16:43:19 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:43:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:43:19 --> Model Class Initialized
INFO - 2016-06-10 16:43:19 --> Form Validation Class Initialized
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:43:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:43:19 --> Final output sent to browser
DEBUG - 2016-06-10 16:43:19 --> Total execution time: 0.1200
INFO - 2016-06-10 16:43:25 --> Config Class Initialized
INFO - 2016-06-10 16:43:25 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:43:25 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:43:25 --> Utf8 Class Initialized
INFO - 2016-06-10 16:43:25 --> URI Class Initialized
INFO - 2016-06-10 16:43:25 --> Router Class Initialized
INFO - 2016-06-10 16:43:25 --> Output Class Initialized
INFO - 2016-06-10 16:43:25 --> Security Class Initialized
DEBUG - 2016-06-10 16:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:43:25 --> Input Class Initialized
INFO - 2016-06-10 16:43:25 --> Language Class Initialized
INFO - 2016-06-10 16:43:25 --> Loader Class Initialized
INFO - 2016-06-10 16:43:25 --> Helper loaded: form_helper
INFO - 2016-06-10 16:43:25 --> Database Driver Class Initialized
INFO - 2016-06-10 16:43:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:43:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:43:25 --> Email Class Initialized
INFO - 2016-06-10 16:43:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:43:25 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:43:25 --> Helper loaded: language_helper
INFO - 2016-06-10 16:43:25 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:43:25 --> Model Class Initialized
INFO - 2016-06-10 16:43:25 --> Helper loaded: date_helper
INFO - 2016-06-10 16:43:25 --> Controller Class Initialized
INFO - 2016-06-10 16:43:25 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:43:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:43:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:43:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:43:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:43:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:43:25 --> Model Class Initialized
INFO - 2016-06-10 16:43:25 --> Form Validation Class Initialized
INFO - 2016-06-10 16:43:25 --> Final output sent to browser
DEBUG - 2016-06-10 16:43:25 --> Total execution time: 0.0688
INFO - 2016-06-10 16:43:46 --> Config Class Initialized
INFO - 2016-06-10 16:43:46 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:43:46 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:43:46 --> Utf8 Class Initialized
INFO - 2016-06-10 16:43:46 --> URI Class Initialized
INFO - 2016-06-10 16:43:46 --> Router Class Initialized
INFO - 2016-06-10 16:43:46 --> Output Class Initialized
INFO - 2016-06-10 16:43:46 --> Security Class Initialized
DEBUG - 2016-06-10 16:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:43:46 --> Input Class Initialized
INFO - 2016-06-10 16:43:46 --> Language Class Initialized
INFO - 2016-06-10 16:43:46 --> Loader Class Initialized
INFO - 2016-06-10 16:43:46 --> Helper loaded: form_helper
INFO - 2016-06-10 16:43:46 --> Database Driver Class Initialized
INFO - 2016-06-10 16:43:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:43:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:43:47 --> Email Class Initialized
INFO - 2016-06-10 16:43:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:43:47 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:43:47 --> Helper loaded: language_helper
INFO - 2016-06-10 16:43:47 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:43:47 --> Model Class Initialized
INFO - 2016-06-10 16:43:47 --> Helper loaded: date_helper
INFO - 2016-06-10 16:43:47 --> Controller Class Initialized
INFO - 2016-06-10 16:43:47 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:43:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:43:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:43:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:43:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:43:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:43:47 --> Model Class Initialized
INFO - 2016-06-10 16:43:47 --> Form Validation Class Initialized
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:43:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:43:47 --> Final output sent to browser
DEBUG - 2016-06-10 16:43:47 --> Total execution time: 0.0616
INFO - 2016-06-10 16:44:00 --> Config Class Initialized
INFO - 2016-06-10 16:44:00 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:44:00 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:44:00 --> Utf8 Class Initialized
INFO - 2016-06-10 16:44:00 --> URI Class Initialized
INFO - 2016-06-10 16:44:00 --> Router Class Initialized
INFO - 2016-06-10 16:44:00 --> Output Class Initialized
INFO - 2016-06-10 16:44:00 --> Security Class Initialized
DEBUG - 2016-06-10 16:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:44:00 --> Input Class Initialized
INFO - 2016-06-10 16:44:00 --> Language Class Initialized
INFO - 2016-06-10 16:44:00 --> Loader Class Initialized
INFO - 2016-06-10 16:44:00 --> Helper loaded: form_helper
INFO - 2016-06-10 16:44:00 --> Database Driver Class Initialized
INFO - 2016-06-10 16:44:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:44:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:44:00 --> Email Class Initialized
INFO - 2016-06-10 16:44:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:44:00 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:44:00 --> Helper loaded: language_helper
INFO - 2016-06-10 16:44:00 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:44:00 --> Model Class Initialized
INFO - 2016-06-10 16:44:00 --> Helper loaded: date_helper
INFO - 2016-06-10 16:44:00 --> Controller Class Initialized
INFO - 2016-06-10 16:44:00 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:44:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:44:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:44:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:44:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:44:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:44:00 --> Model Class Initialized
INFO - 2016-06-10 16:44:00 --> Form Validation Class Initialized
INFO - 2016-06-10 16:44:00 --> Final output sent to browser
DEBUG - 2016-06-10 16:44:00 --> Total execution time: 0.0843
INFO - 2016-06-10 16:44:21 --> Config Class Initialized
INFO - 2016-06-10 16:44:21 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:44:21 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:44:21 --> Utf8 Class Initialized
INFO - 2016-06-10 16:44:21 --> URI Class Initialized
INFO - 2016-06-10 16:44:21 --> Router Class Initialized
INFO - 2016-06-10 16:44:21 --> Output Class Initialized
INFO - 2016-06-10 16:44:21 --> Security Class Initialized
DEBUG - 2016-06-10 16:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:44:21 --> Input Class Initialized
INFO - 2016-06-10 16:44:21 --> Language Class Initialized
INFO - 2016-06-10 16:44:21 --> Loader Class Initialized
INFO - 2016-06-10 16:44:21 --> Helper loaded: form_helper
INFO - 2016-06-10 16:44:21 --> Database Driver Class Initialized
INFO - 2016-06-10 16:44:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:44:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:44:21 --> Email Class Initialized
INFO - 2016-06-10 16:44:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:44:21 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:44:21 --> Helper loaded: language_helper
INFO - 2016-06-10 16:44:21 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:44:21 --> Model Class Initialized
INFO - 2016-06-10 16:44:21 --> Helper loaded: date_helper
INFO - 2016-06-10 16:44:21 --> Controller Class Initialized
INFO - 2016-06-10 16:44:21 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:44:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:44:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:44:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:44:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:44:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:44:21 --> Model Class Initialized
INFO - 2016-06-10 16:44:21 --> Form Validation Class Initialized
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:44:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:44:21 --> Final output sent to browser
DEBUG - 2016-06-10 16:44:21 --> Total execution time: 0.0972
INFO - 2016-06-10 16:44:35 --> Config Class Initialized
INFO - 2016-06-10 16:44:35 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:44:35 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:44:35 --> Utf8 Class Initialized
INFO - 2016-06-10 16:44:35 --> URI Class Initialized
INFO - 2016-06-10 16:44:35 --> Router Class Initialized
INFO - 2016-06-10 16:44:35 --> Output Class Initialized
INFO - 2016-06-10 16:44:35 --> Security Class Initialized
DEBUG - 2016-06-10 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:44:35 --> Input Class Initialized
INFO - 2016-06-10 16:44:35 --> Language Class Initialized
INFO - 2016-06-10 16:44:35 --> Loader Class Initialized
INFO - 2016-06-10 16:44:35 --> Helper loaded: form_helper
INFO - 2016-06-10 16:44:35 --> Database Driver Class Initialized
INFO - 2016-06-10 16:44:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:44:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:44:35 --> Email Class Initialized
INFO - 2016-06-10 16:44:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:44:35 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:44:35 --> Helper loaded: language_helper
INFO - 2016-06-10 16:44:35 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:44:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:44:35 --> Model Class Initialized
INFO - 2016-06-10 16:44:35 --> Helper loaded: date_helper
INFO - 2016-06-10 16:44:35 --> Controller Class Initialized
INFO - 2016-06-10 16:44:35 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:44:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:44:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:44:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:44:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:44:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:44:35 --> Model Class Initialized
INFO - 2016-06-10 16:44:35 --> Form Validation Class Initialized
INFO - 2016-06-10 16:44:35 --> Final output sent to browser
DEBUG - 2016-06-10 16:44:35 --> Total execution time: 0.0927
INFO - 2016-06-10 16:46:18 --> Config Class Initialized
INFO - 2016-06-10 16:46:18 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:46:18 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:46:18 --> Utf8 Class Initialized
INFO - 2016-06-10 16:46:18 --> URI Class Initialized
INFO - 2016-06-10 16:46:18 --> Router Class Initialized
INFO - 2016-06-10 16:46:18 --> Output Class Initialized
INFO - 2016-06-10 16:46:18 --> Security Class Initialized
DEBUG - 2016-06-10 16:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:46:18 --> Input Class Initialized
INFO - 2016-06-10 16:46:18 --> Language Class Initialized
INFO - 2016-06-10 16:46:18 --> Loader Class Initialized
INFO - 2016-06-10 16:46:18 --> Helper loaded: form_helper
INFO - 2016-06-10 16:46:18 --> Database Driver Class Initialized
INFO - 2016-06-10 16:46:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:46:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:46:18 --> Email Class Initialized
INFO - 2016-06-10 16:46:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:46:18 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:46:18 --> Helper loaded: language_helper
INFO - 2016-06-10 16:46:18 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:46:18 --> Model Class Initialized
INFO - 2016-06-10 16:46:18 --> Helper loaded: date_helper
INFO - 2016-06-10 16:46:18 --> Controller Class Initialized
INFO - 2016-06-10 16:46:18 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:46:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:46:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:46:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:46:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:46:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:46:18 --> Model Class Initialized
INFO - 2016-06-10 16:46:18 --> Form Validation Class Initialized
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:46:18 --> Final output sent to browser
DEBUG - 2016-06-10 16:46:18 --> Total execution time: 0.0568
INFO - 2016-06-10 16:46:33 --> Config Class Initialized
INFO - 2016-06-10 16:46:33 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:46:33 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:46:33 --> Utf8 Class Initialized
INFO - 2016-06-10 16:46:33 --> URI Class Initialized
INFO - 2016-06-10 16:46:33 --> Router Class Initialized
INFO - 2016-06-10 16:46:33 --> Output Class Initialized
INFO - 2016-06-10 16:46:33 --> Security Class Initialized
DEBUG - 2016-06-10 16:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:46:33 --> Input Class Initialized
INFO - 2016-06-10 16:46:33 --> Language Class Initialized
INFO - 2016-06-10 16:46:33 --> Loader Class Initialized
INFO - 2016-06-10 16:46:33 --> Helper loaded: form_helper
INFO - 2016-06-10 16:46:33 --> Database Driver Class Initialized
INFO - 2016-06-10 16:46:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:46:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:46:33 --> Email Class Initialized
INFO - 2016-06-10 16:46:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:46:33 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:46:33 --> Helper loaded: language_helper
INFO - 2016-06-10 16:46:33 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:46:33 --> Model Class Initialized
INFO - 2016-06-10 16:46:33 --> Helper loaded: date_helper
INFO - 2016-06-10 16:46:33 --> Controller Class Initialized
INFO - 2016-06-10 16:46:33 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:46:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:46:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:46:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:46:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:46:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:46:33 --> Model Class Initialized
INFO - 2016-06-10 16:46:33 --> Form Validation Class Initialized
INFO - 2016-06-10 16:46:33 --> Final output sent to browser
DEBUG - 2016-06-10 16:46:33 --> Total execution time: 0.0410
INFO - 2016-06-10 16:47:15 --> Config Class Initialized
INFO - 2016-06-10 16:47:15 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:47:15 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:47:15 --> Utf8 Class Initialized
INFO - 2016-06-10 16:47:15 --> URI Class Initialized
INFO - 2016-06-10 16:47:15 --> Router Class Initialized
INFO - 2016-06-10 16:47:15 --> Output Class Initialized
INFO - 2016-06-10 16:47:15 --> Security Class Initialized
DEBUG - 2016-06-10 16:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:47:15 --> Input Class Initialized
INFO - 2016-06-10 16:47:15 --> Language Class Initialized
INFO - 2016-06-10 16:47:15 --> Loader Class Initialized
INFO - 2016-06-10 16:47:15 --> Helper loaded: form_helper
INFO - 2016-06-10 16:47:15 --> Database Driver Class Initialized
INFO - 2016-06-10 16:47:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:47:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:47:16 --> Email Class Initialized
INFO - 2016-06-10 16:47:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:47:16 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:47:16 --> Helper loaded: language_helper
INFO - 2016-06-10 16:47:16 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:47:16 --> Model Class Initialized
INFO - 2016-06-10 16:47:16 --> Helper loaded: date_helper
INFO - 2016-06-10 16:47:16 --> Controller Class Initialized
INFO - 2016-06-10 16:47:16 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:47:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:47:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:47:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:47:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:47:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:47:16 --> Model Class Initialized
INFO - 2016-06-10 16:47:16 --> Form Validation Class Initialized
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:47:16 --> Final output sent to browser
DEBUG - 2016-06-10 16:47:16 --> Total execution time: 0.0729
INFO - 2016-06-10 16:47:22 --> Config Class Initialized
INFO - 2016-06-10 16:47:22 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:47:22 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:47:22 --> Utf8 Class Initialized
INFO - 2016-06-10 16:47:22 --> URI Class Initialized
INFO - 2016-06-10 16:47:22 --> Router Class Initialized
INFO - 2016-06-10 16:47:22 --> Output Class Initialized
INFO - 2016-06-10 16:47:22 --> Security Class Initialized
DEBUG - 2016-06-10 16:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:47:22 --> Input Class Initialized
INFO - 2016-06-10 16:47:22 --> Language Class Initialized
INFO - 2016-06-10 16:47:22 --> Loader Class Initialized
INFO - 2016-06-10 16:47:22 --> Helper loaded: form_helper
INFO - 2016-06-10 16:47:22 --> Database Driver Class Initialized
INFO - 2016-06-10 16:47:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:47:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:47:22 --> Email Class Initialized
INFO - 2016-06-10 16:47:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:47:22 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:47:22 --> Helper loaded: language_helper
INFO - 2016-06-10 16:47:22 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:47:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:47:22 --> Model Class Initialized
INFO - 2016-06-10 16:47:22 --> Helper loaded: date_helper
INFO - 2016-06-10 16:47:22 --> Controller Class Initialized
INFO - 2016-06-10 16:47:22 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:47:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:47:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:47:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:47:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:47:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:47:22 --> Model Class Initialized
INFO - 2016-06-10 16:47:22 --> Form Validation Class Initialized
INFO - 2016-06-10 16:47:22 --> Final output sent to browser
DEBUG - 2016-06-10 16:47:22 --> Total execution time: 0.1613
INFO - 2016-06-10 16:47:32 --> Config Class Initialized
INFO - 2016-06-10 16:47:32 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:47:32 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:47:32 --> Utf8 Class Initialized
INFO - 2016-06-10 16:47:32 --> URI Class Initialized
INFO - 2016-06-10 16:47:32 --> Router Class Initialized
INFO - 2016-06-10 16:47:32 --> Output Class Initialized
INFO - 2016-06-10 16:47:32 --> Security Class Initialized
DEBUG - 2016-06-10 16:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:47:32 --> Input Class Initialized
INFO - 2016-06-10 16:47:32 --> Language Class Initialized
INFO - 2016-06-10 16:47:32 --> Loader Class Initialized
INFO - 2016-06-10 16:47:32 --> Helper loaded: form_helper
INFO - 2016-06-10 16:47:32 --> Database Driver Class Initialized
INFO - 2016-06-10 16:47:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:47:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:47:32 --> Email Class Initialized
INFO - 2016-06-10 16:47:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:47:32 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:47:32 --> Helper loaded: language_helper
INFO - 2016-06-10 16:47:32 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:47:32 --> Model Class Initialized
INFO - 2016-06-10 16:47:32 --> Helper loaded: date_helper
INFO - 2016-06-10 16:47:32 --> Controller Class Initialized
INFO - 2016-06-10 16:47:32 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:47:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:47:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:47:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:47:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:47:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:47:32 --> Model Class Initialized
INFO - 2016-06-10 16:47:32 --> Form Validation Class Initialized
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 16:47:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 16:47:32 --> Final output sent to browser
DEBUG - 2016-06-10 16:47:32 --> Total execution time: 0.0516
INFO - 2016-06-10 16:47:47 --> Config Class Initialized
INFO - 2016-06-10 16:47:47 --> Hooks Class Initialized
DEBUG - 2016-06-10 16:47:47 --> UTF-8 Support Enabled
INFO - 2016-06-10 16:47:47 --> Utf8 Class Initialized
INFO - 2016-06-10 16:47:47 --> URI Class Initialized
INFO - 2016-06-10 16:47:47 --> Router Class Initialized
INFO - 2016-06-10 16:47:47 --> Output Class Initialized
INFO - 2016-06-10 16:47:47 --> Security Class Initialized
DEBUG - 2016-06-10 16:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 16:47:47 --> Input Class Initialized
INFO - 2016-06-10 16:47:47 --> Language Class Initialized
INFO - 2016-06-10 16:47:47 --> Loader Class Initialized
INFO - 2016-06-10 16:47:47 --> Helper loaded: form_helper
INFO - 2016-06-10 16:47:47 --> Database Driver Class Initialized
INFO - 2016-06-10 16:47:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 16:47:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 16:47:47 --> Email Class Initialized
INFO - 2016-06-10 16:47:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 16:47:47 --> Helper loaded: cookie_helper
INFO - 2016-06-10 16:47:47 --> Helper loaded: language_helper
INFO - 2016-06-10 16:47:47 --> Helper loaded: url_helper
DEBUG - 2016-06-10 16:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 16:47:47 --> Model Class Initialized
INFO - 2016-06-10 16:47:47 --> Helper loaded: date_helper
INFO - 2016-06-10 16:47:47 --> Controller Class Initialized
INFO - 2016-06-10 16:47:47 --> Helper loaded: languages_helper
INFO - 2016-06-10 16:47:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 16:47:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 16:47:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 16:47:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 16:47:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 16:47:47 --> Model Class Initialized
INFO - 2016-06-10 16:47:47 --> Form Validation Class Initialized
INFO - 2016-06-10 16:47:47 --> Final output sent to browser
DEBUG - 2016-06-10 16:47:47 --> Total execution time: 0.0346
INFO - 2016-06-10 17:08:21 --> Config Class Initialized
INFO - 2016-06-10 17:08:21 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:08:21 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:08:21 --> Utf8 Class Initialized
INFO - 2016-06-10 17:08:21 --> URI Class Initialized
INFO - 2016-06-10 17:08:21 --> Router Class Initialized
INFO - 2016-06-10 17:08:21 --> Output Class Initialized
INFO - 2016-06-10 17:08:21 --> Security Class Initialized
DEBUG - 2016-06-10 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:08:21 --> Input Class Initialized
INFO - 2016-06-10 17:08:21 --> Language Class Initialized
INFO - 2016-06-10 17:08:21 --> Loader Class Initialized
INFO - 2016-06-10 17:08:21 --> Helper loaded: form_helper
INFO - 2016-06-10 17:08:21 --> Database Driver Class Initialized
INFO - 2016-06-10 17:08:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:08:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:08:21 --> Email Class Initialized
INFO - 2016-06-10 17:08:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:08:21 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:08:21 --> Helper loaded: language_helper
INFO - 2016-06-10 17:08:21 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:08:21 --> Model Class Initialized
INFO - 2016-06-10 17:08:21 --> Helper loaded: date_helper
INFO - 2016-06-10 17:08:21 --> Controller Class Initialized
INFO - 2016-06-10 17:08:21 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:08:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:08:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:08:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:08:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:08:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 17:08:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:08:21 --> Form Validation Class Initialized
INFO - 2016-06-10 17:08:21 --> Config Class Initialized
INFO - 2016-06-10 17:08:21 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:08:21 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:08:21 --> Utf8 Class Initialized
INFO - 2016-06-10 17:08:21 --> URI Class Initialized
INFO - 2016-06-10 17:08:21 --> Router Class Initialized
INFO - 2016-06-10 17:08:21 --> Output Class Initialized
INFO - 2016-06-10 17:08:21 --> Security Class Initialized
DEBUG - 2016-06-10 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:08:21 --> Input Class Initialized
INFO - 2016-06-10 17:08:21 --> Language Class Initialized
INFO - 2016-06-10 17:08:21 --> Loader Class Initialized
INFO - 2016-06-10 17:08:22 --> Helper loaded: form_helper
INFO - 2016-06-10 17:08:22 --> Database Driver Class Initialized
INFO - 2016-06-10 17:08:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:08:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:08:22 --> Email Class Initialized
INFO - 2016-06-10 17:08:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:08:22 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:08:22 --> Helper loaded: language_helper
INFO - 2016-06-10 17:08:22 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:08:22 --> Model Class Initialized
INFO - 2016-06-10 17:08:22 --> Helper loaded: date_helper
INFO - 2016-06-10 17:08:22 --> Controller Class Initialized
INFO - 2016-06-10 17:08:22 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:08:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:08:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:08:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:08:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:08:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 17:08:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:08:22 --> Form Validation Class Initialized
DEBUG - 2016-06-10 17:08:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:08:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 17:08:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 17:08:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 17:08:22 --> Final output sent to browser
DEBUG - 2016-06-10 17:08:22 --> Total execution time: 0.0675
INFO - 2016-06-10 17:30:37 --> Config Class Initialized
INFO - 2016-06-10 17:30:37 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:30:37 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:30:37 --> Utf8 Class Initialized
INFO - 2016-06-10 17:30:37 --> URI Class Initialized
INFO - 2016-06-10 17:30:37 --> Router Class Initialized
INFO - 2016-06-10 17:30:37 --> Output Class Initialized
INFO - 2016-06-10 17:30:37 --> Security Class Initialized
DEBUG - 2016-06-10 17:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:30:37 --> Input Class Initialized
INFO - 2016-06-10 17:30:37 --> Language Class Initialized
INFO - 2016-06-10 17:30:37 --> Loader Class Initialized
INFO - 2016-06-10 17:30:37 --> Helper loaded: form_helper
INFO - 2016-06-10 17:30:37 --> Database Driver Class Initialized
INFO - 2016-06-10 17:30:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:30:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:30:37 --> Email Class Initialized
INFO - 2016-06-10 17:30:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:30:37 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:30:37 --> Helper loaded: language_helper
INFO - 2016-06-10 17:30:37 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:30:37 --> Model Class Initialized
INFO - 2016-06-10 17:30:37 --> Helper loaded: date_helper
INFO - 2016-06-10 17:30:37 --> Controller Class Initialized
INFO - 2016-06-10 17:30:37 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:30:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:30:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:30:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:30:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:30:37 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 17:30:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:30:37 --> Form Validation Class Initialized
DEBUG - 2016-06-10 17:30:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:30:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 17:30:37 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 17:30:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 17:30:37 --> Final output sent to browser
DEBUG - 2016-06-10 17:30:37 --> Total execution time: 0.0706
INFO - 2016-06-10 17:35:35 --> Config Class Initialized
INFO - 2016-06-10 17:35:35 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:35:35 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:35:35 --> Utf8 Class Initialized
INFO - 2016-06-10 17:35:35 --> URI Class Initialized
INFO - 2016-06-10 17:35:35 --> Router Class Initialized
INFO - 2016-06-10 17:35:35 --> Output Class Initialized
INFO - 2016-06-10 17:35:35 --> Security Class Initialized
DEBUG - 2016-06-10 17:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:35:35 --> Input Class Initialized
INFO - 2016-06-10 17:35:35 --> Language Class Initialized
INFO - 2016-06-10 17:35:35 --> Loader Class Initialized
INFO - 2016-06-10 17:35:35 --> Helper loaded: form_helper
INFO - 2016-06-10 17:35:35 --> Database Driver Class Initialized
INFO - 2016-06-10 17:35:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:35:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:35:35 --> Email Class Initialized
INFO - 2016-06-10 17:35:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:35:35 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:35:35 --> Helper loaded: language_helper
INFO - 2016-06-10 17:35:35 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:35:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:35:35 --> Model Class Initialized
INFO - 2016-06-10 17:35:35 --> Helper loaded: date_helper
INFO - 2016-06-10 17:35:35 --> Controller Class Initialized
INFO - 2016-06-10 17:35:35 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:35:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:35:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:35:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:35:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:35:35 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 17:35:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:35:35 --> Form Validation Class Initialized
DEBUG - 2016-06-10 17:35:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:35:36 --> Config Class Initialized
INFO - 2016-06-10 17:35:36 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:35:36 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:35:36 --> Utf8 Class Initialized
INFO - 2016-06-10 17:35:36 --> URI Class Initialized
DEBUG - 2016-06-10 17:35:36 --> No URI present. Default controller set.
INFO - 2016-06-10 17:35:36 --> Router Class Initialized
INFO - 2016-06-10 17:35:36 --> Output Class Initialized
INFO - 2016-06-10 17:35:36 --> Security Class Initialized
DEBUG - 2016-06-10 17:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:35:36 --> Input Class Initialized
INFO - 2016-06-10 17:35:36 --> Language Class Initialized
INFO - 2016-06-10 17:35:36 --> Loader Class Initialized
INFO - 2016-06-10 17:35:36 --> Helper loaded: form_helper
INFO - 2016-06-10 17:35:36 --> Database Driver Class Initialized
INFO - 2016-06-10 17:35:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:35:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:35:36 --> Email Class Initialized
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:35:36 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:35:36 --> Helper loaded: language_helper
INFO - 2016-06-10 17:35:36 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:35:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:35:36 --> Model Class Initialized
INFO - 2016-06-10 17:35:36 --> Helper loaded: date_helper
INFO - 2016-06-10 17:35:36 --> Controller Class Initialized
INFO - 2016-06-10 17:35:36 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:35:36 --> Config Class Initialized
INFO - 2016-06-10 17:35:36 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:35:36 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:35:36 --> Utf8 Class Initialized
INFO - 2016-06-10 17:35:36 --> URI Class Initialized
INFO - 2016-06-10 17:35:36 --> Router Class Initialized
INFO - 2016-06-10 17:35:36 --> Output Class Initialized
INFO - 2016-06-10 17:35:36 --> Security Class Initialized
DEBUG - 2016-06-10 17:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:35:36 --> Input Class Initialized
INFO - 2016-06-10 17:35:36 --> Language Class Initialized
INFO - 2016-06-10 17:35:36 --> Loader Class Initialized
INFO - 2016-06-10 17:35:36 --> Helper loaded: form_helper
INFO - 2016-06-10 17:35:36 --> Database Driver Class Initialized
INFO - 2016-06-10 17:35:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:35:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:35:36 --> Email Class Initialized
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:35:36 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:35:36 --> Helper loaded: language_helper
INFO - 2016-06-10 17:35:36 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:35:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:35:36 --> Model Class Initialized
INFO - 2016-06-10 17:35:36 --> Helper loaded: date_helper
INFO - 2016-06-10 17:35:36 --> Controller Class Initialized
INFO - 2016-06-10 17:35:36 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:35:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:35:36 --> Model Class Initialized
INFO - 2016-06-10 17:35:36 --> Form Validation Class Initialized
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-10 17:35:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 17:35:36 --> Final output sent to browser
DEBUG - 2016-06-10 17:35:36 --> Total execution time: 0.0377
INFO - 2016-06-10 17:57:03 --> Config Class Initialized
INFO - 2016-06-10 17:57:03 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:57:03 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:57:03 --> Utf8 Class Initialized
INFO - 2016-06-10 17:57:03 --> URI Class Initialized
INFO - 2016-06-10 17:57:03 --> Router Class Initialized
INFO - 2016-06-10 17:57:03 --> Output Class Initialized
INFO - 2016-06-10 17:57:03 --> Security Class Initialized
DEBUG - 2016-06-10 17:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:57:03 --> Input Class Initialized
INFO - 2016-06-10 17:57:03 --> Language Class Initialized
INFO - 2016-06-10 17:57:03 --> Loader Class Initialized
INFO - 2016-06-10 17:57:03 --> Helper loaded: form_helper
INFO - 2016-06-10 17:57:03 --> Database Driver Class Initialized
INFO - 2016-06-10 17:57:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:57:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:57:03 --> Email Class Initialized
INFO - 2016-06-10 17:57:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:57:03 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:57:03 --> Helper loaded: language_helper
INFO - 2016-06-10 17:57:03 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:03 --> Model Class Initialized
INFO - 2016-06-10 17:57:03 --> Helper loaded: date_helper
INFO - 2016-06-10 17:57:03 --> Controller Class Initialized
INFO - 2016-06-10 17:57:03 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:57:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:57:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:57:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:57:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:57:03 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 17:57:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:03 --> Form Validation Class Initialized
INFO - 2016-06-10 17:57:04 --> Config Class Initialized
INFO - 2016-06-10 17:57:04 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:57:04 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:57:04 --> Utf8 Class Initialized
INFO - 2016-06-10 17:57:04 --> URI Class Initialized
INFO - 2016-06-10 17:57:04 --> Router Class Initialized
INFO - 2016-06-10 17:57:04 --> Output Class Initialized
INFO - 2016-06-10 17:57:04 --> Security Class Initialized
DEBUG - 2016-06-10 17:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:57:04 --> Input Class Initialized
INFO - 2016-06-10 17:57:04 --> Language Class Initialized
INFO - 2016-06-10 17:57:04 --> Loader Class Initialized
INFO - 2016-06-10 17:57:04 --> Helper loaded: form_helper
INFO - 2016-06-10 17:57:04 --> Database Driver Class Initialized
INFO - 2016-06-10 17:57:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:57:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:57:04 --> Email Class Initialized
INFO - 2016-06-10 17:57:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:57:04 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:57:04 --> Helper loaded: language_helper
INFO - 2016-06-10 17:57:04 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:04 --> Model Class Initialized
INFO - 2016-06-10 17:57:04 --> Helper loaded: date_helper
INFO - 2016-06-10 17:57:04 --> Controller Class Initialized
INFO - 2016-06-10 17:57:04 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:57:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:57:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:57:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:57:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:57:04 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 17:57:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:04 --> Form Validation Class Initialized
DEBUG - 2016-06-10 17:57:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 17:57:04 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 17:57:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 17:57:04 --> Final output sent to browser
DEBUG - 2016-06-10 17:57:04 --> Total execution time: 0.0353
INFO - 2016-06-10 17:57:31 --> Config Class Initialized
INFO - 2016-06-10 17:57:31 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:57:31 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:57:31 --> Utf8 Class Initialized
INFO - 2016-06-10 17:57:31 --> URI Class Initialized
INFO - 2016-06-10 17:57:31 --> Router Class Initialized
INFO - 2016-06-10 17:57:31 --> Output Class Initialized
INFO - 2016-06-10 17:57:31 --> Security Class Initialized
DEBUG - 2016-06-10 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:57:31 --> Input Class Initialized
INFO - 2016-06-10 17:57:31 --> Language Class Initialized
INFO - 2016-06-10 17:57:31 --> Loader Class Initialized
INFO - 2016-06-10 17:57:31 --> Helper loaded: form_helper
INFO - 2016-06-10 17:57:31 --> Database Driver Class Initialized
INFO - 2016-06-10 17:57:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:57:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:57:31 --> Email Class Initialized
INFO - 2016-06-10 17:57:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:57:31 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:57:31 --> Helper loaded: language_helper
INFO - 2016-06-10 17:57:31 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:31 --> Model Class Initialized
INFO - 2016-06-10 17:57:31 --> Helper loaded: date_helper
INFO - 2016-06-10 17:57:31 --> Controller Class Initialized
INFO - 2016-06-10 17:57:31 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:57:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:57:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:57:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:57:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:57:31 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-10 17:57:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:31 --> Form Validation Class Initialized
DEBUG - 2016-06-10 17:57:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:38 --> Config Class Initialized
INFO - 2016-06-10 17:57:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:57:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:57:38 --> Utf8 Class Initialized
INFO - 2016-06-10 17:57:38 --> URI Class Initialized
DEBUG - 2016-06-10 17:57:38 --> No URI present. Default controller set.
INFO - 2016-06-10 17:57:38 --> Router Class Initialized
INFO - 2016-06-10 17:57:38 --> Output Class Initialized
INFO - 2016-06-10 17:57:38 --> Security Class Initialized
DEBUG - 2016-06-10 17:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:57:38 --> Input Class Initialized
INFO - 2016-06-10 17:57:38 --> Language Class Initialized
INFO - 2016-06-10 17:57:38 --> Loader Class Initialized
INFO - 2016-06-10 17:57:38 --> Helper loaded: form_helper
INFO - 2016-06-10 17:57:38 --> Database Driver Class Initialized
INFO - 2016-06-10 17:57:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:57:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:57:38 --> Email Class Initialized
INFO - 2016-06-10 17:57:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:57:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:57:38 --> Helper loaded: language_helper
INFO - 2016-06-10 17:57:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:38 --> Model Class Initialized
INFO - 2016-06-10 17:57:38 --> Helper loaded: date_helper
INFO - 2016-06-10 17:57:38 --> Controller Class Initialized
INFO - 2016-06-10 17:57:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:57:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:57:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:57:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:57:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:57:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:57:39 --> Config Class Initialized
INFO - 2016-06-10 17:57:39 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:57:39 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:57:39 --> Utf8 Class Initialized
INFO - 2016-06-10 17:57:39 --> URI Class Initialized
INFO - 2016-06-10 17:57:39 --> Router Class Initialized
INFO - 2016-06-10 17:57:39 --> Output Class Initialized
INFO - 2016-06-10 17:57:39 --> Security Class Initialized
DEBUG - 2016-06-10 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:57:39 --> Input Class Initialized
INFO - 2016-06-10 17:57:39 --> Language Class Initialized
INFO - 2016-06-10 17:57:39 --> Loader Class Initialized
INFO - 2016-06-10 17:57:39 --> Helper loaded: form_helper
INFO - 2016-06-10 17:57:39 --> Database Driver Class Initialized
INFO - 2016-06-10 17:57:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:57:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:57:39 --> Email Class Initialized
INFO - 2016-06-10 17:57:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:57:39 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:57:39 --> Helper loaded: language_helper
INFO - 2016-06-10 17:57:39 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:39 --> Model Class Initialized
INFO - 2016-06-10 17:57:39 --> Helper loaded: date_helper
INFO - 2016-06-10 17:57:39 --> Controller Class Initialized
INFO - 2016-06-10 17:57:39 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:57:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:57:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:57:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:57:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:57:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:57:39 --> Model Class Initialized
INFO - 2016-06-10 17:57:39 --> Form Validation Class Initialized
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 17:57:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 17:57:39 --> Final output sent to browser
DEBUG - 2016-06-10 17:57:39 --> Total execution time: 0.1161
INFO - 2016-06-10 17:57:46 --> Config Class Initialized
INFO - 2016-06-10 17:57:46 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:57:46 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:57:46 --> Utf8 Class Initialized
INFO - 2016-06-10 17:57:46 --> URI Class Initialized
INFO - 2016-06-10 17:57:46 --> Router Class Initialized
INFO - 2016-06-10 17:57:46 --> Output Class Initialized
INFO - 2016-06-10 17:57:46 --> Security Class Initialized
DEBUG - 2016-06-10 17:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:57:46 --> Input Class Initialized
INFO - 2016-06-10 17:57:46 --> Language Class Initialized
INFO - 2016-06-10 17:57:46 --> Loader Class Initialized
INFO - 2016-06-10 17:57:46 --> Helper loaded: form_helper
INFO - 2016-06-10 17:57:46 --> Database Driver Class Initialized
INFO - 2016-06-10 17:57:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:57:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:57:46 --> Email Class Initialized
INFO - 2016-06-10 17:57:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:57:46 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:57:46 --> Helper loaded: language_helper
INFO - 2016-06-10 17:57:46 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:57:46 --> Model Class Initialized
INFO - 2016-06-10 17:57:46 --> Helper loaded: date_helper
INFO - 2016-06-10 17:57:46 --> Controller Class Initialized
INFO - 2016-06-10 17:57:46 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:57:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:57:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:57:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:57:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:57:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:57:46 --> Model Class Initialized
INFO - 2016-06-10 17:57:46 --> Form Validation Class Initialized
INFO - 2016-06-10 17:57:46 --> Final output sent to browser
DEBUG - 2016-06-10 17:57:46 --> Total execution time: 0.0413
INFO - 2016-06-10 17:58:22 --> Config Class Initialized
INFO - 2016-06-10 17:58:22 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:58:22 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:58:22 --> Utf8 Class Initialized
INFO - 2016-06-10 17:58:22 --> URI Class Initialized
INFO - 2016-06-10 17:58:22 --> Router Class Initialized
INFO - 2016-06-10 17:58:22 --> Output Class Initialized
INFO - 2016-06-10 17:58:22 --> Security Class Initialized
DEBUG - 2016-06-10 17:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:58:22 --> Input Class Initialized
INFO - 2016-06-10 17:58:22 --> Language Class Initialized
INFO - 2016-06-10 17:58:22 --> Loader Class Initialized
INFO - 2016-06-10 17:58:22 --> Helper loaded: form_helper
INFO - 2016-06-10 17:58:22 --> Database Driver Class Initialized
INFO - 2016-06-10 17:58:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:58:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:58:22 --> Email Class Initialized
INFO - 2016-06-10 17:58:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:58:22 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:58:22 --> Helper loaded: language_helper
INFO - 2016-06-10 17:58:22 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:58:22 --> Model Class Initialized
INFO - 2016-06-10 17:58:22 --> Helper loaded: date_helper
INFO - 2016-06-10 17:58:22 --> Controller Class Initialized
INFO - 2016-06-10 17:58:22 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:58:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:58:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:58:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:58:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:58:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:58:22 --> Model Class Initialized
INFO - 2016-06-10 17:58:22 --> Form Validation Class Initialized
INFO - 2016-06-10 17:58:22 --> Final output sent to browser
DEBUG - 2016-06-10 17:58:22 --> Total execution time: 0.1589
INFO - 2016-06-10 17:58:50 --> Config Class Initialized
INFO - 2016-06-10 17:58:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:58:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:58:50 --> Utf8 Class Initialized
INFO - 2016-06-10 17:58:50 --> URI Class Initialized
INFO - 2016-06-10 17:58:50 --> Router Class Initialized
INFO - 2016-06-10 17:58:50 --> Output Class Initialized
INFO - 2016-06-10 17:58:50 --> Security Class Initialized
DEBUG - 2016-06-10 17:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:58:50 --> Input Class Initialized
INFO - 2016-06-10 17:58:50 --> Language Class Initialized
INFO - 2016-06-10 17:58:50 --> Loader Class Initialized
INFO - 2016-06-10 17:58:50 --> Helper loaded: form_helper
INFO - 2016-06-10 17:58:50 --> Database Driver Class Initialized
INFO - 2016-06-10 17:58:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:58:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:58:50 --> Email Class Initialized
INFO - 2016-06-10 17:58:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:58:50 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:58:50 --> Helper loaded: language_helper
INFO - 2016-06-10 17:58:50 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:58:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:58:50 --> Model Class Initialized
INFO - 2016-06-10 17:58:50 --> Helper loaded: date_helper
INFO - 2016-06-10 17:58:50 --> Controller Class Initialized
INFO - 2016-06-10 17:58:50 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:58:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:58:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:58:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:58:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:58:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:58:50 --> Model Class Initialized
INFO - 2016-06-10 17:58:50 --> Form Validation Class Initialized
INFO - 2016-06-10 17:58:51 --> Database Utility Class Initialized
INFO - 2016-06-10 17:58:51 --> Helper loaded: file_helper
INFO - 2016-06-10 17:58:51 --> Helper loaded: download_helper
INFO - 2016-06-10 17:58:59 --> Config Class Initialized
INFO - 2016-06-10 17:58:59 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:58:59 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:58:59 --> Utf8 Class Initialized
INFO - 2016-06-10 17:58:59 --> URI Class Initialized
INFO - 2016-06-10 17:58:59 --> Router Class Initialized
INFO - 2016-06-10 17:58:59 --> Output Class Initialized
INFO - 2016-06-10 17:58:59 --> Security Class Initialized
DEBUG - 2016-06-10 17:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:58:59 --> Input Class Initialized
INFO - 2016-06-10 17:58:59 --> Language Class Initialized
INFO - 2016-06-10 17:58:59 --> Loader Class Initialized
INFO - 2016-06-10 17:58:59 --> Helper loaded: form_helper
INFO - 2016-06-10 17:58:59 --> Database Driver Class Initialized
INFO - 2016-06-10 17:58:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:58:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:58:59 --> Email Class Initialized
INFO - 2016-06-10 17:58:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:58:59 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:58:59 --> Helper loaded: language_helper
INFO - 2016-06-10 17:58:59 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:58:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:58:59 --> Model Class Initialized
INFO - 2016-06-10 17:58:59 --> Helper loaded: date_helper
INFO - 2016-06-10 17:58:59 --> Controller Class Initialized
INFO - 2016-06-10 17:58:59 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:58:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:58:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:58:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:58:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:58:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:58:59 --> Model Class Initialized
INFO - 2016-06-10 17:58:59 --> Form Validation Class Initialized
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 17:58:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 17:58:59 --> Final output sent to browser
DEBUG - 2016-06-10 17:58:59 --> Total execution time: 0.0994
INFO - 2016-06-10 17:59:10 --> Config Class Initialized
INFO - 2016-06-10 17:59:10 --> Hooks Class Initialized
DEBUG - 2016-06-10 17:59:10 --> UTF-8 Support Enabled
INFO - 2016-06-10 17:59:10 --> Utf8 Class Initialized
INFO - 2016-06-10 17:59:10 --> URI Class Initialized
INFO - 2016-06-10 17:59:10 --> Router Class Initialized
INFO - 2016-06-10 17:59:10 --> Output Class Initialized
INFO - 2016-06-10 17:59:10 --> Security Class Initialized
DEBUG - 2016-06-10 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 17:59:10 --> Input Class Initialized
INFO - 2016-06-10 17:59:10 --> Language Class Initialized
INFO - 2016-06-10 17:59:10 --> Loader Class Initialized
INFO - 2016-06-10 17:59:10 --> Helper loaded: form_helper
INFO - 2016-06-10 17:59:10 --> Database Driver Class Initialized
INFO - 2016-06-10 17:59:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 17:59:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 17:59:10 --> Email Class Initialized
INFO - 2016-06-10 17:59:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 17:59:10 --> Helper loaded: cookie_helper
INFO - 2016-06-10 17:59:10 --> Helper loaded: language_helper
INFO - 2016-06-10 17:59:10 --> Helper loaded: url_helper
DEBUG - 2016-06-10 17:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 17:59:10 --> Model Class Initialized
INFO - 2016-06-10 17:59:10 --> Helper loaded: date_helper
INFO - 2016-06-10 17:59:10 --> Controller Class Initialized
INFO - 2016-06-10 17:59:10 --> Helper loaded: languages_helper
INFO - 2016-06-10 17:59:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 17:59:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 17:59:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 17:59:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 17:59:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 17:59:10 --> Model Class Initialized
INFO - 2016-06-10 17:59:10 --> Form Validation Class Initialized
INFO - 2016-06-10 17:59:10 --> Final output sent to browser
DEBUG - 2016-06-10 17:59:10 --> Total execution time: 0.1278
INFO - 2016-06-10 18:01:42 --> Config Class Initialized
INFO - 2016-06-10 18:01:42 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:01:42 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:01:42 --> Utf8 Class Initialized
INFO - 2016-06-10 18:01:42 --> URI Class Initialized
INFO - 2016-06-10 18:01:42 --> Router Class Initialized
INFO - 2016-06-10 18:01:42 --> Output Class Initialized
INFO - 2016-06-10 18:01:42 --> Security Class Initialized
DEBUG - 2016-06-10 18:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:01:42 --> Input Class Initialized
INFO - 2016-06-10 18:01:42 --> Language Class Initialized
INFO - 2016-06-10 18:01:42 --> Loader Class Initialized
INFO - 2016-06-10 18:01:42 --> Helper loaded: form_helper
INFO - 2016-06-10 18:01:42 --> Database Driver Class Initialized
INFO - 2016-06-10 18:01:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:01:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:01:42 --> Email Class Initialized
INFO - 2016-06-10 18:01:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:01:42 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:01:42 --> Helper loaded: language_helper
INFO - 2016-06-10 18:01:42 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:01:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:01:42 --> Model Class Initialized
INFO - 2016-06-10 18:01:42 --> Helper loaded: date_helper
INFO - 2016-06-10 18:01:42 --> Controller Class Initialized
INFO - 2016-06-10 18:01:42 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:01:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:01:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:01:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:01:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:01:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:01:42 --> Model Class Initialized
INFO - 2016-06-10 18:01:42 --> Form Validation Class Initialized
INFO - 2016-06-10 18:01:42 --> Database Utility Class Initialized
INFO - 2016-06-10 18:01:42 --> Helper loaded: file_helper
INFO - 2016-06-10 18:01:42 --> Helper loaded: download_helper
INFO - 2016-06-10 18:02:35 --> Config Class Initialized
INFO - 2016-06-10 18:02:35 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:02:35 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:02:35 --> Utf8 Class Initialized
INFO - 2016-06-10 18:02:35 --> URI Class Initialized
INFO - 2016-06-10 18:02:35 --> Router Class Initialized
INFO - 2016-06-10 18:02:35 --> Output Class Initialized
INFO - 2016-06-10 18:02:35 --> Security Class Initialized
DEBUG - 2016-06-10 18:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:02:35 --> Input Class Initialized
INFO - 2016-06-10 18:02:35 --> Language Class Initialized
INFO - 2016-06-10 18:02:35 --> Loader Class Initialized
INFO - 2016-06-10 18:02:35 --> Helper loaded: form_helper
INFO - 2016-06-10 18:02:35 --> Database Driver Class Initialized
INFO - 2016-06-10 18:02:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:02:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:02:35 --> Email Class Initialized
INFO - 2016-06-10 18:02:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:02:35 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:02:35 --> Helper loaded: language_helper
INFO - 2016-06-10 18:02:35 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:02:35 --> Model Class Initialized
INFO - 2016-06-10 18:02:35 --> Helper loaded: date_helper
INFO - 2016-06-10 18:02:35 --> Controller Class Initialized
INFO - 2016-06-10 18:02:35 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:02:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:02:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:02:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:02:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:02:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:02:35 --> Model Class Initialized
INFO - 2016-06-10 18:02:35 --> Form Validation Class Initialized
INFO - 2016-06-10 18:02:35 --> Database Utility Class Initialized
INFO - 2016-06-10 18:02:35 --> Helper loaded: file_helper
INFO - 2016-06-10 18:02:35 --> Helper loaded: download_helper
INFO - 2016-06-10 18:02:48 --> Config Class Initialized
INFO - 2016-06-10 18:02:48 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:02:48 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:02:48 --> Utf8 Class Initialized
INFO - 2016-06-10 18:02:48 --> URI Class Initialized
INFO - 2016-06-10 18:02:48 --> Router Class Initialized
INFO - 2016-06-10 18:02:48 --> Output Class Initialized
INFO - 2016-06-10 18:02:48 --> Security Class Initialized
DEBUG - 2016-06-10 18:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:02:48 --> Input Class Initialized
INFO - 2016-06-10 18:02:48 --> Language Class Initialized
INFO - 2016-06-10 18:02:48 --> Loader Class Initialized
INFO - 2016-06-10 18:02:48 --> Helper loaded: form_helper
INFO - 2016-06-10 18:02:48 --> Database Driver Class Initialized
INFO - 2016-06-10 18:02:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:02:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:02:48 --> Email Class Initialized
INFO - 2016-06-10 18:02:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:02:48 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:02:48 --> Helper loaded: language_helper
INFO - 2016-06-10 18:02:48 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:02:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:02:48 --> Model Class Initialized
INFO - 2016-06-10 18:02:48 --> Helper loaded: date_helper
INFO - 2016-06-10 18:02:48 --> Controller Class Initialized
INFO - 2016-06-10 18:02:48 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:02:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:02:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:02:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:02:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:02:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:02:48 --> Model Class Initialized
INFO - 2016-06-10 18:02:48 --> Form Validation Class Initialized
INFO - 2016-06-10 18:02:48 --> Database Utility Class Initialized
INFO - 2016-06-10 18:02:48 --> Helper loaded: file_helper
INFO - 2016-06-10 18:02:48 --> Helper loaded: download_helper
INFO - 2016-06-10 18:06:55 --> Config Class Initialized
INFO - 2016-06-10 18:06:55 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:06:55 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:06:55 --> Utf8 Class Initialized
INFO - 2016-06-10 18:06:55 --> URI Class Initialized
INFO - 2016-06-10 18:06:55 --> Router Class Initialized
INFO - 2016-06-10 18:06:55 --> Output Class Initialized
INFO - 2016-06-10 18:06:55 --> Security Class Initialized
DEBUG - 2016-06-10 18:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:06:55 --> Input Class Initialized
INFO - 2016-06-10 18:06:55 --> Language Class Initialized
INFO - 2016-06-10 18:06:55 --> Loader Class Initialized
INFO - 2016-06-10 18:06:55 --> Helper loaded: form_helper
INFO - 2016-06-10 18:06:55 --> Database Driver Class Initialized
INFO - 2016-06-10 18:06:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:06:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:06:55 --> Email Class Initialized
INFO - 2016-06-10 18:06:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:06:55 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:06:55 --> Helper loaded: language_helper
INFO - 2016-06-10 18:06:55 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:06:55 --> Model Class Initialized
INFO - 2016-06-10 18:06:55 --> Helper loaded: date_helper
INFO - 2016-06-10 18:06:55 --> Controller Class Initialized
INFO - 2016-06-10 18:06:55 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:06:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:06:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:06:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:06:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:06:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:06:55 --> Model Class Initialized
INFO - 2016-06-10 18:06:55 --> Form Validation Class Initialized
INFO - 2016-06-10 18:06:55 --> Database Utility Class Initialized
INFO - 2016-06-10 18:06:55 --> Helper loaded: file_helper
INFO - 2016-06-10 18:06:55 --> Helper loaded: download_helper
INFO - 2016-06-10 18:07:22 --> Config Class Initialized
INFO - 2016-06-10 18:07:22 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:07:22 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:07:22 --> Utf8 Class Initialized
INFO - 2016-06-10 18:07:22 --> URI Class Initialized
INFO - 2016-06-10 18:07:22 --> Router Class Initialized
INFO - 2016-06-10 18:07:22 --> Output Class Initialized
INFO - 2016-06-10 18:07:22 --> Security Class Initialized
DEBUG - 2016-06-10 18:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:07:22 --> Input Class Initialized
INFO - 2016-06-10 18:07:22 --> Language Class Initialized
INFO - 2016-06-10 18:07:22 --> Loader Class Initialized
INFO - 2016-06-10 18:07:22 --> Helper loaded: form_helper
INFO - 2016-06-10 18:07:22 --> Database Driver Class Initialized
INFO - 2016-06-10 18:07:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:07:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:07:22 --> Email Class Initialized
INFO - 2016-06-10 18:07:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:07:22 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:07:22 --> Helper loaded: language_helper
INFO - 2016-06-10 18:07:22 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:07:22 --> Model Class Initialized
INFO - 2016-06-10 18:07:22 --> Helper loaded: date_helper
INFO - 2016-06-10 18:07:22 --> Controller Class Initialized
INFO - 2016-06-10 18:07:22 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:07:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:07:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:07:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:07:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:07:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:07:22 --> Model Class Initialized
INFO - 2016-06-10 18:07:22 --> Form Validation Class Initialized
INFO - 2016-06-10 18:07:22 --> Database Utility Class Initialized
INFO - 2016-06-10 18:07:22 --> Helper loaded: file_helper
INFO - 2016-06-10 18:07:22 --> Helper loaded: download_helper
INFO - 2016-06-10 18:19:46 --> Config Class Initialized
INFO - 2016-06-10 18:19:46 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:19:46 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:19:46 --> Utf8 Class Initialized
INFO - 2016-06-10 18:19:46 --> URI Class Initialized
INFO - 2016-06-10 18:19:46 --> Router Class Initialized
INFO - 2016-06-10 18:19:46 --> Output Class Initialized
INFO - 2016-06-10 18:19:46 --> Security Class Initialized
DEBUG - 2016-06-10 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:19:46 --> Input Class Initialized
INFO - 2016-06-10 18:19:46 --> Language Class Initialized
INFO - 2016-06-10 18:19:46 --> Loader Class Initialized
INFO - 2016-06-10 18:19:46 --> Helper loaded: form_helper
INFO - 2016-06-10 18:19:46 --> Database Driver Class Initialized
INFO - 2016-06-10 18:19:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:19:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:19:46 --> Email Class Initialized
INFO - 2016-06-10 18:19:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:19:46 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:19:46 --> Helper loaded: language_helper
INFO - 2016-06-10 18:19:46 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:19:46 --> Model Class Initialized
INFO - 2016-06-10 18:19:46 --> Helper loaded: date_helper
INFO - 2016-06-10 18:19:46 --> Controller Class Initialized
INFO - 2016-06-10 18:19:46 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:19:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:19:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:19:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:19:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:19:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:19:46 --> Model Class Initialized
INFO - 2016-06-10 18:19:46 --> Form Validation Class Initialized
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-10 18:19:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 18:19:46 --> Final output sent to browser
DEBUG - 2016-06-10 18:19:46 --> Total execution time: 0.0703
INFO - 2016-06-10 18:19:51 --> Config Class Initialized
INFO - 2016-06-10 18:19:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:19:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:19:51 --> Utf8 Class Initialized
INFO - 2016-06-10 18:19:51 --> URI Class Initialized
INFO - 2016-06-10 18:19:51 --> Router Class Initialized
INFO - 2016-06-10 18:19:51 --> Output Class Initialized
INFO - 2016-06-10 18:19:51 --> Security Class Initialized
DEBUG - 2016-06-10 18:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:19:51 --> Input Class Initialized
INFO - 2016-06-10 18:19:51 --> Language Class Initialized
INFO - 2016-06-10 18:19:51 --> Loader Class Initialized
INFO - 2016-06-10 18:19:51 --> Helper loaded: form_helper
INFO - 2016-06-10 18:19:51 --> Database Driver Class Initialized
INFO - 2016-06-10 18:19:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:19:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:19:51 --> Email Class Initialized
INFO - 2016-06-10 18:19:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:19:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:19:51 --> Helper loaded: language_helper
INFO - 2016-06-10 18:19:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:19:51 --> Model Class Initialized
INFO - 2016-06-10 18:19:51 --> Helper loaded: date_helper
INFO - 2016-06-10 18:19:51 --> Controller Class Initialized
INFO - 2016-06-10 18:19:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:19:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:19:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:19:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:19:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:19:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:19:51 --> Model Class Initialized
INFO - 2016-06-10 18:19:51 --> Form Validation Class Initialized
INFO - 2016-06-10 18:19:51 --> Final output sent to browser
DEBUG - 2016-06-10 18:19:51 --> Total execution time: 0.0719
INFO - 2016-06-10 18:20:38 --> Config Class Initialized
INFO - 2016-06-10 18:20:38 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:20:38 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:20:38 --> Utf8 Class Initialized
INFO - 2016-06-10 18:20:38 --> URI Class Initialized
INFO - 2016-06-10 18:20:38 --> Router Class Initialized
INFO - 2016-06-10 18:20:38 --> Output Class Initialized
INFO - 2016-06-10 18:20:38 --> Security Class Initialized
DEBUG - 2016-06-10 18:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:20:38 --> Input Class Initialized
INFO - 2016-06-10 18:20:38 --> Language Class Initialized
INFO - 2016-06-10 18:20:38 --> Loader Class Initialized
INFO - 2016-06-10 18:20:38 --> Helper loaded: form_helper
INFO - 2016-06-10 18:20:38 --> Database Driver Class Initialized
INFO - 2016-06-10 18:20:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:20:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:20:38 --> Email Class Initialized
INFO - 2016-06-10 18:20:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:20:38 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:20:38 --> Helper loaded: language_helper
INFO - 2016-06-10 18:20:38 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:20:38 --> Model Class Initialized
INFO - 2016-06-10 18:20:38 --> Helper loaded: date_helper
INFO - 2016-06-10 18:20:38 --> Controller Class Initialized
INFO - 2016-06-10 18:20:38 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:20:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:20:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:20:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:20:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:20:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:20:38 --> Model Class Initialized
INFO - 2016-06-10 18:20:38 --> Form Validation Class Initialized
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-10 18:20:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 18:20:38 --> Final output sent to browser
DEBUG - 2016-06-10 18:20:38 --> Total execution time: 0.1519
INFO - 2016-06-10 18:20:52 --> Config Class Initialized
INFO - 2016-06-10 18:20:52 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:20:52 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:20:52 --> Utf8 Class Initialized
INFO - 2016-06-10 18:20:52 --> URI Class Initialized
INFO - 2016-06-10 18:20:52 --> Router Class Initialized
INFO - 2016-06-10 18:20:52 --> Output Class Initialized
INFO - 2016-06-10 18:20:52 --> Security Class Initialized
DEBUG - 2016-06-10 18:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:20:52 --> Input Class Initialized
INFO - 2016-06-10 18:20:52 --> Language Class Initialized
INFO - 2016-06-10 18:20:52 --> Loader Class Initialized
INFO - 2016-06-10 18:20:52 --> Helper loaded: form_helper
INFO - 2016-06-10 18:20:52 --> Database Driver Class Initialized
INFO - 2016-06-10 18:20:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:20:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:20:52 --> Email Class Initialized
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:20:52 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:20:52 --> Helper loaded: language_helper
INFO - 2016-06-10 18:20:52 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:20:52 --> Model Class Initialized
INFO - 2016-06-10 18:20:52 --> Helper loaded: date_helper
INFO - 2016-06-10 18:20:52 --> Controller Class Initialized
INFO - 2016-06-10 18:20:52 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-10 18:20:52 --> Config Class Initialized
INFO - 2016-06-10 18:20:52 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:20:52 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:20:52 --> Utf8 Class Initialized
INFO - 2016-06-10 18:20:52 --> URI Class Initialized
INFO - 2016-06-10 18:20:52 --> Router Class Initialized
INFO - 2016-06-10 18:20:52 --> Output Class Initialized
INFO - 2016-06-10 18:20:52 --> Security Class Initialized
DEBUG - 2016-06-10 18:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:20:52 --> Input Class Initialized
INFO - 2016-06-10 18:20:52 --> Language Class Initialized
INFO - 2016-06-10 18:20:52 --> Loader Class Initialized
INFO - 2016-06-10 18:20:52 --> Helper loaded: form_helper
INFO - 2016-06-10 18:20:52 --> Database Driver Class Initialized
INFO - 2016-06-10 18:20:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:20:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:20:52 --> Email Class Initialized
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:20:52 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:20:52 --> Helper loaded: language_helper
INFO - 2016-06-10 18:20:52 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:20:52 --> Model Class Initialized
INFO - 2016-06-10 18:20:52 --> Helper loaded: date_helper
INFO - 2016-06-10 18:20:52 --> Controller Class Initialized
INFO - 2016-06-10 18:20:52 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-10 18:20:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-10 18:20:52 --> Model Class Initialized
INFO - 2016-06-10 18:20:52 --> Form Validation Class Initialized
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-10 18:20:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 18:20:52 --> Final output sent to browser
DEBUG - 2016-06-10 18:20:52 --> Total execution time: 0.2003
INFO - 2016-06-10 18:21:08 --> Config Class Initialized
INFO - 2016-06-10 18:21:08 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:21:08 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:21:08 --> Utf8 Class Initialized
INFO - 2016-06-10 18:21:08 --> URI Class Initialized
INFO - 2016-06-10 18:21:08 --> Router Class Initialized
INFO - 2016-06-10 18:21:08 --> Output Class Initialized
INFO - 2016-06-10 18:21:08 --> Security Class Initialized
DEBUG - 2016-06-10 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:21:08 --> Input Class Initialized
INFO - 2016-06-10 18:21:08 --> Language Class Initialized
INFO - 2016-06-10 18:21:08 --> Loader Class Initialized
INFO - 2016-06-10 18:21:08 --> Helper loaded: form_helper
INFO - 2016-06-10 18:21:08 --> Database Driver Class Initialized
INFO - 2016-06-10 18:21:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:21:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:21:08 --> Email Class Initialized
INFO - 2016-06-10 18:21:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:21:08 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:21:08 --> Helper loaded: language_helper
INFO - 2016-06-10 18:21:08 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:21:08 --> Model Class Initialized
INFO - 2016-06-10 18:21:08 --> Helper loaded: date_helper
INFO - 2016-06-10 18:21:08 --> Controller Class Initialized
INFO - 2016-06-10 18:21:08 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:21:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-10 18:21:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-10 18:21:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-10 18:21:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-10 18:21:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-10 18:21:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-10 18:21:08 --> Model Class Initialized
INFO - 2016-06-10 18:21:08 --> Form Validation Class Initialized
INFO - 2016-06-10 18:21:15 --> Config Class Initialized
INFO - 2016-06-10 18:21:15 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:21:15 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:21:15 --> Utf8 Class Initialized
INFO - 2016-06-10 18:21:15 --> URI Class Initialized
INFO - 2016-06-10 18:21:15 --> Router Class Initialized
INFO - 2016-06-10 18:21:15 --> Output Class Initialized
INFO - 2016-06-10 18:21:15 --> Security Class Initialized
DEBUG - 2016-06-10 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:21:15 --> Input Class Initialized
INFO - 2016-06-10 18:21:15 --> Language Class Initialized
INFO - 2016-06-10 18:21:15 --> Loader Class Initialized
INFO - 2016-06-10 18:21:15 --> Helper loaded: form_helper
INFO - 2016-06-10 18:21:15 --> Database Driver Class Initialized
INFO - 2016-06-10 18:21:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:21:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:21:15 --> Email Class Initialized
INFO - 2016-06-10 18:21:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:21:15 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:21:15 --> Helper loaded: language_helper
INFO - 2016-06-10 18:21:15 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:21:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:21:15 --> Model Class Initialized
INFO - 2016-06-10 18:21:15 --> Helper loaded: date_helper
INFO - 2016-06-10 18:21:15 --> Controller Class Initialized
INFO - 2016-06-10 18:21:15 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:21:15 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-10 18:21:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-10 18:21:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-10 18:21:15 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-10 18:21:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-10 18:21:15 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-10 18:21:15 --> Model Class Initialized
INFO - 2016-06-10 18:21:15 --> Form Validation Class Initialized
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-10 18:21:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-10 18:21:15 --> Final output sent to browser
DEBUG - 2016-06-10 18:21:15 --> Total execution time: 0.1156
INFO - 2016-06-10 18:24:50 --> Config Class Initialized
INFO - 2016-06-10 18:24:50 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:24:50 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:24:50 --> Utf8 Class Initialized
INFO - 2016-06-10 18:24:51 --> URI Class Initialized
INFO - 2016-06-10 18:24:51 --> Router Class Initialized
INFO - 2016-06-10 18:24:51 --> Output Class Initialized
INFO - 2016-06-10 18:24:51 --> Security Class Initialized
DEBUG - 2016-06-10 18:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:24:51 --> Input Class Initialized
INFO - 2016-06-10 18:24:51 --> Language Class Initialized
INFO - 2016-06-10 18:24:51 --> Loader Class Initialized
INFO - 2016-06-10 18:24:51 --> Helper loaded: form_helper
INFO - 2016-06-10 18:24:51 --> Database Driver Class Initialized
INFO - 2016-06-10 18:24:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:24:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:24:51 --> Email Class Initialized
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:24:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:24:51 --> Helper loaded: language_helper
INFO - 2016-06-10 18:24:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:24:51 --> Model Class Initialized
INFO - 2016-06-10 18:24:51 --> Helper loaded: date_helper
INFO - 2016-06-10 18:24:51 --> Controller Class Initialized
INFO - 2016-06-10 18:24:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-10 18:24:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:24:51 --> Form Validation Class Initialized
INFO - 2016-06-10 18:24:51 --> Config Class Initialized
INFO - 2016-06-10 18:24:51 --> Hooks Class Initialized
DEBUG - 2016-06-10 18:24:51 --> UTF-8 Support Enabled
INFO - 2016-06-10 18:24:51 --> Utf8 Class Initialized
INFO - 2016-06-10 18:24:51 --> URI Class Initialized
INFO - 2016-06-10 18:24:51 --> Router Class Initialized
INFO - 2016-06-10 18:24:51 --> Output Class Initialized
INFO - 2016-06-10 18:24:51 --> Security Class Initialized
DEBUG - 2016-06-10 18:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-10 18:24:51 --> Input Class Initialized
INFO - 2016-06-10 18:24:51 --> Language Class Initialized
INFO - 2016-06-10 18:24:51 --> Loader Class Initialized
INFO - 2016-06-10 18:24:51 --> Helper loaded: form_helper
INFO - 2016-06-10 18:24:51 --> Database Driver Class Initialized
INFO - 2016-06-10 18:24:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-10 18:24:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-10 18:24:51 --> Email Class Initialized
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-10 18:24:51 --> Helper loaded: cookie_helper
INFO - 2016-06-10 18:24:51 --> Helper loaded: language_helper
INFO - 2016-06-10 18:24:51 --> Helper loaded: url_helper
DEBUG - 2016-06-10 18:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:24:51 --> Model Class Initialized
INFO - 2016-06-10 18:24:51 --> Helper loaded: date_helper
INFO - 2016-06-10 18:24:51 --> Controller Class Initialized
INFO - 2016-06-10 18:24:51 --> Helper loaded: languages_helper
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-10 18:24:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-10 18:24:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:24:51 --> Form Validation Class Initialized
DEBUG - 2016-06-10 18:24:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-10 18:24:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-10 18:24:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-10 18:24:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-10 18:24:51 --> Final output sent to browser
DEBUG - 2016-06-10 18:24:51 --> Total execution time: 0.0623
