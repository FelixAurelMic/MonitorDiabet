<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-11 12:06:32 --> Config Class Initialized
INFO - 2016-06-11 12:06:32 --> Hooks Class Initialized
DEBUG - 2016-06-11 12:06:32 --> UTF-8 Support Enabled
INFO - 2016-06-11 12:06:32 --> Utf8 Class Initialized
INFO - 2016-06-11 12:06:32 --> URI Class Initialized
DEBUG - 2016-06-11 12:06:32 --> No URI present. Default controller set.
INFO - 2016-06-11 12:06:32 --> Router Class Initialized
INFO - 2016-06-11 12:06:32 --> Output Class Initialized
INFO - 2016-06-11 12:06:32 --> Security Class Initialized
DEBUG - 2016-06-11 12:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-11 12:06:32 --> Input Class Initialized
INFO - 2016-06-11 12:06:32 --> Language Class Initialized
INFO - 2016-06-11 12:06:33 --> Loader Class Initialized
INFO - 2016-06-11 12:06:33 --> Helper loaded: form_helper
INFO - 2016-06-11 12:06:33 --> Database Driver Class Initialized
INFO - 2016-06-11 12:06:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-11 12:06:33 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-11 12:06:33 --> Email Class Initialized
INFO - 2016-06-11 12:06:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-11 12:06:33 --> Helper loaded: cookie_helper
INFO - 2016-06-11 12:06:33 --> Helper loaded: language_helper
INFO - 2016-06-11 12:06:33 --> Helper loaded: url_helper
DEBUG - 2016-06-11 12:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-11 12:06:33 --> Model Class Initialized
INFO - 2016-06-11 12:06:33 --> Helper loaded: date_helper
INFO - 2016-06-11 12:06:33 --> Controller Class Initialized
INFO - 2016-06-11 12:06:33 --> Helper loaded: languages_helper
INFO - 2016-06-11 12:06:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-11 12:06:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-11 12:06:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-11 12:06:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-11 12:06:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-11 15:06:33 --> Model Class Initialized
INFO - 2016-06-11 15:06:33 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-11 15:06:33 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-11 15:06:33 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-11 15:06:33 --> Final output sent to browser
DEBUG - 2016-06-11 15:06:33 --> Total execution time: 1.6154
INFO - 2016-06-11 12:06:34 --> Config Class Initialized
INFO - 2016-06-11 12:06:34 --> Hooks Class Initialized
DEBUG - 2016-06-11 12:06:34 --> UTF-8 Support Enabled
INFO - 2016-06-11 12:06:34 --> Utf8 Class Initialized
INFO - 2016-06-11 12:06:34 --> URI Class Initialized
INFO - 2016-06-11 12:06:34 --> Router Class Initialized
INFO - 2016-06-11 12:06:34 --> Output Class Initialized
INFO - 2016-06-11 12:06:34 --> Security Class Initialized
DEBUG - 2016-06-11 12:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-11 12:06:34 --> Input Class Initialized
INFO - 2016-06-11 12:06:34 --> Language Class Initialized
ERROR - 2016-06-11 12:06:34 --> 404 Page Not Found: Faviconico/index
