<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-06 10:17:24 --> Config Class Initialized
INFO - 2016-06-06 10:17:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:17:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:17:24 --> Utf8 Class Initialized
INFO - 2016-06-06 10:17:24 --> URI Class Initialized
INFO - 2016-06-06 10:17:24 --> Router Class Initialized
INFO - 2016-06-06 10:17:24 --> Output Class Initialized
INFO - 2016-06-06 10:17:25 --> Security Class Initialized
DEBUG - 2016-06-06 10:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:17:25 --> CSRF cookie sent
INFO - 2016-06-06 10:17:25 --> Input Class Initialized
INFO - 2016-06-06 10:17:25 --> Language Class Initialized
INFO - 2016-06-06 10:17:25 --> Loader Class Initialized
INFO - 2016-06-06 10:17:25 --> Helper loaded: form_helper
INFO - 2016-06-06 10:17:25 --> Database Driver Class Initialized
INFO - 2016-06-06 10:17:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:17:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:17:27 --> Email Class Initialized
INFO - 2016-06-06 10:17:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:17:27 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:17:27 --> Helper loaded: language_helper
INFO - 2016-06-06 10:17:27 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:17:27 --> Model Class Initialized
INFO - 2016-06-06 10:17:27 --> Helper loaded: date_helper
INFO - 2016-06-06 10:17:27 --> Controller Class Initialized
INFO - 2016-06-06 10:17:27 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:17:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:17:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:17:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:17:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:17:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:17:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:17:28 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:17:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:17:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:17:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:17:28 --> Final output sent to browser
DEBUG - 2016-06-06 10:17:28 --> Total execution time: 4.8470
INFO - 2016-06-06 10:17:37 --> Config Class Initialized
INFO - 2016-06-06 10:17:37 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:17:37 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:17:37 --> Utf8 Class Initialized
INFO - 2016-06-06 10:17:37 --> URI Class Initialized
INFO - 2016-06-06 10:17:37 --> Router Class Initialized
INFO - 2016-06-06 10:17:37 --> Output Class Initialized
INFO - 2016-06-06 10:17:37 --> Security Class Initialized
DEBUG - 2016-06-06 10:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:17:37 --> CSRF cookie sent
INFO - 2016-06-06 10:17:37 --> Input Class Initialized
INFO - 2016-06-06 10:17:37 --> Language Class Initialized
ERROR - 2016-06-06 10:17:37 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-06 10:26:13 --> Config Class Initialized
INFO - 2016-06-06 10:26:13 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:26:13 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:26:13 --> Utf8 Class Initialized
INFO - 2016-06-06 10:26:13 --> URI Class Initialized
INFO - 2016-06-06 10:26:13 --> Router Class Initialized
INFO - 2016-06-06 10:26:13 --> Output Class Initialized
INFO - 2016-06-06 10:26:13 --> Security Class Initialized
DEBUG - 2016-06-06 10:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:26:13 --> CSRF cookie sent
INFO - 2016-06-06 10:26:13 --> CSRF token verified
INFO - 2016-06-06 10:26:13 --> Input Class Initialized
INFO - 2016-06-06 10:26:13 --> Language Class Initialized
INFO - 2016-06-06 10:26:13 --> Loader Class Initialized
INFO - 2016-06-06 10:26:13 --> Helper loaded: form_helper
INFO - 2016-06-06 10:26:13 --> Database Driver Class Initialized
INFO - 2016-06-06 10:26:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:26:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:26:13 --> Email Class Initialized
INFO - 2016-06-06 10:26:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:26:13 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:26:13 --> Helper loaded: language_helper
INFO - 2016-06-06 10:26:13 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:26:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:26:13 --> Model Class Initialized
INFO - 2016-06-06 10:26:13 --> Helper loaded: date_helper
INFO - 2016-06-06 10:26:13 --> Controller Class Initialized
INFO - 2016-06-06 10:26:14 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:26:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:26:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:26:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:26:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:26:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:26:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:26:14 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:26:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:26:14 --> Final output sent to browser
DEBUG - 2016-06-06 10:26:14 --> Total execution time: 0.0563
INFO - 2016-06-06 10:26:25 --> Config Class Initialized
INFO - 2016-06-06 10:26:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:26:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:26:25 --> Utf8 Class Initialized
INFO - 2016-06-06 10:26:25 --> URI Class Initialized
INFO - 2016-06-06 10:26:25 --> Router Class Initialized
INFO - 2016-06-06 10:26:25 --> Output Class Initialized
INFO - 2016-06-06 10:26:25 --> Security Class Initialized
DEBUG - 2016-06-06 10:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:26:25 --> CSRF cookie sent
INFO - 2016-06-06 10:26:25 --> CSRF token verified
INFO - 2016-06-06 10:26:25 --> Input Class Initialized
INFO - 2016-06-06 10:26:25 --> Language Class Initialized
INFO - 2016-06-06 10:26:25 --> Loader Class Initialized
INFO - 2016-06-06 10:26:25 --> Helper loaded: form_helper
INFO - 2016-06-06 10:26:25 --> Database Driver Class Initialized
INFO - 2016-06-06 10:26:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:26:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:26:25 --> Email Class Initialized
INFO - 2016-06-06 10:26:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:26:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:26:25 --> Helper loaded: language_helper
INFO - 2016-06-06 10:26:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:26:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:26:25 --> Model Class Initialized
INFO - 2016-06-06 10:26:25 --> Helper loaded: date_helper
INFO - 2016-06-06 10:26:25 --> Controller Class Initialized
INFO - 2016-06-06 10:26:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:26:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:26:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:26:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:26:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:26:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:26:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:26:25 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:26:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-06 10:26:25 --> Unable to find validation rule: captcha_check()
ERROR - 2016-06-06 10:26:25 --> Could not find the language line "form_validation_captcha_check()"
INFO - 2016-06-06 10:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:26:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:26:25 --> Final output sent to browser
DEBUG - 2016-06-06 10:26:25 --> Total execution time: 0.0823
INFO - 2016-06-06 10:27:55 --> Config Class Initialized
INFO - 2016-06-06 10:27:55 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:27:55 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:27:55 --> Utf8 Class Initialized
INFO - 2016-06-06 10:27:55 --> URI Class Initialized
INFO - 2016-06-06 10:27:55 --> Router Class Initialized
INFO - 2016-06-06 10:27:55 --> Output Class Initialized
INFO - 2016-06-06 10:27:55 --> Security Class Initialized
DEBUG - 2016-06-06 10:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:27:55 --> CSRF cookie sent
INFO - 2016-06-06 10:27:55 --> CSRF token verified
INFO - 2016-06-06 10:27:55 --> Input Class Initialized
INFO - 2016-06-06 10:27:55 --> Language Class Initialized
INFO - 2016-06-06 10:27:55 --> Loader Class Initialized
INFO - 2016-06-06 10:27:55 --> Helper loaded: form_helper
INFO - 2016-06-06 10:27:55 --> Database Driver Class Initialized
INFO - 2016-06-06 10:27:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:27:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:27:55 --> Email Class Initialized
INFO - 2016-06-06 10:27:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:27:55 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:27:55 --> Helper loaded: language_helper
INFO - 2016-06-06 10:27:55 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:27:55 --> Model Class Initialized
INFO - 2016-06-06 10:27:55 --> Helper loaded: date_helper
INFO - 2016-06-06 10:27:55 --> Controller Class Initialized
INFO - 2016-06-06 10:27:55 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:27:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:27:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:27:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:27:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:27:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:27:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:27:55 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:27:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-06 10:27:55 --> Unable to find validation rule: captcha_check()
ERROR - 2016-06-06 10:27:55 --> Could not find the language line "form_validation_captcha_check()"
INFO - 2016-06-06 10:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:27:55 --> Final output sent to browser
DEBUG - 2016-06-06 10:27:55 --> Total execution time: 0.0593
INFO - 2016-06-06 10:28:22 --> Config Class Initialized
INFO - 2016-06-06 10:28:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:28:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:28:22 --> Utf8 Class Initialized
INFO - 2016-06-06 10:28:22 --> URI Class Initialized
INFO - 2016-06-06 10:28:22 --> Router Class Initialized
INFO - 2016-06-06 10:28:22 --> Output Class Initialized
INFO - 2016-06-06 10:28:22 --> Security Class Initialized
DEBUG - 2016-06-06 10:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:28:22 --> CSRF cookie sent
INFO - 2016-06-06 10:28:22 --> CSRF token verified
INFO - 2016-06-06 10:28:22 --> Input Class Initialized
INFO - 2016-06-06 10:28:22 --> Language Class Initialized
INFO - 2016-06-06 10:28:22 --> Loader Class Initialized
INFO - 2016-06-06 10:28:22 --> Helper loaded: form_helper
INFO - 2016-06-06 10:28:22 --> Database Driver Class Initialized
INFO - 2016-06-06 10:28:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:28:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:28:22 --> Email Class Initialized
INFO - 2016-06-06 10:28:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:28:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:28:22 --> Helper loaded: language_helper
INFO - 2016-06-06 10:28:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:28:22 --> Model Class Initialized
INFO - 2016-06-06 10:28:22 --> Helper loaded: date_helper
INFO - 2016-06-06 10:28:22 --> Controller Class Initialized
INFO - 2016-06-06 10:28:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:28:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:28:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:28:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:28:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:28:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:28:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:28:22 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:28:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-06 10:28:22 --> Unable to find validation rule: captcha_check()
ERROR - 2016-06-06 10:28:22 --> Could not find the language line "form_validation_captcha_check()"
INFO - 2016-06-06 10:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:28:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:28:22 --> Final output sent to browser
DEBUG - 2016-06-06 10:28:22 --> Total execution time: 0.0995
INFO - 2016-06-06 10:29:07 --> Config Class Initialized
INFO - 2016-06-06 10:29:07 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:29:07 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:29:07 --> Utf8 Class Initialized
INFO - 2016-06-06 10:29:07 --> URI Class Initialized
INFO - 2016-06-06 10:29:07 --> Router Class Initialized
INFO - 2016-06-06 10:29:07 --> Output Class Initialized
INFO - 2016-06-06 10:29:07 --> Security Class Initialized
DEBUG - 2016-06-06 10:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:29:07 --> CSRF cookie sent
INFO - 2016-06-06 10:29:07 --> CSRF token verified
INFO - 2016-06-06 10:29:07 --> Input Class Initialized
INFO - 2016-06-06 10:29:07 --> Language Class Initialized
INFO - 2016-06-06 10:29:07 --> Loader Class Initialized
INFO - 2016-06-06 10:29:07 --> Helper loaded: form_helper
INFO - 2016-06-06 10:29:07 --> Database Driver Class Initialized
INFO - 2016-06-06 10:29:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:29:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:29:07 --> Email Class Initialized
INFO - 2016-06-06 10:29:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:29:07 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:29:07 --> Helper loaded: language_helper
INFO - 2016-06-06 10:29:07 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:29:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:29:07 --> Model Class Initialized
INFO - 2016-06-06 10:29:07 --> Helper loaded: date_helper
INFO - 2016-06-06 10:29:07 --> Controller Class Initialized
INFO - 2016-06-06 10:29:07 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:29:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:29:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:29:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:29:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:29:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:29:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:29:07 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:29:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-06 10:29:07 --> Unable to find callback validation rule: captcha_check()
ERROR - 2016-06-06 10:29:07 --> Could not find the language line "form_validation_captcha_check()"
INFO - 2016-06-06 10:29:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:29:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:29:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:29:07 --> Final output sent to browser
DEBUG - 2016-06-06 10:29:07 --> Total execution time: 0.0441
INFO - 2016-06-06 10:31:09 --> Config Class Initialized
INFO - 2016-06-06 10:31:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:09 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:09 --> URI Class Initialized
INFO - 2016-06-06 10:31:09 --> Router Class Initialized
INFO - 2016-06-06 10:31:09 --> Output Class Initialized
INFO - 2016-06-06 10:31:09 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:09 --> CSRF cookie sent
INFO - 2016-06-06 10:31:09 --> CSRF token verified
INFO - 2016-06-06 10:31:09 --> Input Class Initialized
INFO - 2016-06-06 10:31:09 --> Language Class Initialized
INFO - 2016-06-06 10:31:09 --> Loader Class Initialized
INFO - 2016-06-06 10:31:09 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:09 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:09 --> Email Class Initialized
INFO - 2016-06-06 10:31:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:09 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:09 --> Model Class Initialized
INFO - 2016-06-06 10:31:09 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:09 --> Controller Class Initialized
INFO - 2016-06-06 10:31:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:09 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:31:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:09 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:31:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:31:09 --> Final output sent to browser
DEBUG - 2016-06-06 10:31:09 --> Total execution time: 0.1529
INFO - 2016-06-06 10:31:13 --> Config Class Initialized
INFO - 2016-06-06 10:31:13 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:13 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:13 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:13 --> URI Class Initialized
INFO - 2016-06-06 10:31:13 --> Router Class Initialized
INFO - 2016-06-06 10:31:13 --> Output Class Initialized
INFO - 2016-06-06 10:31:13 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:13 --> CSRF cookie sent
INFO - 2016-06-06 10:31:13 --> CSRF token verified
INFO - 2016-06-06 10:31:13 --> Input Class Initialized
INFO - 2016-06-06 10:31:13 --> Language Class Initialized
INFO - 2016-06-06 10:31:13 --> Loader Class Initialized
INFO - 2016-06-06 10:31:13 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:13 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:13 --> Email Class Initialized
INFO - 2016-06-06 10:31:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:13 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:13 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:13 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:13 --> Model Class Initialized
INFO - 2016-06-06 10:31:13 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:13 --> Controller Class Initialized
INFO - 2016-06-06 10:31:13 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:31:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:13 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:31:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:31:13 --> Final output sent to browser
DEBUG - 2016-06-06 10:31:13 --> Total execution time: 0.0391
INFO - 2016-06-06 10:31:42 --> Config Class Initialized
INFO - 2016-06-06 10:31:42 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:42 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:42 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:42 --> URI Class Initialized
INFO - 2016-06-06 10:31:42 --> Router Class Initialized
INFO - 2016-06-06 10:31:42 --> Output Class Initialized
INFO - 2016-06-06 10:31:42 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:42 --> CSRF cookie sent
INFO - 2016-06-06 10:31:42 --> CSRF token verified
INFO - 2016-06-06 10:31:42 --> Input Class Initialized
INFO - 2016-06-06 10:31:42 --> Language Class Initialized
INFO - 2016-06-06 10:31:42 --> Loader Class Initialized
INFO - 2016-06-06 10:31:42 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:42 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:42 --> Email Class Initialized
INFO - 2016-06-06 10:31:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:42 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:42 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:42 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:42 --> Model Class Initialized
INFO - 2016-06-06 10:31:42 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:42 --> Controller Class Initialized
INFO - 2016-06-06 10:31:42 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:42 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:31:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:42 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:31:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:43 --> Config Class Initialized
INFO - 2016-06-06 10:31:43 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:43 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:43 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:43 --> URI Class Initialized
DEBUG - 2016-06-06 10:31:43 --> No URI present. Default controller set.
INFO - 2016-06-06 10:31:43 --> Router Class Initialized
INFO - 2016-06-06 10:31:43 --> Output Class Initialized
INFO - 2016-06-06 10:31:43 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:43 --> CSRF cookie sent
INFO - 2016-06-06 10:31:43 --> Input Class Initialized
INFO - 2016-06-06 10:31:43 --> Language Class Initialized
INFO - 2016-06-06 10:31:43 --> Loader Class Initialized
INFO - 2016-06-06 10:31:43 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:43 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:43 --> Email Class Initialized
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:43 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:43 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:43 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:43 --> Model Class Initialized
INFO - 2016-06-06 10:31:43 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:43 --> Controller Class Initialized
INFO - 2016-06-06 10:31:43 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 10:31:43 --> Config Class Initialized
INFO - 2016-06-06 10:31:43 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:43 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:43 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:43 --> URI Class Initialized
INFO - 2016-06-06 10:31:43 --> Router Class Initialized
INFO - 2016-06-06 10:31:43 --> Output Class Initialized
INFO - 2016-06-06 10:31:43 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:43 --> CSRF cookie sent
INFO - 2016-06-06 10:31:43 --> Input Class Initialized
INFO - 2016-06-06 10:31:43 --> Language Class Initialized
INFO - 2016-06-06 10:31:43 --> Loader Class Initialized
INFO - 2016-06-06 10:31:43 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:43 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:43 --> Email Class Initialized
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:43 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:43 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:43 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:43 --> Model Class Initialized
INFO - 2016-06-06 10:31:43 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:43 --> Controller Class Initialized
INFO - 2016-06-06 10:31:43 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 10:31:43 --> Model Class Initialized
INFO - 2016-06-06 10:31:43 --> Form Validation Class Initialized
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 10:31:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 10:31:43 --> Final output sent to browser
DEBUG - 2016-06-06 10:31:43 --> Total execution time: 0.0600
INFO - 2016-06-06 10:31:46 --> Config Class Initialized
INFO - 2016-06-06 10:31:46 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:46 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:46 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:46 --> URI Class Initialized
INFO - 2016-06-06 10:31:46 --> Router Class Initialized
INFO - 2016-06-06 10:31:46 --> Output Class Initialized
INFO - 2016-06-06 10:31:46 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:46 --> CSRF cookie sent
INFO - 2016-06-06 10:31:46 --> CSRF token verified
INFO - 2016-06-06 10:31:46 --> Input Class Initialized
INFO - 2016-06-06 10:31:46 --> Language Class Initialized
INFO - 2016-06-06 10:31:46 --> Loader Class Initialized
INFO - 2016-06-06 10:31:46 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:46 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:46 --> Email Class Initialized
INFO - 2016-06-06 10:31:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:46 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:46 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:46 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:46 --> Model Class Initialized
INFO - 2016-06-06 10:31:46 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:46 --> Controller Class Initialized
INFO - 2016-06-06 10:31:46 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 10:31:46 --> Model Class Initialized
INFO - 2016-06-06 10:31:46 --> Form Validation Class Initialized
INFO - 2016-06-06 10:31:46 --> Final output sent to browser
DEBUG - 2016-06-06 10:31:46 --> Total execution time: 0.0432
INFO - 2016-06-06 10:31:47 --> Config Class Initialized
INFO - 2016-06-06 10:31:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:47 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:47 --> URI Class Initialized
INFO - 2016-06-06 10:31:47 --> Router Class Initialized
INFO - 2016-06-06 10:31:47 --> Output Class Initialized
INFO - 2016-06-06 10:31:47 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:47 --> CSRF cookie sent
INFO - 2016-06-06 10:31:47 --> Input Class Initialized
INFO - 2016-06-06 10:31:47 --> Language Class Initialized
INFO - 2016-06-06 10:31:47 --> Loader Class Initialized
INFO - 2016-06-06 10:31:47 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:47 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:47 --> Email Class Initialized
INFO - 2016-06-06 10:31:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:47 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:47 --> Model Class Initialized
INFO - 2016-06-06 10:31:47 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:47 --> Controller Class Initialized
INFO - 2016-06-06 10:31:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:47 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:31:47 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:47 --> Form Validation Class Initialized
INFO - 2016-06-06 10:31:48 --> Config Class Initialized
INFO - 2016-06-06 10:31:48 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:31:48 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:31:48 --> Utf8 Class Initialized
INFO - 2016-06-06 10:31:48 --> URI Class Initialized
INFO - 2016-06-06 10:31:48 --> Router Class Initialized
INFO - 2016-06-06 10:31:48 --> Output Class Initialized
INFO - 2016-06-06 10:31:48 --> Security Class Initialized
DEBUG - 2016-06-06 10:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:31:48 --> CSRF cookie sent
INFO - 2016-06-06 10:31:48 --> Input Class Initialized
INFO - 2016-06-06 10:31:48 --> Language Class Initialized
INFO - 2016-06-06 10:31:48 --> Loader Class Initialized
INFO - 2016-06-06 10:31:48 --> Helper loaded: form_helper
INFO - 2016-06-06 10:31:48 --> Database Driver Class Initialized
INFO - 2016-06-06 10:31:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:31:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:31:48 --> Email Class Initialized
INFO - 2016-06-06 10:31:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:31:48 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:31:48 --> Helper loaded: language_helper
INFO - 2016-06-06 10:31:48 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:31:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:48 --> Model Class Initialized
INFO - 2016-06-06 10:31:48 --> Helper loaded: date_helper
INFO - 2016-06-06 10:31:48 --> Controller Class Initialized
INFO - 2016-06-06 10:31:48 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:31:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:31:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:31:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:31:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:31:48 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:31:48 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:48 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:31:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:31:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:31:48 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:31:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:31:48 --> Final output sent to browser
DEBUG - 2016-06-06 10:31:48 --> Total execution time: 0.1573
INFO - 2016-06-06 10:32:50 --> Config Class Initialized
INFO - 2016-06-06 10:32:50 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:32:50 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:32:50 --> Utf8 Class Initialized
INFO - 2016-06-06 10:32:50 --> URI Class Initialized
INFO - 2016-06-06 10:32:50 --> Router Class Initialized
INFO - 2016-06-06 10:32:50 --> Output Class Initialized
INFO - 2016-06-06 10:32:50 --> Security Class Initialized
DEBUG - 2016-06-06 10:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:32:50 --> CSRF cookie sent
INFO - 2016-06-06 10:32:50 --> CSRF token verified
INFO - 2016-06-06 10:32:50 --> Input Class Initialized
INFO - 2016-06-06 10:32:50 --> Language Class Initialized
INFO - 2016-06-06 10:32:50 --> Loader Class Initialized
INFO - 2016-06-06 10:32:50 --> Helper loaded: form_helper
INFO - 2016-06-06 10:32:50 --> Database Driver Class Initialized
INFO - 2016-06-06 10:32:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:32:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:32:50 --> Email Class Initialized
INFO - 2016-06-06 10:32:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:32:50 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:32:50 --> Helper loaded: language_helper
INFO - 2016-06-06 10:32:50 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:32:50 --> Model Class Initialized
INFO - 2016-06-06 10:32:50 --> Helper loaded: date_helper
INFO - 2016-06-06 10:32:50 --> Controller Class Initialized
INFO - 2016-06-06 10:32:50 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:32:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:32:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:32:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:32:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:32:50 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:32:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:32:50 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:32:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:32:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:32:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:32:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:32:50 --> Final output sent to browser
DEBUG - 2016-06-06 10:32:50 --> Total execution time: 0.0629
INFO - 2016-06-06 10:32:54 --> Config Class Initialized
INFO - 2016-06-06 10:32:54 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:32:54 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:32:54 --> Utf8 Class Initialized
INFO - 2016-06-06 10:32:54 --> URI Class Initialized
INFO - 2016-06-06 10:32:54 --> Router Class Initialized
INFO - 2016-06-06 10:32:54 --> Output Class Initialized
INFO - 2016-06-06 10:32:54 --> Security Class Initialized
DEBUG - 2016-06-06 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:32:54 --> CSRF cookie sent
INFO - 2016-06-06 10:32:54 --> CSRF token verified
INFO - 2016-06-06 10:32:54 --> Input Class Initialized
INFO - 2016-06-06 10:32:54 --> Language Class Initialized
INFO - 2016-06-06 10:32:54 --> Loader Class Initialized
INFO - 2016-06-06 10:32:54 --> Helper loaded: form_helper
INFO - 2016-06-06 10:32:54 --> Database Driver Class Initialized
INFO - 2016-06-06 10:32:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:32:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:32:54 --> Email Class Initialized
INFO - 2016-06-06 10:32:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:32:54 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:32:54 --> Helper loaded: language_helper
INFO - 2016-06-06 10:32:54 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:32:54 --> Model Class Initialized
INFO - 2016-06-06 10:32:54 --> Helper loaded: date_helper
INFO - 2016-06-06 10:32:54 --> Controller Class Initialized
INFO - 2016-06-06 10:32:54 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:32:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:32:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:32:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:32:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:32:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:32:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:32:54 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:32:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-06 10:32:54 --> Severity: 4096 --> Object of class Auth could not be converted to string /home/demis/www/platformadiabet/application/libraries/SVS_Form_validation.php 47
INFO - 2016-06-06 10:32:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:32:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:32:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:32:54 --> Final output sent to browser
DEBUG - 2016-06-06 10:32:54 --> Total execution time: 0.0351
INFO - 2016-06-06 10:34:25 --> Config Class Initialized
INFO - 2016-06-06 10:34:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:34:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:34:25 --> Utf8 Class Initialized
INFO - 2016-06-06 10:34:25 --> URI Class Initialized
INFO - 2016-06-06 10:34:25 --> Router Class Initialized
INFO - 2016-06-06 10:34:25 --> Output Class Initialized
INFO - 2016-06-06 10:34:25 --> Security Class Initialized
DEBUG - 2016-06-06 10:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:34:25 --> CSRF cookie sent
INFO - 2016-06-06 10:34:25 --> CSRF token verified
INFO - 2016-06-06 10:34:25 --> Input Class Initialized
INFO - 2016-06-06 10:34:25 --> Language Class Initialized
INFO - 2016-06-06 10:34:25 --> Loader Class Initialized
INFO - 2016-06-06 10:34:25 --> Helper loaded: form_helper
INFO - 2016-06-06 10:34:25 --> Database Driver Class Initialized
INFO - 2016-06-06 10:34:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:34:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:34:25 --> Email Class Initialized
INFO - 2016-06-06 10:34:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:34:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:34:25 --> Helper loaded: language_helper
INFO - 2016-06-06 10:34:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:34:25 --> Model Class Initialized
INFO - 2016-06-06 10:34:25 --> Helper loaded: date_helper
INFO - 2016-06-06 10:34:25 --> Controller Class Initialized
INFO - 2016-06-06 10:34:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:34:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:34:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:34:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:34:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:34:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:34:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:34:25 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:34:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:34:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:34:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:34:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:34:25 --> Final output sent to browser
DEBUG - 2016-06-06 10:34:25 --> Total execution time: 0.1161
INFO - 2016-06-06 10:34:32 --> Config Class Initialized
INFO - 2016-06-06 10:34:32 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:34:32 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:34:32 --> Utf8 Class Initialized
INFO - 2016-06-06 10:34:32 --> URI Class Initialized
INFO - 2016-06-06 10:34:32 --> Router Class Initialized
INFO - 2016-06-06 10:34:32 --> Output Class Initialized
INFO - 2016-06-06 10:34:32 --> Security Class Initialized
DEBUG - 2016-06-06 10:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:34:32 --> CSRF cookie sent
INFO - 2016-06-06 10:34:32 --> CSRF token verified
INFO - 2016-06-06 10:34:32 --> Input Class Initialized
INFO - 2016-06-06 10:34:32 --> Language Class Initialized
INFO - 2016-06-06 10:34:32 --> Loader Class Initialized
INFO - 2016-06-06 10:34:32 --> Helper loaded: form_helper
INFO - 2016-06-06 10:34:32 --> Database Driver Class Initialized
INFO - 2016-06-06 10:34:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:34:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:34:32 --> Email Class Initialized
INFO - 2016-06-06 10:34:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:34:32 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:34:32 --> Helper loaded: language_helper
INFO - 2016-06-06 10:34:32 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:34:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:34:32 --> Model Class Initialized
INFO - 2016-06-06 10:34:32 --> Helper loaded: date_helper
INFO - 2016-06-06 10:34:32 --> Controller Class Initialized
INFO - 2016-06-06 10:34:32 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:34:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:34:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:34:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:34:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:34:32 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:34:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:34:32 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:34:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-06 10:34:32 --> Severity: 4096 --> Object of class Auth could not be converted to string /home/demis/www/platformadiabet/application/libraries/SVS_Form_validation.php 47
INFO - 2016-06-06 10:34:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:34:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:34:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:34:32 --> Final output sent to browser
DEBUG - 2016-06-06 10:34:32 --> Total execution time: 0.0276
INFO - 2016-06-06 10:34:57 --> Config Class Initialized
INFO - 2016-06-06 10:34:57 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:34:57 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:34:57 --> Utf8 Class Initialized
INFO - 2016-06-06 10:34:57 --> URI Class Initialized
INFO - 2016-06-06 10:34:57 --> Router Class Initialized
INFO - 2016-06-06 10:34:57 --> Output Class Initialized
INFO - 2016-06-06 10:34:57 --> Security Class Initialized
DEBUG - 2016-06-06 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:34:57 --> CSRF cookie sent
INFO - 2016-06-06 10:34:57 --> CSRF token verified
INFO - 2016-06-06 10:34:57 --> Input Class Initialized
INFO - 2016-06-06 10:34:57 --> Language Class Initialized
INFO - 2016-06-06 10:34:57 --> Loader Class Initialized
INFO - 2016-06-06 10:34:57 --> Helper loaded: form_helper
INFO - 2016-06-06 10:34:57 --> Database Driver Class Initialized
INFO - 2016-06-06 10:34:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:34:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:34:57 --> Email Class Initialized
INFO - 2016-06-06 10:34:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:34:57 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:34:57 --> Helper loaded: language_helper
INFO - 2016-06-06 10:34:57 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:34:57 --> Model Class Initialized
INFO - 2016-06-06 10:34:57 --> Helper loaded: date_helper
INFO - 2016-06-06 10:34:57 --> Controller Class Initialized
INFO - 2016-06-06 10:34:57 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:34:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:34:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:34:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:34:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:34:57 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:34:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:34:57 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:34:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:35:19 --> Config Class Initialized
INFO - 2016-06-06 10:35:19 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:35:19 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:35:19 --> Utf8 Class Initialized
INFO - 2016-06-06 10:35:19 --> URI Class Initialized
INFO - 2016-06-06 10:35:19 --> Router Class Initialized
INFO - 2016-06-06 10:35:19 --> Output Class Initialized
INFO - 2016-06-06 10:35:19 --> Security Class Initialized
DEBUG - 2016-06-06 10:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:35:19 --> CSRF cookie sent
INFO - 2016-06-06 10:35:19 --> Input Class Initialized
INFO - 2016-06-06 10:35:19 --> Language Class Initialized
INFO - 2016-06-06 10:35:19 --> Loader Class Initialized
INFO - 2016-06-06 10:35:19 --> Helper loaded: form_helper
INFO - 2016-06-06 10:35:19 --> Database Driver Class Initialized
INFO - 2016-06-06 10:35:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:35:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:35:19 --> Email Class Initialized
INFO - 2016-06-06 10:35:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:35:19 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:35:19 --> Helper loaded: language_helper
INFO - 2016-06-06 10:35:19 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:35:19 --> Model Class Initialized
INFO - 2016-06-06 10:35:19 --> Helper loaded: date_helper
INFO - 2016-06-06 10:35:19 --> Controller Class Initialized
INFO - 2016-06-06 10:35:19 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:35:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:35:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:35:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:35:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:35:19 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:35:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:35:19 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:35:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:35:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:35:19 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:35:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:35:19 --> Final output sent to browser
DEBUG - 2016-06-06 10:35:19 --> Total execution time: 0.0706
INFO - 2016-06-06 10:35:27 --> Config Class Initialized
INFO - 2016-06-06 10:35:27 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:35:27 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:35:27 --> Utf8 Class Initialized
INFO - 2016-06-06 10:35:27 --> URI Class Initialized
INFO - 2016-06-06 10:35:27 --> Router Class Initialized
INFO - 2016-06-06 10:35:27 --> Output Class Initialized
INFO - 2016-06-06 10:35:27 --> Security Class Initialized
DEBUG - 2016-06-06 10:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:35:27 --> CSRF cookie sent
INFO - 2016-06-06 10:35:27 --> CSRF token verified
INFO - 2016-06-06 10:35:27 --> Input Class Initialized
INFO - 2016-06-06 10:35:27 --> Language Class Initialized
INFO - 2016-06-06 10:35:27 --> Loader Class Initialized
INFO - 2016-06-06 10:35:27 --> Helper loaded: form_helper
INFO - 2016-06-06 10:35:27 --> Database Driver Class Initialized
INFO - 2016-06-06 10:35:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:35:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:35:27 --> Email Class Initialized
INFO - 2016-06-06 10:35:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:35:27 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:35:27 --> Helper loaded: language_helper
INFO - 2016-06-06 10:35:27 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:35:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:35:27 --> Model Class Initialized
INFO - 2016-06-06 10:35:27 --> Helper loaded: date_helper
INFO - 2016-06-06 10:35:27 --> Controller Class Initialized
INFO - 2016-06-06 10:35:27 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:35:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:35:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:35:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:35:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:35:27 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:35:27 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:35:27 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:35:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:01 --> Config Class Initialized
INFO - 2016-06-06 10:38:01 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:38:01 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:38:01 --> Utf8 Class Initialized
INFO - 2016-06-06 10:38:01 --> URI Class Initialized
INFO - 2016-06-06 10:38:01 --> Router Class Initialized
INFO - 2016-06-06 10:38:01 --> Output Class Initialized
INFO - 2016-06-06 10:38:01 --> Security Class Initialized
DEBUG - 2016-06-06 10:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:38:01 --> CSRF cookie sent
INFO - 2016-06-06 10:38:01 --> Input Class Initialized
INFO - 2016-06-06 10:38:01 --> Language Class Initialized
INFO - 2016-06-06 10:38:01 --> Loader Class Initialized
INFO - 2016-06-06 10:38:01 --> Helper loaded: form_helper
INFO - 2016-06-06 10:38:01 --> Database Driver Class Initialized
INFO - 2016-06-06 10:38:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:38:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:38:01 --> Email Class Initialized
INFO - 2016-06-06 10:38:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:38:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:38:01 --> Helper loaded: language_helper
INFO - 2016-06-06 10:38:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:01 --> Model Class Initialized
INFO - 2016-06-06 10:38:01 --> Helper loaded: date_helper
INFO - 2016-06-06 10:38:01 --> Controller Class Initialized
INFO - 2016-06-06 10:38:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:38:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:38:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:38:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:38:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:38:01 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:38:01 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:01 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:38:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:38:01 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:38:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:38:01 --> Final output sent to browser
DEBUG - 2016-06-06 10:38:01 --> Total execution time: 0.1000
INFO - 2016-06-06 10:38:10 --> Config Class Initialized
INFO - 2016-06-06 10:38:10 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:38:10 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:38:10 --> Utf8 Class Initialized
INFO - 2016-06-06 10:38:10 --> URI Class Initialized
INFO - 2016-06-06 10:38:10 --> Router Class Initialized
INFO - 2016-06-06 10:38:10 --> Output Class Initialized
INFO - 2016-06-06 10:38:10 --> Security Class Initialized
DEBUG - 2016-06-06 10:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:38:10 --> CSRF cookie sent
INFO - 2016-06-06 10:38:10 --> CSRF token verified
INFO - 2016-06-06 10:38:10 --> Input Class Initialized
INFO - 2016-06-06 10:38:10 --> Language Class Initialized
INFO - 2016-06-06 10:38:10 --> Loader Class Initialized
INFO - 2016-06-06 10:38:10 --> Helper loaded: form_helper
INFO - 2016-06-06 10:38:10 --> Database Driver Class Initialized
INFO - 2016-06-06 10:38:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:38:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:38:10 --> Email Class Initialized
INFO - 2016-06-06 10:38:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:38:10 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:38:10 --> Helper loaded: language_helper
INFO - 2016-06-06 10:38:10 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:10 --> Model Class Initialized
INFO - 2016-06-06 10:38:10 --> Helper loaded: date_helper
INFO - 2016-06-06 10:38:10 --> Controller Class Initialized
INFO - 2016-06-06 10:38:10 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:38:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:38:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:38:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:38:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:38:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:38:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:10 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:38:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:49 --> Config Class Initialized
INFO - 2016-06-06 10:38:49 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:38:49 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:38:49 --> Utf8 Class Initialized
INFO - 2016-06-06 10:38:49 --> URI Class Initialized
INFO - 2016-06-06 10:38:49 --> Router Class Initialized
INFO - 2016-06-06 10:38:49 --> Output Class Initialized
INFO - 2016-06-06 10:38:49 --> Security Class Initialized
DEBUG - 2016-06-06 10:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:38:49 --> CSRF cookie sent
INFO - 2016-06-06 10:38:49 --> Input Class Initialized
INFO - 2016-06-06 10:38:49 --> Language Class Initialized
INFO - 2016-06-06 10:38:49 --> Loader Class Initialized
INFO - 2016-06-06 10:38:49 --> Helper loaded: form_helper
INFO - 2016-06-06 10:38:49 --> Database Driver Class Initialized
INFO - 2016-06-06 10:38:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:38:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:38:49 --> Email Class Initialized
INFO - 2016-06-06 10:38:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:38:49 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:38:49 --> Helper loaded: language_helper
INFO - 2016-06-06 10:38:49 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:49 --> Model Class Initialized
INFO - 2016-06-06 10:38:49 --> Helper loaded: date_helper
INFO - 2016-06-06 10:38:49 --> Controller Class Initialized
INFO - 2016-06-06 10:38:49 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:38:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:38:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:38:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:38:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:38:49 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:38:49 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:49 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:38:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:38:49 --> Final output sent to browser
DEBUG - 2016-06-06 10:38:49 --> Total execution time: 0.0216
INFO - 2016-06-06 10:38:54 --> Config Class Initialized
INFO - 2016-06-06 10:38:54 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:38:54 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:38:54 --> Utf8 Class Initialized
INFO - 2016-06-06 10:38:54 --> URI Class Initialized
INFO - 2016-06-06 10:38:54 --> Router Class Initialized
INFO - 2016-06-06 10:38:54 --> Output Class Initialized
INFO - 2016-06-06 10:38:54 --> Security Class Initialized
DEBUG - 2016-06-06 10:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:38:54 --> CSRF cookie sent
INFO - 2016-06-06 10:38:54 --> CSRF token verified
INFO - 2016-06-06 10:38:54 --> Input Class Initialized
INFO - 2016-06-06 10:38:54 --> Language Class Initialized
INFO - 2016-06-06 10:38:54 --> Loader Class Initialized
INFO - 2016-06-06 10:38:54 --> Helper loaded: form_helper
INFO - 2016-06-06 10:38:54 --> Database Driver Class Initialized
INFO - 2016-06-06 10:38:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:38:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:38:54 --> Email Class Initialized
INFO - 2016-06-06 10:38:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:38:54 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:38:54 --> Helper loaded: language_helper
INFO - 2016-06-06 10:38:54 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:54 --> Model Class Initialized
INFO - 2016-06-06 10:38:54 --> Helper loaded: date_helper
INFO - 2016-06-06 10:38:54 --> Controller Class Initialized
INFO - 2016-06-06 10:38:54 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:38:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:38:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:38:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:38:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:38:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:38:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:54 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:38:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:38:54 --> Final output sent to browser
DEBUG - 2016-06-06 10:38:54 --> Total execution time: 0.0459
INFO - 2016-06-06 10:38:59 --> Config Class Initialized
INFO - 2016-06-06 10:38:59 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:38:59 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:38:59 --> Utf8 Class Initialized
INFO - 2016-06-06 10:38:59 --> URI Class Initialized
INFO - 2016-06-06 10:38:59 --> Router Class Initialized
INFO - 2016-06-06 10:38:59 --> Output Class Initialized
INFO - 2016-06-06 10:38:59 --> Security Class Initialized
DEBUG - 2016-06-06 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:38:59 --> CSRF cookie sent
INFO - 2016-06-06 10:38:59 --> CSRF token verified
INFO - 2016-06-06 10:38:59 --> Input Class Initialized
INFO - 2016-06-06 10:38:59 --> Language Class Initialized
INFO - 2016-06-06 10:38:59 --> Loader Class Initialized
INFO - 2016-06-06 10:38:59 --> Helper loaded: form_helper
INFO - 2016-06-06 10:38:59 --> Database Driver Class Initialized
INFO - 2016-06-06 10:38:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:38:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:38:59 --> Email Class Initialized
INFO - 2016-06-06 10:38:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:38:59 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:38:59 --> Helper loaded: language_helper
INFO - 2016-06-06 10:38:59 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:59 --> Model Class Initialized
INFO - 2016-06-06 10:38:59 --> Helper loaded: date_helper
INFO - 2016-06-06 10:38:59 --> Controller Class Initialized
INFO - 2016-06-06 10:38:59 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:38:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:38:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:38:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:38:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:38:59 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:38:59 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:38:59 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:38:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-06 10:38:59 --> Severity: 4096 --> Object of class Auth could not be converted to string /home/demis/www/platformadiabet/application/libraries/SVS_Form_validation.php 46
INFO - 2016-06-06 10:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:38:59 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:38:59 --> Final output sent to browser
DEBUG - 2016-06-06 10:38:59 --> Total execution time: 0.0211
INFO - 2016-06-06 10:39:29 --> Config Class Initialized
INFO - 2016-06-06 10:39:29 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:39:29 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:39:29 --> Utf8 Class Initialized
INFO - 2016-06-06 10:39:29 --> URI Class Initialized
INFO - 2016-06-06 10:39:29 --> Router Class Initialized
INFO - 2016-06-06 10:39:29 --> Output Class Initialized
INFO - 2016-06-06 10:39:29 --> Security Class Initialized
DEBUG - 2016-06-06 10:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:39:29 --> CSRF cookie sent
INFO - 2016-06-06 10:39:29 --> CSRF token verified
INFO - 2016-06-06 10:39:29 --> Input Class Initialized
INFO - 2016-06-06 10:39:29 --> Language Class Initialized
INFO - 2016-06-06 10:39:29 --> Loader Class Initialized
INFO - 2016-06-06 10:39:29 --> Helper loaded: form_helper
INFO - 2016-06-06 10:39:29 --> Database Driver Class Initialized
INFO - 2016-06-06 10:39:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:39:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:39:29 --> Email Class Initialized
INFO - 2016-06-06 10:39:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:39:29 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:39:29 --> Helper loaded: language_helper
INFO - 2016-06-06 10:39:29 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:39:29 --> Model Class Initialized
INFO - 2016-06-06 10:39:29 --> Helper loaded: date_helper
INFO - 2016-06-06 10:39:29 --> Controller Class Initialized
INFO - 2016-06-06 10:39:29 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:39:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:39:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:39:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:39:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:39:29 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:39:29 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:39:29 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:39:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:39:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:39:29 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:39:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:39:29 --> Final output sent to browser
DEBUG - 2016-06-06 10:39:29 --> Total execution time: 0.0282
INFO - 2016-06-06 10:39:46 --> Config Class Initialized
INFO - 2016-06-06 10:39:46 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:39:46 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:39:46 --> Utf8 Class Initialized
INFO - 2016-06-06 10:39:46 --> URI Class Initialized
INFO - 2016-06-06 10:39:46 --> Router Class Initialized
INFO - 2016-06-06 10:39:46 --> Output Class Initialized
INFO - 2016-06-06 10:39:46 --> Security Class Initialized
DEBUG - 2016-06-06 10:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:39:46 --> CSRF cookie sent
INFO - 2016-06-06 10:39:46 --> CSRF token verified
INFO - 2016-06-06 10:39:46 --> Input Class Initialized
INFO - 2016-06-06 10:39:46 --> Language Class Initialized
INFO - 2016-06-06 10:39:46 --> Loader Class Initialized
INFO - 2016-06-06 10:39:46 --> Helper loaded: form_helper
INFO - 2016-06-06 10:39:46 --> Database Driver Class Initialized
INFO - 2016-06-06 10:39:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:39:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:39:46 --> Email Class Initialized
INFO - 2016-06-06 10:39:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:39:46 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:39:46 --> Helper loaded: language_helper
INFO - 2016-06-06 10:39:46 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:39:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:39:46 --> Model Class Initialized
INFO - 2016-06-06 10:39:46 --> Helper loaded: date_helper
INFO - 2016-06-06 10:39:46 --> Controller Class Initialized
INFO - 2016-06-06 10:39:46 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:39:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:39:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:39:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:39:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:39:46 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:39:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:39:46 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:39:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:39:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:39:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:39:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:39:46 --> Final output sent to browser
DEBUG - 2016-06-06 10:39:46 --> Total execution time: 0.0383
INFO - 2016-06-06 10:43:05 --> Config Class Initialized
INFO - 2016-06-06 10:43:05 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:43:05 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:43:05 --> Utf8 Class Initialized
INFO - 2016-06-06 10:43:05 --> URI Class Initialized
INFO - 2016-06-06 10:43:05 --> Router Class Initialized
INFO - 2016-06-06 10:43:05 --> Output Class Initialized
INFO - 2016-06-06 10:43:05 --> Security Class Initialized
DEBUG - 2016-06-06 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:43:05 --> CSRF cookie sent
INFO - 2016-06-06 10:43:05 --> Input Class Initialized
INFO - 2016-06-06 10:43:05 --> Language Class Initialized
INFO - 2016-06-06 10:43:05 --> Loader Class Initialized
INFO - 2016-06-06 10:43:05 --> Helper loaded: form_helper
INFO - 2016-06-06 10:43:05 --> Database Driver Class Initialized
INFO - 2016-06-06 10:43:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:43:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:43:05 --> Email Class Initialized
INFO - 2016-06-06 10:43:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:43:05 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:43:05 --> Helper loaded: language_helper
INFO - 2016-06-06 10:43:05 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:43:05 --> Model Class Initialized
INFO - 2016-06-06 10:43:05 --> Helper loaded: date_helper
INFO - 2016-06-06 10:43:05 --> Controller Class Initialized
INFO - 2016-06-06 10:43:05 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:43:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:43:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:43:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:43:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:43:05 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:43:05 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:43:05 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:43:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:43:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:43:05 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:43:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:43:05 --> Final output sent to browser
DEBUG - 2016-06-06 10:43:05 --> Total execution time: 0.1377
INFO - 2016-06-06 10:43:28 --> Config Class Initialized
INFO - 2016-06-06 10:43:28 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:43:28 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:43:28 --> Utf8 Class Initialized
INFO - 2016-06-06 10:43:28 --> URI Class Initialized
INFO - 2016-06-06 10:43:28 --> Router Class Initialized
INFO - 2016-06-06 10:43:28 --> Output Class Initialized
INFO - 2016-06-06 10:43:28 --> Security Class Initialized
DEBUG - 2016-06-06 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:43:28 --> CSRF cookie sent
INFO - 2016-06-06 10:43:28 --> Input Class Initialized
INFO - 2016-06-06 10:43:28 --> Language Class Initialized
INFO - 2016-06-06 10:43:28 --> Loader Class Initialized
INFO - 2016-06-06 10:43:28 --> Helper loaded: form_helper
INFO - 2016-06-06 10:43:28 --> Database Driver Class Initialized
INFO - 2016-06-06 10:43:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:43:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:43:28 --> Email Class Initialized
INFO - 2016-06-06 10:43:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:43:28 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:43:28 --> Helper loaded: language_helper
INFO - 2016-06-06 10:43:28 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:43:28 --> Model Class Initialized
INFO - 2016-06-06 10:43:28 --> Helper loaded: date_helper
INFO - 2016-06-06 10:43:28 --> Controller Class Initialized
INFO - 2016-06-06 10:43:28 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:43:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:43:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:43:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:43:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:43:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:43:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:43:28 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:43:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:43:28 --> Final output sent to browser
DEBUG - 2016-06-06 10:43:28 --> Total execution time: 0.0329
INFO - 2016-06-06 10:45:13 --> Config Class Initialized
INFO - 2016-06-06 10:45:13 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:45:13 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:45:13 --> Utf8 Class Initialized
INFO - 2016-06-06 10:45:13 --> URI Class Initialized
INFO - 2016-06-06 10:45:13 --> Router Class Initialized
INFO - 2016-06-06 10:45:13 --> Output Class Initialized
INFO - 2016-06-06 10:45:13 --> Security Class Initialized
DEBUG - 2016-06-06 10:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:45:13 --> CSRF cookie sent
INFO - 2016-06-06 10:45:13 --> Input Class Initialized
INFO - 2016-06-06 10:45:13 --> Language Class Initialized
INFO - 2016-06-06 10:45:13 --> Loader Class Initialized
INFO - 2016-06-06 10:45:13 --> Helper loaded: form_helper
INFO - 2016-06-06 10:45:13 --> Database Driver Class Initialized
INFO - 2016-06-06 10:45:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:45:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:45:13 --> Email Class Initialized
INFO - 2016-06-06 10:45:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:45:13 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:45:13 --> Helper loaded: language_helper
INFO - 2016-06-06 10:45:13 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:13 --> Model Class Initialized
INFO - 2016-06-06 10:45:13 --> Helper loaded: date_helper
INFO - 2016-06-06 10:45:13 --> Controller Class Initialized
INFO - 2016-06-06 10:45:13 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:45:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:45:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:45:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:45:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:45:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:45:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:13 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:45:13 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:45:13 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:45:13 --> Final output sent to browser
DEBUG - 2016-06-06 10:45:13 --> Total execution time: 0.0995
INFO - 2016-06-06 10:45:28 --> Config Class Initialized
INFO - 2016-06-06 10:45:28 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:45:28 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:45:28 --> Utf8 Class Initialized
INFO - 2016-06-06 10:45:28 --> URI Class Initialized
INFO - 2016-06-06 10:45:28 --> Router Class Initialized
INFO - 2016-06-06 10:45:28 --> Output Class Initialized
INFO - 2016-06-06 10:45:28 --> Security Class Initialized
DEBUG - 2016-06-06 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:45:28 --> CSRF cookie sent
INFO - 2016-06-06 10:45:28 --> Input Class Initialized
INFO - 2016-06-06 10:45:28 --> Language Class Initialized
INFO - 2016-06-06 10:45:28 --> Loader Class Initialized
INFO - 2016-06-06 10:45:28 --> Helper loaded: form_helper
INFO - 2016-06-06 10:45:28 --> Database Driver Class Initialized
INFO - 2016-06-06 10:45:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:45:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:45:28 --> Email Class Initialized
INFO - 2016-06-06 10:45:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:45:28 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:45:28 --> Helper loaded: language_helper
INFO - 2016-06-06 10:45:28 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:28 --> Model Class Initialized
INFO - 2016-06-06 10:45:28 --> Helper loaded: date_helper
INFO - 2016-06-06 10:45:28 --> Controller Class Initialized
INFO - 2016-06-06 10:45:28 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:45:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:45:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:45:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:45:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:45:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:45:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:28 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:45:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:45:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:45:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:45:28 --> Final output sent to browser
DEBUG - 2016-06-06 10:45:28 --> Total execution time: 0.0234
INFO - 2016-06-06 10:45:57 --> Config Class Initialized
INFO - 2016-06-06 10:45:57 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:45:57 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:45:57 --> Utf8 Class Initialized
INFO - 2016-06-06 10:45:57 --> URI Class Initialized
INFO - 2016-06-06 10:45:57 --> Router Class Initialized
INFO - 2016-06-06 10:45:57 --> Output Class Initialized
INFO - 2016-06-06 10:45:57 --> Security Class Initialized
DEBUG - 2016-06-06 10:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:45:57 --> CSRF cookie sent
INFO - 2016-06-06 10:45:57 --> CSRF token verified
INFO - 2016-06-06 10:45:57 --> Input Class Initialized
INFO - 2016-06-06 10:45:57 --> Language Class Initialized
INFO - 2016-06-06 10:45:57 --> Loader Class Initialized
INFO - 2016-06-06 10:45:57 --> Helper loaded: form_helper
INFO - 2016-06-06 10:45:57 --> Database Driver Class Initialized
INFO - 2016-06-06 10:45:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:45:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:45:57 --> Email Class Initialized
INFO - 2016-06-06 10:45:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:45:57 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:45:57 --> Helper loaded: language_helper
INFO - 2016-06-06 10:45:57 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:45:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:57 --> Model Class Initialized
INFO - 2016-06-06 10:45:57 --> Helper loaded: date_helper
INFO - 2016-06-06 10:45:57 --> Controller Class Initialized
INFO - 2016-06-06 10:45:57 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:45:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:45:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:45:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:45:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:45:57 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:45:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:57 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:45:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:45:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:45:57 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:45:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:45:57 --> Final output sent to browser
DEBUG - 2016-06-06 10:45:57 --> Total execution time: 0.0436
INFO - 2016-06-06 10:46:10 --> Config Class Initialized
INFO - 2016-06-06 10:46:10 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:46:10 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:46:10 --> Utf8 Class Initialized
INFO - 2016-06-06 10:46:10 --> URI Class Initialized
INFO - 2016-06-06 10:46:10 --> Router Class Initialized
INFO - 2016-06-06 10:46:10 --> Output Class Initialized
INFO - 2016-06-06 10:46:10 --> Security Class Initialized
DEBUG - 2016-06-06 10:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:46:10 --> CSRF cookie sent
INFO - 2016-06-06 10:46:10 --> CSRF token verified
INFO - 2016-06-06 10:46:10 --> Input Class Initialized
INFO - 2016-06-06 10:46:10 --> Language Class Initialized
INFO - 2016-06-06 10:46:10 --> Loader Class Initialized
INFO - 2016-06-06 10:46:10 --> Helper loaded: form_helper
INFO - 2016-06-06 10:46:10 --> Database Driver Class Initialized
INFO - 2016-06-06 10:46:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:46:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:46:11 --> Email Class Initialized
INFO - 2016-06-06 10:46:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:46:11 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:46:11 --> Helper loaded: language_helper
INFO - 2016-06-06 10:46:11 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:46:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:11 --> Model Class Initialized
INFO - 2016-06-06 10:46:11 --> Helper loaded: date_helper
INFO - 2016-06-06 10:46:11 --> Controller Class Initialized
INFO - 2016-06-06 10:46:11 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:46:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:46:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:46:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:46:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:46:11 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:46:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:11 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:46:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:46:11 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:46:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:46:11 --> Final output sent to browser
DEBUG - 2016-06-06 10:46:11 --> Total execution time: 0.0824
INFO - 2016-06-06 10:46:20 --> Config Class Initialized
INFO - 2016-06-06 10:46:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:46:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:46:20 --> Utf8 Class Initialized
INFO - 2016-06-06 10:46:20 --> URI Class Initialized
INFO - 2016-06-06 10:46:20 --> Router Class Initialized
INFO - 2016-06-06 10:46:20 --> Output Class Initialized
INFO - 2016-06-06 10:46:20 --> Security Class Initialized
DEBUG - 2016-06-06 10:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:46:20 --> CSRF cookie sent
INFO - 2016-06-06 10:46:20 --> CSRF token verified
INFO - 2016-06-06 10:46:20 --> Input Class Initialized
INFO - 2016-06-06 10:46:20 --> Language Class Initialized
INFO - 2016-06-06 10:46:20 --> Loader Class Initialized
INFO - 2016-06-06 10:46:20 --> Helper loaded: form_helper
INFO - 2016-06-06 10:46:20 --> Database Driver Class Initialized
INFO - 2016-06-06 10:46:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:46:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:46:20 --> Email Class Initialized
INFO - 2016-06-06 10:46:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:46:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:46:20 --> Helper loaded: language_helper
INFO - 2016-06-06 10:46:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:20 --> Model Class Initialized
INFO - 2016-06-06 10:46:20 --> Helper loaded: date_helper
INFO - 2016-06-06 10:46:20 --> Controller Class Initialized
INFO - 2016-06-06 10:46:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:46:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:46:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:46:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:46:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:46:20 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:46:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:20 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:46:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:46:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:46:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:46:20 --> Final output sent to browser
DEBUG - 2016-06-06 10:46:20 --> Total execution time: 0.0708
INFO - 2016-06-06 10:46:52 --> Config Class Initialized
INFO - 2016-06-06 10:46:52 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:46:52 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:46:52 --> Utf8 Class Initialized
INFO - 2016-06-06 10:46:52 --> URI Class Initialized
INFO - 2016-06-06 10:46:52 --> Router Class Initialized
INFO - 2016-06-06 10:46:52 --> Output Class Initialized
INFO - 2016-06-06 10:46:52 --> Security Class Initialized
DEBUG - 2016-06-06 10:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:46:52 --> CSRF cookie sent
INFO - 2016-06-06 10:46:52 --> CSRF token verified
INFO - 2016-06-06 10:46:52 --> Input Class Initialized
INFO - 2016-06-06 10:46:52 --> Language Class Initialized
INFO - 2016-06-06 10:46:52 --> Loader Class Initialized
INFO - 2016-06-06 10:46:52 --> Helper loaded: form_helper
INFO - 2016-06-06 10:46:52 --> Database Driver Class Initialized
INFO - 2016-06-06 10:46:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:46:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:46:52 --> Email Class Initialized
INFO - 2016-06-06 10:46:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:46:52 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:46:52 --> Helper loaded: language_helper
INFO - 2016-06-06 10:46:52 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:52 --> Model Class Initialized
INFO - 2016-06-06 10:46:52 --> Helper loaded: date_helper
INFO - 2016-06-06 10:46:52 --> Controller Class Initialized
INFO - 2016-06-06 10:46:52 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:46:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:46:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:46:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:46:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:46:52 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:46:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:52 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:46:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:46:52 --> Final output sent to browser
DEBUG - 2016-06-06 10:46:52 --> Total execution time: 0.1853
INFO - 2016-06-06 10:51:46 --> Config Class Initialized
INFO - 2016-06-06 10:51:46 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:51:46 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:51:46 --> Utf8 Class Initialized
INFO - 2016-06-06 10:51:46 --> URI Class Initialized
INFO - 2016-06-06 10:51:46 --> Router Class Initialized
INFO - 2016-06-06 10:51:46 --> Output Class Initialized
INFO - 2016-06-06 10:51:46 --> Security Class Initialized
DEBUG - 2016-06-06 10:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:51:46 --> CSRF cookie sent
INFO - 2016-06-06 10:51:46 --> CSRF token verified
INFO - 2016-06-06 10:51:46 --> Input Class Initialized
INFO - 2016-06-06 10:51:46 --> Language Class Initialized
INFO - 2016-06-06 10:51:46 --> Loader Class Initialized
INFO - 2016-06-06 10:51:46 --> Helper loaded: form_helper
INFO - 2016-06-06 10:51:46 --> Database Driver Class Initialized
INFO - 2016-06-06 10:51:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:51:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:51:46 --> Email Class Initialized
INFO - 2016-06-06 10:51:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:51:46 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:51:46 --> Helper loaded: language_helper
INFO - 2016-06-06 10:51:46 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:51:46 --> Model Class Initialized
INFO - 2016-06-06 10:51:46 --> Helper loaded: date_helper
INFO - 2016-06-06 10:51:46 --> Controller Class Initialized
INFO - 2016-06-06 10:51:46 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:51:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:51:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:51:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:51:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:51:46 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:51:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:51:46 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:51:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:51:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:51:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:51:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:51:46 --> Final output sent to browser
DEBUG - 2016-06-06 10:51:46 --> Total execution time: 0.1098
INFO - 2016-06-06 10:52:25 --> Config Class Initialized
INFO - 2016-06-06 10:52:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:52:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:52:25 --> Utf8 Class Initialized
INFO - 2016-06-06 10:52:25 --> URI Class Initialized
INFO - 2016-06-06 10:52:25 --> Router Class Initialized
INFO - 2016-06-06 10:52:25 --> Output Class Initialized
INFO - 2016-06-06 10:52:25 --> Security Class Initialized
DEBUG - 2016-06-06 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:52:25 --> CSRF cookie sent
INFO - 2016-06-06 10:52:25 --> CSRF token verified
INFO - 2016-06-06 10:52:25 --> Input Class Initialized
INFO - 2016-06-06 10:52:25 --> Language Class Initialized
INFO - 2016-06-06 10:52:25 --> Loader Class Initialized
INFO - 2016-06-06 10:52:25 --> Helper loaded: form_helper
INFO - 2016-06-06 10:52:25 --> Database Driver Class Initialized
INFO - 2016-06-06 10:52:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:52:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:52:25 --> Email Class Initialized
INFO - 2016-06-06 10:52:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:52:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:52:25 --> Helper loaded: language_helper
INFO - 2016-06-06 10:52:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:52:25 --> Model Class Initialized
INFO - 2016-06-06 10:52:25 --> Helper loaded: date_helper
INFO - 2016-06-06 10:52:25 --> Controller Class Initialized
INFO - 2016-06-06 10:52:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:52:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:52:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:52:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:52:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:52:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:52:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:52:25 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:52:41 --> Config Class Initialized
INFO - 2016-06-06 10:52:41 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:52:41 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:52:41 --> Utf8 Class Initialized
INFO - 2016-06-06 10:52:41 --> URI Class Initialized
INFO - 2016-06-06 10:52:41 --> Router Class Initialized
INFO - 2016-06-06 10:52:41 --> Output Class Initialized
INFO - 2016-06-06 10:52:41 --> Security Class Initialized
DEBUG - 2016-06-06 10:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:52:44 --> Config Class Initialized
INFO - 2016-06-06 10:52:44 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:52:44 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:52:44 --> Utf8 Class Initialized
INFO - 2016-06-06 10:52:44 --> URI Class Initialized
INFO - 2016-06-06 10:52:44 --> Router Class Initialized
INFO - 2016-06-06 10:52:44 --> Output Class Initialized
INFO - 2016-06-06 10:52:44 --> Security Class Initialized
DEBUG - 2016-06-06 10:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:52:44 --> CSRF cookie sent
INFO - 2016-06-06 10:52:44 --> Input Class Initialized
INFO - 2016-06-06 10:52:44 --> Language Class Initialized
INFO - 2016-06-06 10:52:44 --> Loader Class Initialized
INFO - 2016-06-06 10:52:44 --> Helper loaded: form_helper
INFO - 2016-06-06 10:52:44 --> Database Driver Class Initialized
INFO - 2016-06-06 10:52:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:52:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:52:44 --> Email Class Initialized
INFO - 2016-06-06 10:52:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:52:44 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:52:44 --> Helper loaded: language_helper
INFO - 2016-06-06 10:52:44 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:52:44 --> Model Class Initialized
INFO - 2016-06-06 10:52:44 --> Helper loaded: date_helper
INFO - 2016-06-06 10:52:44 --> Controller Class Initialized
INFO - 2016-06-06 10:52:44 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:52:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:52:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:52:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:52:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:52:44 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:52:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:52:44 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:52:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:52:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:52:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:52:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:52:44 --> Final output sent to browser
DEBUG - 2016-06-06 10:52:44 --> Total execution time: 0.1004
INFO - 2016-06-06 10:53:18 --> Config Class Initialized
INFO - 2016-06-06 10:53:18 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:53:18 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:53:18 --> Utf8 Class Initialized
INFO - 2016-06-06 10:53:18 --> URI Class Initialized
INFO - 2016-06-06 10:53:18 --> Router Class Initialized
INFO - 2016-06-06 10:53:18 --> Output Class Initialized
INFO - 2016-06-06 10:53:18 --> Security Class Initialized
DEBUG - 2016-06-06 10:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:53:18 --> CSRF cookie sent
INFO - 2016-06-06 10:53:18 --> CSRF token verified
INFO - 2016-06-06 10:53:18 --> Input Class Initialized
INFO - 2016-06-06 10:53:18 --> Language Class Initialized
INFO - 2016-06-06 10:53:18 --> Loader Class Initialized
INFO - 2016-06-06 10:53:18 --> Helper loaded: form_helper
INFO - 2016-06-06 10:53:18 --> Database Driver Class Initialized
INFO - 2016-06-06 10:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:53:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:53:18 --> Email Class Initialized
INFO - 2016-06-06 10:53:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:53:18 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:53:18 --> Helper loaded: language_helper
INFO - 2016-06-06 10:53:18 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:18 --> Model Class Initialized
INFO - 2016-06-06 10:53:18 --> Helper loaded: date_helper
INFO - 2016-06-06 10:53:18 --> Controller Class Initialized
INFO - 2016-06-06 10:53:18 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:53:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:53:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:53:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:53:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:53:18 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:53:18 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:18 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:41 --> Config Class Initialized
INFO - 2016-06-06 10:53:41 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:53:41 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:53:41 --> Utf8 Class Initialized
INFO - 2016-06-06 10:53:41 --> URI Class Initialized
INFO - 2016-06-06 10:53:41 --> Router Class Initialized
INFO - 2016-06-06 10:53:41 --> Output Class Initialized
INFO - 2016-06-06 10:53:41 --> Security Class Initialized
DEBUG - 2016-06-06 10:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:53:43 --> Config Class Initialized
INFO - 2016-06-06 10:53:43 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:53:43 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:53:43 --> Utf8 Class Initialized
INFO - 2016-06-06 10:53:43 --> URI Class Initialized
INFO - 2016-06-06 10:53:43 --> Router Class Initialized
INFO - 2016-06-06 10:53:43 --> Output Class Initialized
INFO - 2016-06-06 10:53:43 --> Security Class Initialized
DEBUG - 2016-06-06 10:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:53:43 --> CSRF cookie sent
INFO - 2016-06-06 10:53:43 --> Input Class Initialized
INFO - 2016-06-06 10:53:43 --> Language Class Initialized
INFO - 2016-06-06 10:53:43 --> Loader Class Initialized
INFO - 2016-06-06 10:53:43 --> Helper loaded: form_helper
INFO - 2016-06-06 10:53:43 --> Database Driver Class Initialized
INFO - 2016-06-06 10:53:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:53:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:53:43 --> Email Class Initialized
INFO - 2016-06-06 10:53:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:53:43 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:53:43 --> Helper loaded: language_helper
INFO - 2016-06-06 10:53:43 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:43 --> Model Class Initialized
INFO - 2016-06-06 10:53:43 --> Helper loaded: date_helper
INFO - 2016-06-06 10:53:43 --> Controller Class Initialized
INFO - 2016-06-06 10:53:43 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:53:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:53:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:53:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:53:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:53:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:53:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:43 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:53:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:53:43 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:53:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:53:43 --> Final output sent to browser
DEBUG - 2016-06-06 10:53:43 --> Total execution time: 0.0370
INFO - 2016-06-06 10:53:54 --> Config Class Initialized
INFO - 2016-06-06 10:53:54 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:53:54 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:53:54 --> Utf8 Class Initialized
INFO - 2016-06-06 10:53:54 --> URI Class Initialized
INFO - 2016-06-06 10:53:54 --> Router Class Initialized
INFO - 2016-06-06 10:53:54 --> Output Class Initialized
INFO - 2016-06-06 10:53:54 --> Security Class Initialized
DEBUG - 2016-06-06 10:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:53:54 --> CSRF cookie sent
INFO - 2016-06-06 10:53:54 --> CSRF token verified
INFO - 2016-06-06 10:53:55 --> Input Class Initialized
INFO - 2016-06-06 10:53:55 --> Language Class Initialized
INFO - 2016-06-06 10:53:55 --> Loader Class Initialized
INFO - 2016-06-06 10:53:55 --> Helper loaded: form_helper
INFO - 2016-06-06 10:53:55 --> Database Driver Class Initialized
INFO - 2016-06-06 10:53:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:53:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:53:55 --> Email Class Initialized
INFO - 2016-06-06 10:53:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:53:55 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:53:55 --> Helper loaded: language_helper
INFO - 2016-06-06 10:53:55 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:55 --> Model Class Initialized
INFO - 2016-06-06 10:53:55 --> Helper loaded: date_helper
INFO - 2016-06-06 10:53:55 --> Controller Class Initialized
INFO - 2016-06-06 10:53:55 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:53:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:53:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:53:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:53:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:53:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:53:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:53:55 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:53:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:54:06 --> Config Class Initialized
INFO - 2016-06-06 10:54:06 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:54:06 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:54:06 --> Utf8 Class Initialized
INFO - 2016-06-06 10:54:06 --> URI Class Initialized
INFO - 2016-06-06 10:54:06 --> Router Class Initialized
INFO - 2016-06-06 10:54:06 --> Output Class Initialized
INFO - 2016-06-06 10:54:06 --> Security Class Initialized
DEBUG - 2016-06-06 10:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:54:06 --> CSRF cookie sent
INFO - 2016-06-06 10:54:06 --> Input Class Initialized
INFO - 2016-06-06 10:54:06 --> Language Class Initialized
INFO - 2016-06-06 10:54:06 --> Loader Class Initialized
INFO - 2016-06-06 10:54:06 --> Helper loaded: form_helper
INFO - 2016-06-06 10:54:06 --> Database Driver Class Initialized
INFO - 2016-06-06 10:54:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:54:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:54:06 --> Email Class Initialized
INFO - 2016-06-06 10:54:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:54:06 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:54:06 --> Helper loaded: language_helper
INFO - 2016-06-06 10:54:06 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:54:06 --> Model Class Initialized
INFO - 2016-06-06 10:54:06 --> Helper loaded: date_helper
INFO - 2016-06-06 10:54:06 --> Controller Class Initialized
INFO - 2016-06-06 10:54:06 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:54:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:54:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:54:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:54:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:54:06 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:54:06 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:54:06 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:54:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:54:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:54:06 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:54:06 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:54:06 --> Final output sent to browser
DEBUG - 2016-06-06 10:54:06 --> Total execution time: 0.0144
INFO - 2016-06-06 10:54:25 --> Config Class Initialized
INFO - 2016-06-06 10:54:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:54:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:54:25 --> Utf8 Class Initialized
INFO - 2016-06-06 10:54:25 --> URI Class Initialized
INFO - 2016-06-06 10:54:25 --> Router Class Initialized
INFO - 2016-06-06 10:54:25 --> Output Class Initialized
INFO - 2016-06-06 10:54:25 --> Security Class Initialized
DEBUG - 2016-06-06 10:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:54:25 --> CSRF cookie sent
INFO - 2016-06-06 10:54:25 --> CSRF token verified
INFO - 2016-06-06 10:54:25 --> Input Class Initialized
INFO - 2016-06-06 10:54:25 --> Language Class Initialized
INFO - 2016-06-06 10:54:25 --> Loader Class Initialized
INFO - 2016-06-06 10:54:25 --> Helper loaded: form_helper
INFO - 2016-06-06 10:54:25 --> Database Driver Class Initialized
INFO - 2016-06-06 10:54:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:54:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:54:25 --> Email Class Initialized
INFO - 2016-06-06 10:54:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:54:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:54:25 --> Helper loaded: language_helper
INFO - 2016-06-06 10:54:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:54:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:54:25 --> Model Class Initialized
INFO - 2016-06-06 10:54:25 --> Helper loaded: date_helper
INFO - 2016-06-06 10:54:25 --> Controller Class Initialized
INFO - 2016-06-06 10:54:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:54:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:54:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:54:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:54:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:54:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:54:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:54:25 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:54:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:55:53 --> Config Class Initialized
INFO - 2016-06-06 10:55:53 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:55:53 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:55:53 --> Utf8 Class Initialized
INFO - 2016-06-06 10:55:53 --> URI Class Initialized
INFO - 2016-06-06 10:55:53 --> Router Class Initialized
INFO - 2016-06-06 10:55:53 --> Output Class Initialized
INFO - 2016-06-06 10:55:53 --> Security Class Initialized
DEBUG - 2016-06-06 10:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:55:53 --> Input Class Initialized
INFO - 2016-06-06 10:55:53 --> Language Class Initialized
INFO - 2016-06-06 10:55:53 --> Loader Class Initialized
INFO - 2016-06-06 10:55:53 --> Helper loaded: form_helper
INFO - 2016-06-06 10:55:53 --> Database Driver Class Initialized
INFO - 2016-06-06 10:55:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:55:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:55:53 --> Email Class Initialized
INFO - 2016-06-06 10:55:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:55:53 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:55:53 --> Helper loaded: language_helper
INFO - 2016-06-06 10:55:53 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:55:53 --> Model Class Initialized
INFO - 2016-06-06 10:55:53 --> Helper loaded: date_helper
INFO - 2016-06-06 10:55:53 --> Controller Class Initialized
INFO - 2016-06-06 10:55:53 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:55:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:55:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:55:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:55:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:55:53 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:55:53 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:55:53 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:55:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:55:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 10:55:53 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 10:55:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 10:55:53 --> Final output sent to browser
DEBUG - 2016-06-06 10:55:53 --> Total execution time: 0.0447
INFO - 2016-06-06 10:56:10 --> Config Class Initialized
INFO - 2016-06-06 10:56:10 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:56:10 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:56:10 --> Utf8 Class Initialized
INFO - 2016-06-06 10:56:10 --> URI Class Initialized
INFO - 2016-06-06 10:56:10 --> Router Class Initialized
INFO - 2016-06-06 10:56:10 --> Output Class Initialized
INFO - 2016-06-06 10:56:10 --> Security Class Initialized
DEBUG - 2016-06-06 10:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:56:10 --> Input Class Initialized
INFO - 2016-06-06 10:56:10 --> Language Class Initialized
INFO - 2016-06-06 10:56:10 --> Loader Class Initialized
INFO - 2016-06-06 10:56:10 --> Helper loaded: form_helper
INFO - 2016-06-06 10:56:10 --> Database Driver Class Initialized
INFO - 2016-06-06 10:56:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:56:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:56:10 --> Email Class Initialized
INFO - 2016-06-06 10:56:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:56:10 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:56:10 --> Helper loaded: language_helper
INFO - 2016-06-06 10:56:10 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:56:10 --> Model Class Initialized
INFO - 2016-06-06 10:56:10 --> Helper loaded: date_helper
INFO - 2016-06-06 10:56:10 --> Controller Class Initialized
INFO - 2016-06-06 10:56:10 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:56:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:56:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:56:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:56:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:56:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:56:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:56:10 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:56:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:57:13 --> Config Class Initialized
INFO - 2016-06-06 10:57:13 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:57:13 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:57:13 --> Utf8 Class Initialized
INFO - 2016-06-06 10:57:13 --> URI Class Initialized
INFO - 2016-06-06 10:57:13 --> Router Class Initialized
INFO - 2016-06-06 10:57:13 --> Output Class Initialized
INFO - 2016-06-06 10:57:13 --> Security Class Initialized
DEBUG - 2016-06-06 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:57:13 --> Input Class Initialized
INFO - 2016-06-06 10:57:13 --> Language Class Initialized
INFO - 2016-06-06 10:57:13 --> Loader Class Initialized
INFO - 2016-06-06 10:57:13 --> Helper loaded: form_helper
INFO - 2016-06-06 10:57:13 --> Database Driver Class Initialized
INFO - 2016-06-06 10:57:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:57:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:57:13 --> Email Class Initialized
INFO - 2016-06-06 10:57:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:57:13 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:57:13 --> Helper loaded: language_helper
INFO - 2016-06-06 10:57:13 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:57:13 --> Model Class Initialized
INFO - 2016-06-06 10:57:13 --> Helper loaded: date_helper
INFO - 2016-06-06 10:57:13 --> Controller Class Initialized
INFO - 2016-06-06 10:57:13 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:57:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:57:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:57:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:57:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:57:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:57:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:57:13 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:57:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:58:09 --> Config Class Initialized
INFO - 2016-06-06 10:58:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 10:58:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 10:58:09 --> Utf8 Class Initialized
INFO - 2016-06-06 10:58:09 --> URI Class Initialized
INFO - 2016-06-06 10:58:09 --> Router Class Initialized
INFO - 2016-06-06 10:58:09 --> Output Class Initialized
INFO - 2016-06-06 10:58:09 --> Security Class Initialized
DEBUG - 2016-06-06 10:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 10:58:09 --> Input Class Initialized
INFO - 2016-06-06 10:58:09 --> Language Class Initialized
INFO - 2016-06-06 10:58:09 --> Loader Class Initialized
INFO - 2016-06-06 10:58:09 --> Helper loaded: form_helper
INFO - 2016-06-06 10:58:09 --> Database Driver Class Initialized
INFO - 2016-06-06 10:58:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 10:58:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 10:58:09 --> Email Class Initialized
INFO - 2016-06-06 10:58:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 10:58:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 10:58:09 --> Helper loaded: language_helper
INFO - 2016-06-06 10:58:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 10:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:58:09 --> Model Class Initialized
INFO - 2016-06-06 10:58:09 --> Helper loaded: date_helper
INFO - 2016-06-06 10:58:09 --> Controller Class Initialized
INFO - 2016-06-06 10:58:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 10:58:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 10:58:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 10:58:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 10:58:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 10:58:09 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 10:58:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 10:58:09 --> Form Validation Class Initialized
DEBUG - 2016-06-06 10:58:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:02 --> Config Class Initialized
INFO - 2016-06-06 11:00:02 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:00:02 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:00:02 --> Utf8 Class Initialized
INFO - 2016-06-06 11:00:02 --> URI Class Initialized
INFO - 2016-06-06 11:00:02 --> Router Class Initialized
INFO - 2016-06-06 11:00:02 --> Output Class Initialized
INFO - 2016-06-06 11:00:02 --> Security Class Initialized
DEBUG - 2016-06-06 11:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:00:02 --> Input Class Initialized
INFO - 2016-06-06 11:00:02 --> Language Class Initialized
INFO - 2016-06-06 11:00:02 --> Loader Class Initialized
INFO - 2016-06-06 11:00:02 --> Helper loaded: form_helper
INFO - 2016-06-06 11:00:02 --> Database Driver Class Initialized
INFO - 2016-06-06 11:00:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:00:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:00:02 --> Email Class Initialized
INFO - 2016-06-06 11:00:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:00:02 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:00:02 --> Helper loaded: language_helper
INFO - 2016-06-06 11:00:02 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:02 --> Model Class Initialized
INFO - 2016-06-06 11:00:02 --> Helper loaded: date_helper
INFO - 2016-06-06 11:00:02 --> Controller Class Initialized
INFO - 2016-06-06 11:00:02 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:00:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:00:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:00:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:00:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:00:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:00:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:02 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:00:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:03 --> Config Class Initialized
INFO - 2016-06-06 11:00:03 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:00:03 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:00:03 --> Utf8 Class Initialized
INFO - 2016-06-06 11:00:03 --> URI Class Initialized
INFO - 2016-06-06 11:00:03 --> Router Class Initialized
INFO - 2016-06-06 11:00:03 --> Output Class Initialized
INFO - 2016-06-06 11:00:03 --> Security Class Initialized
DEBUG - 2016-06-06 11:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:00:03 --> Input Class Initialized
INFO - 2016-06-06 11:00:03 --> Language Class Initialized
INFO - 2016-06-06 11:00:03 --> Loader Class Initialized
INFO - 2016-06-06 11:00:03 --> Helper loaded: form_helper
INFO - 2016-06-06 11:00:03 --> Database Driver Class Initialized
INFO - 2016-06-06 11:00:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:00:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:00:03 --> Email Class Initialized
INFO - 2016-06-06 11:00:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:00:03 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:00:03 --> Helper loaded: language_helper
INFO - 2016-06-06 11:00:03 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:03 --> Model Class Initialized
INFO - 2016-06-06 11:00:03 --> Helper loaded: date_helper
INFO - 2016-06-06 11:00:03 --> Controller Class Initialized
INFO - 2016-06-06 11:00:03 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:00:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:00:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:00:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:00:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:00:03 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:00:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:03 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:00:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:00:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:00:03 --> Final output sent to browser
DEBUG - 2016-06-06 11:00:03 --> Total execution time: 0.0401
INFO - 2016-06-06 11:00:09 --> Config Class Initialized
INFO - 2016-06-06 11:00:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:00:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:00:09 --> Utf8 Class Initialized
INFO - 2016-06-06 11:00:09 --> URI Class Initialized
INFO - 2016-06-06 11:00:09 --> Router Class Initialized
INFO - 2016-06-06 11:00:09 --> Output Class Initialized
INFO - 2016-06-06 11:00:09 --> Security Class Initialized
DEBUG - 2016-06-06 11:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:00:09 --> Input Class Initialized
INFO - 2016-06-06 11:00:09 --> Language Class Initialized
INFO - 2016-06-06 11:00:09 --> Loader Class Initialized
INFO - 2016-06-06 11:00:09 --> Helper loaded: form_helper
INFO - 2016-06-06 11:00:09 --> Database Driver Class Initialized
INFO - 2016-06-06 11:00:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:00:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:00:09 --> Email Class Initialized
INFO - 2016-06-06 11:00:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:00:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:00:09 --> Helper loaded: language_helper
INFO - 2016-06-06 11:00:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:09 --> Model Class Initialized
INFO - 2016-06-06 11:00:09 --> Helper loaded: date_helper
INFO - 2016-06-06 11:00:09 --> Controller Class Initialized
INFO - 2016-06-06 11:00:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:00:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:00:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:00:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:00:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:00:09 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:00:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:09 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:12 --> Config Class Initialized
INFO - 2016-06-06 11:00:12 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:00:12 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:00:12 --> Utf8 Class Initialized
INFO - 2016-06-06 11:00:12 --> URI Class Initialized
INFO - 2016-06-06 11:00:12 --> Router Class Initialized
INFO - 2016-06-06 11:00:12 --> Output Class Initialized
INFO - 2016-06-06 11:00:12 --> Security Class Initialized
DEBUG - 2016-06-06 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:00:12 --> Input Class Initialized
INFO - 2016-06-06 11:00:12 --> Language Class Initialized
INFO - 2016-06-06 11:00:12 --> Loader Class Initialized
INFO - 2016-06-06 11:00:12 --> Helper loaded: form_helper
INFO - 2016-06-06 11:00:12 --> Database Driver Class Initialized
INFO - 2016-06-06 11:00:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:00:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:00:12 --> Email Class Initialized
INFO - 2016-06-06 11:00:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:00:12 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:00:12 --> Helper loaded: language_helper
INFO - 2016-06-06 11:00:12 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:12 --> Model Class Initialized
INFO - 2016-06-06 11:00:12 --> Helper loaded: date_helper
INFO - 2016-06-06 11:00:12 --> Controller Class Initialized
INFO - 2016-06-06 11:00:12 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:00:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:00:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:00:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:00:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:00:12 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:00:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:12 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:00:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:00:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:00:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:00:12 --> Final output sent to browser
DEBUG - 2016-06-06 11:00:12 --> Total execution time: 0.0508
INFO - 2016-06-06 11:00:24 --> Config Class Initialized
INFO - 2016-06-06 11:00:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:00:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:00:24 --> Utf8 Class Initialized
INFO - 2016-06-06 11:00:24 --> URI Class Initialized
INFO - 2016-06-06 11:00:24 --> Router Class Initialized
INFO - 2016-06-06 11:00:24 --> Output Class Initialized
INFO - 2016-06-06 11:00:24 --> Security Class Initialized
DEBUG - 2016-06-06 11:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:00:24 --> Input Class Initialized
INFO - 2016-06-06 11:00:24 --> Language Class Initialized
INFO - 2016-06-06 11:00:24 --> Loader Class Initialized
INFO - 2016-06-06 11:00:24 --> Helper loaded: form_helper
INFO - 2016-06-06 11:00:24 --> Database Driver Class Initialized
INFO - 2016-06-06 11:00:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:00:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:00:24 --> Email Class Initialized
INFO - 2016-06-06 11:00:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:00:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:00:24 --> Helper loaded: language_helper
INFO - 2016-06-06 11:00:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:24 --> Model Class Initialized
INFO - 2016-06-06 11:00:24 --> Helper loaded: date_helper
INFO - 2016-06-06 11:00:24 --> Controller Class Initialized
INFO - 2016-06-06 11:00:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:00:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:00:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:00:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:00:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:00:24 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:00:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:00:24 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:00:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:40 --> Config Class Initialized
INFO - 2016-06-06 11:01:40 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:01:40 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:01:40 --> Utf8 Class Initialized
INFO - 2016-06-06 11:01:40 --> URI Class Initialized
INFO - 2016-06-06 11:01:40 --> Router Class Initialized
INFO - 2016-06-06 11:01:40 --> Output Class Initialized
INFO - 2016-06-06 11:01:40 --> Security Class Initialized
DEBUG - 2016-06-06 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:01:40 --> Input Class Initialized
INFO - 2016-06-06 11:01:40 --> Language Class Initialized
INFO - 2016-06-06 11:01:40 --> Loader Class Initialized
INFO - 2016-06-06 11:01:40 --> Helper loaded: form_helper
INFO - 2016-06-06 11:01:40 --> Database Driver Class Initialized
INFO - 2016-06-06 11:01:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:01:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:01:40 --> Email Class Initialized
INFO - 2016-06-06 11:01:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:01:40 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:01:40 --> Helper loaded: language_helper
INFO - 2016-06-06 11:01:40 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:01:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:40 --> Model Class Initialized
INFO - 2016-06-06 11:01:40 --> Helper loaded: date_helper
INFO - 2016-06-06 11:01:40 --> Controller Class Initialized
INFO - 2016-06-06 11:01:40 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:01:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:01:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:01:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:01:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:01:40 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:01:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:40 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:01:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:40 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:01:40 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:01:40 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:01:40 --> Final output sent to browser
DEBUG - 2016-06-06 11:01:40 --> Total execution time: 0.0426
INFO - 2016-06-06 11:01:41 --> Config Class Initialized
INFO - 2016-06-06 11:01:41 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:01:41 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:01:41 --> Utf8 Class Initialized
INFO - 2016-06-06 11:01:41 --> URI Class Initialized
INFO - 2016-06-06 11:01:41 --> Router Class Initialized
INFO - 2016-06-06 11:01:41 --> Output Class Initialized
INFO - 2016-06-06 11:01:41 --> Security Class Initialized
DEBUG - 2016-06-06 11:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:01:41 --> Input Class Initialized
INFO - 2016-06-06 11:01:41 --> Language Class Initialized
INFO - 2016-06-06 11:01:41 --> Loader Class Initialized
INFO - 2016-06-06 11:01:41 --> Helper loaded: form_helper
INFO - 2016-06-06 11:01:41 --> Database Driver Class Initialized
INFO - 2016-06-06 11:01:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:01:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:01:41 --> Email Class Initialized
INFO - 2016-06-06 11:01:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:01:41 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:01:41 --> Helper loaded: language_helper
INFO - 2016-06-06 11:01:41 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:41 --> Model Class Initialized
INFO - 2016-06-06 11:01:41 --> Helper loaded: date_helper
INFO - 2016-06-06 11:01:41 --> Controller Class Initialized
INFO - 2016-06-06 11:01:41 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:01:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:01:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:01:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:01:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:01:41 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:01:41 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:41 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:01:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:01:41 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:01:41 --> Final output sent to browser
DEBUG - 2016-06-06 11:01:41 --> Total execution time: 0.0147
INFO - 2016-06-06 11:01:54 --> Config Class Initialized
INFO - 2016-06-06 11:01:54 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:01:54 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:01:54 --> Utf8 Class Initialized
INFO - 2016-06-06 11:01:54 --> URI Class Initialized
INFO - 2016-06-06 11:01:54 --> Router Class Initialized
INFO - 2016-06-06 11:01:54 --> Output Class Initialized
INFO - 2016-06-06 11:01:54 --> Security Class Initialized
DEBUG - 2016-06-06 11:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:01:54 --> Input Class Initialized
INFO - 2016-06-06 11:01:54 --> Language Class Initialized
INFO - 2016-06-06 11:01:54 --> Loader Class Initialized
INFO - 2016-06-06 11:01:54 --> Helper loaded: form_helper
INFO - 2016-06-06 11:01:54 --> Database Driver Class Initialized
INFO - 2016-06-06 11:01:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:01:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:01:54 --> Email Class Initialized
INFO - 2016-06-06 11:01:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:01:54 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:01:54 --> Helper loaded: language_helper
INFO - 2016-06-06 11:01:54 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:54 --> Model Class Initialized
INFO - 2016-06-06 11:01:54 --> Helper loaded: date_helper
INFO - 2016-06-06 11:01:54 --> Controller Class Initialized
INFO - 2016-06-06 11:01:54 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:01:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:01:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:01:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:01:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:01:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:01:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:01:54 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:01:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:05:37 --> Config Class Initialized
INFO - 2016-06-06 11:05:37 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:05:37 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:05:37 --> Utf8 Class Initialized
INFO - 2016-06-06 11:05:37 --> URI Class Initialized
INFO - 2016-06-06 11:05:37 --> Router Class Initialized
INFO - 2016-06-06 11:05:37 --> Output Class Initialized
INFO - 2016-06-06 11:05:37 --> Security Class Initialized
DEBUG - 2016-06-06 11:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:05:37 --> Input Class Initialized
INFO - 2016-06-06 11:05:37 --> Language Class Initialized
INFO - 2016-06-06 11:05:37 --> Loader Class Initialized
INFO - 2016-06-06 11:05:37 --> Helper loaded: form_helper
INFO - 2016-06-06 11:05:37 --> Database Driver Class Initialized
INFO - 2016-06-06 11:05:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:05:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:05:37 --> Email Class Initialized
INFO - 2016-06-06 11:05:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:05:37 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:05:37 --> Helper loaded: language_helper
INFO - 2016-06-06 11:05:37 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:05:37 --> Model Class Initialized
INFO - 2016-06-06 11:05:37 --> Helper loaded: date_helper
INFO - 2016-06-06 11:05:37 --> Controller Class Initialized
INFO - 2016-06-06 11:05:37 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:05:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:05:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:05:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:05:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:05:37 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:05:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:05:37 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:05:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:08:18 --> Config Class Initialized
INFO - 2016-06-06 11:08:18 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:08:18 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:08:18 --> Utf8 Class Initialized
INFO - 2016-06-06 11:08:18 --> URI Class Initialized
INFO - 2016-06-06 11:08:18 --> Router Class Initialized
INFO - 2016-06-06 11:08:18 --> Output Class Initialized
INFO - 2016-06-06 11:08:18 --> Security Class Initialized
DEBUG - 2016-06-06 11:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:08:18 --> Input Class Initialized
INFO - 2016-06-06 11:08:18 --> Language Class Initialized
INFO - 2016-06-06 11:08:18 --> Loader Class Initialized
INFO - 2016-06-06 11:08:18 --> Helper loaded: form_helper
INFO - 2016-06-06 11:08:18 --> Database Driver Class Initialized
INFO - 2016-06-06 11:08:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:08:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:08:18 --> Email Class Initialized
INFO - 2016-06-06 11:08:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:08:18 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:08:18 --> Helper loaded: language_helper
INFO - 2016-06-06 11:08:18 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:08:18 --> Model Class Initialized
INFO - 2016-06-06 11:08:18 --> Helper loaded: date_helper
INFO - 2016-06-06 11:08:18 --> Controller Class Initialized
INFO - 2016-06-06 11:08:18 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:08:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:08:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:08:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:08:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:08:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:08:18 --> Model Class Initialized
INFO - 2016-06-06 11:08:18 --> Form Validation Class Initialized
INFO - 2016-06-06 11:08:19 --> Config Class Initialized
INFO - 2016-06-06 11:08:19 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:08:19 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:08:19 --> Utf8 Class Initialized
INFO - 2016-06-06 11:08:19 --> URI Class Initialized
INFO - 2016-06-06 11:08:19 --> Router Class Initialized
INFO - 2016-06-06 11:08:19 --> Output Class Initialized
INFO - 2016-06-06 11:08:19 --> Security Class Initialized
DEBUG - 2016-06-06 11:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:08:19 --> Input Class Initialized
INFO - 2016-06-06 11:08:19 --> Language Class Initialized
INFO - 2016-06-06 11:08:19 --> Loader Class Initialized
INFO - 2016-06-06 11:08:19 --> Helper loaded: form_helper
INFO - 2016-06-06 11:08:19 --> Database Driver Class Initialized
INFO - 2016-06-06 11:08:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:08:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:08:19 --> Email Class Initialized
INFO - 2016-06-06 11:08:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:08:19 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:08:19 --> Helper loaded: language_helper
INFO - 2016-06-06 11:08:19 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:08:19 --> Model Class Initialized
INFO - 2016-06-06 11:08:19 --> Helper loaded: date_helper
INFO - 2016-06-06 11:08:19 --> Controller Class Initialized
INFO - 2016-06-06 11:08:19 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:08:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:08:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:08:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:08:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:08:19 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:08:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:08:19 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:08:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:08:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:08:19 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:08:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:08:19 --> Final output sent to browser
DEBUG - 2016-06-06 11:08:19 --> Total execution time: 0.0440
INFO - 2016-06-06 11:12:23 --> Config Class Initialized
INFO - 2016-06-06 11:12:23 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:12:23 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:12:23 --> Utf8 Class Initialized
INFO - 2016-06-06 11:12:23 --> URI Class Initialized
INFO - 2016-06-06 11:12:23 --> Router Class Initialized
INFO - 2016-06-06 11:12:23 --> Output Class Initialized
INFO - 2016-06-06 11:12:23 --> Security Class Initialized
DEBUG - 2016-06-06 11:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:12:23 --> Input Class Initialized
INFO - 2016-06-06 11:12:23 --> Language Class Initialized
INFO - 2016-06-06 11:12:23 --> Loader Class Initialized
INFO - 2016-06-06 11:12:23 --> Helper loaded: form_helper
INFO - 2016-06-06 11:12:23 --> Database Driver Class Initialized
INFO - 2016-06-06 11:12:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:12:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:12:23 --> Email Class Initialized
INFO - 2016-06-06 11:12:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:12:23 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:12:23 --> Helper loaded: language_helper
INFO - 2016-06-06 11:12:23 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:12:23 --> Model Class Initialized
INFO - 2016-06-06 11:12:23 --> Helper loaded: date_helper
INFO - 2016-06-06 11:12:23 --> Controller Class Initialized
INFO - 2016-06-06 11:12:23 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:12:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:12:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:12:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:12:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:12:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:12:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:12:23 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:12:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:12:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:12:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:12:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:12:23 --> Final output sent to browser
DEBUG - 2016-06-06 11:12:23 --> Total execution time: 0.0573
INFO - 2016-06-06 11:12:40 --> Config Class Initialized
INFO - 2016-06-06 11:12:40 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:12:40 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:12:40 --> Utf8 Class Initialized
INFO - 2016-06-06 11:12:40 --> URI Class Initialized
INFO - 2016-06-06 11:12:40 --> Router Class Initialized
INFO - 2016-06-06 11:12:40 --> Output Class Initialized
INFO - 2016-06-06 11:12:40 --> Security Class Initialized
DEBUG - 2016-06-06 11:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:12:40 --> Input Class Initialized
INFO - 2016-06-06 11:12:40 --> Language Class Initialized
INFO - 2016-06-06 11:12:40 --> Loader Class Initialized
INFO - 2016-06-06 11:12:40 --> Helper loaded: form_helper
INFO - 2016-06-06 11:12:40 --> Database Driver Class Initialized
INFO - 2016-06-06 11:12:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:12:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:12:40 --> Email Class Initialized
INFO - 2016-06-06 11:12:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:12:40 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:12:40 --> Helper loaded: language_helper
INFO - 2016-06-06 11:12:40 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:12:40 --> Model Class Initialized
INFO - 2016-06-06 11:12:40 --> Helper loaded: date_helper
INFO - 2016-06-06 11:12:40 --> Controller Class Initialized
INFO - 2016-06-06 11:12:40 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:12:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:12:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:12:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:12:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:12:40 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:12:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:12:40 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:12:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:20 --> Config Class Initialized
INFO - 2016-06-06 11:13:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:13:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:13:20 --> Utf8 Class Initialized
INFO - 2016-06-06 11:13:20 --> URI Class Initialized
INFO - 2016-06-06 11:13:20 --> Router Class Initialized
INFO - 2016-06-06 11:13:20 --> Output Class Initialized
INFO - 2016-06-06 11:13:20 --> Security Class Initialized
DEBUG - 2016-06-06 11:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:13:20 --> Input Class Initialized
INFO - 2016-06-06 11:13:20 --> Language Class Initialized
INFO - 2016-06-06 11:13:20 --> Loader Class Initialized
INFO - 2016-06-06 11:13:20 --> Helper loaded: form_helper
INFO - 2016-06-06 11:13:20 --> Database Driver Class Initialized
INFO - 2016-06-06 11:13:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:13:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:13:20 --> Email Class Initialized
INFO - 2016-06-06 11:13:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:13:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:13:20 --> Helper loaded: language_helper
INFO - 2016-06-06 11:13:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:20 --> Model Class Initialized
INFO - 2016-06-06 11:13:20 --> Helper loaded: date_helper
INFO - 2016-06-06 11:13:20 --> Controller Class Initialized
INFO - 2016-06-06 11:13:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:13:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:13:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:13:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:13:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:13:20 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:13:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:20 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:13:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:34 --> Config Class Initialized
INFO - 2016-06-06 11:13:34 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:13:34 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:13:34 --> Utf8 Class Initialized
INFO - 2016-06-06 11:13:34 --> URI Class Initialized
INFO - 2016-06-06 11:13:34 --> Router Class Initialized
INFO - 2016-06-06 11:13:34 --> Output Class Initialized
INFO - 2016-06-06 11:13:34 --> Security Class Initialized
DEBUG - 2016-06-06 11:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:13:34 --> Input Class Initialized
INFO - 2016-06-06 11:13:34 --> Language Class Initialized
INFO - 2016-06-06 11:13:34 --> Loader Class Initialized
INFO - 2016-06-06 11:13:34 --> Helper loaded: form_helper
INFO - 2016-06-06 11:13:34 --> Database Driver Class Initialized
INFO - 2016-06-06 11:13:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:13:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:13:34 --> Email Class Initialized
INFO - 2016-06-06 11:13:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:13:34 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:13:34 --> Helper loaded: language_helper
INFO - 2016-06-06 11:13:34 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:34 --> Model Class Initialized
INFO - 2016-06-06 11:13:34 --> Helper loaded: date_helper
INFO - 2016-06-06 11:13:34 --> Controller Class Initialized
INFO - 2016-06-06 11:13:34 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:13:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:13:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:13:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:13:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:13:34 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:13:34 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:34 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:13:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:13:34 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:13:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:13:34 --> Final output sent to browser
DEBUG - 2016-06-06 11:13:34 --> Total execution time: 0.1280
INFO - 2016-06-06 11:13:53 --> Config Class Initialized
INFO - 2016-06-06 11:13:53 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:13:53 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:13:53 --> Utf8 Class Initialized
INFO - 2016-06-06 11:13:53 --> URI Class Initialized
INFO - 2016-06-06 11:13:53 --> Router Class Initialized
INFO - 2016-06-06 11:13:53 --> Output Class Initialized
INFO - 2016-06-06 11:13:53 --> Security Class Initialized
DEBUG - 2016-06-06 11:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:13:53 --> Input Class Initialized
INFO - 2016-06-06 11:13:53 --> Language Class Initialized
INFO - 2016-06-06 11:13:53 --> Loader Class Initialized
INFO - 2016-06-06 11:13:53 --> Helper loaded: form_helper
INFO - 2016-06-06 11:13:53 --> Database Driver Class Initialized
INFO - 2016-06-06 11:13:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:13:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:13:53 --> Email Class Initialized
INFO - 2016-06-06 11:13:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:13:53 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:13:53 --> Helper loaded: language_helper
INFO - 2016-06-06 11:13:53 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:53 --> Model Class Initialized
INFO - 2016-06-06 11:13:53 --> Helper loaded: date_helper
INFO - 2016-06-06 11:13:53 --> Controller Class Initialized
INFO - 2016-06-06 11:13:53 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:13:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:13:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:13:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:13:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:13:53 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:13:53 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:53 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:13:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:54 --> Config Class Initialized
INFO - 2016-06-06 11:13:54 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:13:54 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:13:54 --> Utf8 Class Initialized
INFO - 2016-06-06 11:13:54 --> URI Class Initialized
DEBUG - 2016-06-06 11:13:54 --> No URI present. Default controller set.
INFO - 2016-06-06 11:13:54 --> Router Class Initialized
INFO - 2016-06-06 11:13:54 --> Output Class Initialized
INFO - 2016-06-06 11:13:54 --> Security Class Initialized
DEBUG - 2016-06-06 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:13:54 --> Input Class Initialized
INFO - 2016-06-06 11:13:54 --> Language Class Initialized
INFO - 2016-06-06 11:13:54 --> Loader Class Initialized
INFO - 2016-06-06 11:13:54 --> Helper loaded: form_helper
INFO - 2016-06-06 11:13:54 --> Database Driver Class Initialized
INFO - 2016-06-06 11:13:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:13:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:13:54 --> Email Class Initialized
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:13:54 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:13:54 --> Helper loaded: language_helper
INFO - 2016-06-06 11:13:54 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:54 --> Model Class Initialized
INFO - 2016-06-06 11:13:54 --> Helper loaded: date_helper
INFO - 2016-06-06 11:13:54 --> Controller Class Initialized
INFO - 2016-06-06 11:13:54 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:13:54 --> Config Class Initialized
INFO - 2016-06-06 11:13:54 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:13:54 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:13:54 --> Utf8 Class Initialized
INFO - 2016-06-06 11:13:54 --> URI Class Initialized
INFO - 2016-06-06 11:13:54 --> Router Class Initialized
INFO - 2016-06-06 11:13:54 --> Output Class Initialized
INFO - 2016-06-06 11:13:54 --> Security Class Initialized
DEBUG - 2016-06-06 11:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:13:54 --> Input Class Initialized
INFO - 2016-06-06 11:13:54 --> Language Class Initialized
INFO - 2016-06-06 11:13:54 --> Loader Class Initialized
INFO - 2016-06-06 11:13:54 --> Helper loaded: form_helper
INFO - 2016-06-06 11:13:54 --> Database Driver Class Initialized
INFO - 2016-06-06 11:13:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:13:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:13:54 --> Email Class Initialized
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:13:54 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:13:54 --> Helper loaded: language_helper
INFO - 2016-06-06 11:13:54 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:54 --> Model Class Initialized
INFO - 2016-06-06 11:13:54 --> Helper loaded: date_helper
INFO - 2016-06-06 11:13:54 --> Controller Class Initialized
INFO - 2016-06-06 11:13:54 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:13:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:13:54 --> Model Class Initialized
INFO - 2016-06-06 11:13:54 --> Form Validation Class Initialized
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 11:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 11:13:55 --> Final output sent to browser
DEBUG - 2016-06-06 11:13:55 --> Total execution time: 0.3071
INFO - 2016-06-06 11:13:57 --> Config Class Initialized
INFO - 2016-06-06 11:13:57 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:13:57 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:13:57 --> Utf8 Class Initialized
INFO - 2016-06-06 11:13:57 --> URI Class Initialized
INFO - 2016-06-06 11:13:57 --> Router Class Initialized
INFO - 2016-06-06 11:13:57 --> Output Class Initialized
INFO - 2016-06-06 11:13:57 --> Security Class Initialized
DEBUG - 2016-06-06 11:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:13:57 --> Input Class Initialized
INFO - 2016-06-06 11:13:57 --> Language Class Initialized
INFO - 2016-06-06 11:13:57 --> Loader Class Initialized
INFO - 2016-06-06 11:13:57 --> Helper loaded: form_helper
INFO - 2016-06-06 11:13:57 --> Database Driver Class Initialized
INFO - 2016-06-06 11:13:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:13:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:13:57 --> Email Class Initialized
INFO - 2016-06-06 11:13:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:13:57 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:13:57 --> Helper loaded: language_helper
INFO - 2016-06-06 11:13:57 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:13:57 --> Model Class Initialized
INFO - 2016-06-06 11:13:57 --> Helper loaded: date_helper
INFO - 2016-06-06 11:13:57 --> Controller Class Initialized
INFO - 2016-06-06 11:13:57 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:13:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:13:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:13:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:13:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:13:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:13:57 --> Model Class Initialized
INFO - 2016-06-06 11:13:57 --> Form Validation Class Initialized
INFO - 2016-06-06 11:13:57 --> Final output sent to browser
DEBUG - 2016-06-06 11:13:57 --> Total execution time: 0.0927
INFO - 2016-06-06 11:19:11 --> Config Class Initialized
INFO - 2016-06-06 11:19:11 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:19:11 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:19:11 --> Utf8 Class Initialized
INFO - 2016-06-06 11:19:11 --> URI Class Initialized
INFO - 2016-06-06 11:19:11 --> Router Class Initialized
INFO - 2016-06-06 11:19:11 --> Output Class Initialized
INFO - 2016-06-06 11:19:11 --> Security Class Initialized
DEBUG - 2016-06-06 11:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:19:11 --> Input Class Initialized
INFO - 2016-06-06 11:19:11 --> Language Class Initialized
INFO - 2016-06-06 11:19:11 --> Loader Class Initialized
INFO - 2016-06-06 11:19:11 --> Helper loaded: form_helper
INFO - 2016-06-06 11:19:11 --> Database Driver Class Initialized
INFO - 2016-06-06 11:19:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:19:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:19:11 --> Email Class Initialized
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:19:11 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:19:11 --> Helper loaded: language_helper
INFO - 2016-06-06 11:19:11 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:19:11 --> Model Class Initialized
INFO - 2016-06-06 11:19:11 --> Helper loaded: date_helper
INFO - 2016-06-06 11:19:11 --> Controller Class Initialized
INFO - 2016-06-06 11:19:11 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:19:11 --> Model Class Initialized
INFO - 2016-06-06 11:19:11 --> Form Validation Class Initialized
INFO - 2016-06-06 11:19:11 --> Config Class Initialized
INFO - 2016-06-06 11:19:11 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:19:11 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:19:11 --> Utf8 Class Initialized
INFO - 2016-06-06 11:19:11 --> URI Class Initialized
INFO - 2016-06-06 11:19:11 --> Router Class Initialized
INFO - 2016-06-06 11:19:11 --> Output Class Initialized
INFO - 2016-06-06 11:19:11 --> Security Class Initialized
DEBUG - 2016-06-06 11:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:19:11 --> Input Class Initialized
INFO - 2016-06-06 11:19:11 --> Language Class Initialized
INFO - 2016-06-06 11:19:11 --> Loader Class Initialized
INFO - 2016-06-06 11:19:11 --> Helper loaded: form_helper
INFO - 2016-06-06 11:19:11 --> Database Driver Class Initialized
INFO - 2016-06-06 11:19:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:19:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:19:11 --> Email Class Initialized
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:19:11 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:19:11 --> Helper loaded: language_helper
INFO - 2016-06-06 11:19:11 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:19:11 --> Model Class Initialized
INFO - 2016-06-06 11:19:11 --> Helper loaded: date_helper
INFO - 2016-06-06 11:19:11 --> Controller Class Initialized
INFO - 2016-06-06 11:19:11 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:19:11 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:19:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:19:11 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:19:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:19:11 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:19:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:19:11 --> Final output sent to browser
DEBUG - 2016-06-06 11:19:11 --> Total execution time: 0.0436
INFO - 2016-06-06 11:33:24 --> Config Class Initialized
INFO - 2016-06-06 11:33:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:33:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:33:24 --> Utf8 Class Initialized
INFO - 2016-06-06 11:33:24 --> URI Class Initialized
INFO - 2016-06-06 11:33:24 --> Router Class Initialized
INFO - 2016-06-06 11:33:24 --> Output Class Initialized
INFO - 2016-06-06 11:33:24 --> Security Class Initialized
DEBUG - 2016-06-06 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:33:24 --> Input Class Initialized
INFO - 2016-06-06 11:33:24 --> Language Class Initialized
INFO - 2016-06-06 11:33:24 --> Loader Class Initialized
INFO - 2016-06-06 11:33:24 --> Helper loaded: form_helper
INFO - 2016-06-06 11:33:24 --> Database Driver Class Initialized
INFO - 2016-06-06 11:33:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:33:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:33:24 --> Email Class Initialized
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:33:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:33:24 --> Helper loaded: language_helper
INFO - 2016-06-06 11:33:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:33:24 --> Model Class Initialized
INFO - 2016-06-06 11:33:24 --> Helper loaded: date_helper
INFO - 2016-06-06 11:33:24 --> Controller Class Initialized
INFO - 2016-06-06 11:33:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:33:24 --> Model Class Initialized
INFO - 2016-06-06 11:33:24 --> Form Validation Class Initialized
INFO - 2016-06-06 11:33:24 --> Config Class Initialized
INFO - 2016-06-06 11:33:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:33:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:33:24 --> Utf8 Class Initialized
INFO - 2016-06-06 11:33:24 --> URI Class Initialized
INFO - 2016-06-06 11:33:24 --> Router Class Initialized
INFO - 2016-06-06 11:33:24 --> Output Class Initialized
INFO - 2016-06-06 11:33:24 --> Security Class Initialized
DEBUG - 2016-06-06 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:33:24 --> Input Class Initialized
INFO - 2016-06-06 11:33:24 --> Language Class Initialized
INFO - 2016-06-06 11:33:24 --> Loader Class Initialized
INFO - 2016-06-06 11:33:24 --> Helper loaded: form_helper
INFO - 2016-06-06 11:33:24 --> Database Driver Class Initialized
INFO - 2016-06-06 11:33:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:33:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:33:24 --> Email Class Initialized
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:33:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:33:24 --> Helper loaded: language_helper
INFO - 2016-06-06 11:33:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:33:24 --> Model Class Initialized
INFO - 2016-06-06 11:33:24 --> Helper loaded: date_helper
INFO - 2016-06-06 11:33:24 --> Controller Class Initialized
INFO - 2016-06-06 11:33:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:33:24 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:33:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:33:24 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:33:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:33:24 --> Final output sent to browser
DEBUG - 2016-06-06 11:33:24 --> Total execution time: 0.0131
INFO - 2016-06-06 11:36:07 --> Config Class Initialized
INFO - 2016-06-06 11:36:07 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:36:07 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:36:07 --> Utf8 Class Initialized
INFO - 2016-06-06 11:36:07 --> URI Class Initialized
INFO - 2016-06-06 11:36:07 --> Router Class Initialized
INFO - 2016-06-06 11:36:07 --> Output Class Initialized
INFO - 2016-06-06 11:36:07 --> Security Class Initialized
DEBUG - 2016-06-06 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:36:07 --> Input Class Initialized
INFO - 2016-06-06 11:36:07 --> Language Class Initialized
INFO - 2016-06-06 11:36:07 --> Loader Class Initialized
INFO - 2016-06-06 11:36:07 --> Helper loaded: form_helper
INFO - 2016-06-06 11:36:07 --> Database Driver Class Initialized
INFO - 2016-06-06 11:36:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:36:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:36:07 --> Email Class Initialized
INFO - 2016-06-06 11:36:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:36:07 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:36:07 --> Helper loaded: language_helper
INFO - 2016-06-06 11:36:07 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:36:07 --> Model Class Initialized
INFO - 2016-06-06 11:36:07 --> Helper loaded: date_helper
INFO - 2016-06-06 11:36:07 --> Controller Class Initialized
INFO - 2016-06-06 11:36:07 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:36:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:36:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:36:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:36:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:36:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:36:07 --> Model Class Initialized
INFO - 2016-06-06 11:36:07 --> Form Validation Class Initialized
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 11:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 11:36:07 --> Final output sent to browser
DEBUG - 2016-06-06 11:36:07 --> Total execution time: 0.0760
INFO - 2016-06-06 11:36:09 --> Config Class Initialized
INFO - 2016-06-06 11:36:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:36:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:36:09 --> Utf8 Class Initialized
INFO - 2016-06-06 11:36:09 --> URI Class Initialized
INFO - 2016-06-06 11:36:09 --> Router Class Initialized
INFO - 2016-06-06 11:36:09 --> Output Class Initialized
INFO - 2016-06-06 11:36:09 --> Security Class Initialized
DEBUG - 2016-06-06 11:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:36:09 --> Input Class Initialized
INFO - 2016-06-06 11:36:09 --> Language Class Initialized
INFO - 2016-06-06 11:36:09 --> Loader Class Initialized
INFO - 2016-06-06 11:36:09 --> Helper loaded: form_helper
INFO - 2016-06-06 11:36:09 --> Database Driver Class Initialized
INFO - 2016-06-06 11:36:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:36:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:36:09 --> Email Class Initialized
INFO - 2016-06-06 11:36:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:36:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:36:09 --> Helper loaded: language_helper
INFO - 2016-06-06 11:36:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:36:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:36:09 --> Model Class Initialized
INFO - 2016-06-06 11:36:09 --> Helper loaded: date_helper
INFO - 2016-06-06 11:36:09 --> Controller Class Initialized
INFO - 2016-06-06 11:36:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:36:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:36:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:36:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:36:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:36:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:36:09 --> Model Class Initialized
INFO - 2016-06-06 11:36:09 --> Form Validation Class Initialized
INFO - 2016-06-06 11:36:09 --> Final output sent to browser
DEBUG - 2016-06-06 11:36:09 --> Total execution time: 0.0297
INFO - 2016-06-06 11:37:16 --> Config Class Initialized
INFO - 2016-06-06 11:37:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:37:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:37:16 --> Utf8 Class Initialized
INFO - 2016-06-06 11:37:16 --> URI Class Initialized
INFO - 2016-06-06 11:37:16 --> Router Class Initialized
INFO - 2016-06-06 11:37:16 --> Output Class Initialized
INFO - 2016-06-06 11:37:16 --> Security Class Initialized
DEBUG - 2016-06-06 11:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:37:16 --> Input Class Initialized
INFO - 2016-06-06 11:37:16 --> Language Class Initialized
INFO - 2016-06-06 11:37:16 --> Loader Class Initialized
INFO - 2016-06-06 11:37:16 --> Helper loaded: form_helper
INFO - 2016-06-06 11:37:16 --> Database Driver Class Initialized
INFO - 2016-06-06 11:37:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:37:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:37:16 --> Email Class Initialized
INFO - 2016-06-06 11:37:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:37:16 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:37:16 --> Helper loaded: language_helper
INFO - 2016-06-06 11:37:16 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:37:16 --> Model Class Initialized
INFO - 2016-06-06 11:37:16 --> Helper loaded: date_helper
INFO - 2016-06-06 11:37:16 --> Controller Class Initialized
INFO - 2016-06-06 11:37:16 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:37:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:37:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:37:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:37:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:37:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:37:16 --> Model Class Initialized
INFO - 2016-06-06 11:37:16 --> Form Validation Class Initialized
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 11:37:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 11:37:16 --> Final output sent to browser
DEBUG - 2016-06-06 11:37:16 --> Total execution time: 0.0631
INFO - 2016-06-06 11:37:18 --> Config Class Initialized
INFO - 2016-06-06 11:37:18 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:37:18 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:37:18 --> Utf8 Class Initialized
INFO - 2016-06-06 11:37:18 --> URI Class Initialized
INFO - 2016-06-06 11:37:18 --> Router Class Initialized
INFO - 2016-06-06 11:37:18 --> Output Class Initialized
INFO - 2016-06-06 11:37:18 --> Security Class Initialized
DEBUG - 2016-06-06 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:37:18 --> Input Class Initialized
INFO - 2016-06-06 11:37:18 --> Language Class Initialized
INFO - 2016-06-06 11:37:18 --> Loader Class Initialized
INFO - 2016-06-06 11:37:18 --> Helper loaded: form_helper
INFO - 2016-06-06 11:37:18 --> Database Driver Class Initialized
INFO - 2016-06-06 11:37:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:37:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:37:18 --> Email Class Initialized
INFO - 2016-06-06 11:37:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:37:18 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:37:18 --> Helper loaded: language_helper
INFO - 2016-06-06 11:37:18 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:37:18 --> Model Class Initialized
INFO - 2016-06-06 11:37:18 --> Helper loaded: date_helper
INFO - 2016-06-06 11:37:18 --> Controller Class Initialized
INFO - 2016-06-06 11:37:18 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:37:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:37:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:37:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:37:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:37:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:37:18 --> Model Class Initialized
INFO - 2016-06-06 11:37:18 --> Form Validation Class Initialized
INFO - 2016-06-06 11:37:18 --> Final output sent to browser
DEBUG - 2016-06-06 11:37:18 --> Total execution time: 0.0301
INFO - 2016-06-06 11:40:57 --> Config Class Initialized
INFO - 2016-06-06 11:40:57 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:40:57 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:40:57 --> Utf8 Class Initialized
INFO - 2016-06-06 11:40:57 --> URI Class Initialized
INFO - 2016-06-06 11:40:57 --> Router Class Initialized
INFO - 2016-06-06 11:40:57 --> Output Class Initialized
INFO - 2016-06-06 11:40:57 --> Security Class Initialized
DEBUG - 2016-06-06 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:40:57 --> Input Class Initialized
INFO - 2016-06-06 11:40:57 --> Language Class Initialized
INFO - 2016-06-06 11:40:57 --> Loader Class Initialized
INFO - 2016-06-06 11:40:57 --> Helper loaded: form_helper
INFO - 2016-06-06 11:40:57 --> Database Driver Class Initialized
INFO - 2016-06-06 11:40:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:40:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:40:57 --> Email Class Initialized
INFO - 2016-06-06 11:40:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:40:57 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:40:57 --> Helper loaded: language_helper
INFO - 2016-06-06 11:40:57 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:40:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:40:57 --> Model Class Initialized
INFO - 2016-06-06 11:40:57 --> Helper loaded: date_helper
INFO - 2016-06-06 11:40:57 --> Controller Class Initialized
INFO - 2016-06-06 11:40:57 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:40:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:40:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:40:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:40:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:40:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:40:57 --> Model Class Initialized
INFO - 2016-06-06 11:40:57 --> Form Validation Class Initialized
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 11:40:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 11:40:57 --> Final output sent to browser
DEBUG - 2016-06-06 11:40:57 --> Total execution time: 0.1226
INFO - 2016-06-06 11:41:01 --> Config Class Initialized
INFO - 2016-06-06 11:41:01 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:41:01 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:41:01 --> Utf8 Class Initialized
INFO - 2016-06-06 11:41:01 --> URI Class Initialized
INFO - 2016-06-06 11:41:01 --> Router Class Initialized
INFO - 2016-06-06 11:41:01 --> Output Class Initialized
INFO - 2016-06-06 11:41:01 --> Security Class Initialized
DEBUG - 2016-06-06 11:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:41:01 --> Input Class Initialized
INFO - 2016-06-06 11:41:01 --> Language Class Initialized
INFO - 2016-06-06 11:41:01 --> Loader Class Initialized
INFO - 2016-06-06 11:41:01 --> Helper loaded: form_helper
INFO - 2016-06-06 11:41:01 --> Database Driver Class Initialized
INFO - 2016-06-06 11:41:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:41:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:41:01 --> Email Class Initialized
INFO - 2016-06-06 11:41:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:41:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:41:01 --> Helper loaded: language_helper
INFO - 2016-06-06 11:41:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:41:01 --> Model Class Initialized
INFO - 2016-06-06 11:41:01 --> Helper loaded: date_helper
INFO - 2016-06-06 11:41:01 --> Controller Class Initialized
INFO - 2016-06-06 11:41:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:41:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:41:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:41:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:41:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:41:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:41:01 --> Model Class Initialized
INFO - 2016-06-06 11:41:01 --> Form Validation Class Initialized
INFO - 2016-06-06 11:41:01 --> Final output sent to browser
DEBUG - 2016-06-06 11:41:01 --> Total execution time: 0.0157
INFO - 2016-06-06 11:41:29 --> Config Class Initialized
INFO - 2016-06-06 11:41:29 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:41:29 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:41:29 --> Utf8 Class Initialized
INFO - 2016-06-06 11:41:29 --> URI Class Initialized
INFO - 2016-06-06 11:41:29 --> Router Class Initialized
INFO - 2016-06-06 11:41:29 --> Output Class Initialized
INFO - 2016-06-06 11:41:29 --> Security Class Initialized
DEBUG - 2016-06-06 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:41:29 --> Input Class Initialized
INFO - 2016-06-06 11:41:29 --> Language Class Initialized
INFO - 2016-06-06 11:41:29 --> Loader Class Initialized
INFO - 2016-06-06 11:41:29 --> Helper loaded: form_helper
INFO - 2016-06-06 11:41:29 --> Database Driver Class Initialized
INFO - 2016-06-06 11:41:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:41:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:41:29 --> Email Class Initialized
INFO - 2016-06-06 11:41:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:41:29 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:41:29 --> Helper loaded: language_helper
INFO - 2016-06-06 11:41:29 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:41:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:41:29 --> Model Class Initialized
INFO - 2016-06-06 11:41:29 --> Helper loaded: date_helper
INFO - 2016-06-06 11:41:29 --> Controller Class Initialized
INFO - 2016-06-06 11:41:29 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:41:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:41:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:41:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:41:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:41:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:41:29 --> Model Class Initialized
INFO - 2016-06-06 11:41:29 --> Form Validation Class Initialized
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 11:41:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 11:41:29 --> Final output sent to browser
DEBUG - 2016-06-06 11:41:29 --> Total execution time: 0.0497
INFO - 2016-06-06 11:41:32 --> Config Class Initialized
INFO - 2016-06-06 11:41:32 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:41:32 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:41:32 --> Utf8 Class Initialized
INFO - 2016-06-06 11:41:32 --> URI Class Initialized
INFO - 2016-06-06 11:41:32 --> Router Class Initialized
INFO - 2016-06-06 11:41:32 --> Output Class Initialized
INFO - 2016-06-06 11:41:32 --> Security Class Initialized
DEBUG - 2016-06-06 11:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:41:32 --> Input Class Initialized
INFO - 2016-06-06 11:41:32 --> Language Class Initialized
INFO - 2016-06-06 11:41:32 --> Loader Class Initialized
INFO - 2016-06-06 11:41:32 --> Helper loaded: form_helper
INFO - 2016-06-06 11:41:32 --> Database Driver Class Initialized
INFO - 2016-06-06 11:41:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:41:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:41:32 --> Email Class Initialized
INFO - 2016-06-06 11:41:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:41:32 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:41:32 --> Helper loaded: language_helper
INFO - 2016-06-06 11:41:32 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:41:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:41:32 --> Model Class Initialized
INFO - 2016-06-06 11:41:32 --> Helper loaded: date_helper
INFO - 2016-06-06 11:41:32 --> Controller Class Initialized
INFO - 2016-06-06 11:41:32 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:41:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:41:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:41:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:41:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:41:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:41:32 --> Model Class Initialized
INFO - 2016-06-06 11:41:32 --> Form Validation Class Initialized
INFO - 2016-06-06 11:41:32 --> Final output sent to browser
DEBUG - 2016-06-06 11:41:32 --> Total execution time: 0.1271
INFO - 2016-06-06 11:43:16 --> Config Class Initialized
INFO - 2016-06-06 11:43:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:43:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:43:16 --> Utf8 Class Initialized
INFO - 2016-06-06 11:43:16 --> URI Class Initialized
INFO - 2016-06-06 11:43:16 --> Router Class Initialized
INFO - 2016-06-06 11:43:16 --> Output Class Initialized
INFO - 2016-06-06 11:43:16 --> Security Class Initialized
DEBUG - 2016-06-06 11:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:43:16 --> Input Class Initialized
INFO - 2016-06-06 11:43:16 --> Language Class Initialized
INFO - 2016-06-06 11:43:16 --> Loader Class Initialized
INFO - 2016-06-06 11:43:16 --> Helper loaded: form_helper
INFO - 2016-06-06 11:43:16 --> Database Driver Class Initialized
INFO - 2016-06-06 11:43:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:43:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:43:16 --> Email Class Initialized
INFO - 2016-06-06 11:43:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:43:16 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:43:16 --> Helper loaded: language_helper
INFO - 2016-06-06 11:43:16 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:43:16 --> Model Class Initialized
INFO - 2016-06-06 11:43:16 --> Helper loaded: date_helper
INFO - 2016-06-06 11:43:16 --> Controller Class Initialized
INFO - 2016-06-06 11:43:16 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:43:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:43:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:43:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:43:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:43:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:43:16 --> Model Class Initialized
INFO - 2016-06-06 11:43:16 --> Form Validation Class Initialized
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 11:43:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 11:43:16 --> Final output sent to browser
DEBUG - 2016-06-06 11:43:16 --> Total execution time: 0.0788
INFO - 2016-06-06 11:43:20 --> Config Class Initialized
INFO - 2016-06-06 11:43:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:43:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:43:20 --> Utf8 Class Initialized
INFO - 2016-06-06 11:43:20 --> URI Class Initialized
INFO - 2016-06-06 11:43:20 --> Router Class Initialized
INFO - 2016-06-06 11:43:20 --> Output Class Initialized
INFO - 2016-06-06 11:43:20 --> Security Class Initialized
DEBUG - 2016-06-06 11:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:43:20 --> Input Class Initialized
INFO - 2016-06-06 11:43:20 --> Language Class Initialized
INFO - 2016-06-06 11:43:20 --> Loader Class Initialized
INFO - 2016-06-06 11:43:20 --> Helper loaded: form_helper
INFO - 2016-06-06 11:43:20 --> Database Driver Class Initialized
INFO - 2016-06-06 11:43:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:43:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:43:20 --> Email Class Initialized
INFO - 2016-06-06 11:43:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:43:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:43:20 --> Helper loaded: language_helper
INFO - 2016-06-06 11:43:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:43:20 --> Model Class Initialized
INFO - 2016-06-06 11:43:20 --> Helper loaded: date_helper
INFO - 2016-06-06 11:43:20 --> Controller Class Initialized
INFO - 2016-06-06 11:43:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:43:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:43:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:43:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:43:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:43:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:43:20 --> Model Class Initialized
INFO - 2016-06-06 11:43:20 --> Form Validation Class Initialized
INFO - 2016-06-06 11:43:20 --> Final output sent to browser
DEBUG - 2016-06-06 11:43:20 --> Total execution time: 0.0744
INFO - 2016-06-06 11:46:22 --> Config Class Initialized
INFO - 2016-06-06 11:46:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:46:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:46:22 --> Utf8 Class Initialized
INFO - 2016-06-06 11:46:22 --> URI Class Initialized
INFO - 2016-06-06 11:46:22 --> Router Class Initialized
INFO - 2016-06-06 11:46:22 --> Output Class Initialized
INFO - 2016-06-06 11:46:22 --> Security Class Initialized
DEBUG - 2016-06-06 11:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:46:22 --> Input Class Initialized
INFO - 2016-06-06 11:46:22 --> Language Class Initialized
INFO - 2016-06-06 11:46:22 --> Loader Class Initialized
INFO - 2016-06-06 11:46:22 --> Helper loaded: form_helper
INFO - 2016-06-06 11:46:22 --> Database Driver Class Initialized
INFO - 2016-06-06 11:46:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:46:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:46:22 --> Email Class Initialized
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:46:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:46:22 --> Helper loaded: language_helper
INFO - 2016-06-06 11:46:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:46:22 --> Model Class Initialized
INFO - 2016-06-06 11:46:22 --> Helper loaded: date_helper
INFO - 2016-06-06 11:46:22 --> Controller Class Initialized
INFO - 2016-06-06 11:46:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:46:22 --> Model Class Initialized
INFO - 2016-06-06 11:46:22 --> Form Validation Class Initialized
INFO - 2016-06-06 11:46:22 --> Config Class Initialized
INFO - 2016-06-06 11:46:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:46:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:46:22 --> Utf8 Class Initialized
INFO - 2016-06-06 11:46:22 --> URI Class Initialized
INFO - 2016-06-06 11:46:22 --> Router Class Initialized
INFO - 2016-06-06 11:46:22 --> Output Class Initialized
INFO - 2016-06-06 11:46:22 --> Security Class Initialized
DEBUG - 2016-06-06 11:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:46:22 --> Input Class Initialized
INFO - 2016-06-06 11:46:22 --> Language Class Initialized
INFO - 2016-06-06 11:46:22 --> Loader Class Initialized
INFO - 2016-06-06 11:46:22 --> Helper loaded: form_helper
INFO - 2016-06-06 11:46:22 --> Database Driver Class Initialized
INFO - 2016-06-06 11:46:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:46:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:46:22 --> Email Class Initialized
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:46:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:46:22 --> Helper loaded: language_helper
INFO - 2016-06-06 11:46:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:46:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:46:22 --> Model Class Initialized
INFO - 2016-06-06 11:46:22 --> Helper loaded: date_helper
INFO - 2016-06-06 11:46:22 --> Controller Class Initialized
INFO - 2016-06-06 11:46:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:46:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:46:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:46:22 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:46:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:46:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:46:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:46:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:46:22 --> Final output sent to browser
DEBUG - 2016-06-06 11:46:22 --> Total execution time: 0.0427
INFO - 2016-06-06 11:58:52 --> Config Class Initialized
INFO - 2016-06-06 11:58:52 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:58:52 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:58:52 --> Utf8 Class Initialized
INFO - 2016-06-06 11:58:52 --> URI Class Initialized
INFO - 2016-06-06 11:58:52 --> Router Class Initialized
INFO - 2016-06-06 11:58:52 --> Output Class Initialized
INFO - 2016-06-06 11:58:52 --> Security Class Initialized
DEBUG - 2016-06-06 11:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:58:52 --> Input Class Initialized
INFO - 2016-06-06 11:58:52 --> Language Class Initialized
INFO - 2016-06-06 11:58:52 --> Loader Class Initialized
INFO - 2016-06-06 11:58:52 --> Helper loaded: form_helper
INFO - 2016-06-06 11:58:52 --> Database Driver Class Initialized
INFO - 2016-06-06 11:58:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:58:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:58:52 --> Email Class Initialized
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:58:52 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:58:52 --> Helper loaded: language_helper
INFO - 2016-06-06 11:58:52 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:58:52 --> Model Class Initialized
INFO - 2016-06-06 11:58:52 --> Helper loaded: date_helper
INFO - 2016-06-06 11:58:52 --> Controller Class Initialized
INFO - 2016-06-06 11:58:52 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 11:58:52 --> Model Class Initialized
INFO - 2016-06-06 11:58:52 --> Form Validation Class Initialized
INFO - 2016-06-06 11:58:52 --> Config Class Initialized
INFO - 2016-06-06 11:58:52 --> Hooks Class Initialized
DEBUG - 2016-06-06 11:58:52 --> UTF-8 Support Enabled
INFO - 2016-06-06 11:58:52 --> Utf8 Class Initialized
INFO - 2016-06-06 11:58:52 --> URI Class Initialized
INFO - 2016-06-06 11:58:52 --> Router Class Initialized
INFO - 2016-06-06 11:58:52 --> Output Class Initialized
INFO - 2016-06-06 11:58:52 --> Security Class Initialized
DEBUG - 2016-06-06 11:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 11:58:52 --> Input Class Initialized
INFO - 2016-06-06 11:58:52 --> Language Class Initialized
INFO - 2016-06-06 11:58:52 --> Loader Class Initialized
INFO - 2016-06-06 11:58:52 --> Helper loaded: form_helper
INFO - 2016-06-06 11:58:52 --> Database Driver Class Initialized
INFO - 2016-06-06 11:58:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 11:58:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 11:58:52 --> Email Class Initialized
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 11:58:52 --> Helper loaded: cookie_helper
INFO - 2016-06-06 11:58:52 --> Helper loaded: language_helper
INFO - 2016-06-06 11:58:52 --> Helper loaded: url_helper
DEBUG - 2016-06-06 11:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:58:52 --> Model Class Initialized
INFO - 2016-06-06 11:58:52 --> Helper loaded: date_helper
INFO - 2016-06-06 11:58:52 --> Controller Class Initialized
INFO - 2016-06-06 11:58:52 --> Helper loaded: languages_helper
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 11:58:52 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 11:58:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:58:52 --> Form Validation Class Initialized
DEBUG - 2016-06-06 11:58:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 11:58:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 11:58:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 11:58:52 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 11:58:52 --> Final output sent to browser
DEBUG - 2016-06-06 11:58:52 --> Total execution time: 0.0151
INFO - 2016-06-06 12:01:09 --> Config Class Initialized
INFO - 2016-06-06 12:01:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:01:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:01:09 --> Utf8 Class Initialized
INFO - 2016-06-06 12:01:09 --> URI Class Initialized
INFO - 2016-06-06 12:01:09 --> Router Class Initialized
INFO - 2016-06-06 12:01:09 --> Output Class Initialized
INFO - 2016-06-06 12:01:09 --> Security Class Initialized
DEBUG - 2016-06-06 12:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:01:09 --> Input Class Initialized
INFO - 2016-06-06 12:01:09 --> Language Class Initialized
INFO - 2016-06-06 12:01:09 --> Loader Class Initialized
INFO - 2016-06-06 12:01:09 --> Helper loaded: form_helper
INFO - 2016-06-06 12:01:09 --> Database Driver Class Initialized
INFO - 2016-06-06 12:01:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:01:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:01:09 --> Email Class Initialized
INFO - 2016-06-06 12:01:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:01:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:01:09 --> Helper loaded: language_helper
INFO - 2016-06-06 12:01:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:01:09 --> Model Class Initialized
INFO - 2016-06-06 12:01:09 --> Helper loaded: date_helper
INFO - 2016-06-06 12:01:09 --> Controller Class Initialized
INFO - 2016-06-06 12:01:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:01:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:01:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:01:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:01:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:01:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:01:09 --> Model Class Initialized
INFO - 2016-06-06 12:01:09 --> Form Validation Class Initialized
INFO - 2016-06-06 12:01:11 --> Config Class Initialized
INFO - 2016-06-06 12:01:11 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:01:11 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:01:11 --> Utf8 Class Initialized
INFO - 2016-06-06 12:01:11 --> URI Class Initialized
INFO - 2016-06-06 12:01:11 --> Router Class Initialized
INFO - 2016-06-06 12:01:11 --> Output Class Initialized
INFO - 2016-06-06 12:01:11 --> Security Class Initialized
DEBUG - 2016-06-06 12:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:01:11 --> Input Class Initialized
INFO - 2016-06-06 12:01:11 --> Language Class Initialized
INFO - 2016-06-06 12:01:11 --> Loader Class Initialized
INFO - 2016-06-06 12:01:11 --> Helper loaded: form_helper
INFO - 2016-06-06 12:01:11 --> Database Driver Class Initialized
INFO - 2016-06-06 12:01:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:01:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:01:11 --> Email Class Initialized
INFO - 2016-06-06 12:01:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:01:11 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:01:11 --> Helper loaded: language_helper
INFO - 2016-06-06 12:01:11 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:01:11 --> Model Class Initialized
INFO - 2016-06-06 12:01:11 --> Helper loaded: date_helper
INFO - 2016-06-06 12:01:11 --> Controller Class Initialized
INFO - 2016-06-06 12:01:11 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:01:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:01:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:01:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:01:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:01:11 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 12:01:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:01:11 --> Form Validation Class Initialized
DEBUG - 2016-06-06 12:01:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 12:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 12:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 12:01:11 --> Final output sent to browser
DEBUG - 2016-06-06 12:01:11 --> Total execution time: 0.0357
INFO - 2016-06-06 12:19:52 --> Config Class Initialized
INFO - 2016-06-06 12:19:52 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:19:52 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:19:52 --> Utf8 Class Initialized
INFO - 2016-06-06 12:19:52 --> URI Class Initialized
INFO - 2016-06-06 12:19:52 --> Router Class Initialized
INFO - 2016-06-06 12:19:52 --> Output Class Initialized
INFO - 2016-06-06 12:19:52 --> Security Class Initialized
DEBUG - 2016-06-06 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:19:52 --> Input Class Initialized
INFO - 2016-06-06 12:19:52 --> Language Class Initialized
INFO - 2016-06-06 12:19:52 --> Loader Class Initialized
INFO - 2016-06-06 12:19:52 --> Helper loaded: form_helper
INFO - 2016-06-06 12:19:52 --> Database Driver Class Initialized
INFO - 2016-06-06 12:19:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:19:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:19:52 --> Email Class Initialized
INFO - 2016-06-06 12:19:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:19:52 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:19:52 --> Helper loaded: language_helper
INFO - 2016-06-06 12:19:52 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:19:52 --> Model Class Initialized
INFO - 2016-06-06 12:19:52 --> Helper loaded: date_helper
INFO - 2016-06-06 12:19:52 --> Controller Class Initialized
INFO - 2016-06-06 12:19:52 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:19:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:19:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:19:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:19:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:19:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:19:52 --> Model Class Initialized
INFO - 2016-06-06 12:19:52 --> Form Validation Class Initialized
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-06 12:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:19:52 --> Final output sent to browser
DEBUG - 2016-06-06 12:19:52 --> Total execution time: 0.0733
INFO - 2016-06-06 12:20:00 --> Config Class Initialized
INFO - 2016-06-06 12:20:00 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:20:00 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:20:00 --> Utf8 Class Initialized
INFO - 2016-06-06 12:20:00 --> URI Class Initialized
INFO - 2016-06-06 12:20:00 --> Router Class Initialized
INFO - 2016-06-06 12:20:00 --> Output Class Initialized
INFO - 2016-06-06 12:20:00 --> Security Class Initialized
DEBUG - 2016-06-06 12:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:20:01 --> Input Class Initialized
INFO - 2016-06-06 12:20:01 --> Language Class Initialized
INFO - 2016-06-06 12:20:01 --> Loader Class Initialized
INFO - 2016-06-06 12:20:01 --> Helper loaded: form_helper
INFO - 2016-06-06 12:20:01 --> Database Driver Class Initialized
INFO - 2016-06-06 12:20:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:20:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:20:01 --> Email Class Initialized
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:20:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:20:01 --> Helper loaded: language_helper
INFO - 2016-06-06 12:20:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:20:01 --> Model Class Initialized
INFO - 2016-06-06 12:20:01 --> Helper loaded: date_helper
INFO - 2016-06-06 12:20:01 --> Controller Class Initialized
INFO - 2016-06-06 12:20:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 12:20:01 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:20:01 --> Form Validation Class Initialized
INFO - 2016-06-06 12:20:01 --> Config Class Initialized
INFO - 2016-06-06 12:20:01 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:20:01 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:20:01 --> Utf8 Class Initialized
INFO - 2016-06-06 12:20:01 --> URI Class Initialized
INFO - 2016-06-06 12:20:01 --> Router Class Initialized
INFO - 2016-06-06 12:20:01 --> Output Class Initialized
INFO - 2016-06-06 12:20:01 --> Security Class Initialized
DEBUG - 2016-06-06 12:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:20:01 --> Input Class Initialized
INFO - 2016-06-06 12:20:01 --> Language Class Initialized
INFO - 2016-06-06 12:20:01 --> Loader Class Initialized
INFO - 2016-06-06 12:20:01 --> Helper loaded: form_helper
INFO - 2016-06-06 12:20:01 --> Database Driver Class Initialized
INFO - 2016-06-06 12:20:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:20:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:20:01 --> Email Class Initialized
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:20:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:20:01 --> Helper loaded: language_helper
INFO - 2016-06-06 12:20:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:20:01 --> Model Class Initialized
INFO - 2016-06-06 12:20:01 --> Helper loaded: date_helper
INFO - 2016-06-06 12:20:01 --> Controller Class Initialized
INFO - 2016-06-06 12:20:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:20:01 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 12:20:01 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:20:01 --> Form Validation Class Initialized
DEBUG - 2016-06-06 12:20:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:20:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 12:20:01 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 12:20:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 12:20:01 --> Final output sent to browser
DEBUG - 2016-06-06 12:20:01 --> Total execution time: 0.0339
INFO - 2016-06-06 12:21:23 --> Config Class Initialized
INFO - 2016-06-06 12:21:23 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:21:23 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:21:23 --> Utf8 Class Initialized
INFO - 2016-06-06 12:21:23 --> URI Class Initialized
INFO - 2016-06-06 12:21:23 --> Router Class Initialized
INFO - 2016-06-06 12:21:23 --> Output Class Initialized
INFO - 2016-06-06 12:21:23 --> Security Class Initialized
DEBUG - 2016-06-06 12:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:21:23 --> Input Class Initialized
INFO - 2016-06-06 12:21:23 --> Language Class Initialized
INFO - 2016-06-06 12:21:23 --> Loader Class Initialized
INFO - 2016-06-06 12:21:23 --> Helper loaded: form_helper
INFO - 2016-06-06 12:21:23 --> Database Driver Class Initialized
INFO - 2016-06-06 12:21:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:21:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:21:23 --> Email Class Initialized
INFO - 2016-06-06 12:21:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:21:23 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:21:23 --> Helper loaded: language_helper
INFO - 2016-06-06 12:21:23 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:21:23 --> Model Class Initialized
INFO - 2016-06-06 12:21:23 --> Helper loaded: date_helper
INFO - 2016-06-06 12:21:23 --> Controller Class Initialized
INFO - 2016-06-06 12:21:23 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:21:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:21:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:21:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:21:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:21:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 12:21:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:21:23 --> Form Validation Class Initialized
DEBUG - 2016-06-06 12:21:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:21:24 --> Config Class Initialized
INFO - 2016-06-06 12:21:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:21:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:21:24 --> Utf8 Class Initialized
INFO - 2016-06-06 12:21:24 --> URI Class Initialized
DEBUG - 2016-06-06 12:21:24 --> No URI present. Default controller set.
INFO - 2016-06-06 12:21:24 --> Router Class Initialized
INFO - 2016-06-06 12:21:24 --> Output Class Initialized
INFO - 2016-06-06 12:21:24 --> Security Class Initialized
DEBUG - 2016-06-06 12:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:21:24 --> Input Class Initialized
INFO - 2016-06-06 12:21:24 --> Language Class Initialized
INFO - 2016-06-06 12:21:24 --> Loader Class Initialized
INFO - 2016-06-06 12:21:24 --> Helper loaded: form_helper
INFO - 2016-06-06 12:21:24 --> Database Driver Class Initialized
INFO - 2016-06-06 12:21:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:21:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:21:24 --> Email Class Initialized
INFO - 2016-06-06 12:21:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:21:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:21:24 --> Helper loaded: language_helper
INFO - 2016-06-06 12:21:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:21:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:21:24 --> Model Class Initialized
INFO - 2016-06-06 12:21:24 --> Helper loaded: date_helper
INFO - 2016-06-06 12:21:24 --> Controller Class Initialized
INFO - 2016-06-06 12:21:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:21:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:21:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:21:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:21:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:21:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:21:25 --> Config Class Initialized
INFO - 2016-06-06 12:21:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:21:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:21:25 --> Utf8 Class Initialized
INFO - 2016-06-06 12:21:25 --> URI Class Initialized
INFO - 2016-06-06 12:21:25 --> Router Class Initialized
INFO - 2016-06-06 12:21:25 --> Output Class Initialized
INFO - 2016-06-06 12:21:25 --> Security Class Initialized
DEBUG - 2016-06-06 12:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:21:25 --> Input Class Initialized
INFO - 2016-06-06 12:21:25 --> Language Class Initialized
INFO - 2016-06-06 12:21:25 --> Loader Class Initialized
INFO - 2016-06-06 12:21:25 --> Helper loaded: form_helper
INFO - 2016-06-06 12:21:25 --> Database Driver Class Initialized
INFO - 2016-06-06 12:21:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:21:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:21:25 --> Email Class Initialized
INFO - 2016-06-06 12:21:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:21:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:21:25 --> Helper loaded: language_helper
INFO - 2016-06-06 12:21:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:21:25 --> Model Class Initialized
INFO - 2016-06-06 12:21:25 --> Helper loaded: date_helper
INFO - 2016-06-06 12:21:25 --> Controller Class Initialized
INFO - 2016-06-06 12:21:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:21:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:21:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:21:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:21:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:21:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:21:25 --> Model Class Initialized
INFO - 2016-06-06 12:21:25 --> Form Validation Class Initialized
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-06 12:21:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:21:25 --> Final output sent to browser
DEBUG - 2016-06-06 12:21:25 --> Total execution time: 0.1108
INFO - 2016-06-06 12:21:46 --> Config Class Initialized
INFO - 2016-06-06 12:21:46 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:21:46 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:21:46 --> Utf8 Class Initialized
INFO - 2016-06-06 12:21:46 --> URI Class Initialized
INFO - 2016-06-06 12:21:46 --> Router Class Initialized
INFO - 2016-06-06 12:21:46 --> Output Class Initialized
INFO - 2016-06-06 12:21:46 --> Security Class Initialized
DEBUG - 2016-06-06 12:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:21:46 --> Input Class Initialized
INFO - 2016-06-06 12:21:46 --> Language Class Initialized
INFO - 2016-06-06 12:21:46 --> Loader Class Initialized
INFO - 2016-06-06 12:21:46 --> Helper loaded: form_helper
INFO - 2016-06-06 12:21:46 --> Database Driver Class Initialized
INFO - 2016-06-06 12:21:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:21:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:21:46 --> Email Class Initialized
INFO - 2016-06-06 12:21:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:21:46 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:21:46 --> Helper loaded: language_helper
INFO - 2016-06-06 12:21:46 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:21:46 --> Model Class Initialized
INFO - 2016-06-06 12:21:46 --> Helper loaded: date_helper
INFO - 2016-06-06 12:21:46 --> Controller Class Initialized
INFO - 2016-06-06 12:21:46 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:21:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:21:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:21:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:21:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:21:46 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 12:21:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:21:46 --> Form Validation Class Initialized
INFO - 2016-06-06 12:21:46 --> Helper loaded: string_helper
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-06-06 12:21:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:21:46 --> Final output sent to browser
DEBUG - 2016-06-06 12:21:46 --> Total execution time: 0.0767
INFO - 2016-06-06 12:22:58 --> Config Class Initialized
INFO - 2016-06-06 12:22:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:22:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:22:58 --> Utf8 Class Initialized
INFO - 2016-06-06 12:22:58 --> URI Class Initialized
INFO - 2016-06-06 12:22:58 --> Router Class Initialized
INFO - 2016-06-06 12:22:58 --> Output Class Initialized
INFO - 2016-06-06 12:22:58 --> Security Class Initialized
DEBUG - 2016-06-06 12:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:22:58 --> Input Class Initialized
INFO - 2016-06-06 12:22:58 --> Language Class Initialized
INFO - 2016-06-06 12:22:58 --> Loader Class Initialized
INFO - 2016-06-06 12:22:58 --> Helper loaded: form_helper
INFO - 2016-06-06 12:22:58 --> Database Driver Class Initialized
INFO - 2016-06-06 12:22:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:22:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:22:58 --> Email Class Initialized
INFO - 2016-06-06 12:22:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:22:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:22:58 --> Helper loaded: language_helper
INFO - 2016-06-06 12:22:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:22:58 --> Model Class Initialized
INFO - 2016-06-06 12:22:58 --> Helper loaded: date_helper
INFO - 2016-06-06 12:22:58 --> Controller Class Initialized
INFO - 2016-06-06 12:22:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:22:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:22:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:22:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:22:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:22:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:22:58 --> Model Class Initialized
INFO - 2016-06-06 12:22:58 --> Form Validation Class Initialized
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-06 12:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:22:58 --> Final output sent to browser
DEBUG - 2016-06-06 12:22:58 --> Total execution time: 0.1186
INFO - 2016-06-06 12:23:22 --> Config Class Initialized
INFO - 2016-06-06 12:23:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:23:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:23:22 --> Utf8 Class Initialized
INFO - 2016-06-06 12:23:22 --> URI Class Initialized
DEBUG - 2016-06-06 12:23:22 --> No URI present. Default controller set.
INFO - 2016-06-06 12:23:22 --> Router Class Initialized
INFO - 2016-06-06 12:23:22 --> Output Class Initialized
INFO - 2016-06-06 12:23:22 --> Security Class Initialized
DEBUG - 2016-06-06 12:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:23:22 --> Input Class Initialized
INFO - 2016-06-06 12:23:22 --> Language Class Initialized
INFO - 2016-06-06 12:23:22 --> Loader Class Initialized
INFO - 2016-06-06 12:23:22 --> Helper loaded: form_helper
INFO - 2016-06-06 12:23:22 --> Database Driver Class Initialized
INFO - 2016-06-06 12:23:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:23:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:23:22 --> Email Class Initialized
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:23:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:23:22 --> Helper loaded: language_helper
INFO - 2016-06-06 12:23:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:23:22 --> Model Class Initialized
INFO - 2016-06-06 12:23:22 --> Helper loaded: date_helper
INFO - 2016-06-06 12:23:22 --> Controller Class Initialized
INFO - 2016-06-06 12:23:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:23:22 --> Config Class Initialized
INFO - 2016-06-06 12:23:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:23:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:23:22 --> Utf8 Class Initialized
INFO - 2016-06-06 12:23:22 --> URI Class Initialized
INFO - 2016-06-06 12:23:22 --> Router Class Initialized
INFO - 2016-06-06 12:23:22 --> Output Class Initialized
INFO - 2016-06-06 12:23:22 --> Security Class Initialized
DEBUG - 2016-06-06 12:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:23:22 --> Input Class Initialized
INFO - 2016-06-06 12:23:22 --> Language Class Initialized
INFO - 2016-06-06 12:23:22 --> Loader Class Initialized
INFO - 2016-06-06 12:23:22 --> Helper loaded: form_helper
INFO - 2016-06-06 12:23:22 --> Database Driver Class Initialized
INFO - 2016-06-06 12:23:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:23:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:23:22 --> Email Class Initialized
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:23:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:23:22 --> Helper loaded: language_helper
INFO - 2016-06-06 12:23:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:23:22 --> Model Class Initialized
INFO - 2016-06-06 12:23:22 --> Helper loaded: date_helper
INFO - 2016-06-06 12:23:22 --> Controller Class Initialized
INFO - 2016-06-06 12:23:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:23:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:23:22 --> Model Class Initialized
INFO - 2016-06-06 12:23:22 --> Form Validation Class Initialized
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-06 12:23:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:23:22 --> Final output sent to browser
DEBUG - 2016-06-06 12:23:22 --> Total execution time: 0.0513
INFO - 2016-06-06 12:24:01 --> Config Class Initialized
INFO - 2016-06-06 12:24:01 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:24:01 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:24:01 --> Utf8 Class Initialized
INFO - 2016-06-06 12:24:01 --> URI Class Initialized
INFO - 2016-06-06 12:24:01 --> Router Class Initialized
INFO - 2016-06-06 12:24:01 --> Output Class Initialized
INFO - 2016-06-06 12:24:01 --> Security Class Initialized
DEBUG - 2016-06-06 12:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:24:01 --> Input Class Initialized
INFO - 2016-06-06 12:24:01 --> Language Class Initialized
INFO - 2016-06-06 12:24:01 --> Loader Class Initialized
INFO - 2016-06-06 12:24:01 --> Helper loaded: form_helper
INFO - 2016-06-06 12:24:01 --> Database Driver Class Initialized
INFO - 2016-06-06 12:24:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:24:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:24:01 --> Email Class Initialized
INFO - 2016-06-06 12:24:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:24:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:24:01 --> Helper loaded: language_helper
INFO - 2016-06-06 12:24:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:24:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:24:01 --> Model Class Initialized
INFO - 2016-06-06 12:24:01 --> Helper loaded: date_helper
INFO - 2016-06-06 12:24:01 --> Controller Class Initialized
INFO - 2016-06-06 12:24:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:24:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:24:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:24:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:24:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:24:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:24:01 --> Model Class Initialized
INFO - 2016-06-06 12:24:01 --> Form Validation Class Initialized
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-06 12:24:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:24:01 --> Final output sent to browser
DEBUG - 2016-06-06 12:24:01 --> Total execution time: 0.0814
INFO - 2016-06-06 12:24:12 --> Config Class Initialized
INFO - 2016-06-06 12:24:12 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:24:12 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:24:12 --> Utf8 Class Initialized
INFO - 2016-06-06 12:24:12 --> URI Class Initialized
DEBUG - 2016-06-06 12:24:12 --> No URI present. Default controller set.
INFO - 2016-06-06 12:24:12 --> Router Class Initialized
INFO - 2016-06-06 12:24:12 --> Output Class Initialized
INFO - 2016-06-06 12:24:12 --> Security Class Initialized
DEBUG - 2016-06-06 12:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:24:12 --> Input Class Initialized
INFO - 2016-06-06 12:24:12 --> Language Class Initialized
INFO - 2016-06-06 12:24:12 --> Loader Class Initialized
INFO - 2016-06-06 12:24:12 --> Helper loaded: form_helper
INFO - 2016-06-06 12:24:12 --> Database Driver Class Initialized
INFO - 2016-06-06 12:24:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:24:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:24:12 --> Email Class Initialized
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:24:12 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:24:12 --> Helper loaded: language_helper
INFO - 2016-06-06 12:24:12 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:24:12 --> Model Class Initialized
INFO - 2016-06-06 12:24:12 --> Helper loaded: date_helper
INFO - 2016-06-06 12:24:12 --> Controller Class Initialized
INFO - 2016-06-06 12:24:12 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:24:12 --> Config Class Initialized
INFO - 2016-06-06 12:24:12 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:24:12 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:24:12 --> Utf8 Class Initialized
INFO - 2016-06-06 12:24:12 --> URI Class Initialized
INFO - 2016-06-06 12:24:12 --> Router Class Initialized
INFO - 2016-06-06 12:24:12 --> Output Class Initialized
INFO - 2016-06-06 12:24:12 --> Security Class Initialized
DEBUG - 2016-06-06 12:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:24:12 --> Input Class Initialized
INFO - 2016-06-06 12:24:12 --> Language Class Initialized
INFO - 2016-06-06 12:24:12 --> Loader Class Initialized
INFO - 2016-06-06 12:24:12 --> Helper loaded: form_helper
INFO - 2016-06-06 12:24:12 --> Database Driver Class Initialized
INFO - 2016-06-06 12:24:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:24:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:24:12 --> Email Class Initialized
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:24:12 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:24:12 --> Helper loaded: language_helper
INFO - 2016-06-06 12:24:12 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:24:12 --> Model Class Initialized
INFO - 2016-06-06 12:24:12 --> Helper loaded: date_helper
INFO - 2016-06-06 12:24:12 --> Controller Class Initialized
INFO - 2016-06-06 12:24:12 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:24:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:24:12 --> Model Class Initialized
INFO - 2016-06-06 12:24:12 --> Form Validation Class Initialized
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-06 12:24:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:24:12 --> Final output sent to browser
DEBUG - 2016-06-06 12:24:12 --> Total execution time: 0.0249
INFO - 2016-06-06 12:24:15 --> Config Class Initialized
INFO - 2016-06-06 12:24:15 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:24:15 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:24:15 --> Utf8 Class Initialized
INFO - 2016-06-06 12:24:15 --> URI Class Initialized
INFO - 2016-06-06 12:24:15 --> Router Class Initialized
INFO - 2016-06-06 12:24:15 --> Output Class Initialized
INFO - 2016-06-06 12:24:15 --> Security Class Initialized
DEBUG - 2016-06-06 12:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:24:15 --> Input Class Initialized
INFO - 2016-06-06 12:24:15 --> Language Class Initialized
INFO - 2016-06-06 12:24:15 --> Loader Class Initialized
INFO - 2016-06-06 12:24:15 --> Helper loaded: form_helper
INFO - 2016-06-06 12:24:15 --> Database Driver Class Initialized
INFO - 2016-06-06 12:24:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:24:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:24:15 --> Email Class Initialized
INFO - 2016-06-06 12:24:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:24:15 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:24:15 --> Helper loaded: language_helper
INFO - 2016-06-06 12:24:15 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:24:15 --> Model Class Initialized
INFO - 2016-06-06 12:24:15 --> Helper loaded: date_helper
INFO - 2016-06-06 12:24:15 --> Controller Class Initialized
INFO - 2016-06-06 12:24:15 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:24:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:24:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:24:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:24:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:24:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:24:15 --> Model Class Initialized
INFO - 2016-06-06 12:24:15 --> Form Validation Class Initialized
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-06 12:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:24:15 --> Final output sent to browser
DEBUG - 2016-06-06 12:24:15 --> Total execution time: 0.0583
INFO - 2016-06-06 12:24:22 --> Config Class Initialized
INFO - 2016-06-06 12:24:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:24:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:24:22 --> Utf8 Class Initialized
INFO - 2016-06-06 12:24:22 --> URI Class Initialized
DEBUG - 2016-06-06 12:24:22 --> No URI present. Default controller set.
INFO - 2016-06-06 12:24:22 --> Router Class Initialized
INFO - 2016-06-06 12:24:22 --> Output Class Initialized
INFO - 2016-06-06 12:24:22 --> Security Class Initialized
DEBUG - 2016-06-06 12:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:24:22 --> Input Class Initialized
INFO - 2016-06-06 12:24:22 --> Language Class Initialized
INFO - 2016-06-06 12:24:22 --> Loader Class Initialized
INFO - 2016-06-06 12:24:22 --> Helper loaded: form_helper
INFO - 2016-06-06 12:24:22 --> Database Driver Class Initialized
INFO - 2016-06-06 12:24:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:24:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:24:22 --> Email Class Initialized
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:24:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:24:22 --> Helper loaded: language_helper
INFO - 2016-06-06 12:24:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:24:22 --> Model Class Initialized
INFO - 2016-06-06 12:24:22 --> Helper loaded: date_helper
INFO - 2016-06-06 12:24:22 --> Controller Class Initialized
INFO - 2016-06-06 12:24:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:24:22 --> Config Class Initialized
INFO - 2016-06-06 12:24:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 12:24:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 12:24:22 --> Utf8 Class Initialized
INFO - 2016-06-06 12:24:22 --> URI Class Initialized
INFO - 2016-06-06 12:24:22 --> Router Class Initialized
INFO - 2016-06-06 12:24:22 --> Output Class Initialized
INFO - 2016-06-06 12:24:22 --> Security Class Initialized
DEBUG - 2016-06-06 12:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 12:24:22 --> Input Class Initialized
INFO - 2016-06-06 12:24:22 --> Language Class Initialized
INFO - 2016-06-06 12:24:22 --> Loader Class Initialized
INFO - 2016-06-06 12:24:22 --> Helper loaded: form_helper
INFO - 2016-06-06 12:24:22 --> Database Driver Class Initialized
INFO - 2016-06-06 12:24:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 12:24:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 12:24:22 --> Email Class Initialized
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 12:24:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 12:24:22 --> Helper loaded: language_helper
INFO - 2016-06-06 12:24:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 12:24:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 12:24:22 --> Model Class Initialized
INFO - 2016-06-06 12:24:22 --> Helper loaded: date_helper
INFO - 2016-06-06 12:24:22 --> Controller Class Initialized
INFO - 2016-06-06 12:24:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 12:24:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 12:24:22 --> Model Class Initialized
INFO - 2016-06-06 12:24:22 --> Form Validation Class Initialized
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-06 12:24:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 12:24:22 --> Final output sent to browser
DEBUG - 2016-06-06 12:24:22 --> Total execution time: 0.0808
INFO - 2016-06-06 13:09:59 --> Config Class Initialized
INFO - 2016-06-06 13:09:59 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:09:59 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:09:59 --> Utf8 Class Initialized
INFO - 2016-06-06 13:09:59 --> URI Class Initialized
INFO - 2016-06-06 13:09:59 --> Router Class Initialized
INFO - 2016-06-06 13:09:59 --> Output Class Initialized
INFO - 2016-06-06 13:09:59 --> Security Class Initialized
DEBUG - 2016-06-06 13:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:09:59 --> Input Class Initialized
INFO - 2016-06-06 13:09:59 --> Language Class Initialized
INFO - 2016-06-06 13:09:59 --> Loader Class Initialized
INFO - 2016-06-06 13:09:59 --> Helper loaded: form_helper
INFO - 2016-06-06 13:09:59 --> Database Driver Class Initialized
INFO - 2016-06-06 13:09:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:09:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:09:59 --> Email Class Initialized
INFO - 2016-06-06 13:09:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:09:59 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:09:59 --> Helper loaded: language_helper
INFO - 2016-06-06 13:09:59 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:09:59 --> Model Class Initialized
INFO - 2016-06-06 13:09:59 --> Helper loaded: date_helper
INFO - 2016-06-06 13:09:59 --> Controller Class Initialized
INFO - 2016-06-06 13:09:59 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:09:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:09:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:09:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:09:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:09:59 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 13:09:59 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:09:59 --> Form Validation Class Initialized
INFO - 2016-06-06 13:10:00 --> Config Class Initialized
INFO - 2016-06-06 13:10:00 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:10:00 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:10:00 --> Utf8 Class Initialized
INFO - 2016-06-06 13:10:00 --> URI Class Initialized
INFO - 2016-06-06 13:10:00 --> Router Class Initialized
INFO - 2016-06-06 13:10:00 --> Output Class Initialized
INFO - 2016-06-06 13:10:00 --> Security Class Initialized
DEBUG - 2016-06-06 13:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:10:00 --> Input Class Initialized
INFO - 2016-06-06 13:10:00 --> Language Class Initialized
INFO - 2016-06-06 13:10:00 --> Loader Class Initialized
INFO - 2016-06-06 13:10:00 --> Helper loaded: form_helper
INFO - 2016-06-06 13:10:00 --> Database Driver Class Initialized
INFO - 2016-06-06 13:10:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:10:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:10:00 --> Email Class Initialized
INFO - 2016-06-06 13:10:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:10:00 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:10:00 --> Helper loaded: language_helper
INFO - 2016-06-06 13:10:00 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:00 --> Model Class Initialized
INFO - 2016-06-06 13:10:00 --> Helper loaded: date_helper
INFO - 2016-06-06 13:10:00 --> Controller Class Initialized
INFO - 2016-06-06 13:10:00 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:10:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:10:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:10:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:10:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:10:00 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 13:10:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:00 --> Form Validation Class Initialized
DEBUG - 2016-06-06 13:10:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 13:10:00 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 13:10:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 13:10:00 --> Final output sent to browser
DEBUG - 2016-06-06 13:10:00 --> Total execution time: 0.0155
INFO - 2016-06-06 13:10:13 --> Config Class Initialized
INFO - 2016-06-06 13:10:13 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:10:13 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:10:13 --> Utf8 Class Initialized
INFO - 2016-06-06 13:10:13 --> URI Class Initialized
INFO - 2016-06-06 13:10:13 --> Router Class Initialized
INFO - 2016-06-06 13:10:13 --> Output Class Initialized
INFO - 2016-06-06 13:10:13 --> Security Class Initialized
DEBUG - 2016-06-06 13:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:10:13 --> Input Class Initialized
INFO - 2016-06-06 13:10:13 --> Language Class Initialized
INFO - 2016-06-06 13:10:13 --> Loader Class Initialized
INFO - 2016-06-06 13:10:13 --> Helper loaded: form_helper
INFO - 2016-06-06 13:10:13 --> Database Driver Class Initialized
INFO - 2016-06-06 13:10:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:10:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:10:13 --> Email Class Initialized
INFO - 2016-06-06 13:10:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:10:13 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:10:13 --> Helper loaded: language_helper
INFO - 2016-06-06 13:10:13 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:10:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:13 --> Model Class Initialized
INFO - 2016-06-06 13:10:13 --> Helper loaded: date_helper
INFO - 2016-06-06 13:10:13 --> Controller Class Initialized
INFO - 2016-06-06 13:10:13 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:10:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:10:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:10:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:10:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:10:13 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 13:10:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:13 --> Form Validation Class Initialized
DEBUG - 2016-06-06 13:10:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:14 --> Config Class Initialized
INFO - 2016-06-06 13:10:14 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:10:14 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:10:14 --> Utf8 Class Initialized
INFO - 2016-06-06 13:10:14 --> URI Class Initialized
DEBUG - 2016-06-06 13:10:14 --> No URI present. Default controller set.
INFO - 2016-06-06 13:10:14 --> Router Class Initialized
INFO - 2016-06-06 13:10:14 --> Output Class Initialized
INFO - 2016-06-06 13:10:14 --> Security Class Initialized
DEBUG - 2016-06-06 13:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:10:14 --> Input Class Initialized
INFO - 2016-06-06 13:10:14 --> Language Class Initialized
INFO - 2016-06-06 13:10:14 --> Loader Class Initialized
INFO - 2016-06-06 13:10:14 --> Helper loaded: form_helper
INFO - 2016-06-06 13:10:14 --> Database Driver Class Initialized
INFO - 2016-06-06 13:10:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:10:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:10:14 --> Email Class Initialized
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:10:14 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:10:14 --> Helper loaded: language_helper
INFO - 2016-06-06 13:10:14 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:14 --> Model Class Initialized
INFO - 2016-06-06 13:10:14 --> Helper loaded: date_helper
INFO - 2016-06-06 13:10:14 --> Controller Class Initialized
INFO - 2016-06-06 13:10:14 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:10:14 --> Config Class Initialized
INFO - 2016-06-06 13:10:14 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:10:14 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:10:14 --> Utf8 Class Initialized
INFO - 2016-06-06 13:10:14 --> URI Class Initialized
INFO - 2016-06-06 13:10:14 --> Router Class Initialized
INFO - 2016-06-06 13:10:14 --> Output Class Initialized
INFO - 2016-06-06 13:10:14 --> Security Class Initialized
DEBUG - 2016-06-06 13:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:10:14 --> Input Class Initialized
INFO - 2016-06-06 13:10:14 --> Language Class Initialized
INFO - 2016-06-06 13:10:14 --> Loader Class Initialized
INFO - 2016-06-06 13:10:14 --> Helper loaded: form_helper
INFO - 2016-06-06 13:10:14 --> Database Driver Class Initialized
INFO - 2016-06-06 13:10:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:10:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:10:14 --> Email Class Initialized
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:10:14 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:10:14 --> Helper loaded: language_helper
INFO - 2016-06-06 13:10:14 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:14 --> Model Class Initialized
INFO - 2016-06-06 13:10:14 --> Helper loaded: date_helper
INFO - 2016-06-06 13:10:14 --> Controller Class Initialized
INFO - 2016-06-06 13:10:14 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:10:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:10:14 --> Model Class Initialized
INFO - 2016-06-06 13:10:14 --> Form Validation Class Initialized
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 13:10:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 13:10:14 --> Final output sent to browser
DEBUG - 2016-06-06 13:10:14 --> Total execution time: 0.0875
INFO - 2016-06-06 13:10:16 --> Config Class Initialized
INFO - 2016-06-06 13:10:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:10:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:10:16 --> Utf8 Class Initialized
INFO - 2016-06-06 13:10:16 --> URI Class Initialized
INFO - 2016-06-06 13:10:16 --> Router Class Initialized
INFO - 2016-06-06 13:10:16 --> Output Class Initialized
INFO - 2016-06-06 13:10:16 --> Security Class Initialized
DEBUG - 2016-06-06 13:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:10:16 --> Input Class Initialized
INFO - 2016-06-06 13:10:16 --> Language Class Initialized
INFO - 2016-06-06 13:10:16 --> Loader Class Initialized
INFO - 2016-06-06 13:10:16 --> Helper loaded: form_helper
INFO - 2016-06-06 13:10:16 --> Database Driver Class Initialized
INFO - 2016-06-06 13:10:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:10:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:10:16 --> Email Class Initialized
INFO - 2016-06-06 13:10:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:10:16 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:10:16 --> Helper loaded: language_helper
INFO - 2016-06-06 13:10:16 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:10:16 --> Model Class Initialized
INFO - 2016-06-06 13:10:16 --> Helper loaded: date_helper
INFO - 2016-06-06 13:10:16 --> Controller Class Initialized
INFO - 2016-06-06 13:10:16 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:10:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:10:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:10:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:10:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:10:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:10:16 --> Model Class Initialized
INFO - 2016-06-06 13:10:16 --> Form Validation Class Initialized
INFO - 2016-06-06 13:10:16 --> Final output sent to browser
DEBUG - 2016-06-06 13:10:16 --> Total execution time: 0.0183
INFO - 2016-06-06 13:19:25 --> Config Class Initialized
INFO - 2016-06-06 13:19:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:19:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:19:25 --> Utf8 Class Initialized
INFO - 2016-06-06 13:19:25 --> URI Class Initialized
INFO - 2016-06-06 13:19:25 --> Router Class Initialized
INFO - 2016-06-06 13:19:25 --> Output Class Initialized
INFO - 2016-06-06 13:19:25 --> Security Class Initialized
DEBUG - 2016-06-06 13:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:19:25 --> Input Class Initialized
INFO - 2016-06-06 13:19:25 --> Language Class Initialized
INFO - 2016-06-06 13:19:25 --> Loader Class Initialized
INFO - 2016-06-06 13:19:25 --> Helper loaded: form_helper
INFO - 2016-06-06 13:19:25 --> Database Driver Class Initialized
INFO - 2016-06-06 13:19:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:19:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:19:25 --> Email Class Initialized
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:19:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:19:25 --> Helper loaded: language_helper
INFO - 2016-06-06 13:19:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:19:25 --> Model Class Initialized
INFO - 2016-06-06 13:19:25 --> Helper loaded: date_helper
INFO - 2016-06-06 13:19:25 --> Controller Class Initialized
INFO - 2016-06-06 13:19:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:19:25 --> Model Class Initialized
INFO - 2016-06-06 13:19:25 --> Form Validation Class Initialized
INFO - 2016-06-06 13:19:25 --> Config Class Initialized
INFO - 2016-06-06 13:19:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:19:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:19:25 --> Utf8 Class Initialized
INFO - 2016-06-06 13:19:25 --> URI Class Initialized
INFO - 2016-06-06 13:19:25 --> Router Class Initialized
INFO - 2016-06-06 13:19:25 --> Output Class Initialized
INFO - 2016-06-06 13:19:25 --> Security Class Initialized
DEBUG - 2016-06-06 13:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:19:25 --> Input Class Initialized
INFO - 2016-06-06 13:19:25 --> Language Class Initialized
INFO - 2016-06-06 13:19:25 --> Loader Class Initialized
INFO - 2016-06-06 13:19:25 --> Helper loaded: form_helper
INFO - 2016-06-06 13:19:25 --> Database Driver Class Initialized
INFO - 2016-06-06 13:19:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:19:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:19:25 --> Email Class Initialized
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:19:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:19:25 --> Helper loaded: language_helper
INFO - 2016-06-06 13:19:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:19:25 --> Model Class Initialized
INFO - 2016-06-06 13:19:25 --> Helper loaded: date_helper
INFO - 2016-06-06 13:19:25 --> Controller Class Initialized
INFO - 2016-06-06 13:19:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:19:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-06 13:19:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:19:25 --> Form Validation Class Initialized
DEBUG - 2016-06-06 13:19:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:19:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-06 13:19:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-06 13:19:25 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-06 13:19:25 --> Final output sent to browser
DEBUG - 2016-06-06 13:19:25 --> Total execution time: 0.0154
INFO - 2016-06-06 13:31:45 --> Config Class Initialized
INFO - 2016-06-06 13:31:45 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:31:45 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:31:45 --> Utf8 Class Initialized
INFO - 2016-06-06 13:31:45 --> URI Class Initialized
INFO - 2016-06-06 13:31:45 --> Router Class Initialized
INFO - 2016-06-06 13:31:45 --> Output Class Initialized
INFO - 2016-06-06 13:31:45 --> Security Class Initialized
DEBUG - 2016-06-06 13:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:31:45 --> Input Class Initialized
INFO - 2016-06-06 13:31:45 --> Language Class Initialized
INFO - 2016-06-06 13:31:45 --> Loader Class Initialized
INFO - 2016-06-06 13:31:45 --> Helper loaded: form_helper
INFO - 2016-06-06 13:31:45 --> Database Driver Class Initialized
INFO - 2016-06-06 13:31:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:31:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:31:45 --> Email Class Initialized
INFO - 2016-06-06 13:31:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:31:45 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:31:45 --> Helper loaded: language_helper
INFO - 2016-06-06 13:31:45 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:31:45 --> Model Class Initialized
INFO - 2016-06-06 13:31:45 --> Helper loaded: date_helper
INFO - 2016-06-06 13:31:45 --> Controller Class Initialized
INFO - 2016-06-06 13:31:45 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:31:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:31:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:31:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:31:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:31:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:31:45 --> Model Class Initialized
INFO - 2016-06-06 13:31:45 --> Form Validation Class Initialized
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 13:31:45 --> Could not find the language line "dashboard_glucose_value_label "
ERROR - 2016-06-06 13:31:45 --> Severity: Notice --> Undefined variable: pacienti /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 23
ERROR - 2016-06-06 13:31:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 23
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 13:31:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 13:31:45 --> Final output sent to browser
DEBUG - 2016-06-06 13:31:45 --> Total execution time: 0.0389
INFO - 2016-06-06 13:31:47 --> Config Class Initialized
INFO - 2016-06-06 13:31:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:31:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:31:47 --> Utf8 Class Initialized
INFO - 2016-06-06 13:31:47 --> URI Class Initialized
INFO - 2016-06-06 13:31:47 --> Router Class Initialized
INFO - 2016-06-06 13:31:47 --> Output Class Initialized
INFO - 2016-06-06 13:31:47 --> Security Class Initialized
DEBUG - 2016-06-06 13:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:31:47 --> Input Class Initialized
INFO - 2016-06-06 13:31:47 --> Language Class Initialized
INFO - 2016-06-06 13:31:47 --> Loader Class Initialized
INFO - 2016-06-06 13:31:47 --> Helper loaded: form_helper
INFO - 2016-06-06 13:31:47 --> Database Driver Class Initialized
INFO - 2016-06-06 13:31:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:31:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:31:47 --> Email Class Initialized
INFO - 2016-06-06 13:31:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:31:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:31:47 --> Helper loaded: language_helper
INFO - 2016-06-06 13:31:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:31:47 --> Model Class Initialized
INFO - 2016-06-06 13:31:47 --> Helper loaded: date_helper
INFO - 2016-06-06 13:31:47 --> Controller Class Initialized
INFO - 2016-06-06 13:31:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:31:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:31:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:31:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:31:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:31:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:31:47 --> Model Class Initialized
INFO - 2016-06-06 13:31:47 --> Form Validation Class Initialized
INFO - 2016-06-06 13:31:47 --> Final output sent to browser
DEBUG - 2016-06-06 13:31:47 --> Total execution time: 0.0143
INFO - 2016-06-06 13:32:07 --> Config Class Initialized
INFO - 2016-06-06 13:32:07 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:32:07 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:32:07 --> Utf8 Class Initialized
INFO - 2016-06-06 13:32:07 --> URI Class Initialized
INFO - 2016-06-06 13:32:07 --> Router Class Initialized
INFO - 2016-06-06 13:32:07 --> Output Class Initialized
INFO - 2016-06-06 13:32:07 --> Security Class Initialized
DEBUG - 2016-06-06 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:32:07 --> Input Class Initialized
INFO - 2016-06-06 13:32:07 --> Language Class Initialized
INFO - 2016-06-06 13:32:07 --> Loader Class Initialized
INFO - 2016-06-06 13:32:07 --> Helper loaded: form_helper
INFO - 2016-06-06 13:32:07 --> Database Driver Class Initialized
INFO - 2016-06-06 13:32:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:32:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:32:07 --> Email Class Initialized
INFO - 2016-06-06 13:32:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:32:07 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:32:07 --> Helper loaded: language_helper
INFO - 2016-06-06 13:32:07 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:32:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:32:07 --> Model Class Initialized
INFO - 2016-06-06 13:32:07 --> Helper loaded: date_helper
INFO - 2016-06-06 13:32:07 --> Controller Class Initialized
INFO - 2016-06-06 13:32:07 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:32:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:32:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:32:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:32:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:32:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:32:07 --> Model Class Initialized
INFO - 2016-06-06 13:32:07 --> Form Validation Class Initialized
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 13:32:07 --> Could not find the language line "dashboard_glucose_value_label "
ERROR - 2016-06-06 13:32:07 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 23
ERROR - 2016-06-06 13:32:07 --> Severity: Notice --> Undefined variable: pacienti /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 24
ERROR - 2016-06-06 13:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 24
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 13:32:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 13:32:07 --> Final output sent to browser
DEBUG - 2016-06-06 13:32:07 --> Total execution time: 0.0302
INFO - 2016-06-06 13:32:09 --> Config Class Initialized
INFO - 2016-06-06 13:32:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:32:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:32:09 --> Utf8 Class Initialized
INFO - 2016-06-06 13:32:09 --> URI Class Initialized
INFO - 2016-06-06 13:32:09 --> Router Class Initialized
INFO - 2016-06-06 13:32:09 --> Output Class Initialized
INFO - 2016-06-06 13:32:09 --> Security Class Initialized
DEBUG - 2016-06-06 13:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:32:09 --> Input Class Initialized
INFO - 2016-06-06 13:32:09 --> Language Class Initialized
INFO - 2016-06-06 13:32:09 --> Loader Class Initialized
INFO - 2016-06-06 13:32:09 --> Helper loaded: form_helper
INFO - 2016-06-06 13:32:09 --> Database Driver Class Initialized
INFO - 2016-06-06 13:32:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:32:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:32:09 --> Email Class Initialized
INFO - 2016-06-06 13:32:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:32:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:32:09 --> Helper loaded: language_helper
INFO - 2016-06-06 13:32:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:32:09 --> Model Class Initialized
INFO - 2016-06-06 13:32:09 --> Helper loaded: date_helper
INFO - 2016-06-06 13:32:09 --> Controller Class Initialized
INFO - 2016-06-06 13:32:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:32:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:32:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:32:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:32:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:32:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:32:09 --> Model Class Initialized
INFO - 2016-06-06 13:32:09 --> Form Validation Class Initialized
INFO - 2016-06-06 13:32:09 --> Final output sent to browser
DEBUG - 2016-06-06 13:32:09 --> Total execution time: 0.0137
INFO - 2016-06-06 13:40:00 --> Config Class Initialized
INFO - 2016-06-06 13:40:00 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:40:00 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:40:00 --> Utf8 Class Initialized
INFO - 2016-06-06 13:40:00 --> URI Class Initialized
INFO - 2016-06-06 13:40:00 --> Router Class Initialized
INFO - 2016-06-06 13:40:00 --> Output Class Initialized
INFO - 2016-06-06 13:40:00 --> Security Class Initialized
DEBUG - 2016-06-06 13:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:40:00 --> Input Class Initialized
INFO - 2016-06-06 13:40:00 --> Language Class Initialized
ERROR - 2016-06-06 13:40:00 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /home/demis/www/platformadiabet/application/controllers/Diabet.php 120
INFO - 2016-06-06 13:40:16 --> Config Class Initialized
INFO - 2016-06-06 13:40:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:40:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:40:16 --> Utf8 Class Initialized
INFO - 2016-06-06 13:40:16 --> URI Class Initialized
INFO - 2016-06-06 13:40:16 --> Router Class Initialized
INFO - 2016-06-06 13:40:16 --> Output Class Initialized
INFO - 2016-06-06 13:40:16 --> Security Class Initialized
DEBUG - 2016-06-06 13:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:40:16 --> Input Class Initialized
INFO - 2016-06-06 13:40:16 --> Language Class Initialized
ERROR - 2016-06-06 13:40:16 --> Severity: Parsing Error --> syntax error, unexpected ',' /home/demis/www/platformadiabet/application/controllers/Diabet.php 365
INFO - 2016-06-06 13:40:33 --> Config Class Initialized
INFO - 2016-06-06 13:40:33 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:40:33 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:40:33 --> Utf8 Class Initialized
INFO - 2016-06-06 13:40:33 --> URI Class Initialized
INFO - 2016-06-06 13:40:33 --> Router Class Initialized
INFO - 2016-06-06 13:40:33 --> Output Class Initialized
INFO - 2016-06-06 13:40:33 --> Security Class Initialized
DEBUG - 2016-06-06 13:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:40:33 --> Input Class Initialized
INFO - 2016-06-06 13:40:33 --> Language Class Initialized
INFO - 2016-06-06 13:40:33 --> Loader Class Initialized
INFO - 2016-06-06 13:40:33 --> Helper loaded: form_helper
INFO - 2016-06-06 13:40:33 --> Database Driver Class Initialized
INFO - 2016-06-06 13:40:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:40:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:40:33 --> Email Class Initialized
INFO - 2016-06-06 13:40:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:40:33 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:40:33 --> Helper loaded: language_helper
INFO - 2016-06-06 13:40:33 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:40:33 --> Model Class Initialized
INFO - 2016-06-06 13:40:33 --> Helper loaded: date_helper
INFO - 2016-06-06 13:40:33 --> Controller Class Initialized
INFO - 2016-06-06 13:40:33 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:40:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:40:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:40:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:40:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:40:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:40:33 --> Model Class Initialized
INFO - 2016-06-06 13:40:33 --> Form Validation Class Initialized
ERROR - 2016-06-06 13:40:33 --> Severity: Notice --> Undefined offset: 0 /home/demis/www/platformadiabet/application/controllers/Diabet.php 375
ERROR - 2016-06-06 13:40:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 375
INFO - 2016-06-06 13:40:59 --> Config Class Initialized
INFO - 2016-06-06 13:40:59 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:40:59 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:40:59 --> Utf8 Class Initialized
INFO - 2016-06-06 13:40:59 --> URI Class Initialized
INFO - 2016-06-06 13:40:59 --> Router Class Initialized
INFO - 2016-06-06 13:40:59 --> Output Class Initialized
INFO - 2016-06-06 13:40:59 --> Security Class Initialized
DEBUG - 2016-06-06 13:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:40:59 --> Input Class Initialized
INFO - 2016-06-06 13:40:59 --> Language Class Initialized
INFO - 2016-06-06 13:40:59 --> Loader Class Initialized
INFO - 2016-06-06 13:40:59 --> Helper loaded: form_helper
INFO - 2016-06-06 13:40:59 --> Database Driver Class Initialized
INFO - 2016-06-06 13:40:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:40:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:40:59 --> Email Class Initialized
INFO - 2016-06-06 13:40:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:40:59 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:40:59 --> Helper loaded: language_helper
INFO - 2016-06-06 13:40:59 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:40:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:40:59 --> Model Class Initialized
INFO - 2016-06-06 13:40:59 --> Helper loaded: date_helper
INFO - 2016-06-06 13:40:59 --> Controller Class Initialized
INFO - 2016-06-06 13:40:59 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:40:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:40:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:40:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:40:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:40:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:40:59 --> Model Class Initialized
INFO - 2016-06-06 13:40:59 --> Form Validation Class Initialized
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "2016-05-31"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "121"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "122"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "123"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "124"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "125"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "126"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "127"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "128"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "129"
ERROR - 2016-06-06 13:40:59 --> Could not find the language line "0"
INFO - 2016-06-06 13:41:26 --> Config Class Initialized
INFO - 2016-06-06 13:41:26 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:41:26 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:41:26 --> Utf8 Class Initialized
INFO - 2016-06-06 13:41:26 --> URI Class Initialized
INFO - 2016-06-06 13:41:26 --> Router Class Initialized
INFO - 2016-06-06 13:41:26 --> Output Class Initialized
INFO - 2016-06-06 13:41:26 --> Security Class Initialized
DEBUG - 2016-06-06 13:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:41:26 --> Input Class Initialized
INFO - 2016-06-06 13:41:26 --> Language Class Initialized
INFO - 2016-06-06 13:41:26 --> Loader Class Initialized
INFO - 2016-06-06 13:41:26 --> Helper loaded: form_helper
INFO - 2016-06-06 13:41:26 --> Database Driver Class Initialized
INFO - 2016-06-06 13:41:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:41:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:41:26 --> Email Class Initialized
INFO - 2016-06-06 13:41:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:41:26 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:41:26 --> Helper loaded: language_helper
INFO - 2016-06-06 13:41:26 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:41:26 --> Model Class Initialized
INFO - 2016-06-06 13:41:26 --> Helper loaded: date_helper
INFO - 2016-06-06 13:41:26 --> Controller Class Initialized
INFO - 2016-06-06 13:41:26 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:41:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:41:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:41:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:41:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:41:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:41:26 --> Model Class Initialized
INFO - 2016-06-06 13:41:26 --> Form Validation Class Initialized
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "2016-05-31"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "121"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "122"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "123"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "124"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "125"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "126"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "127"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "128"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "129"
ERROR - 2016-06-06 13:41:26 --> Could not find the language line "0"
INFO - 2016-06-06 13:42:14 --> Config Class Initialized
INFO - 2016-06-06 13:42:14 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:42:14 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:42:14 --> Utf8 Class Initialized
INFO - 2016-06-06 13:42:14 --> URI Class Initialized
INFO - 2016-06-06 13:42:14 --> Router Class Initialized
INFO - 2016-06-06 13:42:14 --> Output Class Initialized
INFO - 2016-06-06 13:42:14 --> Security Class Initialized
DEBUG - 2016-06-06 13:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:42:14 --> Input Class Initialized
INFO - 2016-06-06 13:42:14 --> Language Class Initialized
INFO - 2016-06-06 13:42:14 --> Loader Class Initialized
INFO - 2016-06-06 13:42:14 --> Helper loaded: form_helper
INFO - 2016-06-06 13:42:14 --> Database Driver Class Initialized
INFO - 2016-06-06 13:42:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:42:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:42:14 --> Email Class Initialized
INFO - 2016-06-06 13:42:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:42:14 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:42:14 --> Helper loaded: language_helper
INFO - 2016-06-06 13:42:14 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:42:14 --> Model Class Initialized
INFO - 2016-06-06 13:42:14 --> Helper loaded: date_helper
INFO - 2016-06-06 13:42:14 --> Controller Class Initialized
INFO - 2016-06-06 13:42:14 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:42:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:42:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:42:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:42:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:42:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:42:14 --> Model Class Initialized
INFO - 2016-06-06 13:42:14 --> Form Validation Class Initialized
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "2016-05-31"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "121"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "122"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "123"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "124"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "125"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "126"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "127"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "128"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "129"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "0"
ERROR - 2016-06-06 13:42:14 --> Could not find the language line "{"interval_1_nota":"nota 1","interval_2_nota":"nota 2","interval_3_nota":"nota 3","interval_4_nota":"nota 4","interval_5_nota":"nota 5","interval_6_nota":"nota 6","interval_7_nota":"nota 7","interval_8_nota":"nota 8","interval_9_nota":"nota 9","interval_10_nota":"nota 10"}"
INFO - 2016-06-06 13:42:41 --> Config Class Initialized
INFO - 2016-06-06 13:42:41 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:42:41 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:42:41 --> Utf8 Class Initialized
INFO - 2016-06-06 13:42:41 --> URI Class Initialized
INFO - 2016-06-06 13:42:41 --> Router Class Initialized
INFO - 2016-06-06 13:42:41 --> Output Class Initialized
INFO - 2016-06-06 13:42:41 --> Security Class Initialized
DEBUG - 2016-06-06 13:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:42:41 --> Input Class Initialized
INFO - 2016-06-06 13:42:41 --> Language Class Initialized
INFO - 2016-06-06 13:42:41 --> Loader Class Initialized
INFO - 2016-06-06 13:42:41 --> Helper loaded: form_helper
INFO - 2016-06-06 13:42:41 --> Database Driver Class Initialized
INFO - 2016-06-06 13:42:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:42:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:42:41 --> Email Class Initialized
INFO - 2016-06-06 13:42:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:42:41 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:42:41 --> Helper loaded: language_helper
INFO - 2016-06-06 13:42:41 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:42:41 --> Model Class Initialized
INFO - 2016-06-06 13:42:41 --> Helper loaded: date_helper
INFO - 2016-06-06 13:42:41 --> Controller Class Initialized
INFO - 2016-06-06 13:42:41 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:42:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:42:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:42:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:42:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:42:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:42:41 --> Model Class Initialized
INFO - 2016-06-06 13:42:41 --> Form Validation Class Initialized
INFO - 2016-06-06 13:44:59 --> Config Class Initialized
INFO - 2016-06-06 13:44:59 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:44:59 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:44:59 --> Utf8 Class Initialized
INFO - 2016-06-06 13:44:59 --> URI Class Initialized
INFO - 2016-06-06 13:44:59 --> Router Class Initialized
INFO - 2016-06-06 13:44:59 --> Output Class Initialized
INFO - 2016-06-06 13:44:59 --> Security Class Initialized
DEBUG - 2016-06-06 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:44:59 --> Input Class Initialized
INFO - 2016-06-06 13:44:59 --> Language Class Initialized
INFO - 2016-06-06 13:44:59 --> Loader Class Initialized
INFO - 2016-06-06 13:44:59 --> Helper loaded: form_helper
INFO - 2016-06-06 13:44:59 --> Database Driver Class Initialized
INFO - 2016-06-06 13:44:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:44:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:44:59 --> Email Class Initialized
INFO - 2016-06-06 13:44:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:44:59 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:44:59 --> Helper loaded: language_helper
INFO - 2016-06-06 13:44:59 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:44:59 --> Model Class Initialized
INFO - 2016-06-06 13:44:59 --> Helper loaded: date_helper
INFO - 2016-06-06 13:44:59 --> Controller Class Initialized
INFO - 2016-06-06 13:44:59 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:44:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:44:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:44:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:44:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:44:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:44:59 --> Model Class Initialized
INFO - 2016-06-06 13:44:59 --> Form Validation Class Initialized
ERROR - 2016-06-06 13:45:00 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
ERROR - 2016-06-06 13:45:00 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
INFO - 2016-06-06 13:45:20 --> Config Class Initialized
INFO - 2016-06-06 13:45:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:45:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:45:20 --> Utf8 Class Initialized
INFO - 2016-06-06 13:45:20 --> URI Class Initialized
INFO - 2016-06-06 13:45:20 --> Router Class Initialized
INFO - 2016-06-06 13:45:20 --> Output Class Initialized
INFO - 2016-06-06 13:45:20 --> Security Class Initialized
DEBUG - 2016-06-06 13:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:45:20 --> Input Class Initialized
INFO - 2016-06-06 13:45:20 --> Language Class Initialized
INFO - 2016-06-06 13:45:20 --> Loader Class Initialized
INFO - 2016-06-06 13:45:20 --> Helper loaded: form_helper
INFO - 2016-06-06 13:45:20 --> Database Driver Class Initialized
INFO - 2016-06-06 13:45:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:45:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:45:20 --> Email Class Initialized
INFO - 2016-06-06 13:45:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:45:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:45:20 --> Helper loaded: language_helper
INFO - 2016-06-06 13:45:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:45:20 --> Model Class Initialized
INFO - 2016-06-06 13:45:20 --> Helper loaded: date_helper
INFO - 2016-06-06 13:45:20 --> Controller Class Initialized
INFO - 2016-06-06 13:45:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:45:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:45:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:45:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:45:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:45:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:45:20 --> Model Class Initialized
INFO - 2016-06-06 13:45:20 --> Form Validation Class Initialized
ERROR - 2016-06-06 13:45:20 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
ERROR - 2016-06-06 13:45:20 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
INFO - 2016-06-06 13:45:24 --> Config Class Initialized
INFO - 2016-06-06 13:45:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:45:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:45:24 --> Utf8 Class Initialized
INFO - 2016-06-06 13:45:24 --> URI Class Initialized
INFO - 2016-06-06 13:45:24 --> Router Class Initialized
INFO - 2016-06-06 13:45:24 --> Output Class Initialized
INFO - 2016-06-06 13:45:24 --> Security Class Initialized
DEBUG - 2016-06-06 13:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:45:24 --> Input Class Initialized
INFO - 2016-06-06 13:45:24 --> Language Class Initialized
INFO - 2016-06-06 13:45:24 --> Loader Class Initialized
INFO - 2016-06-06 13:45:24 --> Helper loaded: form_helper
INFO - 2016-06-06 13:45:24 --> Database Driver Class Initialized
INFO - 2016-06-06 13:45:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:45:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:45:24 --> Email Class Initialized
INFO - 2016-06-06 13:45:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:45:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:45:24 --> Helper loaded: language_helper
INFO - 2016-06-06 13:45:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:45:24 --> Model Class Initialized
INFO - 2016-06-06 13:45:24 --> Helper loaded: date_helper
INFO - 2016-06-06 13:45:24 --> Controller Class Initialized
INFO - 2016-06-06 13:45:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:45:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:45:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:45:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:45:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:45:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:45:24 --> Model Class Initialized
INFO - 2016-06-06 13:45:24 --> Form Validation Class Initialized
ERROR - 2016-06-06 13:45:24 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
ERROR - 2016-06-06 13:45:24 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
INFO - 2016-06-06 13:45:43 --> Config Class Initialized
INFO - 2016-06-06 13:45:43 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:45:43 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:45:43 --> Utf8 Class Initialized
INFO - 2016-06-06 13:45:43 --> URI Class Initialized
INFO - 2016-06-06 13:45:43 --> Router Class Initialized
INFO - 2016-06-06 13:45:43 --> Output Class Initialized
INFO - 2016-06-06 13:45:43 --> Security Class Initialized
DEBUG - 2016-06-06 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:45:43 --> Input Class Initialized
INFO - 2016-06-06 13:45:43 --> Language Class Initialized
INFO - 2016-06-06 13:45:43 --> Loader Class Initialized
INFO - 2016-06-06 13:45:43 --> Helper loaded: form_helper
INFO - 2016-06-06 13:45:43 --> Database Driver Class Initialized
INFO - 2016-06-06 13:45:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:45:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:45:43 --> Email Class Initialized
INFO - 2016-06-06 13:45:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:45:43 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:45:43 --> Helper loaded: language_helper
INFO - 2016-06-06 13:45:43 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:45:43 --> Model Class Initialized
INFO - 2016-06-06 13:45:43 --> Helper loaded: date_helper
INFO - 2016-06-06 13:45:43 --> Controller Class Initialized
INFO - 2016-06-06 13:45:43 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:45:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:45:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:45:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:45:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:45:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:45:43 --> Model Class Initialized
INFO - 2016-06-06 13:45:43 --> Form Validation Class Initialized
INFO - 2016-06-06 13:46:40 --> Config Class Initialized
INFO - 2016-06-06 13:46:40 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:46:40 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:46:40 --> Utf8 Class Initialized
INFO - 2016-06-06 13:46:40 --> URI Class Initialized
INFO - 2016-06-06 13:46:40 --> Router Class Initialized
INFO - 2016-06-06 13:46:40 --> Output Class Initialized
INFO - 2016-06-06 13:46:40 --> Security Class Initialized
DEBUG - 2016-06-06 13:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:46:40 --> Input Class Initialized
INFO - 2016-06-06 13:46:40 --> Language Class Initialized
INFO - 2016-06-06 13:46:40 --> Loader Class Initialized
INFO - 2016-06-06 13:46:40 --> Helper loaded: form_helper
INFO - 2016-06-06 13:46:40 --> Database Driver Class Initialized
INFO - 2016-06-06 13:46:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:46:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:46:40 --> Email Class Initialized
INFO - 2016-06-06 13:46:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:46:40 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:46:40 --> Helper loaded: language_helper
INFO - 2016-06-06 13:46:40 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:46:40 --> Model Class Initialized
INFO - 2016-06-06 13:46:40 --> Helper loaded: date_helper
INFO - 2016-06-06 13:46:40 --> Controller Class Initialized
INFO - 2016-06-06 13:46:40 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:46:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:46:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:46:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:46:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:46:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:46:40 --> Model Class Initialized
INFO - 2016-06-06 13:46:40 --> Form Validation Class Initialized
INFO - 2016-06-06 13:46:47 --> Config Class Initialized
INFO - 2016-06-06 13:46:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:46:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:46:47 --> Utf8 Class Initialized
INFO - 2016-06-06 13:46:47 --> URI Class Initialized
INFO - 2016-06-06 13:46:47 --> Router Class Initialized
INFO - 2016-06-06 13:46:47 --> Output Class Initialized
INFO - 2016-06-06 13:46:47 --> Security Class Initialized
DEBUG - 2016-06-06 13:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:46:47 --> Input Class Initialized
INFO - 2016-06-06 13:46:47 --> Language Class Initialized
INFO - 2016-06-06 13:46:47 --> Loader Class Initialized
INFO - 2016-06-06 13:46:47 --> Helper loaded: form_helper
INFO - 2016-06-06 13:46:47 --> Database Driver Class Initialized
INFO - 2016-06-06 13:46:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:46:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:46:47 --> Email Class Initialized
INFO - 2016-06-06 13:46:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:46:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:46:47 --> Helper loaded: language_helper
INFO - 2016-06-06 13:46:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:46:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:46:47 --> Model Class Initialized
INFO - 2016-06-06 13:46:47 --> Helper loaded: date_helper
INFO - 2016-06-06 13:46:47 --> Controller Class Initialized
INFO - 2016-06-06 13:46:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:46:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:46:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:46:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:46:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:46:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:46:47 --> Model Class Initialized
INFO - 2016-06-06 13:46:47 --> Form Validation Class Initialized
INFO - 2016-06-06 13:47:37 --> Config Class Initialized
INFO - 2016-06-06 13:47:37 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:47:37 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:47:37 --> Utf8 Class Initialized
INFO - 2016-06-06 13:47:37 --> URI Class Initialized
INFO - 2016-06-06 13:47:37 --> Router Class Initialized
INFO - 2016-06-06 13:47:37 --> Output Class Initialized
INFO - 2016-06-06 13:47:37 --> Security Class Initialized
DEBUG - 2016-06-06 13:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:47:37 --> Input Class Initialized
INFO - 2016-06-06 13:47:37 --> Language Class Initialized
INFO - 2016-06-06 13:47:37 --> Loader Class Initialized
INFO - 2016-06-06 13:47:37 --> Helper loaded: form_helper
INFO - 2016-06-06 13:47:37 --> Database Driver Class Initialized
INFO - 2016-06-06 13:47:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:47:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:47:37 --> Email Class Initialized
INFO - 2016-06-06 13:47:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:47:37 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:47:37 --> Helper loaded: language_helper
INFO - 2016-06-06 13:47:37 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:47:37 --> Model Class Initialized
INFO - 2016-06-06 13:47:37 --> Helper loaded: date_helper
INFO - 2016-06-06 13:47:37 --> Controller Class Initialized
INFO - 2016-06-06 13:47:37 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:47:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:47:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:47:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:47:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:47:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:47:37 --> Model Class Initialized
INFO - 2016-06-06 13:47:37 --> Form Validation Class Initialized
INFO - 2016-06-06 13:50:06 --> Config Class Initialized
INFO - 2016-06-06 13:50:06 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:50:06 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:50:06 --> Utf8 Class Initialized
INFO - 2016-06-06 13:50:06 --> URI Class Initialized
INFO - 2016-06-06 13:50:06 --> Router Class Initialized
INFO - 2016-06-06 13:50:06 --> Output Class Initialized
INFO - 2016-06-06 13:50:06 --> Security Class Initialized
DEBUG - 2016-06-06 13:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:50:06 --> Input Class Initialized
INFO - 2016-06-06 13:50:06 --> Language Class Initialized
INFO - 2016-06-06 13:50:06 --> Loader Class Initialized
INFO - 2016-06-06 13:50:06 --> Helper loaded: form_helper
INFO - 2016-06-06 13:50:06 --> Database Driver Class Initialized
INFO - 2016-06-06 13:50:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:50:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:50:06 --> Email Class Initialized
INFO - 2016-06-06 13:50:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:50:06 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:50:06 --> Helper loaded: language_helper
INFO - 2016-06-06 13:50:06 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:50:06 --> Model Class Initialized
INFO - 2016-06-06 13:50:06 --> Helper loaded: date_helper
INFO - 2016-06-06 13:50:06 --> Controller Class Initialized
INFO - 2016-06-06 13:50:06 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:50:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:50:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:50:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:50:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:50:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:50:06 --> Model Class Initialized
INFO - 2016-06-06 13:50:06 --> Form Validation Class Initialized
INFO - 2016-06-06 13:50:07 --> Config Class Initialized
INFO - 2016-06-06 13:50:07 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:50:07 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:50:07 --> Utf8 Class Initialized
INFO - 2016-06-06 13:50:07 --> URI Class Initialized
INFO - 2016-06-06 13:50:07 --> Router Class Initialized
INFO - 2016-06-06 13:50:07 --> Output Class Initialized
INFO - 2016-06-06 13:50:07 --> Security Class Initialized
DEBUG - 2016-06-06 13:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:50:07 --> Input Class Initialized
INFO - 2016-06-06 13:50:07 --> Language Class Initialized
INFO - 2016-06-06 13:50:07 --> Loader Class Initialized
INFO - 2016-06-06 13:50:07 --> Helper loaded: form_helper
INFO - 2016-06-06 13:50:07 --> Database Driver Class Initialized
INFO - 2016-06-06 13:50:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:50:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:50:07 --> Email Class Initialized
INFO - 2016-06-06 13:50:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:50:07 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:50:07 --> Helper loaded: language_helper
INFO - 2016-06-06 13:50:07 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:50:07 --> Model Class Initialized
INFO - 2016-06-06 13:50:07 --> Helper loaded: date_helper
INFO - 2016-06-06 13:50:07 --> Controller Class Initialized
INFO - 2016-06-06 13:50:07 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:50:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:50:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:50:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:50:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:50:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:50:07 --> Model Class Initialized
INFO - 2016-06-06 13:50:07 --> Form Validation Class Initialized
INFO - 2016-06-06 13:50:09 --> Config Class Initialized
INFO - 2016-06-06 13:50:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:50:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:50:09 --> Utf8 Class Initialized
INFO - 2016-06-06 13:50:09 --> URI Class Initialized
INFO - 2016-06-06 13:50:09 --> Router Class Initialized
INFO - 2016-06-06 13:50:09 --> Output Class Initialized
INFO - 2016-06-06 13:50:09 --> Security Class Initialized
DEBUG - 2016-06-06 13:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:50:09 --> Input Class Initialized
INFO - 2016-06-06 13:50:09 --> Language Class Initialized
INFO - 2016-06-06 13:50:09 --> Loader Class Initialized
INFO - 2016-06-06 13:50:09 --> Helper loaded: form_helper
INFO - 2016-06-06 13:50:09 --> Database Driver Class Initialized
INFO - 2016-06-06 13:50:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:50:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:50:09 --> Email Class Initialized
INFO - 2016-06-06 13:50:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:50:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:50:09 --> Helper loaded: language_helper
INFO - 2016-06-06 13:50:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:50:09 --> Model Class Initialized
INFO - 2016-06-06 13:50:09 --> Helper loaded: date_helper
INFO - 2016-06-06 13:50:09 --> Controller Class Initialized
INFO - 2016-06-06 13:50:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:50:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:50:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:50:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:50:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:50:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:50:09 --> Model Class Initialized
INFO - 2016-06-06 13:50:09 --> Form Validation Class Initialized
INFO - 2016-06-06 13:50:18 --> Config Class Initialized
INFO - 2016-06-06 13:50:18 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:50:18 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:50:18 --> Utf8 Class Initialized
INFO - 2016-06-06 13:50:18 --> URI Class Initialized
INFO - 2016-06-06 13:50:18 --> Router Class Initialized
INFO - 2016-06-06 13:50:18 --> Output Class Initialized
INFO - 2016-06-06 13:50:18 --> Security Class Initialized
DEBUG - 2016-06-06 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:50:18 --> Input Class Initialized
INFO - 2016-06-06 13:50:18 --> Language Class Initialized
INFO - 2016-06-06 13:50:18 --> Loader Class Initialized
INFO - 2016-06-06 13:50:18 --> Helper loaded: form_helper
INFO - 2016-06-06 13:50:18 --> Database Driver Class Initialized
INFO - 2016-06-06 13:50:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:50:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:50:18 --> Email Class Initialized
INFO - 2016-06-06 13:50:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:50:18 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:50:18 --> Helper loaded: language_helper
INFO - 2016-06-06 13:50:18 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:50:18 --> Model Class Initialized
INFO - 2016-06-06 13:50:18 --> Helper loaded: date_helper
INFO - 2016-06-06 13:50:18 --> Controller Class Initialized
INFO - 2016-06-06 13:50:18 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:50:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:50:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:50:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:50:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:50:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:50:18 --> Model Class Initialized
INFO - 2016-06-06 13:50:18 --> Form Validation Class Initialized
INFO - 2016-06-06 13:51:04 --> Config Class Initialized
INFO - 2016-06-06 13:51:04 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:51:04 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:51:04 --> Utf8 Class Initialized
INFO - 2016-06-06 13:51:04 --> URI Class Initialized
INFO - 2016-06-06 13:51:04 --> Router Class Initialized
INFO - 2016-06-06 13:51:04 --> Output Class Initialized
INFO - 2016-06-06 13:51:04 --> Security Class Initialized
DEBUG - 2016-06-06 13:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:51:04 --> Input Class Initialized
INFO - 2016-06-06 13:51:04 --> Language Class Initialized
INFO - 2016-06-06 13:51:04 --> Loader Class Initialized
INFO - 2016-06-06 13:51:04 --> Helper loaded: form_helper
INFO - 2016-06-06 13:51:04 --> Database Driver Class Initialized
INFO - 2016-06-06 13:51:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:51:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:51:04 --> Email Class Initialized
INFO - 2016-06-06 13:51:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:51:04 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:51:04 --> Helper loaded: language_helper
INFO - 2016-06-06 13:51:04 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:51:04 --> Model Class Initialized
INFO - 2016-06-06 13:51:04 --> Helper loaded: date_helper
INFO - 2016-06-06 13:51:04 --> Controller Class Initialized
INFO - 2016-06-06 13:51:04 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:51:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:51:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:51:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:51:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:51:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:51:04 --> Model Class Initialized
INFO - 2016-06-06 13:51:04 --> Form Validation Class Initialized
INFO - 2016-06-06 13:55:17 --> Config Class Initialized
INFO - 2016-06-06 13:55:17 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:55:17 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:55:17 --> Utf8 Class Initialized
INFO - 2016-06-06 13:55:17 --> URI Class Initialized
INFO - 2016-06-06 13:55:17 --> Router Class Initialized
INFO - 2016-06-06 13:55:17 --> Output Class Initialized
INFO - 2016-06-06 13:55:17 --> Security Class Initialized
DEBUG - 2016-06-06 13:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:55:17 --> Input Class Initialized
INFO - 2016-06-06 13:55:17 --> Language Class Initialized
INFO - 2016-06-06 13:55:17 --> Loader Class Initialized
INFO - 2016-06-06 13:55:17 --> Helper loaded: form_helper
INFO - 2016-06-06 13:55:17 --> Database Driver Class Initialized
INFO - 2016-06-06 13:55:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 13:55:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 13:55:17 --> Email Class Initialized
INFO - 2016-06-06 13:55:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 13:55:17 --> Helper loaded: cookie_helper
INFO - 2016-06-06 13:55:17 --> Helper loaded: language_helper
INFO - 2016-06-06 13:55:17 --> Helper loaded: url_helper
DEBUG - 2016-06-06 13:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 13:55:17 --> Model Class Initialized
INFO - 2016-06-06 13:55:17 --> Helper loaded: date_helper
INFO - 2016-06-06 13:55:17 --> Controller Class Initialized
INFO - 2016-06-06 13:55:17 --> Helper loaded: languages_helper
INFO - 2016-06-06 13:55:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 13:55:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 13:55:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 13:55:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 13:55:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 13:55:17 --> Model Class Initialized
INFO - 2016-06-06 13:55:17 --> Form Validation Class Initialized
INFO - 2016-06-06 13:58:26 --> Config Class Initialized
INFO - 2016-06-06 13:58:26 --> Hooks Class Initialized
DEBUG - 2016-06-06 13:58:26 --> UTF-8 Support Enabled
INFO - 2016-06-06 13:58:26 --> Utf8 Class Initialized
INFO - 2016-06-06 13:58:26 --> URI Class Initialized
INFO - 2016-06-06 13:58:26 --> Router Class Initialized
INFO - 2016-06-06 13:58:26 --> Output Class Initialized
INFO - 2016-06-06 13:58:26 --> Security Class Initialized
DEBUG - 2016-06-06 13:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 13:58:26 --> Input Class Initialized
INFO - 2016-06-06 13:58:26 --> Language Class Initialized
ERROR - 2016-06-06 13:58:26 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/controllers/Diabet.php 380
INFO - 2016-06-06 14:02:49 --> Config Class Initialized
INFO - 2016-06-06 14:02:49 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:02:49 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:02:49 --> Utf8 Class Initialized
INFO - 2016-06-06 14:02:49 --> URI Class Initialized
INFO - 2016-06-06 14:02:49 --> Router Class Initialized
INFO - 2016-06-06 14:02:49 --> Output Class Initialized
INFO - 2016-06-06 14:02:49 --> Security Class Initialized
DEBUG - 2016-06-06 14:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:02:49 --> Input Class Initialized
INFO - 2016-06-06 14:02:49 --> Language Class Initialized
INFO - 2016-06-06 14:02:49 --> Loader Class Initialized
INFO - 2016-06-06 14:02:49 --> Helper loaded: form_helper
INFO - 2016-06-06 14:02:49 --> Database Driver Class Initialized
INFO - 2016-06-06 14:02:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:02:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:02:49 --> Email Class Initialized
INFO - 2016-06-06 14:02:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:02:49 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:02:49 --> Helper loaded: language_helper
INFO - 2016-06-06 14:02:49 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:02:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:02:49 --> Model Class Initialized
INFO - 2016-06-06 14:02:49 --> Helper loaded: date_helper
INFO - 2016-06-06 14:02:49 --> Controller Class Initialized
INFO - 2016-06-06 14:02:49 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:02:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:02:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:02:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:02:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:02:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:02:49 --> Model Class Initialized
INFO - 2016-06-06 14:02:49 --> Form Validation Class Initialized
ERROR - 2016-06-06 14:02:49 --> Severity: Notice --> Undefined variable: valu2 /home/demis/www/platformadiabet/application/controllers/Diabet.php 377
ERROR - 2016-06-06 14:02:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 377
ERROR - 2016-06-06 14:02:49 --> Severity: Notice --> Undefined variable: valu2 /home/demis/www/platformadiabet/application/controllers/Diabet.php 377
ERROR - 2016-06-06 14:02:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/controllers/Diabet.php 377
INFO - 2016-06-06 14:02:58 --> Config Class Initialized
INFO - 2016-06-06 14:02:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:02:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:02:58 --> Utf8 Class Initialized
INFO - 2016-06-06 14:02:58 --> URI Class Initialized
INFO - 2016-06-06 14:02:58 --> Router Class Initialized
INFO - 2016-06-06 14:02:58 --> Output Class Initialized
INFO - 2016-06-06 14:02:58 --> Security Class Initialized
DEBUG - 2016-06-06 14:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:02:58 --> Input Class Initialized
INFO - 2016-06-06 14:02:58 --> Language Class Initialized
INFO - 2016-06-06 14:02:58 --> Loader Class Initialized
INFO - 2016-06-06 14:02:58 --> Helper loaded: form_helper
INFO - 2016-06-06 14:02:58 --> Database Driver Class Initialized
INFO - 2016-06-06 14:02:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:02:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:02:58 --> Email Class Initialized
INFO - 2016-06-06 14:02:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:02:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:02:58 --> Helper loaded: language_helper
INFO - 2016-06-06 14:02:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:02:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:02:58 --> Model Class Initialized
INFO - 2016-06-06 14:02:58 --> Helper loaded: date_helper
INFO - 2016-06-06 14:02:58 --> Controller Class Initialized
INFO - 2016-06-06 14:02:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:02:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:02:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:02:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:02:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:02:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:02:58 --> Model Class Initialized
INFO - 2016-06-06 14:02:58 --> Form Validation Class Initialized
INFO - 2016-06-06 14:07:35 --> Config Class Initialized
INFO - 2016-06-06 14:07:35 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:07:35 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:07:35 --> Utf8 Class Initialized
INFO - 2016-06-06 14:07:35 --> URI Class Initialized
INFO - 2016-06-06 14:07:35 --> Router Class Initialized
INFO - 2016-06-06 14:07:35 --> Output Class Initialized
INFO - 2016-06-06 14:07:35 --> Security Class Initialized
DEBUG - 2016-06-06 14:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:07:35 --> Input Class Initialized
INFO - 2016-06-06 14:07:35 --> Language Class Initialized
INFO - 2016-06-06 14:07:35 --> Loader Class Initialized
INFO - 2016-06-06 14:07:35 --> Helper loaded: form_helper
INFO - 2016-06-06 14:07:35 --> Database Driver Class Initialized
INFO - 2016-06-06 14:07:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:07:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:07:35 --> Email Class Initialized
INFO - 2016-06-06 14:07:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:07:35 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:07:35 --> Helper loaded: language_helper
INFO - 2016-06-06 14:07:35 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:07:35 --> Model Class Initialized
INFO - 2016-06-06 14:07:35 --> Helper loaded: date_helper
INFO - 2016-06-06 14:07:35 --> Controller Class Initialized
INFO - 2016-06-06 14:07:35 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:07:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:07:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:07:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:07:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:07:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:07:35 --> Model Class Initialized
INFO - 2016-06-06 14:07:35 --> Form Validation Class Initialized
INFO - 2016-06-06 14:09:03 --> Config Class Initialized
INFO - 2016-06-06 14:09:03 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:09:03 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:09:03 --> Utf8 Class Initialized
INFO - 2016-06-06 14:09:03 --> URI Class Initialized
INFO - 2016-06-06 14:09:03 --> Router Class Initialized
INFO - 2016-06-06 14:09:03 --> Output Class Initialized
INFO - 2016-06-06 14:09:03 --> Security Class Initialized
DEBUG - 2016-06-06 14:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:09:03 --> Input Class Initialized
INFO - 2016-06-06 14:09:03 --> Language Class Initialized
INFO - 2016-06-06 14:09:03 --> Loader Class Initialized
INFO - 2016-06-06 14:09:03 --> Helper loaded: form_helper
INFO - 2016-06-06 14:09:03 --> Database Driver Class Initialized
INFO - 2016-06-06 14:09:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:09:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:09:03 --> Email Class Initialized
INFO - 2016-06-06 14:09:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:09:03 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:09:03 --> Helper loaded: language_helper
INFO - 2016-06-06 14:09:03 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:09:03 --> Model Class Initialized
INFO - 2016-06-06 14:09:03 --> Helper loaded: date_helper
INFO - 2016-06-06 14:09:03 --> Controller Class Initialized
INFO - 2016-06-06 14:09:03 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:09:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:09:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:09:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:09:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:09:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:09:03 --> Model Class Initialized
INFO - 2016-06-06 14:09:03 --> Form Validation Class Initialized
INFO - 2016-06-06 14:09:28 --> Config Class Initialized
INFO - 2016-06-06 14:09:28 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:09:28 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:09:28 --> Utf8 Class Initialized
INFO - 2016-06-06 14:09:28 --> URI Class Initialized
INFO - 2016-06-06 14:09:28 --> Router Class Initialized
INFO - 2016-06-06 14:09:28 --> Output Class Initialized
INFO - 2016-06-06 14:09:28 --> Security Class Initialized
DEBUG - 2016-06-06 14:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:09:28 --> Input Class Initialized
INFO - 2016-06-06 14:09:28 --> Language Class Initialized
INFO - 2016-06-06 14:09:28 --> Loader Class Initialized
INFO - 2016-06-06 14:09:28 --> Helper loaded: form_helper
INFO - 2016-06-06 14:09:28 --> Database Driver Class Initialized
INFO - 2016-06-06 14:09:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:09:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:09:28 --> Email Class Initialized
INFO - 2016-06-06 14:09:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:09:28 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:09:28 --> Helper loaded: language_helper
INFO - 2016-06-06 14:09:28 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:09:28 --> Model Class Initialized
INFO - 2016-06-06 14:09:28 --> Helper loaded: date_helper
INFO - 2016-06-06 14:09:28 --> Controller Class Initialized
INFO - 2016-06-06 14:09:28 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:09:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:09:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:09:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:09:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:09:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:09:28 --> Model Class Initialized
INFO - 2016-06-06 14:09:28 --> Form Validation Class Initialized
INFO - 2016-06-06 14:30:20 --> Config Class Initialized
INFO - 2016-06-06 14:30:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:30:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:30:20 --> Utf8 Class Initialized
INFO - 2016-06-06 14:30:20 --> URI Class Initialized
INFO - 2016-06-06 14:30:20 --> Router Class Initialized
INFO - 2016-06-06 14:30:20 --> Output Class Initialized
INFO - 2016-06-06 14:30:20 --> Security Class Initialized
DEBUG - 2016-06-06 14:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:30:20 --> Input Class Initialized
INFO - 2016-06-06 14:30:20 --> Language Class Initialized
INFO - 2016-06-06 14:30:20 --> Loader Class Initialized
INFO - 2016-06-06 14:30:20 --> Helper loaded: form_helper
INFO - 2016-06-06 14:30:20 --> Database Driver Class Initialized
INFO - 2016-06-06 14:30:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:30:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:30:20 --> Email Class Initialized
INFO - 2016-06-06 14:30:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:30:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:30:20 --> Helper loaded: language_helper
INFO - 2016-06-06 14:30:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:30:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:30:20 --> Model Class Initialized
INFO - 2016-06-06 14:30:20 --> Helper loaded: date_helper
INFO - 2016-06-06 14:30:20 --> Controller Class Initialized
INFO - 2016-06-06 14:30:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:30:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:30:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:30:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:30:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:30:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:30:20 --> Model Class Initialized
INFO - 2016-06-06 14:30:20 --> Form Validation Class Initialized
INFO - 2016-06-06 14:36:15 --> Config Class Initialized
INFO - 2016-06-06 14:36:15 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:36:15 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:36:15 --> Utf8 Class Initialized
INFO - 2016-06-06 14:36:15 --> URI Class Initialized
INFO - 2016-06-06 14:36:15 --> Router Class Initialized
INFO - 2016-06-06 14:36:15 --> Output Class Initialized
INFO - 2016-06-06 14:36:15 --> Security Class Initialized
DEBUG - 2016-06-06 14:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:36:15 --> Input Class Initialized
INFO - 2016-06-06 14:36:15 --> Language Class Initialized
INFO - 2016-06-06 14:36:15 --> Loader Class Initialized
INFO - 2016-06-06 14:36:15 --> Helper loaded: form_helper
INFO - 2016-06-06 14:36:15 --> Database Driver Class Initialized
INFO - 2016-06-06 14:36:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:36:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:36:15 --> Email Class Initialized
INFO - 2016-06-06 14:36:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:36:15 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:36:15 --> Helper loaded: language_helper
INFO - 2016-06-06 14:36:15 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:36:15 --> Model Class Initialized
INFO - 2016-06-06 14:36:15 --> Helper loaded: date_helper
INFO - 2016-06-06 14:36:15 --> Controller Class Initialized
INFO - 2016-06-06 14:36:15 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:36:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:36:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:36:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:36:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:36:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:36:15 --> Model Class Initialized
INFO - 2016-06-06 14:36:15 --> Form Validation Class Initialized
INFO - 2016-06-06 14:37:51 --> Config Class Initialized
INFO - 2016-06-06 14:37:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:37:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:37:51 --> Utf8 Class Initialized
INFO - 2016-06-06 14:37:51 --> URI Class Initialized
INFO - 2016-06-06 14:37:51 --> Router Class Initialized
INFO - 2016-06-06 14:37:51 --> Output Class Initialized
INFO - 2016-06-06 14:37:51 --> Security Class Initialized
DEBUG - 2016-06-06 14:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:37:51 --> Input Class Initialized
INFO - 2016-06-06 14:37:51 --> Language Class Initialized
INFO - 2016-06-06 14:37:51 --> Loader Class Initialized
INFO - 2016-06-06 14:37:51 --> Helper loaded: form_helper
INFO - 2016-06-06 14:37:51 --> Database Driver Class Initialized
INFO - 2016-06-06 14:37:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:37:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:37:51 --> Email Class Initialized
INFO - 2016-06-06 14:37:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:37:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:37:51 --> Helper loaded: language_helper
INFO - 2016-06-06 14:37:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:37:51 --> Model Class Initialized
INFO - 2016-06-06 14:37:51 --> Helper loaded: date_helper
INFO - 2016-06-06 14:37:51 --> Controller Class Initialized
INFO - 2016-06-06 14:37:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:37:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:37:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:37:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:37:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:37:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:37:51 --> Model Class Initialized
INFO - 2016-06-06 14:37:51 --> Form Validation Class Initialized
INFO - 2016-06-06 14:39:39 --> Config Class Initialized
INFO - 2016-06-06 14:39:39 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:39:39 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:39:39 --> Utf8 Class Initialized
INFO - 2016-06-06 14:39:39 --> URI Class Initialized
INFO - 2016-06-06 14:39:39 --> Router Class Initialized
INFO - 2016-06-06 14:39:39 --> Output Class Initialized
INFO - 2016-06-06 14:39:39 --> Security Class Initialized
DEBUG - 2016-06-06 14:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:39:39 --> Input Class Initialized
INFO - 2016-06-06 14:39:39 --> Language Class Initialized
INFO - 2016-06-06 14:39:39 --> Loader Class Initialized
INFO - 2016-06-06 14:39:39 --> Helper loaded: form_helper
INFO - 2016-06-06 14:39:39 --> Database Driver Class Initialized
INFO - 2016-06-06 14:39:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:39:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:39:39 --> Email Class Initialized
INFO - 2016-06-06 14:39:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:39:39 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:39:39 --> Helper loaded: language_helper
INFO - 2016-06-06 14:39:39 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:39:39 --> Model Class Initialized
INFO - 2016-06-06 14:39:39 --> Helper loaded: date_helper
INFO - 2016-06-06 14:39:39 --> Controller Class Initialized
INFO - 2016-06-06 14:39:39 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:39:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:39:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:39:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:39:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:39:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:39:39 --> Model Class Initialized
INFO - 2016-06-06 14:39:39 --> Form Validation Class Initialized
ERROR - 2016-06-06 14:39:39 --> Severity: Warning --> array_combine() expects parameter 2 to be array, object given /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
ERROR - 2016-06-06 14:39:39 --> Severity: Warning --> array_combine() expects parameter 2 to be array, object given /home/demis/www/platformadiabet/application/controllers/Diabet.php 370
INFO - 2016-06-06 14:40:01 --> Config Class Initialized
INFO - 2016-06-06 14:40:01 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:40:01 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:40:01 --> Utf8 Class Initialized
INFO - 2016-06-06 14:40:01 --> URI Class Initialized
INFO - 2016-06-06 14:40:01 --> Router Class Initialized
INFO - 2016-06-06 14:40:01 --> Output Class Initialized
INFO - 2016-06-06 14:40:01 --> Security Class Initialized
DEBUG - 2016-06-06 14:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:40:01 --> Input Class Initialized
INFO - 2016-06-06 14:40:01 --> Language Class Initialized
INFO - 2016-06-06 14:40:01 --> Loader Class Initialized
INFO - 2016-06-06 14:40:01 --> Helper loaded: form_helper
INFO - 2016-06-06 14:40:01 --> Database Driver Class Initialized
INFO - 2016-06-06 14:40:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:40:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:40:01 --> Email Class Initialized
INFO - 2016-06-06 14:40:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:40:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:40:01 --> Helper loaded: language_helper
INFO - 2016-06-06 14:40:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:40:01 --> Model Class Initialized
INFO - 2016-06-06 14:40:01 --> Helper loaded: date_helper
INFO - 2016-06-06 14:40:01 --> Controller Class Initialized
INFO - 2016-06-06 14:40:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:40:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:40:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:40:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:40:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:40:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:40:01 --> Model Class Initialized
INFO - 2016-06-06 14:40:01 --> Form Validation Class Initialized
INFO - 2016-06-06 14:40:17 --> Config Class Initialized
INFO - 2016-06-06 14:40:17 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:40:17 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:40:17 --> Utf8 Class Initialized
INFO - 2016-06-06 14:40:17 --> URI Class Initialized
INFO - 2016-06-06 14:40:17 --> Router Class Initialized
INFO - 2016-06-06 14:40:17 --> Output Class Initialized
INFO - 2016-06-06 14:40:17 --> Security Class Initialized
DEBUG - 2016-06-06 14:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:40:17 --> Input Class Initialized
INFO - 2016-06-06 14:40:17 --> Language Class Initialized
INFO - 2016-06-06 14:40:17 --> Loader Class Initialized
INFO - 2016-06-06 14:40:17 --> Helper loaded: form_helper
INFO - 2016-06-06 14:40:17 --> Database Driver Class Initialized
INFO - 2016-06-06 14:40:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:40:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:40:17 --> Email Class Initialized
INFO - 2016-06-06 14:40:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:40:17 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:40:17 --> Helper loaded: language_helper
INFO - 2016-06-06 14:40:17 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:40:17 --> Model Class Initialized
INFO - 2016-06-06 14:40:17 --> Helper loaded: date_helper
INFO - 2016-06-06 14:40:17 --> Controller Class Initialized
INFO - 2016-06-06 14:40:17 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:40:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:40:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:40:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:40:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:40:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:40:17 --> Model Class Initialized
INFO - 2016-06-06 14:40:17 --> Form Validation Class Initialized
INFO - 2016-06-06 14:40:27 --> Config Class Initialized
INFO - 2016-06-06 14:40:27 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:40:27 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:40:27 --> Utf8 Class Initialized
INFO - 2016-06-06 14:40:27 --> URI Class Initialized
INFO - 2016-06-06 14:40:27 --> Router Class Initialized
INFO - 2016-06-06 14:40:27 --> Output Class Initialized
INFO - 2016-06-06 14:40:27 --> Security Class Initialized
DEBUG - 2016-06-06 14:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:40:27 --> Input Class Initialized
INFO - 2016-06-06 14:40:27 --> Language Class Initialized
INFO - 2016-06-06 14:40:27 --> Loader Class Initialized
INFO - 2016-06-06 14:40:27 --> Helper loaded: form_helper
INFO - 2016-06-06 14:40:27 --> Database Driver Class Initialized
INFO - 2016-06-06 14:40:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:40:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:40:27 --> Email Class Initialized
INFO - 2016-06-06 14:40:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:40:27 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:40:27 --> Helper loaded: language_helper
INFO - 2016-06-06 14:40:27 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:40:27 --> Model Class Initialized
INFO - 2016-06-06 14:40:27 --> Helper loaded: date_helper
INFO - 2016-06-06 14:40:27 --> Controller Class Initialized
INFO - 2016-06-06 14:40:27 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:40:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:40:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:40:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:40:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:40:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:40:27 --> Model Class Initialized
INFO - 2016-06-06 14:40:27 --> Form Validation Class Initialized
INFO - 2016-06-06 14:40:39 --> Config Class Initialized
INFO - 2016-06-06 14:40:39 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:40:39 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:40:39 --> Utf8 Class Initialized
INFO - 2016-06-06 14:40:39 --> URI Class Initialized
INFO - 2016-06-06 14:40:39 --> Router Class Initialized
INFO - 2016-06-06 14:40:39 --> Output Class Initialized
INFO - 2016-06-06 14:40:39 --> Security Class Initialized
DEBUG - 2016-06-06 14:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:40:39 --> Input Class Initialized
INFO - 2016-06-06 14:40:39 --> Language Class Initialized
INFO - 2016-06-06 14:40:39 --> Loader Class Initialized
INFO - 2016-06-06 14:40:39 --> Helper loaded: form_helper
INFO - 2016-06-06 14:40:39 --> Database Driver Class Initialized
INFO - 2016-06-06 14:40:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:40:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:40:39 --> Email Class Initialized
INFO - 2016-06-06 14:40:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:40:39 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:40:39 --> Helper loaded: language_helper
INFO - 2016-06-06 14:40:39 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:40:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:40:39 --> Model Class Initialized
INFO - 2016-06-06 14:40:39 --> Helper loaded: date_helper
INFO - 2016-06-06 14:40:39 --> Controller Class Initialized
INFO - 2016-06-06 14:40:39 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:40:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:40:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:40:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:40:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:40:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:40:39 --> Model Class Initialized
INFO - 2016-06-06 14:40:39 --> Form Validation Class Initialized
ERROR - 2016-06-06 14:40:39 --> Severity: Warning --> array_combine(): Both parameters should have an equal number of elements /home/demis/www/platformadiabet/application/controllers/Diabet.php 371
ERROR - 2016-06-06 14:40:39 --> Severity: Warning --> array_combine(): Both parameters should have an equal number of elements /home/demis/www/platformadiabet/application/controllers/Diabet.php 371
INFO - 2016-06-06 14:40:55 --> Config Class Initialized
INFO - 2016-06-06 14:40:55 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:40:55 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:40:55 --> Utf8 Class Initialized
INFO - 2016-06-06 14:40:55 --> URI Class Initialized
INFO - 2016-06-06 14:40:55 --> Router Class Initialized
INFO - 2016-06-06 14:40:55 --> Output Class Initialized
INFO - 2016-06-06 14:40:55 --> Security Class Initialized
DEBUG - 2016-06-06 14:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:40:55 --> Input Class Initialized
INFO - 2016-06-06 14:40:55 --> Language Class Initialized
INFO - 2016-06-06 14:40:55 --> Loader Class Initialized
INFO - 2016-06-06 14:40:55 --> Helper loaded: form_helper
INFO - 2016-06-06 14:40:55 --> Database Driver Class Initialized
INFO - 2016-06-06 14:40:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:40:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:40:55 --> Email Class Initialized
INFO - 2016-06-06 14:40:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:40:55 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:40:55 --> Helper loaded: language_helper
INFO - 2016-06-06 14:40:55 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:40:55 --> Model Class Initialized
INFO - 2016-06-06 14:40:55 --> Helper loaded: date_helper
INFO - 2016-06-06 14:40:55 --> Controller Class Initialized
INFO - 2016-06-06 14:40:55 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:40:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:40:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:40:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:40:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:40:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:40:55 --> Model Class Initialized
INFO - 2016-06-06 14:40:55 --> Form Validation Class Initialized
INFO - 2016-06-06 14:43:48 --> Config Class Initialized
INFO - 2016-06-06 14:43:48 --> Hooks Class Initialized
DEBUG - 2016-06-06 14:43:48 --> UTF-8 Support Enabled
INFO - 2016-06-06 14:43:48 --> Utf8 Class Initialized
INFO - 2016-06-06 14:43:48 --> URI Class Initialized
INFO - 2016-06-06 14:43:48 --> Router Class Initialized
INFO - 2016-06-06 14:43:48 --> Output Class Initialized
INFO - 2016-06-06 14:43:48 --> Security Class Initialized
DEBUG - 2016-06-06 14:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 14:43:48 --> Input Class Initialized
INFO - 2016-06-06 14:43:48 --> Language Class Initialized
INFO - 2016-06-06 14:43:48 --> Loader Class Initialized
INFO - 2016-06-06 14:43:48 --> Helper loaded: form_helper
INFO - 2016-06-06 14:43:48 --> Database Driver Class Initialized
INFO - 2016-06-06 14:43:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 14:43:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 14:43:48 --> Email Class Initialized
INFO - 2016-06-06 14:43:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 14:43:48 --> Helper loaded: cookie_helper
INFO - 2016-06-06 14:43:48 --> Helper loaded: language_helper
INFO - 2016-06-06 14:43:48 --> Helper loaded: url_helper
DEBUG - 2016-06-06 14:43:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 14:43:48 --> Model Class Initialized
INFO - 2016-06-06 14:43:48 --> Helper loaded: date_helper
INFO - 2016-06-06 14:43:48 --> Controller Class Initialized
INFO - 2016-06-06 14:43:48 --> Helper loaded: languages_helper
INFO - 2016-06-06 14:43:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 14:43:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 14:43:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 14:43:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 14:43:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 14:43:48 --> Model Class Initialized
INFO - 2016-06-06 14:43:48 --> Form Validation Class Initialized
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 14:43:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 14:43:48 --> Could not find the language line "dashboard_glucose_value_label "
INFO - 2016-06-06 15:23:51 --> Config Class Initialized
INFO - 2016-06-06 15:23:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:23:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:23:51 --> Utf8 Class Initialized
INFO - 2016-06-06 15:23:51 --> URI Class Initialized
INFO - 2016-06-06 15:23:51 --> Router Class Initialized
INFO - 2016-06-06 15:23:51 --> Output Class Initialized
INFO - 2016-06-06 15:23:51 --> Security Class Initialized
DEBUG - 2016-06-06 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:23:51 --> Input Class Initialized
INFO - 2016-06-06 15:23:51 --> Language Class Initialized
INFO - 2016-06-06 15:23:51 --> Loader Class Initialized
INFO - 2016-06-06 15:23:51 --> Helper loaded: form_helper
INFO - 2016-06-06 15:23:51 --> Database Driver Class Initialized
INFO - 2016-06-06 15:23:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:23:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:23:51 --> Email Class Initialized
INFO - 2016-06-06 15:23:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:23:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:23:51 --> Helper loaded: language_helper
INFO - 2016-06-06 15:23:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:23:51 --> Model Class Initialized
INFO - 2016-06-06 15:23:51 --> Helper loaded: date_helper
INFO - 2016-06-06 15:23:51 --> Controller Class Initialized
INFO - 2016-06-06 15:23:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:23:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:23:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:23:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:23:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:23:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:23:51 --> Model Class Initialized
INFO - 2016-06-06 15:23:51 --> Form Validation Class Initialized
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_1 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 26
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_2 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 34
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_3 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 42
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_4 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 50
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_5 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 58
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_6 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 66
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_7 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_8 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 82
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_9 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 90
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_10 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 98
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_1 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 26
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_2 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 34
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_3 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 42
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_4 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 50
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_5 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 58
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_6 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 66
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_7 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_8 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 82
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_9 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 90
ERROR - 2016-06-06 15:23:51 --> Severity: Notice --> Undefined index: interval_10 /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 98
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:23:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:23:51 --> Final output sent to browser
DEBUG - 2016-06-06 15:23:51 --> Total execution time: 0.0415
INFO - 2016-06-06 15:23:54 --> Config Class Initialized
INFO - 2016-06-06 15:23:54 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:23:54 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:23:54 --> Utf8 Class Initialized
INFO - 2016-06-06 15:23:54 --> URI Class Initialized
INFO - 2016-06-06 15:23:54 --> Router Class Initialized
INFO - 2016-06-06 15:23:54 --> Output Class Initialized
INFO - 2016-06-06 15:23:54 --> Security Class Initialized
DEBUG - 2016-06-06 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:23:54 --> Input Class Initialized
INFO - 2016-06-06 15:23:54 --> Language Class Initialized
INFO - 2016-06-06 15:23:54 --> Loader Class Initialized
INFO - 2016-06-06 15:23:54 --> Helper loaded: form_helper
INFO - 2016-06-06 15:23:54 --> Database Driver Class Initialized
INFO - 2016-06-06 15:23:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:23:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:23:54 --> Email Class Initialized
INFO - 2016-06-06 15:23:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:23:54 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:23:54 --> Helper loaded: language_helper
INFO - 2016-06-06 15:23:54 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:23:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:23:54 --> Model Class Initialized
INFO - 2016-06-06 15:23:54 --> Helper loaded: date_helper
INFO - 2016-06-06 15:23:54 --> Controller Class Initialized
INFO - 2016-06-06 15:23:54 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:23:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:23:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:23:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:23:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:23:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:23:54 --> Model Class Initialized
INFO - 2016-06-06 15:23:54 --> Form Validation Class Initialized
INFO - 2016-06-06 15:23:54 --> Final output sent to browser
DEBUG - 2016-06-06 15:23:54 --> Total execution time: 0.0355
INFO - 2016-06-06 15:24:50 --> Config Class Initialized
INFO - 2016-06-06 15:24:50 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:24:50 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:24:50 --> Utf8 Class Initialized
INFO - 2016-06-06 15:24:50 --> URI Class Initialized
INFO - 2016-06-06 15:24:50 --> Router Class Initialized
INFO - 2016-06-06 15:24:50 --> Output Class Initialized
INFO - 2016-06-06 15:24:50 --> Security Class Initialized
DEBUG - 2016-06-06 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:24:50 --> Input Class Initialized
INFO - 2016-06-06 15:24:50 --> Language Class Initialized
INFO - 2016-06-06 15:24:50 --> Loader Class Initialized
INFO - 2016-06-06 15:24:50 --> Helper loaded: form_helper
INFO - 2016-06-06 15:24:50 --> Database Driver Class Initialized
INFO - 2016-06-06 15:24:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:24:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:24:50 --> Email Class Initialized
INFO - 2016-06-06 15:24:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:24:50 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:24:50 --> Helper loaded: language_helper
INFO - 2016-06-06 15:24:50 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:24:50 --> Model Class Initialized
INFO - 2016-06-06 15:24:50 --> Helper loaded: date_helper
INFO - 2016-06-06 15:24:50 --> Controller Class Initialized
INFO - 2016-06-06 15:24:50 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:24:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:24:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:24:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:24:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:24:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:24:50 --> Model Class Initialized
INFO - 2016-06-06 15:24:50 --> Form Validation Class Initialized
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:24:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:24:50 --> Final output sent to browser
DEBUG - 2016-06-06 15:24:50 --> Total execution time: 0.0348
INFO - 2016-06-06 15:24:51 --> Config Class Initialized
INFO - 2016-06-06 15:24:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:24:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:24:51 --> Utf8 Class Initialized
INFO - 2016-06-06 15:24:51 --> URI Class Initialized
INFO - 2016-06-06 15:24:51 --> Router Class Initialized
INFO - 2016-06-06 15:24:51 --> Output Class Initialized
INFO - 2016-06-06 15:24:51 --> Security Class Initialized
DEBUG - 2016-06-06 15:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:24:51 --> Input Class Initialized
INFO - 2016-06-06 15:24:51 --> Language Class Initialized
INFO - 2016-06-06 15:24:51 --> Loader Class Initialized
INFO - 2016-06-06 15:24:51 --> Helper loaded: form_helper
INFO - 2016-06-06 15:24:51 --> Database Driver Class Initialized
INFO - 2016-06-06 15:24:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:24:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:24:51 --> Email Class Initialized
INFO - 2016-06-06 15:24:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:24:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:24:51 --> Helper loaded: language_helper
INFO - 2016-06-06 15:24:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:24:51 --> Model Class Initialized
INFO - 2016-06-06 15:24:51 --> Helper loaded: date_helper
INFO - 2016-06-06 15:24:51 --> Controller Class Initialized
INFO - 2016-06-06 15:24:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:24:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:24:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:24:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:24:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:24:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:24:51 --> Model Class Initialized
INFO - 2016-06-06 15:24:51 --> Form Validation Class Initialized
INFO - 2016-06-06 15:24:51 --> Final output sent to browser
DEBUG - 2016-06-06 15:24:51 --> Total execution time: 0.0213
INFO - 2016-06-06 15:25:31 --> Config Class Initialized
INFO - 2016-06-06 15:25:31 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:25:31 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:25:31 --> Utf8 Class Initialized
INFO - 2016-06-06 15:25:31 --> URI Class Initialized
INFO - 2016-06-06 15:25:31 --> Router Class Initialized
INFO - 2016-06-06 15:25:31 --> Output Class Initialized
INFO - 2016-06-06 15:25:31 --> Security Class Initialized
DEBUG - 2016-06-06 15:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:25:31 --> Input Class Initialized
INFO - 2016-06-06 15:25:31 --> Language Class Initialized
INFO - 2016-06-06 15:25:31 --> Loader Class Initialized
INFO - 2016-06-06 15:25:31 --> Helper loaded: form_helper
INFO - 2016-06-06 15:25:31 --> Database Driver Class Initialized
INFO - 2016-06-06 15:25:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:25:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:25:31 --> Email Class Initialized
INFO - 2016-06-06 15:25:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:25:31 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:25:31 --> Helper loaded: language_helper
INFO - 2016-06-06 15:25:31 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:25:31 --> Model Class Initialized
INFO - 2016-06-06 15:25:31 --> Helper loaded: date_helper
INFO - 2016-06-06 15:25:31 --> Controller Class Initialized
INFO - 2016-06-06 15:25:31 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:25:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:25:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:25:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:25:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:25:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:25:31 --> Model Class Initialized
INFO - 2016-06-06 15:25:31 --> Form Validation Class Initialized
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:25:31 --> Final output sent to browser
DEBUG - 2016-06-06 15:25:31 --> Total execution time: 0.0288
INFO - 2016-06-06 15:25:33 --> Config Class Initialized
INFO - 2016-06-06 15:25:33 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:25:33 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:25:33 --> Utf8 Class Initialized
INFO - 2016-06-06 15:25:33 --> URI Class Initialized
INFO - 2016-06-06 15:25:33 --> Router Class Initialized
INFO - 2016-06-06 15:25:33 --> Output Class Initialized
INFO - 2016-06-06 15:25:33 --> Security Class Initialized
DEBUG - 2016-06-06 15:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:25:33 --> Input Class Initialized
INFO - 2016-06-06 15:25:33 --> Language Class Initialized
INFO - 2016-06-06 15:25:33 --> Loader Class Initialized
INFO - 2016-06-06 15:25:33 --> Helper loaded: form_helper
INFO - 2016-06-06 15:25:33 --> Database Driver Class Initialized
INFO - 2016-06-06 15:25:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:25:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:25:33 --> Email Class Initialized
INFO - 2016-06-06 15:25:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:25:33 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:25:33 --> Helper loaded: language_helper
INFO - 2016-06-06 15:25:33 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:25:33 --> Model Class Initialized
INFO - 2016-06-06 15:25:33 --> Helper loaded: date_helper
INFO - 2016-06-06 15:25:33 --> Controller Class Initialized
INFO - 2016-06-06 15:25:33 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:25:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:25:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:25:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:25:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:25:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:25:33 --> Model Class Initialized
INFO - 2016-06-06 15:25:33 --> Form Validation Class Initialized
INFO - 2016-06-06 15:25:33 --> Final output sent to browser
DEBUG - 2016-06-06 15:25:33 --> Total execution time: 0.0180
INFO - 2016-06-06 15:26:22 --> Config Class Initialized
INFO - 2016-06-06 15:26:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:26:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:26:22 --> Utf8 Class Initialized
INFO - 2016-06-06 15:26:22 --> URI Class Initialized
INFO - 2016-06-06 15:26:22 --> Router Class Initialized
INFO - 2016-06-06 15:26:22 --> Output Class Initialized
INFO - 2016-06-06 15:26:22 --> Security Class Initialized
DEBUG - 2016-06-06 15:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:26:22 --> Input Class Initialized
INFO - 2016-06-06 15:26:22 --> Language Class Initialized
INFO - 2016-06-06 15:26:22 --> Loader Class Initialized
INFO - 2016-06-06 15:26:22 --> Helper loaded: form_helper
INFO - 2016-06-06 15:26:22 --> Database Driver Class Initialized
INFO - 2016-06-06 15:26:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:26:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:26:22 --> Email Class Initialized
INFO - 2016-06-06 15:26:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:26:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:26:22 --> Helper loaded: language_helper
INFO - 2016-06-06 15:26:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:26:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:26:22 --> Model Class Initialized
INFO - 2016-06-06 15:26:22 --> Helper loaded: date_helper
INFO - 2016-06-06 15:26:22 --> Controller Class Initialized
INFO - 2016-06-06 15:26:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:26:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:26:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:26:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:26:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:26:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:26:22 --> Model Class Initialized
INFO - 2016-06-06 15:26:22 --> Form Validation Class Initialized
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:26:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:26:22 --> Final output sent to browser
DEBUG - 2016-06-06 15:26:22 --> Total execution time: 0.0523
INFO - 2016-06-06 15:26:24 --> Config Class Initialized
INFO - 2016-06-06 15:26:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:26:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:26:24 --> Utf8 Class Initialized
INFO - 2016-06-06 15:26:24 --> URI Class Initialized
INFO - 2016-06-06 15:26:24 --> Router Class Initialized
INFO - 2016-06-06 15:26:24 --> Output Class Initialized
INFO - 2016-06-06 15:26:24 --> Security Class Initialized
DEBUG - 2016-06-06 15:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:26:24 --> Input Class Initialized
INFO - 2016-06-06 15:26:24 --> Language Class Initialized
INFO - 2016-06-06 15:26:24 --> Loader Class Initialized
INFO - 2016-06-06 15:26:24 --> Helper loaded: form_helper
INFO - 2016-06-06 15:26:24 --> Database Driver Class Initialized
INFO - 2016-06-06 15:26:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:26:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:26:24 --> Email Class Initialized
INFO - 2016-06-06 15:26:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:26:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:26:24 --> Helper loaded: language_helper
INFO - 2016-06-06 15:26:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:26:24 --> Model Class Initialized
INFO - 2016-06-06 15:26:24 --> Helper loaded: date_helper
INFO - 2016-06-06 15:26:24 --> Controller Class Initialized
INFO - 2016-06-06 15:26:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:26:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:26:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:26:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:26:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:26:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:26:24 --> Model Class Initialized
INFO - 2016-06-06 15:26:24 --> Form Validation Class Initialized
INFO - 2016-06-06 15:26:24 --> Final output sent to browser
DEBUG - 2016-06-06 15:26:24 --> Total execution time: 0.0143
INFO - 2016-06-06 15:27:12 --> Config Class Initialized
INFO - 2016-06-06 15:27:12 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:27:12 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:27:12 --> Utf8 Class Initialized
INFO - 2016-06-06 15:27:12 --> URI Class Initialized
INFO - 2016-06-06 15:27:12 --> Router Class Initialized
INFO - 2016-06-06 15:27:12 --> Output Class Initialized
INFO - 2016-06-06 15:27:12 --> Security Class Initialized
DEBUG - 2016-06-06 15:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:27:12 --> Input Class Initialized
INFO - 2016-06-06 15:27:12 --> Language Class Initialized
INFO - 2016-06-06 15:27:12 --> Loader Class Initialized
INFO - 2016-06-06 15:27:12 --> Helper loaded: form_helper
INFO - 2016-06-06 15:27:12 --> Database Driver Class Initialized
INFO - 2016-06-06 15:27:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:27:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:27:12 --> Email Class Initialized
INFO - 2016-06-06 15:27:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:27:12 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:27:12 --> Helper loaded: language_helper
INFO - 2016-06-06 15:27:12 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:27:12 --> Model Class Initialized
INFO - 2016-06-06 15:27:12 --> Helper loaded: date_helper
INFO - 2016-06-06 15:27:12 --> Controller Class Initialized
INFO - 2016-06-06 15:27:12 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:27:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:27:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:27:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:27:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:27:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:27:12 --> Model Class Initialized
INFO - 2016-06-06 15:27:12 --> Form Validation Class Initialized
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:27:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:27:12 --> Final output sent to browser
DEBUG - 2016-06-06 15:27:12 --> Total execution time: 0.0360
INFO - 2016-06-06 15:27:14 --> Config Class Initialized
INFO - 2016-06-06 15:27:14 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:27:14 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:27:14 --> Utf8 Class Initialized
INFO - 2016-06-06 15:27:14 --> URI Class Initialized
INFO - 2016-06-06 15:27:14 --> Router Class Initialized
INFO - 2016-06-06 15:27:14 --> Output Class Initialized
INFO - 2016-06-06 15:27:14 --> Security Class Initialized
DEBUG - 2016-06-06 15:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:27:14 --> Input Class Initialized
INFO - 2016-06-06 15:27:14 --> Language Class Initialized
INFO - 2016-06-06 15:27:14 --> Loader Class Initialized
INFO - 2016-06-06 15:27:14 --> Helper loaded: form_helper
INFO - 2016-06-06 15:27:14 --> Database Driver Class Initialized
INFO - 2016-06-06 15:27:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:27:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:27:14 --> Email Class Initialized
INFO - 2016-06-06 15:27:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:27:14 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:27:14 --> Helper loaded: language_helper
INFO - 2016-06-06 15:27:14 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:27:14 --> Model Class Initialized
INFO - 2016-06-06 15:27:14 --> Helper loaded: date_helper
INFO - 2016-06-06 15:27:14 --> Controller Class Initialized
INFO - 2016-06-06 15:27:14 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:27:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:27:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:27:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:27:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:27:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:27:14 --> Model Class Initialized
INFO - 2016-06-06 15:27:14 --> Form Validation Class Initialized
INFO - 2016-06-06 15:27:14 --> Final output sent to browser
DEBUG - 2016-06-06 15:27:14 --> Total execution time: 0.0144
INFO - 2016-06-06 15:28:32 --> Config Class Initialized
INFO - 2016-06-06 15:28:32 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:28:32 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:28:32 --> Utf8 Class Initialized
INFO - 2016-06-06 15:28:32 --> URI Class Initialized
INFO - 2016-06-06 15:28:32 --> Router Class Initialized
INFO - 2016-06-06 15:28:32 --> Output Class Initialized
INFO - 2016-06-06 15:28:32 --> Security Class Initialized
DEBUG - 2016-06-06 15:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:28:32 --> Input Class Initialized
INFO - 2016-06-06 15:28:32 --> Language Class Initialized
INFO - 2016-06-06 15:28:32 --> Loader Class Initialized
INFO - 2016-06-06 15:28:32 --> Helper loaded: form_helper
INFO - 2016-06-06 15:28:32 --> Database Driver Class Initialized
INFO - 2016-06-06 15:28:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:28:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:28:32 --> Email Class Initialized
INFO - 2016-06-06 15:28:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:28:32 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:28:32 --> Helper loaded: language_helper
INFO - 2016-06-06 15:28:32 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:28:32 --> Model Class Initialized
INFO - 2016-06-06 15:28:32 --> Helper loaded: date_helper
INFO - 2016-06-06 15:28:32 --> Controller Class Initialized
INFO - 2016-06-06 15:28:32 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:28:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:28:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:28:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:28:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:28:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:28:32 --> Model Class Initialized
INFO - 2016-06-06 15:28:32 --> Form Validation Class Initialized
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:28:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:28:32 --> Final output sent to browser
DEBUG - 2016-06-06 15:28:32 --> Total execution time: 0.0320
INFO - 2016-06-06 15:28:34 --> Config Class Initialized
INFO - 2016-06-06 15:28:34 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:28:34 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:28:34 --> Utf8 Class Initialized
INFO - 2016-06-06 15:28:34 --> URI Class Initialized
INFO - 2016-06-06 15:28:34 --> Router Class Initialized
INFO - 2016-06-06 15:28:34 --> Output Class Initialized
INFO - 2016-06-06 15:28:34 --> Security Class Initialized
DEBUG - 2016-06-06 15:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:28:34 --> Input Class Initialized
INFO - 2016-06-06 15:28:34 --> Language Class Initialized
INFO - 2016-06-06 15:28:34 --> Loader Class Initialized
INFO - 2016-06-06 15:28:34 --> Helper loaded: form_helper
INFO - 2016-06-06 15:28:34 --> Database Driver Class Initialized
INFO - 2016-06-06 15:28:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:28:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:28:34 --> Email Class Initialized
INFO - 2016-06-06 15:28:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:28:34 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:28:34 --> Helper loaded: language_helper
INFO - 2016-06-06 15:28:34 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:28:34 --> Model Class Initialized
INFO - 2016-06-06 15:28:34 --> Helper loaded: date_helper
INFO - 2016-06-06 15:28:34 --> Controller Class Initialized
INFO - 2016-06-06 15:28:34 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:28:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:28:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:28:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:28:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:28:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:28:34 --> Model Class Initialized
INFO - 2016-06-06 15:28:34 --> Form Validation Class Initialized
INFO - 2016-06-06 15:28:34 --> Final output sent to browser
DEBUG - 2016-06-06 15:28:34 --> Total execution time: 0.0160
INFO - 2016-06-06 15:29:51 --> Config Class Initialized
INFO - 2016-06-06 15:29:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:29:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:29:51 --> Utf8 Class Initialized
INFO - 2016-06-06 15:29:51 --> URI Class Initialized
INFO - 2016-06-06 15:29:51 --> Router Class Initialized
INFO - 2016-06-06 15:29:51 --> Output Class Initialized
INFO - 2016-06-06 15:29:51 --> Security Class Initialized
DEBUG - 2016-06-06 15:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:29:51 --> Input Class Initialized
INFO - 2016-06-06 15:29:51 --> Language Class Initialized
INFO - 2016-06-06 15:29:51 --> Loader Class Initialized
INFO - 2016-06-06 15:29:51 --> Helper loaded: form_helper
INFO - 2016-06-06 15:29:51 --> Database Driver Class Initialized
INFO - 2016-06-06 15:29:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:29:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:29:51 --> Email Class Initialized
INFO - 2016-06-06 15:29:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:29:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:29:51 --> Helper loaded: language_helper
INFO - 2016-06-06 15:29:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:29:51 --> Model Class Initialized
INFO - 2016-06-06 15:29:51 --> Helper loaded: date_helper
INFO - 2016-06-06 15:29:51 --> Controller Class Initialized
INFO - 2016-06-06 15:29:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:29:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:29:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:29:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:29:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:29:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:29:51 --> Model Class Initialized
INFO - 2016-06-06 15:29:51 --> Form Validation Class Initialized
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:29:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:29:51 --> Final output sent to browser
DEBUG - 2016-06-06 15:29:51 --> Total execution time: 0.0341
INFO - 2016-06-06 15:29:53 --> Config Class Initialized
INFO - 2016-06-06 15:29:53 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:29:53 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:29:53 --> Utf8 Class Initialized
INFO - 2016-06-06 15:29:53 --> URI Class Initialized
INFO - 2016-06-06 15:29:53 --> Router Class Initialized
INFO - 2016-06-06 15:29:53 --> Output Class Initialized
INFO - 2016-06-06 15:29:53 --> Security Class Initialized
DEBUG - 2016-06-06 15:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:29:53 --> Input Class Initialized
INFO - 2016-06-06 15:29:53 --> Language Class Initialized
INFO - 2016-06-06 15:29:53 --> Loader Class Initialized
INFO - 2016-06-06 15:29:53 --> Helper loaded: form_helper
INFO - 2016-06-06 15:29:53 --> Database Driver Class Initialized
INFO - 2016-06-06 15:29:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:29:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:29:53 --> Email Class Initialized
INFO - 2016-06-06 15:29:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:29:53 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:29:53 --> Helper loaded: language_helper
INFO - 2016-06-06 15:29:53 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:29:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:29:53 --> Model Class Initialized
INFO - 2016-06-06 15:29:53 --> Helper loaded: date_helper
INFO - 2016-06-06 15:29:53 --> Controller Class Initialized
INFO - 2016-06-06 15:29:53 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:29:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:29:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:29:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:29:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:29:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:29:53 --> Model Class Initialized
INFO - 2016-06-06 15:29:53 --> Form Validation Class Initialized
INFO - 2016-06-06 15:29:53 --> Final output sent to browser
DEBUG - 2016-06-06 15:29:53 --> Total execution time: 0.0146
INFO - 2016-06-06 15:31:58 --> Config Class Initialized
INFO - 2016-06-06 15:31:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:31:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:31:58 --> Utf8 Class Initialized
INFO - 2016-06-06 15:31:58 --> URI Class Initialized
INFO - 2016-06-06 15:31:58 --> Router Class Initialized
INFO - 2016-06-06 15:31:58 --> Output Class Initialized
INFO - 2016-06-06 15:31:58 --> Security Class Initialized
DEBUG - 2016-06-06 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:31:58 --> Input Class Initialized
INFO - 2016-06-06 15:31:58 --> Language Class Initialized
INFO - 2016-06-06 15:31:58 --> Loader Class Initialized
INFO - 2016-06-06 15:31:58 --> Helper loaded: form_helper
INFO - 2016-06-06 15:31:58 --> Database Driver Class Initialized
INFO - 2016-06-06 15:31:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:31:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:31:58 --> Email Class Initialized
INFO - 2016-06-06 15:31:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:31:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:31:58 --> Helper loaded: language_helper
INFO - 2016-06-06 15:31:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:31:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:31:58 --> Model Class Initialized
INFO - 2016-06-06 15:31:58 --> Helper loaded: date_helper
INFO - 2016-06-06 15:31:58 --> Controller Class Initialized
INFO - 2016-06-06 15:31:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:31:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:31:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:31:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:31:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:31:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:31:58 --> Model Class Initialized
INFO - 2016-06-06 15:31:58 --> Form Validation Class Initialized
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:31:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:31:58 --> Final output sent to browser
DEBUG - 2016-06-06 15:31:58 --> Total execution time: 0.0587
INFO - 2016-06-06 15:32:00 --> Config Class Initialized
INFO - 2016-06-06 15:32:00 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:32:00 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:32:00 --> Utf8 Class Initialized
INFO - 2016-06-06 15:32:00 --> URI Class Initialized
INFO - 2016-06-06 15:32:00 --> Router Class Initialized
INFO - 2016-06-06 15:32:00 --> Output Class Initialized
INFO - 2016-06-06 15:32:00 --> Security Class Initialized
DEBUG - 2016-06-06 15:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:32:00 --> Input Class Initialized
INFO - 2016-06-06 15:32:00 --> Language Class Initialized
INFO - 2016-06-06 15:32:00 --> Loader Class Initialized
INFO - 2016-06-06 15:32:00 --> Helper loaded: form_helper
INFO - 2016-06-06 15:32:00 --> Database Driver Class Initialized
INFO - 2016-06-06 15:32:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:32:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:32:00 --> Email Class Initialized
INFO - 2016-06-06 15:32:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:32:00 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:32:00 --> Helper loaded: language_helper
INFO - 2016-06-06 15:32:00 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:32:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:32:00 --> Model Class Initialized
INFO - 2016-06-06 15:32:00 --> Helper loaded: date_helper
INFO - 2016-06-06 15:32:00 --> Controller Class Initialized
INFO - 2016-06-06 15:32:00 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:32:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:32:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:32:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:32:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:32:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:32:00 --> Model Class Initialized
INFO - 2016-06-06 15:32:00 --> Form Validation Class Initialized
INFO - 2016-06-06 15:32:00 --> Final output sent to browser
DEBUG - 2016-06-06 15:32:00 --> Total execution time: 0.0553
INFO - 2016-06-06 15:33:57 --> Config Class Initialized
INFO - 2016-06-06 15:33:57 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:33:57 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:33:57 --> Utf8 Class Initialized
INFO - 2016-06-06 15:33:57 --> URI Class Initialized
INFO - 2016-06-06 15:33:57 --> Router Class Initialized
INFO - 2016-06-06 15:33:57 --> Output Class Initialized
INFO - 2016-06-06 15:33:57 --> Security Class Initialized
DEBUG - 2016-06-06 15:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:33:57 --> Input Class Initialized
INFO - 2016-06-06 15:33:57 --> Language Class Initialized
INFO - 2016-06-06 15:33:57 --> Loader Class Initialized
INFO - 2016-06-06 15:33:57 --> Helper loaded: form_helper
INFO - 2016-06-06 15:33:57 --> Database Driver Class Initialized
INFO - 2016-06-06 15:33:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:33:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:33:57 --> Email Class Initialized
INFO - 2016-06-06 15:33:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:33:57 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:33:57 --> Helper loaded: language_helper
INFO - 2016-06-06 15:33:57 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:33:57 --> Model Class Initialized
INFO - 2016-06-06 15:33:57 --> Helper loaded: date_helper
INFO - 2016-06-06 15:33:57 --> Controller Class Initialized
INFO - 2016-06-06 15:33:57 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:33:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:33:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:33:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:33:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:33:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:33:57 --> Model Class Initialized
INFO - 2016-06-06 15:33:57 --> Form Validation Class Initialized
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:33:57 --> Final output sent to browser
DEBUG - 2016-06-06 15:33:57 --> Total execution time: 0.0285
INFO - 2016-06-06 15:34:01 --> Config Class Initialized
INFO - 2016-06-06 15:34:01 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:34:01 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:34:01 --> Utf8 Class Initialized
INFO - 2016-06-06 15:34:01 --> URI Class Initialized
INFO - 2016-06-06 15:34:01 --> Router Class Initialized
INFO - 2016-06-06 15:34:01 --> Output Class Initialized
INFO - 2016-06-06 15:34:01 --> Security Class Initialized
DEBUG - 2016-06-06 15:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:34:01 --> Input Class Initialized
INFO - 2016-06-06 15:34:01 --> Language Class Initialized
INFO - 2016-06-06 15:34:01 --> Loader Class Initialized
INFO - 2016-06-06 15:34:01 --> Helper loaded: form_helper
INFO - 2016-06-06 15:34:01 --> Database Driver Class Initialized
INFO - 2016-06-06 15:34:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:34:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:34:01 --> Email Class Initialized
INFO - 2016-06-06 15:34:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:34:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:34:01 --> Helper loaded: language_helper
INFO - 2016-06-06 15:34:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:34:01 --> Model Class Initialized
INFO - 2016-06-06 15:34:01 --> Helper loaded: date_helper
INFO - 2016-06-06 15:34:01 --> Controller Class Initialized
INFO - 2016-06-06 15:34:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:34:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:34:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:34:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:34:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:34:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:34:01 --> Model Class Initialized
INFO - 2016-06-06 15:34:01 --> Form Validation Class Initialized
INFO - 2016-06-06 15:34:01 --> Final output sent to browser
DEBUG - 2016-06-06 15:34:01 --> Total execution time: 0.0418
INFO - 2016-06-06 15:34:40 --> Config Class Initialized
INFO - 2016-06-06 15:34:40 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:34:40 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:34:40 --> Utf8 Class Initialized
INFO - 2016-06-06 15:34:40 --> URI Class Initialized
INFO - 2016-06-06 15:34:40 --> Router Class Initialized
INFO - 2016-06-06 15:34:40 --> Output Class Initialized
INFO - 2016-06-06 15:34:40 --> Security Class Initialized
DEBUG - 2016-06-06 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:34:40 --> Input Class Initialized
INFO - 2016-06-06 15:34:40 --> Language Class Initialized
INFO - 2016-06-06 15:34:40 --> Loader Class Initialized
INFO - 2016-06-06 15:34:40 --> Helper loaded: form_helper
INFO - 2016-06-06 15:34:40 --> Database Driver Class Initialized
INFO - 2016-06-06 15:34:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:34:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:34:40 --> Email Class Initialized
INFO - 2016-06-06 15:34:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:34:40 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:34:40 --> Helper loaded: language_helper
INFO - 2016-06-06 15:34:40 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:34:40 --> Model Class Initialized
INFO - 2016-06-06 15:34:40 --> Helper loaded: date_helper
INFO - 2016-06-06 15:34:40 --> Controller Class Initialized
INFO - 2016-06-06 15:34:40 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:34:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:34:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:34:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:34:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:34:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:34:40 --> Model Class Initialized
INFO - 2016-06-06 15:34:40 --> Form Validation Class Initialized
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:34:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:34:40 --> Final output sent to browser
DEBUG - 2016-06-06 15:34:40 --> Total execution time: 0.0616
INFO - 2016-06-06 15:34:42 --> Config Class Initialized
INFO - 2016-06-06 15:34:42 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:34:42 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:34:42 --> Utf8 Class Initialized
INFO - 2016-06-06 15:34:42 --> URI Class Initialized
INFO - 2016-06-06 15:34:42 --> Router Class Initialized
INFO - 2016-06-06 15:34:42 --> Output Class Initialized
INFO - 2016-06-06 15:34:42 --> Security Class Initialized
DEBUG - 2016-06-06 15:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:34:42 --> Input Class Initialized
INFO - 2016-06-06 15:34:42 --> Language Class Initialized
INFO - 2016-06-06 15:34:42 --> Loader Class Initialized
INFO - 2016-06-06 15:34:42 --> Helper loaded: form_helper
INFO - 2016-06-06 15:34:42 --> Database Driver Class Initialized
INFO - 2016-06-06 15:34:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:34:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:34:42 --> Email Class Initialized
INFO - 2016-06-06 15:34:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:34:42 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:34:42 --> Helper loaded: language_helper
INFO - 2016-06-06 15:34:42 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:34:42 --> Model Class Initialized
INFO - 2016-06-06 15:34:42 --> Helper loaded: date_helper
INFO - 2016-06-06 15:34:42 --> Controller Class Initialized
INFO - 2016-06-06 15:34:42 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:34:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:34:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:34:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:34:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:34:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:34:42 --> Model Class Initialized
INFO - 2016-06-06 15:34:42 --> Form Validation Class Initialized
INFO - 2016-06-06 15:34:42 --> Final output sent to browser
DEBUG - 2016-06-06 15:34:42 --> Total execution time: 0.0283
INFO - 2016-06-06 15:35:09 --> Config Class Initialized
INFO - 2016-06-06 15:35:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:35:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:35:09 --> Utf8 Class Initialized
INFO - 2016-06-06 15:35:09 --> URI Class Initialized
INFO - 2016-06-06 15:35:09 --> Router Class Initialized
INFO - 2016-06-06 15:35:09 --> Output Class Initialized
INFO - 2016-06-06 15:35:09 --> Security Class Initialized
DEBUG - 2016-06-06 15:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:35:09 --> Input Class Initialized
INFO - 2016-06-06 15:35:09 --> Language Class Initialized
INFO - 2016-06-06 15:35:09 --> Loader Class Initialized
INFO - 2016-06-06 15:35:09 --> Helper loaded: form_helper
INFO - 2016-06-06 15:35:09 --> Database Driver Class Initialized
INFO - 2016-06-06 15:35:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:35:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:35:09 --> Email Class Initialized
INFO - 2016-06-06 15:35:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:35:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:35:09 --> Helper loaded: language_helper
INFO - 2016-06-06 15:35:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:35:09 --> Model Class Initialized
INFO - 2016-06-06 15:35:09 --> Helper loaded: date_helper
INFO - 2016-06-06 15:35:09 --> Controller Class Initialized
INFO - 2016-06-06 15:35:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:35:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:35:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:35:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:35:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:35:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:35:09 --> Model Class Initialized
INFO - 2016-06-06 15:35:09 --> Form Validation Class Initialized
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:35:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:35:09 --> Final output sent to browser
DEBUG - 2016-06-06 15:35:09 --> Total execution time: 0.0254
INFO - 2016-06-06 15:35:11 --> Config Class Initialized
INFO - 2016-06-06 15:35:11 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:35:11 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:35:11 --> Utf8 Class Initialized
INFO - 2016-06-06 15:35:11 --> URI Class Initialized
INFO - 2016-06-06 15:35:11 --> Router Class Initialized
INFO - 2016-06-06 15:35:11 --> Output Class Initialized
INFO - 2016-06-06 15:35:11 --> Security Class Initialized
DEBUG - 2016-06-06 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:35:11 --> Input Class Initialized
INFO - 2016-06-06 15:35:11 --> Language Class Initialized
INFO - 2016-06-06 15:35:11 --> Loader Class Initialized
INFO - 2016-06-06 15:35:11 --> Helper loaded: form_helper
INFO - 2016-06-06 15:35:11 --> Database Driver Class Initialized
INFO - 2016-06-06 15:35:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:35:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:35:11 --> Email Class Initialized
INFO - 2016-06-06 15:35:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:35:11 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:35:11 --> Helper loaded: language_helper
INFO - 2016-06-06 15:35:11 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:35:11 --> Model Class Initialized
INFO - 2016-06-06 15:35:11 --> Helper loaded: date_helper
INFO - 2016-06-06 15:35:11 --> Controller Class Initialized
INFO - 2016-06-06 15:35:11 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:35:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:35:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:35:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:35:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:35:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:35:11 --> Model Class Initialized
INFO - 2016-06-06 15:35:11 --> Form Validation Class Initialized
INFO - 2016-06-06 15:35:11 --> Final output sent to browser
DEBUG - 2016-06-06 15:35:11 --> Total execution time: 0.0146
INFO - 2016-06-06 15:39:36 --> Config Class Initialized
INFO - 2016-06-06 15:39:36 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:39:36 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:39:36 --> Utf8 Class Initialized
INFO - 2016-06-06 15:39:36 --> URI Class Initialized
INFO - 2016-06-06 15:39:36 --> Router Class Initialized
INFO - 2016-06-06 15:39:36 --> Output Class Initialized
INFO - 2016-06-06 15:39:36 --> Security Class Initialized
DEBUG - 2016-06-06 15:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:39:36 --> Input Class Initialized
INFO - 2016-06-06 15:39:36 --> Language Class Initialized
INFO - 2016-06-06 15:39:36 --> Loader Class Initialized
INFO - 2016-06-06 15:39:36 --> Helper loaded: form_helper
INFO - 2016-06-06 15:39:36 --> Database Driver Class Initialized
INFO - 2016-06-06 15:39:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:39:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:39:36 --> Email Class Initialized
INFO - 2016-06-06 15:39:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:39:36 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:39:36 --> Helper loaded: language_helper
INFO - 2016-06-06 15:39:36 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:39:36 --> Model Class Initialized
INFO - 2016-06-06 15:39:36 --> Helper loaded: date_helper
INFO - 2016-06-06 15:39:36 --> Controller Class Initialized
INFO - 2016-06-06 15:39:36 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:39:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:39:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:39:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:39:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:39:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:39:36 --> Model Class Initialized
INFO - 2016-06-06 15:39:36 --> Form Validation Class Initialized
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:39:36 --> Final output sent to browser
DEBUG - 2016-06-06 15:39:36 --> Total execution time: 0.0866
INFO - 2016-06-06 15:39:39 --> Config Class Initialized
INFO - 2016-06-06 15:39:39 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:39:39 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:39:39 --> Utf8 Class Initialized
INFO - 2016-06-06 15:39:39 --> URI Class Initialized
INFO - 2016-06-06 15:39:39 --> Router Class Initialized
INFO - 2016-06-06 15:39:39 --> Output Class Initialized
INFO - 2016-06-06 15:39:39 --> Security Class Initialized
DEBUG - 2016-06-06 15:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:39:39 --> Input Class Initialized
INFO - 2016-06-06 15:39:39 --> Language Class Initialized
INFO - 2016-06-06 15:39:39 --> Loader Class Initialized
INFO - 2016-06-06 15:39:39 --> Helper loaded: form_helper
INFO - 2016-06-06 15:39:39 --> Database Driver Class Initialized
INFO - 2016-06-06 15:39:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:39:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:39:39 --> Email Class Initialized
INFO - 2016-06-06 15:39:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:39:39 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:39:39 --> Helper loaded: language_helper
INFO - 2016-06-06 15:39:39 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:39:39 --> Model Class Initialized
INFO - 2016-06-06 15:39:39 --> Helper loaded: date_helper
INFO - 2016-06-06 15:39:39 --> Controller Class Initialized
INFO - 2016-06-06 15:39:39 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:39:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:39:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:39:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:39:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:39:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:39:39 --> Model Class Initialized
INFO - 2016-06-06 15:39:39 --> Form Validation Class Initialized
INFO - 2016-06-06 15:39:39 --> Final output sent to browser
DEBUG - 2016-06-06 15:39:39 --> Total execution time: 0.0135
INFO - 2016-06-06 15:40:08 --> Config Class Initialized
INFO - 2016-06-06 15:40:08 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:40:08 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:40:08 --> Utf8 Class Initialized
INFO - 2016-06-06 15:40:08 --> URI Class Initialized
INFO - 2016-06-06 15:40:08 --> Router Class Initialized
INFO - 2016-06-06 15:40:08 --> Output Class Initialized
INFO - 2016-06-06 15:40:08 --> Security Class Initialized
DEBUG - 2016-06-06 15:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:40:08 --> Input Class Initialized
INFO - 2016-06-06 15:40:08 --> Language Class Initialized
INFO - 2016-06-06 15:40:08 --> Loader Class Initialized
INFO - 2016-06-06 15:40:08 --> Helper loaded: form_helper
INFO - 2016-06-06 15:40:08 --> Database Driver Class Initialized
INFO - 2016-06-06 15:40:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:40:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:40:08 --> Email Class Initialized
INFO - 2016-06-06 15:40:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:40:08 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:40:08 --> Helper loaded: language_helper
INFO - 2016-06-06 15:40:08 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:40:08 --> Model Class Initialized
INFO - 2016-06-06 15:40:08 --> Helper loaded: date_helper
INFO - 2016-06-06 15:40:08 --> Controller Class Initialized
INFO - 2016-06-06 15:40:08 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:40:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:40:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:40:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:40:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:40:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:40:08 --> Model Class Initialized
INFO - 2016-06-06 15:40:08 --> Form Validation Class Initialized
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:40:08 --> Final output sent to browser
DEBUG - 2016-06-06 15:40:08 --> Total execution time: 0.0307
INFO - 2016-06-06 15:40:10 --> Config Class Initialized
INFO - 2016-06-06 15:40:10 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:40:10 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:40:10 --> Utf8 Class Initialized
INFO - 2016-06-06 15:40:10 --> URI Class Initialized
INFO - 2016-06-06 15:40:10 --> Router Class Initialized
INFO - 2016-06-06 15:40:10 --> Output Class Initialized
INFO - 2016-06-06 15:40:10 --> Security Class Initialized
DEBUG - 2016-06-06 15:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:40:10 --> Input Class Initialized
INFO - 2016-06-06 15:40:10 --> Language Class Initialized
INFO - 2016-06-06 15:40:10 --> Loader Class Initialized
INFO - 2016-06-06 15:40:10 --> Helper loaded: form_helper
INFO - 2016-06-06 15:40:10 --> Database Driver Class Initialized
INFO - 2016-06-06 15:40:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:40:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:40:10 --> Email Class Initialized
INFO - 2016-06-06 15:40:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:40:10 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:40:10 --> Helper loaded: language_helper
INFO - 2016-06-06 15:40:10 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:40:10 --> Model Class Initialized
INFO - 2016-06-06 15:40:10 --> Helper loaded: date_helper
INFO - 2016-06-06 15:40:10 --> Controller Class Initialized
INFO - 2016-06-06 15:40:10 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:40:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:40:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:40:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:40:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:40:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:40:10 --> Model Class Initialized
INFO - 2016-06-06 15:40:10 --> Form Validation Class Initialized
INFO - 2016-06-06 15:40:10 --> Final output sent to browser
DEBUG - 2016-06-06 15:40:10 --> Total execution time: 0.0133
INFO - 2016-06-06 15:40:47 --> Config Class Initialized
INFO - 2016-06-06 15:40:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:40:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:40:47 --> Utf8 Class Initialized
INFO - 2016-06-06 15:40:47 --> URI Class Initialized
INFO - 2016-06-06 15:40:47 --> Router Class Initialized
INFO - 2016-06-06 15:40:47 --> Output Class Initialized
INFO - 2016-06-06 15:40:47 --> Security Class Initialized
DEBUG - 2016-06-06 15:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:40:47 --> Input Class Initialized
INFO - 2016-06-06 15:40:47 --> Language Class Initialized
INFO - 2016-06-06 15:40:47 --> Loader Class Initialized
INFO - 2016-06-06 15:40:47 --> Helper loaded: form_helper
INFO - 2016-06-06 15:40:47 --> Database Driver Class Initialized
INFO - 2016-06-06 15:40:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:40:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:40:47 --> Email Class Initialized
INFO - 2016-06-06 15:40:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:40:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:40:47 --> Helper loaded: language_helper
INFO - 2016-06-06 15:40:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:40:47 --> Model Class Initialized
INFO - 2016-06-06 15:40:47 --> Helper loaded: date_helper
INFO - 2016-06-06 15:40:47 --> Controller Class Initialized
INFO - 2016-06-06 15:40:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:40:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:40:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:40:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:40:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:40:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:40:47 --> Model Class Initialized
INFO - 2016-06-06 15:40:47 --> Form Validation Class Initialized
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:40:47 --> Final output sent to browser
DEBUG - 2016-06-06 15:40:47 --> Total execution time: 0.0313
INFO - 2016-06-06 15:40:51 --> Config Class Initialized
INFO - 2016-06-06 15:40:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:40:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:40:51 --> Utf8 Class Initialized
INFO - 2016-06-06 15:40:51 --> URI Class Initialized
INFO - 2016-06-06 15:40:51 --> Router Class Initialized
INFO - 2016-06-06 15:40:51 --> Output Class Initialized
INFO - 2016-06-06 15:40:51 --> Security Class Initialized
DEBUG - 2016-06-06 15:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:40:51 --> Input Class Initialized
INFO - 2016-06-06 15:40:51 --> Language Class Initialized
INFO - 2016-06-06 15:40:51 --> Loader Class Initialized
INFO - 2016-06-06 15:40:51 --> Helper loaded: form_helper
INFO - 2016-06-06 15:40:51 --> Database Driver Class Initialized
INFO - 2016-06-06 15:40:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:40:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:40:51 --> Email Class Initialized
INFO - 2016-06-06 15:40:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:40:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:40:51 --> Helper loaded: language_helper
INFO - 2016-06-06 15:40:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:40:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:40:51 --> Model Class Initialized
INFO - 2016-06-06 15:40:51 --> Helper loaded: date_helper
INFO - 2016-06-06 15:40:51 --> Controller Class Initialized
INFO - 2016-06-06 15:40:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:40:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:40:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:40:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:40:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:40:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:40:51 --> Model Class Initialized
INFO - 2016-06-06 15:40:51 --> Form Validation Class Initialized
INFO - 2016-06-06 15:40:51 --> Final output sent to browser
DEBUG - 2016-06-06 15:40:51 --> Total execution time: 0.0267
INFO - 2016-06-06 15:42:35 --> Config Class Initialized
INFO - 2016-06-06 15:42:35 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:42:35 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:42:35 --> Utf8 Class Initialized
INFO - 2016-06-06 15:42:35 --> URI Class Initialized
INFO - 2016-06-06 15:42:35 --> Router Class Initialized
INFO - 2016-06-06 15:42:35 --> Output Class Initialized
INFO - 2016-06-06 15:42:35 --> Security Class Initialized
DEBUG - 2016-06-06 15:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:42:35 --> Input Class Initialized
INFO - 2016-06-06 15:42:35 --> Language Class Initialized
INFO - 2016-06-06 15:42:35 --> Loader Class Initialized
INFO - 2016-06-06 15:42:35 --> Helper loaded: form_helper
INFO - 2016-06-06 15:42:35 --> Database Driver Class Initialized
INFO - 2016-06-06 15:42:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:42:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:42:35 --> Email Class Initialized
INFO - 2016-06-06 15:42:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:42:35 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:42:35 --> Helper loaded: language_helper
INFO - 2016-06-06 15:42:35 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:42:35 --> Model Class Initialized
INFO - 2016-06-06 15:42:35 --> Helper loaded: date_helper
INFO - 2016-06-06 15:42:35 --> Controller Class Initialized
INFO - 2016-06-06 15:42:35 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:42:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:42:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:42:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:42:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:42:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:42:35 --> Model Class Initialized
INFO - 2016-06-06 15:42:35 --> Form Validation Class Initialized
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:42:35 --> Final output sent to browser
DEBUG - 2016-06-06 15:42:35 --> Total execution time: 0.0444
INFO - 2016-06-06 15:42:37 --> Config Class Initialized
INFO - 2016-06-06 15:42:37 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:42:37 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:42:37 --> Utf8 Class Initialized
INFO - 2016-06-06 15:42:37 --> URI Class Initialized
INFO - 2016-06-06 15:42:37 --> Router Class Initialized
INFO - 2016-06-06 15:42:37 --> Output Class Initialized
INFO - 2016-06-06 15:42:37 --> Security Class Initialized
DEBUG - 2016-06-06 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:42:37 --> Input Class Initialized
INFO - 2016-06-06 15:42:37 --> Language Class Initialized
INFO - 2016-06-06 15:42:37 --> Loader Class Initialized
INFO - 2016-06-06 15:42:37 --> Helper loaded: form_helper
INFO - 2016-06-06 15:42:37 --> Database Driver Class Initialized
INFO - 2016-06-06 15:42:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:42:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:42:37 --> Email Class Initialized
INFO - 2016-06-06 15:42:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:42:37 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:42:37 --> Helper loaded: language_helper
INFO - 2016-06-06 15:42:37 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:42:37 --> Model Class Initialized
INFO - 2016-06-06 15:42:37 --> Helper loaded: date_helper
INFO - 2016-06-06 15:42:37 --> Controller Class Initialized
INFO - 2016-06-06 15:42:37 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:42:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:42:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:42:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:42:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:42:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:42:37 --> Model Class Initialized
INFO - 2016-06-06 15:42:37 --> Form Validation Class Initialized
INFO - 2016-06-06 15:42:37 --> Final output sent to browser
DEBUG - 2016-06-06 15:42:37 --> Total execution time: 0.0141
INFO - 2016-06-06 15:44:00 --> Config Class Initialized
INFO - 2016-06-06 15:44:00 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:44:00 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:44:00 --> Utf8 Class Initialized
INFO - 2016-06-06 15:44:00 --> URI Class Initialized
INFO - 2016-06-06 15:44:00 --> Router Class Initialized
INFO - 2016-06-06 15:44:00 --> Output Class Initialized
INFO - 2016-06-06 15:44:00 --> Security Class Initialized
DEBUG - 2016-06-06 15:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:44:00 --> Input Class Initialized
INFO - 2016-06-06 15:44:00 --> Language Class Initialized
INFO - 2016-06-06 15:44:00 --> Loader Class Initialized
INFO - 2016-06-06 15:44:00 --> Helper loaded: form_helper
INFO - 2016-06-06 15:44:00 --> Database Driver Class Initialized
INFO - 2016-06-06 15:44:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:44:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:44:00 --> Email Class Initialized
INFO - 2016-06-06 15:44:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:44:00 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:44:00 --> Helper loaded: language_helper
INFO - 2016-06-06 15:44:00 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:44:00 --> Model Class Initialized
INFO - 2016-06-06 15:44:00 --> Helper loaded: date_helper
INFO - 2016-06-06 15:44:00 --> Controller Class Initialized
INFO - 2016-06-06 15:44:00 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:44:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:44:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:44:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:44:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:44:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:44:00 --> Model Class Initialized
INFO - 2016-06-06 15:44:00 --> Form Validation Class Initialized
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:44:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:44:00 --> Final output sent to browser
DEBUG - 2016-06-06 15:44:00 --> Total execution time: 0.0308
INFO - 2016-06-06 15:44:03 --> Config Class Initialized
INFO - 2016-06-06 15:44:03 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:44:03 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:44:03 --> Utf8 Class Initialized
INFO - 2016-06-06 15:44:03 --> URI Class Initialized
INFO - 2016-06-06 15:44:03 --> Router Class Initialized
INFO - 2016-06-06 15:44:03 --> Output Class Initialized
INFO - 2016-06-06 15:44:03 --> Security Class Initialized
DEBUG - 2016-06-06 15:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:44:03 --> Input Class Initialized
INFO - 2016-06-06 15:44:03 --> Language Class Initialized
INFO - 2016-06-06 15:44:03 --> Loader Class Initialized
INFO - 2016-06-06 15:44:03 --> Helper loaded: form_helper
INFO - 2016-06-06 15:44:03 --> Database Driver Class Initialized
INFO - 2016-06-06 15:44:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:44:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:44:03 --> Email Class Initialized
INFO - 2016-06-06 15:44:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:44:03 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:44:03 --> Helper loaded: language_helper
INFO - 2016-06-06 15:44:03 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:44:03 --> Model Class Initialized
INFO - 2016-06-06 15:44:03 --> Helper loaded: date_helper
INFO - 2016-06-06 15:44:03 --> Controller Class Initialized
INFO - 2016-06-06 15:44:03 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:44:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:44:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:44:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:44:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:44:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:44:03 --> Model Class Initialized
INFO - 2016-06-06 15:44:03 --> Form Validation Class Initialized
INFO - 2016-06-06 15:44:03 --> Final output sent to browser
DEBUG - 2016-06-06 15:44:03 --> Total execution time: 0.0144
INFO - 2016-06-06 15:44:41 --> Config Class Initialized
INFO - 2016-06-06 15:44:41 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:44:41 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:44:41 --> Utf8 Class Initialized
INFO - 2016-06-06 15:44:41 --> URI Class Initialized
INFO - 2016-06-06 15:44:41 --> Router Class Initialized
INFO - 2016-06-06 15:44:41 --> Output Class Initialized
INFO - 2016-06-06 15:44:41 --> Security Class Initialized
DEBUG - 2016-06-06 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:44:41 --> Input Class Initialized
INFO - 2016-06-06 15:44:41 --> Language Class Initialized
INFO - 2016-06-06 15:44:41 --> Loader Class Initialized
INFO - 2016-06-06 15:44:41 --> Helper loaded: form_helper
INFO - 2016-06-06 15:44:41 --> Database Driver Class Initialized
INFO - 2016-06-06 15:44:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:44:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:44:41 --> Email Class Initialized
INFO - 2016-06-06 15:44:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:44:41 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:44:41 --> Helper loaded: language_helper
INFO - 2016-06-06 15:44:41 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:44:41 --> Model Class Initialized
INFO - 2016-06-06 15:44:41 --> Helper loaded: date_helper
INFO - 2016-06-06 15:44:41 --> Controller Class Initialized
INFO - 2016-06-06 15:44:41 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:44:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:44:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:44:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:44:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:44:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:44:41 --> Model Class Initialized
INFO - 2016-06-06 15:44:41 --> Form Validation Class Initialized
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:44:41 --> Final output sent to browser
DEBUG - 2016-06-06 15:44:41 --> Total execution time: 0.0306
INFO - 2016-06-06 15:44:45 --> Config Class Initialized
INFO - 2016-06-06 15:44:45 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:44:45 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:44:45 --> Utf8 Class Initialized
INFO - 2016-06-06 15:44:45 --> URI Class Initialized
INFO - 2016-06-06 15:44:45 --> Router Class Initialized
INFO - 2016-06-06 15:44:45 --> Output Class Initialized
INFO - 2016-06-06 15:44:45 --> Security Class Initialized
DEBUG - 2016-06-06 15:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:44:45 --> Input Class Initialized
INFO - 2016-06-06 15:44:45 --> Language Class Initialized
INFO - 2016-06-06 15:44:45 --> Loader Class Initialized
INFO - 2016-06-06 15:44:45 --> Helper loaded: form_helper
INFO - 2016-06-06 15:44:45 --> Database Driver Class Initialized
INFO - 2016-06-06 15:44:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:44:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:44:45 --> Email Class Initialized
INFO - 2016-06-06 15:44:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:44:45 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:44:45 --> Helper loaded: language_helper
INFO - 2016-06-06 15:44:45 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:44:45 --> Model Class Initialized
INFO - 2016-06-06 15:44:45 --> Helper loaded: date_helper
INFO - 2016-06-06 15:44:45 --> Controller Class Initialized
INFO - 2016-06-06 15:44:45 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:44:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:44:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:44:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:44:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:44:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:44:45 --> Model Class Initialized
INFO - 2016-06-06 15:44:45 --> Form Validation Class Initialized
INFO - 2016-06-06 15:44:45 --> Final output sent to browser
DEBUG - 2016-06-06 15:44:45 --> Total execution time: 0.0572
INFO - 2016-06-06 15:47:20 --> Config Class Initialized
INFO - 2016-06-06 15:47:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:47:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:47:20 --> Utf8 Class Initialized
INFO - 2016-06-06 15:47:20 --> URI Class Initialized
INFO - 2016-06-06 15:47:20 --> Router Class Initialized
INFO - 2016-06-06 15:47:20 --> Output Class Initialized
INFO - 2016-06-06 15:47:20 --> Security Class Initialized
DEBUG - 2016-06-06 15:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:47:20 --> Input Class Initialized
INFO - 2016-06-06 15:47:20 --> Language Class Initialized
INFO - 2016-06-06 15:47:20 --> Loader Class Initialized
INFO - 2016-06-06 15:47:20 --> Helper loaded: form_helper
INFO - 2016-06-06 15:47:20 --> Database Driver Class Initialized
INFO - 2016-06-06 15:47:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:47:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:47:20 --> Email Class Initialized
INFO - 2016-06-06 15:47:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:47:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:47:20 --> Helper loaded: language_helper
INFO - 2016-06-06 15:47:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:47:20 --> Model Class Initialized
INFO - 2016-06-06 15:47:20 --> Helper loaded: date_helper
INFO - 2016-06-06 15:47:20 --> Controller Class Initialized
INFO - 2016-06-06 15:47:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:47:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:47:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:47:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:47:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:47:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:47:20 --> Model Class Initialized
INFO - 2016-06-06 15:47:20 --> Form Validation Class Initialized
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:47:20 --> Final output sent to browser
DEBUG - 2016-06-06 15:47:20 --> Total execution time: 0.1039
INFO - 2016-06-06 15:47:24 --> Config Class Initialized
INFO - 2016-06-06 15:47:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:47:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:47:24 --> Utf8 Class Initialized
INFO - 2016-06-06 15:47:24 --> URI Class Initialized
INFO - 2016-06-06 15:47:24 --> Router Class Initialized
INFO - 2016-06-06 15:47:24 --> Output Class Initialized
INFO - 2016-06-06 15:47:24 --> Security Class Initialized
DEBUG - 2016-06-06 15:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:47:24 --> Input Class Initialized
INFO - 2016-06-06 15:47:24 --> Language Class Initialized
INFO - 2016-06-06 15:47:24 --> Loader Class Initialized
INFO - 2016-06-06 15:47:24 --> Helper loaded: form_helper
INFO - 2016-06-06 15:47:24 --> Database Driver Class Initialized
INFO - 2016-06-06 15:47:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:47:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:47:24 --> Email Class Initialized
INFO - 2016-06-06 15:47:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:47:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:47:24 --> Helper loaded: language_helper
INFO - 2016-06-06 15:47:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:47:24 --> Model Class Initialized
INFO - 2016-06-06 15:47:24 --> Helper loaded: date_helper
INFO - 2016-06-06 15:47:24 --> Controller Class Initialized
INFO - 2016-06-06 15:47:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:47:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:47:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:47:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:47:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:47:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:47:24 --> Model Class Initialized
INFO - 2016-06-06 15:47:24 --> Form Validation Class Initialized
INFO - 2016-06-06 15:47:24 --> Final output sent to browser
DEBUG - 2016-06-06 15:47:24 --> Total execution time: 0.0357
INFO - 2016-06-06 15:49:28 --> Config Class Initialized
INFO - 2016-06-06 15:49:28 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:49:28 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:49:28 --> Utf8 Class Initialized
INFO - 2016-06-06 15:49:28 --> URI Class Initialized
INFO - 2016-06-06 15:49:28 --> Router Class Initialized
INFO - 2016-06-06 15:49:28 --> Output Class Initialized
INFO - 2016-06-06 15:49:28 --> Security Class Initialized
DEBUG - 2016-06-06 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:49:28 --> Input Class Initialized
INFO - 2016-06-06 15:49:28 --> Language Class Initialized
INFO - 2016-06-06 15:49:28 --> Loader Class Initialized
INFO - 2016-06-06 15:49:28 --> Helper loaded: form_helper
INFO - 2016-06-06 15:49:28 --> Database Driver Class Initialized
INFO - 2016-06-06 15:49:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:49:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:49:28 --> Email Class Initialized
INFO - 2016-06-06 15:49:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:49:28 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:49:28 --> Helper loaded: language_helper
INFO - 2016-06-06 15:49:28 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:49:28 --> Model Class Initialized
INFO - 2016-06-06 15:49:28 --> Helper loaded: date_helper
INFO - 2016-06-06 15:49:28 --> Controller Class Initialized
INFO - 2016-06-06 15:49:28 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:49:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:49:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:49:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:49:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:49:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:49:28 --> Model Class Initialized
INFO - 2016-06-06 15:49:28 --> Form Validation Class Initialized
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:49:28 --> Final output sent to browser
DEBUG - 2016-06-06 15:49:28 --> Total execution time: 0.0282
INFO - 2016-06-06 15:49:31 --> Config Class Initialized
INFO - 2016-06-06 15:49:31 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:49:31 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:49:31 --> Utf8 Class Initialized
INFO - 2016-06-06 15:49:31 --> URI Class Initialized
INFO - 2016-06-06 15:49:31 --> Router Class Initialized
INFO - 2016-06-06 15:49:31 --> Output Class Initialized
INFO - 2016-06-06 15:49:31 --> Security Class Initialized
DEBUG - 2016-06-06 15:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:49:31 --> Input Class Initialized
INFO - 2016-06-06 15:49:31 --> Language Class Initialized
INFO - 2016-06-06 15:49:31 --> Loader Class Initialized
INFO - 2016-06-06 15:49:31 --> Helper loaded: form_helper
INFO - 2016-06-06 15:49:31 --> Database Driver Class Initialized
INFO - 2016-06-06 15:49:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:49:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:49:31 --> Email Class Initialized
INFO - 2016-06-06 15:49:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:49:31 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:49:31 --> Helper loaded: language_helper
INFO - 2016-06-06 15:49:31 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:49:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:49:31 --> Model Class Initialized
INFO - 2016-06-06 15:49:31 --> Helper loaded: date_helper
INFO - 2016-06-06 15:49:31 --> Controller Class Initialized
INFO - 2016-06-06 15:49:31 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:49:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:49:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:49:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:49:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:49:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:49:31 --> Model Class Initialized
INFO - 2016-06-06 15:49:31 --> Form Validation Class Initialized
INFO - 2016-06-06 15:49:31 --> Final output sent to browser
DEBUG - 2016-06-06 15:49:31 --> Total execution time: 0.0600
INFO - 2016-06-06 15:51:47 --> Config Class Initialized
INFO - 2016-06-06 15:51:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:51:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:51:47 --> Utf8 Class Initialized
INFO - 2016-06-06 15:51:47 --> URI Class Initialized
INFO - 2016-06-06 15:51:47 --> Router Class Initialized
INFO - 2016-06-06 15:51:47 --> Output Class Initialized
INFO - 2016-06-06 15:51:47 --> Security Class Initialized
DEBUG - 2016-06-06 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:51:47 --> Input Class Initialized
INFO - 2016-06-06 15:51:47 --> Language Class Initialized
INFO - 2016-06-06 15:51:47 --> Loader Class Initialized
INFO - 2016-06-06 15:51:47 --> Helper loaded: form_helper
INFO - 2016-06-06 15:51:47 --> Database Driver Class Initialized
INFO - 2016-06-06 15:51:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:51:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:51:47 --> Email Class Initialized
INFO - 2016-06-06 15:51:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:51:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:51:47 --> Helper loaded: language_helper
INFO - 2016-06-06 15:51:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:51:47 --> Model Class Initialized
INFO - 2016-06-06 15:51:47 --> Helper loaded: date_helper
INFO - 2016-06-06 15:51:47 --> Controller Class Initialized
INFO - 2016-06-06 15:51:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:51:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:51:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:51:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:51:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:51:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:51:47 --> Model Class Initialized
INFO - 2016-06-06 15:51:47 --> Form Validation Class Initialized
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:51:47 --> Final output sent to browser
DEBUG - 2016-06-06 15:51:47 --> Total execution time: 0.0442
INFO - 2016-06-06 15:51:51 --> Config Class Initialized
INFO - 2016-06-06 15:51:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:51:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:51:51 --> Utf8 Class Initialized
INFO - 2016-06-06 15:51:51 --> URI Class Initialized
INFO - 2016-06-06 15:51:51 --> Router Class Initialized
INFO - 2016-06-06 15:51:51 --> Output Class Initialized
INFO - 2016-06-06 15:51:51 --> Security Class Initialized
DEBUG - 2016-06-06 15:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:51:51 --> Input Class Initialized
INFO - 2016-06-06 15:51:51 --> Language Class Initialized
INFO - 2016-06-06 15:51:51 --> Loader Class Initialized
INFO - 2016-06-06 15:51:51 --> Helper loaded: form_helper
INFO - 2016-06-06 15:51:51 --> Database Driver Class Initialized
INFO - 2016-06-06 15:51:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:51:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:51:51 --> Email Class Initialized
INFO - 2016-06-06 15:51:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:51:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:51:51 --> Helper loaded: language_helper
INFO - 2016-06-06 15:51:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:51:51 --> Model Class Initialized
INFO - 2016-06-06 15:51:51 --> Helper loaded: date_helper
INFO - 2016-06-06 15:51:51 --> Controller Class Initialized
INFO - 2016-06-06 15:51:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:51:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:51:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:51:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:51:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:51:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:51:51 --> Model Class Initialized
INFO - 2016-06-06 15:51:51 --> Form Validation Class Initialized
INFO - 2016-06-06 15:51:51 --> Final output sent to browser
DEBUG - 2016-06-06 15:51:51 --> Total execution time: 0.0309
INFO - 2016-06-06 15:51:58 --> Config Class Initialized
INFO - 2016-06-06 15:51:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:51:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:51:58 --> Utf8 Class Initialized
INFO - 2016-06-06 15:51:58 --> URI Class Initialized
INFO - 2016-06-06 15:51:58 --> Router Class Initialized
INFO - 2016-06-06 15:51:58 --> Output Class Initialized
INFO - 2016-06-06 15:51:58 --> Security Class Initialized
DEBUG - 2016-06-06 15:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:51:58 --> Input Class Initialized
INFO - 2016-06-06 15:51:58 --> Language Class Initialized
INFO - 2016-06-06 15:51:58 --> Loader Class Initialized
INFO - 2016-06-06 15:51:58 --> Helper loaded: form_helper
INFO - 2016-06-06 15:51:58 --> Database Driver Class Initialized
INFO - 2016-06-06 15:51:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:51:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:51:58 --> Email Class Initialized
INFO - 2016-06-06 15:51:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:51:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:51:58 --> Helper loaded: language_helper
INFO - 2016-06-06 15:51:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:51:58 --> Model Class Initialized
INFO - 2016-06-06 15:51:58 --> Helper loaded: date_helper
INFO - 2016-06-06 15:51:58 --> Controller Class Initialized
INFO - 2016-06-06 15:51:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:51:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:51:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:51:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:51:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:51:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:51:58 --> Model Class Initialized
INFO - 2016-06-06 15:51:58 --> Form Validation Class Initialized
INFO - 2016-06-06 15:51:58 --> Final output sent to browser
DEBUG - 2016-06-06 15:51:58 --> Total execution time: 0.0593
INFO - 2016-06-06 15:56:21 --> Config Class Initialized
INFO - 2016-06-06 15:56:21 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:56:21 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:56:21 --> Utf8 Class Initialized
INFO - 2016-06-06 15:56:21 --> URI Class Initialized
INFO - 2016-06-06 15:56:21 --> Router Class Initialized
INFO - 2016-06-06 15:56:21 --> Output Class Initialized
INFO - 2016-06-06 15:56:21 --> Security Class Initialized
DEBUG - 2016-06-06 15:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:56:21 --> Input Class Initialized
INFO - 2016-06-06 15:56:21 --> Language Class Initialized
INFO - 2016-06-06 15:56:21 --> Loader Class Initialized
INFO - 2016-06-06 15:56:21 --> Helper loaded: form_helper
INFO - 2016-06-06 15:56:21 --> Database Driver Class Initialized
INFO - 2016-06-06 15:56:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:56:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:56:21 --> Email Class Initialized
INFO - 2016-06-06 15:56:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:56:21 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:56:21 --> Helper loaded: language_helper
INFO - 2016-06-06 15:56:21 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:56:21 --> Model Class Initialized
INFO - 2016-06-06 15:56:21 --> Helper loaded: date_helper
INFO - 2016-06-06 15:56:21 --> Controller Class Initialized
INFO - 2016-06-06 15:56:21 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:56:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:56:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:56:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:56:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:56:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:56:21 --> Model Class Initialized
INFO - 2016-06-06 15:56:21 --> Form Validation Class Initialized
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 31
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 38
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 45
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 52
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 59
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 67
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 81
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 88
ERROR - 2016-06-06 15:56:21 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 95
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:56:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:56:21 --> Final output sent to browser
DEBUG - 2016-06-06 15:56:21 --> Total execution time: 0.1168
INFO - 2016-06-06 15:56:23 --> Config Class Initialized
INFO - 2016-06-06 15:56:23 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:56:23 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:56:23 --> Utf8 Class Initialized
INFO - 2016-06-06 15:56:23 --> URI Class Initialized
INFO - 2016-06-06 15:56:23 --> Router Class Initialized
INFO - 2016-06-06 15:56:23 --> Output Class Initialized
INFO - 2016-06-06 15:56:23 --> Security Class Initialized
DEBUG - 2016-06-06 15:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:56:23 --> Input Class Initialized
INFO - 2016-06-06 15:56:23 --> Language Class Initialized
INFO - 2016-06-06 15:56:23 --> Loader Class Initialized
INFO - 2016-06-06 15:56:23 --> Helper loaded: form_helper
INFO - 2016-06-06 15:56:23 --> Database Driver Class Initialized
INFO - 2016-06-06 15:56:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:56:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:56:23 --> Email Class Initialized
INFO - 2016-06-06 15:56:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:56:23 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:56:23 --> Helper loaded: language_helper
INFO - 2016-06-06 15:56:23 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:56:23 --> Model Class Initialized
INFO - 2016-06-06 15:56:23 --> Helper loaded: date_helper
INFO - 2016-06-06 15:56:23 --> Controller Class Initialized
INFO - 2016-06-06 15:56:23 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:56:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:56:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:56:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:56:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:56:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:56:23 --> Model Class Initialized
INFO - 2016-06-06 15:56:23 --> Form Validation Class Initialized
INFO - 2016-06-06 15:56:23 --> Final output sent to browser
DEBUG - 2016-06-06 15:56:23 --> Total execution time: 0.0186
INFO - 2016-06-06 15:57:56 --> Config Class Initialized
INFO - 2016-06-06 15:57:56 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:57:56 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:57:56 --> Utf8 Class Initialized
INFO - 2016-06-06 15:57:56 --> URI Class Initialized
INFO - 2016-06-06 15:57:56 --> Router Class Initialized
INFO - 2016-06-06 15:57:56 --> Output Class Initialized
INFO - 2016-06-06 15:57:56 --> Security Class Initialized
DEBUG - 2016-06-06 15:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:57:56 --> Input Class Initialized
INFO - 2016-06-06 15:57:56 --> Language Class Initialized
INFO - 2016-06-06 15:57:56 --> Loader Class Initialized
INFO - 2016-06-06 15:57:56 --> Helper loaded: form_helper
INFO - 2016-06-06 15:57:56 --> Database Driver Class Initialized
INFO - 2016-06-06 15:57:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:57:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:57:56 --> Email Class Initialized
INFO - 2016-06-06 15:57:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:57:56 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:57:56 --> Helper loaded: language_helper
INFO - 2016-06-06 15:57:56 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:57:56 --> Model Class Initialized
INFO - 2016-06-06 15:57:56 --> Helper loaded: date_helper
INFO - 2016-06-06 15:57:56 --> Controller Class Initialized
INFO - 2016-06-06 15:57:56 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:57:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:57:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:57:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:57:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:57:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:57:56 --> Model Class Initialized
INFO - 2016-06-06 15:57:56 --> Form Validation Class Initialized
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:57:56 --> Final output sent to browser
DEBUG - 2016-06-06 15:57:56 --> Total execution time: 0.1036
INFO - 2016-06-06 15:57:58 --> Config Class Initialized
INFO - 2016-06-06 15:57:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:57:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:57:58 --> Utf8 Class Initialized
INFO - 2016-06-06 15:57:58 --> URI Class Initialized
INFO - 2016-06-06 15:57:58 --> Router Class Initialized
INFO - 2016-06-06 15:57:58 --> Output Class Initialized
INFO - 2016-06-06 15:57:58 --> Security Class Initialized
DEBUG - 2016-06-06 15:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:57:58 --> Input Class Initialized
INFO - 2016-06-06 15:57:58 --> Language Class Initialized
INFO - 2016-06-06 15:57:58 --> Loader Class Initialized
INFO - 2016-06-06 15:57:58 --> Helper loaded: form_helper
INFO - 2016-06-06 15:57:58 --> Database Driver Class Initialized
INFO - 2016-06-06 15:57:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:57:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:57:58 --> Email Class Initialized
INFO - 2016-06-06 15:57:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:57:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:57:58 --> Helper loaded: language_helper
INFO - 2016-06-06 15:57:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:57:58 --> Model Class Initialized
INFO - 2016-06-06 15:57:58 --> Helper loaded: date_helper
INFO - 2016-06-06 15:57:58 --> Controller Class Initialized
INFO - 2016-06-06 15:57:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:57:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:57:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:57:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:57:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:57:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:57:58 --> Model Class Initialized
INFO - 2016-06-06 15:57:58 --> Form Validation Class Initialized
INFO - 2016-06-06 15:57:58 --> Final output sent to browser
DEBUG - 2016-06-06 15:57:58 --> Total execution time: 0.0197
INFO - 2016-06-06 15:58:44 --> Config Class Initialized
INFO - 2016-06-06 15:58:44 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:58:44 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:58:44 --> Utf8 Class Initialized
INFO - 2016-06-06 15:58:44 --> URI Class Initialized
INFO - 2016-06-06 15:58:44 --> Router Class Initialized
INFO - 2016-06-06 15:58:44 --> Output Class Initialized
INFO - 2016-06-06 15:58:44 --> Security Class Initialized
DEBUG - 2016-06-06 15:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:58:44 --> Input Class Initialized
INFO - 2016-06-06 15:58:44 --> Language Class Initialized
INFO - 2016-06-06 15:58:44 --> Loader Class Initialized
INFO - 2016-06-06 15:58:44 --> Helper loaded: form_helper
INFO - 2016-06-06 15:58:44 --> Database Driver Class Initialized
INFO - 2016-06-06 15:58:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:58:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:58:44 --> Email Class Initialized
INFO - 2016-06-06 15:58:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:58:44 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:58:44 --> Helper loaded: language_helper
INFO - 2016-06-06 15:58:44 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:58:44 --> Model Class Initialized
INFO - 2016-06-06 15:58:44 --> Helper loaded: date_helper
INFO - 2016-06-06 15:58:44 --> Controller Class Initialized
INFO - 2016-06-06 15:58:44 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:58:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:58:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:58:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:58:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:58:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:58:44 --> Model Class Initialized
INFO - 2016-06-06 15:58:44 --> Form Validation Class Initialized
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:58:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:58:44 --> Final output sent to browser
DEBUG - 2016-06-06 15:58:44 --> Total execution time: 0.0257
INFO - 2016-06-06 15:58:48 --> Config Class Initialized
INFO - 2016-06-06 15:58:48 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:58:48 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:58:48 --> Utf8 Class Initialized
INFO - 2016-06-06 15:58:48 --> URI Class Initialized
INFO - 2016-06-06 15:58:48 --> Router Class Initialized
INFO - 2016-06-06 15:58:48 --> Output Class Initialized
INFO - 2016-06-06 15:58:48 --> Security Class Initialized
DEBUG - 2016-06-06 15:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:58:48 --> Input Class Initialized
INFO - 2016-06-06 15:58:48 --> Language Class Initialized
INFO - 2016-06-06 15:58:48 --> Loader Class Initialized
INFO - 2016-06-06 15:58:48 --> Helper loaded: form_helper
INFO - 2016-06-06 15:58:48 --> Database Driver Class Initialized
INFO - 2016-06-06 15:58:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:58:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:58:48 --> Email Class Initialized
INFO - 2016-06-06 15:58:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:58:48 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:58:48 --> Helper loaded: language_helper
INFO - 2016-06-06 15:58:48 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:58:48 --> Model Class Initialized
INFO - 2016-06-06 15:58:48 --> Helper loaded: date_helper
INFO - 2016-06-06 15:58:48 --> Controller Class Initialized
INFO - 2016-06-06 15:58:48 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:58:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:58:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:58:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:58:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:58:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:58:48 --> Model Class Initialized
INFO - 2016-06-06 15:58:48 --> Form Validation Class Initialized
INFO - 2016-06-06 15:58:48 --> Final output sent to browser
DEBUG - 2016-06-06 15:58:48 --> Total execution time: 0.0475
INFO - 2016-06-06 15:59:06 --> Config Class Initialized
INFO - 2016-06-06 15:59:06 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:59:06 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:59:06 --> Utf8 Class Initialized
INFO - 2016-06-06 15:59:06 --> URI Class Initialized
INFO - 2016-06-06 15:59:06 --> Router Class Initialized
INFO - 2016-06-06 15:59:06 --> Output Class Initialized
INFO - 2016-06-06 15:59:06 --> Security Class Initialized
DEBUG - 2016-06-06 15:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:59:06 --> Input Class Initialized
INFO - 2016-06-06 15:59:06 --> Language Class Initialized
INFO - 2016-06-06 15:59:06 --> Loader Class Initialized
INFO - 2016-06-06 15:59:06 --> Helper loaded: form_helper
INFO - 2016-06-06 15:59:06 --> Database Driver Class Initialized
INFO - 2016-06-06 15:59:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:59:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:59:06 --> Email Class Initialized
INFO - 2016-06-06 15:59:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:59:06 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:59:06 --> Helper loaded: language_helper
INFO - 2016-06-06 15:59:06 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:59:06 --> Model Class Initialized
INFO - 2016-06-06 15:59:06 --> Helper loaded: date_helper
INFO - 2016-06-06 15:59:06 --> Controller Class Initialized
INFO - 2016-06-06 15:59:06 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:59:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:59:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:59:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:59:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:59:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:59:06 --> Model Class Initialized
INFO - 2016-06-06 15:59:06 --> Form Validation Class Initialized
INFO - 2016-06-06 15:59:07 --> Final output sent to browser
DEBUG - 2016-06-06 15:59:07 --> Total execution time: 0.0742
INFO - 2016-06-06 15:59:17 --> Config Class Initialized
INFO - 2016-06-06 15:59:17 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:59:17 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:59:17 --> Utf8 Class Initialized
INFO - 2016-06-06 15:59:17 --> URI Class Initialized
INFO - 2016-06-06 15:59:17 --> Router Class Initialized
INFO - 2016-06-06 15:59:17 --> Output Class Initialized
INFO - 2016-06-06 15:59:17 --> Security Class Initialized
DEBUG - 2016-06-06 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:59:17 --> Input Class Initialized
INFO - 2016-06-06 15:59:17 --> Language Class Initialized
INFO - 2016-06-06 15:59:17 --> Loader Class Initialized
INFO - 2016-06-06 15:59:17 --> Helper loaded: form_helper
INFO - 2016-06-06 15:59:17 --> Database Driver Class Initialized
INFO - 2016-06-06 15:59:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:59:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:59:17 --> Email Class Initialized
INFO - 2016-06-06 15:59:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:59:17 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:59:17 --> Helper loaded: language_helper
INFO - 2016-06-06 15:59:17 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:59:17 --> Model Class Initialized
INFO - 2016-06-06 15:59:17 --> Helper loaded: date_helper
INFO - 2016-06-06 15:59:17 --> Controller Class Initialized
INFO - 2016-06-06 15:59:17 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:59:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:59:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:59:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:59:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:59:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:59:17 --> Model Class Initialized
INFO - 2016-06-06 15:59:17 --> Form Validation Class Initialized
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 31
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 38
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 45
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 52
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 59
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 67
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 81
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 88
ERROR - 2016-06-06 15:59:17 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 95
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 15:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 15:59:17 --> Final output sent to browser
DEBUG - 2016-06-06 15:59:17 --> Total execution time: 0.0478
INFO - 2016-06-06 15:59:22 --> Config Class Initialized
INFO - 2016-06-06 15:59:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 15:59:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 15:59:22 --> Utf8 Class Initialized
INFO - 2016-06-06 15:59:22 --> URI Class Initialized
INFO - 2016-06-06 15:59:22 --> Router Class Initialized
INFO - 2016-06-06 15:59:22 --> Output Class Initialized
INFO - 2016-06-06 15:59:22 --> Security Class Initialized
DEBUG - 2016-06-06 15:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 15:59:22 --> Input Class Initialized
INFO - 2016-06-06 15:59:22 --> Language Class Initialized
INFO - 2016-06-06 15:59:22 --> Loader Class Initialized
INFO - 2016-06-06 15:59:22 --> Helper loaded: form_helper
INFO - 2016-06-06 15:59:22 --> Database Driver Class Initialized
INFO - 2016-06-06 15:59:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 15:59:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 15:59:22 --> Email Class Initialized
INFO - 2016-06-06 15:59:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 15:59:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 15:59:22 --> Helper loaded: language_helper
INFO - 2016-06-06 15:59:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 15:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 15:59:22 --> Model Class Initialized
INFO - 2016-06-06 15:59:22 --> Helper loaded: date_helper
INFO - 2016-06-06 15:59:22 --> Controller Class Initialized
INFO - 2016-06-06 15:59:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 15:59:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 15:59:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 15:59:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 15:59:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 15:59:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 15:59:22 --> Model Class Initialized
INFO - 2016-06-06 15:59:22 --> Form Validation Class Initialized
INFO - 2016-06-06 15:59:22 --> Final output sent to browser
DEBUG - 2016-06-06 15:59:22 --> Total execution time: 0.0253
INFO - 2016-06-06 16:00:00 --> Config Class Initialized
INFO - 2016-06-06 16:00:00 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:00:00 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:00:00 --> Utf8 Class Initialized
INFO - 2016-06-06 16:00:00 --> URI Class Initialized
INFO - 2016-06-06 16:00:00 --> Router Class Initialized
INFO - 2016-06-06 16:00:00 --> Output Class Initialized
INFO - 2016-06-06 16:00:00 --> Security Class Initialized
DEBUG - 2016-06-06 16:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:00:00 --> Input Class Initialized
INFO - 2016-06-06 16:00:00 --> Language Class Initialized
INFO - 2016-06-06 16:00:00 --> Loader Class Initialized
INFO - 2016-06-06 16:00:00 --> Helper loaded: form_helper
INFO - 2016-06-06 16:00:00 --> Database Driver Class Initialized
INFO - 2016-06-06 16:00:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:00:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:00:00 --> Email Class Initialized
INFO - 2016-06-06 16:00:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:00:00 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:00:00 --> Helper loaded: language_helper
INFO - 2016-06-06 16:00:00 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:00:00 --> Model Class Initialized
INFO - 2016-06-06 16:00:00 --> Helper loaded: date_helper
INFO - 2016-06-06 16:00:00 --> Controller Class Initialized
INFO - 2016-06-06 16:00:00 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:00:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:00:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:00:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:00:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:00:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:00:00 --> Model Class Initialized
INFO - 2016-06-06 16:00:00 --> Form Validation Class Initialized
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:00:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:00:00 --> Final output sent to browser
DEBUG - 2016-06-06 16:00:00 --> Total execution time: 0.0268
INFO - 2016-06-06 16:00:04 --> Config Class Initialized
INFO - 2016-06-06 16:00:04 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:00:04 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:00:04 --> Utf8 Class Initialized
INFO - 2016-06-06 16:00:04 --> URI Class Initialized
INFO - 2016-06-06 16:00:04 --> Router Class Initialized
INFO - 2016-06-06 16:00:04 --> Output Class Initialized
INFO - 2016-06-06 16:00:04 --> Security Class Initialized
DEBUG - 2016-06-06 16:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:00:04 --> Input Class Initialized
INFO - 2016-06-06 16:00:04 --> Language Class Initialized
INFO - 2016-06-06 16:00:04 --> Loader Class Initialized
INFO - 2016-06-06 16:00:04 --> Helper loaded: form_helper
INFO - 2016-06-06 16:00:04 --> Database Driver Class Initialized
INFO - 2016-06-06 16:00:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:00:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:00:04 --> Email Class Initialized
INFO - 2016-06-06 16:00:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:00:04 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:00:04 --> Helper loaded: language_helper
INFO - 2016-06-06 16:00:04 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:00:04 --> Model Class Initialized
INFO - 2016-06-06 16:00:04 --> Helper loaded: date_helper
INFO - 2016-06-06 16:00:04 --> Controller Class Initialized
INFO - 2016-06-06 16:00:04 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:00:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:00:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:00:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:00:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:00:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:00:04 --> Model Class Initialized
INFO - 2016-06-06 16:00:04 --> Form Validation Class Initialized
INFO - 2016-06-06 16:00:04 --> Final output sent to browser
DEBUG - 2016-06-06 16:00:04 --> Total execution time: 0.0591
INFO - 2016-06-06 16:05:25 --> Config Class Initialized
INFO - 2016-06-06 16:05:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:05:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:05:25 --> Utf8 Class Initialized
INFO - 2016-06-06 16:05:25 --> URI Class Initialized
INFO - 2016-06-06 16:05:25 --> Router Class Initialized
INFO - 2016-06-06 16:05:25 --> Output Class Initialized
INFO - 2016-06-06 16:05:25 --> Security Class Initialized
DEBUG - 2016-06-06 16:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:05:25 --> Input Class Initialized
INFO - 2016-06-06 16:05:25 --> Language Class Initialized
INFO - 2016-06-06 16:05:25 --> Loader Class Initialized
INFO - 2016-06-06 16:05:25 --> Helper loaded: form_helper
INFO - 2016-06-06 16:05:25 --> Database Driver Class Initialized
INFO - 2016-06-06 16:05:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:05:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:05:25 --> Email Class Initialized
INFO - 2016-06-06 16:05:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:05:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:05:25 --> Helper loaded: language_helper
INFO - 2016-06-06 16:05:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:05:25 --> Model Class Initialized
INFO - 2016-06-06 16:05:25 --> Helper loaded: date_helper
INFO - 2016-06-06 16:05:25 --> Controller Class Initialized
INFO - 2016-06-06 16:05:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:05:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:05:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:05:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:05:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:05:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:05:25 --> Model Class Initialized
INFO - 2016-06-06 16:05:25 --> Form Validation Class Initialized
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:05:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
ERROR - 2016-06-06 16:05:25 --> Severity: Parsing Error --> syntax error, unexpected ':' /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php 15
INFO - 2016-06-06 16:06:28 --> Config Class Initialized
INFO - 2016-06-06 16:06:28 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:06:28 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:06:28 --> Utf8 Class Initialized
INFO - 2016-06-06 16:06:28 --> URI Class Initialized
INFO - 2016-06-06 16:06:28 --> Router Class Initialized
INFO - 2016-06-06 16:06:28 --> Output Class Initialized
INFO - 2016-06-06 16:06:28 --> Security Class Initialized
DEBUG - 2016-06-06 16:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:06:28 --> Input Class Initialized
INFO - 2016-06-06 16:06:28 --> Language Class Initialized
INFO - 2016-06-06 16:06:28 --> Loader Class Initialized
INFO - 2016-06-06 16:06:28 --> Helper loaded: form_helper
INFO - 2016-06-06 16:06:28 --> Database Driver Class Initialized
INFO - 2016-06-06 16:06:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:06:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:06:29 --> Email Class Initialized
INFO - 2016-06-06 16:06:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:06:29 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:06:29 --> Helper loaded: language_helper
INFO - 2016-06-06 16:06:29 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:06:29 --> Model Class Initialized
INFO - 2016-06-06 16:06:29 --> Helper loaded: date_helper
INFO - 2016-06-06 16:06:29 --> Controller Class Initialized
INFO - 2016-06-06 16:06:29 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:06:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:06:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:06:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:06:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:06:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:06:29 --> Model Class Initialized
INFO - 2016-06-06 16:06:29 --> Form Validation Class Initialized
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:06:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:06:29 --> Final output sent to browser
DEBUG - 2016-06-06 16:06:29 --> Total execution time: 0.1088
INFO - 2016-06-06 16:07:26 --> Config Class Initialized
INFO - 2016-06-06 16:07:26 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:07:26 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:07:26 --> Utf8 Class Initialized
INFO - 2016-06-06 16:07:26 --> URI Class Initialized
INFO - 2016-06-06 16:07:26 --> Router Class Initialized
INFO - 2016-06-06 16:07:26 --> Output Class Initialized
INFO - 2016-06-06 16:07:26 --> Security Class Initialized
DEBUG - 2016-06-06 16:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:07:26 --> Input Class Initialized
INFO - 2016-06-06 16:07:26 --> Language Class Initialized
INFO - 2016-06-06 16:07:26 --> Loader Class Initialized
INFO - 2016-06-06 16:07:26 --> Helper loaded: form_helper
INFO - 2016-06-06 16:07:26 --> Database Driver Class Initialized
INFO - 2016-06-06 16:07:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:07:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:07:26 --> Email Class Initialized
INFO - 2016-06-06 16:07:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:07:26 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:07:26 --> Helper loaded: language_helper
INFO - 2016-06-06 16:07:26 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:07:26 --> Model Class Initialized
INFO - 2016-06-06 16:07:26 --> Helper loaded: date_helper
INFO - 2016-06-06 16:07:26 --> Controller Class Initialized
INFO - 2016-06-06 16:07:26 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:07:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:07:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:07:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:07:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:07:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:07:26 --> Model Class Initialized
INFO - 2016-06-06 16:07:26 --> Form Validation Class Initialized
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:07:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:07:38 --> Config Class Initialized
INFO - 2016-06-06 16:07:38 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:07:38 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:07:38 --> Utf8 Class Initialized
INFO - 2016-06-06 16:07:38 --> URI Class Initialized
INFO - 2016-06-06 16:07:38 --> Router Class Initialized
INFO - 2016-06-06 16:07:38 --> Output Class Initialized
INFO - 2016-06-06 16:07:38 --> Security Class Initialized
DEBUG - 2016-06-06 16:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:07:38 --> Input Class Initialized
INFO - 2016-06-06 16:07:38 --> Language Class Initialized
INFO - 2016-06-06 16:07:38 --> Loader Class Initialized
INFO - 2016-06-06 16:07:38 --> Helper loaded: form_helper
INFO - 2016-06-06 16:07:38 --> Database Driver Class Initialized
INFO - 2016-06-06 16:07:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:07:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:07:38 --> Email Class Initialized
INFO - 2016-06-06 16:07:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:07:38 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:07:38 --> Helper loaded: language_helper
INFO - 2016-06-06 16:07:38 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:07:38 --> Model Class Initialized
INFO - 2016-06-06 16:07:38 --> Helper loaded: date_helper
INFO - 2016-06-06 16:07:38 --> Controller Class Initialized
INFO - 2016-06-06 16:07:38 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:07:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:07:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:07:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:07:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:07:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:07:38 --> Model Class Initialized
INFO - 2016-06-06 16:07:38 --> Form Validation Class Initialized
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:07:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:07:38 --> Final output sent to browser
DEBUG - 2016-06-06 16:07:38 --> Total execution time: 0.0506
INFO - 2016-06-06 16:08:24 --> Config Class Initialized
INFO - 2016-06-06 16:08:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:08:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:08:24 --> Utf8 Class Initialized
INFO - 2016-06-06 16:08:24 --> URI Class Initialized
INFO - 2016-06-06 16:08:24 --> Router Class Initialized
INFO - 2016-06-06 16:08:24 --> Output Class Initialized
INFO - 2016-06-06 16:08:24 --> Security Class Initialized
DEBUG - 2016-06-06 16:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:08:24 --> Input Class Initialized
INFO - 2016-06-06 16:08:24 --> Language Class Initialized
INFO - 2016-06-06 16:08:24 --> Loader Class Initialized
INFO - 2016-06-06 16:08:24 --> Helper loaded: form_helper
INFO - 2016-06-06 16:08:24 --> Database Driver Class Initialized
INFO - 2016-06-06 16:08:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:08:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:08:24 --> Email Class Initialized
INFO - 2016-06-06 16:08:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:08:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:08:24 --> Helper loaded: language_helper
INFO - 2016-06-06 16:08:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:08:24 --> Model Class Initialized
INFO - 2016-06-06 16:08:24 --> Helper loaded: date_helper
INFO - 2016-06-06 16:08:24 --> Controller Class Initialized
INFO - 2016-06-06 16:08:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:08:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:08:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:08:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:08:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:08:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:08:24 --> Model Class Initialized
INFO - 2016-06-06 16:08:24 --> Form Validation Class Initialized
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:08:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:08:24 --> Final output sent to browser
DEBUG - 2016-06-06 16:08:24 --> Total execution time: 0.0263
INFO - 2016-06-06 16:10:12 --> Config Class Initialized
INFO - 2016-06-06 16:10:12 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:10:12 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:10:12 --> Utf8 Class Initialized
INFO - 2016-06-06 16:10:12 --> URI Class Initialized
INFO - 2016-06-06 16:10:12 --> Router Class Initialized
INFO - 2016-06-06 16:10:12 --> Output Class Initialized
INFO - 2016-06-06 16:10:12 --> Security Class Initialized
DEBUG - 2016-06-06 16:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:10:12 --> Input Class Initialized
INFO - 2016-06-06 16:10:12 --> Language Class Initialized
INFO - 2016-06-06 16:10:12 --> Loader Class Initialized
INFO - 2016-06-06 16:10:12 --> Helper loaded: form_helper
INFO - 2016-06-06 16:10:12 --> Database Driver Class Initialized
INFO - 2016-06-06 16:10:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:10:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:10:12 --> Email Class Initialized
INFO - 2016-06-06 16:10:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:10:12 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:10:12 --> Helper loaded: language_helper
INFO - 2016-06-06 16:10:12 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:10:12 --> Model Class Initialized
INFO - 2016-06-06 16:10:12 --> Helper loaded: date_helper
INFO - 2016-06-06 16:10:12 --> Controller Class Initialized
INFO - 2016-06-06 16:10:12 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:10:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:10:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:10:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:10:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:10:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:10:12 --> Model Class Initialized
INFO - 2016-06-06 16:10:12 --> Form Validation Class Initialized
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:10:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:10:12 --> Final output sent to browser
DEBUG - 2016-06-06 16:10:12 --> Total execution time: 0.0332
INFO - 2016-06-06 16:11:10 --> Config Class Initialized
INFO - 2016-06-06 16:11:10 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:11:10 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:11:10 --> Utf8 Class Initialized
INFO - 2016-06-06 16:11:10 --> URI Class Initialized
INFO - 2016-06-06 16:11:10 --> Router Class Initialized
INFO - 2016-06-06 16:11:10 --> Output Class Initialized
INFO - 2016-06-06 16:11:10 --> Security Class Initialized
DEBUG - 2016-06-06 16:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:11:10 --> Input Class Initialized
INFO - 2016-06-06 16:11:10 --> Language Class Initialized
INFO - 2016-06-06 16:11:10 --> Loader Class Initialized
INFO - 2016-06-06 16:11:10 --> Helper loaded: form_helper
INFO - 2016-06-06 16:11:10 --> Database Driver Class Initialized
INFO - 2016-06-06 16:11:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:11:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:11:10 --> Email Class Initialized
INFO - 2016-06-06 16:11:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:11:10 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:11:10 --> Helper loaded: language_helper
INFO - 2016-06-06 16:11:10 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:11:10 --> Model Class Initialized
INFO - 2016-06-06 16:11:10 --> Helper loaded: date_helper
INFO - 2016-06-06 16:11:10 --> Controller Class Initialized
INFO - 2016-06-06 16:11:10 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:11:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:11:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:11:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:11:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:11:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:11:10 --> Model Class Initialized
INFO - 2016-06-06 16:11:10 --> Form Validation Class Initialized
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:11:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:11:10 --> Final output sent to browser
DEBUG - 2016-06-06 16:11:10 --> Total execution time: 0.0447
INFO - 2016-06-06 16:11:16 --> Config Class Initialized
INFO - 2016-06-06 16:11:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:11:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:11:16 --> Utf8 Class Initialized
INFO - 2016-06-06 16:11:16 --> URI Class Initialized
INFO - 2016-06-06 16:11:16 --> Router Class Initialized
INFO - 2016-06-06 16:11:16 --> Output Class Initialized
INFO - 2016-06-06 16:11:16 --> Security Class Initialized
DEBUG - 2016-06-06 16:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:11:16 --> Input Class Initialized
INFO - 2016-06-06 16:11:16 --> Language Class Initialized
INFO - 2016-06-06 16:11:16 --> Loader Class Initialized
INFO - 2016-06-06 16:11:16 --> Helper loaded: form_helper
INFO - 2016-06-06 16:11:16 --> Database Driver Class Initialized
INFO - 2016-06-06 16:11:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:11:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:11:16 --> Email Class Initialized
INFO - 2016-06-06 16:11:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:11:16 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:11:16 --> Helper loaded: language_helper
INFO - 2016-06-06 16:11:16 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:11:16 --> Model Class Initialized
INFO - 2016-06-06 16:11:16 --> Helper loaded: date_helper
INFO - 2016-06-06 16:11:16 --> Controller Class Initialized
INFO - 2016-06-06 16:11:16 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:11:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:11:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:11:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:11:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:11:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:11:16 --> Model Class Initialized
INFO - 2016-06-06 16:11:16 --> Form Validation Class Initialized
INFO - 2016-06-06 16:11:16 --> Final output sent to browser
DEBUG - 2016-06-06 16:11:16 --> Total execution time: 0.0594
INFO - 2016-06-06 16:11:23 --> Config Class Initialized
INFO - 2016-06-06 16:11:23 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:11:23 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:11:23 --> Utf8 Class Initialized
INFO - 2016-06-06 16:11:23 --> URI Class Initialized
INFO - 2016-06-06 16:11:23 --> Router Class Initialized
INFO - 2016-06-06 16:11:23 --> Output Class Initialized
INFO - 2016-06-06 16:11:23 --> Security Class Initialized
DEBUG - 2016-06-06 16:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:11:23 --> Input Class Initialized
INFO - 2016-06-06 16:11:23 --> Language Class Initialized
INFO - 2016-06-06 16:11:23 --> Loader Class Initialized
INFO - 2016-06-06 16:11:23 --> Helper loaded: form_helper
INFO - 2016-06-06 16:11:23 --> Database Driver Class Initialized
INFO - 2016-06-06 16:11:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:11:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:11:23 --> Email Class Initialized
INFO - 2016-06-06 16:11:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:11:23 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:11:23 --> Helper loaded: language_helper
INFO - 2016-06-06 16:11:23 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:11:23 --> Model Class Initialized
INFO - 2016-06-06 16:11:23 --> Helper loaded: date_helper
INFO - 2016-06-06 16:11:23 --> Controller Class Initialized
INFO - 2016-06-06 16:11:23 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:11:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:11:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:11:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:11:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:11:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:11:23 --> Model Class Initialized
INFO - 2016-06-06 16:11:23 --> Form Validation Class Initialized
INFO - 2016-06-06 16:11:23 --> Final output sent to browser
DEBUG - 2016-06-06 16:11:23 --> Total execution time: 0.0413
INFO - 2016-06-06 16:11:33 --> Config Class Initialized
INFO - 2016-06-06 16:11:33 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:11:33 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:11:33 --> Utf8 Class Initialized
INFO - 2016-06-06 16:11:33 --> URI Class Initialized
INFO - 2016-06-06 16:11:33 --> Router Class Initialized
INFO - 2016-06-06 16:11:33 --> Output Class Initialized
INFO - 2016-06-06 16:11:33 --> Security Class Initialized
DEBUG - 2016-06-06 16:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:11:33 --> Input Class Initialized
INFO - 2016-06-06 16:11:33 --> Language Class Initialized
INFO - 2016-06-06 16:11:33 --> Loader Class Initialized
INFO - 2016-06-06 16:11:33 --> Helper loaded: form_helper
INFO - 2016-06-06 16:11:33 --> Database Driver Class Initialized
INFO - 2016-06-06 16:11:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:11:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:11:33 --> Email Class Initialized
INFO - 2016-06-06 16:11:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:11:33 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:11:33 --> Helper loaded: language_helper
INFO - 2016-06-06 16:11:33 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:11:33 --> Model Class Initialized
INFO - 2016-06-06 16:11:33 --> Helper loaded: date_helper
INFO - 2016-06-06 16:11:33 --> Controller Class Initialized
INFO - 2016-06-06 16:11:33 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:11:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:11:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:11:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:11:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:11:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:11:33 --> Model Class Initialized
INFO - 2016-06-06 16:11:33 --> Form Validation Class Initialized
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 31
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 38
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 45
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 52
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 59
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 67
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 81
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 88
ERROR - 2016-06-06 16:11:33 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 95
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:11:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:11:33 --> Final output sent to browser
DEBUG - 2016-06-06 16:11:33 --> Total execution time: 0.0293
INFO - 2016-06-06 16:11:41 --> Config Class Initialized
INFO - 2016-06-06 16:11:41 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:11:41 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:11:41 --> Utf8 Class Initialized
INFO - 2016-06-06 16:11:41 --> URI Class Initialized
INFO - 2016-06-06 16:11:41 --> Router Class Initialized
INFO - 2016-06-06 16:11:41 --> Output Class Initialized
INFO - 2016-06-06 16:11:41 --> Security Class Initialized
DEBUG - 2016-06-06 16:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:11:41 --> Input Class Initialized
INFO - 2016-06-06 16:11:41 --> Language Class Initialized
INFO - 2016-06-06 16:11:41 --> Loader Class Initialized
INFO - 2016-06-06 16:11:41 --> Helper loaded: form_helper
INFO - 2016-06-06 16:11:41 --> Database Driver Class Initialized
INFO - 2016-06-06 16:11:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:11:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:11:41 --> Email Class Initialized
INFO - 2016-06-06 16:11:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:11:41 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:11:41 --> Helper loaded: language_helper
INFO - 2016-06-06 16:11:41 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:11:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:11:41 --> Model Class Initialized
INFO - 2016-06-06 16:11:41 --> Helper loaded: date_helper
INFO - 2016-06-06 16:11:41 --> Controller Class Initialized
INFO - 2016-06-06 16:11:41 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:11:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:11:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:11:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:11:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:11:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:11:41 --> Model Class Initialized
INFO - 2016-06-06 16:11:41 --> Form Validation Class Initialized
INFO - 2016-06-06 16:11:41 --> Final output sent to browser
DEBUG - 2016-06-06 16:11:41 --> Total execution time: 0.0578
INFO - 2016-06-06 16:13:03 --> Config Class Initialized
INFO - 2016-06-06 16:13:03 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:13:03 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:13:03 --> Utf8 Class Initialized
INFO - 2016-06-06 16:13:03 --> URI Class Initialized
INFO - 2016-06-06 16:13:03 --> Router Class Initialized
INFO - 2016-06-06 16:13:03 --> Output Class Initialized
INFO - 2016-06-06 16:13:03 --> Security Class Initialized
DEBUG - 2016-06-06 16:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:13:03 --> Input Class Initialized
INFO - 2016-06-06 16:13:03 --> Language Class Initialized
INFO - 2016-06-06 16:13:03 --> Loader Class Initialized
INFO - 2016-06-06 16:13:03 --> Helper loaded: form_helper
INFO - 2016-06-06 16:13:03 --> Database Driver Class Initialized
INFO - 2016-06-06 16:13:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:13:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:13:03 --> Email Class Initialized
INFO - 2016-06-06 16:13:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:13:03 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:13:03 --> Helper loaded: language_helper
INFO - 2016-06-06 16:13:03 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:13:03 --> Model Class Initialized
INFO - 2016-06-06 16:13:03 --> Helper loaded: date_helper
INFO - 2016-06-06 16:13:03 --> Controller Class Initialized
INFO - 2016-06-06 16:13:03 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:13:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:13:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:13:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:13:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:13:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:13:03 --> Model Class Initialized
INFO - 2016-06-06 16:13:03 --> Form Validation Class Initialized
INFO - 2016-06-06 16:13:33 --> Config Class Initialized
INFO - 2016-06-06 16:13:33 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:13:33 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:13:33 --> Utf8 Class Initialized
INFO - 2016-06-06 16:13:33 --> URI Class Initialized
INFO - 2016-06-06 16:13:33 --> Router Class Initialized
INFO - 2016-06-06 16:13:33 --> Output Class Initialized
INFO - 2016-06-06 16:13:33 --> Security Class Initialized
DEBUG - 2016-06-06 16:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:13:33 --> Input Class Initialized
INFO - 2016-06-06 16:13:33 --> Language Class Initialized
INFO - 2016-06-06 16:13:33 --> Loader Class Initialized
INFO - 2016-06-06 16:13:33 --> Helper loaded: form_helper
INFO - 2016-06-06 16:13:33 --> Database Driver Class Initialized
INFO - 2016-06-06 16:13:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:13:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:13:33 --> Email Class Initialized
INFO - 2016-06-06 16:13:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:13:33 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:13:33 --> Helper loaded: language_helper
INFO - 2016-06-06 16:13:33 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:13:33 --> Model Class Initialized
INFO - 2016-06-06 16:13:33 --> Helper loaded: date_helper
INFO - 2016-06-06 16:13:33 --> Controller Class Initialized
INFO - 2016-06-06 16:13:33 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:13:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:13:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:13:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:13:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:13:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:13:33 --> Model Class Initialized
INFO - 2016-06-06 16:13:33 --> Form Validation Class Initialized
INFO - 2016-06-06 16:13:41 --> Config Class Initialized
INFO - 2016-06-06 16:13:41 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:13:41 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:13:41 --> Utf8 Class Initialized
INFO - 2016-06-06 16:13:41 --> URI Class Initialized
INFO - 2016-06-06 16:13:41 --> Router Class Initialized
INFO - 2016-06-06 16:13:41 --> Output Class Initialized
INFO - 2016-06-06 16:13:41 --> Security Class Initialized
DEBUG - 2016-06-06 16:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:13:41 --> Input Class Initialized
INFO - 2016-06-06 16:13:41 --> Language Class Initialized
INFO - 2016-06-06 16:13:41 --> Loader Class Initialized
INFO - 2016-06-06 16:13:41 --> Helper loaded: form_helper
INFO - 2016-06-06 16:13:41 --> Database Driver Class Initialized
INFO - 2016-06-06 16:13:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:13:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:13:41 --> Email Class Initialized
INFO - 2016-06-06 16:13:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:13:41 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:13:41 --> Helper loaded: language_helper
INFO - 2016-06-06 16:13:41 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:13:41 --> Model Class Initialized
INFO - 2016-06-06 16:13:41 --> Helper loaded: date_helper
INFO - 2016-06-06 16:13:41 --> Controller Class Initialized
INFO - 2016-06-06 16:13:41 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:13:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:13:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:13:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:13:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:13:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:13:41 --> Model Class Initialized
INFO - 2016-06-06 16:13:41 --> Form Validation Class Initialized
INFO - 2016-06-06 16:14:15 --> Config Class Initialized
INFO - 2016-06-06 16:14:15 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:14:15 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:14:15 --> Utf8 Class Initialized
INFO - 2016-06-06 16:14:15 --> URI Class Initialized
INFO - 2016-06-06 16:14:15 --> Router Class Initialized
INFO - 2016-06-06 16:14:15 --> Output Class Initialized
INFO - 2016-06-06 16:14:15 --> Security Class Initialized
DEBUG - 2016-06-06 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:14:15 --> Input Class Initialized
INFO - 2016-06-06 16:14:15 --> Language Class Initialized
INFO - 2016-06-06 16:14:15 --> Loader Class Initialized
INFO - 2016-06-06 16:14:15 --> Helper loaded: form_helper
INFO - 2016-06-06 16:14:15 --> Database Driver Class Initialized
INFO - 2016-06-06 16:14:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:14:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:14:15 --> Email Class Initialized
INFO - 2016-06-06 16:14:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:14:15 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:14:15 --> Helper loaded: language_helper
INFO - 2016-06-06 16:14:15 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:14:15 --> Model Class Initialized
INFO - 2016-06-06 16:14:15 --> Helper loaded: date_helper
INFO - 2016-06-06 16:14:15 --> Controller Class Initialized
INFO - 2016-06-06 16:14:15 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:14:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:14:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:14:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:14:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:14:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:14:15 --> Model Class Initialized
INFO - 2016-06-06 16:14:15 --> Form Validation Class Initialized
INFO - 2016-06-06 16:14:27 --> Config Class Initialized
INFO - 2016-06-06 16:14:27 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:14:27 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:14:27 --> Utf8 Class Initialized
INFO - 2016-06-06 16:14:27 --> URI Class Initialized
INFO - 2016-06-06 16:14:27 --> Router Class Initialized
INFO - 2016-06-06 16:14:27 --> Output Class Initialized
INFO - 2016-06-06 16:14:27 --> Security Class Initialized
DEBUG - 2016-06-06 16:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:14:27 --> Input Class Initialized
INFO - 2016-06-06 16:14:27 --> Language Class Initialized
INFO - 2016-06-06 16:14:27 --> Loader Class Initialized
INFO - 2016-06-06 16:14:27 --> Helper loaded: form_helper
INFO - 2016-06-06 16:14:27 --> Database Driver Class Initialized
INFO - 2016-06-06 16:14:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:14:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:14:27 --> Email Class Initialized
INFO - 2016-06-06 16:14:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:14:27 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:14:27 --> Helper loaded: language_helper
INFO - 2016-06-06 16:14:27 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:14:27 --> Model Class Initialized
INFO - 2016-06-06 16:14:27 --> Helper loaded: date_helper
INFO - 2016-06-06 16:14:27 --> Controller Class Initialized
INFO - 2016-06-06 16:14:27 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:14:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:14:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:14:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:14:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:14:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:14:27 --> Model Class Initialized
INFO - 2016-06-06 16:14:27 --> Form Validation Class Initialized
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:14:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:14:27 --> Final output sent to browser
DEBUG - 2016-06-06 16:14:27 --> Total execution time: 0.0355
INFO - 2016-06-06 16:14:33 --> Config Class Initialized
INFO - 2016-06-06 16:14:33 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:14:33 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:14:33 --> Utf8 Class Initialized
INFO - 2016-06-06 16:14:33 --> URI Class Initialized
INFO - 2016-06-06 16:14:33 --> Router Class Initialized
INFO - 2016-06-06 16:14:33 --> Output Class Initialized
INFO - 2016-06-06 16:14:33 --> Security Class Initialized
DEBUG - 2016-06-06 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:14:33 --> Input Class Initialized
INFO - 2016-06-06 16:14:33 --> Language Class Initialized
INFO - 2016-06-06 16:14:33 --> Loader Class Initialized
INFO - 2016-06-06 16:14:33 --> Helper loaded: form_helper
INFO - 2016-06-06 16:14:33 --> Database Driver Class Initialized
INFO - 2016-06-06 16:14:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:14:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:14:33 --> Email Class Initialized
INFO - 2016-06-06 16:14:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:14:33 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:14:33 --> Helper loaded: language_helper
INFO - 2016-06-06 16:14:33 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:14:33 --> Model Class Initialized
INFO - 2016-06-06 16:14:33 --> Helper loaded: date_helper
INFO - 2016-06-06 16:14:33 --> Controller Class Initialized
INFO - 2016-06-06 16:14:33 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:14:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:14:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:14:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:14:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:14:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:14:33 --> Model Class Initialized
INFO - 2016-06-06 16:14:33 --> Form Validation Class Initialized
INFO - 2016-06-06 16:14:33 --> Final output sent to browser
DEBUG - 2016-06-06 16:14:33 --> Total execution time: 0.0198
INFO - 2016-06-06 16:14:38 --> Config Class Initialized
INFO - 2016-06-06 16:14:38 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:14:38 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:14:38 --> Utf8 Class Initialized
INFO - 2016-06-06 16:14:38 --> URI Class Initialized
INFO - 2016-06-06 16:14:38 --> Router Class Initialized
INFO - 2016-06-06 16:14:38 --> Output Class Initialized
INFO - 2016-06-06 16:14:38 --> Security Class Initialized
DEBUG - 2016-06-06 16:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:14:38 --> Input Class Initialized
INFO - 2016-06-06 16:14:38 --> Language Class Initialized
INFO - 2016-06-06 16:14:38 --> Loader Class Initialized
INFO - 2016-06-06 16:14:38 --> Helper loaded: form_helper
INFO - 2016-06-06 16:14:38 --> Database Driver Class Initialized
INFO - 2016-06-06 16:14:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:14:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:14:38 --> Email Class Initialized
INFO - 2016-06-06 16:14:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:14:38 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:14:38 --> Helper loaded: language_helper
INFO - 2016-06-06 16:14:38 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:14:38 --> Model Class Initialized
INFO - 2016-06-06 16:14:38 --> Helper loaded: date_helper
INFO - 2016-06-06 16:14:38 --> Controller Class Initialized
INFO - 2016-06-06 16:14:38 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:14:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:14:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:14:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:14:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:14:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:14:38 --> Model Class Initialized
INFO - 2016-06-06 16:14:38 --> Form Validation Class Initialized
INFO - 2016-06-06 16:14:38 --> Final output sent to browser
DEBUG - 2016-06-06 16:14:38 --> Total execution time: 0.0324
INFO - 2016-06-06 16:14:50 --> Config Class Initialized
INFO - 2016-06-06 16:14:50 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:14:50 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:14:50 --> Utf8 Class Initialized
INFO - 2016-06-06 16:14:50 --> URI Class Initialized
INFO - 2016-06-06 16:14:50 --> Router Class Initialized
INFO - 2016-06-06 16:14:50 --> Output Class Initialized
INFO - 2016-06-06 16:14:50 --> Security Class Initialized
DEBUG - 2016-06-06 16:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:14:50 --> Input Class Initialized
INFO - 2016-06-06 16:14:50 --> Language Class Initialized
INFO - 2016-06-06 16:14:50 --> Loader Class Initialized
INFO - 2016-06-06 16:14:50 --> Helper loaded: form_helper
INFO - 2016-06-06 16:14:50 --> Database Driver Class Initialized
INFO - 2016-06-06 16:14:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:14:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:14:50 --> Email Class Initialized
INFO - 2016-06-06 16:14:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:14:50 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:14:50 --> Helper loaded: language_helper
INFO - 2016-06-06 16:14:50 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:14:50 --> Model Class Initialized
INFO - 2016-06-06 16:14:50 --> Helper loaded: date_helper
INFO - 2016-06-06 16:14:50 --> Controller Class Initialized
INFO - 2016-06-06 16:14:50 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:14:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:14:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:14:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:14:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:14:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:14:50 --> Model Class Initialized
INFO - 2016-06-06 16:14:50 --> Form Validation Class Initialized
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:14:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:14:50 --> Final output sent to browser
DEBUG - 2016-06-06 16:14:50 --> Total execution time: 0.0942
INFO - 2016-06-06 16:14:55 --> Config Class Initialized
INFO - 2016-06-06 16:14:55 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:14:55 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:14:55 --> Utf8 Class Initialized
INFO - 2016-06-06 16:14:55 --> URI Class Initialized
INFO - 2016-06-06 16:14:55 --> Router Class Initialized
INFO - 2016-06-06 16:14:55 --> Output Class Initialized
INFO - 2016-06-06 16:14:55 --> Security Class Initialized
DEBUG - 2016-06-06 16:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:14:55 --> Input Class Initialized
INFO - 2016-06-06 16:14:55 --> Language Class Initialized
INFO - 2016-06-06 16:14:55 --> Loader Class Initialized
INFO - 2016-06-06 16:14:55 --> Helper loaded: form_helper
INFO - 2016-06-06 16:14:55 --> Database Driver Class Initialized
INFO - 2016-06-06 16:14:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:14:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:14:55 --> Email Class Initialized
INFO - 2016-06-06 16:14:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:14:55 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:14:55 --> Helper loaded: language_helper
INFO - 2016-06-06 16:14:55 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:14:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:14:55 --> Model Class Initialized
INFO - 2016-06-06 16:14:55 --> Helper loaded: date_helper
INFO - 2016-06-06 16:14:55 --> Controller Class Initialized
INFO - 2016-06-06 16:14:55 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:14:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:14:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:14:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:14:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:14:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:14:55 --> Model Class Initialized
INFO - 2016-06-06 16:14:55 --> Form Validation Class Initialized
INFO - 2016-06-06 16:14:55 --> Final output sent to browser
DEBUG - 2016-06-06 16:14:55 --> Total execution time: 0.0549
INFO - 2016-06-06 16:21:28 --> Config Class Initialized
INFO - 2016-06-06 16:21:28 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:28 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:28 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:28 --> URI Class Initialized
INFO - 2016-06-06 16:21:28 --> Router Class Initialized
INFO - 2016-06-06 16:21:28 --> Output Class Initialized
INFO - 2016-06-06 16:21:28 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:28 --> Input Class Initialized
INFO - 2016-06-06 16:21:28 --> Language Class Initialized
INFO - 2016-06-06 16:21:28 --> Loader Class Initialized
INFO - 2016-06-06 16:21:28 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:28 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:28 --> Email Class Initialized
INFO - 2016-06-06 16:21:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:28 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:28 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:28 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:28 --> Model Class Initialized
INFO - 2016-06-06 16:21:28 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:28 --> Controller Class Initialized
INFO - 2016-06-06 16:21:28 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:28 --> Model Class Initialized
INFO - 2016-06-06 16:21:28 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:21:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:21:28 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:28 --> Total execution time: 0.0335
INFO - 2016-06-06 16:21:36 --> Config Class Initialized
INFO - 2016-06-06 16:21:36 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:36 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:36 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:36 --> URI Class Initialized
INFO - 2016-06-06 16:21:36 --> Router Class Initialized
INFO - 2016-06-06 16:21:36 --> Output Class Initialized
INFO - 2016-06-06 16:21:36 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:36 --> Input Class Initialized
INFO - 2016-06-06 16:21:36 --> Language Class Initialized
INFO - 2016-06-06 16:21:36 --> Loader Class Initialized
INFO - 2016-06-06 16:21:36 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:36 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:36 --> Email Class Initialized
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:36 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:36 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:36 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:36 --> Model Class Initialized
INFO - 2016-06-06 16:21:36 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:36 --> Controller Class Initialized
INFO - 2016-06-06 16:21:36 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:36 --> Model Class Initialized
INFO - 2016-06-06 16:21:36 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:36 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:36 --> Total execution time: 0.0586
INFO - 2016-06-06 16:21:36 --> Config Class Initialized
INFO - 2016-06-06 16:21:36 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:36 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:36 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:36 --> URI Class Initialized
INFO - 2016-06-06 16:21:36 --> Router Class Initialized
INFO - 2016-06-06 16:21:36 --> Output Class Initialized
INFO - 2016-06-06 16:21:36 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:36 --> Input Class Initialized
INFO - 2016-06-06 16:21:36 --> Language Class Initialized
INFO - 2016-06-06 16:21:36 --> Loader Class Initialized
INFO - 2016-06-06 16:21:36 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:36 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:36 --> Email Class Initialized
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:36 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:36 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:36 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:36 --> Model Class Initialized
INFO - 2016-06-06 16:21:36 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:36 --> Controller Class Initialized
INFO - 2016-06-06 16:21:36 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:36 --> Model Class Initialized
INFO - 2016-06-06 16:21:36 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:21:36 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:36 --> Total execution time: 0.0274
INFO - 2016-06-06 16:21:40 --> Config Class Initialized
INFO - 2016-06-06 16:21:40 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:40 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:40 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:40 --> URI Class Initialized
INFO - 2016-06-06 16:21:40 --> Router Class Initialized
INFO - 2016-06-06 16:21:40 --> Output Class Initialized
INFO - 2016-06-06 16:21:40 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:40 --> Input Class Initialized
INFO - 2016-06-06 16:21:40 --> Language Class Initialized
INFO - 2016-06-06 16:21:40 --> Loader Class Initialized
INFO - 2016-06-06 16:21:40 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:40 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:40 --> Email Class Initialized
INFO - 2016-06-06 16:21:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:40 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:40 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:40 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:40 --> Model Class Initialized
INFO - 2016-06-06 16:21:40 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:40 --> Controller Class Initialized
INFO - 2016-06-06 16:21:40 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:40 --> Model Class Initialized
INFO - 2016-06-06 16:21:40 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:40 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:40 --> Total execution time: 0.0575
INFO - 2016-06-06 16:21:40 --> Config Class Initialized
INFO - 2016-06-06 16:21:40 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:40 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:40 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:40 --> URI Class Initialized
INFO - 2016-06-06 16:21:40 --> Router Class Initialized
INFO - 2016-06-06 16:21:41 --> Output Class Initialized
INFO - 2016-06-06 16:21:41 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:41 --> Input Class Initialized
INFO - 2016-06-06 16:21:41 --> Language Class Initialized
INFO - 2016-06-06 16:21:41 --> Loader Class Initialized
INFO - 2016-06-06 16:21:41 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:41 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:41 --> Email Class Initialized
INFO - 2016-06-06 16:21:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:41 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:41 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:41 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:41 --> Model Class Initialized
INFO - 2016-06-06 16:21:41 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:41 --> Controller Class Initialized
INFO - 2016-06-06 16:21:41 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:41 --> Model Class Initialized
INFO - 2016-06-06 16:21:41 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:21:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:21:41 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:41 --> Total execution time: 0.0654
INFO - 2016-06-06 16:21:48 --> Config Class Initialized
INFO - 2016-06-06 16:21:48 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:48 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:48 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:48 --> URI Class Initialized
INFO - 2016-06-06 16:21:48 --> Router Class Initialized
INFO - 2016-06-06 16:21:48 --> Output Class Initialized
INFO - 2016-06-06 16:21:48 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:48 --> Input Class Initialized
INFO - 2016-06-06 16:21:48 --> Language Class Initialized
INFO - 2016-06-06 16:21:48 --> Loader Class Initialized
INFO - 2016-06-06 16:21:48 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:48 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:48 --> Email Class Initialized
INFO - 2016-06-06 16:21:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:48 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:48 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:48 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:48 --> Model Class Initialized
INFO - 2016-06-06 16:21:48 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:48 --> Controller Class Initialized
INFO - 2016-06-06 16:21:48 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:48 --> Model Class Initialized
INFO - 2016-06-06 16:21:48 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:48 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:48 --> Total execution time: 0.0574
INFO - 2016-06-06 16:21:49 --> Config Class Initialized
INFO - 2016-06-06 16:21:49 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:49 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:49 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:49 --> URI Class Initialized
INFO - 2016-06-06 16:21:49 --> Router Class Initialized
INFO - 2016-06-06 16:21:49 --> Output Class Initialized
INFO - 2016-06-06 16:21:49 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:49 --> Input Class Initialized
INFO - 2016-06-06 16:21:49 --> Language Class Initialized
INFO - 2016-06-06 16:21:49 --> Loader Class Initialized
INFO - 2016-06-06 16:21:49 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:49 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:49 --> Email Class Initialized
INFO - 2016-06-06 16:21:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:49 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:49 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:49 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:49 --> Model Class Initialized
INFO - 2016-06-06 16:21:49 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:49 --> Controller Class Initialized
INFO - 2016-06-06 16:21:49 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:49 --> Model Class Initialized
INFO - 2016-06-06 16:21:49 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:21:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:21:49 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:49 --> Total execution time: 0.0350
INFO - 2016-06-06 16:21:56 --> Config Class Initialized
INFO - 2016-06-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:56 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:56 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:56 --> URI Class Initialized
INFO - 2016-06-06 16:21:56 --> Router Class Initialized
INFO - 2016-06-06 16:21:56 --> Output Class Initialized
INFO - 2016-06-06 16:21:56 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:56 --> Input Class Initialized
INFO - 2016-06-06 16:21:56 --> Language Class Initialized
INFO - 2016-06-06 16:21:56 --> Loader Class Initialized
INFO - 2016-06-06 16:21:56 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:56 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:56 --> Email Class Initialized
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:56 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:56 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:56 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:56 --> Model Class Initialized
INFO - 2016-06-06 16:21:56 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:56 --> Controller Class Initialized
INFO - 2016-06-06 16:21:56 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:56 --> Model Class Initialized
INFO - 2016-06-06 16:21:56 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:56 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:56 --> Total execution time: 0.0429
INFO - 2016-06-06 16:21:56 --> Config Class Initialized
INFO - 2016-06-06 16:21:56 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:21:56 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:21:56 --> Utf8 Class Initialized
INFO - 2016-06-06 16:21:56 --> URI Class Initialized
INFO - 2016-06-06 16:21:56 --> Router Class Initialized
INFO - 2016-06-06 16:21:56 --> Output Class Initialized
INFO - 2016-06-06 16:21:56 --> Security Class Initialized
DEBUG - 2016-06-06 16:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:21:56 --> Input Class Initialized
INFO - 2016-06-06 16:21:56 --> Language Class Initialized
INFO - 2016-06-06 16:21:56 --> Loader Class Initialized
INFO - 2016-06-06 16:21:56 --> Helper loaded: form_helper
INFO - 2016-06-06 16:21:56 --> Database Driver Class Initialized
INFO - 2016-06-06 16:21:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:21:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:21:56 --> Email Class Initialized
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:21:56 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:21:56 --> Helper loaded: language_helper
INFO - 2016-06-06 16:21:56 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:21:56 --> Model Class Initialized
INFO - 2016-06-06 16:21:56 --> Helper loaded: date_helper
INFO - 2016-06-06 16:21:56 --> Controller Class Initialized
INFO - 2016-06-06 16:21:56 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:21:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:21:56 --> Model Class Initialized
INFO - 2016-06-06 16:21:56 --> Form Validation Class Initialized
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:21:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:21:56 --> Final output sent to browser
DEBUG - 2016-06-06 16:21:56 --> Total execution time: 0.0387
INFO - 2016-06-06 16:22:02 --> Config Class Initialized
INFO - 2016-06-06 16:22:02 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:22:02 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:22:02 --> Utf8 Class Initialized
INFO - 2016-06-06 16:22:02 --> URI Class Initialized
INFO - 2016-06-06 16:22:02 --> Router Class Initialized
INFO - 2016-06-06 16:22:02 --> Output Class Initialized
INFO - 2016-06-06 16:22:02 --> Security Class Initialized
DEBUG - 2016-06-06 16:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:22:02 --> Input Class Initialized
INFO - 2016-06-06 16:22:02 --> Language Class Initialized
INFO - 2016-06-06 16:22:02 --> Loader Class Initialized
INFO - 2016-06-06 16:22:02 --> Helper loaded: form_helper
INFO - 2016-06-06 16:22:02 --> Database Driver Class Initialized
INFO - 2016-06-06 16:22:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:22:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:22:02 --> Email Class Initialized
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:22:02 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:22:02 --> Helper loaded: language_helper
INFO - 2016-06-06 16:22:02 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:22:02 --> Model Class Initialized
INFO - 2016-06-06 16:22:02 --> Helper loaded: date_helper
INFO - 2016-06-06 16:22:02 --> Controller Class Initialized
INFO - 2016-06-06 16:22:02 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:22:02 --> Model Class Initialized
INFO - 2016-06-06 16:22:02 --> Form Validation Class Initialized
INFO - 2016-06-06 16:22:02 --> Final output sent to browser
DEBUG - 2016-06-06 16:22:02 --> Total execution time: 0.0562
INFO - 2016-06-06 16:22:02 --> Config Class Initialized
INFO - 2016-06-06 16:22:02 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:22:02 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:22:02 --> Utf8 Class Initialized
INFO - 2016-06-06 16:22:02 --> URI Class Initialized
INFO - 2016-06-06 16:22:02 --> Router Class Initialized
INFO - 2016-06-06 16:22:02 --> Output Class Initialized
INFO - 2016-06-06 16:22:02 --> Security Class Initialized
DEBUG - 2016-06-06 16:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:22:02 --> Input Class Initialized
INFO - 2016-06-06 16:22:02 --> Language Class Initialized
INFO - 2016-06-06 16:22:02 --> Loader Class Initialized
INFO - 2016-06-06 16:22:02 --> Helper loaded: form_helper
INFO - 2016-06-06 16:22:02 --> Database Driver Class Initialized
INFO - 2016-06-06 16:22:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:22:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:22:02 --> Email Class Initialized
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:22:02 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:22:02 --> Helper loaded: language_helper
INFO - 2016-06-06 16:22:02 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:22:02 --> Model Class Initialized
INFO - 2016-06-06 16:22:02 --> Helper loaded: date_helper
INFO - 2016-06-06 16:22:02 --> Controller Class Initialized
INFO - 2016-06-06 16:22:02 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:22:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:22:02 --> Model Class Initialized
INFO - 2016-06-06 16:22:02 --> Form Validation Class Initialized
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:22:02 --> Final output sent to browser
DEBUG - 2016-06-06 16:22:02 --> Total execution time: 0.0275
INFO - 2016-06-06 16:22:09 --> Config Class Initialized
INFO - 2016-06-06 16:22:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:22:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:22:09 --> Utf8 Class Initialized
INFO - 2016-06-06 16:22:09 --> URI Class Initialized
INFO - 2016-06-06 16:22:09 --> Router Class Initialized
INFO - 2016-06-06 16:22:09 --> Output Class Initialized
INFO - 2016-06-06 16:22:09 --> Security Class Initialized
DEBUG - 2016-06-06 16:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:22:09 --> Input Class Initialized
INFO - 2016-06-06 16:22:09 --> Language Class Initialized
INFO - 2016-06-06 16:22:09 --> Loader Class Initialized
INFO - 2016-06-06 16:22:09 --> Helper loaded: form_helper
INFO - 2016-06-06 16:22:09 --> Database Driver Class Initialized
INFO - 2016-06-06 16:22:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:22:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:22:09 --> Email Class Initialized
INFO - 2016-06-06 16:22:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:22:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:22:09 --> Helper loaded: language_helper
INFO - 2016-06-06 16:22:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:22:09 --> Model Class Initialized
INFO - 2016-06-06 16:22:09 --> Helper loaded: date_helper
INFO - 2016-06-06 16:22:09 --> Controller Class Initialized
INFO - 2016-06-06 16:22:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:22:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:22:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:22:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:22:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:22:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:22:09 --> Model Class Initialized
INFO - 2016-06-06 16:22:09 --> Form Validation Class Initialized
INFO - 2016-06-06 16:22:09 --> Final output sent to browser
DEBUG - 2016-06-06 16:22:09 --> Total execution time: 0.0470
INFO - 2016-06-06 16:22:10 --> Config Class Initialized
INFO - 2016-06-06 16:22:10 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:22:10 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:22:10 --> Utf8 Class Initialized
INFO - 2016-06-06 16:22:10 --> URI Class Initialized
INFO - 2016-06-06 16:22:10 --> Router Class Initialized
INFO - 2016-06-06 16:22:10 --> Output Class Initialized
INFO - 2016-06-06 16:22:10 --> Security Class Initialized
DEBUG - 2016-06-06 16:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:22:10 --> Input Class Initialized
INFO - 2016-06-06 16:22:10 --> Language Class Initialized
INFO - 2016-06-06 16:22:10 --> Loader Class Initialized
INFO - 2016-06-06 16:22:10 --> Helper loaded: form_helper
INFO - 2016-06-06 16:22:10 --> Database Driver Class Initialized
INFO - 2016-06-06 16:22:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:22:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:22:10 --> Email Class Initialized
INFO - 2016-06-06 16:22:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:22:10 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:22:10 --> Helper loaded: language_helper
INFO - 2016-06-06 16:22:10 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:22:10 --> Model Class Initialized
INFO - 2016-06-06 16:22:10 --> Helper loaded: date_helper
INFO - 2016-06-06 16:22:10 --> Controller Class Initialized
INFO - 2016-06-06 16:22:10 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:22:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:22:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:22:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:22:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:22:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:22:10 --> Model Class Initialized
INFO - 2016-06-06 16:22:10 --> Form Validation Class Initialized
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:22:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:22:10 --> Final output sent to browser
DEBUG - 2016-06-06 16:22:10 --> Total execution time: 0.0253
INFO - 2016-06-06 16:22:16 --> Config Class Initialized
INFO - 2016-06-06 16:22:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:22:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:22:16 --> Utf8 Class Initialized
INFO - 2016-06-06 16:22:16 --> URI Class Initialized
INFO - 2016-06-06 16:22:16 --> Router Class Initialized
INFO - 2016-06-06 16:22:16 --> Output Class Initialized
INFO - 2016-06-06 16:22:16 --> Security Class Initialized
DEBUG - 2016-06-06 16:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:22:16 --> Input Class Initialized
INFO - 2016-06-06 16:22:16 --> Language Class Initialized
INFO - 2016-06-06 16:22:16 --> Loader Class Initialized
INFO - 2016-06-06 16:22:16 --> Helper loaded: form_helper
INFO - 2016-06-06 16:22:16 --> Database Driver Class Initialized
INFO - 2016-06-06 16:22:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:22:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:22:16 --> Email Class Initialized
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:22:16 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:22:16 --> Helper loaded: language_helper
INFO - 2016-06-06 16:22:16 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:22:16 --> Model Class Initialized
INFO - 2016-06-06 16:22:16 --> Helper loaded: date_helper
INFO - 2016-06-06 16:22:16 --> Controller Class Initialized
INFO - 2016-06-06 16:22:16 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:22:16 --> Model Class Initialized
INFO - 2016-06-06 16:22:16 --> Form Validation Class Initialized
INFO - 2016-06-06 16:22:16 --> Final output sent to browser
DEBUG - 2016-06-06 16:22:16 --> Total execution time: 0.0556
INFO - 2016-06-06 16:22:16 --> Config Class Initialized
INFO - 2016-06-06 16:22:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:22:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:22:16 --> Utf8 Class Initialized
INFO - 2016-06-06 16:22:16 --> URI Class Initialized
INFO - 2016-06-06 16:22:16 --> Router Class Initialized
INFO - 2016-06-06 16:22:16 --> Output Class Initialized
INFO - 2016-06-06 16:22:16 --> Security Class Initialized
DEBUG - 2016-06-06 16:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:22:16 --> Input Class Initialized
INFO - 2016-06-06 16:22:16 --> Language Class Initialized
INFO - 2016-06-06 16:22:16 --> Loader Class Initialized
INFO - 2016-06-06 16:22:16 --> Helper loaded: form_helper
INFO - 2016-06-06 16:22:16 --> Database Driver Class Initialized
INFO - 2016-06-06 16:22:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:22:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:22:16 --> Email Class Initialized
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:22:16 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:22:16 --> Helper loaded: language_helper
INFO - 2016-06-06 16:22:16 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:22:16 --> Model Class Initialized
INFO - 2016-06-06 16:22:16 --> Helper loaded: date_helper
INFO - 2016-06-06 16:22:16 --> Controller Class Initialized
INFO - 2016-06-06 16:22:16 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:22:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:22:16 --> Model Class Initialized
INFO - 2016-06-06 16:22:16 --> Form Validation Class Initialized
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:22:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:22:16 --> Final output sent to browser
DEBUG - 2016-06-06 16:22:16 --> Total execution time: 0.0297
INFO - 2016-06-06 16:22:22 --> Config Class Initialized
INFO - 2016-06-06 16:22:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:22:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:22:22 --> Utf8 Class Initialized
INFO - 2016-06-06 16:22:22 --> URI Class Initialized
INFO - 2016-06-06 16:22:22 --> Router Class Initialized
INFO - 2016-06-06 16:22:22 --> Output Class Initialized
INFO - 2016-06-06 16:22:22 --> Security Class Initialized
DEBUG - 2016-06-06 16:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:22:22 --> Input Class Initialized
INFO - 2016-06-06 16:22:22 --> Language Class Initialized
INFO - 2016-06-06 16:22:22 --> Loader Class Initialized
INFO - 2016-06-06 16:22:22 --> Helper loaded: form_helper
INFO - 2016-06-06 16:22:22 --> Database Driver Class Initialized
INFO - 2016-06-06 16:22:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:22:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:22:22 --> Email Class Initialized
INFO - 2016-06-06 16:22:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:22:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:22:22 --> Helper loaded: language_helper
INFO - 2016-06-06 16:22:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:22:22 --> Model Class Initialized
INFO - 2016-06-06 16:22:22 --> Helper loaded: date_helper
INFO - 2016-06-06 16:22:22 --> Controller Class Initialized
INFO - 2016-06-06 16:22:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:22:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:22:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:22:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:22:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:22:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:22:22 --> Model Class Initialized
INFO - 2016-06-06 16:22:22 --> Form Validation Class Initialized
INFO - 2016-06-06 16:22:22 --> Final output sent to browser
DEBUG - 2016-06-06 16:22:22 --> Total execution time: 0.0671
INFO - 2016-06-06 16:26:04 --> Config Class Initialized
INFO - 2016-06-06 16:26:04 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:26:04 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:26:04 --> Utf8 Class Initialized
INFO - 2016-06-06 16:26:04 --> URI Class Initialized
INFO - 2016-06-06 16:26:04 --> Router Class Initialized
INFO - 2016-06-06 16:26:04 --> Output Class Initialized
INFO - 2016-06-06 16:26:04 --> Security Class Initialized
DEBUG - 2016-06-06 16:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:26:04 --> Input Class Initialized
INFO - 2016-06-06 16:26:04 --> Language Class Initialized
INFO - 2016-06-06 16:26:04 --> Loader Class Initialized
INFO - 2016-06-06 16:26:04 --> Helper loaded: form_helper
INFO - 2016-06-06 16:26:04 --> Database Driver Class Initialized
INFO - 2016-06-06 16:26:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:26:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:26:04 --> Email Class Initialized
INFO - 2016-06-06 16:26:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:26:04 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:26:04 --> Helper loaded: language_helper
INFO - 2016-06-06 16:26:04 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:26:04 --> Model Class Initialized
INFO - 2016-06-06 16:26:04 --> Helper loaded: date_helper
INFO - 2016-06-06 16:26:04 --> Controller Class Initialized
INFO - 2016-06-06 16:26:04 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:26:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:26:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:26:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:26:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:26:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:26:04 --> Model Class Initialized
INFO - 2016-06-06 16:26:04 --> Form Validation Class Initialized
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:26:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:26:04 --> Final output sent to browser
DEBUG - 2016-06-06 16:26:04 --> Total execution time: 0.0574
INFO - 2016-06-06 16:26:09 --> Config Class Initialized
INFO - 2016-06-06 16:26:09 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:26:09 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:26:09 --> Utf8 Class Initialized
INFO - 2016-06-06 16:26:09 --> URI Class Initialized
INFO - 2016-06-06 16:26:09 --> Router Class Initialized
INFO - 2016-06-06 16:26:09 --> Output Class Initialized
INFO - 2016-06-06 16:26:09 --> Security Class Initialized
DEBUG - 2016-06-06 16:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:26:09 --> Input Class Initialized
INFO - 2016-06-06 16:26:09 --> Language Class Initialized
INFO - 2016-06-06 16:26:09 --> Loader Class Initialized
INFO - 2016-06-06 16:26:09 --> Helper loaded: form_helper
INFO - 2016-06-06 16:26:09 --> Database Driver Class Initialized
INFO - 2016-06-06 16:26:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:26:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:26:09 --> Email Class Initialized
INFO - 2016-06-06 16:26:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:26:09 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:26:09 --> Helper loaded: language_helper
INFO - 2016-06-06 16:26:09 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:26:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:26:09 --> Model Class Initialized
INFO - 2016-06-06 16:26:09 --> Helper loaded: date_helper
INFO - 2016-06-06 16:26:09 --> Controller Class Initialized
INFO - 2016-06-06 16:26:09 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:26:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:26:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:26:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:26:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:26:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:26:09 --> Model Class Initialized
INFO - 2016-06-06 16:26:09 --> Form Validation Class Initialized
INFO - 2016-06-06 16:27:19 --> Config Class Initialized
INFO - 2016-06-06 16:27:19 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:27:19 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:27:19 --> Utf8 Class Initialized
INFO - 2016-06-06 16:27:19 --> URI Class Initialized
INFO - 2016-06-06 16:27:19 --> Router Class Initialized
INFO - 2016-06-06 16:27:19 --> Output Class Initialized
INFO - 2016-06-06 16:27:19 --> Security Class Initialized
DEBUG - 2016-06-06 16:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:27:19 --> Input Class Initialized
INFO - 2016-06-06 16:27:19 --> Language Class Initialized
INFO - 2016-06-06 16:27:19 --> Loader Class Initialized
INFO - 2016-06-06 16:27:19 --> Helper loaded: form_helper
INFO - 2016-06-06 16:27:19 --> Database Driver Class Initialized
INFO - 2016-06-06 16:27:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:27:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:27:19 --> Email Class Initialized
INFO - 2016-06-06 16:27:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:27:19 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:27:19 --> Helper loaded: language_helper
INFO - 2016-06-06 16:27:19 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:27:19 --> Model Class Initialized
INFO - 2016-06-06 16:27:19 --> Helper loaded: date_helper
INFO - 2016-06-06 16:27:19 --> Controller Class Initialized
INFO - 2016-06-06 16:27:19 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:27:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:27:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:27:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:27:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:27:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:27:19 --> Model Class Initialized
INFO - 2016-06-06 16:27:19 --> Form Validation Class Initialized
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:27:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:27:19 --> Final output sent to browser
DEBUG - 2016-06-06 16:27:19 --> Total execution time: 0.0669
INFO - 2016-06-06 16:27:24 --> Config Class Initialized
INFO - 2016-06-06 16:27:24 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:27:24 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:27:24 --> Utf8 Class Initialized
INFO - 2016-06-06 16:27:24 --> URI Class Initialized
INFO - 2016-06-06 16:27:24 --> Router Class Initialized
INFO - 2016-06-06 16:27:24 --> Output Class Initialized
INFO - 2016-06-06 16:27:24 --> Security Class Initialized
DEBUG - 2016-06-06 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:27:24 --> Input Class Initialized
INFO - 2016-06-06 16:27:24 --> Language Class Initialized
INFO - 2016-06-06 16:27:24 --> Loader Class Initialized
INFO - 2016-06-06 16:27:24 --> Helper loaded: form_helper
INFO - 2016-06-06 16:27:24 --> Database Driver Class Initialized
INFO - 2016-06-06 16:27:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:27:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:27:24 --> Email Class Initialized
INFO - 2016-06-06 16:27:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:27:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:27:24 --> Helper loaded: language_helper
INFO - 2016-06-06 16:27:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:27:24 --> Model Class Initialized
INFO - 2016-06-06 16:27:24 --> Helper loaded: date_helper
INFO - 2016-06-06 16:27:24 --> Controller Class Initialized
INFO - 2016-06-06 16:27:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:27:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:27:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:27:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:27:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:27:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:27:24 --> Model Class Initialized
INFO - 2016-06-06 16:27:24 --> Form Validation Class Initialized
INFO - 2016-06-06 16:27:24 --> Final output sent to browser
DEBUG - 2016-06-06 16:27:24 --> Total execution time: 0.0374
INFO - 2016-06-06 16:27:34 --> Config Class Initialized
INFO - 2016-06-06 16:27:34 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:27:34 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:27:34 --> Utf8 Class Initialized
INFO - 2016-06-06 16:27:34 --> URI Class Initialized
INFO - 2016-06-06 16:27:34 --> Router Class Initialized
INFO - 2016-06-06 16:27:34 --> Output Class Initialized
INFO - 2016-06-06 16:27:34 --> Security Class Initialized
DEBUG - 2016-06-06 16:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:27:34 --> Input Class Initialized
INFO - 2016-06-06 16:27:34 --> Language Class Initialized
INFO - 2016-06-06 16:27:34 --> Loader Class Initialized
INFO - 2016-06-06 16:27:34 --> Helper loaded: form_helper
INFO - 2016-06-06 16:27:34 --> Database Driver Class Initialized
INFO - 2016-06-06 16:27:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:27:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:27:34 --> Email Class Initialized
INFO - 2016-06-06 16:27:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:27:34 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:27:34 --> Helper loaded: language_helper
INFO - 2016-06-06 16:27:34 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:27:34 --> Model Class Initialized
INFO - 2016-06-06 16:27:34 --> Helper loaded: date_helper
INFO - 2016-06-06 16:27:34 --> Controller Class Initialized
INFO - 2016-06-06 16:27:34 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:27:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:27:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:27:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:27:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:27:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:27:34 --> Model Class Initialized
INFO - 2016-06-06 16:27:34 --> Form Validation Class Initialized
INFO - 2016-06-06 16:27:34 --> Final output sent to browser
DEBUG - 2016-06-06 16:27:34 --> Total execution time: 0.1924
INFO - 2016-06-06 16:27:51 --> Config Class Initialized
INFO - 2016-06-06 16:27:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:27:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:27:51 --> Utf8 Class Initialized
INFO - 2016-06-06 16:27:51 --> URI Class Initialized
INFO - 2016-06-06 16:27:51 --> Router Class Initialized
INFO - 2016-06-06 16:27:51 --> Output Class Initialized
INFO - 2016-06-06 16:27:51 --> Security Class Initialized
DEBUG - 2016-06-06 16:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:27:51 --> Input Class Initialized
INFO - 2016-06-06 16:27:51 --> Language Class Initialized
INFO - 2016-06-06 16:27:51 --> Loader Class Initialized
INFO - 2016-06-06 16:27:51 --> Helper loaded: form_helper
INFO - 2016-06-06 16:27:51 --> Database Driver Class Initialized
INFO - 2016-06-06 16:27:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:27:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:27:51 --> Email Class Initialized
INFO - 2016-06-06 16:27:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:27:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:27:51 --> Helper loaded: language_helper
INFO - 2016-06-06 16:27:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:27:51 --> Model Class Initialized
INFO - 2016-06-06 16:27:51 --> Helper loaded: date_helper
INFO - 2016-06-06 16:27:51 --> Controller Class Initialized
INFO - 2016-06-06 16:27:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:27:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:27:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:27:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:27:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:27:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:27:51 --> Model Class Initialized
INFO - 2016-06-06 16:27:51 --> Form Validation Class Initialized
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 31
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 38
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 45
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 52
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 59
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 67
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 81
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 88
ERROR - 2016-06-06 16:27:51 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 95
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:27:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:27:51 --> Final output sent to browser
DEBUG - 2016-06-06 16:27:51 --> Total execution time: 0.0568
INFO - 2016-06-06 16:27:55 --> Config Class Initialized
INFO - 2016-06-06 16:27:55 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:27:55 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:27:55 --> Utf8 Class Initialized
INFO - 2016-06-06 16:27:55 --> URI Class Initialized
INFO - 2016-06-06 16:27:55 --> Router Class Initialized
INFO - 2016-06-06 16:27:55 --> Output Class Initialized
INFO - 2016-06-06 16:27:55 --> Security Class Initialized
DEBUG - 2016-06-06 16:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:27:55 --> Input Class Initialized
INFO - 2016-06-06 16:27:55 --> Language Class Initialized
INFO - 2016-06-06 16:27:55 --> Loader Class Initialized
INFO - 2016-06-06 16:27:55 --> Helper loaded: form_helper
INFO - 2016-06-06 16:27:55 --> Database Driver Class Initialized
INFO - 2016-06-06 16:27:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:27:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:27:55 --> Email Class Initialized
INFO - 2016-06-06 16:27:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:27:55 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:27:55 --> Helper loaded: language_helper
INFO - 2016-06-06 16:27:55 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:27:55 --> Model Class Initialized
INFO - 2016-06-06 16:27:55 --> Helper loaded: date_helper
INFO - 2016-06-06 16:27:55 --> Controller Class Initialized
INFO - 2016-06-06 16:27:55 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:27:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:27:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:27:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:27:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:27:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:27:55 --> Model Class Initialized
INFO - 2016-06-06 16:27:55 --> Form Validation Class Initialized
INFO - 2016-06-06 16:27:55 --> Final output sent to browser
DEBUG - 2016-06-06 16:27:55 --> Total execution time: 0.1033
INFO - 2016-06-06 16:28:15 --> Config Class Initialized
INFO - 2016-06-06 16:28:15 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:28:15 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:28:15 --> Utf8 Class Initialized
INFO - 2016-06-06 16:28:15 --> URI Class Initialized
INFO - 2016-06-06 16:28:15 --> Router Class Initialized
INFO - 2016-06-06 16:28:15 --> Output Class Initialized
INFO - 2016-06-06 16:28:15 --> Security Class Initialized
DEBUG - 2016-06-06 16:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:28:15 --> Input Class Initialized
INFO - 2016-06-06 16:28:15 --> Language Class Initialized
INFO - 2016-06-06 16:28:15 --> Loader Class Initialized
INFO - 2016-06-06 16:28:15 --> Helper loaded: form_helper
INFO - 2016-06-06 16:28:15 --> Database Driver Class Initialized
INFO - 2016-06-06 16:28:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:28:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:28:15 --> Email Class Initialized
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:28:15 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:28:15 --> Helper loaded: language_helper
INFO - 2016-06-06 16:28:15 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:28:15 --> Model Class Initialized
INFO - 2016-06-06 16:28:15 --> Helper loaded: date_helper
INFO - 2016-06-06 16:28:15 --> Controller Class Initialized
INFO - 2016-06-06 16:28:15 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:28:15 --> Model Class Initialized
INFO - 2016-06-06 16:28:15 --> Form Validation Class Initialized
INFO - 2016-06-06 16:28:15 --> Config Class Initialized
INFO - 2016-06-06 16:28:15 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:28:15 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:28:15 --> Utf8 Class Initialized
INFO - 2016-06-06 16:28:15 --> URI Class Initialized
INFO - 2016-06-06 16:28:15 --> Router Class Initialized
INFO - 2016-06-06 16:28:15 --> Output Class Initialized
INFO - 2016-06-06 16:28:15 --> Security Class Initialized
DEBUG - 2016-06-06 16:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:28:15 --> Input Class Initialized
INFO - 2016-06-06 16:28:15 --> Language Class Initialized
INFO - 2016-06-06 16:28:15 --> Loader Class Initialized
INFO - 2016-06-06 16:28:15 --> Helper loaded: form_helper
INFO - 2016-06-06 16:28:15 --> Database Driver Class Initialized
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 31
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 38
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 45
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 52
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 59
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 67
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 81
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 88
ERROR - 2016-06-06 16:28:15 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 95
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:28:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:28:15 --> Final output sent to browser
DEBUG - 2016-06-06 16:28:15 --> Total execution time: 0.0345
INFO - 2016-06-06 16:28:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:28:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:28:15 --> Email Class Initialized
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:28:15 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:28:15 --> Helper loaded: language_helper
INFO - 2016-06-06 16:28:15 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:28:15 --> Model Class Initialized
INFO - 2016-06-06 16:28:15 --> Helper loaded: date_helper
INFO - 2016-06-06 16:28:15 --> Controller Class Initialized
INFO - 2016-06-06 16:28:15 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:28:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:28:15 --> Model Class Initialized
INFO - 2016-06-06 16:28:15 --> Form Validation Class Initialized
INFO - 2016-06-06 16:28:15 --> Final output sent to browser
DEBUG - 2016-06-06 16:28:15 --> Total execution time: 0.0281
INFO - 2016-06-06 16:28:19 --> Config Class Initialized
INFO - 2016-06-06 16:28:19 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:28:19 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:28:19 --> Utf8 Class Initialized
INFO - 2016-06-06 16:28:19 --> URI Class Initialized
INFO - 2016-06-06 16:28:19 --> Router Class Initialized
INFO - 2016-06-06 16:28:19 --> Output Class Initialized
INFO - 2016-06-06 16:28:19 --> Security Class Initialized
DEBUG - 2016-06-06 16:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:28:19 --> Input Class Initialized
INFO - 2016-06-06 16:28:19 --> Language Class Initialized
INFO - 2016-06-06 16:28:19 --> Loader Class Initialized
INFO - 2016-06-06 16:28:19 --> Helper loaded: form_helper
INFO - 2016-06-06 16:28:19 --> Database Driver Class Initialized
INFO - 2016-06-06 16:28:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:28:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:28:19 --> Email Class Initialized
INFO - 2016-06-06 16:28:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:28:19 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:28:19 --> Helper loaded: language_helper
INFO - 2016-06-06 16:28:19 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:28:19 --> Model Class Initialized
INFO - 2016-06-06 16:28:19 --> Helper loaded: date_helper
INFO - 2016-06-06 16:28:19 --> Controller Class Initialized
INFO - 2016-06-06 16:28:19 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:28:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:28:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:28:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:28:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:28:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:28:19 --> Model Class Initialized
INFO - 2016-06-06 16:28:19 --> Form Validation Class Initialized
INFO - 2016-06-06 16:28:19 --> Final output sent to browser
DEBUG - 2016-06-06 16:28:19 --> Total execution time: 0.0463
INFO - 2016-06-06 16:29:05 --> Config Class Initialized
INFO - 2016-06-06 16:29:05 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:29:05 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:29:05 --> Utf8 Class Initialized
INFO - 2016-06-06 16:29:05 --> URI Class Initialized
INFO - 2016-06-06 16:29:05 --> Router Class Initialized
INFO - 2016-06-06 16:29:05 --> Output Class Initialized
INFO - 2016-06-06 16:29:05 --> Security Class Initialized
DEBUG - 2016-06-06 16:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:29:05 --> Input Class Initialized
INFO - 2016-06-06 16:29:05 --> Language Class Initialized
INFO - 2016-06-06 16:29:05 --> Loader Class Initialized
INFO - 2016-06-06 16:29:05 --> Helper loaded: form_helper
INFO - 2016-06-06 16:29:05 --> Database Driver Class Initialized
INFO - 2016-06-06 16:29:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:29:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:29:05 --> Email Class Initialized
INFO - 2016-06-06 16:29:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:29:05 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:29:05 --> Helper loaded: language_helper
INFO - 2016-06-06 16:29:05 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:29:05 --> Model Class Initialized
INFO - 2016-06-06 16:29:05 --> Helper loaded: date_helper
INFO - 2016-06-06 16:29:05 --> Controller Class Initialized
INFO - 2016-06-06 16:29:05 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:29:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:29:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:29:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:29:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:29:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:29:05 --> Model Class Initialized
INFO - 2016-06-06 16:29:05 --> Form Validation Class Initialized
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:29:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:29:05 --> Final output sent to browser
DEBUG - 2016-06-06 16:29:05 --> Total execution time: 0.1034
INFO - 2016-06-06 16:29:10 --> Config Class Initialized
INFO - 2016-06-06 16:29:10 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:29:10 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:29:10 --> Utf8 Class Initialized
INFO - 2016-06-06 16:29:10 --> URI Class Initialized
INFO - 2016-06-06 16:29:10 --> Router Class Initialized
INFO - 2016-06-06 16:29:10 --> Output Class Initialized
INFO - 2016-06-06 16:29:10 --> Security Class Initialized
DEBUG - 2016-06-06 16:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:29:10 --> Input Class Initialized
INFO - 2016-06-06 16:29:10 --> Language Class Initialized
INFO - 2016-06-06 16:29:10 --> Loader Class Initialized
INFO - 2016-06-06 16:29:10 --> Helper loaded: form_helper
INFO - 2016-06-06 16:29:10 --> Database Driver Class Initialized
INFO - 2016-06-06 16:29:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:29:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:29:10 --> Email Class Initialized
INFO - 2016-06-06 16:29:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:29:10 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:29:10 --> Helper loaded: language_helper
INFO - 2016-06-06 16:29:10 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:29:10 --> Model Class Initialized
INFO - 2016-06-06 16:29:10 --> Helper loaded: date_helper
INFO - 2016-06-06 16:29:10 --> Controller Class Initialized
INFO - 2016-06-06 16:29:10 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:29:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:29:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:29:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:29:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:29:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:29:10 --> Model Class Initialized
INFO - 2016-06-06 16:29:10 --> Form Validation Class Initialized
INFO - 2016-06-06 16:29:10 --> Final output sent to browser
DEBUG - 2016-06-06 16:29:10 --> Total execution time: 0.0483
INFO - 2016-06-06 16:29:20 --> Config Class Initialized
INFO - 2016-06-06 16:29:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:29:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:29:20 --> Utf8 Class Initialized
INFO - 2016-06-06 16:29:20 --> URI Class Initialized
INFO - 2016-06-06 16:29:20 --> Router Class Initialized
INFO - 2016-06-06 16:29:20 --> Output Class Initialized
INFO - 2016-06-06 16:29:20 --> Security Class Initialized
DEBUG - 2016-06-06 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:29:20 --> Input Class Initialized
INFO - 2016-06-06 16:29:20 --> Language Class Initialized
INFO - 2016-06-06 16:29:20 --> Loader Class Initialized
INFO - 2016-06-06 16:29:20 --> Helper loaded: form_helper
INFO - 2016-06-06 16:29:20 --> Database Driver Class Initialized
INFO - 2016-06-06 16:29:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:29:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:29:20 --> Email Class Initialized
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:29:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:29:20 --> Helper loaded: language_helper
INFO - 2016-06-06 16:29:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:29:20 --> Model Class Initialized
INFO - 2016-06-06 16:29:20 --> Helper loaded: date_helper
INFO - 2016-06-06 16:29:20 --> Controller Class Initialized
INFO - 2016-06-06 16:29:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:29:20 --> Model Class Initialized
INFO - 2016-06-06 16:29:20 --> Form Validation Class Initialized
INFO - 2016-06-06 16:29:20 --> Final output sent to browser
DEBUG - 2016-06-06 16:29:20 --> Total execution time: 0.0336
INFO - 2016-06-06 16:29:20 --> Config Class Initialized
INFO - 2016-06-06 16:29:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:29:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:29:20 --> Utf8 Class Initialized
INFO - 2016-06-06 16:29:20 --> URI Class Initialized
INFO - 2016-06-06 16:29:20 --> Router Class Initialized
INFO - 2016-06-06 16:29:20 --> Output Class Initialized
INFO - 2016-06-06 16:29:20 --> Security Class Initialized
DEBUG - 2016-06-06 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:29:20 --> Input Class Initialized
INFO - 2016-06-06 16:29:20 --> Language Class Initialized
INFO - 2016-06-06 16:29:20 --> Loader Class Initialized
INFO - 2016-06-06 16:29:20 --> Helper loaded: form_helper
INFO - 2016-06-06 16:29:20 --> Database Driver Class Initialized
INFO - 2016-06-06 16:29:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:29:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:29:20 --> Email Class Initialized
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:29:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:29:20 --> Helper loaded: language_helper
INFO - 2016-06-06 16:29:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:29:20 --> Model Class Initialized
INFO - 2016-06-06 16:29:20 --> Helper loaded: date_helper
INFO - 2016-06-06 16:29:20 --> Controller Class Initialized
INFO - 2016-06-06 16:29:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:29:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:29:20 --> Model Class Initialized
INFO - 2016-06-06 16:29:20 --> Form Validation Class Initialized
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:29:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:29:20 --> Final output sent to browser
DEBUG - 2016-06-06 16:29:20 --> Total execution time: 0.0410
INFO - 2016-06-06 16:29:29 --> Config Class Initialized
INFO - 2016-06-06 16:29:29 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:29:29 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:29:29 --> Utf8 Class Initialized
INFO - 2016-06-06 16:29:29 --> URI Class Initialized
INFO - 2016-06-06 16:29:29 --> Router Class Initialized
INFO - 2016-06-06 16:29:29 --> Output Class Initialized
INFO - 2016-06-06 16:29:29 --> Security Class Initialized
DEBUG - 2016-06-06 16:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:29:29 --> Input Class Initialized
INFO - 2016-06-06 16:29:29 --> Language Class Initialized
INFO - 2016-06-06 16:29:29 --> Loader Class Initialized
INFO - 2016-06-06 16:29:29 --> Helper loaded: form_helper
INFO - 2016-06-06 16:29:29 --> Database Driver Class Initialized
INFO - 2016-06-06 16:29:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:29:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:29:29 --> Email Class Initialized
INFO - 2016-06-06 16:29:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:29:29 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:29:29 --> Helper loaded: language_helper
INFO - 2016-06-06 16:29:29 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:29:29 --> Model Class Initialized
INFO - 2016-06-06 16:29:29 --> Helper loaded: date_helper
INFO - 2016-06-06 16:29:29 --> Controller Class Initialized
INFO - 2016-06-06 16:29:29 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:29:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:29:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:29:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:29:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:29:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:29:29 --> Model Class Initialized
INFO - 2016-06-06 16:29:29 --> Form Validation Class Initialized
INFO - 2016-06-06 16:29:29 --> Final output sent to browser
DEBUG - 2016-06-06 16:29:29 --> Total execution time: 0.0555
INFO - 2016-06-06 16:32:26 --> Config Class Initialized
INFO - 2016-06-06 16:32:26 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:32:26 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:32:26 --> Utf8 Class Initialized
INFO - 2016-06-06 16:32:26 --> URI Class Initialized
INFO - 2016-06-06 16:32:26 --> Router Class Initialized
INFO - 2016-06-06 16:32:26 --> Output Class Initialized
INFO - 2016-06-06 16:32:26 --> Security Class Initialized
DEBUG - 2016-06-06 16:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:32:26 --> Input Class Initialized
INFO - 2016-06-06 16:32:26 --> Language Class Initialized
INFO - 2016-06-06 16:32:26 --> Loader Class Initialized
INFO - 2016-06-06 16:32:26 --> Helper loaded: form_helper
INFO - 2016-06-06 16:32:26 --> Database Driver Class Initialized
INFO - 2016-06-06 16:32:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:32:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:32:26 --> Email Class Initialized
INFO - 2016-06-06 16:32:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:32:26 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:32:26 --> Helper loaded: language_helper
INFO - 2016-06-06 16:32:26 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:32:26 --> Model Class Initialized
INFO - 2016-06-06 16:32:26 --> Helper loaded: date_helper
INFO - 2016-06-06 16:32:26 --> Controller Class Initialized
INFO - 2016-06-06 16:32:26 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:32:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:32:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:32:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:32:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:32:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:32:26 --> Model Class Initialized
INFO - 2016-06-06 16:32:26 --> Form Validation Class Initialized
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:32:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:32:26 --> Final output sent to browser
DEBUG - 2016-06-06 16:32:26 --> Total execution time: 0.0544
INFO - 2016-06-06 16:32:31 --> Config Class Initialized
INFO - 2016-06-06 16:32:31 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:32:31 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:32:31 --> Utf8 Class Initialized
INFO - 2016-06-06 16:32:31 --> URI Class Initialized
INFO - 2016-06-06 16:32:31 --> Router Class Initialized
INFO - 2016-06-06 16:32:31 --> Output Class Initialized
INFO - 2016-06-06 16:32:31 --> Security Class Initialized
DEBUG - 2016-06-06 16:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:32:31 --> Input Class Initialized
INFO - 2016-06-06 16:32:31 --> Language Class Initialized
INFO - 2016-06-06 16:32:31 --> Loader Class Initialized
INFO - 2016-06-06 16:32:31 --> Helper loaded: form_helper
INFO - 2016-06-06 16:32:31 --> Database Driver Class Initialized
INFO - 2016-06-06 16:32:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:32:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:32:31 --> Email Class Initialized
INFO - 2016-06-06 16:32:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:32:31 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:32:31 --> Helper loaded: language_helper
INFO - 2016-06-06 16:32:31 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:32:31 --> Model Class Initialized
INFO - 2016-06-06 16:32:31 --> Helper loaded: date_helper
INFO - 2016-06-06 16:32:31 --> Controller Class Initialized
INFO - 2016-06-06 16:32:31 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:32:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:32:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:32:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:32:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:32:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:32:31 --> Model Class Initialized
INFO - 2016-06-06 16:32:31 --> Form Validation Class Initialized
INFO - 2016-06-06 16:32:31 --> Final output sent to browser
DEBUG - 2016-06-06 16:32:31 --> Total execution time: 0.0597
INFO - 2016-06-06 16:32:42 --> Config Class Initialized
INFO - 2016-06-06 16:32:42 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:32:42 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:32:42 --> Utf8 Class Initialized
INFO - 2016-06-06 16:32:42 --> URI Class Initialized
INFO - 2016-06-06 16:32:42 --> Router Class Initialized
INFO - 2016-06-06 16:32:42 --> Output Class Initialized
INFO - 2016-06-06 16:32:42 --> Security Class Initialized
DEBUG - 2016-06-06 16:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:32:42 --> Input Class Initialized
INFO - 2016-06-06 16:32:42 --> Language Class Initialized
INFO - 2016-06-06 16:32:42 --> Loader Class Initialized
INFO - 2016-06-06 16:32:42 --> Helper loaded: form_helper
INFO - 2016-06-06 16:32:42 --> Database Driver Class Initialized
INFO - 2016-06-06 16:32:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:32:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:32:42 --> Email Class Initialized
INFO - 2016-06-06 16:32:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:32:42 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:32:42 --> Helper loaded: language_helper
INFO - 2016-06-06 16:32:42 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:32:42 --> Model Class Initialized
INFO - 2016-06-06 16:32:42 --> Helper loaded: date_helper
INFO - 2016-06-06 16:32:42 --> Controller Class Initialized
INFO - 2016-06-06 16:32:42 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:32:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:32:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:32:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:32:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:32:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:32:42 --> Model Class Initialized
INFO - 2016-06-06 16:32:42 --> Form Validation Class Initialized
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:32:42 --> Final output sent to browser
DEBUG - 2016-06-06 16:32:42 --> Total execution time: 0.1073
INFO - 2016-06-06 16:32:50 --> Config Class Initialized
INFO - 2016-06-06 16:32:50 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:32:50 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:32:50 --> Utf8 Class Initialized
INFO - 2016-06-06 16:32:50 --> URI Class Initialized
INFO - 2016-06-06 16:32:50 --> Router Class Initialized
INFO - 2016-06-06 16:32:50 --> Output Class Initialized
INFO - 2016-06-06 16:32:50 --> Security Class Initialized
DEBUG - 2016-06-06 16:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:32:50 --> Input Class Initialized
INFO - 2016-06-06 16:32:50 --> Language Class Initialized
INFO - 2016-06-06 16:32:50 --> Loader Class Initialized
INFO - 2016-06-06 16:32:50 --> Helper loaded: form_helper
INFO - 2016-06-06 16:32:50 --> Database Driver Class Initialized
INFO - 2016-06-06 16:32:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:32:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:32:50 --> Email Class Initialized
INFO - 2016-06-06 16:32:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:32:50 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:32:50 --> Helper loaded: language_helper
INFO - 2016-06-06 16:32:50 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:32:50 --> Model Class Initialized
INFO - 2016-06-06 16:32:50 --> Helper loaded: date_helper
INFO - 2016-06-06 16:32:50 --> Controller Class Initialized
INFO - 2016-06-06 16:32:50 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:32:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:32:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:32:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:32:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:32:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:32:50 --> Model Class Initialized
INFO - 2016-06-06 16:32:50 --> Form Validation Class Initialized
INFO - 2016-06-06 16:32:50 --> Final output sent to browser
DEBUG - 2016-06-06 16:32:50 --> Total execution time: 0.1895
INFO - 2016-06-06 16:32:56 --> Config Class Initialized
INFO - 2016-06-06 16:32:56 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:32:56 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:32:56 --> Utf8 Class Initialized
INFO - 2016-06-06 16:32:56 --> URI Class Initialized
INFO - 2016-06-06 16:32:56 --> Router Class Initialized
INFO - 2016-06-06 16:32:56 --> Output Class Initialized
INFO - 2016-06-06 16:32:56 --> Security Class Initialized
DEBUG - 2016-06-06 16:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:32:56 --> Input Class Initialized
INFO - 2016-06-06 16:32:56 --> Language Class Initialized
INFO - 2016-06-06 16:32:56 --> Loader Class Initialized
INFO - 2016-06-06 16:32:56 --> Helper loaded: form_helper
INFO - 2016-06-06 16:32:56 --> Database Driver Class Initialized
INFO - 2016-06-06 16:32:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:32:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:32:56 --> Email Class Initialized
INFO - 2016-06-06 16:32:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:32:56 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:32:56 --> Helper loaded: language_helper
INFO - 2016-06-06 16:32:56 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:32:56 --> Model Class Initialized
INFO - 2016-06-06 16:32:56 --> Helper loaded: date_helper
INFO - 2016-06-06 16:32:56 --> Controller Class Initialized
INFO - 2016-06-06 16:32:56 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:32:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:32:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:32:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:32:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:32:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:32:56 --> Model Class Initialized
INFO - 2016-06-06 16:32:56 --> Form Validation Class Initialized
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:32:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:32:56 --> Final output sent to browser
DEBUG - 2016-06-06 16:32:56 --> Total execution time: 0.0341
INFO - 2016-06-06 16:33:04 --> Config Class Initialized
INFO - 2016-06-06 16:33:04 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:33:04 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:33:04 --> Utf8 Class Initialized
INFO - 2016-06-06 16:33:04 --> URI Class Initialized
INFO - 2016-06-06 16:33:04 --> Router Class Initialized
INFO - 2016-06-06 16:33:04 --> Output Class Initialized
INFO - 2016-06-06 16:33:04 --> Security Class Initialized
DEBUG - 2016-06-06 16:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:33:04 --> Input Class Initialized
INFO - 2016-06-06 16:33:04 --> Language Class Initialized
INFO - 2016-06-06 16:33:04 --> Loader Class Initialized
INFO - 2016-06-06 16:33:04 --> Helper loaded: form_helper
INFO - 2016-06-06 16:33:04 --> Database Driver Class Initialized
INFO - 2016-06-06 16:33:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:33:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:33:04 --> Email Class Initialized
INFO - 2016-06-06 16:33:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:33:04 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:33:04 --> Helper loaded: language_helper
INFO - 2016-06-06 16:33:04 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:33:04 --> Model Class Initialized
INFO - 2016-06-06 16:33:04 --> Helper loaded: date_helper
INFO - 2016-06-06 16:33:04 --> Controller Class Initialized
INFO - 2016-06-06 16:33:04 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:33:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:33:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:33:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:33:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:33:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:33:04 --> Model Class Initialized
INFO - 2016-06-06 16:33:04 --> Form Validation Class Initialized
INFO - 2016-06-06 16:33:04 --> Final output sent to browser
DEBUG - 2016-06-06 16:33:04 --> Total execution time: 0.0864
INFO - 2016-06-06 16:34:04 --> Config Class Initialized
INFO - 2016-06-06 16:34:04 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:34:04 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:34:04 --> Utf8 Class Initialized
INFO - 2016-06-06 16:34:04 --> URI Class Initialized
INFO - 2016-06-06 16:34:04 --> Router Class Initialized
INFO - 2016-06-06 16:34:04 --> Output Class Initialized
INFO - 2016-06-06 16:34:04 --> Security Class Initialized
DEBUG - 2016-06-06 16:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:34:04 --> Input Class Initialized
INFO - 2016-06-06 16:34:04 --> Language Class Initialized
INFO - 2016-06-06 16:34:04 --> Loader Class Initialized
INFO - 2016-06-06 16:34:04 --> Helper loaded: form_helper
INFO - 2016-06-06 16:34:04 --> Database Driver Class Initialized
INFO - 2016-06-06 16:34:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:34:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:34:04 --> Email Class Initialized
INFO - 2016-06-06 16:34:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:34:04 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:34:04 --> Helper loaded: language_helper
INFO - 2016-06-06 16:34:04 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:34:04 --> Model Class Initialized
INFO - 2016-06-06 16:34:04 --> Helper loaded: date_helper
INFO - 2016-06-06 16:34:04 --> Controller Class Initialized
INFO - 2016-06-06 16:34:04 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:34:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:34:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:34:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:34:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:34:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:34:04 --> Model Class Initialized
INFO - 2016-06-06 16:34:04 --> Form Validation Class Initialized
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:34:04 --> Final output sent to browser
DEBUG - 2016-06-06 16:34:04 --> Total execution time: 0.0986
INFO - 2016-06-06 16:34:08 --> Config Class Initialized
INFO - 2016-06-06 16:34:08 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:34:08 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:34:08 --> Utf8 Class Initialized
INFO - 2016-06-06 16:34:08 --> URI Class Initialized
INFO - 2016-06-06 16:34:08 --> Router Class Initialized
INFO - 2016-06-06 16:34:08 --> Output Class Initialized
INFO - 2016-06-06 16:34:08 --> Security Class Initialized
DEBUG - 2016-06-06 16:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:34:08 --> Input Class Initialized
INFO - 2016-06-06 16:34:08 --> Language Class Initialized
INFO - 2016-06-06 16:34:08 --> Loader Class Initialized
INFO - 2016-06-06 16:34:08 --> Helper loaded: form_helper
INFO - 2016-06-06 16:34:08 --> Database Driver Class Initialized
INFO - 2016-06-06 16:34:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:34:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:34:08 --> Email Class Initialized
INFO - 2016-06-06 16:34:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:34:08 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:34:08 --> Helper loaded: language_helper
INFO - 2016-06-06 16:34:08 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:34:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:34:08 --> Model Class Initialized
INFO - 2016-06-06 16:34:08 --> Helper loaded: date_helper
INFO - 2016-06-06 16:34:08 --> Controller Class Initialized
INFO - 2016-06-06 16:34:08 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:34:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:34:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:34:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:34:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:34:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:34:08 --> Model Class Initialized
INFO - 2016-06-06 16:34:08 --> Form Validation Class Initialized
INFO - 2016-06-06 16:34:08 --> Final output sent to browser
DEBUG - 2016-06-06 16:34:08 --> Total execution time: 0.0151
INFO - 2016-06-06 16:34:16 --> Config Class Initialized
INFO - 2016-06-06 16:34:16 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:34:16 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:34:16 --> Utf8 Class Initialized
INFO - 2016-06-06 16:34:16 --> URI Class Initialized
INFO - 2016-06-06 16:34:16 --> Router Class Initialized
INFO - 2016-06-06 16:34:16 --> Output Class Initialized
INFO - 2016-06-06 16:34:16 --> Security Class Initialized
DEBUG - 2016-06-06 16:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:34:16 --> Input Class Initialized
INFO - 2016-06-06 16:34:16 --> Language Class Initialized
INFO - 2016-06-06 16:34:16 --> Loader Class Initialized
INFO - 2016-06-06 16:34:16 --> Helper loaded: form_helper
INFO - 2016-06-06 16:34:16 --> Database Driver Class Initialized
INFO - 2016-06-06 16:34:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:34:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:34:16 --> Email Class Initialized
INFO - 2016-06-06 16:34:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:34:16 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:34:16 --> Helper loaded: language_helper
INFO - 2016-06-06 16:34:16 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:34:16 --> Model Class Initialized
INFO - 2016-06-06 16:34:16 --> Helper loaded: date_helper
INFO - 2016-06-06 16:34:16 --> Controller Class Initialized
INFO - 2016-06-06 16:34:16 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:34:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:34:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:34:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:34:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:34:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:34:16 --> Model Class Initialized
INFO - 2016-06-06 16:34:16 --> Form Validation Class Initialized
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:34:16 --> Final output sent to browser
DEBUG - 2016-06-06 16:34:16 --> Total execution time: 0.0541
INFO - 2016-06-06 16:34:23 --> Config Class Initialized
INFO - 2016-06-06 16:34:23 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:34:23 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:34:23 --> Utf8 Class Initialized
INFO - 2016-06-06 16:34:23 --> URI Class Initialized
INFO - 2016-06-06 16:34:23 --> Router Class Initialized
INFO - 2016-06-06 16:34:23 --> Output Class Initialized
INFO - 2016-06-06 16:34:23 --> Security Class Initialized
DEBUG - 2016-06-06 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:34:23 --> Input Class Initialized
INFO - 2016-06-06 16:34:23 --> Language Class Initialized
INFO - 2016-06-06 16:34:23 --> Loader Class Initialized
INFO - 2016-06-06 16:34:23 --> Helper loaded: form_helper
INFO - 2016-06-06 16:34:23 --> Database Driver Class Initialized
INFO - 2016-06-06 16:34:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:34:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:34:23 --> Email Class Initialized
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:34:23 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:34:23 --> Helper loaded: language_helper
INFO - 2016-06-06 16:34:23 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:34:23 --> Model Class Initialized
INFO - 2016-06-06 16:34:23 --> Helper loaded: date_helper
INFO - 2016-06-06 16:34:23 --> Controller Class Initialized
INFO - 2016-06-06 16:34:23 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:34:23 --> Model Class Initialized
INFO - 2016-06-06 16:34:23 --> Form Validation Class Initialized
INFO - 2016-06-06 16:34:23 --> Final output sent to browser
DEBUG - 2016-06-06 16:34:23 --> Total execution time: 0.0861
INFO - 2016-06-06 16:34:23 --> Config Class Initialized
INFO - 2016-06-06 16:34:23 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:34:23 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:34:23 --> Utf8 Class Initialized
INFO - 2016-06-06 16:34:23 --> URI Class Initialized
INFO - 2016-06-06 16:34:23 --> Router Class Initialized
INFO - 2016-06-06 16:34:23 --> Output Class Initialized
INFO - 2016-06-06 16:34:23 --> Security Class Initialized
DEBUG - 2016-06-06 16:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:34:23 --> Input Class Initialized
INFO - 2016-06-06 16:34:23 --> Language Class Initialized
INFO - 2016-06-06 16:34:23 --> Loader Class Initialized
INFO - 2016-06-06 16:34:23 --> Helper loaded: form_helper
INFO - 2016-06-06 16:34:23 --> Database Driver Class Initialized
INFO - 2016-06-06 16:34:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:34:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:34:23 --> Email Class Initialized
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:34:23 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:34:23 --> Helper loaded: language_helper
INFO - 2016-06-06 16:34:23 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:34:23 --> Model Class Initialized
INFO - 2016-06-06 16:34:23 --> Helper loaded: date_helper
INFO - 2016-06-06 16:34:23 --> Controller Class Initialized
INFO - 2016-06-06 16:34:23 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:34:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:34:23 --> Model Class Initialized
INFO - 2016-06-06 16:34:23 --> Form Validation Class Initialized
INFO - 2016-06-06 16:34:23 --> Final output sent to browser
DEBUG - 2016-06-06 16:34:23 --> Total execution time: 0.0576
INFO - 2016-06-06 16:34:52 --> Config Class Initialized
INFO - 2016-06-06 16:34:52 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:34:52 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:34:52 --> Utf8 Class Initialized
INFO - 2016-06-06 16:34:52 --> URI Class Initialized
INFO - 2016-06-06 16:34:52 --> Router Class Initialized
INFO - 2016-06-06 16:34:52 --> Output Class Initialized
INFO - 2016-06-06 16:34:52 --> Security Class Initialized
DEBUG - 2016-06-06 16:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:34:52 --> Input Class Initialized
INFO - 2016-06-06 16:34:52 --> Language Class Initialized
INFO - 2016-06-06 16:34:52 --> Loader Class Initialized
INFO - 2016-06-06 16:34:52 --> Helper loaded: form_helper
INFO - 2016-06-06 16:34:52 --> Database Driver Class Initialized
INFO - 2016-06-06 16:34:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:34:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:34:53 --> Email Class Initialized
INFO - 2016-06-06 16:34:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:34:53 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:34:53 --> Helper loaded: language_helper
INFO - 2016-06-06 16:34:53 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:34:53 --> Model Class Initialized
INFO - 2016-06-06 16:34:53 --> Helper loaded: date_helper
INFO - 2016-06-06 16:34:53 --> Controller Class Initialized
INFO - 2016-06-06 16:34:53 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:34:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:34:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:34:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:34:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:34:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:34:53 --> Model Class Initialized
INFO - 2016-06-06 16:34:53 --> Form Validation Class Initialized
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 31
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 38
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 45
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 52
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 59
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 67
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 74
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 81
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 88
ERROR - 2016-06-06 16:34:53 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 95
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:34:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:34:53 --> Final output sent to browser
DEBUG - 2016-06-06 16:34:53 --> Total execution time: 0.0856
INFO - 2016-06-06 16:34:58 --> Config Class Initialized
INFO - 2016-06-06 16:34:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:34:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:34:58 --> Utf8 Class Initialized
INFO - 2016-06-06 16:34:58 --> URI Class Initialized
INFO - 2016-06-06 16:34:58 --> Router Class Initialized
INFO - 2016-06-06 16:34:58 --> Output Class Initialized
INFO - 2016-06-06 16:34:58 --> Security Class Initialized
DEBUG - 2016-06-06 16:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:34:58 --> Input Class Initialized
INFO - 2016-06-06 16:34:58 --> Language Class Initialized
INFO - 2016-06-06 16:34:58 --> Loader Class Initialized
INFO - 2016-06-06 16:34:58 --> Helper loaded: form_helper
INFO - 2016-06-06 16:34:58 --> Database Driver Class Initialized
INFO - 2016-06-06 16:34:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:34:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:34:58 --> Email Class Initialized
INFO - 2016-06-06 16:34:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:34:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:34:58 --> Helper loaded: language_helper
INFO - 2016-06-06 16:34:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:34:58 --> Model Class Initialized
INFO - 2016-06-06 16:34:58 --> Helper loaded: date_helper
INFO - 2016-06-06 16:34:58 --> Controller Class Initialized
INFO - 2016-06-06 16:34:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:34:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:34:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:34:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:34:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:34:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:34:58 --> Model Class Initialized
INFO - 2016-06-06 16:34:58 --> Form Validation Class Initialized
INFO - 2016-06-06 16:34:58 --> Final output sent to browser
DEBUG - 2016-06-06 16:34:58 --> Total execution time: 0.0653
INFO - 2016-06-06 16:35:17 --> Config Class Initialized
INFO - 2016-06-06 16:35:17 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:35:17 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:35:17 --> Utf8 Class Initialized
INFO - 2016-06-06 16:35:17 --> URI Class Initialized
INFO - 2016-06-06 16:35:17 --> Router Class Initialized
INFO - 2016-06-06 16:35:17 --> Output Class Initialized
INFO - 2016-06-06 16:35:17 --> Security Class Initialized
DEBUG - 2016-06-06 16:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:35:17 --> Input Class Initialized
INFO - 2016-06-06 16:35:17 --> Language Class Initialized
INFO - 2016-06-06 16:35:17 --> Loader Class Initialized
INFO - 2016-06-06 16:35:17 --> Helper loaded: form_helper
INFO - 2016-06-06 16:35:17 --> Database Driver Class Initialized
INFO - 2016-06-06 16:35:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:35:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:35:17 --> Email Class Initialized
INFO - 2016-06-06 16:35:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:35:17 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:35:17 --> Helper loaded: language_helper
INFO - 2016-06-06 16:35:17 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:35:17 --> Model Class Initialized
INFO - 2016-06-06 16:35:17 --> Helper loaded: date_helper
INFO - 2016-06-06 16:35:17 --> Controller Class Initialized
INFO - 2016-06-06 16:35:17 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:35:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:35:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:35:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:35:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:35:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:35:17 --> Model Class Initialized
INFO - 2016-06-06 16:35:17 --> Form Validation Class Initialized
INFO - 2016-06-06 16:35:17 --> Final output sent to browser
DEBUG - 2016-06-06 16:35:17 --> Total execution time: 0.0492
INFO - 2016-06-06 16:37:48 --> Config Class Initialized
INFO - 2016-06-06 16:37:48 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:37:48 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:37:48 --> Utf8 Class Initialized
INFO - 2016-06-06 16:37:48 --> URI Class Initialized
INFO - 2016-06-06 16:37:48 --> Router Class Initialized
INFO - 2016-06-06 16:37:48 --> Output Class Initialized
INFO - 2016-06-06 16:37:48 --> Security Class Initialized
DEBUG - 2016-06-06 16:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:37:48 --> Input Class Initialized
INFO - 2016-06-06 16:37:48 --> Language Class Initialized
INFO - 2016-06-06 16:37:48 --> Loader Class Initialized
INFO - 2016-06-06 16:37:48 --> Helper loaded: form_helper
INFO - 2016-06-06 16:37:48 --> Database Driver Class Initialized
INFO - 2016-06-06 16:37:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:37:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:37:48 --> Email Class Initialized
INFO - 2016-06-06 16:37:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:37:48 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:37:48 --> Helper loaded: language_helper
INFO - 2016-06-06 16:37:48 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:37:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:37:48 --> Model Class Initialized
INFO - 2016-06-06 16:37:48 --> Helper loaded: date_helper
INFO - 2016-06-06 16:37:48 --> Controller Class Initialized
INFO - 2016-06-06 16:37:48 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:37:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:37:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:37:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:37:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:37:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:37:48 --> Model Class Initialized
INFO - 2016-06-06 16:37:48 --> Form Validation Class Initialized
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:37:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:38:19 --> Config Class Initialized
INFO - 2016-06-06 16:38:19 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:38:19 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:38:19 --> Utf8 Class Initialized
INFO - 2016-06-06 16:38:19 --> URI Class Initialized
INFO - 2016-06-06 16:38:19 --> Router Class Initialized
INFO - 2016-06-06 16:38:19 --> Output Class Initialized
INFO - 2016-06-06 16:38:19 --> Security Class Initialized
DEBUG - 2016-06-06 16:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:38:19 --> Input Class Initialized
INFO - 2016-06-06 16:38:19 --> Language Class Initialized
INFO - 2016-06-06 16:38:19 --> Loader Class Initialized
INFO - 2016-06-06 16:38:19 --> Helper loaded: form_helper
INFO - 2016-06-06 16:38:19 --> Database Driver Class Initialized
INFO - 2016-06-06 16:38:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:38:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:38:19 --> Email Class Initialized
INFO - 2016-06-06 16:38:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:38:19 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:38:19 --> Helper loaded: language_helper
INFO - 2016-06-06 16:38:19 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:38:19 --> Model Class Initialized
INFO - 2016-06-06 16:38:19 --> Helper loaded: date_helper
INFO - 2016-06-06 16:38:19 --> Controller Class Initialized
INFO - 2016-06-06 16:38:19 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:38:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:38:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:38:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:38:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:38:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:38:19 --> Model Class Initialized
INFO - 2016-06-06 16:38:19 --> Form Validation Class Initialized
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:38:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:38:19 --> Final output sent to browser
DEBUG - 2016-06-06 16:38:19 --> Total execution time: 0.0456
INFO - 2016-06-06 16:38:27 --> Config Class Initialized
INFO - 2016-06-06 16:38:27 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:38:27 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:38:27 --> Utf8 Class Initialized
INFO - 2016-06-06 16:38:27 --> URI Class Initialized
INFO - 2016-06-06 16:38:27 --> Router Class Initialized
INFO - 2016-06-06 16:38:27 --> Output Class Initialized
INFO - 2016-06-06 16:38:27 --> Security Class Initialized
DEBUG - 2016-06-06 16:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:38:27 --> Input Class Initialized
INFO - 2016-06-06 16:38:27 --> Language Class Initialized
INFO - 2016-06-06 16:38:27 --> Loader Class Initialized
INFO - 2016-06-06 16:38:27 --> Helper loaded: form_helper
INFO - 2016-06-06 16:38:27 --> Database Driver Class Initialized
INFO - 2016-06-06 16:38:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:38:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:38:27 --> Email Class Initialized
INFO - 2016-06-06 16:38:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:38:27 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:38:27 --> Helper loaded: language_helper
INFO - 2016-06-06 16:38:27 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:38:27 --> Model Class Initialized
INFO - 2016-06-06 16:38:27 --> Helper loaded: date_helper
INFO - 2016-06-06 16:38:27 --> Controller Class Initialized
INFO - 2016-06-06 16:38:27 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:38:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:38:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:38:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:38:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:38:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:38:27 --> Model Class Initialized
INFO - 2016-06-06 16:38:27 --> Form Validation Class Initialized
INFO - 2016-06-06 16:38:27 --> Final output sent to browser
DEBUG - 2016-06-06 16:38:27 --> Total execution time: 0.0522
INFO - 2016-06-06 16:38:43 --> Config Class Initialized
INFO - 2016-06-06 16:38:43 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:38:43 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:38:43 --> Utf8 Class Initialized
INFO - 2016-06-06 16:38:43 --> URI Class Initialized
INFO - 2016-06-06 16:38:43 --> Router Class Initialized
INFO - 2016-06-06 16:38:43 --> Output Class Initialized
INFO - 2016-06-06 16:38:43 --> Security Class Initialized
DEBUG - 2016-06-06 16:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:38:43 --> Input Class Initialized
INFO - 2016-06-06 16:38:43 --> Language Class Initialized
INFO - 2016-06-06 16:38:43 --> Loader Class Initialized
INFO - 2016-06-06 16:38:43 --> Helper loaded: form_helper
INFO - 2016-06-06 16:38:43 --> Database Driver Class Initialized
INFO - 2016-06-06 16:38:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:38:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:38:43 --> Email Class Initialized
INFO - 2016-06-06 16:38:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:38:43 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:38:43 --> Helper loaded: language_helper
INFO - 2016-06-06 16:38:43 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:38:43 --> Model Class Initialized
INFO - 2016-06-06 16:38:43 --> Helper loaded: date_helper
INFO - 2016-06-06 16:38:43 --> Controller Class Initialized
INFO - 2016-06-06 16:38:43 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:38:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:38:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:38:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:38:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:38:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:38:43 --> Model Class Initialized
INFO - 2016-06-06 16:38:43 --> Form Validation Class Initialized
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 16:38:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 16:38:43 --> Final output sent to browser
DEBUG - 2016-06-06 16:38:43 --> Total execution time: 0.0665
INFO - 2016-06-06 16:38:50 --> Config Class Initialized
INFO - 2016-06-06 16:38:50 --> Hooks Class Initialized
DEBUG - 2016-06-06 16:38:50 --> UTF-8 Support Enabled
INFO - 2016-06-06 16:38:50 --> Utf8 Class Initialized
INFO - 2016-06-06 16:38:50 --> URI Class Initialized
INFO - 2016-06-06 16:38:50 --> Router Class Initialized
INFO - 2016-06-06 16:38:50 --> Output Class Initialized
INFO - 2016-06-06 16:38:50 --> Security Class Initialized
DEBUG - 2016-06-06 16:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 16:38:50 --> Input Class Initialized
INFO - 2016-06-06 16:38:50 --> Language Class Initialized
INFO - 2016-06-06 16:38:50 --> Loader Class Initialized
INFO - 2016-06-06 16:38:50 --> Helper loaded: form_helper
INFO - 2016-06-06 16:38:50 --> Database Driver Class Initialized
INFO - 2016-06-06 16:38:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 16:38:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 16:38:50 --> Email Class Initialized
INFO - 2016-06-06 16:38:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 16:38:50 --> Helper loaded: cookie_helper
INFO - 2016-06-06 16:38:50 --> Helper loaded: language_helper
INFO - 2016-06-06 16:38:50 --> Helper loaded: url_helper
DEBUG - 2016-06-06 16:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 16:38:50 --> Model Class Initialized
INFO - 2016-06-06 16:38:50 --> Helper loaded: date_helper
INFO - 2016-06-06 16:38:50 --> Controller Class Initialized
INFO - 2016-06-06 16:38:50 --> Helper loaded: languages_helper
INFO - 2016-06-06 16:38:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 16:38:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 16:38:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 16:38:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 16:38:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 16:38:50 --> Model Class Initialized
INFO - 2016-06-06 16:38:50 --> Form Validation Class Initialized
INFO - 2016-06-06 16:38:50 --> Final output sent to browser
DEBUG - 2016-06-06 16:38:50 --> Total execution time: 0.0550
INFO - 2016-06-06 17:23:49 --> Config Class Initialized
INFO - 2016-06-06 17:23:49 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:23:49 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:23:49 --> Utf8 Class Initialized
INFO - 2016-06-06 17:23:49 --> URI Class Initialized
INFO - 2016-06-06 17:23:49 --> Router Class Initialized
INFO - 2016-06-06 17:23:49 --> Output Class Initialized
INFO - 2016-06-06 17:23:49 --> Security Class Initialized
DEBUG - 2016-06-06 17:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:23:49 --> Input Class Initialized
INFO - 2016-06-06 17:23:49 --> Language Class Initialized
INFO - 2016-06-06 17:23:49 --> Loader Class Initialized
INFO - 2016-06-06 17:23:49 --> Helper loaded: form_helper
INFO - 2016-06-06 17:23:49 --> Database Driver Class Initialized
INFO - 2016-06-06 17:23:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:23:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:23:49 --> Email Class Initialized
INFO - 2016-06-06 17:23:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:23:49 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:23:49 --> Helper loaded: language_helper
INFO - 2016-06-06 17:23:49 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:23:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:23:49 --> Model Class Initialized
INFO - 2016-06-06 17:23:49 --> Helper loaded: date_helper
INFO - 2016-06-06 17:23:49 --> Controller Class Initialized
INFO - 2016-06-06 17:23:49 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:23:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:23:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:23:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:23:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:23:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:23:49 --> Model Class Initialized
INFO - 2016-06-06 17:23:49 --> Form Validation Class Initialized
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:23:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:23:49 --> Final output sent to browser
DEBUG - 2016-06-06 17:23:49 --> Total execution time: 0.0597
INFO - 2016-06-06 17:23:51 --> Config Class Initialized
INFO - 2016-06-06 17:23:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:23:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:23:51 --> Utf8 Class Initialized
INFO - 2016-06-06 17:23:51 --> URI Class Initialized
INFO - 2016-06-06 17:23:51 --> Router Class Initialized
INFO - 2016-06-06 17:23:51 --> Output Class Initialized
INFO - 2016-06-06 17:23:51 --> Security Class Initialized
DEBUG - 2016-06-06 17:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:23:51 --> Input Class Initialized
INFO - 2016-06-06 17:23:51 --> Language Class Initialized
INFO - 2016-06-06 17:23:51 --> Loader Class Initialized
INFO - 2016-06-06 17:23:51 --> Helper loaded: form_helper
INFO - 2016-06-06 17:23:51 --> Database Driver Class Initialized
INFO - 2016-06-06 17:23:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:23:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:23:51 --> Email Class Initialized
INFO - 2016-06-06 17:23:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:23:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:23:51 --> Helper loaded: language_helper
INFO - 2016-06-06 17:23:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:23:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:23:51 --> Model Class Initialized
INFO - 2016-06-06 17:23:51 --> Helper loaded: date_helper
INFO - 2016-06-06 17:23:51 --> Controller Class Initialized
INFO - 2016-06-06 17:23:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:23:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:23:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:23:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:23:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:23:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:23:51 --> Model Class Initialized
INFO - 2016-06-06 17:23:51 --> Form Validation Class Initialized
INFO - 2016-06-06 17:23:51 --> Final output sent to browser
DEBUG - 2016-06-06 17:23:51 --> Total execution time: 0.0158
INFO - 2016-06-06 17:25:31 --> Config Class Initialized
INFO - 2016-06-06 17:25:31 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:25:31 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:25:31 --> Utf8 Class Initialized
INFO - 2016-06-06 17:25:31 --> URI Class Initialized
INFO - 2016-06-06 17:25:31 --> Router Class Initialized
INFO - 2016-06-06 17:25:31 --> Output Class Initialized
INFO - 2016-06-06 17:25:31 --> Security Class Initialized
DEBUG - 2016-06-06 17:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:25:31 --> Input Class Initialized
INFO - 2016-06-06 17:25:31 --> Language Class Initialized
INFO - 2016-06-06 17:25:31 --> Loader Class Initialized
INFO - 2016-06-06 17:25:31 --> Helper loaded: form_helper
INFO - 2016-06-06 17:25:31 --> Database Driver Class Initialized
INFO - 2016-06-06 17:25:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:25:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:25:31 --> Email Class Initialized
INFO - 2016-06-06 17:25:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:25:31 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:25:31 --> Helper loaded: language_helper
INFO - 2016-06-06 17:25:31 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:25:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:25:31 --> Model Class Initialized
INFO - 2016-06-06 17:25:31 --> Helper loaded: date_helper
INFO - 2016-06-06 17:25:31 --> Controller Class Initialized
INFO - 2016-06-06 17:25:31 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:25:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:25:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:25:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:25:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:25:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:25:31 --> Model Class Initialized
INFO - 2016-06-06 17:25:31 --> Form Validation Class Initialized
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:25:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:25:31 --> Final output sent to browser
DEBUG - 2016-06-06 17:25:31 --> Total execution time: 0.0636
INFO - 2016-06-06 17:25:33 --> Config Class Initialized
INFO - 2016-06-06 17:25:33 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:25:33 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:25:33 --> Utf8 Class Initialized
INFO - 2016-06-06 17:25:33 --> URI Class Initialized
INFO - 2016-06-06 17:25:33 --> Router Class Initialized
INFO - 2016-06-06 17:25:33 --> Output Class Initialized
INFO - 2016-06-06 17:25:33 --> Security Class Initialized
DEBUG - 2016-06-06 17:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:25:33 --> Input Class Initialized
INFO - 2016-06-06 17:25:33 --> Language Class Initialized
INFO - 2016-06-06 17:25:33 --> Loader Class Initialized
INFO - 2016-06-06 17:25:33 --> Helper loaded: form_helper
INFO - 2016-06-06 17:25:33 --> Database Driver Class Initialized
INFO - 2016-06-06 17:25:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:25:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:25:33 --> Email Class Initialized
INFO - 2016-06-06 17:25:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:25:33 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:25:33 --> Helper loaded: language_helper
INFO - 2016-06-06 17:25:33 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:25:33 --> Model Class Initialized
INFO - 2016-06-06 17:25:33 --> Helper loaded: date_helper
INFO - 2016-06-06 17:25:33 --> Controller Class Initialized
INFO - 2016-06-06 17:25:33 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:25:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:25:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:25:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:25:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:25:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:25:33 --> Model Class Initialized
INFO - 2016-06-06 17:25:33 --> Form Validation Class Initialized
INFO - 2016-06-06 17:25:33 --> Final output sent to browser
DEBUG - 2016-06-06 17:25:33 --> Total execution time: 0.0247
INFO - 2016-06-06 17:29:34 --> Config Class Initialized
INFO - 2016-06-06 17:29:34 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:29:34 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:29:34 --> Utf8 Class Initialized
INFO - 2016-06-06 17:29:34 --> URI Class Initialized
INFO - 2016-06-06 17:29:34 --> Router Class Initialized
INFO - 2016-06-06 17:29:34 --> Output Class Initialized
INFO - 2016-06-06 17:29:34 --> Security Class Initialized
DEBUG - 2016-06-06 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:29:34 --> Input Class Initialized
INFO - 2016-06-06 17:29:34 --> Language Class Initialized
INFO - 2016-06-06 17:29:34 --> Loader Class Initialized
INFO - 2016-06-06 17:29:34 --> Helper loaded: form_helper
INFO - 2016-06-06 17:29:34 --> Database Driver Class Initialized
INFO - 2016-06-06 17:29:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:29:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:29:34 --> Email Class Initialized
INFO - 2016-06-06 17:29:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:29:34 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:29:34 --> Helper loaded: language_helper
INFO - 2016-06-06 17:29:34 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:29:34 --> Model Class Initialized
INFO - 2016-06-06 17:29:34 --> Helper loaded: date_helper
INFO - 2016-06-06 17:29:34 --> Controller Class Initialized
INFO - 2016-06-06 17:29:34 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:29:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:29:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:29:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:29:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:29:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:29:34 --> Model Class Initialized
INFO - 2016-06-06 17:29:34 --> Form Validation Class Initialized
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:29:34 --> Final output sent to browser
DEBUG - 2016-06-06 17:29:34 --> Total execution time: 0.0650
INFO - 2016-06-06 17:29:37 --> Config Class Initialized
INFO - 2016-06-06 17:29:37 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:29:37 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:29:37 --> Utf8 Class Initialized
INFO - 2016-06-06 17:29:37 --> URI Class Initialized
INFO - 2016-06-06 17:29:37 --> Router Class Initialized
INFO - 2016-06-06 17:29:37 --> Output Class Initialized
INFO - 2016-06-06 17:29:37 --> Security Class Initialized
DEBUG - 2016-06-06 17:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:29:37 --> Input Class Initialized
INFO - 2016-06-06 17:29:37 --> Language Class Initialized
INFO - 2016-06-06 17:29:37 --> Loader Class Initialized
INFO - 2016-06-06 17:29:37 --> Helper loaded: form_helper
INFO - 2016-06-06 17:29:37 --> Database Driver Class Initialized
INFO - 2016-06-06 17:29:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:29:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:29:37 --> Email Class Initialized
INFO - 2016-06-06 17:29:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:29:37 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:29:37 --> Helper loaded: language_helper
INFO - 2016-06-06 17:29:37 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:29:37 --> Model Class Initialized
INFO - 2016-06-06 17:29:37 --> Helper loaded: date_helper
INFO - 2016-06-06 17:29:37 --> Controller Class Initialized
INFO - 2016-06-06 17:29:37 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:29:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:29:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:29:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:29:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:29:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:29:37 --> Model Class Initialized
INFO - 2016-06-06 17:29:37 --> Form Validation Class Initialized
INFO - 2016-06-06 17:29:37 --> Final output sent to browser
DEBUG - 2016-06-06 17:29:37 --> Total execution time: 0.0308
INFO - 2016-06-06 17:29:47 --> Config Class Initialized
INFO - 2016-06-06 17:29:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:29:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:29:47 --> Utf8 Class Initialized
INFO - 2016-06-06 17:29:47 --> URI Class Initialized
INFO - 2016-06-06 17:29:47 --> Router Class Initialized
INFO - 2016-06-06 17:29:47 --> Output Class Initialized
INFO - 2016-06-06 17:29:47 --> Security Class Initialized
DEBUG - 2016-06-06 17:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:29:47 --> Input Class Initialized
INFO - 2016-06-06 17:29:47 --> Language Class Initialized
INFO - 2016-06-06 17:29:47 --> Loader Class Initialized
INFO - 2016-06-06 17:29:47 --> Helper loaded: form_helper
INFO - 2016-06-06 17:29:47 --> Database Driver Class Initialized
INFO - 2016-06-06 17:29:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:29:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:29:47 --> Email Class Initialized
INFO - 2016-06-06 17:29:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:29:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:29:47 --> Helper loaded: language_helper
INFO - 2016-06-06 17:29:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:29:47 --> Model Class Initialized
INFO - 2016-06-06 17:29:47 --> Helper loaded: date_helper
INFO - 2016-06-06 17:29:47 --> Controller Class Initialized
INFO - 2016-06-06 17:29:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:29:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:29:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:29:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:29:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:29:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:29:47 --> Model Class Initialized
INFO - 2016-06-06 17:29:47 --> Form Validation Class Initialized
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_1_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 37
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_2_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 44
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_3_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 51
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_4_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 58
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_5_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 65
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_6_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 73
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_7_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 80
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_8_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 87
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_9_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 94
ERROR - 2016-06-06 17:29:47 --> Severity: Notice --> Undefined index: interval_10_nota /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php 101
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:29:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:29:47 --> Final output sent to browser
DEBUG - 2016-06-06 17:29:47 --> Total execution time: 0.1321
INFO - 2016-06-06 17:29:50 --> Config Class Initialized
INFO - 2016-06-06 17:29:50 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:29:50 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:29:50 --> Utf8 Class Initialized
INFO - 2016-06-06 17:29:50 --> URI Class Initialized
INFO - 2016-06-06 17:29:50 --> Router Class Initialized
INFO - 2016-06-06 17:29:50 --> Output Class Initialized
INFO - 2016-06-06 17:29:50 --> Security Class Initialized
DEBUG - 2016-06-06 17:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:29:50 --> Input Class Initialized
INFO - 2016-06-06 17:29:50 --> Language Class Initialized
INFO - 2016-06-06 17:29:50 --> Loader Class Initialized
INFO - 2016-06-06 17:29:50 --> Helper loaded: form_helper
INFO - 2016-06-06 17:29:50 --> Database Driver Class Initialized
INFO - 2016-06-06 17:29:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:29:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:29:50 --> Email Class Initialized
INFO - 2016-06-06 17:29:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:29:50 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:29:50 --> Helper loaded: language_helper
INFO - 2016-06-06 17:29:50 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:29:50 --> Model Class Initialized
INFO - 2016-06-06 17:29:50 --> Helper loaded: date_helper
INFO - 2016-06-06 17:29:50 --> Controller Class Initialized
INFO - 2016-06-06 17:29:50 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:29:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:29:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:29:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:29:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:29:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:29:50 --> Model Class Initialized
INFO - 2016-06-06 17:29:50 --> Form Validation Class Initialized
INFO - 2016-06-06 17:29:50 --> Final output sent to browser
DEBUG - 2016-06-06 17:29:50 --> Total execution time: 0.0213
INFO - 2016-06-06 17:29:59 --> Config Class Initialized
INFO - 2016-06-06 17:29:59 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:29:59 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:29:59 --> Utf8 Class Initialized
INFO - 2016-06-06 17:29:59 --> URI Class Initialized
INFO - 2016-06-06 17:29:59 --> Router Class Initialized
INFO - 2016-06-06 17:29:59 --> Output Class Initialized
INFO - 2016-06-06 17:29:59 --> Security Class Initialized
DEBUG - 2016-06-06 17:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:29:59 --> Input Class Initialized
INFO - 2016-06-06 17:29:59 --> Language Class Initialized
INFO - 2016-06-06 17:29:59 --> Loader Class Initialized
INFO - 2016-06-06 17:29:59 --> Helper loaded: form_helper
INFO - 2016-06-06 17:29:59 --> Database Driver Class Initialized
INFO - 2016-06-06 17:29:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:29:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:29:59 --> Email Class Initialized
INFO - 2016-06-06 17:29:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:29:59 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:29:59 --> Helper loaded: language_helper
INFO - 2016-06-06 17:29:59 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:29:59 --> Model Class Initialized
INFO - 2016-06-06 17:29:59 --> Helper loaded: date_helper
INFO - 2016-06-06 17:29:59 --> Controller Class Initialized
INFO - 2016-06-06 17:29:59 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:29:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:29:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:29:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:29:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:29:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:29:59 --> Model Class Initialized
INFO - 2016-06-06 17:29:59 --> Form Validation Class Initialized
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:29:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:29:59 --> Final output sent to browser
DEBUG - 2016-06-06 17:29:59 --> Total execution time: 0.0940
INFO - 2016-06-06 17:30:02 --> Config Class Initialized
INFO - 2016-06-06 17:30:02 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:30:02 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:30:02 --> Utf8 Class Initialized
INFO - 2016-06-06 17:30:02 --> URI Class Initialized
INFO - 2016-06-06 17:30:02 --> Router Class Initialized
INFO - 2016-06-06 17:30:02 --> Output Class Initialized
INFO - 2016-06-06 17:30:02 --> Security Class Initialized
DEBUG - 2016-06-06 17:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:30:02 --> Input Class Initialized
INFO - 2016-06-06 17:30:02 --> Language Class Initialized
INFO - 2016-06-06 17:30:02 --> Loader Class Initialized
INFO - 2016-06-06 17:30:02 --> Helper loaded: form_helper
INFO - 2016-06-06 17:30:02 --> Database Driver Class Initialized
INFO - 2016-06-06 17:30:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:30:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:30:02 --> Email Class Initialized
INFO - 2016-06-06 17:30:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:30:02 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:30:02 --> Helper loaded: language_helper
INFO - 2016-06-06 17:30:02 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:30:02 --> Model Class Initialized
INFO - 2016-06-06 17:30:02 --> Helper loaded: date_helper
INFO - 2016-06-06 17:30:02 --> Controller Class Initialized
INFO - 2016-06-06 17:30:02 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:30:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:30:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:30:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:30:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:30:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:30:02 --> Model Class Initialized
INFO - 2016-06-06 17:30:02 --> Form Validation Class Initialized
INFO - 2016-06-06 17:30:02 --> Final output sent to browser
DEBUG - 2016-06-06 17:30:02 --> Total execution time: 0.0984
INFO - 2016-06-06 17:37:22 --> Config Class Initialized
INFO - 2016-06-06 17:37:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:37:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:37:22 --> Utf8 Class Initialized
INFO - 2016-06-06 17:37:22 --> URI Class Initialized
INFO - 2016-06-06 17:37:22 --> Router Class Initialized
INFO - 2016-06-06 17:37:22 --> Output Class Initialized
INFO - 2016-06-06 17:37:22 --> Security Class Initialized
DEBUG - 2016-06-06 17:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:37:22 --> Input Class Initialized
INFO - 2016-06-06 17:37:22 --> Language Class Initialized
INFO - 2016-06-06 17:37:22 --> Loader Class Initialized
INFO - 2016-06-06 17:37:22 --> Helper loaded: form_helper
INFO - 2016-06-06 17:37:22 --> Database Driver Class Initialized
INFO - 2016-06-06 17:37:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:37:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:37:22 --> Email Class Initialized
INFO - 2016-06-06 17:37:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:37:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:37:22 --> Helper loaded: language_helper
INFO - 2016-06-06 17:37:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:37:22 --> Model Class Initialized
INFO - 2016-06-06 17:37:22 --> Helper loaded: date_helper
INFO - 2016-06-06 17:37:22 --> Controller Class Initialized
INFO - 2016-06-06 17:37:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:37:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:37:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:37:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:37:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:37:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:37:22 --> Model Class Initialized
INFO - 2016-06-06 17:37:22 --> Form Validation Class Initialized
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:37:22 --> Final output sent to browser
DEBUG - 2016-06-06 17:37:22 --> Total execution time: 0.0600
INFO - 2016-06-06 17:37:25 --> Config Class Initialized
INFO - 2016-06-06 17:37:25 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:37:25 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:37:25 --> Utf8 Class Initialized
INFO - 2016-06-06 17:37:25 --> URI Class Initialized
INFO - 2016-06-06 17:37:25 --> Router Class Initialized
INFO - 2016-06-06 17:37:25 --> Output Class Initialized
INFO - 2016-06-06 17:37:25 --> Security Class Initialized
DEBUG - 2016-06-06 17:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:37:25 --> Input Class Initialized
INFO - 2016-06-06 17:37:25 --> Language Class Initialized
INFO - 2016-06-06 17:37:25 --> Loader Class Initialized
INFO - 2016-06-06 17:37:25 --> Helper loaded: form_helper
INFO - 2016-06-06 17:37:25 --> Database Driver Class Initialized
INFO - 2016-06-06 17:37:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:37:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:37:25 --> Email Class Initialized
INFO - 2016-06-06 17:37:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:37:25 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:37:25 --> Helper loaded: language_helper
INFO - 2016-06-06 17:37:25 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:37:25 --> Model Class Initialized
INFO - 2016-06-06 17:37:25 --> Helper loaded: date_helper
INFO - 2016-06-06 17:37:25 --> Controller Class Initialized
INFO - 2016-06-06 17:37:25 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:37:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:37:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:37:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:37:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:37:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:37:25 --> Model Class Initialized
INFO - 2016-06-06 17:37:25 --> Form Validation Class Initialized
INFO - 2016-06-06 17:37:25 --> Final output sent to browser
DEBUG - 2016-06-06 17:37:25 --> Total execution time: 0.0223
INFO - 2016-06-06 17:38:18 --> Config Class Initialized
INFO - 2016-06-06 17:38:18 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:38:18 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:38:18 --> Utf8 Class Initialized
INFO - 2016-06-06 17:38:18 --> URI Class Initialized
INFO - 2016-06-06 17:38:18 --> Router Class Initialized
INFO - 2016-06-06 17:38:18 --> Output Class Initialized
INFO - 2016-06-06 17:38:18 --> Security Class Initialized
DEBUG - 2016-06-06 17:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:38:18 --> Input Class Initialized
INFO - 2016-06-06 17:38:18 --> Language Class Initialized
INFO - 2016-06-06 17:38:18 --> Loader Class Initialized
INFO - 2016-06-06 17:38:18 --> Helper loaded: form_helper
INFO - 2016-06-06 17:38:18 --> Database Driver Class Initialized
INFO - 2016-06-06 17:38:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:38:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:38:18 --> Email Class Initialized
INFO - 2016-06-06 17:38:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:38:18 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:38:18 --> Helper loaded: language_helper
INFO - 2016-06-06 17:38:18 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:38:18 --> Model Class Initialized
INFO - 2016-06-06 17:38:18 --> Helper loaded: date_helper
INFO - 2016-06-06 17:38:18 --> Controller Class Initialized
INFO - 2016-06-06 17:38:18 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:38:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:38:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:38:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:38:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:38:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:38:18 --> Model Class Initialized
INFO - 2016-06-06 17:38:18 --> Form Validation Class Initialized
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:38:18 --> Final output sent to browser
DEBUG - 2016-06-06 17:38:18 --> Total execution time: 0.0731
INFO - 2016-06-06 17:38:20 --> Config Class Initialized
INFO - 2016-06-06 17:38:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:38:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:38:20 --> Utf8 Class Initialized
INFO - 2016-06-06 17:38:20 --> URI Class Initialized
INFO - 2016-06-06 17:38:20 --> Router Class Initialized
INFO - 2016-06-06 17:38:20 --> Output Class Initialized
INFO - 2016-06-06 17:38:20 --> Security Class Initialized
DEBUG - 2016-06-06 17:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:38:20 --> Input Class Initialized
INFO - 2016-06-06 17:38:20 --> Language Class Initialized
INFO - 2016-06-06 17:38:20 --> Loader Class Initialized
INFO - 2016-06-06 17:38:20 --> Helper loaded: form_helper
INFO - 2016-06-06 17:38:20 --> Database Driver Class Initialized
INFO - 2016-06-06 17:38:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:38:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:38:20 --> Email Class Initialized
INFO - 2016-06-06 17:38:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:38:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:38:20 --> Helper loaded: language_helper
INFO - 2016-06-06 17:38:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:38:20 --> Model Class Initialized
INFO - 2016-06-06 17:38:20 --> Helper loaded: date_helper
INFO - 2016-06-06 17:38:20 --> Controller Class Initialized
INFO - 2016-06-06 17:38:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:38:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:38:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:38:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:38:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:38:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:38:20 --> Model Class Initialized
INFO - 2016-06-06 17:38:20 --> Form Validation Class Initialized
INFO - 2016-06-06 17:38:20 --> Final output sent to browser
DEBUG - 2016-06-06 17:38:20 --> Total execution time: 0.0212
INFO - 2016-06-06 17:40:47 --> Config Class Initialized
INFO - 2016-06-06 17:40:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:40:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:40:47 --> Utf8 Class Initialized
INFO - 2016-06-06 17:40:47 --> URI Class Initialized
INFO - 2016-06-06 17:40:47 --> Router Class Initialized
INFO - 2016-06-06 17:40:47 --> Output Class Initialized
INFO - 2016-06-06 17:40:47 --> Security Class Initialized
DEBUG - 2016-06-06 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:40:47 --> Input Class Initialized
INFO - 2016-06-06 17:40:47 --> Language Class Initialized
INFO - 2016-06-06 17:40:47 --> Loader Class Initialized
INFO - 2016-06-06 17:40:47 --> Helper loaded: form_helper
INFO - 2016-06-06 17:40:47 --> Database Driver Class Initialized
INFO - 2016-06-06 17:40:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:40:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:40:47 --> Email Class Initialized
INFO - 2016-06-06 17:40:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:40:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:40:47 --> Helper loaded: language_helper
INFO - 2016-06-06 17:40:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:40:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:40:47 --> Model Class Initialized
INFO - 2016-06-06 17:40:47 --> Helper loaded: date_helper
INFO - 2016-06-06 17:40:47 --> Controller Class Initialized
INFO - 2016-06-06 17:40:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:40:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:40:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:40:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:40:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:40:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:40:47 --> Model Class Initialized
INFO - 2016-06-06 17:40:47 --> Form Validation Class Initialized
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:40:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:40:47 --> Final output sent to browser
DEBUG - 2016-06-06 17:40:47 --> Total execution time: 0.0841
INFO - 2016-06-06 17:40:50 --> Config Class Initialized
INFO - 2016-06-06 17:40:50 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:40:50 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:40:50 --> Utf8 Class Initialized
INFO - 2016-06-06 17:40:50 --> URI Class Initialized
INFO - 2016-06-06 17:40:50 --> Router Class Initialized
INFO - 2016-06-06 17:40:50 --> Output Class Initialized
INFO - 2016-06-06 17:40:50 --> Security Class Initialized
DEBUG - 2016-06-06 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:40:50 --> Input Class Initialized
INFO - 2016-06-06 17:40:50 --> Language Class Initialized
INFO - 2016-06-06 17:40:50 --> Loader Class Initialized
INFO - 2016-06-06 17:40:50 --> Helper loaded: form_helper
INFO - 2016-06-06 17:40:50 --> Database Driver Class Initialized
INFO - 2016-06-06 17:40:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:40:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:40:50 --> Email Class Initialized
INFO - 2016-06-06 17:40:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:40:50 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:40:50 --> Helper loaded: language_helper
INFO - 2016-06-06 17:40:50 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:40:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:40:50 --> Model Class Initialized
INFO - 2016-06-06 17:40:50 --> Helper loaded: date_helper
INFO - 2016-06-06 17:40:50 --> Controller Class Initialized
INFO - 2016-06-06 17:40:50 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:40:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:40:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:40:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:40:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:40:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:40:50 --> Model Class Initialized
INFO - 2016-06-06 17:40:50 --> Form Validation Class Initialized
INFO - 2016-06-06 17:40:50 --> Final output sent to browser
DEBUG - 2016-06-06 17:40:50 --> Total execution time: 0.0317
INFO - 2016-06-06 17:41:38 --> Config Class Initialized
INFO - 2016-06-06 17:41:38 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:41:38 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:41:38 --> Utf8 Class Initialized
INFO - 2016-06-06 17:41:38 --> URI Class Initialized
INFO - 2016-06-06 17:41:38 --> Router Class Initialized
INFO - 2016-06-06 17:41:38 --> Output Class Initialized
INFO - 2016-06-06 17:41:38 --> Security Class Initialized
DEBUG - 2016-06-06 17:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:41:38 --> Input Class Initialized
INFO - 2016-06-06 17:41:38 --> Language Class Initialized
INFO - 2016-06-06 17:41:38 --> Loader Class Initialized
INFO - 2016-06-06 17:41:38 --> Helper loaded: form_helper
INFO - 2016-06-06 17:41:38 --> Database Driver Class Initialized
INFO - 2016-06-06 17:41:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:41:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:41:38 --> Email Class Initialized
INFO - 2016-06-06 17:41:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:41:38 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:41:38 --> Helper loaded: language_helper
INFO - 2016-06-06 17:41:38 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:41:38 --> Model Class Initialized
INFO - 2016-06-06 17:41:38 --> Helper loaded: date_helper
INFO - 2016-06-06 17:41:38 --> Controller Class Initialized
INFO - 2016-06-06 17:41:38 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:41:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:41:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:41:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:41:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:41:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:41:38 --> Model Class Initialized
INFO - 2016-06-06 17:41:38 --> Form Validation Class Initialized
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:41:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:41:38 --> Final output sent to browser
DEBUG - 2016-06-06 17:41:38 --> Total execution time: 0.1245
INFO - 2016-06-06 17:41:40 --> Config Class Initialized
INFO - 2016-06-06 17:41:40 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:41:40 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:41:40 --> Utf8 Class Initialized
INFO - 2016-06-06 17:41:40 --> URI Class Initialized
INFO - 2016-06-06 17:41:40 --> Router Class Initialized
INFO - 2016-06-06 17:41:40 --> Output Class Initialized
INFO - 2016-06-06 17:41:40 --> Security Class Initialized
DEBUG - 2016-06-06 17:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:41:40 --> Input Class Initialized
INFO - 2016-06-06 17:41:40 --> Language Class Initialized
INFO - 2016-06-06 17:41:40 --> Loader Class Initialized
INFO - 2016-06-06 17:41:40 --> Helper loaded: form_helper
INFO - 2016-06-06 17:41:40 --> Database Driver Class Initialized
INFO - 2016-06-06 17:41:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:41:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:41:40 --> Email Class Initialized
INFO - 2016-06-06 17:41:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:41:40 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:41:40 --> Helper loaded: language_helper
INFO - 2016-06-06 17:41:40 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:41:40 --> Model Class Initialized
INFO - 2016-06-06 17:41:40 --> Helper loaded: date_helper
INFO - 2016-06-06 17:41:40 --> Controller Class Initialized
INFO - 2016-06-06 17:41:40 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:41:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:41:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:41:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:41:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:41:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:41:40 --> Model Class Initialized
INFO - 2016-06-06 17:41:40 --> Form Validation Class Initialized
INFO - 2016-06-06 17:41:40 --> Final output sent to browser
DEBUG - 2016-06-06 17:41:40 --> Total execution time: 0.0742
INFO - 2016-06-06 17:42:56 --> Config Class Initialized
INFO - 2016-06-06 17:42:56 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:42:56 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:42:56 --> Utf8 Class Initialized
INFO - 2016-06-06 17:42:56 --> URI Class Initialized
INFO - 2016-06-06 17:42:56 --> Router Class Initialized
INFO - 2016-06-06 17:42:56 --> Output Class Initialized
INFO - 2016-06-06 17:42:56 --> Security Class Initialized
DEBUG - 2016-06-06 17:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:42:56 --> Input Class Initialized
INFO - 2016-06-06 17:42:56 --> Language Class Initialized
INFO - 2016-06-06 17:42:56 --> Loader Class Initialized
INFO - 2016-06-06 17:42:56 --> Helper loaded: form_helper
INFO - 2016-06-06 17:42:56 --> Database Driver Class Initialized
INFO - 2016-06-06 17:42:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:42:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:42:56 --> Email Class Initialized
INFO - 2016-06-06 17:42:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:42:56 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:42:56 --> Helper loaded: language_helper
INFO - 2016-06-06 17:42:56 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:42:56 --> Model Class Initialized
INFO - 2016-06-06 17:42:56 --> Helper loaded: date_helper
INFO - 2016-06-06 17:42:56 --> Controller Class Initialized
INFO - 2016-06-06 17:42:56 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:42:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:42:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:42:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:42:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:42:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:42:56 --> Model Class Initialized
INFO - 2016-06-06 17:42:56 --> Form Validation Class Initialized
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:42:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:42:56 --> Final output sent to browser
DEBUG - 2016-06-06 17:42:56 --> Total execution time: 0.0915
INFO - 2016-06-06 17:42:58 --> Config Class Initialized
INFO - 2016-06-06 17:42:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:42:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:42:58 --> Utf8 Class Initialized
INFO - 2016-06-06 17:42:58 --> URI Class Initialized
INFO - 2016-06-06 17:42:58 --> Router Class Initialized
INFO - 2016-06-06 17:42:58 --> Output Class Initialized
INFO - 2016-06-06 17:42:58 --> Security Class Initialized
DEBUG - 2016-06-06 17:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:42:58 --> Input Class Initialized
INFO - 2016-06-06 17:42:58 --> Language Class Initialized
INFO - 2016-06-06 17:42:58 --> Loader Class Initialized
INFO - 2016-06-06 17:42:58 --> Helper loaded: form_helper
INFO - 2016-06-06 17:42:58 --> Database Driver Class Initialized
INFO - 2016-06-06 17:42:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:42:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:42:58 --> Email Class Initialized
INFO - 2016-06-06 17:42:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:42:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:42:58 --> Helper loaded: language_helper
INFO - 2016-06-06 17:42:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:42:58 --> Model Class Initialized
INFO - 2016-06-06 17:42:58 --> Helper loaded: date_helper
INFO - 2016-06-06 17:42:58 --> Controller Class Initialized
INFO - 2016-06-06 17:42:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:42:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:42:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:42:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:42:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:42:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:42:58 --> Model Class Initialized
INFO - 2016-06-06 17:42:58 --> Form Validation Class Initialized
INFO - 2016-06-06 17:42:58 --> Final output sent to browser
DEBUG - 2016-06-06 17:42:58 --> Total execution time: 0.0566
INFO - 2016-06-06 17:43:28 --> Config Class Initialized
INFO - 2016-06-06 17:43:28 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:43:28 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:43:28 --> Utf8 Class Initialized
INFO - 2016-06-06 17:43:28 --> URI Class Initialized
INFO - 2016-06-06 17:43:28 --> Router Class Initialized
INFO - 2016-06-06 17:43:28 --> Output Class Initialized
INFO - 2016-06-06 17:43:28 --> Security Class Initialized
DEBUG - 2016-06-06 17:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:43:28 --> Input Class Initialized
INFO - 2016-06-06 17:43:28 --> Language Class Initialized
INFO - 2016-06-06 17:43:28 --> Loader Class Initialized
INFO - 2016-06-06 17:43:28 --> Helper loaded: form_helper
INFO - 2016-06-06 17:43:28 --> Database Driver Class Initialized
INFO - 2016-06-06 17:43:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:43:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:43:28 --> Email Class Initialized
INFO - 2016-06-06 17:43:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:43:28 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:43:28 --> Helper loaded: language_helper
INFO - 2016-06-06 17:43:28 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:43:28 --> Model Class Initialized
INFO - 2016-06-06 17:43:28 --> Helper loaded: date_helper
INFO - 2016-06-06 17:43:28 --> Controller Class Initialized
INFO - 2016-06-06 17:43:28 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:43:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:43:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:43:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:43:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:43:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:43:28 --> Model Class Initialized
INFO - 2016-06-06 17:43:28 --> Form Validation Class Initialized
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:43:28 --> Final output sent to browser
DEBUG - 2016-06-06 17:43:28 --> Total execution time: 0.0682
INFO - 2016-06-06 17:43:31 --> Config Class Initialized
INFO - 2016-06-06 17:43:31 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:43:31 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:43:31 --> Utf8 Class Initialized
INFO - 2016-06-06 17:43:31 --> URI Class Initialized
INFO - 2016-06-06 17:43:31 --> Router Class Initialized
INFO - 2016-06-06 17:43:31 --> Output Class Initialized
INFO - 2016-06-06 17:43:31 --> Security Class Initialized
DEBUG - 2016-06-06 17:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:43:31 --> Input Class Initialized
INFO - 2016-06-06 17:43:31 --> Language Class Initialized
INFO - 2016-06-06 17:43:31 --> Loader Class Initialized
INFO - 2016-06-06 17:43:31 --> Helper loaded: form_helper
INFO - 2016-06-06 17:43:31 --> Database Driver Class Initialized
INFO - 2016-06-06 17:43:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:43:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:43:31 --> Email Class Initialized
INFO - 2016-06-06 17:43:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:43:31 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:43:31 --> Helper loaded: language_helper
INFO - 2016-06-06 17:43:31 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:43:31 --> Model Class Initialized
INFO - 2016-06-06 17:43:31 --> Helper loaded: date_helper
INFO - 2016-06-06 17:43:31 --> Controller Class Initialized
INFO - 2016-06-06 17:43:31 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:43:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:43:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:43:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:43:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:43:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:43:31 --> Model Class Initialized
INFO - 2016-06-06 17:43:31 --> Form Validation Class Initialized
INFO - 2016-06-06 17:43:31 --> Final output sent to browser
DEBUG - 2016-06-06 17:43:31 --> Total execution time: 0.0609
INFO - 2016-06-06 17:47:43 --> Config Class Initialized
INFO - 2016-06-06 17:47:43 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:47:43 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:47:43 --> Utf8 Class Initialized
INFO - 2016-06-06 17:47:43 --> URI Class Initialized
INFO - 2016-06-06 17:47:43 --> Router Class Initialized
INFO - 2016-06-06 17:47:43 --> Output Class Initialized
INFO - 2016-06-06 17:47:43 --> Security Class Initialized
DEBUG - 2016-06-06 17:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:47:43 --> Input Class Initialized
INFO - 2016-06-06 17:47:43 --> Language Class Initialized
INFO - 2016-06-06 17:47:43 --> Loader Class Initialized
INFO - 2016-06-06 17:47:43 --> Helper loaded: form_helper
INFO - 2016-06-06 17:47:43 --> Database Driver Class Initialized
INFO - 2016-06-06 17:47:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:47:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:47:43 --> Email Class Initialized
INFO - 2016-06-06 17:47:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:47:43 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:47:43 --> Helper loaded: language_helper
INFO - 2016-06-06 17:47:43 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:47:43 --> Model Class Initialized
INFO - 2016-06-06 17:47:43 --> Helper loaded: date_helper
INFO - 2016-06-06 17:47:43 --> Controller Class Initialized
INFO - 2016-06-06 17:47:43 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:47:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:47:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:47:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:47:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:47:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:47:43 --> Model Class Initialized
INFO - 2016-06-06 17:47:43 --> Form Validation Class Initialized
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:47:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:47:43 --> Final output sent to browser
DEBUG - 2016-06-06 17:47:43 --> Total execution time: 0.0864
INFO - 2016-06-06 17:47:45 --> Config Class Initialized
INFO - 2016-06-06 17:47:45 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:47:45 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:47:45 --> Utf8 Class Initialized
INFO - 2016-06-06 17:47:45 --> URI Class Initialized
INFO - 2016-06-06 17:47:45 --> Router Class Initialized
INFO - 2016-06-06 17:47:45 --> Output Class Initialized
INFO - 2016-06-06 17:47:45 --> Security Class Initialized
DEBUG - 2016-06-06 17:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:47:45 --> Input Class Initialized
INFO - 2016-06-06 17:47:45 --> Language Class Initialized
INFO - 2016-06-06 17:47:45 --> Loader Class Initialized
INFO - 2016-06-06 17:47:45 --> Helper loaded: form_helper
INFO - 2016-06-06 17:47:45 --> Database Driver Class Initialized
INFO - 2016-06-06 17:47:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:47:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:47:45 --> Email Class Initialized
INFO - 2016-06-06 17:47:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:47:45 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:47:45 --> Helper loaded: language_helper
INFO - 2016-06-06 17:47:45 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:47:45 --> Model Class Initialized
INFO - 2016-06-06 17:47:45 --> Helper loaded: date_helper
INFO - 2016-06-06 17:47:45 --> Controller Class Initialized
INFO - 2016-06-06 17:47:45 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:47:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:47:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:47:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:47:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:47:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:47:45 --> Model Class Initialized
INFO - 2016-06-06 17:47:45 --> Form Validation Class Initialized
INFO - 2016-06-06 17:47:45 --> Final output sent to browser
DEBUG - 2016-06-06 17:47:45 --> Total execution time: 0.0207
INFO - 2016-06-06 17:48:46 --> Config Class Initialized
INFO - 2016-06-06 17:48:46 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:48:46 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:48:46 --> Utf8 Class Initialized
INFO - 2016-06-06 17:48:46 --> URI Class Initialized
INFO - 2016-06-06 17:48:46 --> Router Class Initialized
INFO - 2016-06-06 17:48:46 --> Output Class Initialized
INFO - 2016-06-06 17:48:46 --> Security Class Initialized
DEBUG - 2016-06-06 17:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:48:46 --> Input Class Initialized
INFO - 2016-06-06 17:48:46 --> Language Class Initialized
INFO - 2016-06-06 17:48:46 --> Loader Class Initialized
INFO - 2016-06-06 17:48:46 --> Helper loaded: form_helper
INFO - 2016-06-06 17:48:46 --> Database Driver Class Initialized
INFO - 2016-06-06 17:48:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:48:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:48:46 --> Email Class Initialized
INFO - 2016-06-06 17:48:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:48:46 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:48:46 --> Helper loaded: language_helper
INFO - 2016-06-06 17:48:46 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:48:46 --> Model Class Initialized
INFO - 2016-06-06 17:48:46 --> Helper loaded: date_helper
INFO - 2016-06-06 17:48:46 --> Controller Class Initialized
INFO - 2016-06-06 17:48:46 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:48:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:48:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:48:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:48:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:48:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:48:46 --> Model Class Initialized
INFO - 2016-06-06 17:48:46 --> Form Validation Class Initialized
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:48:46 --> Final output sent to browser
DEBUG - 2016-06-06 17:48:46 --> Total execution time: 0.0738
INFO - 2016-06-06 17:48:49 --> Config Class Initialized
INFO - 2016-06-06 17:48:49 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:48:49 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:48:49 --> Utf8 Class Initialized
INFO - 2016-06-06 17:48:49 --> URI Class Initialized
INFO - 2016-06-06 17:48:49 --> Router Class Initialized
INFO - 2016-06-06 17:48:49 --> Output Class Initialized
INFO - 2016-06-06 17:48:49 --> Security Class Initialized
DEBUG - 2016-06-06 17:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:48:49 --> Input Class Initialized
INFO - 2016-06-06 17:48:49 --> Language Class Initialized
INFO - 2016-06-06 17:48:49 --> Loader Class Initialized
INFO - 2016-06-06 17:48:49 --> Helper loaded: form_helper
INFO - 2016-06-06 17:48:49 --> Database Driver Class Initialized
INFO - 2016-06-06 17:48:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:48:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:48:49 --> Email Class Initialized
INFO - 2016-06-06 17:48:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:48:49 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:48:49 --> Helper loaded: language_helper
INFO - 2016-06-06 17:48:49 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:48:49 --> Model Class Initialized
INFO - 2016-06-06 17:48:49 --> Helper loaded: date_helper
INFO - 2016-06-06 17:48:49 --> Controller Class Initialized
INFO - 2016-06-06 17:48:49 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:48:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:48:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:48:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:48:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:48:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:48:49 --> Model Class Initialized
INFO - 2016-06-06 17:48:49 --> Form Validation Class Initialized
INFO - 2016-06-06 17:48:49 --> Final output sent to browser
DEBUG - 2016-06-06 17:48:49 --> Total execution time: 0.0819
INFO - 2016-06-06 17:51:49 --> Config Class Initialized
INFO - 2016-06-06 17:51:49 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:51:49 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:51:49 --> Utf8 Class Initialized
INFO - 2016-06-06 17:51:49 --> URI Class Initialized
INFO - 2016-06-06 17:51:49 --> Router Class Initialized
INFO - 2016-06-06 17:51:49 --> Output Class Initialized
INFO - 2016-06-06 17:51:49 --> Security Class Initialized
DEBUG - 2016-06-06 17:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:51:49 --> Input Class Initialized
INFO - 2016-06-06 17:51:49 --> Language Class Initialized
INFO - 2016-06-06 17:51:49 --> Loader Class Initialized
INFO - 2016-06-06 17:51:49 --> Helper loaded: form_helper
INFO - 2016-06-06 17:51:49 --> Database Driver Class Initialized
INFO - 2016-06-06 17:51:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:51:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:51:49 --> Email Class Initialized
INFO - 2016-06-06 17:51:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:51:49 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:51:49 --> Helper loaded: language_helper
INFO - 2016-06-06 17:51:49 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:51:49 --> Model Class Initialized
INFO - 2016-06-06 17:51:49 --> Helper loaded: date_helper
INFO - 2016-06-06 17:51:49 --> Controller Class Initialized
INFO - 2016-06-06 17:51:49 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:51:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:51:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:51:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:51:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:51:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:51:49 --> Model Class Initialized
INFO - 2016-06-06 17:51:49 --> Form Validation Class Initialized
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:51:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:51:49 --> Final output sent to browser
DEBUG - 2016-06-06 17:51:49 --> Total execution time: 0.1055
INFO - 2016-06-06 17:51:51 --> Config Class Initialized
INFO - 2016-06-06 17:51:51 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:51:51 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:51:51 --> Utf8 Class Initialized
INFO - 2016-06-06 17:51:51 --> URI Class Initialized
INFO - 2016-06-06 17:51:51 --> Router Class Initialized
INFO - 2016-06-06 17:51:51 --> Output Class Initialized
INFO - 2016-06-06 17:51:51 --> Security Class Initialized
DEBUG - 2016-06-06 17:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:51:51 --> Input Class Initialized
INFO - 2016-06-06 17:51:51 --> Language Class Initialized
INFO - 2016-06-06 17:51:51 --> Loader Class Initialized
INFO - 2016-06-06 17:51:51 --> Helper loaded: form_helper
INFO - 2016-06-06 17:51:51 --> Database Driver Class Initialized
INFO - 2016-06-06 17:51:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:51:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:51:51 --> Email Class Initialized
INFO - 2016-06-06 17:51:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:51:51 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:51:51 --> Helper loaded: language_helper
INFO - 2016-06-06 17:51:51 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:51:51 --> Model Class Initialized
INFO - 2016-06-06 17:51:51 --> Helper loaded: date_helper
INFO - 2016-06-06 17:51:51 --> Controller Class Initialized
INFO - 2016-06-06 17:51:51 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:51:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:51:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:51:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:51:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:51:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:51:51 --> Model Class Initialized
INFO - 2016-06-06 17:51:51 --> Form Validation Class Initialized
INFO - 2016-06-06 17:51:51 --> Final output sent to browser
DEBUG - 2016-06-06 17:51:51 --> Total execution time: 0.0571
INFO - 2016-06-06 17:54:58 --> Config Class Initialized
INFO - 2016-06-06 17:54:58 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:54:58 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:54:58 --> Utf8 Class Initialized
INFO - 2016-06-06 17:54:58 --> URI Class Initialized
INFO - 2016-06-06 17:54:58 --> Router Class Initialized
INFO - 2016-06-06 17:54:58 --> Output Class Initialized
INFO - 2016-06-06 17:54:58 --> Security Class Initialized
DEBUG - 2016-06-06 17:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:54:58 --> Input Class Initialized
INFO - 2016-06-06 17:54:58 --> Language Class Initialized
INFO - 2016-06-06 17:54:58 --> Loader Class Initialized
INFO - 2016-06-06 17:54:58 --> Helper loaded: form_helper
INFO - 2016-06-06 17:54:58 --> Database Driver Class Initialized
INFO - 2016-06-06 17:54:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:54:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:54:58 --> Email Class Initialized
INFO - 2016-06-06 17:54:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:54:58 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:54:58 --> Helper loaded: language_helper
INFO - 2016-06-06 17:54:58 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:54:58 --> Model Class Initialized
INFO - 2016-06-06 17:54:58 --> Helper loaded: date_helper
INFO - 2016-06-06 17:54:58 --> Controller Class Initialized
INFO - 2016-06-06 17:54:58 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:54:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:54:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:54:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:54:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:54:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:54:58 --> Model Class Initialized
INFO - 2016-06-06 17:54:58 --> Form Validation Class Initialized
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:54:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:54:58 --> Final output sent to browser
DEBUG - 2016-06-06 17:54:58 --> Total execution time: 0.0911
INFO - 2016-06-06 17:55:05 --> Config Class Initialized
INFO - 2016-06-06 17:55:05 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:55:05 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:55:05 --> Utf8 Class Initialized
INFO - 2016-06-06 17:55:05 --> URI Class Initialized
INFO - 2016-06-06 17:55:05 --> Router Class Initialized
INFO - 2016-06-06 17:55:05 --> Output Class Initialized
INFO - 2016-06-06 17:55:05 --> Security Class Initialized
DEBUG - 2016-06-06 17:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:55:05 --> Input Class Initialized
INFO - 2016-06-06 17:55:05 --> Language Class Initialized
INFO - 2016-06-06 17:55:05 --> Loader Class Initialized
INFO - 2016-06-06 17:55:05 --> Helper loaded: form_helper
INFO - 2016-06-06 17:55:05 --> Database Driver Class Initialized
INFO - 2016-06-06 17:55:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:55:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:55:05 --> Email Class Initialized
INFO - 2016-06-06 17:55:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:55:05 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:55:05 --> Helper loaded: language_helper
INFO - 2016-06-06 17:55:05 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:55:05 --> Model Class Initialized
INFO - 2016-06-06 17:55:05 --> Helper loaded: date_helper
INFO - 2016-06-06 17:55:05 --> Controller Class Initialized
INFO - 2016-06-06 17:55:05 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:55:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:55:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:55:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:55:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:55:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:55:05 --> Model Class Initialized
INFO - 2016-06-06 17:55:05 --> Form Validation Class Initialized
INFO - 2016-06-06 17:55:05 --> Final output sent to browser
DEBUG - 2016-06-06 17:55:05 --> Total execution time: 0.0438
INFO - 2016-06-06 17:58:33 --> Config Class Initialized
INFO - 2016-06-06 17:58:33 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:58:33 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:58:33 --> Utf8 Class Initialized
INFO - 2016-06-06 17:58:33 --> URI Class Initialized
INFO - 2016-06-06 17:58:33 --> Router Class Initialized
INFO - 2016-06-06 17:58:33 --> Output Class Initialized
INFO - 2016-06-06 17:58:33 --> Security Class Initialized
DEBUG - 2016-06-06 17:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:58:33 --> Input Class Initialized
INFO - 2016-06-06 17:58:33 --> Language Class Initialized
INFO - 2016-06-06 17:58:33 --> Loader Class Initialized
INFO - 2016-06-06 17:58:33 --> Helper loaded: form_helper
INFO - 2016-06-06 17:58:33 --> Database Driver Class Initialized
INFO - 2016-06-06 17:58:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:58:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:58:33 --> Email Class Initialized
INFO - 2016-06-06 17:58:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:58:33 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:58:33 --> Helper loaded: language_helper
INFO - 2016-06-06 17:58:33 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:58:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:58:33 --> Model Class Initialized
INFO - 2016-06-06 17:58:33 --> Helper loaded: date_helper
INFO - 2016-06-06 17:58:33 --> Controller Class Initialized
INFO - 2016-06-06 17:58:33 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:58:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:58:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:58:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:58:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:58:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:58:33 --> Model Class Initialized
INFO - 2016-06-06 17:58:33 --> Form Validation Class Initialized
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:58:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:58:33 --> Final output sent to browser
DEBUG - 2016-06-06 17:58:33 --> Total execution time: 0.0827
INFO - 2016-06-06 17:58:37 --> Config Class Initialized
INFO - 2016-06-06 17:58:37 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:58:37 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:58:37 --> Utf8 Class Initialized
INFO - 2016-06-06 17:58:37 --> URI Class Initialized
INFO - 2016-06-06 17:58:37 --> Router Class Initialized
INFO - 2016-06-06 17:58:37 --> Output Class Initialized
INFO - 2016-06-06 17:58:37 --> Security Class Initialized
DEBUG - 2016-06-06 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:58:37 --> Input Class Initialized
INFO - 2016-06-06 17:58:37 --> Language Class Initialized
INFO - 2016-06-06 17:58:37 --> Loader Class Initialized
INFO - 2016-06-06 17:58:37 --> Helper loaded: form_helper
INFO - 2016-06-06 17:58:37 --> Database Driver Class Initialized
INFO - 2016-06-06 17:58:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:58:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:58:38 --> Email Class Initialized
INFO - 2016-06-06 17:58:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:58:38 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:58:38 --> Helper loaded: language_helper
INFO - 2016-06-06 17:58:38 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:58:38 --> Model Class Initialized
INFO - 2016-06-06 17:58:38 --> Helper loaded: date_helper
INFO - 2016-06-06 17:58:38 --> Controller Class Initialized
INFO - 2016-06-06 17:58:38 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:58:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:58:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:58:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:58:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:58:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:58:38 --> Model Class Initialized
INFO - 2016-06-06 17:58:38 --> Form Validation Class Initialized
INFO - 2016-06-06 17:58:38 --> Final output sent to browser
DEBUG - 2016-06-06 17:58:38 --> Total execution time: 0.0390
INFO - 2016-06-06 17:59:22 --> Config Class Initialized
INFO - 2016-06-06 17:59:22 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:59:22 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:59:22 --> Utf8 Class Initialized
INFO - 2016-06-06 17:59:22 --> URI Class Initialized
INFO - 2016-06-06 17:59:22 --> Router Class Initialized
INFO - 2016-06-06 17:59:22 --> Output Class Initialized
INFO - 2016-06-06 17:59:22 --> Security Class Initialized
DEBUG - 2016-06-06 17:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:59:22 --> Input Class Initialized
INFO - 2016-06-06 17:59:22 --> Language Class Initialized
INFO - 2016-06-06 17:59:22 --> Loader Class Initialized
INFO - 2016-06-06 17:59:22 --> Helper loaded: form_helper
INFO - 2016-06-06 17:59:22 --> Database Driver Class Initialized
INFO - 2016-06-06 17:59:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:59:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:59:22 --> Email Class Initialized
INFO - 2016-06-06 17:59:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:59:22 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:59:22 --> Helper loaded: language_helper
INFO - 2016-06-06 17:59:22 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:59:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:59:22 --> Model Class Initialized
INFO - 2016-06-06 17:59:22 --> Helper loaded: date_helper
INFO - 2016-06-06 17:59:22 --> Controller Class Initialized
INFO - 2016-06-06 17:59:22 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:59:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:59:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:59:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:59:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:59:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:59:22 --> Model Class Initialized
INFO - 2016-06-06 17:59:22 --> Form Validation Class Initialized
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 17:59:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 17:59:22 --> Final output sent to browser
DEBUG - 2016-06-06 17:59:22 --> Total execution time: 0.0753
INFO - 2016-06-06 17:59:26 --> Config Class Initialized
INFO - 2016-06-06 17:59:26 --> Hooks Class Initialized
DEBUG - 2016-06-06 17:59:26 --> UTF-8 Support Enabled
INFO - 2016-06-06 17:59:26 --> Utf8 Class Initialized
INFO - 2016-06-06 17:59:26 --> URI Class Initialized
INFO - 2016-06-06 17:59:26 --> Router Class Initialized
INFO - 2016-06-06 17:59:26 --> Output Class Initialized
INFO - 2016-06-06 17:59:26 --> Security Class Initialized
DEBUG - 2016-06-06 17:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 17:59:26 --> Input Class Initialized
INFO - 2016-06-06 17:59:26 --> Language Class Initialized
INFO - 2016-06-06 17:59:26 --> Loader Class Initialized
INFO - 2016-06-06 17:59:26 --> Helper loaded: form_helper
INFO - 2016-06-06 17:59:26 --> Database Driver Class Initialized
INFO - 2016-06-06 17:59:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 17:59:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 17:59:26 --> Email Class Initialized
INFO - 2016-06-06 17:59:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 17:59:26 --> Helper loaded: cookie_helper
INFO - 2016-06-06 17:59:26 --> Helper loaded: language_helper
INFO - 2016-06-06 17:59:26 --> Helper loaded: url_helper
DEBUG - 2016-06-06 17:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 17:59:26 --> Model Class Initialized
INFO - 2016-06-06 17:59:26 --> Helper loaded: date_helper
INFO - 2016-06-06 17:59:27 --> Controller Class Initialized
INFO - 2016-06-06 17:59:27 --> Helper loaded: languages_helper
INFO - 2016-06-06 17:59:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 17:59:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 17:59:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 17:59:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 17:59:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 17:59:27 --> Model Class Initialized
INFO - 2016-06-06 17:59:27 --> Form Validation Class Initialized
INFO - 2016-06-06 17:59:27 --> Final output sent to browser
DEBUG - 2016-06-06 17:59:27 --> Total execution time: 0.0620
INFO - 2016-06-06 18:01:15 --> Config Class Initialized
INFO - 2016-06-06 18:01:15 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:01:15 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:01:15 --> Utf8 Class Initialized
INFO - 2016-06-06 18:01:15 --> URI Class Initialized
INFO - 2016-06-06 18:01:15 --> Router Class Initialized
INFO - 2016-06-06 18:01:15 --> Output Class Initialized
INFO - 2016-06-06 18:01:15 --> Security Class Initialized
DEBUG - 2016-06-06 18:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:01:15 --> Input Class Initialized
INFO - 2016-06-06 18:01:15 --> Language Class Initialized
INFO - 2016-06-06 18:01:15 --> Loader Class Initialized
INFO - 2016-06-06 18:01:15 --> Helper loaded: form_helper
INFO - 2016-06-06 18:01:15 --> Database Driver Class Initialized
INFO - 2016-06-06 18:01:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:01:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:01:15 --> Email Class Initialized
INFO - 2016-06-06 18:01:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:01:15 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:01:15 --> Helper loaded: language_helper
INFO - 2016-06-06 18:01:15 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:01:15 --> Model Class Initialized
INFO - 2016-06-06 18:01:15 --> Helper loaded: date_helper
INFO - 2016-06-06 18:01:15 --> Controller Class Initialized
INFO - 2016-06-06 18:01:15 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:01:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:01:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:01:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:01:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:01:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:01:15 --> Model Class Initialized
INFO - 2016-06-06 18:01:15 --> Form Validation Class Initialized
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 18:01:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 18:01:15 --> Final output sent to browser
DEBUG - 2016-06-06 18:01:15 --> Total execution time: 0.0613
INFO - 2016-06-06 18:01:20 --> Config Class Initialized
INFO - 2016-06-06 18:01:20 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:01:20 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:01:20 --> Utf8 Class Initialized
INFO - 2016-06-06 18:01:20 --> URI Class Initialized
INFO - 2016-06-06 18:01:20 --> Router Class Initialized
INFO - 2016-06-06 18:01:20 --> Output Class Initialized
INFO - 2016-06-06 18:01:20 --> Security Class Initialized
DEBUG - 2016-06-06 18:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:01:20 --> Input Class Initialized
INFO - 2016-06-06 18:01:20 --> Language Class Initialized
INFO - 2016-06-06 18:01:20 --> Loader Class Initialized
INFO - 2016-06-06 18:01:20 --> Helper loaded: form_helper
INFO - 2016-06-06 18:01:20 --> Database Driver Class Initialized
INFO - 2016-06-06 18:01:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:01:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:01:20 --> Email Class Initialized
INFO - 2016-06-06 18:01:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:01:20 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:01:20 --> Helper loaded: language_helper
INFO - 2016-06-06 18:01:20 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:01:20 --> Model Class Initialized
INFO - 2016-06-06 18:01:20 --> Helper loaded: date_helper
INFO - 2016-06-06 18:01:20 --> Controller Class Initialized
INFO - 2016-06-06 18:01:20 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:01:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:01:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:01:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:01:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:01:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:01:20 --> Model Class Initialized
INFO - 2016-06-06 18:01:20 --> Form Validation Class Initialized
INFO - 2016-06-06 18:01:20 --> Final output sent to browser
DEBUG - 2016-06-06 18:01:20 --> Total execution time: 0.0740
INFO - 2016-06-06 18:01:43 --> Config Class Initialized
INFO - 2016-06-06 18:01:43 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:01:43 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:01:43 --> Utf8 Class Initialized
INFO - 2016-06-06 18:01:43 --> URI Class Initialized
INFO - 2016-06-06 18:01:43 --> Router Class Initialized
INFO - 2016-06-06 18:01:43 --> Output Class Initialized
INFO - 2016-06-06 18:01:43 --> Security Class Initialized
DEBUG - 2016-06-06 18:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:01:43 --> Input Class Initialized
INFO - 2016-06-06 18:01:43 --> Language Class Initialized
INFO - 2016-06-06 18:01:43 --> Loader Class Initialized
INFO - 2016-06-06 18:01:43 --> Helper loaded: form_helper
INFO - 2016-06-06 18:01:43 --> Database Driver Class Initialized
INFO - 2016-06-06 18:01:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:01:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:01:43 --> Email Class Initialized
INFO - 2016-06-06 18:01:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:01:43 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:01:43 --> Helper loaded: language_helper
INFO - 2016-06-06 18:01:43 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:01:43 --> Model Class Initialized
INFO - 2016-06-06 18:01:43 --> Helper loaded: date_helper
INFO - 2016-06-06 18:01:43 --> Controller Class Initialized
INFO - 2016-06-06 18:01:43 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:01:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:01:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:01:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:01:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:01:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:01:43 --> Model Class Initialized
INFO - 2016-06-06 18:01:43 --> Form Validation Class Initialized
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 18:01:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 18:01:43 --> Final output sent to browser
DEBUG - 2016-06-06 18:01:43 --> Total execution time: 0.0843
INFO - 2016-06-06 18:01:49 --> Config Class Initialized
INFO - 2016-06-06 18:01:49 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:01:49 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:01:49 --> Utf8 Class Initialized
INFO - 2016-06-06 18:01:49 --> URI Class Initialized
INFO - 2016-06-06 18:01:49 --> Router Class Initialized
INFO - 2016-06-06 18:01:49 --> Output Class Initialized
INFO - 2016-06-06 18:01:49 --> Security Class Initialized
DEBUG - 2016-06-06 18:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:01:49 --> Input Class Initialized
INFO - 2016-06-06 18:01:49 --> Language Class Initialized
INFO - 2016-06-06 18:01:49 --> Loader Class Initialized
INFO - 2016-06-06 18:01:49 --> Helper loaded: form_helper
INFO - 2016-06-06 18:01:49 --> Database Driver Class Initialized
INFO - 2016-06-06 18:01:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:01:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:01:49 --> Email Class Initialized
INFO - 2016-06-06 18:01:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:01:49 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:01:49 --> Helper loaded: language_helper
INFO - 2016-06-06 18:01:49 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:01:49 --> Model Class Initialized
INFO - 2016-06-06 18:01:49 --> Helper loaded: date_helper
INFO - 2016-06-06 18:01:49 --> Controller Class Initialized
INFO - 2016-06-06 18:01:49 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:01:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:01:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:01:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:01:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:01:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:01:49 --> Model Class Initialized
INFO - 2016-06-06 18:01:49 --> Form Validation Class Initialized
INFO - 2016-06-06 18:01:49 --> Final output sent to browser
DEBUG - 2016-06-06 18:01:49 --> Total execution time: 0.0414
INFO - 2016-06-06 18:06:26 --> Config Class Initialized
INFO - 2016-06-06 18:06:26 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:06:26 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:06:26 --> Utf8 Class Initialized
INFO - 2016-06-06 18:06:26 --> URI Class Initialized
INFO - 2016-06-06 18:06:26 --> Router Class Initialized
INFO - 2016-06-06 18:06:26 --> Output Class Initialized
INFO - 2016-06-06 18:06:26 --> Security Class Initialized
DEBUG - 2016-06-06 18:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:06:26 --> Input Class Initialized
INFO - 2016-06-06 18:06:26 --> Language Class Initialized
INFO - 2016-06-06 18:06:26 --> Loader Class Initialized
INFO - 2016-06-06 18:06:26 --> Helper loaded: form_helper
INFO - 2016-06-06 18:06:26 --> Database Driver Class Initialized
INFO - 2016-06-06 18:06:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:06:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:06:26 --> Email Class Initialized
INFO - 2016-06-06 18:06:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:06:26 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:06:26 --> Helper loaded: language_helper
INFO - 2016-06-06 18:06:26 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:06:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:06:26 --> Model Class Initialized
INFO - 2016-06-06 18:06:26 --> Helper loaded: date_helper
INFO - 2016-06-06 18:06:26 --> Controller Class Initialized
INFO - 2016-06-06 18:06:26 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:06:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:06:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:06:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:06:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:06:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:06:26 --> Model Class Initialized
INFO - 2016-06-06 18:06:26 --> Form Validation Class Initialized
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 18:06:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 18:06:26 --> Final output sent to browser
DEBUG - 2016-06-06 18:06:26 --> Total execution time: 0.0950
INFO - 2016-06-06 18:06:32 --> Config Class Initialized
INFO - 2016-06-06 18:06:32 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:06:32 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:06:32 --> Utf8 Class Initialized
INFO - 2016-06-06 18:06:32 --> URI Class Initialized
INFO - 2016-06-06 18:06:32 --> Router Class Initialized
INFO - 2016-06-06 18:06:32 --> Output Class Initialized
INFO - 2016-06-06 18:06:32 --> Security Class Initialized
DEBUG - 2016-06-06 18:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:06:32 --> Input Class Initialized
INFO - 2016-06-06 18:06:32 --> Language Class Initialized
INFO - 2016-06-06 18:06:32 --> Loader Class Initialized
INFO - 2016-06-06 18:06:32 --> Helper loaded: form_helper
INFO - 2016-06-06 18:06:32 --> Database Driver Class Initialized
INFO - 2016-06-06 18:06:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:06:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:06:32 --> Email Class Initialized
INFO - 2016-06-06 18:06:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:06:32 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:06:32 --> Helper loaded: language_helper
INFO - 2016-06-06 18:06:32 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:06:32 --> Model Class Initialized
INFO - 2016-06-06 18:06:32 --> Helper loaded: date_helper
INFO - 2016-06-06 18:06:32 --> Controller Class Initialized
INFO - 2016-06-06 18:06:32 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:06:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:06:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:06:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:06:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:06:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:06:32 --> Model Class Initialized
INFO - 2016-06-06 18:06:32 --> Form Validation Class Initialized
INFO - 2016-06-06 18:06:32 --> Final output sent to browser
DEBUG - 2016-06-06 18:06:32 --> Total execution time: 0.0151
INFO - 2016-06-06 18:34:01 --> Config Class Initialized
INFO - 2016-06-06 18:34:01 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:34:01 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:34:01 --> Utf8 Class Initialized
INFO - 2016-06-06 18:34:01 --> URI Class Initialized
INFO - 2016-06-06 18:34:01 --> Router Class Initialized
INFO - 2016-06-06 18:34:01 --> Output Class Initialized
INFO - 2016-06-06 18:34:01 --> Security Class Initialized
DEBUG - 2016-06-06 18:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:34:01 --> Input Class Initialized
INFO - 2016-06-06 18:34:01 --> Language Class Initialized
INFO - 2016-06-06 18:34:01 --> Loader Class Initialized
INFO - 2016-06-06 18:34:01 --> Helper loaded: form_helper
INFO - 2016-06-06 18:34:01 --> Database Driver Class Initialized
INFO - 2016-06-06 18:34:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:34:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:34:01 --> Email Class Initialized
INFO - 2016-06-06 18:34:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:34:01 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:34:01 --> Helper loaded: language_helper
INFO - 2016-06-06 18:34:01 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:34:01 --> Model Class Initialized
INFO - 2016-06-06 18:34:01 --> Helper loaded: date_helper
INFO - 2016-06-06 18:34:01 --> Controller Class Initialized
INFO - 2016-06-06 18:34:01 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:34:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:34:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:34:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:34:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:34:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:34:01 --> Model Class Initialized
INFO - 2016-06-06 18:34:01 --> Form Validation Class Initialized
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 18:34:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 18:34:01 --> Final output sent to browser
DEBUG - 2016-06-06 18:34:01 --> Total execution time: 0.0532
INFO - 2016-06-06 18:34:05 --> Config Class Initialized
INFO - 2016-06-06 18:34:05 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:34:05 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:34:05 --> Utf8 Class Initialized
INFO - 2016-06-06 18:34:05 --> URI Class Initialized
INFO - 2016-06-06 18:34:05 --> Router Class Initialized
INFO - 2016-06-06 18:34:05 --> Output Class Initialized
INFO - 2016-06-06 18:34:05 --> Security Class Initialized
DEBUG - 2016-06-06 18:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:34:05 --> Input Class Initialized
INFO - 2016-06-06 18:34:05 --> Language Class Initialized
INFO - 2016-06-06 18:34:05 --> Loader Class Initialized
INFO - 2016-06-06 18:34:05 --> Helper loaded: form_helper
INFO - 2016-06-06 18:34:05 --> Database Driver Class Initialized
INFO - 2016-06-06 18:34:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:34:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:34:05 --> Email Class Initialized
INFO - 2016-06-06 18:34:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:34:05 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:34:05 --> Helper loaded: language_helper
INFO - 2016-06-06 18:34:05 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:34:05 --> Model Class Initialized
INFO - 2016-06-06 18:34:05 --> Helper loaded: date_helper
INFO - 2016-06-06 18:34:05 --> Controller Class Initialized
INFO - 2016-06-06 18:34:05 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:34:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:34:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:34:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:34:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:34:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:34:05 --> Model Class Initialized
INFO - 2016-06-06 18:34:05 --> Form Validation Class Initialized
INFO - 2016-06-06 18:34:05 --> Final output sent to browser
DEBUG - 2016-06-06 18:34:05 --> Total execution time: 0.0617
INFO - 2016-06-06 18:36:47 --> Config Class Initialized
INFO - 2016-06-06 18:36:47 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:36:47 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:36:47 --> Utf8 Class Initialized
INFO - 2016-06-06 18:36:47 --> URI Class Initialized
INFO - 2016-06-06 18:36:47 --> Router Class Initialized
INFO - 2016-06-06 18:36:47 --> Output Class Initialized
INFO - 2016-06-06 18:36:47 --> Security Class Initialized
DEBUG - 2016-06-06 18:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:36:47 --> Input Class Initialized
INFO - 2016-06-06 18:36:47 --> Language Class Initialized
INFO - 2016-06-06 18:36:47 --> Loader Class Initialized
INFO - 2016-06-06 18:36:47 --> Helper loaded: form_helper
INFO - 2016-06-06 18:36:47 --> Database Driver Class Initialized
INFO - 2016-06-06 18:36:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:36:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:36:47 --> Email Class Initialized
INFO - 2016-06-06 18:36:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:36:47 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:36:47 --> Helper loaded: language_helper
INFO - 2016-06-06 18:36:47 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:36:47 --> Model Class Initialized
INFO - 2016-06-06 18:36:47 --> Helper loaded: date_helper
INFO - 2016-06-06 18:36:47 --> Controller Class Initialized
INFO - 2016-06-06 18:36:47 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:36:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:36:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:36:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:36:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:36:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:36:47 --> Model Class Initialized
INFO - 2016-06-06 18:36:47 --> Form Validation Class Initialized
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 18:36:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 18:36:47 --> Final output sent to browser
DEBUG - 2016-06-06 18:36:47 --> Total execution time: 0.0558
INFO - 2016-06-06 18:36:52 --> Config Class Initialized
INFO - 2016-06-06 18:36:52 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:36:52 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:36:52 --> Utf8 Class Initialized
INFO - 2016-06-06 18:36:52 --> URI Class Initialized
INFO - 2016-06-06 18:36:52 --> Router Class Initialized
INFO - 2016-06-06 18:36:52 --> Output Class Initialized
INFO - 2016-06-06 18:36:52 --> Security Class Initialized
DEBUG - 2016-06-06 18:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:36:52 --> Input Class Initialized
INFO - 2016-06-06 18:36:52 --> Language Class Initialized
INFO - 2016-06-06 18:36:52 --> Loader Class Initialized
INFO - 2016-06-06 18:36:52 --> Helper loaded: form_helper
INFO - 2016-06-06 18:36:52 --> Database Driver Class Initialized
INFO - 2016-06-06 18:36:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:36:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:36:52 --> Email Class Initialized
INFO - 2016-06-06 18:36:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:36:52 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:36:52 --> Helper loaded: language_helper
INFO - 2016-06-06 18:36:52 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:36:52 --> Model Class Initialized
INFO - 2016-06-06 18:36:52 --> Helper loaded: date_helper
INFO - 2016-06-06 18:36:52 --> Controller Class Initialized
INFO - 2016-06-06 18:36:52 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:36:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:36:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:36:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:36:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:36:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:36:52 --> Model Class Initialized
INFO - 2016-06-06 18:36:52 --> Form Validation Class Initialized
INFO - 2016-06-06 18:36:52 --> Final output sent to browser
DEBUG - 2016-06-06 18:36:52 --> Total execution time: 0.0840
INFO - 2016-06-06 18:38:23 --> Config Class Initialized
INFO - 2016-06-06 18:38:23 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:38:23 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:38:23 --> Utf8 Class Initialized
INFO - 2016-06-06 18:38:23 --> URI Class Initialized
INFO - 2016-06-06 18:38:23 --> Router Class Initialized
INFO - 2016-06-06 18:38:23 --> Output Class Initialized
INFO - 2016-06-06 18:38:23 --> Security Class Initialized
DEBUG - 2016-06-06 18:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:38:23 --> Input Class Initialized
INFO - 2016-06-06 18:38:23 --> Language Class Initialized
INFO - 2016-06-06 18:38:23 --> Loader Class Initialized
INFO - 2016-06-06 18:38:23 --> Helper loaded: form_helper
INFO - 2016-06-06 18:38:23 --> Database Driver Class Initialized
INFO - 2016-06-06 18:38:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:38:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:38:24 --> Email Class Initialized
INFO - 2016-06-06 18:38:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:38:24 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:38:24 --> Helper loaded: language_helper
INFO - 2016-06-06 18:38:24 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:38:24 --> Model Class Initialized
INFO - 2016-06-06 18:38:24 --> Helper loaded: date_helper
INFO - 2016-06-06 18:38:24 --> Controller Class Initialized
INFO - 2016-06-06 18:38:24 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:38:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:38:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:38:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:38:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:38:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:38:24 --> Model Class Initialized
INFO - 2016-06-06 18:38:24 --> Form Validation Class Initialized
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-06 18:38:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-06 18:38:24 --> Final output sent to browser
DEBUG - 2016-06-06 18:38:24 --> Total execution time: 0.0884
INFO - 2016-06-06 18:38:29 --> Config Class Initialized
INFO - 2016-06-06 18:38:29 --> Hooks Class Initialized
DEBUG - 2016-06-06 18:38:29 --> UTF-8 Support Enabled
INFO - 2016-06-06 18:38:29 --> Utf8 Class Initialized
INFO - 2016-06-06 18:38:29 --> URI Class Initialized
INFO - 2016-06-06 18:38:29 --> Router Class Initialized
INFO - 2016-06-06 18:38:29 --> Output Class Initialized
INFO - 2016-06-06 18:38:29 --> Security Class Initialized
DEBUG - 2016-06-06 18:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-06 18:38:29 --> Input Class Initialized
INFO - 2016-06-06 18:38:29 --> Language Class Initialized
INFO - 2016-06-06 18:38:29 --> Loader Class Initialized
INFO - 2016-06-06 18:38:29 --> Helper loaded: form_helper
INFO - 2016-06-06 18:38:29 --> Database Driver Class Initialized
INFO - 2016-06-06 18:38:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-06 18:38:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-06 18:38:29 --> Email Class Initialized
INFO - 2016-06-06 18:38:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-06 18:38:29 --> Helper loaded: cookie_helper
INFO - 2016-06-06 18:38:29 --> Helper loaded: language_helper
INFO - 2016-06-06 18:38:29 --> Helper loaded: url_helper
DEBUG - 2016-06-06 18:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-06 18:38:29 --> Model Class Initialized
INFO - 2016-06-06 18:38:29 --> Helper loaded: date_helper
INFO - 2016-06-06 18:38:29 --> Controller Class Initialized
INFO - 2016-06-06 18:38:29 --> Helper loaded: languages_helper
INFO - 2016-06-06 18:38:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-06 18:38:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-06 18:38:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-06 18:38:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-06 18:38:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-06 18:38:29 --> Model Class Initialized
INFO - 2016-06-06 18:38:29 --> Form Validation Class Initialized
INFO - 2016-06-06 18:38:29 --> Final output sent to browser
DEBUG - 2016-06-06 18:38:29 --> Total execution time: 0.0611
