<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-08 10:38:00 --> Config Class Initialized
INFO - 2016-06-08 10:38:00 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:38:00 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:38:00 --> Utf8 Class Initialized
INFO - 2016-06-08 10:38:00 --> URI Class Initialized
INFO - 2016-06-08 10:38:00 --> Router Class Initialized
INFO - 2016-06-08 10:38:01 --> Output Class Initialized
INFO - 2016-06-08 10:38:01 --> Security Class Initialized
DEBUG - 2016-06-08 10:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:38:01 --> Input Class Initialized
INFO - 2016-06-08 10:38:01 --> Language Class Initialized
INFO - 2016-06-08 10:38:01 --> Loader Class Initialized
INFO - 2016-06-08 10:38:01 --> Helper loaded: form_helper
INFO - 2016-06-08 10:38:02 --> Database Driver Class Initialized
INFO - 2016-06-08 10:38:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 10:38:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 10:38:03 --> Email Class Initialized
INFO - 2016-06-08 10:38:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 10:38:03 --> Helper loaded: cookie_helper
INFO - 2016-06-08 10:38:03 --> Helper loaded: language_helper
INFO - 2016-06-08 10:38:03 --> Helper loaded: url_helper
DEBUG - 2016-06-08 10:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:38:04 --> Model Class Initialized
INFO - 2016-06-08 10:38:04 --> Helper loaded: date_helper
INFO - 2016-06-08 10:38:04 --> Controller Class Initialized
INFO - 2016-06-08 10:38:04 --> Helper loaded: languages_helper
INFO - 2016-06-08 10:38:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 10:38:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 10:38:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 10:38:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 10:38:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 10:38:04 --> Model Class Initialized
INFO - 2016-06-08 10:38:04 --> Form Validation Class Initialized
INFO - 2016-06-08 10:38:05 --> Config Class Initialized
INFO - 2016-06-08 10:38:05 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:38:05 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:38:05 --> Utf8 Class Initialized
INFO - 2016-06-08 10:38:05 --> URI Class Initialized
INFO - 2016-06-08 10:38:05 --> Router Class Initialized
INFO - 2016-06-08 10:38:05 --> Output Class Initialized
INFO - 2016-06-08 10:38:05 --> Security Class Initialized
DEBUG - 2016-06-08 10:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:38:05 --> Input Class Initialized
INFO - 2016-06-08 10:38:05 --> Language Class Initialized
INFO - 2016-06-08 10:38:05 --> Loader Class Initialized
INFO - 2016-06-08 10:38:05 --> Helper loaded: form_helper
INFO - 2016-06-08 10:38:05 --> Database Driver Class Initialized
INFO - 2016-06-08 10:38:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 10:38:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 10:38:05 --> Email Class Initialized
INFO - 2016-06-08 10:38:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 10:38:05 --> Helper loaded: cookie_helper
INFO - 2016-06-08 10:38:05 --> Helper loaded: language_helper
INFO - 2016-06-08 10:38:05 --> Helper loaded: url_helper
DEBUG - 2016-06-08 10:38:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:38:05 --> Model Class Initialized
INFO - 2016-06-08 10:38:05 --> Helper loaded: date_helper
INFO - 2016-06-08 10:38:05 --> Controller Class Initialized
INFO - 2016-06-08 10:38:05 --> Helper loaded: languages_helper
INFO - 2016-06-08 10:38:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 10:38:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 10:38:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 10:38:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 10:38:05 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-08 10:38:05 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:38:05 --> Form Validation Class Initialized
DEBUG - 2016-06-08 10:38:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:38:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-08 10:38:05 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-08 10:38:05 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-08 10:38:05 --> Final output sent to browser
DEBUG - 2016-06-08 10:38:05 --> Total execution time: 0.5968
INFO - 2016-06-08 10:38:10 --> Config Class Initialized
INFO - 2016-06-08 10:38:10 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:38:10 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:38:10 --> Utf8 Class Initialized
INFO - 2016-06-08 10:38:10 --> URI Class Initialized
INFO - 2016-06-08 10:38:10 --> Router Class Initialized
INFO - 2016-06-08 10:38:10 --> Output Class Initialized
INFO - 2016-06-08 10:38:10 --> Security Class Initialized
DEBUG - 2016-06-08 10:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:38:10 --> Input Class Initialized
INFO - 2016-06-08 10:38:10 --> Language Class Initialized
ERROR - 2016-06-08 10:38:10 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-08 10:38:56 --> Config Class Initialized
INFO - 2016-06-08 10:38:56 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:38:56 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:38:56 --> Utf8 Class Initialized
INFO - 2016-06-08 10:38:56 --> URI Class Initialized
INFO - 2016-06-08 10:38:56 --> Router Class Initialized
INFO - 2016-06-08 10:38:56 --> Output Class Initialized
INFO - 2016-06-08 10:38:56 --> Security Class Initialized
DEBUG - 2016-06-08 10:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:38:56 --> Input Class Initialized
INFO - 2016-06-08 10:38:56 --> Language Class Initialized
INFO - 2016-06-08 10:38:56 --> Loader Class Initialized
INFO - 2016-06-08 10:38:56 --> Helper loaded: form_helper
INFO - 2016-06-08 10:38:56 --> Database Driver Class Initialized
INFO - 2016-06-08 10:38:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 10:38:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 10:38:56 --> Email Class Initialized
INFO - 2016-06-08 10:38:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 10:38:56 --> Helper loaded: cookie_helper
INFO - 2016-06-08 10:38:56 --> Helper loaded: language_helper
INFO - 2016-06-08 10:38:56 --> Helper loaded: url_helper
DEBUG - 2016-06-08 10:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:38:56 --> Model Class Initialized
INFO - 2016-06-08 10:38:56 --> Helper loaded: date_helper
INFO - 2016-06-08 10:38:56 --> Controller Class Initialized
INFO - 2016-06-08 10:38:56 --> Helper loaded: languages_helper
INFO - 2016-06-08 10:38:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 10:38:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 10:38:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 10:38:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 10:38:56 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-08 10:38:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:38:56 --> Form Validation Class Initialized
DEBUG - 2016-06-08 10:38:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:38:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-08 10:38:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-08 10:38:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-08 10:38:56 --> Final output sent to browser
DEBUG - 2016-06-08 10:38:56 --> Total execution time: 0.1080
INFO - 2016-06-08 10:39:33 --> Config Class Initialized
INFO - 2016-06-08 10:39:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:39:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:39:33 --> Utf8 Class Initialized
INFO - 2016-06-08 10:39:33 --> URI Class Initialized
INFO - 2016-06-08 10:39:33 --> Router Class Initialized
INFO - 2016-06-08 10:39:33 --> Output Class Initialized
INFO - 2016-06-08 10:39:33 --> Security Class Initialized
DEBUG - 2016-06-08 10:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:39:33 --> Input Class Initialized
INFO - 2016-06-08 10:39:33 --> Language Class Initialized
INFO - 2016-06-08 10:39:33 --> Loader Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: form_helper
INFO - 2016-06-08 10:39:33 --> Database Driver Class Initialized
INFO - 2016-06-08 10:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 10:39:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 10:39:33 --> Email Class Initialized
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 10:39:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 10:39:33 --> Helper loaded: language_helper
INFO - 2016-06-08 10:39:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 10:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:39:33 --> Model Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: date_helper
INFO - 2016-06-08 10:39:33 --> Controller Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-08 10:39:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:39:33 --> Form Validation Class Initialized
DEBUG - 2016-06-08 10:39:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:39:33 --> Config Class Initialized
INFO - 2016-06-08 10:39:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:39:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:39:33 --> Utf8 Class Initialized
INFO - 2016-06-08 10:39:33 --> URI Class Initialized
DEBUG - 2016-06-08 10:39:33 --> No URI present. Default controller set.
INFO - 2016-06-08 10:39:33 --> Router Class Initialized
INFO - 2016-06-08 10:39:33 --> Output Class Initialized
INFO - 2016-06-08 10:39:33 --> Security Class Initialized
DEBUG - 2016-06-08 10:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:39:33 --> Input Class Initialized
INFO - 2016-06-08 10:39:33 --> Language Class Initialized
INFO - 2016-06-08 10:39:33 --> Loader Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: form_helper
INFO - 2016-06-08 10:39:33 --> Database Driver Class Initialized
INFO - 2016-06-08 10:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 10:39:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 10:39:33 --> Email Class Initialized
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 10:39:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 10:39:33 --> Helper loaded: language_helper
INFO - 2016-06-08 10:39:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 10:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:39:33 --> Model Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: date_helper
INFO - 2016-06-08 10:39:33 --> Controller Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 10:39:33 --> Config Class Initialized
INFO - 2016-06-08 10:39:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:39:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:39:33 --> Utf8 Class Initialized
INFO - 2016-06-08 10:39:33 --> URI Class Initialized
INFO - 2016-06-08 10:39:33 --> Router Class Initialized
INFO - 2016-06-08 10:39:33 --> Output Class Initialized
INFO - 2016-06-08 10:39:33 --> Security Class Initialized
DEBUG - 2016-06-08 10:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:39:33 --> Input Class Initialized
INFO - 2016-06-08 10:39:33 --> Language Class Initialized
INFO - 2016-06-08 10:39:33 --> Loader Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: form_helper
INFO - 2016-06-08 10:39:33 --> Database Driver Class Initialized
INFO - 2016-06-08 10:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 10:39:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 10:39:33 --> Email Class Initialized
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 10:39:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 10:39:33 --> Helper loaded: language_helper
INFO - 2016-06-08 10:39:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 10:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:39:33 --> Model Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: date_helper
INFO - 2016-06-08 10:39:33 --> Controller Class Initialized
INFO - 2016-06-08 10:39:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 10:39:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 10:39:33 --> Model Class Initialized
INFO - 2016-06-08 10:39:33 --> Form Validation Class Initialized
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-08 10:39:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 10:39:33 --> Final output sent to browser
DEBUG - 2016-06-08 10:39:33 --> Total execution time: 0.2614
INFO - 2016-06-08 10:39:52 --> Config Class Initialized
INFO - 2016-06-08 10:39:52 --> Hooks Class Initialized
DEBUG - 2016-06-08 10:39:52 --> UTF-8 Support Enabled
INFO - 2016-06-08 10:39:52 --> Utf8 Class Initialized
INFO - 2016-06-08 10:39:52 --> URI Class Initialized
INFO - 2016-06-08 10:39:52 --> Router Class Initialized
INFO - 2016-06-08 10:39:52 --> Output Class Initialized
INFO - 2016-06-08 10:39:52 --> Security Class Initialized
DEBUG - 2016-06-08 10:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 10:39:52 --> Input Class Initialized
INFO - 2016-06-08 10:39:52 --> Language Class Initialized
INFO - 2016-06-08 10:39:52 --> Loader Class Initialized
INFO - 2016-06-08 10:39:52 --> Helper loaded: form_helper
INFO - 2016-06-08 10:39:52 --> Database Driver Class Initialized
INFO - 2016-06-08 10:39:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 10:39:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 10:39:52 --> Email Class Initialized
INFO - 2016-06-08 10:39:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 10:39:52 --> Helper loaded: cookie_helper
INFO - 2016-06-08 10:39:52 --> Helper loaded: language_helper
INFO - 2016-06-08 10:39:52 --> Helper loaded: url_helper
DEBUG - 2016-06-08 10:39:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 10:39:52 --> Model Class Initialized
INFO - 2016-06-08 10:39:52 --> Helper loaded: date_helper
INFO - 2016-06-08 10:39:52 --> Controller Class Initialized
INFO - 2016-06-08 10:39:52 --> Helper loaded: languages_helper
INFO - 2016-06-08 10:39:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 10:39:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 10:39:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 10:39:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 10:39:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 10:39:52 --> Model Class Initialized
INFO - 2016-06-08 10:39:52 --> Form Validation Class Initialized
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 10:39:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 10:39:52 --> Final output sent to browser
DEBUG - 2016-06-08 10:39:52 --> Total execution time: 0.1708
INFO - 2016-06-08 11:18:37 --> Config Class Initialized
INFO - 2016-06-08 11:18:37 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:18:38 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:18:38 --> Utf8 Class Initialized
INFO - 2016-06-08 11:18:38 --> URI Class Initialized
INFO - 2016-06-08 11:18:38 --> Router Class Initialized
INFO - 2016-06-08 11:18:38 --> Output Class Initialized
INFO - 2016-06-08 11:18:38 --> Security Class Initialized
DEBUG - 2016-06-08 11:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:18:38 --> Input Class Initialized
INFO - 2016-06-08 11:18:38 --> Language Class Initialized
INFO - 2016-06-08 11:18:38 --> Loader Class Initialized
INFO - 2016-06-08 11:18:38 --> Helper loaded: form_helper
INFO - 2016-06-08 11:18:39 --> Database Driver Class Initialized
INFO - 2016-06-08 11:18:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:18:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:18:43 --> Email Class Initialized
INFO - 2016-06-08 11:18:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:18:43 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:18:43 --> Helper loaded: language_helper
INFO - 2016-06-08 11:18:43 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:18:43 --> Model Class Initialized
INFO - 2016-06-08 11:18:43 --> Helper loaded: date_helper
INFO - 2016-06-08 11:18:44 --> Controller Class Initialized
INFO - 2016-06-08 11:18:44 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:18:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:18:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:18:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:18:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:18:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:18:44 --> Model Class Initialized
INFO - 2016-06-08 11:18:44 --> Form Validation Class Initialized
INFO - 2016-06-08 11:18:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:18:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:18:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:18:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:18:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:18:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:18:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:18:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:18:47 --> Final output sent to browser
DEBUG - 2016-06-08 11:18:47 --> Total execution time: 11.0462
INFO - 2016-06-08 11:20:45 --> Config Class Initialized
INFO - 2016-06-08 11:20:45 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:20:45 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:20:45 --> Utf8 Class Initialized
INFO - 2016-06-08 11:20:45 --> URI Class Initialized
INFO - 2016-06-08 11:20:45 --> Router Class Initialized
INFO - 2016-06-08 11:20:45 --> Output Class Initialized
INFO - 2016-06-08 11:20:45 --> Security Class Initialized
DEBUG - 2016-06-08 11:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:20:45 --> Input Class Initialized
INFO - 2016-06-08 11:20:45 --> Language Class Initialized
INFO - 2016-06-08 11:20:45 --> Loader Class Initialized
INFO - 2016-06-08 11:20:45 --> Helper loaded: form_helper
INFO - 2016-06-08 11:20:45 --> Database Driver Class Initialized
INFO - 2016-06-08 11:20:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:20:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:20:45 --> Email Class Initialized
INFO - 2016-06-08 11:20:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:20:45 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:20:45 --> Helper loaded: language_helper
INFO - 2016-06-08 11:20:45 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:20:45 --> Model Class Initialized
INFO - 2016-06-08 11:20:45 --> Helper loaded: date_helper
INFO - 2016-06-08 11:20:45 --> Controller Class Initialized
INFO - 2016-06-08 11:20:45 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:20:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:20:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:20:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:20:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:20:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:20:45 --> Model Class Initialized
INFO - 2016-06-08 11:20:45 --> Form Validation Class Initialized
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:20:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:20:45 --> Final output sent to browser
DEBUG - 2016-06-08 11:20:45 --> Total execution time: 0.1184
INFO - 2016-06-08 11:22:32 --> Config Class Initialized
INFO - 2016-06-08 11:22:32 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:22:32 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:22:32 --> Utf8 Class Initialized
INFO - 2016-06-08 11:22:32 --> URI Class Initialized
INFO - 2016-06-08 11:22:32 --> Router Class Initialized
INFO - 2016-06-08 11:22:32 --> Output Class Initialized
INFO - 2016-06-08 11:22:32 --> Security Class Initialized
DEBUG - 2016-06-08 11:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:22:32 --> Input Class Initialized
INFO - 2016-06-08 11:22:32 --> Language Class Initialized
INFO - 2016-06-08 11:22:32 --> Loader Class Initialized
INFO - 2016-06-08 11:22:32 --> Helper loaded: form_helper
INFO - 2016-06-08 11:22:32 --> Database Driver Class Initialized
INFO - 2016-06-08 11:22:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:22:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:22:33 --> Email Class Initialized
INFO - 2016-06-08 11:22:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:22:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:22:33 --> Helper loaded: language_helper
INFO - 2016-06-08 11:22:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:22:33 --> Model Class Initialized
INFO - 2016-06-08 11:22:33 --> Helper loaded: date_helper
INFO - 2016-06-08 11:22:33 --> Controller Class Initialized
INFO - 2016-06-08 11:22:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:22:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:22:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:22:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:22:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:22:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:22:33 --> Model Class Initialized
INFO - 2016-06-08 11:22:33 --> Form Validation Class Initialized
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:22:33 --> Final output sent to browser
DEBUG - 2016-06-08 11:22:33 --> Total execution time: 0.1575
INFO - 2016-06-08 11:29:28 --> Config Class Initialized
INFO - 2016-06-08 11:29:28 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:29:28 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:29:28 --> Utf8 Class Initialized
INFO - 2016-06-08 11:29:28 --> URI Class Initialized
INFO - 2016-06-08 11:29:28 --> Router Class Initialized
INFO - 2016-06-08 11:29:28 --> Output Class Initialized
INFO - 2016-06-08 11:29:28 --> Security Class Initialized
DEBUG - 2016-06-08 11:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:29:28 --> Input Class Initialized
INFO - 2016-06-08 11:29:28 --> Language Class Initialized
INFO - 2016-06-08 11:29:28 --> Loader Class Initialized
INFO - 2016-06-08 11:29:28 --> Helper loaded: form_helper
INFO - 2016-06-08 11:29:28 --> Database Driver Class Initialized
INFO - 2016-06-08 11:29:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:29:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:29:28 --> Email Class Initialized
INFO - 2016-06-08 11:29:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:29:28 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:29:28 --> Helper loaded: language_helper
INFO - 2016-06-08 11:29:28 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:29:29 --> Model Class Initialized
INFO - 2016-06-08 11:29:29 --> Helper loaded: date_helper
INFO - 2016-06-08 11:29:29 --> Controller Class Initialized
INFO - 2016-06-08 11:29:29 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:29:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:29:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:29:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:29:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:29:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:29:29 --> Model Class Initialized
INFO - 2016-06-08 11:29:29 --> Form Validation Class Initialized
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:29:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:29:29 --> Final output sent to browser
DEBUG - 2016-06-08 11:29:29 --> Total execution time: 0.1460
INFO - 2016-06-08 11:30:04 --> Config Class Initialized
INFO - 2016-06-08 11:30:04 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:30:04 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:30:04 --> Utf8 Class Initialized
INFO - 2016-06-08 11:30:04 --> URI Class Initialized
INFO - 2016-06-08 11:30:04 --> Router Class Initialized
INFO - 2016-06-08 11:30:04 --> Output Class Initialized
INFO - 2016-06-08 11:30:04 --> Security Class Initialized
DEBUG - 2016-06-08 11:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:30:04 --> Input Class Initialized
INFO - 2016-06-08 11:30:04 --> Language Class Initialized
INFO - 2016-06-08 11:30:04 --> Loader Class Initialized
INFO - 2016-06-08 11:30:04 --> Helper loaded: form_helper
INFO - 2016-06-08 11:30:04 --> Database Driver Class Initialized
INFO - 2016-06-08 11:30:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:30:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:30:05 --> Email Class Initialized
INFO - 2016-06-08 11:30:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:30:05 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:30:05 --> Helper loaded: language_helper
INFO - 2016-06-08 11:30:05 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:30:05 --> Model Class Initialized
INFO - 2016-06-08 11:30:05 --> Helper loaded: date_helper
INFO - 2016-06-08 11:30:05 --> Controller Class Initialized
INFO - 2016-06-08 11:30:05 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:30:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:30:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:30:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:30:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:30:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:30:05 --> Model Class Initialized
INFO - 2016-06-08 11:30:05 --> Form Validation Class Initialized
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:30:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:30:05 --> Final output sent to browser
DEBUG - 2016-06-08 11:30:05 --> Total execution time: 0.0626
INFO - 2016-06-08 11:30:22 --> Config Class Initialized
INFO - 2016-06-08 11:30:22 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:30:22 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:30:22 --> Utf8 Class Initialized
INFO - 2016-06-08 11:30:22 --> URI Class Initialized
INFO - 2016-06-08 11:30:22 --> Router Class Initialized
INFO - 2016-06-08 11:30:22 --> Output Class Initialized
INFO - 2016-06-08 11:30:22 --> Security Class Initialized
DEBUG - 2016-06-08 11:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:30:22 --> Input Class Initialized
INFO - 2016-06-08 11:30:22 --> Language Class Initialized
INFO - 2016-06-08 11:30:22 --> Loader Class Initialized
INFO - 2016-06-08 11:30:22 --> Helper loaded: form_helper
INFO - 2016-06-08 11:30:22 --> Database Driver Class Initialized
INFO - 2016-06-08 11:30:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:30:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:30:22 --> Email Class Initialized
INFO - 2016-06-08 11:30:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:30:22 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:30:22 --> Helper loaded: language_helper
INFO - 2016-06-08 11:30:23 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:30:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:30:23 --> Model Class Initialized
INFO - 2016-06-08 11:30:23 --> Helper loaded: date_helper
INFO - 2016-06-08 11:30:23 --> Controller Class Initialized
INFO - 2016-06-08 11:30:23 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:30:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:30:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:30:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:30:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:30:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:30:23 --> Model Class Initialized
INFO - 2016-06-08 11:30:23 --> Form Validation Class Initialized
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:30:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:30:23 --> Final output sent to browser
DEBUG - 2016-06-08 11:30:23 --> Total execution time: 0.0777
INFO - 2016-06-08 11:30:38 --> Config Class Initialized
INFO - 2016-06-08 11:30:38 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:30:38 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:30:38 --> Utf8 Class Initialized
INFO - 2016-06-08 11:30:38 --> URI Class Initialized
INFO - 2016-06-08 11:30:38 --> Router Class Initialized
INFO - 2016-06-08 11:30:38 --> Output Class Initialized
INFO - 2016-06-08 11:30:38 --> Security Class Initialized
DEBUG - 2016-06-08 11:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:30:38 --> Input Class Initialized
INFO - 2016-06-08 11:30:38 --> Language Class Initialized
INFO - 2016-06-08 11:30:38 --> Loader Class Initialized
INFO - 2016-06-08 11:30:38 --> Helper loaded: form_helper
INFO - 2016-06-08 11:30:38 --> Database Driver Class Initialized
INFO - 2016-06-08 11:30:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:30:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:30:38 --> Email Class Initialized
INFO - 2016-06-08 11:30:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:30:38 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:30:38 --> Helper loaded: language_helper
INFO - 2016-06-08 11:30:38 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:30:38 --> Model Class Initialized
INFO - 2016-06-08 11:30:38 --> Helper loaded: date_helper
INFO - 2016-06-08 11:30:38 --> Controller Class Initialized
INFO - 2016-06-08 11:30:38 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:30:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:30:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:30:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:30:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:30:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:30:38 --> Model Class Initialized
INFO - 2016-06-08 11:30:38 --> Form Validation Class Initialized
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:30:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:30:38 --> Final output sent to browser
DEBUG - 2016-06-08 11:30:38 --> Total execution time: 0.0640
INFO - 2016-06-08 11:33:49 --> Config Class Initialized
INFO - 2016-06-08 11:33:49 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:33:49 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:33:49 --> Utf8 Class Initialized
INFO - 2016-06-08 11:33:49 --> URI Class Initialized
INFO - 2016-06-08 11:33:49 --> Router Class Initialized
INFO - 2016-06-08 11:33:49 --> Output Class Initialized
INFO - 2016-06-08 11:33:49 --> Security Class Initialized
DEBUG - 2016-06-08 11:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:33:49 --> Input Class Initialized
INFO - 2016-06-08 11:33:49 --> Language Class Initialized
INFO - 2016-06-08 11:33:49 --> Loader Class Initialized
INFO - 2016-06-08 11:33:49 --> Helper loaded: form_helper
INFO - 2016-06-08 11:33:49 --> Database Driver Class Initialized
INFO - 2016-06-08 11:33:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:33:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:33:49 --> Email Class Initialized
INFO - 2016-06-08 11:33:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:33:49 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:33:49 --> Helper loaded: language_helper
INFO - 2016-06-08 11:33:49 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:33:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:33:49 --> Model Class Initialized
INFO - 2016-06-08 11:33:49 --> Helper loaded: date_helper
INFO - 2016-06-08 11:33:49 --> Controller Class Initialized
INFO - 2016-06-08 11:33:49 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:33:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:33:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:33:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:33:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:33:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:33:49 --> Model Class Initialized
INFO - 2016-06-08 11:33:49 --> Form Validation Class Initialized
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:33:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:33:49 --> Final output sent to browser
DEBUG - 2016-06-08 11:33:49 --> Total execution time: 0.0601
INFO - 2016-06-08 11:36:10 --> Config Class Initialized
INFO - 2016-06-08 11:36:10 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:36:10 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:36:10 --> Utf8 Class Initialized
INFO - 2016-06-08 11:36:10 --> URI Class Initialized
INFO - 2016-06-08 11:36:10 --> Router Class Initialized
INFO - 2016-06-08 11:36:10 --> Output Class Initialized
INFO - 2016-06-08 11:36:10 --> Security Class Initialized
DEBUG - 2016-06-08 11:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:36:10 --> Input Class Initialized
INFO - 2016-06-08 11:36:10 --> Language Class Initialized
INFO - 2016-06-08 11:36:10 --> Loader Class Initialized
INFO - 2016-06-08 11:36:10 --> Helper loaded: form_helper
INFO - 2016-06-08 11:36:10 --> Database Driver Class Initialized
INFO - 2016-06-08 11:36:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:36:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:36:10 --> Email Class Initialized
INFO - 2016-06-08 11:36:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:36:10 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:36:10 --> Helper loaded: language_helper
INFO - 2016-06-08 11:36:10 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:36:10 --> Model Class Initialized
INFO - 2016-06-08 11:36:10 --> Helper loaded: date_helper
INFO - 2016-06-08 11:36:10 --> Controller Class Initialized
INFO - 2016-06-08 11:36:10 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:36:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:36:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:36:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:36:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:36:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:36:10 --> Model Class Initialized
INFO - 2016-06-08 11:36:10 --> Form Validation Class Initialized
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:36:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:36:10 --> Final output sent to browser
DEBUG - 2016-06-08 11:36:10 --> Total execution time: 0.0519
INFO - 2016-06-08 11:36:19 --> Config Class Initialized
INFO - 2016-06-08 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:36:19 --> Utf8 Class Initialized
INFO - 2016-06-08 11:36:19 --> URI Class Initialized
INFO - 2016-06-08 11:36:19 --> Router Class Initialized
INFO - 2016-06-08 11:36:19 --> Output Class Initialized
INFO - 2016-06-08 11:36:19 --> Security Class Initialized
DEBUG - 2016-06-08 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:36:19 --> Input Class Initialized
INFO - 2016-06-08 11:36:19 --> Language Class Initialized
INFO - 2016-06-08 11:36:19 --> Loader Class Initialized
INFO - 2016-06-08 11:36:19 --> Helper loaded: form_helper
INFO - 2016-06-08 11:36:19 --> Database Driver Class Initialized
INFO - 2016-06-08 11:36:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:36:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:36:19 --> Email Class Initialized
INFO - 2016-06-08 11:36:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:36:19 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:36:19 --> Helper loaded: language_helper
INFO - 2016-06-08 11:36:19 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:36:19 --> Model Class Initialized
INFO - 2016-06-08 11:36:19 --> Helper loaded: date_helper
INFO - 2016-06-08 11:36:19 --> Controller Class Initialized
INFO - 2016-06-08 11:36:19 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:36:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:36:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:36:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:36:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:36:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:36:19 --> Model Class Initialized
INFO - 2016-06-08 11:36:19 --> Form Validation Class Initialized
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:36:19 --> Final output sent to browser
DEBUG - 2016-06-08 11:36:19 --> Total execution time: 0.1181
INFO - 2016-06-08 11:36:23 --> Config Class Initialized
INFO - 2016-06-08 11:36:23 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:36:23 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:36:23 --> Utf8 Class Initialized
INFO - 2016-06-08 11:36:23 --> URI Class Initialized
INFO - 2016-06-08 11:36:23 --> Router Class Initialized
INFO - 2016-06-08 11:36:23 --> Output Class Initialized
INFO - 2016-06-08 11:36:23 --> Security Class Initialized
DEBUG - 2016-06-08 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:36:23 --> Input Class Initialized
INFO - 2016-06-08 11:36:23 --> Language Class Initialized
INFO - 2016-06-08 11:36:23 --> Loader Class Initialized
INFO - 2016-06-08 11:36:23 --> Helper loaded: form_helper
INFO - 2016-06-08 11:36:23 --> Database Driver Class Initialized
INFO - 2016-06-08 11:36:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:36:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:36:23 --> Email Class Initialized
INFO - 2016-06-08 11:36:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:36:23 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:36:23 --> Helper loaded: language_helper
INFO - 2016-06-08 11:36:23 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:36:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:36:23 --> Model Class Initialized
INFO - 2016-06-08 11:36:23 --> Helper loaded: date_helper
INFO - 2016-06-08 11:36:23 --> Controller Class Initialized
INFO - 2016-06-08 11:36:23 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:36:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:36:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:36:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:36:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:36:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-08 11:36:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:36:23 --> Form Validation Class Initialized
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/change_password.php
INFO - 2016-06-08 11:36:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:36:23 --> Final output sent to browser
DEBUG - 2016-06-08 11:36:23 --> Total execution time: 0.1127
INFO - 2016-06-08 11:36:57 --> Config Class Initialized
INFO - 2016-06-08 11:36:57 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:36:57 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:36:57 --> Utf8 Class Initialized
INFO - 2016-06-08 11:36:57 --> URI Class Initialized
INFO - 2016-06-08 11:36:57 --> Router Class Initialized
INFO - 2016-06-08 11:36:57 --> Output Class Initialized
INFO - 2016-06-08 11:36:57 --> Security Class Initialized
DEBUG - 2016-06-08 11:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:36:57 --> Input Class Initialized
INFO - 2016-06-08 11:36:57 --> Language Class Initialized
INFO - 2016-06-08 11:36:57 --> Loader Class Initialized
INFO - 2016-06-08 11:36:57 --> Helper loaded: form_helper
INFO - 2016-06-08 11:36:57 --> Database Driver Class Initialized
INFO - 2016-06-08 11:36:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:36:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:36:57 --> Email Class Initialized
INFO - 2016-06-08 11:36:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:36:57 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:36:57 --> Helper loaded: language_helper
INFO - 2016-06-08 11:36:57 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:36:57 --> Model Class Initialized
INFO - 2016-06-08 11:36:57 --> Helper loaded: date_helper
INFO - 2016-06-08 11:36:57 --> Controller Class Initialized
INFO - 2016-06-08 11:36:57 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:36:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:36:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:36:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:36:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:36:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:36:57 --> Model Class Initialized
INFO - 2016-06-08 11:36:57 --> Form Validation Class Initialized
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:36:57 --> Final output sent to browser
DEBUG - 2016-06-08 11:36:57 --> Total execution time: 0.1793
INFO - 2016-06-08 11:39:33 --> Config Class Initialized
INFO - 2016-06-08 11:39:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:39:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:39:33 --> Utf8 Class Initialized
INFO - 2016-06-08 11:39:33 --> URI Class Initialized
INFO - 2016-06-08 11:39:33 --> Router Class Initialized
INFO - 2016-06-08 11:39:33 --> Output Class Initialized
INFO - 2016-06-08 11:39:33 --> Security Class Initialized
DEBUG - 2016-06-08 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:39:33 --> Input Class Initialized
INFO - 2016-06-08 11:39:33 --> Language Class Initialized
INFO - 2016-06-08 11:39:33 --> Loader Class Initialized
INFO - 2016-06-08 11:39:33 --> Helper loaded: form_helper
INFO - 2016-06-08 11:39:33 --> Database Driver Class Initialized
INFO - 2016-06-08 11:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:39:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:39:33 --> Email Class Initialized
INFO - 2016-06-08 11:39:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:39:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:39:33 --> Helper loaded: language_helper
INFO - 2016-06-08 11:39:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:39:33 --> Model Class Initialized
INFO - 2016-06-08 11:39:33 --> Helper loaded: date_helper
INFO - 2016-06-08 11:39:33 --> Controller Class Initialized
INFO - 2016-06-08 11:39:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:39:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:39:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:39:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:39:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:39:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:39:33 --> Model Class Initialized
INFO - 2016-06-08 11:39:33 --> Form Validation Class Initialized
ERROR - 2016-06-08 11:39:33 --> Severity: Notice --> Undefined variable: content /home/demis/www/platformadiabet/application/controllers/Diabet.php 476
INFO - 2016-06-08 11:40:07 --> Config Class Initialized
INFO - 2016-06-08 11:40:07 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:40:07 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:40:07 --> Utf8 Class Initialized
INFO - 2016-06-08 11:40:07 --> URI Class Initialized
INFO - 2016-06-08 11:40:07 --> Router Class Initialized
INFO - 2016-06-08 11:40:07 --> Output Class Initialized
INFO - 2016-06-08 11:40:07 --> Security Class Initialized
DEBUG - 2016-06-08 11:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:40:07 --> Input Class Initialized
INFO - 2016-06-08 11:40:07 --> Language Class Initialized
INFO - 2016-06-08 11:40:07 --> Loader Class Initialized
INFO - 2016-06-08 11:40:07 --> Helper loaded: form_helper
INFO - 2016-06-08 11:40:07 --> Database Driver Class Initialized
INFO - 2016-06-08 11:40:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:40:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:40:08 --> Email Class Initialized
INFO - 2016-06-08 11:40:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:40:08 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:40:08 --> Helper loaded: language_helper
INFO - 2016-06-08 11:40:08 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:40:08 --> Model Class Initialized
INFO - 2016-06-08 11:40:08 --> Helper loaded: date_helper
INFO - 2016-06-08 11:40:08 --> Controller Class Initialized
INFO - 2016-06-08 11:40:08 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:40:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:40:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:40:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:40:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:40:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:40:08 --> Model Class Initialized
INFO - 2016-06-08 11:40:08 --> Form Validation Class Initialized
ERROR - 2016-06-08 11:40:08 --> Severity: Notice --> Undefined variable: textarea /home/demis/www/platformadiabet/application/controllers/Diabet.php 474
INFO - 2016-06-08 11:40:33 --> Config Class Initialized
INFO - 2016-06-08 11:40:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:40:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:40:33 --> Utf8 Class Initialized
INFO - 2016-06-08 11:40:33 --> URI Class Initialized
INFO - 2016-06-08 11:40:33 --> Router Class Initialized
INFO - 2016-06-08 11:40:33 --> Output Class Initialized
INFO - 2016-06-08 11:40:33 --> Security Class Initialized
DEBUG - 2016-06-08 11:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:40:33 --> Input Class Initialized
INFO - 2016-06-08 11:40:33 --> Language Class Initialized
INFO - 2016-06-08 11:40:33 --> Loader Class Initialized
INFO - 2016-06-08 11:40:33 --> Helper loaded: form_helper
INFO - 2016-06-08 11:40:33 --> Database Driver Class Initialized
INFO - 2016-06-08 11:40:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:40:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:40:33 --> Email Class Initialized
INFO - 2016-06-08 11:40:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:40:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:40:33 --> Helper loaded: language_helper
INFO - 2016-06-08 11:40:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:40:33 --> Model Class Initialized
INFO - 2016-06-08 11:40:33 --> Helper loaded: date_helper
INFO - 2016-06-08 11:40:33 --> Controller Class Initialized
INFO - 2016-06-08 11:40:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:40:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:40:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:40:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:40:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:40:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:40:33 --> Model Class Initialized
INFO - 2016-06-08 11:40:33 --> Form Validation Class Initialized
INFO - 2016-06-08 11:41:46 --> Config Class Initialized
INFO - 2016-06-08 11:41:46 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:41:46 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:41:46 --> Utf8 Class Initialized
INFO - 2016-06-08 11:41:46 --> URI Class Initialized
INFO - 2016-06-08 11:41:46 --> Router Class Initialized
INFO - 2016-06-08 11:41:46 --> Output Class Initialized
INFO - 2016-06-08 11:41:46 --> Security Class Initialized
DEBUG - 2016-06-08 11:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:41:46 --> Input Class Initialized
INFO - 2016-06-08 11:41:46 --> Language Class Initialized
INFO - 2016-06-08 11:41:46 --> Loader Class Initialized
INFO - 2016-06-08 11:41:46 --> Helper loaded: form_helper
INFO - 2016-06-08 11:41:46 --> Database Driver Class Initialized
INFO - 2016-06-08 11:41:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:41:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:41:46 --> Email Class Initialized
INFO - 2016-06-08 11:41:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:41:46 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:41:46 --> Helper loaded: language_helper
INFO - 2016-06-08 11:41:46 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:41:46 --> Model Class Initialized
INFO - 2016-06-08 11:41:46 --> Helper loaded: date_helper
INFO - 2016-06-08 11:41:46 --> Controller Class Initialized
INFO - 2016-06-08 11:41:46 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:41:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:41:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:41:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:41:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:41:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:41:46 --> Model Class Initialized
INFO - 2016-06-08 11:41:46 --> Form Validation Class Initialized
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:41:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:41:46 --> Final output sent to browser
DEBUG - 2016-06-08 11:41:46 --> Total execution time: 0.0849
INFO - 2016-06-08 11:41:47 --> Config Class Initialized
INFO - 2016-06-08 11:41:47 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:41:47 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:41:47 --> Utf8 Class Initialized
INFO - 2016-06-08 11:41:47 --> URI Class Initialized
INFO - 2016-06-08 11:41:47 --> Router Class Initialized
INFO - 2016-06-08 11:41:47 --> Output Class Initialized
INFO - 2016-06-08 11:41:47 --> Security Class Initialized
DEBUG - 2016-06-08 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:41:47 --> Input Class Initialized
INFO - 2016-06-08 11:41:47 --> Language Class Initialized
INFO - 2016-06-08 11:41:47 --> Loader Class Initialized
INFO - 2016-06-08 11:41:47 --> Helper loaded: form_helper
INFO - 2016-06-08 11:41:47 --> Database Driver Class Initialized
INFO - 2016-06-08 11:41:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:41:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:41:47 --> Email Class Initialized
INFO - 2016-06-08 11:41:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:41:47 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:41:47 --> Helper loaded: language_helper
INFO - 2016-06-08 11:41:47 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:41:47 --> Model Class Initialized
INFO - 2016-06-08 11:41:47 --> Helper loaded: date_helper
INFO - 2016-06-08 11:41:47 --> Controller Class Initialized
INFO - 2016-06-08 11:41:47 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:41:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:41:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:41:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:41:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:41:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:41:47 --> Model Class Initialized
INFO - 2016-06-08 11:41:47 --> Form Validation Class Initialized
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:41:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:41:47 --> Final output sent to browser
DEBUG - 2016-06-08 11:41:47 --> Total execution time: 0.0320
INFO - 2016-06-08 11:42:06 --> Config Class Initialized
INFO - 2016-06-08 11:42:06 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:42:06 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:42:06 --> Utf8 Class Initialized
INFO - 2016-06-08 11:42:06 --> URI Class Initialized
INFO - 2016-06-08 11:42:06 --> Router Class Initialized
INFO - 2016-06-08 11:42:06 --> Output Class Initialized
INFO - 2016-06-08 11:42:06 --> Security Class Initialized
DEBUG - 2016-06-08 11:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:42:06 --> Input Class Initialized
INFO - 2016-06-08 11:42:06 --> Language Class Initialized
INFO - 2016-06-08 11:42:06 --> Loader Class Initialized
INFO - 2016-06-08 11:42:06 --> Helper loaded: form_helper
INFO - 2016-06-08 11:42:06 --> Database Driver Class Initialized
INFO - 2016-06-08 11:42:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:42:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:42:06 --> Email Class Initialized
INFO - 2016-06-08 11:42:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:42:06 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:42:06 --> Helper loaded: language_helper
INFO - 2016-06-08 11:42:06 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:42:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:42:06 --> Model Class Initialized
INFO - 2016-06-08 11:42:06 --> Helper loaded: date_helper
INFO - 2016-06-08 11:42:06 --> Controller Class Initialized
INFO - 2016-06-08 11:42:06 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:42:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:42:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:42:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:42:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:42:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:42:06 --> Model Class Initialized
INFO - 2016-06-08 11:42:06 --> Form Validation Class Initialized
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:42:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:42:06 --> Final output sent to browser
DEBUG - 2016-06-08 11:42:06 --> Total execution time: 0.0787
INFO - 2016-06-08 11:44:08 --> Config Class Initialized
INFO - 2016-06-08 11:44:08 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:44:08 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:44:08 --> Utf8 Class Initialized
INFO - 2016-06-08 11:44:08 --> URI Class Initialized
INFO - 2016-06-08 11:44:08 --> Router Class Initialized
INFO - 2016-06-08 11:44:08 --> Output Class Initialized
INFO - 2016-06-08 11:44:08 --> Security Class Initialized
DEBUG - 2016-06-08 11:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:44:08 --> Input Class Initialized
INFO - 2016-06-08 11:44:08 --> Language Class Initialized
INFO - 2016-06-08 11:44:08 --> Loader Class Initialized
INFO - 2016-06-08 11:44:08 --> Helper loaded: form_helper
INFO - 2016-06-08 11:44:08 --> Database Driver Class Initialized
INFO - 2016-06-08 11:44:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:44:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:44:08 --> Email Class Initialized
INFO - 2016-06-08 11:44:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:44:08 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:44:08 --> Helper loaded: language_helper
INFO - 2016-06-08 11:44:08 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:44:08 --> Model Class Initialized
INFO - 2016-06-08 11:44:08 --> Helper loaded: date_helper
INFO - 2016-06-08 11:44:08 --> Controller Class Initialized
INFO - 2016-06-08 11:44:08 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:44:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:44:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:44:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:44:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:44:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:44:08 --> Model Class Initialized
INFO - 2016-06-08 11:44:08 --> Form Validation Class Initialized
INFO - 2016-06-08 11:46:30 --> Config Class Initialized
INFO - 2016-06-08 11:46:30 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:46:30 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:46:30 --> Utf8 Class Initialized
INFO - 2016-06-08 11:46:30 --> URI Class Initialized
INFO - 2016-06-08 11:46:30 --> Router Class Initialized
INFO - 2016-06-08 11:46:30 --> Output Class Initialized
INFO - 2016-06-08 11:46:30 --> Security Class Initialized
DEBUG - 2016-06-08 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:46:30 --> Input Class Initialized
INFO - 2016-06-08 11:46:30 --> Language Class Initialized
INFO - 2016-06-08 11:46:30 --> Loader Class Initialized
INFO - 2016-06-08 11:46:30 --> Helper loaded: form_helper
INFO - 2016-06-08 11:46:30 --> Database Driver Class Initialized
INFO - 2016-06-08 11:46:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:46:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:46:30 --> Email Class Initialized
INFO - 2016-06-08 11:46:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:46:30 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:46:30 --> Helper loaded: language_helper
INFO - 2016-06-08 11:46:30 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:46:30 --> Model Class Initialized
INFO - 2016-06-08 11:46:30 --> Helper loaded: date_helper
INFO - 2016-06-08 11:46:30 --> Controller Class Initialized
INFO - 2016-06-08 11:46:30 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:46:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:46:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:46:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:46:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:46:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:46:31 --> Model Class Initialized
INFO - 2016-06-08 11:46:31 --> Form Validation Class Initialized
INFO - 2016-06-08 11:48:00 --> Config Class Initialized
INFO - 2016-06-08 11:48:00 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:48:00 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:48:00 --> Utf8 Class Initialized
INFO - 2016-06-08 11:48:00 --> URI Class Initialized
INFO - 2016-06-08 11:48:00 --> Router Class Initialized
INFO - 2016-06-08 11:48:00 --> Output Class Initialized
INFO - 2016-06-08 11:48:00 --> Security Class Initialized
DEBUG - 2016-06-08 11:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:48:00 --> Input Class Initialized
INFO - 2016-06-08 11:48:00 --> Language Class Initialized
INFO - 2016-06-08 11:48:00 --> Loader Class Initialized
INFO - 2016-06-08 11:48:00 --> Helper loaded: form_helper
INFO - 2016-06-08 11:48:00 --> Database Driver Class Initialized
INFO - 2016-06-08 11:48:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:48:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:48:00 --> Email Class Initialized
INFO - 2016-06-08 11:48:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:48:00 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:48:00 --> Helper loaded: language_helper
INFO - 2016-06-08 11:48:00 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:48:00 --> Model Class Initialized
INFO - 2016-06-08 11:48:00 --> Helper loaded: date_helper
INFO - 2016-06-08 11:48:00 --> Controller Class Initialized
INFO - 2016-06-08 11:48:00 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:48:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:48:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:48:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:48:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:48:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:48:00 --> Model Class Initialized
INFO - 2016-06-08 11:48:00 --> Form Validation Class Initialized
INFO - 2016-06-08 11:49:16 --> Config Class Initialized
INFO - 2016-06-08 11:49:16 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:49:16 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:49:16 --> Utf8 Class Initialized
INFO - 2016-06-08 11:49:16 --> URI Class Initialized
INFO - 2016-06-08 11:49:16 --> Router Class Initialized
INFO - 2016-06-08 11:49:16 --> Output Class Initialized
INFO - 2016-06-08 11:49:16 --> Security Class Initialized
DEBUG - 2016-06-08 11:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:49:16 --> Input Class Initialized
INFO - 2016-06-08 11:49:16 --> Language Class Initialized
INFO - 2016-06-08 11:49:16 --> Loader Class Initialized
INFO - 2016-06-08 11:49:16 --> Helper loaded: form_helper
INFO - 2016-06-08 11:49:16 --> Database Driver Class Initialized
INFO - 2016-06-08 11:49:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:49:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:49:16 --> Email Class Initialized
INFO - 2016-06-08 11:49:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:49:16 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:49:16 --> Helper loaded: language_helper
INFO - 2016-06-08 11:49:16 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:49:16 --> Model Class Initialized
INFO - 2016-06-08 11:49:16 --> Helper loaded: date_helper
INFO - 2016-06-08 11:49:16 --> Controller Class Initialized
INFO - 2016-06-08 11:49:16 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:49:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:49:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:49:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:49:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:49:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:49:16 --> Model Class Initialized
INFO - 2016-06-08 11:49:16 --> Form Validation Class Initialized
INFO - 2016-06-08 11:49:23 --> Config Class Initialized
INFO - 2016-06-08 11:49:23 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:49:23 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:49:23 --> Utf8 Class Initialized
INFO - 2016-06-08 11:49:23 --> URI Class Initialized
INFO - 2016-06-08 11:49:23 --> Router Class Initialized
INFO - 2016-06-08 11:49:23 --> Output Class Initialized
INFO - 2016-06-08 11:49:23 --> Security Class Initialized
DEBUG - 2016-06-08 11:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:49:23 --> Input Class Initialized
INFO - 2016-06-08 11:49:23 --> Language Class Initialized
INFO - 2016-06-08 11:49:23 --> Loader Class Initialized
INFO - 2016-06-08 11:49:23 --> Helper loaded: form_helper
INFO - 2016-06-08 11:49:23 --> Database Driver Class Initialized
INFO - 2016-06-08 11:49:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:49:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:49:23 --> Email Class Initialized
INFO - 2016-06-08 11:49:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:49:23 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:49:23 --> Helper loaded: language_helper
INFO - 2016-06-08 11:49:23 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:49:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:49:23 --> Model Class Initialized
INFO - 2016-06-08 11:49:23 --> Helper loaded: date_helper
INFO - 2016-06-08 11:49:23 --> Controller Class Initialized
INFO - 2016-06-08 11:49:23 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:49:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:49:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:49:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:49:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:49:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:49:23 --> Model Class Initialized
INFO - 2016-06-08 11:49:23 --> Form Validation Class Initialized
INFO - 2016-06-08 11:50:14 --> Config Class Initialized
INFO - 2016-06-08 11:50:14 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:50:14 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:50:14 --> Utf8 Class Initialized
INFO - 2016-06-08 11:50:14 --> URI Class Initialized
INFO - 2016-06-08 11:50:14 --> Router Class Initialized
INFO - 2016-06-08 11:50:14 --> Output Class Initialized
INFO - 2016-06-08 11:50:14 --> Security Class Initialized
DEBUG - 2016-06-08 11:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:50:14 --> Input Class Initialized
INFO - 2016-06-08 11:50:14 --> Language Class Initialized
INFO - 2016-06-08 11:50:14 --> Loader Class Initialized
INFO - 2016-06-08 11:50:14 --> Helper loaded: form_helper
INFO - 2016-06-08 11:50:14 --> Database Driver Class Initialized
INFO - 2016-06-08 11:50:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:50:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:50:14 --> Email Class Initialized
INFO - 2016-06-08 11:50:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:50:14 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:50:14 --> Helper loaded: language_helper
INFO - 2016-06-08 11:50:14 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:50:14 --> Model Class Initialized
INFO - 2016-06-08 11:50:14 --> Helper loaded: date_helper
INFO - 2016-06-08 11:50:14 --> Controller Class Initialized
INFO - 2016-06-08 11:50:14 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:50:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:50:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:50:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:50:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:50:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:50:14 --> Model Class Initialized
INFO - 2016-06-08 11:50:14 --> Form Validation Class Initialized
ERROR - 2016-06-08 11:50:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1, '<div align="justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit' at line 4 - Invalid query: 
            INSERT INTO `posts` 
                ( `title`, `content`, `featured` ) 
            VALUES
                ( Post 1, '<div align="justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.<br></div>', 1 )
        
INFO - 2016-06-08 11:54:30 --> Config Class Initialized
INFO - 2016-06-08 11:54:30 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:54:30 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:54:30 --> Utf8 Class Initialized
INFO - 2016-06-08 11:54:30 --> URI Class Initialized
INFO - 2016-06-08 11:54:30 --> Router Class Initialized
INFO - 2016-06-08 11:54:30 --> Output Class Initialized
INFO - 2016-06-08 11:54:30 --> Security Class Initialized
DEBUG - 2016-06-08 11:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:54:30 --> Input Class Initialized
INFO - 2016-06-08 11:54:30 --> Language Class Initialized
INFO - 2016-06-08 11:54:30 --> Loader Class Initialized
INFO - 2016-06-08 11:54:30 --> Helper loaded: form_helper
INFO - 2016-06-08 11:54:30 --> Database Driver Class Initialized
INFO - 2016-06-08 11:54:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:54:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:54:30 --> Email Class Initialized
INFO - 2016-06-08 11:54:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:54:30 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:54:30 --> Helper loaded: language_helper
INFO - 2016-06-08 11:54:30 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:54:30 --> Model Class Initialized
INFO - 2016-06-08 11:54:30 --> Helper loaded: date_helper
INFO - 2016-06-08 11:54:30 --> Controller Class Initialized
INFO - 2016-06-08 11:54:30 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:54:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:54:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:54:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:54:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:54:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:54:30 --> Model Class Initialized
INFO - 2016-06-08 11:54:30 --> Form Validation Class Initialized
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:54:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:54:30 --> Final output sent to browser
DEBUG - 2016-06-08 11:54:30 --> Total execution time: 0.0861
INFO - 2016-06-08 11:56:17 --> Config Class Initialized
INFO - 2016-06-08 11:56:17 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:56:17 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:56:17 --> Utf8 Class Initialized
INFO - 2016-06-08 11:56:17 --> URI Class Initialized
INFO - 2016-06-08 11:56:17 --> Router Class Initialized
INFO - 2016-06-08 11:56:17 --> Output Class Initialized
INFO - 2016-06-08 11:56:17 --> Security Class Initialized
DEBUG - 2016-06-08 11:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:56:17 --> Input Class Initialized
INFO - 2016-06-08 11:56:17 --> Language Class Initialized
INFO - 2016-06-08 11:56:17 --> Loader Class Initialized
INFO - 2016-06-08 11:56:17 --> Helper loaded: form_helper
INFO - 2016-06-08 11:56:17 --> Database Driver Class Initialized
INFO - 2016-06-08 11:56:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:56:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:56:18 --> Email Class Initialized
INFO - 2016-06-08 11:56:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:56:18 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:56:18 --> Helper loaded: language_helper
INFO - 2016-06-08 11:56:18 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:56:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:56:18 --> Model Class Initialized
INFO - 2016-06-08 11:56:18 --> Helper loaded: date_helper
INFO - 2016-06-08 11:56:18 --> Controller Class Initialized
INFO - 2016-06-08 11:56:18 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:56:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:56:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:56:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:56:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:56:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:56:18 --> Model Class Initialized
INFO - 2016-06-08 11:56:18 --> Form Validation Class Initialized
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:56:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:56:18 --> Final output sent to browser
DEBUG - 2016-06-08 11:56:18 --> Total execution time: 0.0989
INFO - 2016-06-08 11:58:08 --> Config Class Initialized
INFO - 2016-06-08 11:58:08 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:58:08 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:58:08 --> Utf8 Class Initialized
INFO - 2016-06-08 11:58:08 --> URI Class Initialized
INFO - 2016-06-08 11:58:08 --> Router Class Initialized
INFO - 2016-06-08 11:58:08 --> Output Class Initialized
INFO - 2016-06-08 11:58:08 --> Security Class Initialized
DEBUG - 2016-06-08 11:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:58:08 --> Input Class Initialized
INFO - 2016-06-08 11:58:08 --> Language Class Initialized
INFO - 2016-06-08 11:58:08 --> Loader Class Initialized
INFO - 2016-06-08 11:58:08 --> Helper loaded: form_helper
INFO - 2016-06-08 11:58:08 --> Database Driver Class Initialized
INFO - 2016-06-08 11:58:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:58:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:58:08 --> Email Class Initialized
INFO - 2016-06-08 11:58:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:58:08 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:58:08 --> Helper loaded: language_helper
INFO - 2016-06-08 11:58:08 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:58:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:58:08 --> Model Class Initialized
INFO - 2016-06-08 11:58:08 --> Helper loaded: date_helper
INFO - 2016-06-08 11:58:08 --> Controller Class Initialized
INFO - 2016-06-08 11:58:08 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:58:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:58:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:58:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:58:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:58:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:58:08 --> Model Class Initialized
INFO - 2016-06-08 11:58:08 --> Form Validation Class Initialized
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 11:58:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 11:58:08 --> Final output sent to browser
DEBUG - 2016-06-08 11:58:08 --> Total execution time: 0.0556
INFO - 2016-06-08 11:58:44 --> Config Class Initialized
INFO - 2016-06-08 11:58:44 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:58:44 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:58:44 --> Utf8 Class Initialized
INFO - 2016-06-08 11:58:44 --> URI Class Initialized
INFO - 2016-06-08 11:58:44 --> Router Class Initialized
INFO - 2016-06-08 11:58:44 --> Output Class Initialized
INFO - 2016-06-08 11:58:44 --> Security Class Initialized
DEBUG - 2016-06-08 11:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:58:44 --> Input Class Initialized
INFO - 2016-06-08 11:58:44 --> Language Class Initialized
INFO - 2016-06-08 11:58:44 --> Loader Class Initialized
INFO - 2016-06-08 11:58:44 --> Helper loaded: form_helper
INFO - 2016-06-08 11:58:44 --> Database Driver Class Initialized
INFO - 2016-06-08 11:58:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:58:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:58:44 --> Email Class Initialized
INFO - 2016-06-08 11:58:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:58:44 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:58:44 --> Helper loaded: language_helper
INFO - 2016-06-08 11:58:44 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:58:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:58:44 --> Model Class Initialized
INFO - 2016-06-08 11:58:44 --> Helper loaded: date_helper
INFO - 2016-06-08 11:58:44 --> Controller Class Initialized
INFO - 2016-06-08 11:58:44 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:58:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:58:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:58:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:58:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:58:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:58:44 --> Model Class Initialized
INFO - 2016-06-08 11:58:44 --> Form Validation Class Initialized
ERROR - 2016-06-08 11:58:44 --> Severity: Error --> Call to undefined function html_entity_encode() /home/demis/www/platformadiabet/application/controllers/Diabet.php 469
INFO - 2016-06-08 11:59:19 --> Config Class Initialized
INFO - 2016-06-08 11:59:19 --> Hooks Class Initialized
DEBUG - 2016-06-08 11:59:19 --> UTF-8 Support Enabled
INFO - 2016-06-08 11:59:19 --> Utf8 Class Initialized
INFO - 2016-06-08 11:59:19 --> URI Class Initialized
INFO - 2016-06-08 11:59:19 --> Router Class Initialized
INFO - 2016-06-08 11:59:19 --> Output Class Initialized
INFO - 2016-06-08 11:59:19 --> Security Class Initialized
DEBUG - 2016-06-08 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 11:59:19 --> Input Class Initialized
INFO - 2016-06-08 11:59:19 --> Language Class Initialized
INFO - 2016-06-08 11:59:19 --> Loader Class Initialized
INFO - 2016-06-08 11:59:19 --> Helper loaded: form_helper
INFO - 2016-06-08 11:59:19 --> Database Driver Class Initialized
INFO - 2016-06-08 11:59:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 11:59:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 11:59:19 --> Email Class Initialized
INFO - 2016-06-08 11:59:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 11:59:19 --> Helper loaded: cookie_helper
INFO - 2016-06-08 11:59:19 --> Helper loaded: language_helper
INFO - 2016-06-08 11:59:19 --> Helper loaded: url_helper
DEBUG - 2016-06-08 11:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 11:59:19 --> Model Class Initialized
INFO - 2016-06-08 11:59:19 --> Helper loaded: date_helper
INFO - 2016-06-08 11:59:19 --> Controller Class Initialized
INFO - 2016-06-08 11:59:19 --> Helper loaded: languages_helper
INFO - 2016-06-08 11:59:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 11:59:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 11:59:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 11:59:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 11:59:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 11:59:19 --> Model Class Initialized
INFO - 2016-06-08 11:59:19 --> Form Validation Class Initialized
ERROR - 2016-06-08 11:59:19 --> Severity: Error --> Call to undefined function html_entity_encode() /home/demis/www/platformadiabet/application/controllers/Diabet.php 468
INFO - 2016-06-08 12:00:18 --> Config Class Initialized
INFO - 2016-06-08 12:00:18 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:00:18 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:00:18 --> Utf8 Class Initialized
INFO - 2016-06-08 12:00:18 --> URI Class Initialized
INFO - 2016-06-08 12:00:18 --> Router Class Initialized
INFO - 2016-06-08 12:00:18 --> Output Class Initialized
INFO - 2016-06-08 12:00:18 --> Security Class Initialized
DEBUG - 2016-06-08 12:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:00:18 --> Input Class Initialized
INFO - 2016-06-08 12:00:18 --> Language Class Initialized
INFO - 2016-06-08 12:00:18 --> Loader Class Initialized
INFO - 2016-06-08 12:00:18 --> Helper loaded: form_helper
INFO - 2016-06-08 12:00:18 --> Database Driver Class Initialized
INFO - 2016-06-08 12:00:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:00:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:00:18 --> Email Class Initialized
INFO - 2016-06-08 12:00:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:00:18 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:00:18 --> Helper loaded: language_helper
INFO - 2016-06-08 12:00:18 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:00:18 --> Model Class Initialized
INFO - 2016-06-08 12:00:18 --> Helper loaded: date_helper
INFO - 2016-06-08 12:00:19 --> Controller Class Initialized
INFO - 2016-06-08 12:00:19 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:00:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:00:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:00:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:00:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:00:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:00:19 --> Model Class Initialized
INFO - 2016-06-08 12:00:19 --> Form Validation Class Initialized
ERROR - 2016-06-08 12:00:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1, '&lt;div align=&quot;justify&quot;&gt;Lorem ipsum dolor sit amet, consectetur' at line 4 - Invalid query: 
            INSERT INTO `posts` 
                ( `title`, `content`, `featured` ) 
            VALUES
                ( Post 1, '&lt;div align=&quot;justify&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.&lt;br&gt;&lt;/div&gt;', 1 )
        
INFO - 2016-06-08 12:04:28 --> Config Class Initialized
INFO - 2016-06-08 12:04:28 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:04:28 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:04:28 --> Utf8 Class Initialized
INFO - 2016-06-08 12:04:28 --> URI Class Initialized
INFO - 2016-06-08 12:04:28 --> Router Class Initialized
INFO - 2016-06-08 12:04:28 --> Output Class Initialized
INFO - 2016-06-08 12:04:28 --> Security Class Initialized
DEBUG - 2016-06-08 12:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:04:28 --> Input Class Initialized
INFO - 2016-06-08 12:04:28 --> Language Class Initialized
INFO - 2016-06-08 12:04:28 --> Loader Class Initialized
INFO - 2016-06-08 12:04:28 --> Helper loaded: form_helper
INFO - 2016-06-08 12:04:28 --> Database Driver Class Initialized
INFO - 2016-06-08 12:04:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:04:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:04:28 --> Email Class Initialized
INFO - 2016-06-08 12:04:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:04:28 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:04:28 --> Helper loaded: language_helper
INFO - 2016-06-08 12:04:28 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:04:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:04:28 --> Model Class Initialized
INFO - 2016-06-08 12:04:28 --> Helper loaded: date_helper
INFO - 2016-06-08 12:04:28 --> Controller Class Initialized
INFO - 2016-06-08 12:04:28 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:04:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:04:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:04:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:04:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:04:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:04:28 --> Model Class Initialized
INFO - 2016-06-08 12:04:28 --> Form Validation Class Initialized
ERROR - 2016-06-08 12:04:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1, '&lt;div align=&quot;justify&quot;&gt;Lorem ipsum dolor sit amet, consectetur' at line 4 - Invalid query: 
            INSERT INTO `posts` 
                ( `title`, `content`, `featured` ) 
            VALUES
                ( Post 1, '&lt;div align=&quot;justify&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.&lt;br&gt;&lt;/div&gt;', 1 )
        
INFO - 2016-06-08 12:06:05 --> Config Class Initialized
INFO - 2016-06-08 12:06:05 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:06:05 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:06:05 --> Utf8 Class Initialized
INFO - 2016-06-08 12:06:05 --> URI Class Initialized
INFO - 2016-06-08 12:06:05 --> Router Class Initialized
INFO - 2016-06-08 12:06:05 --> Output Class Initialized
INFO - 2016-06-08 12:06:05 --> Security Class Initialized
DEBUG - 2016-06-08 12:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:06:05 --> Input Class Initialized
INFO - 2016-06-08 12:06:05 --> Language Class Initialized
INFO - 2016-06-08 12:06:05 --> Loader Class Initialized
INFO - 2016-06-08 12:06:05 --> Helper loaded: form_helper
INFO - 2016-06-08 12:06:05 --> Database Driver Class Initialized
INFO - 2016-06-08 12:06:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:06:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:06:05 --> Email Class Initialized
INFO - 2016-06-08 12:06:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:06:05 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:06:05 --> Helper loaded: language_helper
INFO - 2016-06-08 12:06:05 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:06:05 --> Model Class Initialized
INFO - 2016-06-08 12:06:05 --> Helper loaded: date_helper
INFO - 2016-06-08 12:06:05 --> Controller Class Initialized
INFO - 2016-06-08 12:06:05 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:06:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:06:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:06:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:06:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:06:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:06:05 --> Model Class Initialized
INFO - 2016-06-08 12:06:05 --> Form Validation Class Initialized
ERROR - 2016-06-08 12:06:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`title`, `content`, `featured`
            VALUES
                'Post 1', '&lt' at line 2 - Invalid query: 
            INSERT INTO `posts` 
                `title`, `content`, `featured`
            VALUES
                'Post 1', '&lt;div align=&quot;justify&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.&lt;br&gt;&lt;/div&gt;', '1'
        
INFO - 2016-06-08 12:07:21 --> Config Class Initialized
INFO - 2016-06-08 12:07:21 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:07:21 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:07:21 --> Utf8 Class Initialized
INFO - 2016-06-08 12:07:21 --> URI Class Initialized
INFO - 2016-06-08 12:07:21 --> Router Class Initialized
INFO - 2016-06-08 12:07:21 --> Output Class Initialized
INFO - 2016-06-08 12:07:21 --> Security Class Initialized
DEBUG - 2016-06-08 12:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:07:21 --> Input Class Initialized
INFO - 2016-06-08 12:07:21 --> Language Class Initialized
INFO - 2016-06-08 12:07:21 --> Loader Class Initialized
INFO - 2016-06-08 12:07:21 --> Helper loaded: form_helper
INFO - 2016-06-08 12:07:21 --> Database Driver Class Initialized
INFO - 2016-06-08 12:07:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:07:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:07:21 --> Email Class Initialized
INFO - 2016-06-08 12:07:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:07:21 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:07:21 --> Helper loaded: language_helper
INFO - 2016-06-08 12:07:21 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:07:21 --> Model Class Initialized
INFO - 2016-06-08 12:07:21 --> Helper loaded: date_helper
INFO - 2016-06-08 12:07:21 --> Controller Class Initialized
INFO - 2016-06-08 12:07:21 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:07:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:07:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:07:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:07:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:07:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:07:21 --> Model Class Initialized
INFO - 2016-06-08 12:07:21 --> Form Validation Class Initialized
ERROR - 2016-06-08 12:07:21 --> Severity: Error --> Call to undefined function base_64_encode() /home/demis/www/platformadiabet/application/controllers/Diabet.php 468
INFO - 2016-06-08 12:07:34 --> Config Class Initialized
INFO - 2016-06-08 12:07:34 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:07:34 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:07:35 --> Utf8 Class Initialized
INFO - 2016-06-08 12:07:35 --> URI Class Initialized
INFO - 2016-06-08 12:07:35 --> Router Class Initialized
INFO - 2016-06-08 12:07:35 --> Output Class Initialized
INFO - 2016-06-08 12:07:35 --> Security Class Initialized
DEBUG - 2016-06-08 12:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:07:35 --> Input Class Initialized
INFO - 2016-06-08 12:07:35 --> Language Class Initialized
INFO - 2016-06-08 12:07:35 --> Loader Class Initialized
INFO - 2016-06-08 12:07:35 --> Helper loaded: form_helper
INFO - 2016-06-08 12:07:35 --> Database Driver Class Initialized
INFO - 2016-06-08 12:07:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:07:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:07:35 --> Email Class Initialized
INFO - 2016-06-08 12:07:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:07:35 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:07:35 --> Helper loaded: language_helper
INFO - 2016-06-08 12:07:35 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:07:35 --> Model Class Initialized
INFO - 2016-06-08 12:07:35 --> Helper loaded: date_helper
INFO - 2016-06-08 12:07:35 --> Controller Class Initialized
INFO - 2016-06-08 12:07:35 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:07:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:07:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:07:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:07:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:07:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:07:35 --> Model Class Initialized
INFO - 2016-06-08 12:07:35 --> Form Validation Class Initialized
ERROR - 2016-06-08 12:07:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`title`, `content`, `featured`
            VALUES
                'Post 1', 'Jmx' at line 2 - Invalid query: 
            INSERT INTO `posts` 
                `title`, `content`, `featured`
            VALUES
                'Post 1', 'Jmx0O2RpdiBhbGlnbj0mcXVvdDtqdXN0aWZ5JnF1b3Q7Jmd0O0xvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0LCBjb25zZWN0ZXR1ciBhZGlwaXNjaW5nIGVsaXQsIHNlZCBkbyBlaXVzbW9kIHRlbXBvciBpbmNpZGlkdW50IHV0IGxhYm9yZSBldCBkb2xvcmUgbWFnbmEgYWxpcXVhLiBVdCBlbmltIGFkIG1pbmltIHZlbmlhbSwgcXVpcyBub3N0cnVkIGV4ZXJjaXRhdGlvbiB1bGxhbWNvIGxhYm9yaXMgbmlzaSB1dCBhbGlxdWlwIGV4IGVhIGNvbW1vZG8gY29uc2VxdWF0LiBMb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCwgY29uc2VjdGV0dXIgYWRpcGlzY2luZyBlbGl0LCBzZWQgZG8gZWl1c21vZCB0ZW1wb3IgaW5jaWRpZHVudCB1dCBsYWJvcmUgZXQgZG9sb3JlIG1hZ25hIGFsaXF1YS4gVXQgZW5pbSBhZCBtaW5pbSB2ZW5pYW0sIHF1aXMgbm9zdHJ1ZCBleGVyY2l0YXRpb24gdWxsYW1jbyBsYWJvcmlzIG5pc2kgdXQgYWxpcXVpcCBleCBlYSBjb21tb2RvIGNvbnNlcXVhdC4gTG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdCwgc2VkIGRvIGVpdXNtb2QgdGVtcG9yIGluY2lkaWR1bnQgdXQgbGFib3JlIGV0IGRvbG9yZSBtYWduYSBhbGlxdWEuIFV0IGVuaW0gYWQgbWluaW0gdmVuaWFtLCBxdWlzIG5vc3RydWQgZXhlcmNpdGF0aW9uIHVsbGFtY28gbGFib3JpcyBuaXNpIHV0IGFsaXF1aXAgZXggZWEgY29tbW9kbyBjb25zZXF1YXQuIExvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0LCBjb25zZWN0ZXR1ciBhZGlwaXNjaW5nIGVsaXQsIHNlZCBkbyBlaXVzbW9kIHRlbXBvciBpbmNpZGlkdW50IHV0IGxhYm9yZSBldCBkb2xvcmUgbWFnbmEgYWxpcXVhLiBVdCBlbmltIGFkIG1pbmltIHZlbmlhbSwgcXVpcyBub3N0cnVkIGV4ZXJjaXRhdGlvbiB1bGxhbWNvIGxhYm9yaXMgbmlzaSB1dCBhbGlxdWlwIGV4IGVhIGNvbW1vZG8gY29uc2VxdWF0LiZsdDticiZndDsmbHQ7L2RpdiZndDs=', '1'
        
INFO - 2016-06-08 12:19:15 --> Config Class Initialized
INFO - 2016-06-08 12:19:15 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:19:15 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:19:15 --> Utf8 Class Initialized
INFO - 2016-06-08 12:19:15 --> URI Class Initialized
INFO - 2016-06-08 12:19:15 --> Router Class Initialized
INFO - 2016-06-08 12:19:15 --> Output Class Initialized
INFO - 2016-06-08 12:19:15 --> Security Class Initialized
DEBUG - 2016-06-08 12:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:19:15 --> Input Class Initialized
INFO - 2016-06-08 12:19:15 --> Language Class Initialized
INFO - 2016-06-08 12:19:15 --> Loader Class Initialized
INFO - 2016-06-08 12:19:15 --> Helper loaded: form_helper
INFO - 2016-06-08 12:19:15 --> Database Driver Class Initialized
INFO - 2016-06-08 12:19:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:19:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:19:15 --> Email Class Initialized
INFO - 2016-06-08 12:19:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:19:15 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:19:15 --> Helper loaded: language_helper
INFO - 2016-06-08 12:19:15 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:19:15 --> Model Class Initialized
INFO - 2016-06-08 12:19:15 --> Helper loaded: date_helper
INFO - 2016-06-08 12:19:15 --> Controller Class Initialized
INFO - 2016-06-08 12:19:15 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:19:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:19:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:19:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:19:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:19:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:19:15 --> Model Class Initialized
INFO - 2016-06-08 12:19:15 --> Form Validation Class Initialized
INFO - 2016-06-08 12:20:00 --> Config Class Initialized
INFO - 2016-06-08 12:20:00 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:20:00 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:20:00 --> Utf8 Class Initialized
INFO - 2016-06-08 12:20:00 --> URI Class Initialized
INFO - 2016-06-08 12:20:00 --> Router Class Initialized
INFO - 2016-06-08 12:20:00 --> Output Class Initialized
INFO - 2016-06-08 12:20:00 --> Security Class Initialized
DEBUG - 2016-06-08 12:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:20:00 --> Input Class Initialized
INFO - 2016-06-08 12:20:00 --> Language Class Initialized
INFO - 2016-06-08 12:20:00 --> Loader Class Initialized
INFO - 2016-06-08 12:20:00 --> Helper loaded: form_helper
INFO - 2016-06-08 12:20:00 --> Database Driver Class Initialized
INFO - 2016-06-08 12:20:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:20:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:20:00 --> Email Class Initialized
INFO - 2016-06-08 12:20:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:20:00 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:20:00 --> Helper loaded: language_helper
INFO - 2016-06-08 12:20:00 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:20:00 --> Model Class Initialized
INFO - 2016-06-08 12:20:00 --> Helper loaded: date_helper
INFO - 2016-06-08 12:20:00 --> Controller Class Initialized
INFO - 2016-06-08 12:20:00 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:20:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:20:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:20:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:20:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:20:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:20:00 --> Model Class Initialized
INFO - 2016-06-08 12:20:00 --> Form Validation Class Initialized
INFO - 2016-06-08 12:20:55 --> Config Class Initialized
INFO - 2016-06-08 12:20:55 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:20:55 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:20:55 --> Utf8 Class Initialized
INFO - 2016-06-08 12:20:55 --> URI Class Initialized
INFO - 2016-06-08 12:20:55 --> Router Class Initialized
INFO - 2016-06-08 12:20:55 --> Output Class Initialized
INFO - 2016-06-08 12:20:55 --> Security Class Initialized
DEBUG - 2016-06-08 12:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:20:55 --> Input Class Initialized
INFO - 2016-06-08 12:20:55 --> Language Class Initialized
INFO - 2016-06-08 12:20:55 --> Loader Class Initialized
INFO - 2016-06-08 12:20:55 --> Helper loaded: form_helper
INFO - 2016-06-08 12:20:55 --> Database Driver Class Initialized
INFO - 2016-06-08 12:20:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:20:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:20:55 --> Email Class Initialized
INFO - 2016-06-08 12:20:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:20:55 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:20:55 --> Helper loaded: language_helper
INFO - 2016-06-08 12:20:55 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:20:55 --> Model Class Initialized
INFO - 2016-06-08 12:20:55 --> Helper loaded: date_helper
INFO - 2016-06-08 12:20:55 --> Controller Class Initialized
INFO - 2016-06-08 12:20:55 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:20:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:20:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:20:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:20:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:20:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:20:55 --> Model Class Initialized
INFO - 2016-06-08 12:20:55 --> Form Validation Class Initialized
INFO - 2016-06-08 12:22:45 --> Config Class Initialized
INFO - 2016-06-08 12:22:45 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:22:45 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:22:45 --> Utf8 Class Initialized
INFO - 2016-06-08 12:22:45 --> URI Class Initialized
INFO - 2016-06-08 12:22:45 --> Router Class Initialized
INFO - 2016-06-08 12:22:45 --> Output Class Initialized
INFO - 2016-06-08 12:22:45 --> Security Class Initialized
DEBUG - 2016-06-08 12:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:22:45 --> Input Class Initialized
INFO - 2016-06-08 12:22:45 --> Language Class Initialized
INFO - 2016-06-08 12:22:45 --> Loader Class Initialized
INFO - 2016-06-08 12:22:45 --> Helper loaded: form_helper
INFO - 2016-06-08 12:22:45 --> Database Driver Class Initialized
INFO - 2016-06-08 12:22:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:22:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:22:45 --> Email Class Initialized
INFO - 2016-06-08 12:22:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:22:45 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:22:45 --> Helper loaded: language_helper
INFO - 2016-06-08 12:22:45 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:22:45 --> Model Class Initialized
INFO - 2016-06-08 12:22:45 --> Helper loaded: date_helper
INFO - 2016-06-08 12:22:45 --> Controller Class Initialized
INFO - 2016-06-08 12:22:45 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:22:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:22:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:22:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:22:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:22:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:22:45 --> Model Class Initialized
INFO - 2016-06-08 12:22:45 --> Form Validation Class Initialized
INFO - 2016-06-08 12:30:59 --> Config Class Initialized
INFO - 2016-06-08 12:30:59 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:30:59 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:30:59 --> Utf8 Class Initialized
INFO - 2016-06-08 12:30:59 --> URI Class Initialized
INFO - 2016-06-08 12:30:59 --> Router Class Initialized
INFO - 2016-06-08 12:30:59 --> Output Class Initialized
INFO - 2016-06-08 12:30:59 --> Security Class Initialized
DEBUG - 2016-06-08 12:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:30:59 --> Input Class Initialized
INFO - 2016-06-08 12:30:59 --> Language Class Initialized
INFO - 2016-06-08 12:30:59 --> Loader Class Initialized
INFO - 2016-06-08 12:30:59 --> Helper loaded: form_helper
INFO - 2016-06-08 12:30:59 --> Database Driver Class Initialized
INFO - 2016-06-08 12:31:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:31:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:31:00 --> Email Class Initialized
INFO - 2016-06-08 12:31:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:31:00 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:31:00 --> Helper loaded: language_helper
INFO - 2016-06-08 12:31:00 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:31:00 --> Model Class Initialized
INFO - 2016-06-08 12:31:00 --> Helper loaded: date_helper
INFO - 2016-06-08 12:31:00 --> Controller Class Initialized
INFO - 2016-06-08 12:31:00 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:31:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:31:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:31:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:31:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:31:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:31:00 --> Model Class Initialized
INFO - 2016-06-08 12:31:00 --> Form Validation Class Initialized
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 12:31:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:31:00 --> Final output sent to browser
DEBUG - 2016-06-08 12:31:00 --> Total execution time: 0.0871
INFO - 2016-06-08 12:31:55 --> Config Class Initialized
INFO - 2016-06-08 12:31:55 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:31:55 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:31:55 --> Utf8 Class Initialized
INFO - 2016-06-08 12:31:55 --> URI Class Initialized
INFO - 2016-06-08 12:31:55 --> Router Class Initialized
INFO - 2016-06-08 12:31:55 --> Output Class Initialized
INFO - 2016-06-08 12:31:55 --> Security Class Initialized
DEBUG - 2016-06-08 12:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:31:55 --> Input Class Initialized
INFO - 2016-06-08 12:31:55 --> Language Class Initialized
INFO - 2016-06-08 12:31:55 --> Loader Class Initialized
INFO - 2016-06-08 12:31:55 --> Helper loaded: form_helper
INFO - 2016-06-08 12:31:55 --> Database Driver Class Initialized
INFO - 2016-06-08 12:31:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:31:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:31:55 --> Email Class Initialized
INFO - 2016-06-08 12:31:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:31:55 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:31:55 --> Helper loaded: language_helper
INFO - 2016-06-08 12:31:55 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:31:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:31:55 --> Model Class Initialized
INFO - 2016-06-08 12:31:55 --> Helper loaded: date_helper
INFO - 2016-06-08 12:31:55 --> Controller Class Initialized
INFO - 2016-06-08 12:31:55 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:31:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:31:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:31:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:31:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:31:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:31:55 --> Model Class Initialized
INFO - 2016-06-08 12:31:56 --> Form Validation Class Initialized
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:31:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:31:56 --> Final output sent to browser
DEBUG - 2016-06-08 12:31:56 --> Total execution time: 0.1048
INFO - 2016-06-08 12:32:32 --> Config Class Initialized
INFO - 2016-06-08 12:32:32 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:32:32 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:32:32 --> Utf8 Class Initialized
INFO - 2016-06-08 12:32:32 --> URI Class Initialized
INFO - 2016-06-08 12:32:32 --> Router Class Initialized
INFO - 2016-06-08 12:32:32 --> Output Class Initialized
INFO - 2016-06-08 12:32:32 --> Security Class Initialized
DEBUG - 2016-06-08 12:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:32:32 --> Input Class Initialized
INFO - 2016-06-08 12:32:32 --> Language Class Initialized
INFO - 2016-06-08 12:32:32 --> Loader Class Initialized
INFO - 2016-06-08 12:32:32 --> Helper loaded: form_helper
INFO - 2016-06-08 12:32:32 --> Database Driver Class Initialized
INFO - 2016-06-08 12:32:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:32:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:32:32 --> Email Class Initialized
INFO - 2016-06-08 12:32:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:32:32 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:32:32 --> Helper loaded: language_helper
INFO - 2016-06-08 12:32:32 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:32:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:32:32 --> Model Class Initialized
INFO - 2016-06-08 12:32:32 --> Helper loaded: date_helper
INFO - 2016-06-08 12:32:32 --> Controller Class Initialized
INFO - 2016-06-08 12:32:32 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:32:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:32:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:32:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:32:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:32:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:32:32 --> Model Class Initialized
INFO - 2016-06-08 12:32:32 --> Form Validation Class Initialized
INFO - 2016-06-08 12:32:36 --> Config Class Initialized
INFO - 2016-06-08 12:32:36 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:32:36 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:32:36 --> Utf8 Class Initialized
INFO - 2016-06-08 12:32:36 --> URI Class Initialized
INFO - 2016-06-08 12:32:36 --> Router Class Initialized
INFO - 2016-06-08 12:32:36 --> Output Class Initialized
INFO - 2016-06-08 12:32:36 --> Security Class Initialized
DEBUG - 2016-06-08 12:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:32:36 --> Input Class Initialized
INFO - 2016-06-08 12:32:36 --> Language Class Initialized
INFO - 2016-06-08 12:32:36 --> Loader Class Initialized
INFO - 2016-06-08 12:32:36 --> Helper loaded: form_helper
INFO - 2016-06-08 12:32:36 --> Database Driver Class Initialized
INFO - 2016-06-08 12:32:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:32:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:32:36 --> Email Class Initialized
INFO - 2016-06-08 12:32:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:32:36 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:32:36 --> Helper loaded: language_helper
INFO - 2016-06-08 12:32:36 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:32:36 --> Model Class Initialized
INFO - 2016-06-08 12:32:36 --> Helper loaded: date_helper
INFO - 2016-06-08 12:32:36 --> Controller Class Initialized
INFO - 2016-06-08 12:32:36 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:32:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:32:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:32:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:32:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:32:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:32:36 --> Model Class Initialized
INFO - 2016-06-08 12:32:36 --> Form Validation Class Initialized
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:32:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:32:36 --> Final output sent to browser
DEBUG - 2016-06-08 12:32:36 --> Total execution time: 0.0756
INFO - 2016-06-08 12:32:52 --> Config Class Initialized
INFO - 2016-06-08 12:32:52 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:32:52 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:32:52 --> Utf8 Class Initialized
INFO - 2016-06-08 12:32:52 --> URI Class Initialized
INFO - 2016-06-08 12:32:52 --> Router Class Initialized
INFO - 2016-06-08 12:32:52 --> Output Class Initialized
INFO - 2016-06-08 12:32:52 --> Security Class Initialized
DEBUG - 2016-06-08 12:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:32:52 --> Input Class Initialized
INFO - 2016-06-08 12:32:52 --> Language Class Initialized
INFO - 2016-06-08 12:32:52 --> Loader Class Initialized
INFO - 2016-06-08 12:32:52 --> Helper loaded: form_helper
INFO - 2016-06-08 12:32:52 --> Database Driver Class Initialized
INFO - 2016-06-08 12:32:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:32:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:32:52 --> Email Class Initialized
INFO - 2016-06-08 12:32:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:32:52 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:32:52 --> Helper loaded: language_helper
INFO - 2016-06-08 12:32:52 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:32:52 --> Model Class Initialized
INFO - 2016-06-08 12:32:52 --> Helper loaded: date_helper
INFO - 2016-06-08 12:32:52 --> Controller Class Initialized
INFO - 2016-06-08 12:32:52 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:32:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:32:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:32:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:32:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:32:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:32:52 --> Model Class Initialized
INFO - 2016-06-08 12:32:52 --> Form Validation Class Initialized
INFO - 2016-06-08 12:33:57 --> Config Class Initialized
INFO - 2016-06-08 12:33:57 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:33:57 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:33:57 --> Utf8 Class Initialized
INFO - 2016-06-08 12:33:57 --> URI Class Initialized
INFO - 2016-06-08 12:33:57 --> Router Class Initialized
INFO - 2016-06-08 12:33:57 --> Output Class Initialized
INFO - 2016-06-08 12:33:57 --> Security Class Initialized
DEBUG - 2016-06-08 12:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:33:57 --> Input Class Initialized
INFO - 2016-06-08 12:33:57 --> Language Class Initialized
INFO - 2016-06-08 12:33:57 --> Loader Class Initialized
INFO - 2016-06-08 12:33:57 --> Helper loaded: form_helper
INFO - 2016-06-08 12:33:57 --> Database Driver Class Initialized
INFO - 2016-06-08 12:33:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:33:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:33:57 --> Email Class Initialized
INFO - 2016-06-08 12:33:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:33:57 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:33:57 --> Helper loaded: language_helper
INFO - 2016-06-08 12:33:57 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:33:57 --> Model Class Initialized
INFO - 2016-06-08 12:33:57 --> Helper loaded: date_helper
INFO - 2016-06-08 12:33:57 --> Controller Class Initialized
INFO - 2016-06-08 12:33:57 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:33:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:33:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:33:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:33:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:33:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:33:57 --> Model Class Initialized
INFO - 2016-06-08 12:33:57 --> Form Validation Class Initialized
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:33:57 --> Final output sent to browser
DEBUG - 2016-06-08 12:33:57 --> Total execution time: 0.0733
INFO - 2016-06-08 12:35:09 --> Config Class Initialized
INFO - 2016-06-08 12:35:09 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:35:09 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:35:09 --> Utf8 Class Initialized
INFO - 2016-06-08 12:35:09 --> URI Class Initialized
INFO - 2016-06-08 12:35:09 --> Router Class Initialized
INFO - 2016-06-08 12:35:09 --> Output Class Initialized
INFO - 2016-06-08 12:35:09 --> Security Class Initialized
DEBUG - 2016-06-08 12:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:35:09 --> Input Class Initialized
INFO - 2016-06-08 12:35:09 --> Language Class Initialized
INFO - 2016-06-08 12:35:09 --> Loader Class Initialized
INFO - 2016-06-08 12:35:09 --> Helper loaded: form_helper
INFO - 2016-06-08 12:35:09 --> Database Driver Class Initialized
INFO - 2016-06-08 12:35:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:35:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:35:09 --> Email Class Initialized
INFO - 2016-06-08 12:35:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:35:09 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:35:09 --> Helper loaded: language_helper
INFO - 2016-06-08 12:35:09 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:35:09 --> Model Class Initialized
INFO - 2016-06-08 12:35:09 --> Helper loaded: date_helper
INFO - 2016-06-08 12:35:09 --> Controller Class Initialized
INFO - 2016-06-08 12:35:09 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:35:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:35:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:35:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:35:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:35:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:35:09 --> Model Class Initialized
INFO - 2016-06-08 12:35:09 --> Form Validation Class Initialized
INFO - 2016-06-08 12:35:59 --> Config Class Initialized
INFO - 2016-06-08 12:35:59 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:35:59 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:35:59 --> Utf8 Class Initialized
INFO - 2016-06-08 12:35:59 --> URI Class Initialized
INFO - 2016-06-08 12:35:59 --> Router Class Initialized
INFO - 2016-06-08 12:35:59 --> Output Class Initialized
INFO - 2016-06-08 12:35:59 --> Security Class Initialized
DEBUG - 2016-06-08 12:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:35:59 --> Input Class Initialized
INFO - 2016-06-08 12:35:59 --> Language Class Initialized
INFO - 2016-06-08 12:35:59 --> Loader Class Initialized
INFO - 2016-06-08 12:35:59 --> Helper loaded: form_helper
INFO - 2016-06-08 12:35:59 --> Database Driver Class Initialized
INFO - 2016-06-08 12:35:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:35:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:35:59 --> Email Class Initialized
INFO - 2016-06-08 12:35:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:35:59 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:35:59 --> Helper loaded: language_helper
INFO - 2016-06-08 12:35:59 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:35:59 --> Model Class Initialized
INFO - 2016-06-08 12:35:59 --> Helper loaded: date_helper
INFO - 2016-06-08 12:35:59 --> Controller Class Initialized
INFO - 2016-06-08 12:35:59 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:35:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:35:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:35:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:35:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:35:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:35:59 --> Model Class Initialized
INFO - 2016-06-08 12:35:59 --> Form Validation Class Initialized
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 12:35:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:35:59 --> Final output sent to browser
DEBUG - 2016-06-08 12:35:59 --> Total execution time: 0.1413
INFO - 2016-06-08 12:39:57 --> Config Class Initialized
INFO - 2016-06-08 12:39:57 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:39:57 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:39:57 --> Utf8 Class Initialized
INFO - 2016-06-08 12:39:57 --> URI Class Initialized
INFO - 2016-06-08 12:39:57 --> Router Class Initialized
INFO - 2016-06-08 12:39:57 --> Output Class Initialized
INFO - 2016-06-08 12:39:57 --> Security Class Initialized
DEBUG - 2016-06-08 12:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:39:57 --> Input Class Initialized
INFO - 2016-06-08 12:39:57 --> Language Class Initialized
INFO - 2016-06-08 12:39:57 --> Loader Class Initialized
INFO - 2016-06-08 12:39:57 --> Helper loaded: form_helper
INFO - 2016-06-08 12:39:57 --> Database Driver Class Initialized
INFO - 2016-06-08 12:39:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:39:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:39:57 --> Email Class Initialized
INFO - 2016-06-08 12:39:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:39:57 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:39:57 --> Helper loaded: language_helper
INFO - 2016-06-08 12:39:57 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:39:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:39:57 --> Model Class Initialized
INFO - 2016-06-08 12:39:57 --> Helper loaded: date_helper
INFO - 2016-06-08 12:39:57 --> Controller Class Initialized
INFO - 2016-06-08 12:39:57 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:39:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:39:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:39:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:39:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:39:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:39:57 --> Model Class Initialized
INFO - 2016-06-08 12:39:57 --> Form Validation Class Initialized
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:39:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:39:57 --> Final output sent to browser
DEBUG - 2016-06-08 12:39:57 --> Total execution time: 0.0282
INFO - 2016-06-08 12:40:12 --> Config Class Initialized
INFO - 2016-06-08 12:40:12 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:40:12 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:40:12 --> Utf8 Class Initialized
INFO - 2016-06-08 12:40:12 --> URI Class Initialized
INFO - 2016-06-08 12:40:12 --> Router Class Initialized
INFO - 2016-06-08 12:40:12 --> Output Class Initialized
INFO - 2016-06-08 12:40:12 --> Security Class Initialized
DEBUG - 2016-06-08 12:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:40:12 --> Input Class Initialized
INFO - 2016-06-08 12:40:12 --> Language Class Initialized
INFO - 2016-06-08 12:40:12 --> Loader Class Initialized
INFO - 2016-06-08 12:40:12 --> Helper loaded: form_helper
INFO - 2016-06-08 12:40:12 --> Database Driver Class Initialized
INFO - 2016-06-08 12:40:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:40:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:40:12 --> Email Class Initialized
INFO - 2016-06-08 12:40:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:40:12 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:40:12 --> Helper loaded: language_helper
INFO - 2016-06-08 12:40:12 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:40:12 --> Model Class Initialized
INFO - 2016-06-08 12:40:12 --> Helper loaded: date_helper
INFO - 2016-06-08 12:40:12 --> Controller Class Initialized
INFO - 2016-06-08 12:40:12 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:40:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:40:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:40:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:40:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:40:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:40:12 --> Model Class Initialized
INFO - 2016-06-08 12:40:12 --> Form Validation Class Initialized
INFO - 2016-06-08 12:40:12 --> Final output sent to browser
DEBUG - 2016-06-08 12:40:12 --> Total execution time: 0.1415
INFO - 2016-06-08 12:40:33 --> Config Class Initialized
INFO - 2016-06-08 12:40:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:40:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:40:33 --> Utf8 Class Initialized
INFO - 2016-06-08 12:40:33 --> URI Class Initialized
INFO - 2016-06-08 12:40:33 --> Router Class Initialized
INFO - 2016-06-08 12:40:33 --> Output Class Initialized
INFO - 2016-06-08 12:40:33 --> Security Class Initialized
DEBUG - 2016-06-08 12:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:40:33 --> Input Class Initialized
INFO - 2016-06-08 12:40:33 --> Language Class Initialized
INFO - 2016-06-08 12:40:33 --> Loader Class Initialized
INFO - 2016-06-08 12:40:33 --> Helper loaded: form_helper
INFO - 2016-06-08 12:40:33 --> Database Driver Class Initialized
INFO - 2016-06-08 12:40:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:40:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:40:33 --> Email Class Initialized
INFO - 2016-06-08 12:40:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:40:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:40:33 --> Helper loaded: language_helper
INFO - 2016-06-08 12:40:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:40:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:40:33 --> Model Class Initialized
INFO - 2016-06-08 12:40:33 --> Helper loaded: date_helper
INFO - 2016-06-08 12:40:33 --> Controller Class Initialized
INFO - 2016-06-08 12:40:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:40:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:40:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:40:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:40:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:40:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:40:33 --> Model Class Initialized
INFO - 2016-06-08 12:40:33 --> Form Validation Class Initialized
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:40:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:40:33 --> Final output sent to browser
DEBUG - 2016-06-08 12:40:33 --> Total execution time: 0.0309
INFO - 2016-06-08 12:41:07 --> Config Class Initialized
INFO - 2016-06-08 12:41:07 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:41:07 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:41:07 --> Utf8 Class Initialized
INFO - 2016-06-08 12:41:07 --> URI Class Initialized
INFO - 2016-06-08 12:41:07 --> Router Class Initialized
INFO - 2016-06-08 12:41:07 --> Output Class Initialized
INFO - 2016-06-08 12:41:07 --> Security Class Initialized
DEBUG - 2016-06-08 12:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:41:07 --> Input Class Initialized
INFO - 2016-06-08 12:41:07 --> Language Class Initialized
INFO - 2016-06-08 12:41:07 --> Loader Class Initialized
INFO - 2016-06-08 12:41:07 --> Helper loaded: form_helper
INFO - 2016-06-08 12:41:07 --> Database Driver Class Initialized
INFO - 2016-06-08 12:41:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:41:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:41:07 --> Email Class Initialized
INFO - 2016-06-08 12:41:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:41:07 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:41:07 --> Helper loaded: language_helper
INFO - 2016-06-08 12:41:07 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:41:07 --> Model Class Initialized
INFO - 2016-06-08 12:41:07 --> Helper loaded: date_helper
INFO - 2016-06-08 12:41:07 --> Controller Class Initialized
INFO - 2016-06-08 12:41:07 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:41:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:41:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:41:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:41:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:41:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:41:07 --> Model Class Initialized
INFO - 2016-06-08 12:41:07 --> Form Validation Class Initialized
INFO - 2016-06-08 12:41:07 --> Final output sent to browser
DEBUG - 2016-06-08 12:41:07 --> Total execution time: 0.1266
INFO - 2016-06-08 12:42:56 --> Config Class Initialized
INFO - 2016-06-08 12:42:56 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:42:56 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:42:56 --> Utf8 Class Initialized
INFO - 2016-06-08 12:42:56 --> URI Class Initialized
INFO - 2016-06-08 12:42:56 --> Router Class Initialized
INFO - 2016-06-08 12:42:56 --> Output Class Initialized
INFO - 2016-06-08 12:42:56 --> Security Class Initialized
DEBUG - 2016-06-08 12:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:42:56 --> Input Class Initialized
INFO - 2016-06-08 12:42:56 --> Language Class Initialized
INFO - 2016-06-08 12:42:56 --> Loader Class Initialized
INFO - 2016-06-08 12:42:56 --> Helper loaded: form_helper
INFO - 2016-06-08 12:42:56 --> Database Driver Class Initialized
INFO - 2016-06-08 12:42:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:42:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:42:56 --> Email Class Initialized
INFO - 2016-06-08 12:42:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:42:56 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:42:56 --> Helper loaded: language_helper
INFO - 2016-06-08 12:42:56 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:42:56 --> Model Class Initialized
INFO - 2016-06-08 12:42:56 --> Helper loaded: date_helper
INFO - 2016-06-08 12:42:56 --> Controller Class Initialized
INFO - 2016-06-08 12:42:56 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:42:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:42:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:42:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:42:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:42:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:42:56 --> Model Class Initialized
INFO - 2016-06-08 12:42:56 --> Form Validation Class Initialized
INFO - 2016-06-08 12:42:56 --> Final output sent to browser
DEBUG - 2016-06-08 12:42:56 --> Total execution time: 0.1087
INFO - 2016-06-08 12:44:33 --> Config Class Initialized
INFO - 2016-06-08 12:44:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:44:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:44:33 --> Utf8 Class Initialized
INFO - 2016-06-08 12:44:33 --> URI Class Initialized
INFO - 2016-06-08 12:44:33 --> Router Class Initialized
INFO - 2016-06-08 12:44:33 --> Output Class Initialized
INFO - 2016-06-08 12:44:33 --> Security Class Initialized
DEBUG - 2016-06-08 12:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:44:33 --> Input Class Initialized
INFO - 2016-06-08 12:44:33 --> Language Class Initialized
INFO - 2016-06-08 12:44:33 --> Loader Class Initialized
INFO - 2016-06-08 12:44:33 --> Helper loaded: form_helper
INFO - 2016-06-08 12:44:33 --> Database Driver Class Initialized
INFO - 2016-06-08 12:44:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:44:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:44:33 --> Email Class Initialized
INFO - 2016-06-08 12:44:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:44:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:44:33 --> Helper loaded: language_helper
INFO - 2016-06-08 12:44:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:44:33 --> Model Class Initialized
INFO - 2016-06-08 12:44:33 --> Helper loaded: date_helper
INFO - 2016-06-08 12:44:33 --> Controller Class Initialized
INFO - 2016-06-08 12:44:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:44:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:44:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:44:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:44:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:44:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:44:33 --> Model Class Initialized
INFO - 2016-06-08 12:44:33 --> Form Validation Class Initialized
INFO - 2016-06-08 12:44:33 --> Final output sent to browser
DEBUG - 2016-06-08 12:44:33 --> Total execution time: 0.1973
INFO - 2016-06-08 12:46:24 --> Config Class Initialized
INFO - 2016-06-08 12:46:24 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:46:24 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:46:24 --> Utf8 Class Initialized
INFO - 2016-06-08 12:46:24 --> URI Class Initialized
INFO - 2016-06-08 12:46:24 --> Router Class Initialized
INFO - 2016-06-08 12:46:24 --> Output Class Initialized
INFO - 2016-06-08 12:46:24 --> Security Class Initialized
DEBUG - 2016-06-08 12:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:46:24 --> Input Class Initialized
INFO - 2016-06-08 12:46:24 --> Language Class Initialized
INFO - 2016-06-08 12:46:24 --> Loader Class Initialized
INFO - 2016-06-08 12:46:24 --> Helper loaded: form_helper
INFO - 2016-06-08 12:46:24 --> Database Driver Class Initialized
INFO - 2016-06-08 12:46:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:46:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:46:24 --> Email Class Initialized
INFO - 2016-06-08 12:46:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:46:24 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:46:24 --> Helper loaded: language_helper
INFO - 2016-06-08 12:46:24 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:46:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:46:24 --> Model Class Initialized
INFO - 2016-06-08 12:46:24 --> Helper loaded: date_helper
INFO - 2016-06-08 12:46:24 --> Controller Class Initialized
INFO - 2016-06-08 12:46:24 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:46:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:46:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:46:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:46:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:46:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:46:24 --> Model Class Initialized
INFO - 2016-06-08 12:46:24 --> Form Validation Class Initialized
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:46:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:46:24 --> Final output sent to browser
DEBUG - 2016-06-08 12:46:24 --> Total execution time: 0.0628
INFO - 2016-06-08 12:46:38 --> Config Class Initialized
INFO - 2016-06-08 12:46:38 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:46:38 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:46:38 --> Utf8 Class Initialized
INFO - 2016-06-08 12:46:38 --> URI Class Initialized
INFO - 2016-06-08 12:46:38 --> Router Class Initialized
INFO - 2016-06-08 12:46:38 --> Output Class Initialized
INFO - 2016-06-08 12:46:38 --> Security Class Initialized
DEBUG - 2016-06-08 12:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:46:38 --> Input Class Initialized
INFO - 2016-06-08 12:46:38 --> Language Class Initialized
INFO - 2016-06-08 12:46:38 --> Loader Class Initialized
INFO - 2016-06-08 12:46:38 --> Helper loaded: form_helper
INFO - 2016-06-08 12:46:38 --> Database Driver Class Initialized
INFO - 2016-06-08 12:46:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:46:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:46:38 --> Email Class Initialized
INFO - 2016-06-08 12:46:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:46:38 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:46:38 --> Helper loaded: language_helper
INFO - 2016-06-08 12:46:38 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:46:38 --> Model Class Initialized
INFO - 2016-06-08 12:46:38 --> Helper loaded: date_helper
INFO - 2016-06-08 12:46:38 --> Controller Class Initialized
INFO - 2016-06-08 12:46:38 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:46:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:46:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:46:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:46:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:46:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:46:38 --> Model Class Initialized
INFO - 2016-06-08 12:46:38 --> Form Validation Class Initialized
INFO - 2016-06-08 12:46:38 --> Final output sent to browser
DEBUG - 2016-06-08 12:46:38 --> Total execution time: 0.1844
INFO - 2016-06-08 12:47:06 --> Config Class Initialized
INFO - 2016-06-08 12:47:06 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:47:06 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:47:06 --> Utf8 Class Initialized
INFO - 2016-06-08 12:47:06 --> URI Class Initialized
INFO - 2016-06-08 12:47:06 --> Router Class Initialized
INFO - 2016-06-08 12:47:06 --> Output Class Initialized
INFO - 2016-06-08 12:47:06 --> Security Class Initialized
DEBUG - 2016-06-08 12:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:47:06 --> Input Class Initialized
INFO - 2016-06-08 12:47:06 --> Language Class Initialized
INFO - 2016-06-08 12:47:06 --> Loader Class Initialized
INFO - 2016-06-08 12:47:06 --> Helper loaded: form_helper
INFO - 2016-06-08 12:47:06 --> Database Driver Class Initialized
INFO - 2016-06-08 12:47:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:47:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:47:06 --> Email Class Initialized
INFO - 2016-06-08 12:47:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:47:06 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:47:06 --> Helper loaded: language_helper
INFO - 2016-06-08 12:47:06 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:47:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:47:06 --> Model Class Initialized
INFO - 2016-06-08 12:47:06 --> Helper loaded: date_helper
INFO - 2016-06-08 12:47:06 --> Controller Class Initialized
INFO - 2016-06-08 12:47:06 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:47:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:47:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:47:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:47:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:47:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:47:06 --> Model Class Initialized
INFO - 2016-06-08 12:47:06 --> Form Validation Class Initialized
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:47:06 --> Final output sent to browser
DEBUG - 2016-06-08 12:47:06 --> Total execution time: 0.0358
INFO - 2016-06-08 12:47:16 --> Config Class Initialized
INFO - 2016-06-08 12:47:16 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:47:16 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:47:16 --> Utf8 Class Initialized
INFO - 2016-06-08 12:47:16 --> URI Class Initialized
INFO - 2016-06-08 12:47:16 --> Router Class Initialized
INFO - 2016-06-08 12:47:16 --> Output Class Initialized
INFO - 2016-06-08 12:47:16 --> Security Class Initialized
DEBUG - 2016-06-08 12:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:47:16 --> Input Class Initialized
INFO - 2016-06-08 12:47:16 --> Language Class Initialized
INFO - 2016-06-08 12:47:16 --> Loader Class Initialized
INFO - 2016-06-08 12:47:16 --> Helper loaded: form_helper
INFO - 2016-06-08 12:47:16 --> Database Driver Class Initialized
INFO - 2016-06-08 12:47:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:47:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:47:16 --> Email Class Initialized
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:47:16 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:47:16 --> Helper loaded: language_helper
INFO - 2016-06-08 12:47:16 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:47:16 --> Model Class Initialized
INFO - 2016-06-08 12:47:16 --> Helper loaded: date_helper
INFO - 2016-06-08 12:47:16 --> Controller Class Initialized
INFO - 2016-06-08 12:47:16 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:47:16 --> Model Class Initialized
INFO - 2016-06-08 12:47:16 --> Form Validation Class Initialized
INFO - 2016-06-08 12:47:16 --> Final output sent to browser
DEBUG - 2016-06-08 12:47:16 --> Total execution time: 0.1204
INFO - 2016-06-08 12:47:16 --> Config Class Initialized
INFO - 2016-06-08 12:47:16 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:47:16 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:47:16 --> Utf8 Class Initialized
INFO - 2016-06-08 12:47:16 --> URI Class Initialized
DEBUG - 2016-06-08 12:47:16 --> No URI present. Default controller set.
INFO - 2016-06-08 12:47:16 --> Router Class Initialized
INFO - 2016-06-08 12:47:16 --> Output Class Initialized
INFO - 2016-06-08 12:47:16 --> Security Class Initialized
DEBUG - 2016-06-08 12:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:47:16 --> Input Class Initialized
INFO - 2016-06-08 12:47:16 --> Language Class Initialized
INFO - 2016-06-08 12:47:16 --> Loader Class Initialized
INFO - 2016-06-08 12:47:16 --> Helper loaded: form_helper
INFO - 2016-06-08 12:47:16 --> Database Driver Class Initialized
INFO - 2016-06-08 12:47:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:47:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:47:16 --> Email Class Initialized
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:47:16 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:47:16 --> Helper loaded: language_helper
INFO - 2016-06-08 12:47:16 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:47:16 --> Model Class Initialized
INFO - 2016-06-08 12:47:16 --> Helper loaded: date_helper
INFO - 2016-06-08 12:47:16 --> Controller Class Initialized
INFO - 2016-06-08 12:47:16 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:47:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:47:17 --> Config Class Initialized
INFO - 2016-06-08 12:47:17 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:47:17 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:47:17 --> Utf8 Class Initialized
INFO - 2016-06-08 12:47:17 --> URI Class Initialized
INFO - 2016-06-08 12:47:17 --> Router Class Initialized
INFO - 2016-06-08 12:47:17 --> Output Class Initialized
INFO - 2016-06-08 12:47:17 --> Security Class Initialized
DEBUG - 2016-06-08 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:47:17 --> Input Class Initialized
INFO - 2016-06-08 12:47:17 --> Language Class Initialized
INFO - 2016-06-08 12:47:17 --> Loader Class Initialized
INFO - 2016-06-08 12:47:17 --> Helper loaded: form_helper
INFO - 2016-06-08 12:47:17 --> Database Driver Class Initialized
INFO - 2016-06-08 12:47:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:47:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:47:17 --> Email Class Initialized
INFO - 2016-06-08 12:47:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:47:17 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:47:17 --> Helper loaded: language_helper
INFO - 2016-06-08 12:47:17 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:47:17 --> Model Class Initialized
INFO - 2016-06-08 12:47:17 --> Helper loaded: date_helper
INFO - 2016-06-08 12:47:17 --> Controller Class Initialized
INFO - 2016-06-08 12:47:17 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:47:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:47:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:47:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:47:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:47:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:47:17 --> Model Class Initialized
INFO - 2016-06-08 12:47:17 --> Form Validation Class Initialized
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-08 12:47:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:47:17 --> Final output sent to browser
DEBUG - 2016-06-08 12:47:17 --> Total execution time: 0.0827
INFO - 2016-06-08 12:47:36 --> Config Class Initialized
INFO - 2016-06-08 12:47:36 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:47:36 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:47:36 --> Utf8 Class Initialized
INFO - 2016-06-08 12:47:36 --> URI Class Initialized
DEBUG - 2016-06-08 12:47:36 --> No URI present. Default controller set.
INFO - 2016-06-08 12:47:36 --> Router Class Initialized
INFO - 2016-06-08 12:47:36 --> Output Class Initialized
INFO - 2016-06-08 12:47:36 --> Security Class Initialized
DEBUG - 2016-06-08 12:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:47:36 --> Input Class Initialized
INFO - 2016-06-08 12:47:36 --> Language Class Initialized
INFO - 2016-06-08 12:47:36 --> Loader Class Initialized
INFO - 2016-06-08 12:47:36 --> Helper loaded: form_helper
INFO - 2016-06-08 12:47:36 --> Database Driver Class Initialized
INFO - 2016-06-08 12:47:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:47:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:47:36 --> Email Class Initialized
INFO - 2016-06-08 12:47:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:47:36 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:47:36 --> Helper loaded: language_helper
INFO - 2016-06-08 12:47:36 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:47:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:47:36 --> Model Class Initialized
INFO - 2016-06-08 12:47:36 --> Helper loaded: date_helper
INFO - 2016-06-08 12:47:36 --> Controller Class Initialized
INFO - 2016-06-08 12:47:36 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:47:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:47:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:47:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:47:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:47:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:47:37 --> Config Class Initialized
INFO - 2016-06-08 12:47:37 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:47:37 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:47:37 --> Utf8 Class Initialized
INFO - 2016-06-08 12:47:37 --> URI Class Initialized
INFO - 2016-06-08 12:47:37 --> Router Class Initialized
INFO - 2016-06-08 12:47:37 --> Output Class Initialized
INFO - 2016-06-08 12:47:37 --> Security Class Initialized
DEBUG - 2016-06-08 12:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:47:37 --> Input Class Initialized
INFO - 2016-06-08 12:47:37 --> Language Class Initialized
INFO - 2016-06-08 12:47:37 --> Loader Class Initialized
INFO - 2016-06-08 12:47:37 --> Helper loaded: form_helper
INFO - 2016-06-08 12:47:37 --> Database Driver Class Initialized
INFO - 2016-06-08 12:47:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:47:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:47:37 --> Email Class Initialized
INFO - 2016-06-08 12:47:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:47:37 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:47:37 --> Helper loaded: language_helper
INFO - 2016-06-08 12:47:37 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:47:37 --> Model Class Initialized
INFO - 2016-06-08 12:47:37 --> Helper loaded: date_helper
INFO - 2016-06-08 12:47:37 --> Controller Class Initialized
INFO - 2016-06-08 12:47:37 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:47:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:47:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:47:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:47:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:47:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:47:37 --> Model Class Initialized
INFO - 2016-06-08 12:47:37 --> Form Validation Class Initialized
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-08 12:47:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:47:37 --> Final output sent to browser
DEBUG - 2016-06-08 12:47:37 --> Total execution time: 0.0520
INFO - 2016-06-08 12:48:20 --> Config Class Initialized
INFO - 2016-06-08 12:48:20 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:48:20 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:48:20 --> Utf8 Class Initialized
INFO - 2016-06-08 12:48:20 --> URI Class Initialized
INFO - 2016-06-08 12:48:20 --> Router Class Initialized
INFO - 2016-06-08 12:48:20 --> Output Class Initialized
INFO - 2016-06-08 12:48:20 --> Security Class Initialized
DEBUG - 2016-06-08 12:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:48:20 --> Input Class Initialized
INFO - 2016-06-08 12:48:20 --> Language Class Initialized
INFO - 2016-06-08 12:48:20 --> Loader Class Initialized
INFO - 2016-06-08 12:48:20 --> Helper loaded: form_helper
INFO - 2016-06-08 12:48:20 --> Database Driver Class Initialized
INFO - 2016-06-08 12:48:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:48:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:48:20 --> Email Class Initialized
INFO - 2016-06-08 12:48:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:48:20 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:48:20 --> Helper loaded: language_helper
INFO - 2016-06-08 12:48:20 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:48:20 --> Model Class Initialized
INFO - 2016-06-08 12:48:20 --> Helper loaded: date_helper
INFO - 2016-06-08 12:48:20 --> Controller Class Initialized
INFO - 2016-06-08 12:48:20 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:48:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:48:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:48:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:48:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:48:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:48:20 --> Model Class Initialized
INFO - 2016-06-08 12:48:20 --> Form Validation Class Initialized
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-08 12:48:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:48:20 --> Final output sent to browser
DEBUG - 2016-06-08 12:48:20 --> Total execution time: 0.0760
INFO - 2016-06-08 12:48:23 --> Config Class Initialized
INFO - 2016-06-08 12:48:23 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:48:23 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:48:23 --> Utf8 Class Initialized
INFO - 2016-06-08 12:48:23 --> URI Class Initialized
INFO - 2016-06-08 12:48:23 --> Router Class Initialized
INFO - 2016-06-08 12:48:23 --> Output Class Initialized
INFO - 2016-06-08 12:48:23 --> Security Class Initialized
DEBUG - 2016-06-08 12:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:48:23 --> Input Class Initialized
INFO - 2016-06-08 12:48:23 --> Language Class Initialized
INFO - 2016-06-08 12:48:23 --> Loader Class Initialized
INFO - 2016-06-08 12:48:23 --> Helper loaded: form_helper
INFO - 2016-06-08 12:48:23 --> Database Driver Class Initialized
INFO - 2016-06-08 12:48:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:48:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:48:23 --> Email Class Initialized
INFO - 2016-06-08 12:48:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:48:23 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:48:23 --> Helper loaded: language_helper
INFO - 2016-06-08 12:48:23 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:48:23 --> Model Class Initialized
INFO - 2016-06-08 12:48:23 --> Helper loaded: date_helper
INFO - 2016-06-08 12:48:23 --> Controller Class Initialized
INFO - 2016-06-08 12:48:23 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:48:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:48:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:48:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:48:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:48:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:48:23 --> Model Class Initialized
INFO - 2016-06-08 12:48:23 --> Form Validation Class Initialized
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 12:48:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:48:23 --> Final output sent to browser
DEBUG - 2016-06-08 12:48:23 --> Total execution time: 0.0705
INFO - 2016-06-08 12:48:31 --> Config Class Initialized
INFO - 2016-06-08 12:48:31 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:48:31 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:48:31 --> Utf8 Class Initialized
INFO - 2016-06-08 12:48:31 --> URI Class Initialized
INFO - 2016-06-08 12:48:31 --> Router Class Initialized
INFO - 2016-06-08 12:48:31 --> Output Class Initialized
INFO - 2016-06-08 12:48:31 --> Security Class Initialized
DEBUG - 2016-06-08 12:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:48:31 --> Input Class Initialized
INFO - 2016-06-08 12:48:31 --> Language Class Initialized
INFO - 2016-06-08 12:48:31 --> Loader Class Initialized
INFO - 2016-06-08 12:48:31 --> Helper loaded: form_helper
INFO - 2016-06-08 12:48:31 --> Database Driver Class Initialized
INFO - 2016-06-08 12:48:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:48:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:48:31 --> Email Class Initialized
INFO - 2016-06-08 12:48:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:48:31 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:48:31 --> Helper loaded: language_helper
INFO - 2016-06-08 12:48:31 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:48:31 --> Model Class Initialized
INFO - 2016-06-08 12:48:31 --> Helper loaded: date_helper
INFO - 2016-06-08 12:48:31 --> Controller Class Initialized
INFO - 2016-06-08 12:48:31 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:48:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:48:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:48:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:48:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:48:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:48:31 --> Model Class Initialized
INFO - 2016-06-08 12:48:31 --> Form Validation Class Initialized
INFO - 2016-06-08 12:48:31 --> Final output sent to browser
DEBUG - 2016-06-08 12:48:31 --> Total execution time: 0.1693
INFO - 2016-06-08 12:48:31 --> Config Class Initialized
INFO - 2016-06-08 12:48:31 --> Hooks Class Initialized
DEBUG - 2016-06-08 12:48:31 --> UTF-8 Support Enabled
INFO - 2016-06-08 12:48:31 --> Utf8 Class Initialized
INFO - 2016-06-08 12:48:31 --> URI Class Initialized
INFO - 2016-06-08 12:48:31 --> Router Class Initialized
INFO - 2016-06-08 12:48:32 --> Output Class Initialized
INFO - 2016-06-08 12:48:32 --> Security Class Initialized
DEBUG - 2016-06-08 12:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 12:48:32 --> Input Class Initialized
INFO - 2016-06-08 12:48:32 --> Language Class Initialized
INFO - 2016-06-08 12:48:32 --> Loader Class Initialized
INFO - 2016-06-08 12:48:32 --> Helper loaded: form_helper
INFO - 2016-06-08 12:48:32 --> Database Driver Class Initialized
INFO - 2016-06-08 12:48:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 12:48:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 12:48:32 --> Email Class Initialized
INFO - 2016-06-08 12:48:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 12:48:32 --> Helper loaded: cookie_helper
INFO - 2016-06-08 12:48:32 --> Helper loaded: language_helper
INFO - 2016-06-08 12:48:32 --> Helper loaded: url_helper
DEBUG - 2016-06-08 12:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 12:48:32 --> Model Class Initialized
INFO - 2016-06-08 12:48:32 --> Helper loaded: date_helper
INFO - 2016-06-08 12:48:32 --> Controller Class Initialized
INFO - 2016-06-08 12:48:32 --> Helper loaded: languages_helper
INFO - 2016-06-08 12:48:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 12:48:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 12:48:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 12:48:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 12:48:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 12:48:32 --> Model Class Initialized
INFO - 2016-06-08 12:48:32 --> Form Validation Class Initialized
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 12:48:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 12:48:32 --> Final output sent to browser
DEBUG - 2016-06-08 12:48:32 --> Total execution time: 0.0742
INFO - 2016-06-08 13:05:31 --> Config Class Initialized
INFO - 2016-06-08 13:05:31 --> Hooks Class Initialized
DEBUG - 2016-06-08 13:05:31 --> UTF-8 Support Enabled
INFO - 2016-06-08 13:05:31 --> Utf8 Class Initialized
INFO - 2016-06-08 13:05:31 --> URI Class Initialized
INFO - 2016-06-08 13:05:31 --> Router Class Initialized
INFO - 2016-06-08 13:05:31 --> Output Class Initialized
INFO - 2016-06-08 13:05:31 --> Security Class Initialized
DEBUG - 2016-06-08 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 13:05:31 --> Input Class Initialized
INFO - 2016-06-08 13:05:31 --> Language Class Initialized
INFO - 2016-06-08 13:05:31 --> Loader Class Initialized
INFO - 2016-06-08 13:05:31 --> Helper loaded: form_helper
INFO - 2016-06-08 13:05:31 --> Database Driver Class Initialized
INFO - 2016-06-08 13:05:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 13:05:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 13:05:31 --> Email Class Initialized
INFO - 2016-06-08 13:05:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 13:05:31 --> Helper loaded: cookie_helper
INFO - 2016-06-08 13:05:31 --> Helper loaded: language_helper
INFO - 2016-06-08 13:05:31 --> Helper loaded: url_helper
DEBUG - 2016-06-08 13:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 13:05:31 --> Model Class Initialized
INFO - 2016-06-08 13:05:31 --> Helper loaded: date_helper
INFO - 2016-06-08 13:05:31 --> Controller Class Initialized
INFO - 2016-06-08 13:05:31 --> Helper loaded: languages_helper
INFO - 2016-06-08 13:05:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 13:05:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 13:05:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 13:05:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 13:05:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 13:05:31 --> Model Class Initialized
INFO - 2016-06-08 13:05:31 --> Form Validation Class Initialized
ERROR - 2016-06-08 13:05:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY 
                DATE(`_create_date`) ASC' at line 10 - Invalid query: 
            SELECT 
                `id`,
                `title`,
                `content`,
                `_create_date`             
            FROM 
                `posts` 
            WHERE 
                
            ORDER BY 
                DATE(`_create_date`) ASC    
        
INFO - 2016-06-08 13:07:21 --> Config Class Initialized
INFO - 2016-06-08 13:07:21 --> Hooks Class Initialized
DEBUG - 2016-06-08 13:07:21 --> UTF-8 Support Enabled
INFO - 2016-06-08 13:07:21 --> Utf8 Class Initialized
INFO - 2016-06-08 13:07:21 --> URI Class Initialized
INFO - 2016-06-08 13:07:21 --> Router Class Initialized
INFO - 2016-06-08 13:07:21 --> Output Class Initialized
INFO - 2016-06-08 13:07:21 --> Security Class Initialized
DEBUG - 2016-06-08 13:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 13:07:21 --> Input Class Initialized
INFO - 2016-06-08 13:07:21 --> Language Class Initialized
INFO - 2016-06-08 13:07:21 --> Loader Class Initialized
INFO - 2016-06-08 13:07:21 --> Helper loaded: form_helper
INFO - 2016-06-08 13:07:21 --> Database Driver Class Initialized
INFO - 2016-06-08 13:07:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 13:07:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 13:07:21 --> Email Class Initialized
INFO - 2016-06-08 13:07:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 13:07:21 --> Helper loaded: cookie_helper
INFO - 2016-06-08 13:07:21 --> Helper loaded: language_helper
INFO - 2016-06-08 13:07:21 --> Helper loaded: url_helper
DEBUG - 2016-06-08 13:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 13:07:21 --> Model Class Initialized
INFO - 2016-06-08 13:07:21 --> Helper loaded: date_helper
INFO - 2016-06-08 13:07:21 --> Controller Class Initialized
INFO - 2016-06-08 13:07:21 --> Helper loaded: languages_helper
INFO - 2016-06-08 13:07:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 13:07:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 13:07:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 13:07:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 13:07:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 13:07:21 --> Model Class Initialized
INFO - 2016-06-08 13:07:21 --> Form Validation Class Initialized
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 13:07:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 13:07:22 --> Final output sent to browser
DEBUG - 2016-06-08 13:07:22 --> Total execution time: 0.0501
INFO - 2016-06-08 14:09:17 --> Config Class Initialized
INFO - 2016-06-08 14:09:17 --> Hooks Class Initialized
DEBUG - 2016-06-08 14:09:17 --> UTF-8 Support Enabled
INFO - 2016-06-08 14:09:17 --> Utf8 Class Initialized
INFO - 2016-06-08 14:09:17 --> URI Class Initialized
INFO - 2016-06-08 14:09:17 --> Router Class Initialized
INFO - 2016-06-08 14:09:17 --> Output Class Initialized
INFO - 2016-06-08 14:09:17 --> Security Class Initialized
DEBUG - 2016-06-08 14:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 14:09:17 --> Input Class Initialized
INFO - 2016-06-08 14:09:17 --> Language Class Initialized
INFO - 2016-06-08 14:09:17 --> Loader Class Initialized
INFO - 2016-06-08 14:09:17 --> Helper loaded: form_helper
INFO - 2016-06-08 14:09:17 --> Database Driver Class Initialized
INFO - 2016-06-08 14:09:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 14:09:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 14:09:17 --> Email Class Initialized
INFO - 2016-06-08 14:09:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 14:09:17 --> Helper loaded: cookie_helper
INFO - 2016-06-08 14:09:17 --> Helper loaded: language_helper
INFO - 2016-06-08 14:09:17 --> Helper loaded: url_helper
DEBUG - 2016-06-08 14:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 14:09:17 --> Model Class Initialized
INFO - 2016-06-08 14:09:17 --> Helper loaded: date_helper
INFO - 2016-06-08 14:09:17 --> Controller Class Initialized
INFO - 2016-06-08 14:09:17 --> Helper loaded: languages_helper
INFO - 2016-06-08 14:09:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 14:09:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 14:09:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 14:09:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 14:09:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 14:09:17 --> Model Class Initialized
INFO - 2016-06-08 14:09:17 --> Form Validation Class Initialized
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 14:09:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 14:09:17 --> Final output sent to browser
DEBUG - 2016-06-08 14:09:17 --> Total execution time: 0.1292
INFO - 2016-06-08 14:19:52 --> Config Class Initialized
INFO - 2016-06-08 14:19:52 --> Hooks Class Initialized
DEBUG - 2016-06-08 14:19:52 --> UTF-8 Support Enabled
INFO - 2016-06-08 14:19:52 --> Utf8 Class Initialized
INFO - 2016-06-08 14:19:52 --> URI Class Initialized
INFO - 2016-06-08 14:19:52 --> Router Class Initialized
INFO - 2016-06-08 14:19:52 --> Output Class Initialized
INFO - 2016-06-08 14:19:52 --> Security Class Initialized
DEBUG - 2016-06-08 14:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 14:19:52 --> Input Class Initialized
INFO - 2016-06-08 14:19:52 --> Language Class Initialized
INFO - 2016-06-08 14:19:52 --> Loader Class Initialized
INFO - 2016-06-08 14:19:52 --> Helper loaded: form_helper
INFO - 2016-06-08 14:19:52 --> Database Driver Class Initialized
INFO - 2016-06-08 14:19:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 14:19:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 14:19:52 --> Email Class Initialized
INFO - 2016-06-08 14:19:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 14:19:52 --> Helper loaded: cookie_helper
INFO - 2016-06-08 14:19:52 --> Helper loaded: language_helper
INFO - 2016-06-08 14:19:52 --> Helper loaded: url_helper
DEBUG - 2016-06-08 14:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 14:19:52 --> Model Class Initialized
INFO - 2016-06-08 14:19:52 --> Helper loaded: date_helper
INFO - 2016-06-08 14:19:52 --> Controller Class Initialized
INFO - 2016-06-08 14:19:52 --> Helper loaded: languages_helper
INFO - 2016-06-08 14:19:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 14:19:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 14:19:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 14:19:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 14:19:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 14:19:52 --> Model Class Initialized
INFO - 2016-06-08 14:19:52 --> Form Validation Class Initialized
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 21
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:19:52 --> Severity: Notice --> Undefined variable: pacient /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 24
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 14:19:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 14:19:52 --> Final output sent to browser
DEBUG - 2016-06-08 14:19:52 --> Total execution time: 0.0733
INFO - 2016-06-08 14:22:54 --> Config Class Initialized
INFO - 2016-06-08 14:22:54 --> Hooks Class Initialized
DEBUG - 2016-06-08 14:22:54 --> UTF-8 Support Enabled
INFO - 2016-06-08 14:22:54 --> Utf8 Class Initialized
INFO - 2016-06-08 14:22:54 --> URI Class Initialized
INFO - 2016-06-08 14:22:54 --> Router Class Initialized
INFO - 2016-06-08 14:22:54 --> Output Class Initialized
INFO - 2016-06-08 14:22:54 --> Security Class Initialized
DEBUG - 2016-06-08 14:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 14:22:54 --> Input Class Initialized
INFO - 2016-06-08 14:22:54 --> Language Class Initialized
INFO - 2016-06-08 14:22:54 --> Loader Class Initialized
INFO - 2016-06-08 14:22:54 --> Helper loaded: form_helper
INFO - 2016-06-08 14:22:54 --> Database Driver Class Initialized
INFO - 2016-06-08 14:22:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 14:22:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 14:22:55 --> Email Class Initialized
INFO - 2016-06-08 14:22:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 14:22:55 --> Helper loaded: cookie_helper
INFO - 2016-06-08 14:22:55 --> Helper loaded: language_helper
INFO - 2016-06-08 14:22:55 --> Helper loaded: url_helper
DEBUG - 2016-06-08 14:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 14:22:55 --> Model Class Initialized
INFO - 2016-06-08 14:22:55 --> Helper loaded: date_helper
INFO - 2016-06-08 14:22:55 --> Controller Class Initialized
INFO - 2016-06-08 14:22:55 --> Helper loaded: languages_helper
INFO - 2016-06-08 14:22:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 14:22:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 14:22:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 14:22:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 14:22:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 14:22:55 --> Model Class Initialized
INFO - 2016-06-08 14:22:55 --> Form Validation Class Initialized
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:22:55 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 14:22:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 14:22:55 --> Final output sent to browser
DEBUG - 2016-06-08 14:22:55 --> Total execution time: 0.0734
INFO - 2016-06-08 14:53:18 --> Config Class Initialized
INFO - 2016-06-08 14:53:18 --> Hooks Class Initialized
DEBUG - 2016-06-08 14:53:18 --> UTF-8 Support Enabled
INFO - 2016-06-08 14:53:18 --> Utf8 Class Initialized
INFO - 2016-06-08 14:53:18 --> URI Class Initialized
INFO - 2016-06-08 14:53:18 --> Router Class Initialized
INFO - 2016-06-08 14:53:18 --> Output Class Initialized
INFO - 2016-06-08 14:53:18 --> Security Class Initialized
DEBUG - 2016-06-08 14:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 14:53:18 --> Input Class Initialized
INFO - 2016-06-08 14:53:18 --> Language Class Initialized
INFO - 2016-06-08 14:53:18 --> Loader Class Initialized
INFO - 2016-06-08 14:53:18 --> Helper loaded: form_helper
INFO - 2016-06-08 14:53:18 --> Database Driver Class Initialized
INFO - 2016-06-08 14:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 14:53:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 14:53:18 --> Email Class Initialized
INFO - 2016-06-08 14:53:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 14:53:18 --> Helper loaded: cookie_helper
INFO - 2016-06-08 14:53:18 --> Helper loaded: language_helper
INFO - 2016-06-08 14:53:18 --> Helper loaded: url_helper
DEBUG - 2016-06-08 14:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 14:53:18 --> Model Class Initialized
INFO - 2016-06-08 14:53:18 --> Helper loaded: date_helper
INFO - 2016-06-08 14:53:18 --> Controller Class Initialized
INFO - 2016-06-08 14:53:18 --> Helper loaded: languages_helper
INFO - 2016-06-08 14:53:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 14:53:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 14:53:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 14:53:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 14:53:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 14:53:18 --> Model Class Initialized
INFO - 2016-06-08 14:53:18 --> Form Validation Class Initialized
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 14:53:18 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 14:53:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 14:53:18 --> Final output sent to browser
DEBUG - 2016-06-08 14:53:18 --> Total execution time: 0.1156
INFO - 2016-06-08 17:46:33 --> Config Class Initialized
INFO - 2016-06-08 17:46:33 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:46:33 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:46:33 --> Utf8 Class Initialized
INFO - 2016-06-08 17:46:33 --> URI Class Initialized
INFO - 2016-06-08 17:46:33 --> Router Class Initialized
INFO - 2016-06-08 17:46:33 --> Output Class Initialized
INFO - 2016-06-08 17:46:33 --> Security Class Initialized
DEBUG - 2016-06-08 17:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:46:33 --> Input Class Initialized
INFO - 2016-06-08 17:46:33 --> Language Class Initialized
INFO - 2016-06-08 17:46:33 --> Loader Class Initialized
INFO - 2016-06-08 17:46:33 --> Helper loaded: form_helper
INFO - 2016-06-08 17:46:33 --> Database Driver Class Initialized
INFO - 2016-06-08 17:46:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:46:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:46:33 --> Email Class Initialized
INFO - 2016-06-08 17:46:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:46:33 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:46:33 --> Helper loaded: language_helper
INFO - 2016-06-08 17:46:33 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:33 --> Model Class Initialized
INFO - 2016-06-08 17:46:33 --> Helper loaded: date_helper
INFO - 2016-06-08 17:46:33 --> Controller Class Initialized
INFO - 2016-06-08 17:46:33 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:46:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:46:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:46:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:46:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:46:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:46:33 --> Model Class Initialized
INFO - 2016-06-08 17:46:33 --> Form Validation Class Initialized
INFO - 2016-06-08 17:46:35 --> Config Class Initialized
INFO - 2016-06-08 17:46:35 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:46:35 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:46:35 --> Utf8 Class Initialized
INFO - 2016-06-08 17:46:35 --> URI Class Initialized
INFO - 2016-06-08 17:46:35 --> Router Class Initialized
INFO - 2016-06-08 17:46:35 --> Output Class Initialized
INFO - 2016-06-08 17:46:35 --> Security Class Initialized
DEBUG - 2016-06-08 17:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:46:35 --> Input Class Initialized
INFO - 2016-06-08 17:46:35 --> Language Class Initialized
INFO - 2016-06-08 17:46:35 --> Loader Class Initialized
INFO - 2016-06-08 17:46:35 --> Helper loaded: form_helper
INFO - 2016-06-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-06-08 17:46:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:46:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:46:35 --> Email Class Initialized
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:46:35 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:46:35 --> Helper loaded: language_helper
INFO - 2016-06-08 17:46:35 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:35 --> Model Class Initialized
INFO - 2016-06-08 17:46:35 --> Helper loaded: date_helper
INFO - 2016-06-08 17:46:35 --> Controller Class Initialized
INFO - 2016-06-08 17:46:35 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:46:35 --> Model Class Initialized
INFO - 2016-06-08 17:46:35 --> Form Validation Class Initialized
INFO - 2016-06-08 17:46:35 --> Config Class Initialized
INFO - 2016-06-08 17:46:35 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:46:35 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:46:35 --> Utf8 Class Initialized
INFO - 2016-06-08 17:46:35 --> URI Class Initialized
INFO - 2016-06-08 17:46:35 --> Router Class Initialized
INFO - 2016-06-08 17:46:35 --> Output Class Initialized
INFO - 2016-06-08 17:46:35 --> Security Class Initialized
DEBUG - 2016-06-08 17:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:46:35 --> Input Class Initialized
INFO - 2016-06-08 17:46:35 --> Language Class Initialized
INFO - 2016-06-08 17:46:35 --> Loader Class Initialized
INFO - 2016-06-08 17:46:35 --> Helper loaded: form_helper
INFO - 2016-06-08 17:46:35 --> Database Driver Class Initialized
INFO - 2016-06-08 17:46:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:46:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:46:35 --> Email Class Initialized
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:46:35 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:46:35 --> Helper loaded: language_helper
INFO - 2016-06-08 17:46:35 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:35 --> Model Class Initialized
INFO - 2016-06-08 17:46:35 --> Helper loaded: date_helper
INFO - 2016-06-08 17:46:35 --> Controller Class Initialized
INFO - 2016-06-08 17:46:35 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:46:35 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-08 17:46:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:35 --> Form Validation Class Initialized
DEBUG - 2016-06-08 17:46:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-08 17:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-08 17:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-08 17:46:35 --> Final output sent to browser
DEBUG - 2016-06-08 17:46:35 --> Total execution time: 0.1415
INFO - 2016-06-08 17:46:51 --> Config Class Initialized
INFO - 2016-06-08 17:46:51 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:46:51 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:46:51 --> Utf8 Class Initialized
INFO - 2016-06-08 17:46:51 --> URI Class Initialized
INFO - 2016-06-08 17:46:51 --> Router Class Initialized
INFO - 2016-06-08 17:46:51 --> Output Class Initialized
INFO - 2016-06-08 17:46:51 --> Security Class Initialized
DEBUG - 2016-06-08 17:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:46:51 --> Input Class Initialized
INFO - 2016-06-08 17:46:51 --> Language Class Initialized
INFO - 2016-06-08 17:46:51 --> Loader Class Initialized
INFO - 2016-06-08 17:46:51 --> Helper loaded: form_helper
INFO - 2016-06-08 17:46:51 --> Database Driver Class Initialized
INFO - 2016-06-08 17:46:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:46:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:46:51 --> Email Class Initialized
INFO - 2016-06-08 17:46:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:46:51 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:46:51 --> Helper loaded: language_helper
INFO - 2016-06-08 17:46:51 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:46:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:51 --> Model Class Initialized
INFO - 2016-06-08 17:46:51 --> Helper loaded: date_helper
INFO - 2016-06-08 17:46:51 --> Controller Class Initialized
INFO - 2016-06-08 17:46:51 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:46:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:46:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:46:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:46:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:46:51 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-08 17:46:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:51 --> Form Validation Class Initialized
DEBUG - 2016-06-08 17:46:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:53 --> Config Class Initialized
INFO - 2016-06-08 17:46:53 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:46:53 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:46:53 --> Utf8 Class Initialized
INFO - 2016-06-08 17:46:53 --> URI Class Initialized
DEBUG - 2016-06-08 17:46:53 --> No URI present. Default controller set.
INFO - 2016-06-08 17:46:53 --> Router Class Initialized
INFO - 2016-06-08 17:46:53 --> Output Class Initialized
INFO - 2016-06-08 17:46:53 --> Security Class Initialized
DEBUG - 2016-06-08 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:46:53 --> Input Class Initialized
INFO - 2016-06-08 17:46:53 --> Language Class Initialized
INFO - 2016-06-08 17:46:53 --> Loader Class Initialized
INFO - 2016-06-08 17:46:53 --> Helper loaded: form_helper
INFO - 2016-06-08 17:46:53 --> Database Driver Class Initialized
INFO - 2016-06-08 17:46:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:46:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:46:53 --> Email Class Initialized
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:46:53 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:46:53 --> Helper loaded: language_helper
INFO - 2016-06-08 17:46:53 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:53 --> Model Class Initialized
INFO - 2016-06-08 17:46:53 --> Helper loaded: date_helper
INFO - 2016-06-08 17:46:53 --> Controller Class Initialized
INFO - 2016-06-08 17:46:53 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:46:53 --> Config Class Initialized
INFO - 2016-06-08 17:46:53 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:46:53 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:46:53 --> Utf8 Class Initialized
INFO - 2016-06-08 17:46:53 --> URI Class Initialized
INFO - 2016-06-08 17:46:53 --> Router Class Initialized
INFO - 2016-06-08 17:46:53 --> Output Class Initialized
INFO - 2016-06-08 17:46:53 --> Security Class Initialized
DEBUG - 2016-06-08 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:46:53 --> Input Class Initialized
INFO - 2016-06-08 17:46:53 --> Language Class Initialized
INFO - 2016-06-08 17:46:53 --> Loader Class Initialized
INFO - 2016-06-08 17:46:53 --> Helper loaded: form_helper
INFO - 2016-06-08 17:46:53 --> Database Driver Class Initialized
INFO - 2016-06-08 17:46:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:46:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:46:53 --> Email Class Initialized
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:46:53 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:46:53 --> Helper loaded: language_helper
INFO - 2016-06-08 17:46:53 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:46:53 --> Model Class Initialized
INFO - 2016-06-08 17:46:53 --> Helper loaded: date_helper
INFO - 2016-06-08 17:46:53 --> Controller Class Initialized
INFO - 2016-06-08 17:46:53 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:46:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:46:53 --> Model Class Initialized
INFO - 2016-06-08 17:46:53 --> Form Validation Class Initialized
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-08 17:46:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:46:53 --> Final output sent to browser
DEBUG - 2016-06-08 17:46:53 --> Total execution time: 0.0263
INFO - 2016-06-08 17:47:06 --> Config Class Initialized
INFO - 2016-06-08 17:47:06 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:47:06 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:47:06 --> Utf8 Class Initialized
INFO - 2016-06-08 17:47:06 --> URI Class Initialized
INFO - 2016-06-08 17:47:06 --> Router Class Initialized
INFO - 2016-06-08 17:47:06 --> Output Class Initialized
INFO - 2016-06-08 17:47:06 --> Security Class Initialized
DEBUG - 2016-06-08 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:47:06 --> Input Class Initialized
INFO - 2016-06-08 17:47:06 --> Language Class Initialized
INFO - 2016-06-08 17:47:06 --> Loader Class Initialized
INFO - 2016-06-08 17:47:06 --> Helper loaded: form_helper
INFO - 2016-06-08 17:47:06 --> Database Driver Class Initialized
INFO - 2016-06-08 17:47:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:47:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:47:06 --> Email Class Initialized
INFO - 2016-06-08 17:47:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:47:06 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:47:06 --> Helper loaded: language_helper
INFO - 2016-06-08 17:47:06 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:47:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:47:06 --> Model Class Initialized
INFO - 2016-06-08 17:47:06 --> Helper loaded: date_helper
INFO - 2016-06-08 17:47:06 --> Controller Class Initialized
INFO - 2016-06-08 17:47:06 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:47:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:47:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:47:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:47:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:47:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:47:06 --> Model Class Initialized
INFO - 2016-06-08 17:47:06 --> Form Validation Class Initialized
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> base64_decode() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 17:47:06 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 17:47:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:47:06 --> Final output sent to browser
DEBUG - 2016-06-08 17:47:06 --> Total execution time: 0.1411
INFO - 2016-06-08 17:48:26 --> Config Class Initialized
INFO - 2016-06-08 17:48:26 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:48:26 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:48:26 --> Utf8 Class Initialized
INFO - 2016-06-08 17:48:26 --> URI Class Initialized
INFO - 2016-06-08 17:48:26 --> Router Class Initialized
INFO - 2016-06-08 17:48:26 --> Output Class Initialized
INFO - 2016-06-08 17:48:26 --> Security Class Initialized
DEBUG - 2016-06-08 17:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:48:26 --> Input Class Initialized
INFO - 2016-06-08 17:48:26 --> Language Class Initialized
INFO - 2016-06-08 17:48:26 --> Loader Class Initialized
INFO - 2016-06-08 17:48:26 --> Helper loaded: form_helper
INFO - 2016-06-08 17:48:26 --> Database Driver Class Initialized
INFO - 2016-06-08 17:48:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:48:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:48:26 --> Email Class Initialized
INFO - 2016-06-08 17:48:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:48:26 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:48:26 --> Helper loaded: language_helper
INFO - 2016-06-08 17:48:26 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:48:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:48:26 --> Model Class Initialized
INFO - 2016-06-08 17:48:26 --> Helper loaded: date_helper
INFO - 2016-06-08 17:48:26 --> Controller Class Initialized
INFO - 2016-06-08 17:48:26 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:48:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:48:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:48:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:48:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:48:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:48:26 --> Model Class Initialized
INFO - 2016-06-08 17:48:26 --> Form Validation Class Initialized
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
ERROR - 2016-06-08 17:48:26 --> Severity: Notice --> Undefined index: featured /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 23
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 17:48:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:48:26 --> Final output sent to browser
DEBUG - 2016-06-08 17:48:26 --> Total execution time: 0.0647
INFO - 2016-06-08 17:49:11 --> Config Class Initialized
INFO - 2016-06-08 17:49:11 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:49:11 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:49:11 --> Utf8 Class Initialized
INFO - 2016-06-08 17:49:11 --> URI Class Initialized
INFO - 2016-06-08 17:49:11 --> Router Class Initialized
INFO - 2016-06-08 17:49:11 --> Output Class Initialized
INFO - 2016-06-08 17:49:11 --> Security Class Initialized
DEBUG - 2016-06-08 17:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:49:11 --> Input Class Initialized
INFO - 2016-06-08 17:49:11 --> Language Class Initialized
INFO - 2016-06-08 17:49:11 --> Loader Class Initialized
INFO - 2016-06-08 17:49:11 --> Helper loaded: form_helper
INFO - 2016-06-08 17:49:11 --> Database Driver Class Initialized
INFO - 2016-06-08 17:49:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:49:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:49:11 --> Email Class Initialized
INFO - 2016-06-08 17:49:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:49:11 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:49:11 --> Helper loaded: language_helper
INFO - 2016-06-08 17:49:11 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:49:11 --> Model Class Initialized
INFO - 2016-06-08 17:49:11 --> Helper loaded: date_helper
INFO - 2016-06-08 17:49:11 --> Controller Class Initialized
INFO - 2016-06-08 17:49:11 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:49:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:49:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:49:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:49:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:49:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:49:11 --> Model Class Initialized
INFO - 2016-06-08 17:49:11 --> Form Validation Class Initialized
INFO - 2016-06-08 17:49:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:49:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:49:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:49:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:49:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:49:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:49:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:49:42 --> Config Class Initialized
INFO - 2016-06-08 17:49:42 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:49:42 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:49:42 --> Utf8 Class Initialized
INFO - 2016-06-08 17:49:42 --> URI Class Initialized
INFO - 2016-06-08 17:49:42 --> Router Class Initialized
INFO - 2016-06-08 17:49:42 --> Output Class Initialized
INFO - 2016-06-08 17:49:42 --> Security Class Initialized
DEBUG - 2016-06-08 17:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:49:42 --> Input Class Initialized
INFO - 2016-06-08 17:49:42 --> Language Class Initialized
INFO - 2016-06-08 17:49:42 --> Loader Class Initialized
INFO - 2016-06-08 17:49:42 --> Helper loaded: form_helper
INFO - 2016-06-08 17:49:42 --> Database Driver Class Initialized
INFO - 2016-06-08 17:49:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:49:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:49:42 --> Email Class Initialized
INFO - 2016-06-08 17:49:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:49:42 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:49:42 --> Helper loaded: language_helper
INFO - 2016-06-08 17:49:42 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:49:42 --> Model Class Initialized
INFO - 2016-06-08 17:49:42 --> Helper loaded: date_helper
INFO - 2016-06-08 17:49:42 --> Controller Class Initialized
INFO - 2016-06-08 17:49:42 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:49:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:49:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:49:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:49:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:49:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:49:42 --> Model Class Initialized
INFO - 2016-06-08 17:49:42 --> Form Validation Class Initialized
INFO - 2016-06-08 17:49:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:49:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:49:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:49:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:49:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:49:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:49:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:51:27 --> Config Class Initialized
INFO - 2016-06-08 17:51:27 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:51:27 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:51:27 --> Utf8 Class Initialized
INFO - 2016-06-08 17:51:27 --> URI Class Initialized
INFO - 2016-06-08 17:51:27 --> Router Class Initialized
INFO - 2016-06-08 17:51:27 --> Output Class Initialized
INFO - 2016-06-08 17:51:27 --> Security Class Initialized
DEBUG - 2016-06-08 17:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:51:27 --> Input Class Initialized
INFO - 2016-06-08 17:51:27 --> Language Class Initialized
INFO - 2016-06-08 17:51:27 --> Loader Class Initialized
INFO - 2016-06-08 17:51:27 --> Helper loaded: form_helper
INFO - 2016-06-08 17:51:27 --> Database Driver Class Initialized
INFO - 2016-06-08 17:51:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:51:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:51:27 --> Email Class Initialized
INFO - 2016-06-08 17:51:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:51:27 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:51:27 --> Helper loaded: language_helper
INFO - 2016-06-08 17:51:27 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:51:27 --> Model Class Initialized
INFO - 2016-06-08 17:51:27 --> Helper loaded: date_helper
INFO - 2016-06-08 17:51:27 --> Controller Class Initialized
INFO - 2016-06-08 17:51:27 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:51:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:51:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:51:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:51:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:51:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:51:27 --> Model Class Initialized
INFO - 2016-06-08 17:51:27 --> Form Validation Class Initialized
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 17:51:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:51:27 --> Final output sent to browser
DEBUG - 2016-06-08 17:51:27 --> Total execution time: 0.1144
INFO - 2016-06-08 17:52:30 --> Config Class Initialized
INFO - 2016-06-08 17:52:30 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:52:30 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:52:30 --> Utf8 Class Initialized
INFO - 2016-06-08 17:52:30 --> URI Class Initialized
INFO - 2016-06-08 17:52:30 --> Router Class Initialized
INFO - 2016-06-08 17:52:30 --> Output Class Initialized
INFO - 2016-06-08 17:52:30 --> Security Class Initialized
DEBUG - 2016-06-08 17:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:52:30 --> Input Class Initialized
INFO - 2016-06-08 17:52:30 --> Language Class Initialized
INFO - 2016-06-08 17:52:30 --> Loader Class Initialized
INFO - 2016-06-08 17:52:30 --> Helper loaded: form_helper
INFO - 2016-06-08 17:52:30 --> Database Driver Class Initialized
INFO - 2016-06-08 17:52:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:52:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:52:30 --> Email Class Initialized
INFO - 2016-06-08 17:52:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:52:30 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:52:30 --> Helper loaded: language_helper
INFO - 2016-06-08 17:52:30 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:52:30 --> Model Class Initialized
INFO - 2016-06-08 17:52:30 --> Helper loaded: date_helper
INFO - 2016-06-08 17:52:30 --> Controller Class Initialized
INFO - 2016-06-08 17:52:30 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:52:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:52:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:52:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:52:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:52:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:52:30 --> Model Class Initialized
INFO - 2016-06-08 17:52:30 --> Form Validation Class Initialized
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:52:30 --> Final output sent to browser
DEBUG - 2016-06-08 17:52:30 --> Total execution time: 0.0420
INFO - 2016-06-08 17:53:04 --> Config Class Initialized
INFO - 2016-06-08 17:53:04 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:53:04 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:53:04 --> Utf8 Class Initialized
INFO - 2016-06-08 17:53:04 --> URI Class Initialized
INFO - 2016-06-08 17:53:04 --> Router Class Initialized
INFO - 2016-06-08 17:53:04 --> Output Class Initialized
INFO - 2016-06-08 17:53:04 --> Security Class Initialized
DEBUG - 2016-06-08 17:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:53:04 --> Input Class Initialized
INFO - 2016-06-08 17:53:04 --> Language Class Initialized
INFO - 2016-06-08 17:53:04 --> Loader Class Initialized
INFO - 2016-06-08 17:53:04 --> Helper loaded: form_helper
INFO - 2016-06-08 17:53:04 --> Database Driver Class Initialized
INFO - 2016-06-08 17:53:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:53:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:53:04 --> Email Class Initialized
INFO - 2016-06-08 17:53:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:53:04 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:53:04 --> Helper loaded: language_helper
INFO - 2016-06-08 17:53:04 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:53:04 --> Model Class Initialized
INFO - 2016-06-08 17:53:04 --> Helper loaded: date_helper
INFO - 2016-06-08 17:53:04 --> Controller Class Initialized
INFO - 2016-06-08 17:53:04 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:53:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:53:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:53:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:53:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:53:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:53:04 --> Model Class Initialized
INFO - 2016-06-08 17:53:04 --> Form Validation Class Initialized
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 17:53:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:53:04 --> Final output sent to browser
DEBUG - 2016-06-08 17:53:04 --> Total execution time: 0.0531
INFO - 2016-06-08 17:54:31 --> Config Class Initialized
INFO - 2016-06-08 17:54:31 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:54:31 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:54:31 --> Utf8 Class Initialized
INFO - 2016-06-08 17:54:31 --> URI Class Initialized
INFO - 2016-06-08 17:54:31 --> Router Class Initialized
INFO - 2016-06-08 17:54:31 --> Output Class Initialized
INFO - 2016-06-08 17:54:31 --> Security Class Initialized
DEBUG - 2016-06-08 17:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:54:31 --> Input Class Initialized
INFO - 2016-06-08 17:54:31 --> Language Class Initialized
INFO - 2016-06-08 17:54:31 --> Loader Class Initialized
INFO - 2016-06-08 17:54:31 --> Helper loaded: form_helper
INFO - 2016-06-08 17:54:31 --> Database Driver Class Initialized
INFO - 2016-06-08 17:54:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:54:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:54:31 --> Email Class Initialized
INFO - 2016-06-08 17:54:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:54:31 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:54:31 --> Helper loaded: language_helper
INFO - 2016-06-08 17:54:31 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:54:31 --> Model Class Initialized
INFO - 2016-06-08 17:54:31 --> Helper loaded: date_helper
INFO - 2016-06-08 17:54:31 --> Controller Class Initialized
INFO - 2016-06-08 17:54:31 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:54:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:54:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:54:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:54:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:54:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:54:31 --> Model Class Initialized
INFO - 2016-06-08 17:54:31 --> Form Validation Class Initialized
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 17:54:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:54:31 --> Final output sent to browser
DEBUG - 2016-06-08 17:54:31 --> Total execution time: 0.0515
INFO - 2016-06-08 17:55:39 --> Config Class Initialized
INFO - 2016-06-08 17:55:39 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:55:39 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:55:39 --> Utf8 Class Initialized
INFO - 2016-06-08 17:55:39 --> URI Class Initialized
INFO - 2016-06-08 17:55:39 --> Router Class Initialized
INFO - 2016-06-08 17:55:39 --> Output Class Initialized
INFO - 2016-06-08 17:55:39 --> Security Class Initialized
DEBUG - 2016-06-08 17:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:55:39 --> Input Class Initialized
INFO - 2016-06-08 17:55:39 --> Language Class Initialized
INFO - 2016-06-08 17:55:39 --> Loader Class Initialized
INFO - 2016-06-08 17:55:39 --> Helper loaded: form_helper
INFO - 2016-06-08 17:55:39 --> Database Driver Class Initialized
INFO - 2016-06-08 17:55:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:55:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:55:39 --> Email Class Initialized
INFO - 2016-06-08 17:55:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:55:39 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:55:39 --> Helper loaded: language_helper
INFO - 2016-06-08 17:55:39 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:55:39 --> Model Class Initialized
INFO - 2016-06-08 17:55:39 --> Helper loaded: date_helper
INFO - 2016-06-08 17:55:39 --> Controller Class Initialized
INFO - 2016-06-08 17:55:39 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:55:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:55:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:55:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:55:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:55:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:55:39 --> Model Class Initialized
INFO - 2016-06-08 17:55:39 --> Form Validation Class Initialized
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 17:55:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 17:55:39 --> Final output sent to browser
DEBUG - 2016-06-08 17:55:39 --> Total execution time: 0.0525
INFO - 2016-06-08 17:58:38 --> Config Class Initialized
INFO - 2016-06-08 17:58:38 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:58:38 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:58:38 --> Utf8 Class Initialized
INFO - 2016-06-08 17:58:38 --> URI Class Initialized
INFO - 2016-06-08 17:58:38 --> Router Class Initialized
INFO - 2016-06-08 17:58:38 --> Output Class Initialized
INFO - 2016-06-08 17:58:38 --> Security Class Initialized
DEBUG - 2016-06-08 17:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:58:38 --> Input Class Initialized
INFO - 2016-06-08 17:58:38 --> Language Class Initialized
INFO - 2016-06-08 17:58:38 --> Loader Class Initialized
INFO - 2016-06-08 17:58:38 --> Helper loaded: form_helper
INFO - 2016-06-08 17:58:38 --> Database Driver Class Initialized
INFO - 2016-06-08 17:58:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:58:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:58:39 --> Email Class Initialized
INFO - 2016-06-08 17:58:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:58:39 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:58:39 --> Helper loaded: language_helper
INFO - 2016-06-08 17:58:39 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:58:39 --> Model Class Initialized
INFO - 2016-06-08 17:58:39 --> Helper loaded: date_helper
INFO - 2016-06-08 17:58:39 --> Controller Class Initialized
INFO - 2016-06-08 17:58:39 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:58:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:58:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:58:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:58:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:58:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:58:39 --> Model Class Initialized
INFO - 2016-06-08 17:58:39 --> Form Validation Class Initialized
INFO - 2016-06-08 17:58:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:58:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:58:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:58:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:58:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:58:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:58:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 17:59:07 --> Config Class Initialized
INFO - 2016-06-08 17:59:07 --> Hooks Class Initialized
DEBUG - 2016-06-08 17:59:07 --> UTF-8 Support Enabled
INFO - 2016-06-08 17:59:07 --> Utf8 Class Initialized
INFO - 2016-06-08 17:59:07 --> URI Class Initialized
INFO - 2016-06-08 17:59:07 --> Router Class Initialized
INFO - 2016-06-08 17:59:07 --> Output Class Initialized
INFO - 2016-06-08 17:59:07 --> Security Class Initialized
DEBUG - 2016-06-08 17:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 17:59:07 --> Input Class Initialized
INFO - 2016-06-08 17:59:07 --> Language Class Initialized
INFO - 2016-06-08 17:59:07 --> Loader Class Initialized
INFO - 2016-06-08 17:59:07 --> Helper loaded: form_helper
INFO - 2016-06-08 17:59:07 --> Database Driver Class Initialized
INFO - 2016-06-08 17:59:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 17:59:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 17:59:07 --> Email Class Initialized
INFO - 2016-06-08 17:59:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 17:59:07 --> Helper loaded: cookie_helper
INFO - 2016-06-08 17:59:07 --> Helper loaded: language_helper
INFO - 2016-06-08 17:59:07 --> Helper loaded: url_helper
DEBUG - 2016-06-08 17:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 17:59:07 --> Model Class Initialized
INFO - 2016-06-08 17:59:07 --> Helper loaded: date_helper
INFO - 2016-06-08 17:59:07 --> Controller Class Initialized
INFO - 2016-06-08 17:59:07 --> Helper loaded: languages_helper
INFO - 2016-06-08 17:59:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 17:59:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 17:59:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 17:59:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 17:59:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 17:59:07 --> Model Class Initialized
INFO - 2016-06-08 17:59:07 --> Form Validation Class Initialized
INFO - 2016-06-08 17:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 17:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 17:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 17:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 17:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 17:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 17:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:01:35 --> Config Class Initialized
INFO - 2016-06-08 18:01:35 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:01:35 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:01:35 --> Utf8 Class Initialized
INFO - 2016-06-08 18:01:35 --> URI Class Initialized
INFO - 2016-06-08 18:01:35 --> Router Class Initialized
INFO - 2016-06-08 18:01:35 --> Output Class Initialized
INFO - 2016-06-08 18:01:35 --> Security Class Initialized
DEBUG - 2016-06-08 18:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:01:35 --> Input Class Initialized
INFO - 2016-06-08 18:01:35 --> Language Class Initialized
INFO - 2016-06-08 18:01:35 --> Loader Class Initialized
INFO - 2016-06-08 18:01:35 --> Helper loaded: form_helper
INFO - 2016-06-08 18:01:35 --> Database Driver Class Initialized
INFO - 2016-06-08 18:01:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:01:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:01:35 --> Email Class Initialized
INFO - 2016-06-08 18:01:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:01:35 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:01:35 --> Helper loaded: language_helper
INFO - 2016-06-08 18:01:35 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:01:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:01:35 --> Model Class Initialized
INFO - 2016-06-08 18:01:35 --> Helper loaded: date_helper
INFO - 2016-06-08 18:01:35 --> Controller Class Initialized
INFO - 2016-06-08 18:01:35 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:01:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:01:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:01:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:01:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:01:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:01:35 --> Model Class Initialized
INFO - 2016-06-08 18:01:35 --> Form Validation Class Initialized
INFO - 2016-06-08 18:01:36 --> Config Class Initialized
INFO - 2016-06-08 18:01:36 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:01:36 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:01:36 --> Utf8 Class Initialized
INFO - 2016-06-08 18:01:36 --> URI Class Initialized
INFO - 2016-06-08 18:01:36 --> Router Class Initialized
INFO - 2016-06-08 18:01:36 --> Output Class Initialized
INFO - 2016-06-08 18:01:36 --> Security Class Initialized
DEBUG - 2016-06-08 18:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:01:36 --> Input Class Initialized
INFO - 2016-06-08 18:01:36 --> Language Class Initialized
INFO - 2016-06-08 18:01:36 --> Loader Class Initialized
INFO - 2016-06-08 18:01:36 --> Helper loaded: form_helper
INFO - 2016-06-08 18:01:36 --> Database Driver Class Initialized
INFO - 2016-06-08 18:01:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:01:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:01:36 --> Email Class Initialized
INFO - 2016-06-08 18:01:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:01:36 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:01:36 --> Helper loaded: language_helper
INFO - 2016-06-08 18:01:36 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:01:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:01:36 --> Model Class Initialized
INFO - 2016-06-08 18:01:36 --> Helper loaded: date_helper
INFO - 2016-06-08 18:01:36 --> Controller Class Initialized
INFO - 2016-06-08 18:01:36 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:01:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:01:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:01:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:01:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:01:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:01:36 --> Model Class Initialized
INFO - 2016-06-08 18:01:36 --> Form Validation Class Initialized
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-08 18:01:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:01:36 --> Final output sent to browser
DEBUG - 2016-06-08 18:01:36 --> Total execution time: 0.1148
INFO - 2016-06-08 18:01:46 --> Config Class Initialized
INFO - 2016-06-08 18:01:46 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:01:46 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:01:46 --> Utf8 Class Initialized
INFO - 2016-06-08 18:01:46 --> URI Class Initialized
INFO - 2016-06-08 18:01:46 --> Router Class Initialized
INFO - 2016-06-08 18:01:46 --> Output Class Initialized
INFO - 2016-06-08 18:01:46 --> Security Class Initialized
DEBUG - 2016-06-08 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:01:46 --> Input Class Initialized
INFO - 2016-06-08 18:01:46 --> Language Class Initialized
INFO - 2016-06-08 18:01:46 --> Loader Class Initialized
INFO - 2016-06-08 18:01:46 --> Helper loaded: form_helper
INFO - 2016-06-08 18:01:46 --> Database Driver Class Initialized
INFO - 2016-06-08 18:01:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:01:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:01:46 --> Email Class Initialized
INFO - 2016-06-08 18:01:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:01:46 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:01:46 --> Helper loaded: language_helper
INFO - 2016-06-08 18:01:46 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:01:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:01:46 --> Model Class Initialized
INFO - 2016-06-08 18:01:46 --> Helper loaded: date_helper
INFO - 2016-06-08 18:01:46 --> Controller Class Initialized
INFO - 2016-06-08 18:01:46 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:01:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:01:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:01:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:01:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:01:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:01:46 --> Model Class Initialized
INFO - 2016-06-08 18:01:46 --> Form Validation Class Initialized
ERROR - 2016-06-08 18:01:46 --> Severity: Warning --> Missing argument 1 for Diabet::addPost() /home/demis/www/platformadiabet/application/controllers/Diabet.php 456
ERROR - 2016-06-08 18:01:46 --> Severity: Notice --> Undefined variable: post_id /home/demis/www/platformadiabet/application/controllers/Diabet.php 458
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:01:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:01:46 --> Final output sent to browser
DEBUG - 2016-06-08 18:01:46 --> Total execution time: 0.1007
INFO - 2016-06-08 18:02:02 --> Config Class Initialized
INFO - 2016-06-08 18:02:02 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:02:02 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:02:02 --> Utf8 Class Initialized
INFO - 2016-06-08 18:02:02 --> URI Class Initialized
INFO - 2016-06-08 18:02:02 --> Router Class Initialized
INFO - 2016-06-08 18:02:02 --> Output Class Initialized
INFO - 2016-06-08 18:02:02 --> Security Class Initialized
DEBUG - 2016-06-08 18:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:02:02 --> Input Class Initialized
INFO - 2016-06-08 18:02:02 --> Language Class Initialized
INFO - 2016-06-08 18:02:02 --> Loader Class Initialized
INFO - 2016-06-08 18:02:02 --> Helper loaded: form_helper
INFO - 2016-06-08 18:02:02 --> Database Driver Class Initialized
INFO - 2016-06-08 18:02:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:02:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:02:02 --> Email Class Initialized
INFO - 2016-06-08 18:02:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:02:02 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:02:02 --> Helper loaded: language_helper
INFO - 2016-06-08 18:02:02 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:02:02 --> Model Class Initialized
INFO - 2016-06-08 18:02:02 --> Helper loaded: date_helper
INFO - 2016-06-08 18:02:02 --> Controller Class Initialized
INFO - 2016-06-08 18:02:02 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:02:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:02:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:02:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:02:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:02:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:02:02 --> Model Class Initialized
INFO - 2016-06-08 18:02:02 --> Form Validation Class Initialized
ERROR - 2016-06-08 18:02:02 --> Severity: Notice --> Undefined variable: post_id /home/demis/www/platformadiabet/application/controllers/Diabet.php 458
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:02:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:02:02 --> Final output sent to browser
DEBUG - 2016-06-08 18:02:02 --> Total execution time: 0.0458
INFO - 2016-06-08 18:02:24 --> Config Class Initialized
INFO - 2016-06-08 18:02:24 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:02:24 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:02:24 --> Utf8 Class Initialized
INFO - 2016-06-08 18:02:24 --> URI Class Initialized
INFO - 2016-06-08 18:02:24 --> Router Class Initialized
INFO - 2016-06-08 18:02:24 --> Output Class Initialized
INFO - 2016-06-08 18:02:24 --> Security Class Initialized
DEBUG - 2016-06-08 18:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:02:24 --> Input Class Initialized
INFO - 2016-06-08 18:02:24 --> Language Class Initialized
INFO - 2016-06-08 18:02:24 --> Loader Class Initialized
INFO - 2016-06-08 18:02:24 --> Helper loaded: form_helper
INFO - 2016-06-08 18:02:24 --> Database Driver Class Initialized
INFO - 2016-06-08 18:02:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:02:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:02:24 --> Email Class Initialized
INFO - 2016-06-08 18:02:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:02:24 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:02:24 --> Helper loaded: language_helper
INFO - 2016-06-08 18:02:24 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:02:24 --> Model Class Initialized
INFO - 2016-06-08 18:02:24 --> Helper loaded: date_helper
INFO - 2016-06-08 18:02:24 --> Controller Class Initialized
INFO - 2016-06-08 18:02:24 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:02:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:02:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:02:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:02:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:02:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:02:24 --> Model Class Initialized
INFO - 2016-06-08 18:02:24 --> Form Validation Class Initialized
ERROR - 2016-06-08 18:02:24 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/controllers/Diabet.php 458
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:02:24 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 63
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:02:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:02:24 --> Final output sent to browser
DEBUG - 2016-06-08 18:02:24 --> Total execution time: 0.0754
INFO - 2016-06-08 18:02:52 --> Config Class Initialized
INFO - 2016-06-08 18:02:52 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:02:52 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:02:52 --> Utf8 Class Initialized
INFO - 2016-06-08 18:02:52 --> URI Class Initialized
INFO - 2016-06-08 18:02:52 --> Router Class Initialized
INFO - 2016-06-08 18:02:52 --> Output Class Initialized
INFO - 2016-06-08 18:02:52 --> Security Class Initialized
DEBUG - 2016-06-08 18:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:02:52 --> Input Class Initialized
INFO - 2016-06-08 18:02:52 --> Language Class Initialized
INFO - 2016-06-08 18:02:52 --> Loader Class Initialized
INFO - 2016-06-08 18:02:52 --> Helper loaded: form_helper
INFO - 2016-06-08 18:02:52 --> Database Driver Class Initialized
INFO - 2016-06-08 18:02:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:02:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:02:52 --> Email Class Initialized
INFO - 2016-06-08 18:02:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:02:52 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:02:52 --> Helper loaded: language_helper
INFO - 2016-06-08 18:02:52 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:02:52 --> Model Class Initialized
INFO - 2016-06-08 18:02:52 --> Helper loaded: date_helper
INFO - 2016-06-08 18:02:52 --> Controller Class Initialized
INFO - 2016-06-08 18:02:52 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:02:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:02:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:02:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:02:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:02:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:02:52 --> Model Class Initialized
INFO - 2016-06-08 18:02:52 --> Form Validation Class Initialized
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:02:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:02:52 --> Final output sent to browser
DEBUG - 2016-06-08 18:02:52 --> Total execution time: 0.0512
INFO - 2016-06-08 18:03:54 --> Config Class Initialized
INFO - 2016-06-08 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:03:54 --> Utf8 Class Initialized
INFO - 2016-06-08 18:03:54 --> URI Class Initialized
INFO - 2016-06-08 18:03:54 --> Router Class Initialized
INFO - 2016-06-08 18:03:54 --> Output Class Initialized
INFO - 2016-06-08 18:03:54 --> Security Class Initialized
DEBUG - 2016-06-08 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:03:54 --> Input Class Initialized
INFO - 2016-06-08 18:03:54 --> Language Class Initialized
INFO - 2016-06-08 18:03:54 --> Loader Class Initialized
INFO - 2016-06-08 18:03:54 --> Helper loaded: form_helper
INFO - 2016-06-08 18:03:54 --> Database Driver Class Initialized
INFO - 2016-06-08 18:03:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:03:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:03:54 --> Email Class Initialized
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:03:54 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:03:54 --> Helper loaded: language_helper
INFO - 2016-06-08 18:03:54 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:03:54 --> Model Class Initialized
INFO - 2016-06-08 18:03:54 --> Helper loaded: date_helper
INFO - 2016-06-08 18:03:54 --> Controller Class Initialized
INFO - 2016-06-08 18:03:54 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:03:54 --> Model Class Initialized
INFO - 2016-06-08 18:03:54 --> Form Validation Class Initialized
INFO - 2016-06-08 18:03:54 --> Config Class Initialized
INFO - 2016-06-08 18:03:54 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:03:54 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:03:54 --> Utf8 Class Initialized
INFO - 2016-06-08 18:03:54 --> URI Class Initialized
INFO - 2016-06-08 18:03:54 --> Router Class Initialized
INFO - 2016-06-08 18:03:54 --> Output Class Initialized
INFO - 2016-06-08 18:03:54 --> Security Class Initialized
DEBUG - 2016-06-08 18:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:03:54 --> Input Class Initialized
INFO - 2016-06-08 18:03:54 --> Language Class Initialized
INFO - 2016-06-08 18:03:54 --> Loader Class Initialized
INFO - 2016-06-08 18:03:54 --> Helper loaded: form_helper
INFO - 2016-06-08 18:03:54 --> Database Driver Class Initialized
INFO - 2016-06-08 18:03:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:03:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:03:54 --> Email Class Initialized
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:03:54 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:03:54 --> Helper loaded: language_helper
INFO - 2016-06-08 18:03:54 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:03:54 --> Model Class Initialized
INFO - 2016-06-08 18:03:54 --> Helper loaded: date_helper
INFO - 2016-06-08 18:03:54 --> Controller Class Initialized
INFO - 2016-06-08 18:03:54 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:03:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:03:54 --> Model Class Initialized
INFO - 2016-06-08 18:03:54 --> Form Validation Class Initialized
INFO - 2016-06-08 18:03:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:03:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:03:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:03:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:03:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:03:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:03:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:06:18 --> Config Class Initialized
INFO - 2016-06-08 18:06:18 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:06:18 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:06:18 --> Utf8 Class Initialized
INFO - 2016-06-08 18:06:18 --> URI Class Initialized
INFO - 2016-06-08 18:06:18 --> Router Class Initialized
INFO - 2016-06-08 18:06:18 --> Output Class Initialized
INFO - 2016-06-08 18:06:18 --> Security Class Initialized
DEBUG - 2016-06-08 18:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:06:18 --> Input Class Initialized
INFO - 2016-06-08 18:06:18 --> Language Class Initialized
INFO - 2016-06-08 18:06:18 --> Loader Class Initialized
INFO - 2016-06-08 18:06:18 --> Helper loaded: form_helper
INFO - 2016-06-08 18:06:18 --> Database Driver Class Initialized
INFO - 2016-06-08 18:06:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:06:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:06:18 --> Email Class Initialized
INFO - 2016-06-08 18:06:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:06:18 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:06:18 --> Helper loaded: language_helper
INFO - 2016-06-08 18:06:18 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:06:18 --> Model Class Initialized
INFO - 2016-06-08 18:06:18 --> Helper loaded: date_helper
INFO - 2016-06-08 18:06:18 --> Controller Class Initialized
INFO - 2016-06-08 18:06:18 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:06:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:06:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:06:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:06:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:06:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:06:18 --> Model Class Initialized
INFO - 2016-06-08 18:06:18 --> Form Validation Class Initialized
INFO - 2016-06-08 18:06:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:06:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:06:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:06:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:06:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:06:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:06:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:06:21 --> Config Class Initialized
INFO - 2016-06-08 18:06:21 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:06:21 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:06:21 --> Utf8 Class Initialized
INFO - 2016-06-08 18:06:21 --> URI Class Initialized
INFO - 2016-06-08 18:06:21 --> Router Class Initialized
INFO - 2016-06-08 18:06:21 --> Output Class Initialized
INFO - 2016-06-08 18:06:21 --> Security Class Initialized
DEBUG - 2016-06-08 18:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:06:21 --> Input Class Initialized
INFO - 2016-06-08 18:06:21 --> Language Class Initialized
INFO - 2016-06-08 18:06:21 --> Loader Class Initialized
INFO - 2016-06-08 18:06:21 --> Helper loaded: form_helper
INFO - 2016-06-08 18:06:21 --> Database Driver Class Initialized
INFO - 2016-06-08 18:06:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:06:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:06:21 --> Email Class Initialized
INFO - 2016-06-08 18:06:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:06:21 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:06:21 --> Helper loaded: language_helper
INFO - 2016-06-08 18:06:21 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:06:21 --> Model Class Initialized
INFO - 2016-06-08 18:06:21 --> Helper loaded: date_helper
INFO - 2016-06-08 18:06:21 --> Controller Class Initialized
INFO - 2016-06-08 18:06:21 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:06:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:06:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:06:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:06:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:06:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:06:21 --> Model Class Initialized
INFO - 2016-06-08 18:06:21 --> Form Validation Class Initialized
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:06:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:06:21 --> Final output sent to browser
DEBUG - 2016-06-08 18:06:21 --> Total execution time: 0.0969
INFO - 2016-06-08 18:06:59 --> Config Class Initialized
INFO - 2016-06-08 18:06:59 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:06:59 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:06:59 --> Utf8 Class Initialized
INFO - 2016-06-08 18:06:59 --> URI Class Initialized
INFO - 2016-06-08 18:06:59 --> Router Class Initialized
INFO - 2016-06-08 18:06:59 --> Output Class Initialized
INFO - 2016-06-08 18:06:59 --> Security Class Initialized
DEBUG - 2016-06-08 18:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:06:59 --> Input Class Initialized
INFO - 2016-06-08 18:06:59 --> Language Class Initialized
INFO - 2016-06-08 18:06:59 --> Loader Class Initialized
INFO - 2016-06-08 18:06:59 --> Helper loaded: form_helper
INFO - 2016-06-08 18:06:59 --> Database Driver Class Initialized
INFO - 2016-06-08 18:06:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:06:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:06:59 --> Email Class Initialized
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:06:59 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:06:59 --> Helper loaded: language_helper
INFO - 2016-06-08 18:06:59 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:06:59 --> Model Class Initialized
INFO - 2016-06-08 18:06:59 --> Helper loaded: date_helper
INFO - 2016-06-08 18:06:59 --> Controller Class Initialized
INFO - 2016-06-08 18:06:59 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:06:59 --> Model Class Initialized
INFO - 2016-06-08 18:06:59 --> Form Validation Class Initialized
INFO - 2016-06-08 18:06:59 --> Final output sent to browser
DEBUG - 2016-06-08 18:06:59 --> Total execution time: 0.1943
INFO - 2016-06-08 18:06:59 --> Config Class Initialized
INFO - 2016-06-08 18:06:59 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:06:59 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:06:59 --> Utf8 Class Initialized
INFO - 2016-06-08 18:06:59 --> URI Class Initialized
INFO - 2016-06-08 18:06:59 --> Router Class Initialized
INFO - 2016-06-08 18:06:59 --> Output Class Initialized
INFO - 2016-06-08 18:06:59 --> Security Class Initialized
DEBUG - 2016-06-08 18:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:06:59 --> Input Class Initialized
INFO - 2016-06-08 18:06:59 --> Language Class Initialized
INFO - 2016-06-08 18:06:59 --> Loader Class Initialized
INFO - 2016-06-08 18:06:59 --> Helper loaded: form_helper
INFO - 2016-06-08 18:06:59 --> Database Driver Class Initialized
INFO - 2016-06-08 18:06:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:06:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:06:59 --> Email Class Initialized
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:06:59 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:06:59 --> Helper loaded: language_helper
INFO - 2016-06-08 18:06:59 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:06:59 --> Model Class Initialized
INFO - 2016-06-08 18:06:59 --> Helper loaded: date_helper
INFO - 2016-06-08 18:06:59 --> Controller Class Initialized
INFO - 2016-06-08 18:06:59 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:06:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:06:59 --> Model Class Initialized
INFO - 2016-06-08 18:06:59 --> Form Validation Class Initialized
INFO - 2016-06-08 18:06:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:06:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:06:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:06:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:06:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:06:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:06:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:09:42 --> Config Class Initialized
INFO - 2016-06-08 18:09:42 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:09:42 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:09:42 --> Utf8 Class Initialized
INFO - 2016-06-08 18:09:42 --> URI Class Initialized
INFO - 2016-06-08 18:09:42 --> Router Class Initialized
INFO - 2016-06-08 18:09:42 --> Output Class Initialized
INFO - 2016-06-08 18:09:42 --> Security Class Initialized
DEBUG - 2016-06-08 18:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:09:42 --> Input Class Initialized
INFO - 2016-06-08 18:09:42 --> Language Class Initialized
INFO - 2016-06-08 18:09:42 --> Loader Class Initialized
INFO - 2016-06-08 18:09:42 --> Helper loaded: form_helper
INFO - 2016-06-08 18:09:42 --> Database Driver Class Initialized
INFO - 2016-06-08 18:09:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:09:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:09:42 --> Email Class Initialized
INFO - 2016-06-08 18:09:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:09:42 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:09:42 --> Helper loaded: language_helper
INFO - 2016-06-08 18:09:42 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:09:42 --> Model Class Initialized
INFO - 2016-06-08 18:09:42 --> Helper loaded: date_helper
INFO - 2016-06-08 18:09:42 --> Controller Class Initialized
INFO - 2016-06-08 18:09:42 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:09:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:09:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:09:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:09:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:09:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:09:42 --> Model Class Initialized
INFO - 2016-06-08 18:09:42 --> Form Validation Class Initialized
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:09:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:09:42 --> Final output sent to browser
DEBUG - 2016-06-08 18:09:42 --> Total execution time: 0.0563
INFO - 2016-06-08 18:11:17 --> Config Class Initialized
INFO - 2016-06-08 18:11:17 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:11:17 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:11:17 --> Utf8 Class Initialized
INFO - 2016-06-08 18:11:17 --> URI Class Initialized
INFO - 2016-06-08 18:11:17 --> Router Class Initialized
INFO - 2016-06-08 18:11:17 --> Output Class Initialized
INFO - 2016-06-08 18:11:17 --> Security Class Initialized
DEBUG - 2016-06-08 18:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:11:17 --> Input Class Initialized
INFO - 2016-06-08 18:11:17 --> Language Class Initialized
INFO - 2016-06-08 18:11:17 --> Loader Class Initialized
INFO - 2016-06-08 18:11:17 --> Helper loaded: form_helper
INFO - 2016-06-08 18:11:17 --> Database Driver Class Initialized
INFO - 2016-06-08 18:11:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:11:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:11:17 --> Email Class Initialized
INFO - 2016-06-08 18:11:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:11:17 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:11:17 --> Helper loaded: language_helper
INFO - 2016-06-08 18:11:17 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:11:17 --> Model Class Initialized
INFO - 2016-06-08 18:11:17 --> Helper loaded: date_helper
INFO - 2016-06-08 18:11:17 --> Controller Class Initialized
INFO - 2016-06-08 18:11:17 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:11:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:11:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:11:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:11:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:11:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:11:17 --> Model Class Initialized
INFO - 2016-06-08 18:11:17 --> Form Validation Class Initialized
INFO - 2016-06-08 18:11:17 --> Final output sent to browser
DEBUG - 2016-06-08 18:11:17 --> Total execution time: 0.2226
INFO - 2016-06-08 18:11:18 --> Config Class Initialized
INFO - 2016-06-08 18:11:18 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:11:18 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:11:18 --> Utf8 Class Initialized
INFO - 2016-06-08 18:11:18 --> URI Class Initialized
INFO - 2016-06-08 18:11:18 --> Router Class Initialized
INFO - 2016-06-08 18:11:18 --> Output Class Initialized
INFO - 2016-06-08 18:11:18 --> Security Class Initialized
DEBUG - 2016-06-08 18:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:11:18 --> Input Class Initialized
INFO - 2016-06-08 18:11:18 --> Language Class Initialized
INFO - 2016-06-08 18:11:18 --> Loader Class Initialized
INFO - 2016-06-08 18:11:18 --> Helper loaded: form_helper
INFO - 2016-06-08 18:11:18 --> Database Driver Class Initialized
INFO - 2016-06-08 18:11:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:11:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:11:18 --> Email Class Initialized
INFO - 2016-06-08 18:11:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:11:18 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:11:18 --> Helper loaded: language_helper
INFO - 2016-06-08 18:11:18 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:11:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:11:18 --> Model Class Initialized
INFO - 2016-06-08 18:11:18 --> Helper loaded: date_helper
INFO - 2016-06-08 18:11:18 --> Controller Class Initialized
INFO - 2016-06-08 18:11:18 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:11:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:11:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:11:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:11:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:11:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:11:18 --> Model Class Initialized
INFO - 2016-06-08 18:11:18 --> Form Validation Class Initialized
INFO - 2016-06-08 18:11:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:11:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:11:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:11:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:11:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:11:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:11:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:12:26 --> Config Class Initialized
INFO - 2016-06-08 18:12:26 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:12:26 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:12:26 --> Utf8 Class Initialized
INFO - 2016-06-08 18:12:26 --> URI Class Initialized
INFO - 2016-06-08 18:12:26 --> Router Class Initialized
INFO - 2016-06-08 18:12:26 --> Output Class Initialized
INFO - 2016-06-08 18:12:26 --> Security Class Initialized
DEBUG - 2016-06-08 18:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:12:26 --> Input Class Initialized
INFO - 2016-06-08 18:12:26 --> Language Class Initialized
INFO - 2016-06-08 18:12:26 --> Loader Class Initialized
INFO - 2016-06-08 18:12:26 --> Helper loaded: form_helper
INFO - 2016-06-08 18:12:26 --> Database Driver Class Initialized
INFO - 2016-06-08 18:12:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:12:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:12:26 --> Email Class Initialized
INFO - 2016-06-08 18:12:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:12:26 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:12:26 --> Helper loaded: language_helper
INFO - 2016-06-08 18:12:26 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:12:26 --> Model Class Initialized
INFO - 2016-06-08 18:12:26 --> Helper loaded: date_helper
INFO - 2016-06-08 18:12:26 --> Controller Class Initialized
INFO - 2016-06-08 18:12:26 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:12:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:12:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:12:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:12:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:12:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:12:26 --> Model Class Initialized
INFO - 2016-06-08 18:12:26 --> Form Validation Class Initialized
INFO - 2016-06-08 18:12:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:12:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:12:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:12:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:12:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:12:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:12:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:13:00 --> Config Class Initialized
INFO - 2016-06-08 18:13:00 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:13:00 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:13:00 --> Utf8 Class Initialized
INFO - 2016-06-08 18:13:00 --> URI Class Initialized
INFO - 2016-06-08 18:13:00 --> Router Class Initialized
INFO - 2016-06-08 18:13:00 --> Output Class Initialized
INFO - 2016-06-08 18:13:00 --> Security Class Initialized
DEBUG - 2016-06-08 18:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:13:00 --> Input Class Initialized
INFO - 2016-06-08 18:13:00 --> Language Class Initialized
INFO - 2016-06-08 18:13:00 --> Loader Class Initialized
INFO - 2016-06-08 18:13:00 --> Helper loaded: form_helper
INFO - 2016-06-08 18:13:00 --> Database Driver Class Initialized
INFO - 2016-06-08 18:13:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:13:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:13:00 --> Email Class Initialized
INFO - 2016-06-08 18:13:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:13:00 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:13:00 --> Helper loaded: language_helper
INFO - 2016-06-08 18:13:00 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:13:00 --> Model Class Initialized
INFO - 2016-06-08 18:13:00 --> Helper loaded: date_helper
INFO - 2016-06-08 18:13:00 --> Controller Class Initialized
INFO - 2016-06-08 18:13:00 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:13:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:13:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:13:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:13:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:13:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:13:00 --> Model Class Initialized
INFO - 2016-06-08 18:13:00 --> Form Validation Class Initialized
INFO - 2016-06-08 18:13:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:13:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:13:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:13:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:13:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:13:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:13:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:13:55 --> Config Class Initialized
INFO - 2016-06-08 18:13:55 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:13:55 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:13:55 --> Utf8 Class Initialized
INFO - 2016-06-08 18:13:55 --> URI Class Initialized
INFO - 2016-06-08 18:13:55 --> Router Class Initialized
INFO - 2016-06-08 18:13:55 --> Output Class Initialized
INFO - 2016-06-08 18:13:55 --> Security Class Initialized
DEBUG - 2016-06-08 18:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:13:55 --> Input Class Initialized
INFO - 2016-06-08 18:13:55 --> Language Class Initialized
INFO - 2016-06-08 18:13:55 --> Loader Class Initialized
INFO - 2016-06-08 18:13:55 --> Helper loaded: form_helper
INFO - 2016-06-08 18:13:55 --> Database Driver Class Initialized
INFO - 2016-06-08 18:13:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:13:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:13:55 --> Email Class Initialized
INFO - 2016-06-08 18:13:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:13:55 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:13:55 --> Helper loaded: language_helper
INFO - 2016-06-08 18:13:55 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:13:55 --> Model Class Initialized
INFO - 2016-06-08 18:13:55 --> Helper loaded: date_helper
INFO - 2016-06-08 18:13:55 --> Controller Class Initialized
INFO - 2016-06-08 18:13:55 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:13:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:13:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:13:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:13:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:13:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:13:55 --> Model Class Initialized
INFO - 2016-06-08 18:13:55 --> Form Validation Class Initialized
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:13:55 --> Severity: Warning --> strip_tags() expects at most 2 parameters, 3 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
ERROR - 2016-06-08 18:13:55 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php 22
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:13:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:13:55 --> Final output sent to browser
DEBUG - 2016-06-08 18:13:55 --> Total execution time: 0.0552
INFO - 2016-06-08 18:14:17 --> Config Class Initialized
INFO - 2016-06-08 18:14:17 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:14:17 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:14:17 --> Utf8 Class Initialized
INFO - 2016-06-08 18:14:17 --> URI Class Initialized
INFO - 2016-06-08 18:14:17 --> Router Class Initialized
INFO - 2016-06-08 18:14:17 --> Output Class Initialized
INFO - 2016-06-08 18:14:17 --> Security Class Initialized
DEBUG - 2016-06-08 18:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:14:17 --> Input Class Initialized
INFO - 2016-06-08 18:14:17 --> Language Class Initialized
INFO - 2016-06-08 18:14:17 --> Loader Class Initialized
INFO - 2016-06-08 18:14:17 --> Helper loaded: form_helper
INFO - 2016-06-08 18:14:17 --> Database Driver Class Initialized
INFO - 2016-06-08 18:14:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:14:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:14:17 --> Email Class Initialized
INFO - 2016-06-08 18:14:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:14:17 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:14:17 --> Helper loaded: language_helper
INFO - 2016-06-08 18:14:17 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:14:17 --> Model Class Initialized
INFO - 2016-06-08 18:14:17 --> Helper loaded: date_helper
INFO - 2016-06-08 18:14:17 --> Controller Class Initialized
INFO - 2016-06-08 18:14:17 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:14:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:14:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:14:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:14:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:14:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:14:17 --> Model Class Initialized
INFO - 2016-06-08 18:14:17 --> Form Validation Class Initialized
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:14:17 --> Final output sent to browser
DEBUG - 2016-06-08 18:14:17 --> Total execution time: 0.0636
INFO - 2016-06-08 18:15:54 --> Config Class Initialized
INFO - 2016-06-08 18:15:54 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:15:54 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:15:54 --> Utf8 Class Initialized
INFO - 2016-06-08 18:15:54 --> URI Class Initialized
INFO - 2016-06-08 18:15:54 --> Router Class Initialized
INFO - 2016-06-08 18:15:54 --> Output Class Initialized
INFO - 2016-06-08 18:15:54 --> Security Class Initialized
DEBUG - 2016-06-08 18:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:15:54 --> Input Class Initialized
INFO - 2016-06-08 18:15:54 --> Language Class Initialized
INFO - 2016-06-08 18:15:54 --> Loader Class Initialized
INFO - 2016-06-08 18:15:54 --> Helper loaded: form_helper
INFO - 2016-06-08 18:15:54 --> Database Driver Class Initialized
INFO - 2016-06-08 18:15:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:15:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:15:54 --> Email Class Initialized
INFO - 2016-06-08 18:15:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:15:54 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:15:54 --> Helper loaded: language_helper
INFO - 2016-06-08 18:15:54 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:15:54 --> Model Class Initialized
INFO - 2016-06-08 18:15:54 --> Helper loaded: date_helper
INFO - 2016-06-08 18:15:54 --> Controller Class Initialized
INFO - 2016-06-08 18:15:54 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:15:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:15:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:15:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:15:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:15:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:15:54 --> Model Class Initialized
INFO - 2016-06-08 18:15:54 --> Form Validation Class Initialized
INFO - 2016-06-08 18:15:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:15:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:15:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:15:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:15:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:15:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:15:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:16:55 --> Config Class Initialized
INFO - 2016-06-08 18:16:55 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:16:55 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:16:55 --> Utf8 Class Initialized
INFO - 2016-06-08 18:16:55 --> URI Class Initialized
INFO - 2016-06-08 18:16:55 --> Router Class Initialized
INFO - 2016-06-08 18:16:55 --> Output Class Initialized
INFO - 2016-06-08 18:16:55 --> Security Class Initialized
DEBUG - 2016-06-08 18:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:16:55 --> Input Class Initialized
INFO - 2016-06-08 18:16:55 --> Language Class Initialized
INFO - 2016-06-08 18:16:55 --> Loader Class Initialized
INFO - 2016-06-08 18:16:55 --> Helper loaded: form_helper
INFO - 2016-06-08 18:16:55 --> Database Driver Class Initialized
INFO - 2016-06-08 18:16:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:16:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:16:55 --> Email Class Initialized
INFO - 2016-06-08 18:16:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:16:55 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:16:55 --> Helper loaded: language_helper
INFO - 2016-06-08 18:16:55 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:16:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:16:55 --> Model Class Initialized
INFO - 2016-06-08 18:16:55 --> Helper loaded: date_helper
INFO - 2016-06-08 18:16:55 --> Controller Class Initialized
INFO - 2016-06-08 18:16:55 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:16:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:16:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:16:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:16:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:16:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:16:55 --> Model Class Initialized
INFO - 2016-06-08 18:16:55 --> Form Validation Class Initialized
INFO - 2016-06-08 18:16:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:16:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:16:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:16:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:16:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:16:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:16:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:17:55 --> Config Class Initialized
INFO - 2016-06-08 18:17:55 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:17:55 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:17:55 --> Utf8 Class Initialized
INFO - 2016-06-08 18:17:55 --> URI Class Initialized
INFO - 2016-06-08 18:17:55 --> Router Class Initialized
INFO - 2016-06-08 18:17:55 --> Output Class Initialized
INFO - 2016-06-08 18:17:55 --> Security Class Initialized
DEBUG - 2016-06-08 18:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:17:55 --> Input Class Initialized
INFO - 2016-06-08 18:17:55 --> Language Class Initialized
INFO - 2016-06-08 18:17:55 --> Loader Class Initialized
INFO - 2016-06-08 18:17:55 --> Helper loaded: form_helper
INFO - 2016-06-08 18:17:55 --> Database Driver Class Initialized
INFO - 2016-06-08 18:17:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:17:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:17:55 --> Email Class Initialized
INFO - 2016-06-08 18:17:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:17:55 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:17:55 --> Helper loaded: language_helper
INFO - 2016-06-08 18:17:55 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:17:55 --> Model Class Initialized
INFO - 2016-06-08 18:17:55 --> Helper loaded: date_helper
INFO - 2016-06-08 18:17:55 --> Controller Class Initialized
INFO - 2016-06-08 18:17:55 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:17:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:17:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:17:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:17:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:17:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:17:55 --> Model Class Initialized
INFO - 2016-06-08 18:17:55 --> Form Validation Class Initialized
INFO - 2016-06-08 18:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:18:35 --> Config Class Initialized
INFO - 2016-06-08 18:18:35 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:18:35 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:18:35 --> Utf8 Class Initialized
INFO - 2016-06-08 18:18:35 --> URI Class Initialized
INFO - 2016-06-08 18:18:35 --> Router Class Initialized
INFO - 2016-06-08 18:18:35 --> Output Class Initialized
INFO - 2016-06-08 18:18:35 --> Security Class Initialized
DEBUG - 2016-06-08 18:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:18:35 --> Input Class Initialized
INFO - 2016-06-08 18:18:35 --> Language Class Initialized
INFO - 2016-06-08 18:18:35 --> Loader Class Initialized
INFO - 2016-06-08 18:18:35 --> Helper loaded: form_helper
INFO - 2016-06-08 18:18:35 --> Database Driver Class Initialized
INFO - 2016-06-08 18:18:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:18:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:18:35 --> Email Class Initialized
INFO - 2016-06-08 18:18:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:18:35 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:18:35 --> Helper loaded: language_helper
INFO - 2016-06-08 18:18:35 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:18:35 --> Model Class Initialized
INFO - 2016-06-08 18:18:35 --> Helper loaded: date_helper
INFO - 2016-06-08 18:18:35 --> Controller Class Initialized
INFO - 2016-06-08 18:18:35 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:18:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:18:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:18:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:18:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:18:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:18:35 --> Model Class Initialized
INFO - 2016-06-08 18:18:35 --> Form Validation Class Initialized
INFO - 2016-06-08 18:18:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:18:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:18:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:18:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:18:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:18:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:18:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:21:02 --> Config Class Initialized
INFO - 2016-06-08 18:21:02 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:21:02 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:21:02 --> Utf8 Class Initialized
INFO - 2016-06-08 18:21:02 --> URI Class Initialized
INFO - 2016-06-08 18:21:02 --> Router Class Initialized
INFO - 2016-06-08 18:21:02 --> Output Class Initialized
INFO - 2016-06-08 18:21:02 --> Security Class Initialized
DEBUG - 2016-06-08 18:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:21:02 --> Input Class Initialized
INFO - 2016-06-08 18:21:02 --> Language Class Initialized
INFO - 2016-06-08 18:21:02 --> Loader Class Initialized
INFO - 2016-06-08 18:21:02 --> Helper loaded: form_helper
INFO - 2016-06-08 18:21:02 --> Database Driver Class Initialized
INFO - 2016-06-08 18:21:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:21:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:21:02 --> Email Class Initialized
INFO - 2016-06-08 18:21:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:21:02 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:21:02 --> Helper loaded: language_helper
INFO - 2016-06-08 18:21:02 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:21:02 --> Model Class Initialized
INFO - 2016-06-08 18:21:02 --> Helper loaded: date_helper
INFO - 2016-06-08 18:21:02 --> Controller Class Initialized
INFO - 2016-06-08 18:21:02 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:21:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:21:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:21:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:21:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:21:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:21:02 --> Model Class Initialized
INFO - 2016-06-08 18:21:02 --> Form Validation Class Initialized
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:21:02 --> Final output sent to browser
DEBUG - 2016-06-08 18:21:02 --> Total execution time: 0.0587
INFO - 2016-06-08 18:21:26 --> Config Class Initialized
INFO - 2016-06-08 18:21:26 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:21:26 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:21:26 --> Utf8 Class Initialized
INFO - 2016-06-08 18:21:26 --> URI Class Initialized
INFO - 2016-06-08 18:21:26 --> Router Class Initialized
INFO - 2016-06-08 18:21:26 --> Output Class Initialized
INFO - 2016-06-08 18:21:26 --> Security Class Initialized
DEBUG - 2016-06-08 18:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:21:26 --> Input Class Initialized
INFO - 2016-06-08 18:21:26 --> Language Class Initialized
INFO - 2016-06-08 18:21:26 --> Loader Class Initialized
INFO - 2016-06-08 18:21:26 --> Helper loaded: form_helper
INFO - 2016-06-08 18:21:26 --> Database Driver Class Initialized
INFO - 2016-06-08 18:21:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:21:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:21:26 --> Email Class Initialized
INFO - 2016-06-08 18:21:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:21:26 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:21:26 --> Helper loaded: language_helper
INFO - 2016-06-08 18:21:26 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:21:26 --> Model Class Initialized
INFO - 2016-06-08 18:21:26 --> Helper loaded: date_helper
INFO - 2016-06-08 18:21:26 --> Controller Class Initialized
INFO - 2016-06-08 18:21:26 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:21:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:21:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:21:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:21:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:21:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:21:26 --> Model Class Initialized
INFO - 2016-06-08 18:21:26 --> Form Validation Class Initialized
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:21:26 --> Final output sent to browser
DEBUG - 2016-06-08 18:21:26 --> Total execution time: 0.0290
INFO - 2016-06-08 18:22:46 --> Config Class Initialized
INFO - 2016-06-08 18:22:46 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:22:46 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:22:46 --> Utf8 Class Initialized
INFO - 2016-06-08 18:22:46 --> URI Class Initialized
INFO - 2016-06-08 18:22:46 --> Router Class Initialized
INFO - 2016-06-08 18:22:46 --> Output Class Initialized
INFO - 2016-06-08 18:22:46 --> Security Class Initialized
DEBUG - 2016-06-08 18:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:22:46 --> Input Class Initialized
INFO - 2016-06-08 18:22:46 --> Language Class Initialized
INFO - 2016-06-08 18:22:46 --> Loader Class Initialized
INFO - 2016-06-08 18:22:46 --> Helper loaded: form_helper
INFO - 2016-06-08 18:22:46 --> Database Driver Class Initialized
INFO - 2016-06-08 18:22:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:22:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:22:46 --> Email Class Initialized
INFO - 2016-06-08 18:22:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:22:46 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:22:46 --> Helper loaded: language_helper
INFO - 2016-06-08 18:22:46 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:22:46 --> Model Class Initialized
INFO - 2016-06-08 18:22:46 --> Helper loaded: date_helper
INFO - 2016-06-08 18:22:46 --> Controller Class Initialized
INFO - 2016-06-08 18:22:46 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:22:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:22:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:22:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:22:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:22:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:22:46 --> Model Class Initialized
INFO - 2016-06-08 18:22:46 --> Form Validation Class Initialized
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:22:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:22:46 --> Final output sent to browser
DEBUG - 2016-06-08 18:22:46 --> Total execution time: 0.0670
INFO - 2016-06-08 18:23:21 --> Config Class Initialized
INFO - 2016-06-08 18:23:21 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:23:21 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:23:21 --> Utf8 Class Initialized
INFO - 2016-06-08 18:23:21 --> URI Class Initialized
INFO - 2016-06-08 18:23:21 --> Router Class Initialized
INFO - 2016-06-08 18:23:21 --> Output Class Initialized
INFO - 2016-06-08 18:23:21 --> Security Class Initialized
DEBUG - 2016-06-08 18:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:23:21 --> Input Class Initialized
INFO - 2016-06-08 18:23:21 --> Language Class Initialized
INFO - 2016-06-08 18:23:21 --> Loader Class Initialized
INFO - 2016-06-08 18:23:21 --> Helper loaded: form_helper
INFO - 2016-06-08 18:23:21 --> Database Driver Class Initialized
INFO - 2016-06-08 18:23:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:23:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:23:21 --> Email Class Initialized
INFO - 2016-06-08 18:23:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:23:21 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:23:21 --> Helper loaded: language_helper
INFO - 2016-06-08 18:23:21 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:23:21 --> Model Class Initialized
INFO - 2016-06-08 18:23:21 --> Helper loaded: date_helper
INFO - 2016-06-08 18:23:21 --> Controller Class Initialized
INFO - 2016-06-08 18:23:21 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:23:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:23:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:23:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:23:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:23:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:23:21 --> Model Class Initialized
INFO - 2016-06-08 18:23:21 --> Form Validation Class Initialized
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:23:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:23:21 --> Final output sent to browser
DEBUG - 2016-06-08 18:23:21 --> Total execution time: 0.0589
INFO - 2016-06-08 18:24:15 --> Config Class Initialized
INFO - 2016-06-08 18:24:15 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:24:15 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:24:15 --> Utf8 Class Initialized
INFO - 2016-06-08 18:24:15 --> URI Class Initialized
INFO - 2016-06-08 18:24:15 --> Router Class Initialized
INFO - 2016-06-08 18:24:15 --> Output Class Initialized
INFO - 2016-06-08 18:24:15 --> Security Class Initialized
DEBUG - 2016-06-08 18:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:24:15 --> Input Class Initialized
INFO - 2016-06-08 18:24:15 --> Language Class Initialized
INFO - 2016-06-08 18:24:15 --> Loader Class Initialized
INFO - 2016-06-08 18:24:15 --> Helper loaded: form_helper
INFO - 2016-06-08 18:24:15 --> Database Driver Class Initialized
INFO - 2016-06-08 18:24:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:24:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:24:15 --> Email Class Initialized
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:24:15 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:24:15 --> Helper loaded: language_helper
INFO - 2016-06-08 18:24:15 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:24:15 --> Model Class Initialized
INFO - 2016-06-08 18:24:15 --> Helper loaded: date_helper
INFO - 2016-06-08 18:24:15 --> Controller Class Initialized
INFO - 2016-06-08 18:24:15 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:24:15 --> Model Class Initialized
INFO - 2016-06-08 18:24:15 --> Form Validation Class Initialized
INFO - 2016-06-08 18:24:15 --> Final output sent to browser
DEBUG - 2016-06-08 18:24:15 --> Total execution time: 0.1591
INFO - 2016-06-08 18:24:15 --> Config Class Initialized
INFO - 2016-06-08 18:24:15 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:24:15 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:24:15 --> Utf8 Class Initialized
INFO - 2016-06-08 18:24:15 --> URI Class Initialized
INFO - 2016-06-08 18:24:15 --> Router Class Initialized
INFO - 2016-06-08 18:24:15 --> Output Class Initialized
INFO - 2016-06-08 18:24:15 --> Security Class Initialized
DEBUG - 2016-06-08 18:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:24:15 --> Input Class Initialized
INFO - 2016-06-08 18:24:15 --> Language Class Initialized
INFO - 2016-06-08 18:24:15 --> Loader Class Initialized
INFO - 2016-06-08 18:24:15 --> Helper loaded: form_helper
INFO - 2016-06-08 18:24:15 --> Database Driver Class Initialized
INFO - 2016-06-08 18:24:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:24:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:24:15 --> Email Class Initialized
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:24:15 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:24:15 --> Helper loaded: language_helper
INFO - 2016-06-08 18:24:15 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:24:15 --> Model Class Initialized
INFO - 2016-06-08 18:24:15 --> Helper loaded: date_helper
INFO - 2016-06-08 18:24:15 --> Controller Class Initialized
INFO - 2016-06-08 18:24:15 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:24:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:24:15 --> Model Class Initialized
INFO - 2016-06-08 18:24:15 --> Form Validation Class Initialized
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:24:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:24:15 --> Final output sent to browser
DEBUG - 2016-06-08 18:24:15 --> Total execution time: 0.0297
INFO - 2016-06-08 18:24:38 --> Config Class Initialized
INFO - 2016-06-08 18:24:38 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:24:38 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:24:38 --> Utf8 Class Initialized
INFO - 2016-06-08 18:24:38 --> URI Class Initialized
INFO - 2016-06-08 18:24:38 --> Router Class Initialized
INFO - 2016-06-08 18:24:38 --> Output Class Initialized
INFO - 2016-06-08 18:24:38 --> Security Class Initialized
DEBUG - 2016-06-08 18:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:24:38 --> Input Class Initialized
INFO - 2016-06-08 18:24:38 --> Language Class Initialized
INFO - 2016-06-08 18:24:38 --> Loader Class Initialized
INFO - 2016-06-08 18:24:38 --> Helper loaded: form_helper
INFO - 2016-06-08 18:24:38 --> Database Driver Class Initialized
INFO - 2016-06-08 18:24:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:24:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:24:38 --> Email Class Initialized
INFO - 2016-06-08 18:24:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:24:38 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:24:38 --> Helper loaded: language_helper
INFO - 2016-06-08 18:24:38 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:24:38 --> Model Class Initialized
INFO - 2016-06-08 18:24:38 --> Helper loaded: date_helper
INFO - 2016-06-08 18:24:38 --> Controller Class Initialized
INFO - 2016-06-08 18:24:38 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:24:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:24:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:24:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:24:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:24:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:24:38 --> Model Class Initialized
INFO - 2016-06-08 18:24:38 --> Form Validation Class Initialized
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:24:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:24:38 --> Final output sent to browser
DEBUG - 2016-06-08 18:24:38 --> Total execution time: 0.0506
INFO - 2016-06-08 18:24:52 --> Config Class Initialized
INFO - 2016-06-08 18:24:52 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:24:52 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:24:52 --> Utf8 Class Initialized
INFO - 2016-06-08 18:24:52 --> URI Class Initialized
INFO - 2016-06-08 18:24:52 --> Router Class Initialized
INFO - 2016-06-08 18:24:52 --> Output Class Initialized
INFO - 2016-06-08 18:24:52 --> Security Class Initialized
DEBUG - 2016-06-08 18:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:24:52 --> Input Class Initialized
INFO - 2016-06-08 18:24:52 --> Language Class Initialized
INFO - 2016-06-08 18:24:52 --> Loader Class Initialized
INFO - 2016-06-08 18:24:52 --> Helper loaded: form_helper
INFO - 2016-06-08 18:24:52 --> Database Driver Class Initialized
INFO - 2016-06-08 18:24:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:24:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:24:52 --> Email Class Initialized
INFO - 2016-06-08 18:24:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:24:52 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:24:52 --> Helper loaded: language_helper
INFO - 2016-06-08 18:24:52 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:24:52 --> Model Class Initialized
INFO - 2016-06-08 18:24:52 --> Helper loaded: date_helper
INFO - 2016-06-08 18:24:52 --> Controller Class Initialized
INFO - 2016-06-08 18:24:52 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:24:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:24:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:24:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:24:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:24:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:24:52 --> Model Class Initialized
INFO - 2016-06-08 18:24:52 --> Form Validation Class Initialized
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:24:52 --> Final output sent to browser
DEBUG - 2016-06-08 18:24:52 --> Total execution time: 0.0452
INFO - 2016-06-08 18:28:42 --> Config Class Initialized
INFO - 2016-06-08 18:28:42 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:28:42 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:28:42 --> Utf8 Class Initialized
INFO - 2016-06-08 18:28:42 --> URI Class Initialized
INFO - 2016-06-08 18:28:42 --> Router Class Initialized
INFO - 2016-06-08 18:28:42 --> Output Class Initialized
INFO - 2016-06-08 18:28:42 --> Security Class Initialized
DEBUG - 2016-06-08 18:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:28:42 --> Input Class Initialized
INFO - 2016-06-08 18:28:42 --> Language Class Initialized
INFO - 2016-06-08 18:28:42 --> Loader Class Initialized
INFO - 2016-06-08 18:28:42 --> Helper loaded: form_helper
INFO - 2016-06-08 18:28:42 --> Database Driver Class Initialized
INFO - 2016-06-08 18:28:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:28:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:28:42 --> Email Class Initialized
INFO - 2016-06-08 18:28:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:28:42 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:28:42 --> Helper loaded: language_helper
INFO - 2016-06-08 18:28:42 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:28:42 --> Model Class Initialized
INFO - 2016-06-08 18:28:42 --> Helper loaded: date_helper
INFO - 2016-06-08 18:28:42 --> Controller Class Initialized
INFO - 2016-06-08 18:28:42 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:28:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:28:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:28:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:28:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:28:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:28:42 --> Model Class Initialized
INFO - 2016-06-08 18:28:42 --> Form Validation Class Initialized
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:28:42 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 63
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:28:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:28:42 --> Final output sent to browser
DEBUG - 2016-06-08 18:28:42 --> Total execution time: 0.0762
INFO - 2016-06-08 18:30:29 --> Config Class Initialized
INFO - 2016-06-08 18:30:29 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:30:29 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:30:29 --> Utf8 Class Initialized
INFO - 2016-06-08 18:30:29 --> URI Class Initialized
INFO - 2016-06-08 18:30:29 --> Router Class Initialized
INFO - 2016-06-08 18:30:29 --> Output Class Initialized
INFO - 2016-06-08 18:30:29 --> Security Class Initialized
DEBUG - 2016-06-08 18:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:30:29 --> Input Class Initialized
INFO - 2016-06-08 18:30:29 --> Language Class Initialized
INFO - 2016-06-08 18:30:29 --> Loader Class Initialized
INFO - 2016-06-08 18:30:29 --> Helper loaded: form_helper
INFO - 2016-06-08 18:30:29 --> Database Driver Class Initialized
INFO - 2016-06-08 18:30:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:30:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:30:29 --> Email Class Initialized
INFO - 2016-06-08 18:30:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:30:29 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:30:29 --> Helper loaded: language_helper
INFO - 2016-06-08 18:30:29 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:30:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:30:29 --> Model Class Initialized
INFO - 2016-06-08 18:30:29 --> Helper loaded: date_helper
INFO - 2016-06-08 18:30:29 --> Controller Class Initialized
INFO - 2016-06-08 18:30:29 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:30:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:30:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:30:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:30:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:30:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:30:29 --> Model Class Initialized
INFO - 2016-06-08 18:30:29 --> Form Validation Class Initialized
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:30:29 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 63
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:30:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:30:29 --> Final output sent to browser
DEBUG - 2016-06-08 18:30:29 --> Total execution time: 0.1179
INFO - 2016-06-08 18:33:58 --> Config Class Initialized
INFO - 2016-06-08 18:33:58 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:33:58 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:33:58 --> Utf8 Class Initialized
INFO - 2016-06-08 18:33:58 --> URI Class Initialized
INFO - 2016-06-08 18:33:58 --> Router Class Initialized
INFO - 2016-06-08 18:33:58 --> Output Class Initialized
INFO - 2016-06-08 18:33:58 --> Security Class Initialized
DEBUG - 2016-06-08 18:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:33:58 --> Input Class Initialized
INFO - 2016-06-08 18:33:58 --> Language Class Initialized
INFO - 2016-06-08 18:33:58 --> Loader Class Initialized
INFO - 2016-06-08 18:33:58 --> Helper loaded: form_helper
INFO - 2016-06-08 18:33:58 --> Database Driver Class Initialized
INFO - 2016-06-08 18:33:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:33:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:33:58 --> Email Class Initialized
INFO - 2016-06-08 18:33:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:33:58 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:33:58 --> Helper loaded: language_helper
INFO - 2016-06-08 18:33:58 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:33:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:33:58 --> Model Class Initialized
INFO - 2016-06-08 18:33:58 --> Helper loaded: date_helper
INFO - 2016-06-08 18:33:58 --> Controller Class Initialized
INFO - 2016-06-08 18:33:58 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:33:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:33:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:33:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:33:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:33:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:33:58 --> Model Class Initialized
INFO - 2016-06-08 18:33:58 --> Form Validation Class Initialized
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:33:58 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 63
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:33:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:33:58 --> Final output sent to browser
DEBUG - 2016-06-08 18:33:58 --> Total execution time: 0.0504
INFO - 2016-06-08 18:35:38 --> Config Class Initialized
INFO - 2016-06-08 18:35:38 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:35:38 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:35:38 --> Utf8 Class Initialized
INFO - 2016-06-08 18:35:38 --> URI Class Initialized
INFO - 2016-06-08 18:35:38 --> Router Class Initialized
INFO - 2016-06-08 18:35:38 --> Output Class Initialized
INFO - 2016-06-08 18:35:38 --> Security Class Initialized
DEBUG - 2016-06-08 18:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:35:38 --> Input Class Initialized
INFO - 2016-06-08 18:35:38 --> Language Class Initialized
INFO - 2016-06-08 18:35:38 --> Loader Class Initialized
INFO - 2016-06-08 18:35:38 --> Helper loaded: form_helper
INFO - 2016-06-08 18:35:38 --> Database Driver Class Initialized
INFO - 2016-06-08 18:35:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:35:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:35:38 --> Email Class Initialized
INFO - 2016-06-08 18:35:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:35:38 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:35:38 --> Helper loaded: language_helper
INFO - 2016-06-08 18:35:38 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:35:38 --> Model Class Initialized
INFO - 2016-06-08 18:35:38 --> Helper loaded: date_helper
INFO - 2016-06-08 18:35:38 --> Controller Class Initialized
INFO - 2016-06-08 18:35:38 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:35:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:35:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:35:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:35:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:35:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:35:38 --> Model Class Initialized
INFO - 2016-06-08 18:35:38 --> Form Validation Class Initialized
INFO - 2016-06-08 18:35:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:35:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:35:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:35:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:35:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:35:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:35:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:35:38 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 64
INFO - 2016-06-08 18:36:14 --> Config Class Initialized
INFO - 2016-06-08 18:36:14 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:36:14 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:36:14 --> Utf8 Class Initialized
INFO - 2016-06-08 18:36:14 --> URI Class Initialized
INFO - 2016-06-08 18:36:14 --> Router Class Initialized
INFO - 2016-06-08 18:36:14 --> Output Class Initialized
INFO - 2016-06-08 18:36:14 --> Security Class Initialized
DEBUG - 2016-06-08 18:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:36:14 --> Input Class Initialized
INFO - 2016-06-08 18:36:14 --> Language Class Initialized
INFO - 2016-06-08 18:36:14 --> Loader Class Initialized
INFO - 2016-06-08 18:36:14 --> Helper loaded: form_helper
INFO - 2016-06-08 18:36:14 --> Database Driver Class Initialized
INFO - 2016-06-08 18:36:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:36:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:36:14 --> Email Class Initialized
INFO - 2016-06-08 18:36:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:36:14 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:36:14 --> Helper loaded: language_helper
INFO - 2016-06-08 18:36:14 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:36:14 --> Model Class Initialized
INFO - 2016-06-08 18:36:14 --> Helper loaded: date_helper
INFO - 2016-06-08 18:36:14 --> Controller Class Initialized
INFO - 2016-06-08 18:36:14 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:36:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:36:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:36:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:36:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:36:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:36:14 --> Model Class Initialized
INFO - 2016-06-08 18:36:14 --> Form Validation Class Initialized
INFO - 2016-06-08 18:36:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:36:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:36:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:36:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:36:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:36:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:36:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:36:14 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 64
INFO - 2016-06-08 18:37:27 --> Config Class Initialized
INFO - 2016-06-08 18:37:27 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:37:27 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:37:27 --> Utf8 Class Initialized
INFO - 2016-06-08 18:37:27 --> URI Class Initialized
INFO - 2016-06-08 18:37:27 --> Router Class Initialized
INFO - 2016-06-08 18:37:27 --> Output Class Initialized
INFO - 2016-06-08 18:37:27 --> Security Class Initialized
DEBUG - 2016-06-08 18:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:37:27 --> Input Class Initialized
INFO - 2016-06-08 18:37:27 --> Language Class Initialized
INFO - 2016-06-08 18:37:27 --> Loader Class Initialized
INFO - 2016-06-08 18:37:27 --> Helper loaded: form_helper
INFO - 2016-06-08 18:37:27 --> Database Driver Class Initialized
INFO - 2016-06-08 18:37:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:37:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:37:27 --> Email Class Initialized
INFO - 2016-06-08 18:37:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:37:27 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:37:27 --> Helper loaded: language_helper
INFO - 2016-06-08 18:37:27 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:37:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:37:27 --> Model Class Initialized
INFO - 2016-06-08 18:37:27 --> Helper loaded: date_helper
INFO - 2016-06-08 18:37:27 --> Controller Class Initialized
INFO - 2016-06-08 18:37:27 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:37:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:37:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:37:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:37:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:37:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:37:27 --> Model Class Initialized
INFO - 2016-06-08 18:37:27 --> Form Validation Class Initialized
INFO - 2016-06-08 18:37:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:37:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:37:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:37:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:37:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:37:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:37:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:37:27 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 64
INFO - 2016-06-08 18:38:11 --> Config Class Initialized
INFO - 2016-06-08 18:38:11 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:38:11 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:38:11 --> Utf8 Class Initialized
INFO - 2016-06-08 18:38:11 --> URI Class Initialized
INFO - 2016-06-08 18:38:11 --> Router Class Initialized
INFO - 2016-06-08 18:38:11 --> Output Class Initialized
INFO - 2016-06-08 18:38:11 --> Security Class Initialized
DEBUG - 2016-06-08 18:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:38:11 --> Input Class Initialized
INFO - 2016-06-08 18:38:11 --> Language Class Initialized
INFO - 2016-06-08 18:38:11 --> Loader Class Initialized
INFO - 2016-06-08 18:38:11 --> Helper loaded: form_helper
INFO - 2016-06-08 18:38:11 --> Database Driver Class Initialized
INFO - 2016-06-08 18:38:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:38:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:38:11 --> Email Class Initialized
INFO - 2016-06-08 18:38:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:38:11 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:38:11 --> Helper loaded: language_helper
INFO - 2016-06-08 18:38:11 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:38:11 --> Model Class Initialized
INFO - 2016-06-08 18:38:11 --> Helper loaded: date_helper
INFO - 2016-06-08 18:38:11 --> Controller Class Initialized
INFO - 2016-06-08 18:38:11 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:38:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:38:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:38:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:38:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:38:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:38:11 --> Model Class Initialized
INFO - 2016-06-08 18:38:11 --> Form Validation Class Initialized
INFO - 2016-06-08 18:38:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:38:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:38:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:38:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:38:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:38:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:38:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:38:11 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 64
INFO - 2016-06-08 18:38:53 --> Config Class Initialized
INFO - 2016-06-08 18:38:53 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:38:53 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:38:53 --> Utf8 Class Initialized
INFO - 2016-06-08 18:38:53 --> URI Class Initialized
INFO - 2016-06-08 18:38:53 --> Router Class Initialized
INFO - 2016-06-08 18:38:53 --> Output Class Initialized
INFO - 2016-06-08 18:38:53 --> Security Class Initialized
DEBUG - 2016-06-08 18:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:38:53 --> Input Class Initialized
INFO - 2016-06-08 18:38:53 --> Language Class Initialized
INFO - 2016-06-08 18:38:53 --> Loader Class Initialized
INFO - 2016-06-08 18:38:53 --> Helper loaded: form_helper
INFO - 2016-06-08 18:38:53 --> Database Driver Class Initialized
INFO - 2016-06-08 18:38:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:38:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:38:53 --> Email Class Initialized
INFO - 2016-06-08 18:38:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:38:53 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:38:53 --> Helper loaded: language_helper
INFO - 2016-06-08 18:38:53 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:38:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:38:53 --> Model Class Initialized
INFO - 2016-06-08 18:38:53 --> Helper loaded: date_helper
INFO - 2016-06-08 18:38:53 --> Controller Class Initialized
INFO - 2016-06-08 18:38:53 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:38:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:38:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:38:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:38:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:38:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:38:53 --> Model Class Initialized
INFO - 2016-06-08 18:38:53 --> Form Validation Class Initialized
INFO - 2016-06-08 18:38:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:38:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:38:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:38:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:38:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:38:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:38:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 18:38:53 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 64
INFO - 2016-06-08 18:39:24 --> Config Class Initialized
INFO - 2016-06-08 18:39:24 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:39:24 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:39:24 --> Utf8 Class Initialized
INFO - 2016-06-08 18:39:24 --> URI Class Initialized
INFO - 2016-06-08 18:39:24 --> Router Class Initialized
INFO - 2016-06-08 18:39:24 --> Output Class Initialized
INFO - 2016-06-08 18:39:24 --> Security Class Initialized
DEBUG - 2016-06-08 18:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:39:24 --> Input Class Initialized
INFO - 2016-06-08 18:39:24 --> Language Class Initialized
INFO - 2016-06-08 18:39:24 --> Loader Class Initialized
INFO - 2016-06-08 18:39:24 --> Helper loaded: form_helper
INFO - 2016-06-08 18:39:24 --> Database Driver Class Initialized
INFO - 2016-06-08 18:39:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:39:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:39:24 --> Email Class Initialized
INFO - 2016-06-08 18:39:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:39:24 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:39:24 --> Helper loaded: language_helper
INFO - 2016-06-08 18:39:24 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:39:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:39:24 --> Model Class Initialized
INFO - 2016-06-08 18:39:24 --> Helper loaded: date_helper
INFO - 2016-06-08 18:39:24 --> Controller Class Initialized
INFO - 2016-06-08 18:39:24 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:39:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:39:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:39:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:39:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:39:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:39:24 --> Model Class Initialized
INFO - 2016-06-08 18:39:24 --> Form Validation Class Initialized
INFO - 2016-06-08 18:39:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:39:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:39:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:39:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:39:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:39:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:39:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:40:01 --> Config Class Initialized
INFO - 2016-06-08 18:40:01 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:40:01 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:40:01 --> Utf8 Class Initialized
INFO - 2016-06-08 18:40:01 --> URI Class Initialized
INFO - 2016-06-08 18:40:01 --> Router Class Initialized
INFO - 2016-06-08 18:40:01 --> Output Class Initialized
INFO - 2016-06-08 18:40:01 --> Security Class Initialized
DEBUG - 2016-06-08 18:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:40:01 --> Input Class Initialized
INFO - 2016-06-08 18:40:01 --> Language Class Initialized
INFO - 2016-06-08 18:40:01 --> Loader Class Initialized
INFO - 2016-06-08 18:40:01 --> Helper loaded: form_helper
INFO - 2016-06-08 18:40:01 --> Database Driver Class Initialized
INFO - 2016-06-08 18:40:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:40:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:40:01 --> Email Class Initialized
INFO - 2016-06-08 18:40:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:40:01 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:40:01 --> Helper loaded: language_helper
INFO - 2016-06-08 18:40:01 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:40:01 --> Model Class Initialized
INFO - 2016-06-08 18:40:01 --> Helper loaded: date_helper
INFO - 2016-06-08 18:40:01 --> Controller Class Initialized
INFO - 2016-06-08 18:40:01 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:40:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:40:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:40:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:40:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:40:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:40:01 --> Model Class Initialized
INFO - 2016-06-08 18:40:01 --> Form Validation Class Initialized
INFO - 2016-06-08 18:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:40:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:40:24 --> Config Class Initialized
INFO - 2016-06-08 18:40:24 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:40:24 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:40:24 --> Utf8 Class Initialized
INFO - 2016-06-08 18:40:24 --> URI Class Initialized
INFO - 2016-06-08 18:40:24 --> Router Class Initialized
INFO - 2016-06-08 18:40:24 --> Output Class Initialized
INFO - 2016-06-08 18:40:24 --> Security Class Initialized
DEBUG - 2016-06-08 18:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:40:24 --> Input Class Initialized
INFO - 2016-06-08 18:40:24 --> Language Class Initialized
INFO - 2016-06-08 18:40:24 --> Loader Class Initialized
INFO - 2016-06-08 18:40:24 --> Helper loaded: form_helper
INFO - 2016-06-08 18:40:24 --> Database Driver Class Initialized
INFO - 2016-06-08 18:40:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:40:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:40:24 --> Email Class Initialized
INFO - 2016-06-08 18:40:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:40:24 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:40:24 --> Helper loaded: language_helper
INFO - 2016-06-08 18:40:24 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:40:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:40:24 --> Model Class Initialized
INFO - 2016-06-08 18:40:24 --> Helper loaded: date_helper
INFO - 2016-06-08 18:40:24 --> Controller Class Initialized
INFO - 2016-06-08 18:40:24 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:40:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:40:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:40:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:40:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:40:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:40:24 --> Model Class Initialized
INFO - 2016-06-08 18:40:24 --> Form Validation Class Initialized
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:40:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:40:24 --> Final output sent to browser
DEBUG - 2016-06-08 18:40:24 --> Total execution time: 0.0880
INFO - 2016-06-08 18:40:35 --> Config Class Initialized
INFO - 2016-06-08 18:40:35 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:40:35 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:40:35 --> Utf8 Class Initialized
INFO - 2016-06-08 18:40:35 --> URI Class Initialized
INFO - 2016-06-08 18:40:35 --> Router Class Initialized
INFO - 2016-06-08 18:40:35 --> Output Class Initialized
INFO - 2016-06-08 18:40:35 --> Security Class Initialized
DEBUG - 2016-06-08 18:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:40:35 --> Input Class Initialized
INFO - 2016-06-08 18:40:35 --> Language Class Initialized
INFO - 2016-06-08 18:40:35 --> Loader Class Initialized
INFO - 2016-06-08 18:40:35 --> Helper loaded: form_helper
INFO - 2016-06-08 18:40:35 --> Database Driver Class Initialized
INFO - 2016-06-08 18:40:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:40:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:40:35 --> Email Class Initialized
INFO - 2016-06-08 18:40:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:40:35 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:40:35 --> Helper loaded: language_helper
INFO - 2016-06-08 18:40:35 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:40:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:40:35 --> Model Class Initialized
INFO - 2016-06-08 18:40:35 --> Helper loaded: date_helper
INFO - 2016-06-08 18:40:35 --> Controller Class Initialized
INFO - 2016-06-08 18:40:35 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:40:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:40:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:40:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:40:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:40:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:40:35 --> Model Class Initialized
INFO - 2016-06-08 18:40:35 --> Form Validation Class Initialized
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:40:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:40:35 --> Final output sent to browser
DEBUG - 2016-06-08 18:40:35 --> Total execution time: 0.1127
INFO - 2016-06-08 18:40:44 --> Config Class Initialized
INFO - 2016-06-08 18:40:44 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:40:44 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:40:44 --> Utf8 Class Initialized
INFO - 2016-06-08 18:40:44 --> URI Class Initialized
INFO - 2016-06-08 18:40:44 --> Router Class Initialized
INFO - 2016-06-08 18:40:44 --> Output Class Initialized
INFO - 2016-06-08 18:40:44 --> Security Class Initialized
DEBUG - 2016-06-08 18:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:40:44 --> Input Class Initialized
INFO - 2016-06-08 18:40:44 --> Language Class Initialized
INFO - 2016-06-08 18:40:44 --> Loader Class Initialized
INFO - 2016-06-08 18:40:44 --> Helper loaded: form_helper
INFO - 2016-06-08 18:40:44 --> Database Driver Class Initialized
INFO - 2016-06-08 18:40:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:40:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:40:44 --> Email Class Initialized
INFO - 2016-06-08 18:40:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:40:44 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:40:44 --> Helper loaded: language_helper
INFO - 2016-06-08 18:40:44 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:40:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:40:44 --> Model Class Initialized
INFO - 2016-06-08 18:40:44 --> Helper loaded: date_helper
INFO - 2016-06-08 18:40:44 --> Controller Class Initialized
INFO - 2016-06-08 18:40:44 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:40:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:40:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:40:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:40:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:40:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:40:44 --> Model Class Initialized
INFO - 2016-06-08 18:40:44 --> Form Validation Class Initialized
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:40:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:40:44 --> Final output sent to browser
DEBUG - 2016-06-08 18:40:44 --> Total execution time: 0.0985
INFO - 2016-06-08 18:43:31 --> Config Class Initialized
INFO - 2016-06-08 18:43:31 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:43:31 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:43:31 --> Utf8 Class Initialized
INFO - 2016-06-08 18:43:31 --> URI Class Initialized
INFO - 2016-06-08 18:43:31 --> Router Class Initialized
INFO - 2016-06-08 18:43:31 --> Output Class Initialized
INFO - 2016-06-08 18:43:31 --> Security Class Initialized
DEBUG - 2016-06-08 18:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:43:31 --> Input Class Initialized
INFO - 2016-06-08 18:43:31 --> Language Class Initialized
INFO - 2016-06-08 18:43:31 --> Loader Class Initialized
INFO - 2016-06-08 18:43:31 --> Helper loaded: form_helper
INFO - 2016-06-08 18:43:31 --> Database Driver Class Initialized
INFO - 2016-06-08 18:43:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:43:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:43:31 --> Email Class Initialized
INFO - 2016-06-08 18:43:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:43:31 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:43:31 --> Helper loaded: language_helper
INFO - 2016-06-08 18:43:31 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:43:31 --> Model Class Initialized
INFO - 2016-06-08 18:43:31 --> Helper loaded: date_helper
INFO - 2016-06-08 18:43:31 --> Controller Class Initialized
INFO - 2016-06-08 18:43:31 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:43:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:43:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:43:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:43:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:43:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:43:31 --> Model Class Initialized
INFO - 2016-06-08 18:43:31 --> Form Validation Class Initialized
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:43:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:43:31 --> Final output sent to browser
DEBUG - 2016-06-08 18:43:31 --> Total execution time: 0.0834
INFO - 2016-06-08 18:53:31 --> Config Class Initialized
INFO - 2016-06-08 18:53:31 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:53:31 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:53:31 --> Utf8 Class Initialized
INFO - 2016-06-08 18:53:31 --> URI Class Initialized
INFO - 2016-06-08 18:53:31 --> Router Class Initialized
INFO - 2016-06-08 18:53:31 --> Output Class Initialized
INFO - 2016-06-08 18:53:31 --> Security Class Initialized
DEBUG - 2016-06-08 18:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:53:31 --> Input Class Initialized
INFO - 2016-06-08 18:53:31 --> Language Class Initialized
INFO - 2016-06-08 18:53:31 --> Loader Class Initialized
INFO - 2016-06-08 18:53:31 --> Helper loaded: form_helper
INFO - 2016-06-08 18:53:31 --> Database Driver Class Initialized
INFO - 2016-06-08 18:53:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:53:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:53:31 --> Email Class Initialized
INFO - 2016-06-08 18:53:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:53:31 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:53:31 --> Helper loaded: language_helper
INFO - 2016-06-08 18:53:31 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:53:31 --> Model Class Initialized
INFO - 2016-06-08 18:53:31 --> Helper loaded: date_helper
INFO - 2016-06-08 18:53:31 --> Controller Class Initialized
INFO - 2016-06-08 18:53:31 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:53:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:53:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:53:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:53:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:53:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:53:31 --> Model Class Initialized
INFO - 2016-06-08 18:53:31 --> Form Validation Class Initialized
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 18:53:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:53:31 --> Final output sent to browser
DEBUG - 2016-06-08 18:53:31 --> Total execution time: 0.0786
INFO - 2016-06-08 18:54:41 --> Config Class Initialized
INFO - 2016-06-08 18:54:41 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:54:41 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:54:41 --> Utf8 Class Initialized
INFO - 2016-06-08 18:54:41 --> URI Class Initialized
INFO - 2016-06-08 18:54:41 --> Router Class Initialized
INFO - 2016-06-08 18:54:41 --> Output Class Initialized
INFO - 2016-06-08 18:54:41 --> Security Class Initialized
DEBUG - 2016-06-08 18:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:54:41 --> Input Class Initialized
INFO - 2016-06-08 18:54:41 --> Language Class Initialized
INFO - 2016-06-08 18:54:41 --> Loader Class Initialized
INFO - 2016-06-08 18:54:41 --> Helper loaded: form_helper
INFO - 2016-06-08 18:54:41 --> Database Driver Class Initialized
INFO - 2016-06-08 18:54:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:54:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:54:42 --> Email Class Initialized
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:54:42 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:54:42 --> Helper loaded: language_helper
INFO - 2016-06-08 18:54:42 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:54:42 --> Model Class Initialized
INFO - 2016-06-08 18:54:42 --> Helper loaded: date_helper
INFO - 2016-06-08 18:54:42 --> Controller Class Initialized
INFO - 2016-06-08 18:54:42 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:54:42 --> Model Class Initialized
INFO - 2016-06-08 18:54:42 --> Form Validation Class Initialized
INFO - 2016-06-08 18:54:42 --> Final output sent to browser
DEBUG - 2016-06-08 18:54:42 --> Total execution time: 0.0607
INFO - 2016-06-08 18:54:42 --> Config Class Initialized
INFO - 2016-06-08 18:54:42 --> Hooks Class Initialized
DEBUG - 2016-06-08 18:54:42 --> UTF-8 Support Enabled
INFO - 2016-06-08 18:54:42 --> Utf8 Class Initialized
INFO - 2016-06-08 18:54:42 --> URI Class Initialized
INFO - 2016-06-08 18:54:42 --> Router Class Initialized
INFO - 2016-06-08 18:54:42 --> Output Class Initialized
INFO - 2016-06-08 18:54:42 --> Security Class Initialized
DEBUG - 2016-06-08 18:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 18:54:42 --> Input Class Initialized
INFO - 2016-06-08 18:54:42 --> Language Class Initialized
INFO - 2016-06-08 18:54:42 --> Loader Class Initialized
INFO - 2016-06-08 18:54:42 --> Helper loaded: form_helper
INFO - 2016-06-08 18:54:42 --> Database Driver Class Initialized
INFO - 2016-06-08 18:54:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 18:54:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 18:54:42 --> Email Class Initialized
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 18:54:42 --> Helper loaded: cookie_helper
INFO - 2016-06-08 18:54:42 --> Helper loaded: language_helper
INFO - 2016-06-08 18:54:42 --> Helper loaded: url_helper
DEBUG - 2016-06-08 18:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 18:54:42 --> Model Class Initialized
INFO - 2016-06-08 18:54:42 --> Helper loaded: date_helper
INFO - 2016-06-08 18:54:42 --> Controller Class Initialized
INFO - 2016-06-08 18:54:42 --> Helper loaded: languages_helper
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 18:54:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 18:54:42 --> Model Class Initialized
INFO - 2016-06-08 18:54:42 --> Form Validation Class Initialized
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 18:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 18:54:42 --> Final output sent to browser
DEBUG - 2016-06-08 18:54:42 --> Total execution time: 0.0391
INFO - 2016-06-08 19:01:11 --> Config Class Initialized
INFO - 2016-06-08 19:01:11 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:01:11 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:01:11 --> Utf8 Class Initialized
INFO - 2016-06-08 19:01:11 --> URI Class Initialized
INFO - 2016-06-08 19:01:11 --> Router Class Initialized
INFO - 2016-06-08 19:01:11 --> Output Class Initialized
INFO - 2016-06-08 19:01:11 --> Security Class Initialized
DEBUG - 2016-06-08 19:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:01:11 --> Input Class Initialized
INFO - 2016-06-08 19:01:11 --> Language Class Initialized
INFO - 2016-06-08 19:01:11 --> Loader Class Initialized
INFO - 2016-06-08 19:01:11 --> Helper loaded: form_helper
INFO - 2016-06-08 19:01:11 --> Database Driver Class Initialized
INFO - 2016-06-08 19:01:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:01:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:01:11 --> Email Class Initialized
INFO - 2016-06-08 19:01:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:01:11 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:01:11 --> Helper loaded: language_helper
INFO - 2016-06-08 19:01:11 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:01:11 --> Model Class Initialized
INFO - 2016-06-08 19:01:11 --> Helper loaded: date_helper
INFO - 2016-06-08 19:01:11 --> Controller Class Initialized
INFO - 2016-06-08 19:01:11 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:01:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:01:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:01:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:01:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:01:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:01:11 --> Model Class Initialized
INFO - 2016-06-08 19:01:11 --> Form Validation Class Initialized
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 19:01:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:01:11 --> Final output sent to browser
DEBUG - 2016-06-08 19:01:11 --> Total execution time: 0.1426
INFO - 2016-06-08 19:01:26 --> Config Class Initialized
INFO - 2016-06-08 19:01:26 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:01:26 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:01:26 --> Utf8 Class Initialized
INFO - 2016-06-08 19:01:26 --> URI Class Initialized
INFO - 2016-06-08 19:01:26 --> Router Class Initialized
INFO - 2016-06-08 19:01:26 --> Output Class Initialized
INFO - 2016-06-08 19:01:26 --> Security Class Initialized
DEBUG - 2016-06-08 19:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:01:26 --> Input Class Initialized
INFO - 2016-06-08 19:01:26 --> Language Class Initialized
INFO - 2016-06-08 19:01:26 --> Loader Class Initialized
INFO - 2016-06-08 19:01:26 --> Helper loaded: form_helper
INFO - 2016-06-08 19:01:26 --> Database Driver Class Initialized
INFO - 2016-06-08 19:01:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:01:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:01:26 --> Email Class Initialized
INFO - 2016-06-08 19:01:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:01:26 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:01:26 --> Helper loaded: language_helper
INFO - 2016-06-08 19:01:26 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:01:26 --> Model Class Initialized
INFO - 2016-06-08 19:01:26 --> Helper loaded: date_helper
INFO - 2016-06-08 19:01:26 --> Controller Class Initialized
INFO - 2016-06-08 19:01:26 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:01:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:01:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:01:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:01:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:01:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:01:26 --> Model Class Initialized
INFO - 2016-06-08 19:01:26 --> Form Validation Class Initialized
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 19:01:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:01:26 --> Final output sent to browser
DEBUG - 2016-06-08 19:01:26 --> Total execution time: 0.0669
INFO - 2016-06-08 19:01:50 --> Config Class Initialized
INFO - 2016-06-08 19:01:50 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:01:50 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:01:50 --> Utf8 Class Initialized
INFO - 2016-06-08 19:01:50 --> URI Class Initialized
INFO - 2016-06-08 19:01:50 --> Router Class Initialized
INFO - 2016-06-08 19:01:50 --> Output Class Initialized
INFO - 2016-06-08 19:01:50 --> Security Class Initialized
DEBUG - 2016-06-08 19:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:01:50 --> Input Class Initialized
INFO - 2016-06-08 19:01:50 --> Language Class Initialized
INFO - 2016-06-08 19:01:50 --> Loader Class Initialized
INFO - 2016-06-08 19:01:50 --> Helper loaded: form_helper
INFO - 2016-06-08 19:01:50 --> Database Driver Class Initialized
INFO - 2016-06-08 19:01:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:01:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:01:50 --> Email Class Initialized
INFO - 2016-06-08 19:01:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:01:50 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:01:50 --> Helper loaded: language_helper
INFO - 2016-06-08 19:01:50 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:01:50 --> Model Class Initialized
INFO - 2016-06-08 19:01:50 --> Helper loaded: date_helper
INFO - 2016-06-08 19:01:50 --> Controller Class Initialized
INFO - 2016-06-08 19:01:50 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:01:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:01:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:01:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:01:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:01:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:01:50 --> Model Class Initialized
INFO - 2016-06-08 19:01:50 --> Form Validation Class Initialized
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:01:50 --> Final output sent to browser
DEBUG - 2016-06-08 19:01:50 --> Total execution time: 0.0496
INFO - 2016-06-08 19:03:23 --> Config Class Initialized
INFO - 2016-06-08 19:03:23 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:03:23 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:03:23 --> Utf8 Class Initialized
INFO - 2016-06-08 19:03:23 --> URI Class Initialized
DEBUG - 2016-06-08 19:03:23 --> No URI present. Default controller set.
INFO - 2016-06-08 19:03:23 --> Router Class Initialized
INFO - 2016-06-08 19:03:23 --> Output Class Initialized
INFO - 2016-06-08 19:03:23 --> Security Class Initialized
DEBUG - 2016-06-08 19:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:03:23 --> Input Class Initialized
INFO - 2016-06-08 19:03:23 --> Language Class Initialized
INFO - 2016-06-08 19:03:23 --> Loader Class Initialized
INFO - 2016-06-08 19:03:23 --> Helper loaded: form_helper
INFO - 2016-06-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-06-08 19:03:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:03:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:03:23 --> Email Class Initialized
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:03:23 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:03:23 --> Helper loaded: language_helper
INFO - 2016-06-08 19:03:23 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:03:23 --> Model Class Initialized
INFO - 2016-06-08 19:03:23 --> Helper loaded: date_helper
INFO - 2016-06-08 19:03:23 --> Controller Class Initialized
INFO - 2016-06-08 19:03:23 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:03:23 --> Config Class Initialized
INFO - 2016-06-08 19:03:23 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:03:23 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:03:23 --> Utf8 Class Initialized
INFO - 2016-06-08 19:03:23 --> URI Class Initialized
INFO - 2016-06-08 19:03:23 --> Router Class Initialized
INFO - 2016-06-08 19:03:23 --> Output Class Initialized
INFO - 2016-06-08 19:03:23 --> Security Class Initialized
DEBUG - 2016-06-08 19:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:03:23 --> Input Class Initialized
INFO - 2016-06-08 19:03:23 --> Language Class Initialized
INFO - 2016-06-08 19:03:23 --> Loader Class Initialized
INFO - 2016-06-08 19:03:23 --> Helper loaded: form_helper
INFO - 2016-06-08 19:03:23 --> Database Driver Class Initialized
INFO - 2016-06-08 19:03:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:03:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:03:23 --> Email Class Initialized
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:03:23 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:03:23 --> Helper loaded: language_helper
INFO - 2016-06-08 19:03:23 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:03:23 --> Model Class Initialized
INFO - 2016-06-08 19:03:23 --> Helper loaded: date_helper
INFO - 2016-06-08 19:03:23 --> Controller Class Initialized
INFO - 2016-06-08 19:03:23 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:03:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:03:23 --> Model Class Initialized
INFO - 2016-06-08 19:03:23 --> Form Validation Class Initialized
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listaAcces.php
INFO - 2016-06-08 19:03:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:03:23 --> Final output sent to browser
DEBUG - 2016-06-08 19:03:23 --> Total execution time: 0.0215
INFO - 2016-06-08 19:12:13 --> Config Class Initialized
INFO - 2016-06-08 19:12:13 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:12:13 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:12:13 --> Utf8 Class Initialized
INFO - 2016-06-08 19:12:13 --> URI Class Initialized
INFO - 2016-06-08 19:12:13 --> Router Class Initialized
INFO - 2016-06-08 19:12:13 --> Output Class Initialized
INFO - 2016-06-08 19:12:13 --> Security Class Initialized
DEBUG - 2016-06-08 19:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:12:13 --> Input Class Initialized
INFO - 2016-06-08 19:12:13 --> Language Class Initialized
INFO - 2016-06-08 19:12:13 --> Loader Class Initialized
INFO - 2016-06-08 19:12:13 --> Helper loaded: form_helper
INFO - 2016-06-08 19:12:13 --> Database Driver Class Initialized
INFO - 2016-06-08 19:12:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:12:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:12:13 --> Email Class Initialized
INFO - 2016-06-08 19:12:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:12:13 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:12:13 --> Helper loaded: language_helper
INFO - 2016-06-08 19:12:13 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:12:13 --> Model Class Initialized
INFO - 2016-06-08 19:12:13 --> Helper loaded: date_helper
INFO - 2016-06-08 19:12:13 --> Controller Class Initialized
INFO - 2016-06-08 19:12:13 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:12:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:12:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:12:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:12:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:12:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:12:13 --> Model Class Initialized
INFO - 2016-06-08 19:12:13 --> Form Validation Class Initialized
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/listare_posturi.php
INFO - 2016-06-08 19:12:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:12:13 --> Final output sent to browser
DEBUG - 2016-06-08 19:12:13 --> Total execution time: 0.0648
INFO - 2016-06-08 19:12:24 --> Config Class Initialized
INFO - 2016-06-08 19:12:24 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:12:24 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:12:24 --> Utf8 Class Initialized
INFO - 2016-06-08 19:12:24 --> URI Class Initialized
INFO - 2016-06-08 19:12:24 --> Router Class Initialized
INFO - 2016-06-08 19:12:24 --> Output Class Initialized
INFO - 2016-06-08 19:12:24 --> Security Class Initialized
DEBUG - 2016-06-08 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:12:24 --> Input Class Initialized
INFO - 2016-06-08 19:12:24 --> Language Class Initialized
INFO - 2016-06-08 19:12:24 --> Loader Class Initialized
INFO - 2016-06-08 19:12:24 --> Helper loaded: form_helper
INFO - 2016-06-08 19:12:24 --> Database Driver Class Initialized
INFO - 2016-06-08 19:12:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:12:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:12:24 --> Email Class Initialized
INFO - 2016-06-08 19:12:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:12:24 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:12:24 --> Helper loaded: language_helper
INFO - 2016-06-08 19:12:24 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:12:24 --> Model Class Initialized
INFO - 2016-06-08 19:12:24 --> Helper loaded: date_helper
INFO - 2016-06-08 19:12:24 --> Controller Class Initialized
INFO - 2016-06-08 19:12:24 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:12:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:12:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:12:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:12:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:12:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:12:24 --> Model Class Initialized
INFO - 2016-06-08 19:12:24 --> Form Validation Class Initialized
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:12:24 --> Final output sent to browser
DEBUG - 2016-06-08 19:12:24 --> Total execution time: 0.0561
INFO - 2016-06-08 19:13:12 --> Config Class Initialized
INFO - 2016-06-08 19:13:12 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:13:12 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:13:12 --> Utf8 Class Initialized
INFO - 2016-06-08 19:13:12 --> URI Class Initialized
INFO - 2016-06-08 19:13:12 --> Router Class Initialized
INFO - 2016-06-08 19:13:12 --> Output Class Initialized
INFO - 2016-06-08 19:13:12 --> Security Class Initialized
DEBUG - 2016-06-08 19:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:13:12 --> Input Class Initialized
INFO - 2016-06-08 19:13:12 --> Language Class Initialized
INFO - 2016-06-08 19:13:12 --> Loader Class Initialized
INFO - 2016-06-08 19:13:12 --> Helper loaded: form_helper
INFO - 2016-06-08 19:13:12 --> Database Driver Class Initialized
INFO - 2016-06-08 19:13:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:13:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:13:12 --> Email Class Initialized
INFO - 2016-06-08 19:13:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:13:12 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:13:12 --> Helper loaded: language_helper
INFO - 2016-06-08 19:13:12 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:13:12 --> Model Class Initialized
INFO - 2016-06-08 19:13:12 --> Helper loaded: date_helper
INFO - 2016-06-08 19:13:12 --> Controller Class Initialized
INFO - 2016-06-08 19:13:12 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:13:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:13:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:13:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:13:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:13:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:13:12 --> Model Class Initialized
INFO - 2016-06-08 19:13:12 --> Form Validation Class Initialized
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:13:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:13:12 --> Final output sent to browser
DEBUG - 2016-06-08 19:13:12 --> Total execution time: 0.0606
INFO - 2016-06-08 19:13:26 --> Config Class Initialized
INFO - 2016-06-08 19:13:26 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:13:26 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:13:26 --> Utf8 Class Initialized
INFO - 2016-06-08 19:13:26 --> URI Class Initialized
INFO - 2016-06-08 19:13:26 --> Router Class Initialized
INFO - 2016-06-08 19:13:26 --> Output Class Initialized
INFO - 2016-06-08 19:13:26 --> Security Class Initialized
DEBUG - 2016-06-08 19:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:13:26 --> Input Class Initialized
INFO - 2016-06-08 19:13:26 --> Language Class Initialized
INFO - 2016-06-08 19:13:26 --> Loader Class Initialized
INFO - 2016-06-08 19:13:26 --> Helper loaded: form_helper
INFO - 2016-06-08 19:13:26 --> Database Driver Class Initialized
INFO - 2016-06-08 19:13:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:13:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:13:26 --> Email Class Initialized
INFO - 2016-06-08 19:13:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:13:26 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:13:26 --> Helper loaded: language_helper
INFO - 2016-06-08 19:13:26 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:13:26 --> Model Class Initialized
INFO - 2016-06-08 19:13:26 --> Helper loaded: date_helper
INFO - 2016-06-08 19:13:26 --> Controller Class Initialized
INFO - 2016-06-08 19:13:26 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:13:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:13:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:13:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:13:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:13:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:13:26 --> Model Class Initialized
INFO - 2016-06-08 19:13:26 --> Form Validation Class Initialized
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:13:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:13:26 --> Final output sent to browser
DEBUG - 2016-06-08 19:13:26 --> Total execution time: 0.0471
INFO - 2016-06-08 19:14:05 --> Config Class Initialized
INFO - 2016-06-08 19:14:05 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:14:05 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:14:05 --> Utf8 Class Initialized
INFO - 2016-06-08 19:14:05 --> URI Class Initialized
INFO - 2016-06-08 19:14:05 --> Router Class Initialized
INFO - 2016-06-08 19:14:05 --> Output Class Initialized
INFO - 2016-06-08 19:14:05 --> Security Class Initialized
DEBUG - 2016-06-08 19:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:14:05 --> Input Class Initialized
INFO - 2016-06-08 19:14:05 --> Language Class Initialized
INFO - 2016-06-08 19:14:05 --> Loader Class Initialized
INFO - 2016-06-08 19:14:05 --> Helper loaded: form_helper
INFO - 2016-06-08 19:14:05 --> Database Driver Class Initialized
INFO - 2016-06-08 19:14:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:14:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:14:05 --> Email Class Initialized
INFO - 2016-06-08 19:14:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:14:05 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:14:05 --> Helper loaded: language_helper
INFO - 2016-06-08 19:14:05 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:14:05 --> Model Class Initialized
INFO - 2016-06-08 19:14:05 --> Helper loaded: date_helper
INFO - 2016-06-08 19:14:05 --> Controller Class Initialized
INFO - 2016-06-08 19:14:05 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:14:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:14:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:14:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:14:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:14:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:14:05 --> Model Class Initialized
INFO - 2016-06-08 19:14:05 --> Form Validation Class Initialized
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:14:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:14:05 --> Final output sent to browser
DEBUG - 2016-06-08 19:14:05 --> Total execution time: 0.0517
INFO - 2016-06-08 19:15:02 --> Config Class Initialized
INFO - 2016-06-08 19:15:02 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:15:02 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:15:02 --> Utf8 Class Initialized
INFO - 2016-06-08 19:15:02 --> URI Class Initialized
INFO - 2016-06-08 19:15:02 --> Router Class Initialized
INFO - 2016-06-08 19:15:02 --> Output Class Initialized
INFO - 2016-06-08 19:15:02 --> Security Class Initialized
DEBUG - 2016-06-08 19:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:15:02 --> Input Class Initialized
INFO - 2016-06-08 19:15:02 --> Language Class Initialized
INFO - 2016-06-08 19:15:02 --> Loader Class Initialized
INFO - 2016-06-08 19:15:02 --> Helper loaded: form_helper
INFO - 2016-06-08 19:15:02 --> Database Driver Class Initialized
INFO - 2016-06-08 19:15:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:15:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:15:02 --> Email Class Initialized
INFO - 2016-06-08 19:15:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:15:02 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:15:02 --> Helper loaded: language_helper
INFO - 2016-06-08 19:15:02 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:15:02 --> Model Class Initialized
INFO - 2016-06-08 19:15:02 --> Helper loaded: date_helper
INFO - 2016-06-08 19:15:02 --> Controller Class Initialized
INFO - 2016-06-08 19:15:02 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:15:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:15:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:15:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:15:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:15:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:15:02 --> Model Class Initialized
INFO - 2016-06-08 19:15:02 --> Form Validation Class Initialized
INFO - 2016-06-08 19:15:26 --> Config Class Initialized
INFO - 2016-06-08 19:15:26 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:15:26 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:15:26 --> Utf8 Class Initialized
INFO - 2016-06-08 19:15:26 --> URI Class Initialized
INFO - 2016-06-08 19:15:26 --> Router Class Initialized
INFO - 2016-06-08 19:15:26 --> Output Class Initialized
INFO - 2016-06-08 19:15:26 --> Security Class Initialized
DEBUG - 2016-06-08 19:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:15:26 --> Input Class Initialized
INFO - 2016-06-08 19:15:26 --> Language Class Initialized
INFO - 2016-06-08 19:15:26 --> Loader Class Initialized
INFO - 2016-06-08 19:15:26 --> Helper loaded: form_helper
INFO - 2016-06-08 19:15:26 --> Database Driver Class Initialized
INFO - 2016-06-08 19:15:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:15:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:15:26 --> Email Class Initialized
INFO - 2016-06-08 19:15:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:15:26 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:15:26 --> Helper loaded: language_helper
INFO - 2016-06-08 19:15:26 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:15:26 --> Model Class Initialized
INFO - 2016-06-08 19:15:26 --> Helper loaded: date_helper
INFO - 2016-06-08 19:15:26 --> Controller Class Initialized
INFO - 2016-06-08 19:15:26 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:15:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:15:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:15:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:15:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:15:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:15:26 --> Model Class Initialized
INFO - 2016-06-08 19:15:26 --> Form Validation Class Initialized
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:15:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:15:26 --> Final output sent to browser
DEBUG - 2016-06-08 19:15:26 --> Total execution time: 0.0662
INFO - 2016-06-08 19:18:07 --> Config Class Initialized
INFO - 2016-06-08 19:18:07 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:18:07 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:18:07 --> Utf8 Class Initialized
INFO - 2016-06-08 19:18:07 --> URI Class Initialized
INFO - 2016-06-08 19:18:07 --> Router Class Initialized
INFO - 2016-06-08 19:18:07 --> Output Class Initialized
INFO - 2016-06-08 19:18:07 --> Security Class Initialized
DEBUG - 2016-06-08 19:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:18:07 --> Input Class Initialized
INFO - 2016-06-08 19:18:07 --> Language Class Initialized
INFO - 2016-06-08 19:18:07 --> Loader Class Initialized
INFO - 2016-06-08 19:18:07 --> Helper loaded: form_helper
INFO - 2016-06-08 19:18:07 --> Database Driver Class Initialized
INFO - 2016-06-08 19:18:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:18:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:18:07 --> Email Class Initialized
INFO - 2016-06-08 19:18:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:18:07 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:18:07 --> Helper loaded: language_helper
INFO - 2016-06-08 19:18:07 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:18:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:18:07 --> Model Class Initialized
INFO - 2016-06-08 19:18:07 --> Helper loaded: date_helper
INFO - 2016-06-08 19:18:07 --> Controller Class Initialized
INFO - 2016-06-08 19:18:07 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:18:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:18:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:18:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:18:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:18:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:18:07 --> Model Class Initialized
INFO - 2016-06-08 19:18:07 --> Form Validation Class Initialized
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-06-08 19:18:07 --> Severity: Notice --> Undefined index: content /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php 59
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:18:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:18:07 --> Final output sent to browser
DEBUG - 2016-06-08 19:18:07 --> Total execution time: 0.0649
INFO - 2016-06-08 19:18:38 --> Config Class Initialized
INFO - 2016-06-08 19:18:38 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:18:38 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:18:38 --> Utf8 Class Initialized
INFO - 2016-06-08 19:18:38 --> URI Class Initialized
INFO - 2016-06-08 19:18:38 --> Router Class Initialized
INFO - 2016-06-08 19:18:38 --> Output Class Initialized
INFO - 2016-06-08 19:18:38 --> Security Class Initialized
DEBUG - 2016-06-08 19:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:18:38 --> Input Class Initialized
INFO - 2016-06-08 19:18:38 --> Language Class Initialized
INFO - 2016-06-08 19:18:38 --> Loader Class Initialized
INFO - 2016-06-08 19:18:38 --> Helper loaded: form_helper
INFO - 2016-06-08 19:18:38 --> Database Driver Class Initialized
INFO - 2016-06-08 19:18:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:18:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:18:38 --> Email Class Initialized
INFO - 2016-06-08 19:18:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:18:38 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:18:38 --> Helper loaded: language_helper
INFO - 2016-06-08 19:18:38 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:18:38 --> Model Class Initialized
INFO - 2016-06-08 19:18:38 --> Helper loaded: date_helper
INFO - 2016-06-08 19:18:38 --> Controller Class Initialized
INFO - 2016-06-08 19:18:38 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:18:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:18:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:18:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:18:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:18:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:18:38 --> Model Class Initialized
INFO - 2016-06-08 19:18:38 --> Form Validation Class Initialized
INFO - 2016-06-08 19:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:18:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:18:55 --> Config Class Initialized
INFO - 2016-06-08 19:18:55 --> Hooks Class Initialized
DEBUG - 2016-06-08 19:18:55 --> UTF-8 Support Enabled
INFO - 2016-06-08 19:18:55 --> Utf8 Class Initialized
INFO - 2016-06-08 19:18:55 --> URI Class Initialized
INFO - 2016-06-08 19:18:55 --> Router Class Initialized
INFO - 2016-06-08 19:18:55 --> Output Class Initialized
INFO - 2016-06-08 19:18:55 --> Security Class Initialized
DEBUG - 2016-06-08 19:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-08 19:18:55 --> Input Class Initialized
INFO - 2016-06-08 19:18:55 --> Language Class Initialized
INFO - 2016-06-08 19:18:55 --> Loader Class Initialized
INFO - 2016-06-08 19:18:55 --> Helper loaded: form_helper
INFO - 2016-06-08 19:18:55 --> Database Driver Class Initialized
INFO - 2016-06-08 19:18:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-08 19:18:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-08 19:18:55 --> Email Class Initialized
INFO - 2016-06-08 19:18:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-08 19:18:55 --> Helper loaded: cookie_helper
INFO - 2016-06-08 19:18:55 --> Helper loaded: language_helper
INFO - 2016-06-08 19:18:55 --> Helper loaded: url_helper
DEBUG - 2016-06-08 19:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-08 19:18:55 --> Model Class Initialized
INFO - 2016-06-08 19:18:55 --> Helper loaded: date_helper
INFO - 2016-06-08 19:18:55 --> Controller Class Initialized
INFO - 2016-06-08 19:18:55 --> Helper loaded: languages_helper
INFO - 2016-06-08 19:18:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-08 19:18:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-08 19:18:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-08 19:18:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-08 19:18:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-08 19:18:55 --> Model Class Initialized
INFO - 2016-06-08 19:18:55 --> Form Validation Class Initialized
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/lista_utilizatori.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/list_posts.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/add_post.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_post.php
INFO - 2016-06-08 19:18:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-08 19:18:55 --> Final output sent to browser
DEBUG - 2016-06-08 19:18:55 --> Total execution time: 0.0632
