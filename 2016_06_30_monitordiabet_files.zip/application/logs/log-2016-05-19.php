<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-19 10:57:36 --> Config Class Initialized
INFO - 2016-05-19 10:57:36 --> Hooks Class Initialized
DEBUG - 2016-05-19 10:57:37 --> UTF-8 Support Enabled
INFO - 2016-05-19 10:57:37 --> Utf8 Class Initialized
INFO - 2016-05-19 10:57:37 --> URI Class Initialized
INFO - 2016-05-19 10:57:37 --> Router Class Initialized
INFO - 2016-05-19 10:57:37 --> Output Class Initialized
INFO - 2016-05-19 10:57:37 --> Security Class Initialized
DEBUG - 2016-05-19 10:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 10:57:37 --> CSRF cookie sent
INFO - 2016-05-19 10:57:37 --> Input Class Initialized
INFO - 2016-05-19 10:57:37 --> Language Class Initialized
INFO - 2016-05-19 10:57:37 --> Loader Class Initialized
INFO - 2016-05-19 10:57:37 --> Helper loaded: form_helper
INFO - 2016-05-19 10:57:37 --> Database Driver Class Initialized
INFO - 2016-05-19 10:57:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 10:57:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 10:57:38 --> Email Class Initialized
INFO - 2016-05-19 10:57:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 10:57:38 --> Helper loaded: cookie_helper
INFO - 2016-05-19 10:57:39 --> Helper loaded: language_helper
INFO - 2016-05-19 10:57:39 --> Helper loaded: url_helper
DEBUG - 2016-05-19 10:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 10:57:39 --> Model Class Initialized
INFO - 2016-05-19 10:57:39 --> Helper loaded: date_helper
INFO - 2016-05-19 10:57:39 --> Controller Class Initialized
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 10:57:39 --> Model Class Initialized
INFO - 2016-05-19 10:57:39 --> Config Class Initialized
INFO - 2016-05-19 10:57:39 --> Hooks Class Initialized
DEBUG - 2016-05-19 10:57:39 --> UTF-8 Support Enabled
INFO - 2016-05-19 10:57:39 --> Utf8 Class Initialized
INFO - 2016-05-19 10:57:39 --> URI Class Initialized
INFO - 2016-05-19 10:57:39 --> Router Class Initialized
INFO - 2016-05-19 10:57:39 --> Output Class Initialized
INFO - 2016-05-19 10:57:39 --> Security Class Initialized
DEBUG - 2016-05-19 10:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 10:57:39 --> CSRF cookie sent
INFO - 2016-05-19 10:57:39 --> Input Class Initialized
INFO - 2016-05-19 10:57:39 --> Language Class Initialized
INFO - 2016-05-19 10:57:39 --> Loader Class Initialized
INFO - 2016-05-19 10:57:39 --> Helper loaded: form_helper
INFO - 2016-05-19 10:57:39 --> Database Driver Class Initialized
INFO - 2016-05-19 10:57:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 10:57:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 10:57:39 --> Email Class Initialized
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 10:57:39 --> Helper loaded: cookie_helper
INFO - 2016-05-19 10:57:39 --> Helper loaded: language_helper
INFO - 2016-05-19 10:57:39 --> Helper loaded: url_helper
DEBUG - 2016-05-19 10:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 10:57:39 --> Model Class Initialized
INFO - 2016-05-19 10:57:39 --> Helper loaded: date_helper
INFO - 2016-05-19 10:57:39 --> Controller Class Initialized
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 10:57:39 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 10:57:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 10:57:39 --> Form Validation Class Initialized
ERROR - 2016-05-19 10:57:39 --> Severity: Notice --> Undefined property: Auth::$callType /home/demis/www/platformadiabet/application/core/SVS_Controller.php 115
INFO - 2016-05-19 10:57:40 --> Helper loaded: languages_helper
INFO - 2016-05-19 10:57:40 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-19 10:57:40 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-19 10:57:40 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-19 10:57:40 --> Final output sent to browser
DEBUG - 2016-05-19 10:57:40 --> Total execution time: 0.6191
INFO - 2016-05-19 10:57:42 --> Config Class Initialized
INFO - 2016-05-19 10:57:42 --> Hooks Class Initialized
DEBUG - 2016-05-19 10:57:42 --> UTF-8 Support Enabled
INFO - 2016-05-19 10:57:42 --> Utf8 Class Initialized
INFO - 2016-05-19 10:57:42 --> URI Class Initialized
INFO - 2016-05-19 10:57:42 --> Router Class Initialized
INFO - 2016-05-19 10:57:42 --> Output Class Initialized
INFO - 2016-05-19 10:57:42 --> Security Class Initialized
DEBUG - 2016-05-19 10:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 10:57:42 --> CSRF cookie sent
INFO - 2016-05-19 10:57:42 --> Input Class Initialized
INFO - 2016-05-19 10:57:42 --> Language Class Initialized
ERROR - 2016-05-19 10:57:42 --> 404 Page Not Found: Faviconico/index
INFO - 2016-05-19 11:06:43 --> Config Class Initialized
INFO - 2016-05-19 11:06:43 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:06:43 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:06:43 --> Utf8 Class Initialized
INFO - 2016-05-19 11:06:43 --> URI Class Initialized
INFO - 2016-05-19 11:06:43 --> Router Class Initialized
INFO - 2016-05-19 11:06:43 --> Output Class Initialized
INFO - 2016-05-19 11:06:43 --> Security Class Initialized
DEBUG - 2016-05-19 11:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:06:43 --> CSRF cookie sent
INFO - 2016-05-19 11:06:43 --> CSRF token verified
INFO - 2016-05-19 11:06:43 --> Input Class Initialized
INFO - 2016-05-19 11:06:43 --> Language Class Initialized
INFO - 2016-05-19 11:06:43 --> Loader Class Initialized
INFO - 2016-05-19 11:06:43 --> Helper loaded: form_helper
INFO - 2016-05-19 11:06:43 --> Database Driver Class Initialized
INFO - 2016-05-19 11:06:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:06:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:06:43 --> Email Class Initialized
INFO - 2016-05-19 11:06:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:06:43 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:06:43 --> Helper loaded: language_helper
INFO - 2016-05-19 11:06:43 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:06:43 --> Model Class Initialized
INFO - 2016-05-19 11:06:43 --> Helper loaded: date_helper
INFO - 2016-05-19 11:06:43 --> Controller Class Initialized
INFO - 2016-05-19 11:06:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:06:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:06:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:06:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:06:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 11:06:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:06:43 --> Form Validation Class Initialized
INFO - 2016-05-19 11:06:44 --> Config Class Initialized
INFO - 2016-05-19 11:06:44 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:06:44 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:06:44 --> Utf8 Class Initialized
INFO - 2016-05-19 11:06:44 --> URI Class Initialized
DEBUG - 2016-05-19 11:06:44 --> No URI present. Default controller set.
INFO - 2016-05-19 11:06:44 --> Router Class Initialized
INFO - 2016-05-19 11:06:44 --> Output Class Initialized
INFO - 2016-05-19 11:06:44 --> Security Class Initialized
DEBUG - 2016-05-19 11:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:06:44 --> CSRF cookie sent
INFO - 2016-05-19 11:06:44 --> Input Class Initialized
INFO - 2016-05-19 11:06:44 --> Language Class Initialized
INFO - 2016-05-19 11:06:44 --> Loader Class Initialized
INFO - 2016-05-19 11:06:44 --> Helper loaded: form_helper
INFO - 2016-05-19 11:06:44 --> Database Driver Class Initialized
INFO - 2016-05-19 11:06:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:06:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:06:44 --> Email Class Initialized
INFO - 2016-05-19 11:06:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:06:44 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:06:44 --> Helper loaded: language_helper
INFO - 2016-05-19 11:06:44 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:06:44 --> Model Class Initialized
INFO - 2016-05-19 11:06:44 --> Helper loaded: date_helper
INFO - 2016-05-19 11:06:44 --> Controller Class Initialized
INFO - 2016-05-19 11:06:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:06:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:06:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:06:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:06:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:06:45 --> Config Class Initialized
INFO - 2016-05-19 11:06:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:06:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:06:45 --> Utf8 Class Initialized
INFO - 2016-05-19 11:06:45 --> URI Class Initialized
INFO - 2016-05-19 11:06:45 --> Router Class Initialized
INFO - 2016-05-19 11:06:45 --> Output Class Initialized
INFO - 2016-05-19 11:06:45 --> Security Class Initialized
DEBUG - 2016-05-19 11:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:06:45 --> CSRF cookie sent
INFO - 2016-05-19 11:06:45 --> Input Class Initialized
INFO - 2016-05-19 11:06:45 --> Language Class Initialized
INFO - 2016-05-19 11:06:45 --> Loader Class Initialized
INFO - 2016-05-19 11:06:45 --> Helper loaded: form_helper
INFO - 2016-05-19 11:06:45 --> Database Driver Class Initialized
INFO - 2016-05-19 11:06:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:06:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:06:45 --> Email Class Initialized
INFO - 2016-05-19 11:06:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:06:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:06:45 --> Helper loaded: language_helper
INFO - 2016-05-19 11:06:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:06:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:06:45 --> Model Class Initialized
INFO - 2016-05-19 11:06:45 --> Helper loaded: date_helper
INFO - 2016-05-19 11:06:45 --> Controller Class Initialized
INFO - 2016-05-19 11:06:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:06:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:06:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:06:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:06:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:06:45 --> Model Class Initialized
INFO - 2016-05-19 11:06:45 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:06:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:06:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 11:06:45 --> Severity: Notice --> Undefined variable: csrf /home/demis/www/platformadiabet/application/views/user_area/home.php 43
INFO - 2016-05-19 11:06:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 11:06:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:06:45 --> Final output sent to browser
DEBUG - 2016-05-19 11:06:45 --> Total execution time: 0.0857
INFO - 2016-05-19 11:08:38 --> Config Class Initialized
INFO - 2016-05-19 11:08:38 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:08:38 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:08:38 --> Utf8 Class Initialized
INFO - 2016-05-19 11:08:38 --> URI Class Initialized
INFO - 2016-05-19 11:08:38 --> Router Class Initialized
INFO - 2016-05-19 11:08:38 --> Output Class Initialized
INFO - 2016-05-19 11:08:38 --> Security Class Initialized
DEBUG - 2016-05-19 11:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:08:38 --> CSRF cookie sent
INFO - 2016-05-19 11:08:38 --> Input Class Initialized
INFO - 2016-05-19 11:08:38 --> Language Class Initialized
INFO - 2016-05-19 11:08:38 --> Loader Class Initialized
INFO - 2016-05-19 11:08:38 --> Helper loaded: form_helper
INFO - 2016-05-19 11:08:38 --> Database Driver Class Initialized
INFO - 2016-05-19 11:08:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:08:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:08:38 --> Email Class Initialized
INFO - 2016-05-19 11:08:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:08:38 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:08:38 --> Helper loaded: language_helper
INFO - 2016-05-19 11:08:38 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:08:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:08:38 --> Model Class Initialized
INFO - 2016-05-19 11:08:38 --> Helper loaded: date_helper
INFO - 2016-05-19 11:08:38 --> Controller Class Initialized
INFO - 2016-05-19 11:08:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:08:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:08:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:08:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:08:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:08:38 --> Model Class Initialized
INFO - 2016-05-19 11:08:38 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:08:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:08:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 11:08:38 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/views/user_area/access.php 26
INFO - 2016-05-19 11:11:30 --> Config Class Initialized
INFO - 2016-05-19 11:11:30 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:11:30 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:11:30 --> Utf8 Class Initialized
INFO - 2016-05-19 11:11:30 --> URI Class Initialized
INFO - 2016-05-19 11:11:30 --> Router Class Initialized
INFO - 2016-05-19 11:11:30 --> Output Class Initialized
INFO - 2016-05-19 11:11:30 --> Security Class Initialized
DEBUG - 2016-05-19 11:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:11:30 --> CSRF cookie sent
INFO - 2016-05-19 11:11:30 --> Input Class Initialized
INFO - 2016-05-19 11:11:30 --> Language Class Initialized
INFO - 2016-05-19 11:11:30 --> Loader Class Initialized
INFO - 2016-05-19 11:11:30 --> Helper loaded: form_helper
INFO - 2016-05-19 11:11:30 --> Database Driver Class Initialized
INFO - 2016-05-19 11:11:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:11:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:11:30 --> Email Class Initialized
INFO - 2016-05-19 11:11:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:11:30 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:11:30 --> Helper loaded: language_helper
INFO - 2016-05-19 11:11:30 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:11:30 --> Model Class Initialized
INFO - 2016-05-19 11:11:30 --> Helper loaded: date_helper
INFO - 2016-05-19 11:11:30 --> Controller Class Initialized
INFO - 2016-05-19 11:11:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:11:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:11:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:11:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:11:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:11:30 --> Model Class Initialized
INFO - 2016-05-19 11:11:30 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:11:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:11:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 11:11:30 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/views/user_area/access.php 20
INFO - 2016-05-19 11:11:50 --> Config Class Initialized
INFO - 2016-05-19 11:11:50 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:11:50 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:11:50 --> Utf8 Class Initialized
INFO - 2016-05-19 11:11:50 --> URI Class Initialized
INFO - 2016-05-19 11:11:50 --> Router Class Initialized
INFO - 2016-05-19 11:11:50 --> Output Class Initialized
INFO - 2016-05-19 11:11:50 --> Security Class Initialized
DEBUG - 2016-05-19 11:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:11:50 --> CSRF cookie sent
INFO - 2016-05-19 11:11:50 --> Input Class Initialized
INFO - 2016-05-19 11:11:50 --> Language Class Initialized
INFO - 2016-05-19 11:11:50 --> Loader Class Initialized
INFO - 2016-05-19 11:11:50 --> Helper loaded: form_helper
INFO - 2016-05-19 11:11:50 --> Database Driver Class Initialized
INFO - 2016-05-19 11:11:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:11:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:11:50 --> Email Class Initialized
INFO - 2016-05-19 11:11:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:11:50 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:11:50 --> Helper loaded: language_helper
INFO - 2016-05-19 11:11:50 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:11:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:11:50 --> Model Class Initialized
INFO - 2016-05-19 11:11:50 --> Helper loaded: date_helper
INFO - 2016-05-19 11:11:50 --> Controller Class Initialized
INFO - 2016-05-19 11:11:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:11:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:11:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:11:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:11:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:11:50 --> Model Class Initialized
INFO - 2016-05-19 11:11:50 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:11:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:11:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 11:11:50 --> Severity: Notice --> Undefined variable: csrf /home/demis/www/platformadiabet/application/views/user_area/access.php 21
INFO - 2016-05-19 11:11:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:11:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:11:50 --> Final output sent to browser
DEBUG - 2016-05-19 11:11:50 --> Total execution time: 0.0469
INFO - 2016-05-19 11:12:27 --> Config Class Initialized
INFO - 2016-05-19 11:12:27 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:12:27 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:12:27 --> Utf8 Class Initialized
INFO - 2016-05-19 11:12:27 --> URI Class Initialized
INFO - 2016-05-19 11:12:27 --> Router Class Initialized
INFO - 2016-05-19 11:12:27 --> Output Class Initialized
INFO - 2016-05-19 11:12:27 --> Security Class Initialized
DEBUG - 2016-05-19 11:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:12:27 --> CSRF cookie sent
INFO - 2016-05-19 11:12:27 --> Input Class Initialized
INFO - 2016-05-19 11:12:27 --> Language Class Initialized
INFO - 2016-05-19 11:12:27 --> Loader Class Initialized
INFO - 2016-05-19 11:12:27 --> Helper loaded: form_helper
INFO - 2016-05-19 11:12:27 --> Database Driver Class Initialized
INFO - 2016-05-19 11:12:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:12:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:12:27 --> Email Class Initialized
INFO - 2016-05-19 11:12:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:12:27 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:12:27 --> Helper loaded: language_helper
INFO - 2016-05-19 11:12:27 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:12:27 --> Model Class Initialized
INFO - 2016-05-19 11:12:27 --> Helper loaded: date_helper
INFO - 2016-05-19 11:12:27 --> Controller Class Initialized
INFO - 2016-05-19 11:12:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:12:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:12:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:12:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:12:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:12:27 --> Model Class Initialized
INFO - 2016-05-19 11:12:27 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:12:27 --> Final output sent to browser
DEBUG - 2016-05-19 11:12:27 --> Total execution time: 0.0226
INFO - 2016-05-19 11:19:09 --> Config Class Initialized
INFO - 2016-05-19 11:19:09 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:19:09 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:19:09 --> Utf8 Class Initialized
INFO - 2016-05-19 11:19:09 --> URI Class Initialized
INFO - 2016-05-19 11:19:09 --> Router Class Initialized
INFO - 2016-05-19 11:19:09 --> Output Class Initialized
INFO - 2016-05-19 11:19:09 --> Security Class Initialized
DEBUG - 2016-05-19 11:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:19:09 --> CSRF cookie sent
INFO - 2016-05-19 11:19:09 --> Input Class Initialized
INFO - 2016-05-19 11:19:09 --> Language Class Initialized
INFO - 2016-05-19 11:19:09 --> Loader Class Initialized
INFO - 2016-05-19 11:19:09 --> Helper loaded: form_helper
INFO - 2016-05-19 11:19:09 --> Database Driver Class Initialized
INFO - 2016-05-19 11:19:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:19:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:19:11 --> Email Class Initialized
INFO - 2016-05-19 11:19:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:19:11 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:19:11 --> Helper loaded: language_helper
INFO - 2016-05-19 11:19:11 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:19:11 --> Model Class Initialized
INFO - 2016-05-19 11:19:11 --> Helper loaded: date_helper
INFO - 2016-05-19 11:19:11 --> Controller Class Initialized
INFO - 2016-05-19 11:19:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:19:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:19:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:19:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:19:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:19:11 --> Model Class Initialized
INFO - 2016-05-19 11:19:12 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:19:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:19:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 11:19:12 --> Severity: Notice --> Undefined variable: select_time /home/demis/www/platformadiabet/application/views/user_area/access.php 19
INFO - 2016-05-19 11:19:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:19:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:19:12 --> Final output sent to browser
DEBUG - 2016-05-19 11:19:12 --> Total execution time: 3.6529
INFO - 2016-05-19 11:19:20 --> Config Class Initialized
INFO - 2016-05-19 11:19:20 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:19:20 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:19:20 --> Utf8 Class Initialized
INFO - 2016-05-19 11:19:20 --> URI Class Initialized
INFO - 2016-05-19 11:19:20 --> Router Class Initialized
INFO - 2016-05-19 11:19:20 --> Output Class Initialized
INFO - 2016-05-19 11:19:20 --> Security Class Initialized
DEBUG - 2016-05-19 11:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:19:20 --> CSRF cookie sent
INFO - 2016-05-19 11:19:20 --> Input Class Initialized
INFO - 2016-05-19 11:19:20 --> Language Class Initialized
INFO - 2016-05-19 11:19:20 --> Loader Class Initialized
INFO - 2016-05-19 11:19:20 --> Helper loaded: form_helper
INFO - 2016-05-19 11:19:20 --> Database Driver Class Initialized
INFO - 2016-05-19 11:19:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:19:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:19:20 --> Email Class Initialized
INFO - 2016-05-19 11:19:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:19:20 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:19:20 --> Helper loaded: language_helper
INFO - 2016-05-19 11:19:20 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:19:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:19:20 --> Model Class Initialized
INFO - 2016-05-19 11:19:20 --> Helper loaded: date_helper
INFO - 2016-05-19 11:19:20 --> Controller Class Initialized
INFO - 2016-05-19 11:19:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:19:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:19:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:19:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:19:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:19:20 --> Model Class Initialized
INFO - 2016-05-19 11:19:20 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:19:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:19:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:19:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:19:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:19:20 --> Final output sent to browser
DEBUG - 2016-05-19 11:19:20 --> Total execution time: 0.1070
INFO - 2016-05-19 11:19:50 --> Config Class Initialized
INFO - 2016-05-19 11:19:50 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:19:50 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:19:50 --> Utf8 Class Initialized
INFO - 2016-05-19 11:19:50 --> URI Class Initialized
INFO - 2016-05-19 11:19:50 --> Router Class Initialized
INFO - 2016-05-19 11:19:50 --> Output Class Initialized
INFO - 2016-05-19 11:19:50 --> Security Class Initialized
DEBUG - 2016-05-19 11:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:19:50 --> CSRF cookie sent
INFO - 2016-05-19 11:19:50 --> Input Class Initialized
INFO - 2016-05-19 11:19:50 --> Language Class Initialized
INFO - 2016-05-19 11:19:50 --> Loader Class Initialized
INFO - 2016-05-19 11:19:50 --> Helper loaded: form_helper
INFO - 2016-05-19 11:19:50 --> Database Driver Class Initialized
INFO - 2016-05-19 11:19:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:19:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:19:50 --> Email Class Initialized
INFO - 2016-05-19 11:19:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:19:50 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:19:50 --> Helper loaded: language_helper
INFO - 2016-05-19 11:19:50 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:19:50 --> Model Class Initialized
INFO - 2016-05-19 11:19:50 --> Helper loaded: date_helper
INFO - 2016-05-19 11:19:50 --> Controller Class Initialized
INFO - 2016-05-19 11:19:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:19:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:19:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:19:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:19:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:19:50 --> Model Class Initialized
INFO - 2016-05-19 11:19:50 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:19:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:19:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:19:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:19:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:19:50 --> Final output sent to browser
DEBUG - 2016-05-19 11:19:50 --> Total execution time: 0.0684
INFO - 2016-05-19 11:35:28 --> Config Class Initialized
INFO - 2016-05-19 11:35:28 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:35:28 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:35:28 --> Utf8 Class Initialized
INFO - 2016-05-19 11:35:28 --> URI Class Initialized
INFO - 2016-05-19 11:35:28 --> Router Class Initialized
INFO - 2016-05-19 11:35:28 --> Output Class Initialized
INFO - 2016-05-19 11:35:28 --> Security Class Initialized
DEBUG - 2016-05-19 11:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:35:28 --> CSRF cookie sent
INFO - 2016-05-19 11:35:28 --> Input Class Initialized
INFO - 2016-05-19 11:35:28 --> Language Class Initialized
INFO - 2016-05-19 11:35:28 --> Loader Class Initialized
INFO - 2016-05-19 11:35:28 --> Helper loaded: form_helper
INFO - 2016-05-19 11:35:28 --> Database Driver Class Initialized
INFO - 2016-05-19 11:35:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:35:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:35:28 --> Email Class Initialized
INFO - 2016-05-19 11:35:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:35:28 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:35:28 --> Helper loaded: language_helper
INFO - 2016-05-19 11:35:28 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:35:28 --> Model Class Initialized
INFO - 2016-05-19 11:35:28 --> Helper loaded: date_helper
INFO - 2016-05-19 11:35:28 --> Controller Class Initialized
INFO - 2016-05-19 11:35:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:35:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:35:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:35:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:35:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:35:28 --> Model Class Initialized
INFO - 2016-05-19 11:35:28 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:35:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:35:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:35:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:35:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:35:28 --> Final output sent to browser
DEBUG - 2016-05-19 11:35:28 --> Total execution time: 0.0585
INFO - 2016-05-19 11:36:54 --> Config Class Initialized
INFO - 2016-05-19 11:36:54 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:36:54 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:36:54 --> Utf8 Class Initialized
INFO - 2016-05-19 11:36:54 --> URI Class Initialized
INFO - 2016-05-19 11:36:54 --> Router Class Initialized
INFO - 2016-05-19 11:36:54 --> Output Class Initialized
INFO - 2016-05-19 11:36:54 --> Security Class Initialized
DEBUG - 2016-05-19 11:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:36:54 --> CSRF cookie sent
INFO - 2016-05-19 11:36:54 --> Input Class Initialized
INFO - 2016-05-19 11:36:54 --> Language Class Initialized
INFO - 2016-05-19 11:36:54 --> Loader Class Initialized
INFO - 2016-05-19 11:36:54 --> Helper loaded: form_helper
INFO - 2016-05-19 11:36:54 --> Database Driver Class Initialized
INFO - 2016-05-19 11:36:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:36:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:36:55 --> Email Class Initialized
INFO - 2016-05-19 11:36:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:36:55 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:36:55 --> Helper loaded: language_helper
INFO - 2016-05-19 11:36:55 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:36:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:36:55 --> Model Class Initialized
INFO - 2016-05-19 11:36:55 --> Helper loaded: date_helper
INFO - 2016-05-19 11:36:55 --> Controller Class Initialized
INFO - 2016-05-19 11:36:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:36:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:36:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:36:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:36:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:36:55 --> Model Class Initialized
INFO - 2016-05-19 11:36:55 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:36:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:36:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:36:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:36:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:36:55 --> Final output sent to browser
DEBUG - 2016-05-19 11:36:55 --> Total execution time: 0.1518
INFO - 2016-05-19 11:37:59 --> Config Class Initialized
INFO - 2016-05-19 11:37:59 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:37:59 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:37:59 --> Utf8 Class Initialized
INFO - 2016-05-19 11:37:59 --> URI Class Initialized
INFO - 2016-05-19 11:37:59 --> Router Class Initialized
INFO - 2016-05-19 11:37:59 --> Output Class Initialized
INFO - 2016-05-19 11:37:59 --> Security Class Initialized
DEBUG - 2016-05-19 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:37:59 --> CSRF cookie sent
INFO - 2016-05-19 11:37:59 --> CSRF token verified
INFO - 2016-05-19 11:37:59 --> Input Class Initialized
INFO - 2016-05-19 11:37:59 --> Language Class Initialized
INFO - 2016-05-19 11:37:59 --> Loader Class Initialized
INFO - 2016-05-19 11:37:59 --> Helper loaded: form_helper
INFO - 2016-05-19 11:37:59 --> Database Driver Class Initialized
INFO - 2016-05-19 11:37:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:37:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:37:59 --> Email Class Initialized
INFO - 2016-05-19 11:37:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:37:59 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:37:59 --> Helper loaded: language_helper
INFO - 2016-05-19 11:37:59 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:37:59 --> Model Class Initialized
INFO - 2016-05-19 11:37:59 --> Helper loaded: date_helper
INFO - 2016-05-19 11:37:59 --> Controller Class Initialized
INFO - 2016-05-19 11:37:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:37:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:37:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:37:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:37:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:37:59 --> Config Class Initialized
INFO - 2016-05-19 11:37:59 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:37:59 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:37:59 --> Utf8 Class Initialized
INFO - 2016-05-19 11:37:59 --> URI Class Initialized
INFO - 2016-05-19 11:37:59 --> Router Class Initialized
INFO - 2016-05-19 11:37:59 --> Output Class Initialized
INFO - 2016-05-19 11:37:59 --> Security Class Initialized
DEBUG - 2016-05-19 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:37:59 --> CSRF cookie sent
INFO - 2016-05-19 11:37:59 --> Input Class Initialized
INFO - 2016-05-19 11:37:59 --> Language Class Initialized
INFO - 2016-05-19 11:37:59 --> Loader Class Initialized
INFO - 2016-05-19 11:37:59 --> Helper loaded: form_helper
INFO - 2016-05-19 11:37:59 --> Database Driver Class Initialized
INFO - 2016-05-19 11:37:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:37:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:37:59 --> Email Class Initialized
INFO - 2016-05-19 11:37:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:37:59 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:37:59 --> Helper loaded: language_helper
INFO - 2016-05-19 11:37:59 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:37:59 --> Model Class Initialized
INFO - 2016-05-19 11:37:59 --> Helper loaded: date_helper
INFO - 2016-05-19 11:37:59 --> Controller Class Initialized
INFO - 2016-05-19 11:38:06 --> Config Class Initialized
INFO - 2016-05-19 11:38:06 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:38:06 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:38:06 --> Utf8 Class Initialized
INFO - 2016-05-19 11:38:06 --> URI Class Initialized
INFO - 2016-05-19 11:38:06 --> Router Class Initialized
INFO - 2016-05-19 11:38:06 --> Output Class Initialized
INFO - 2016-05-19 11:38:06 --> Security Class Initialized
DEBUG - 2016-05-19 11:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:38:06 --> CSRF cookie sent
INFO - 2016-05-19 11:38:06 --> Input Class Initialized
INFO - 2016-05-19 11:38:06 --> Language Class Initialized
INFO - 2016-05-19 11:38:06 --> Loader Class Initialized
INFO - 2016-05-19 11:38:06 --> Helper loaded: form_helper
INFO - 2016-05-19 11:38:06 --> Database Driver Class Initialized
INFO - 2016-05-19 11:38:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:38:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:38:06 --> Email Class Initialized
INFO - 2016-05-19 11:38:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:38:06 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:38:06 --> Helper loaded: language_helper
INFO - 2016-05-19 11:38:06 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:38:06 --> Model Class Initialized
INFO - 2016-05-19 11:38:06 --> Helper loaded: date_helper
INFO - 2016-05-19 11:38:06 --> Controller Class Initialized
INFO - 2016-05-19 11:38:06 --> Model Class Initialized
INFO - 2016-05-19 11:38:06 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:38:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_hello_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_dashboard_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_access_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_informations_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_logout_label"
INFO - 2016-05-19 11:38:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_access_add_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_select_person_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_doctor_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_family_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_email_address_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_name_token_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_type_token_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_save_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_access_added_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_number_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_token_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_name_token_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_email_address_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_type_token_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_action_label"
ERROR - 2016-05-19 11:38:06 --> Could not find the language line "dashboard_action_delete_label"
INFO - 2016-05-19 11:38:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:38:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:38:06 --> Final output sent to browser
DEBUG - 2016-05-19 11:38:06 --> Total execution time: 0.0484
INFO - 2016-05-19 11:38:10 --> Config Class Initialized
INFO - 2016-05-19 11:38:10 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:38:10 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:38:10 --> Utf8 Class Initialized
INFO - 2016-05-19 11:38:10 --> URI Class Initialized
INFO - 2016-05-19 11:38:10 --> Router Class Initialized
INFO - 2016-05-19 11:38:10 --> Output Class Initialized
INFO - 2016-05-19 11:38:10 --> Security Class Initialized
DEBUG - 2016-05-19 11:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:38:10 --> CSRF cookie sent
INFO - 2016-05-19 11:38:10 --> CSRF token verified
INFO - 2016-05-19 11:38:10 --> Input Class Initialized
INFO - 2016-05-19 11:38:10 --> Language Class Initialized
INFO - 2016-05-19 11:38:10 --> Loader Class Initialized
INFO - 2016-05-19 11:38:10 --> Helper loaded: form_helper
INFO - 2016-05-19 11:38:10 --> Database Driver Class Initialized
INFO - 2016-05-19 11:38:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:38:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:38:10 --> Email Class Initialized
INFO - 2016-05-19 11:38:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:38:10 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:38:10 --> Helper loaded: language_helper
INFO - 2016-05-19 11:38:10 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:38:10 --> Model Class Initialized
INFO - 2016-05-19 11:38:10 --> Helper loaded: date_helper
INFO - 2016-05-19 11:38:10 --> Controller Class Initialized
INFO - 2016-05-19 11:38:10 --> Config Class Initialized
INFO - 2016-05-19 11:38:10 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:38:10 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:38:10 --> Utf8 Class Initialized
INFO - 2016-05-19 11:38:10 --> URI Class Initialized
INFO - 2016-05-19 11:38:10 --> Router Class Initialized
INFO - 2016-05-19 11:38:10 --> Output Class Initialized
INFO - 2016-05-19 11:38:10 --> Security Class Initialized
DEBUG - 2016-05-19 11:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:38:10 --> CSRF cookie sent
INFO - 2016-05-19 11:38:10 --> Input Class Initialized
INFO - 2016-05-19 11:38:10 --> Language Class Initialized
INFO - 2016-05-19 11:38:10 --> Loader Class Initialized
INFO - 2016-05-19 11:38:10 --> Helper loaded: form_helper
INFO - 2016-05-19 11:38:10 --> Database Driver Class Initialized
INFO - 2016-05-19 11:38:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:38:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:38:10 --> Email Class Initialized
INFO - 2016-05-19 11:38:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:38:10 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:38:10 --> Helper loaded: language_helper
INFO - 2016-05-19 11:38:10 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:38:10 --> Model Class Initialized
INFO - 2016-05-19 11:38:10 --> Helper loaded: date_helper
INFO - 2016-05-19 11:38:10 --> Controller Class Initialized
INFO - 2016-05-19 11:38:10 --> Model Class Initialized
INFO - 2016-05-19 11:38:10 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:38:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_hello_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_dashboard_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_access_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_informations_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_logout_label"
INFO - 2016-05-19 11:38:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_access_add_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_select_person_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_doctor_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_family_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_email_address_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_name_token_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_type_token_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_save_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_access_added_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_number_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_token_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_name_token_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_email_address_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_type_token_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_action_label"
ERROR - 2016-05-19 11:38:10 --> Could not find the language line "dashboard_action_delete_label"
INFO - 2016-05-19 11:38:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:38:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:38:10 --> Final output sent to browser
DEBUG - 2016-05-19 11:38:10 --> Total execution time: 0.0537
INFO - 2016-05-19 11:38:18 --> Config Class Initialized
INFO - 2016-05-19 11:38:18 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:38:18 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:38:18 --> Utf8 Class Initialized
INFO - 2016-05-19 11:38:18 --> URI Class Initialized
INFO - 2016-05-19 11:38:18 --> Router Class Initialized
INFO - 2016-05-19 11:38:18 --> Output Class Initialized
INFO - 2016-05-19 11:38:18 --> Security Class Initialized
DEBUG - 2016-05-19 11:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:38:18 --> CSRF cookie sent
INFO - 2016-05-19 11:38:18 --> Input Class Initialized
INFO - 2016-05-19 11:38:18 --> Language Class Initialized
INFO - 2016-05-19 11:38:18 --> Loader Class Initialized
INFO - 2016-05-19 11:38:18 --> Helper loaded: form_helper
INFO - 2016-05-19 11:38:18 --> Database Driver Class Initialized
INFO - 2016-05-19 11:38:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:38:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:38:18 --> Email Class Initialized
INFO - 2016-05-19 11:38:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:38:18 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:38:18 --> Helper loaded: language_helper
INFO - 2016-05-19 11:38:18 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:38:18 --> Model Class Initialized
INFO - 2016-05-19 11:38:18 --> Helper loaded: date_helper
INFO - 2016-05-19 11:38:18 --> Controller Class Initialized
INFO - 2016-05-19 11:38:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:38:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:38:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:38:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:38:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:38:18 --> Model Class Initialized
INFO - 2016-05-19 11:38:18 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:38:18 --> Final output sent to browser
DEBUG - 2016-05-19 11:38:18 --> Total execution time: 0.0365
INFO - 2016-05-19 11:38:44 --> Config Class Initialized
INFO - 2016-05-19 11:38:44 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:38:44 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:38:44 --> Utf8 Class Initialized
INFO - 2016-05-19 11:38:44 --> URI Class Initialized
INFO - 2016-05-19 11:38:44 --> Router Class Initialized
INFO - 2016-05-19 11:38:44 --> Output Class Initialized
INFO - 2016-05-19 11:38:44 --> Security Class Initialized
DEBUG - 2016-05-19 11:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:38:44 --> CSRF cookie sent
INFO - 2016-05-19 11:38:44 --> Input Class Initialized
INFO - 2016-05-19 11:38:44 --> Language Class Initialized
INFO - 2016-05-19 11:38:44 --> Loader Class Initialized
INFO - 2016-05-19 11:38:44 --> Helper loaded: form_helper
INFO - 2016-05-19 11:38:44 --> Database Driver Class Initialized
INFO - 2016-05-19 11:38:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:38:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:38:44 --> Email Class Initialized
INFO - 2016-05-19 11:38:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:38:44 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:38:44 --> Helper loaded: language_helper
INFO - 2016-05-19 11:38:44 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:38:44 --> Model Class Initialized
INFO - 2016-05-19 11:38:44 --> Helper loaded: date_helper
INFO - 2016-05-19 11:38:44 --> Controller Class Initialized
INFO - 2016-05-19 11:38:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:38:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:38:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:38:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:38:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:38:44 --> Model Class Initialized
INFO - 2016-05-19 11:38:44 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:38:44 --> Final output sent to browser
DEBUG - 2016-05-19 11:38:44 --> Total execution time: 0.1469
INFO - 2016-05-19 11:40:49 --> Config Class Initialized
INFO - 2016-05-19 11:40:49 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:40:49 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:40:49 --> Utf8 Class Initialized
INFO - 2016-05-19 11:40:49 --> URI Class Initialized
INFO - 2016-05-19 11:40:49 --> Router Class Initialized
INFO - 2016-05-19 11:40:49 --> Output Class Initialized
INFO - 2016-05-19 11:40:49 --> Security Class Initialized
DEBUG - 2016-05-19 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:40:49 --> CSRF cookie sent
INFO - 2016-05-19 11:40:49 --> Input Class Initialized
INFO - 2016-05-19 11:40:49 --> Language Class Initialized
INFO - 2016-05-19 11:40:49 --> Loader Class Initialized
INFO - 2016-05-19 11:40:49 --> Helper loaded: form_helper
INFO - 2016-05-19 11:40:49 --> Database Driver Class Initialized
INFO - 2016-05-19 11:40:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:40:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:40:49 --> Email Class Initialized
INFO - 2016-05-19 11:40:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:40:49 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:40:49 --> Helper loaded: language_helper
INFO - 2016-05-19 11:40:49 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:40:49 --> Model Class Initialized
INFO - 2016-05-19 11:40:49 --> Helper loaded: date_helper
INFO - 2016-05-19 11:40:49 --> Controller Class Initialized
INFO - 2016-05-19 11:40:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:40:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:40:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:40:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:40:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:40:49 --> Model Class Initialized
INFO - 2016-05-19 11:40:49 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:40:49 --> Final output sent to browser
DEBUG - 2016-05-19 11:40:49 --> Total execution time: 0.1333
INFO - 2016-05-19 11:41:18 --> Config Class Initialized
INFO - 2016-05-19 11:41:18 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:41:18 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:41:18 --> Utf8 Class Initialized
INFO - 2016-05-19 11:41:18 --> URI Class Initialized
INFO - 2016-05-19 11:41:18 --> Router Class Initialized
INFO - 2016-05-19 11:41:18 --> Output Class Initialized
INFO - 2016-05-19 11:41:18 --> Security Class Initialized
DEBUG - 2016-05-19 11:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:41:18 --> CSRF cookie sent
INFO - 2016-05-19 11:41:18 --> Input Class Initialized
INFO - 2016-05-19 11:41:18 --> Language Class Initialized
INFO - 2016-05-19 11:41:18 --> Loader Class Initialized
INFO - 2016-05-19 11:41:18 --> Helper loaded: form_helper
INFO - 2016-05-19 11:41:18 --> Database Driver Class Initialized
INFO - 2016-05-19 11:41:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:41:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:41:18 --> Email Class Initialized
INFO - 2016-05-19 11:41:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:41:18 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:41:18 --> Helper loaded: language_helper
INFO - 2016-05-19 11:41:18 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:41:18 --> Model Class Initialized
INFO - 2016-05-19 11:41:18 --> Helper loaded: date_helper
INFO - 2016-05-19 11:41:18 --> Controller Class Initialized
INFO - 2016-05-19 11:41:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:41:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:41:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:41:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:41:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:41:18 --> Model Class Initialized
INFO - 2016-05-19 11:41:18 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:41:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:41:18 --> Final output sent to browser
DEBUG - 2016-05-19 11:41:18 --> Total execution time: 0.0732
INFO - 2016-05-19 11:42:01 --> Config Class Initialized
INFO - 2016-05-19 11:42:01 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:42:01 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:42:01 --> Utf8 Class Initialized
INFO - 2016-05-19 11:42:01 --> URI Class Initialized
INFO - 2016-05-19 11:42:01 --> Router Class Initialized
INFO - 2016-05-19 11:42:01 --> Output Class Initialized
INFO - 2016-05-19 11:42:01 --> Security Class Initialized
DEBUG - 2016-05-19 11:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:42:01 --> CSRF cookie sent
INFO - 2016-05-19 11:42:01 --> Input Class Initialized
INFO - 2016-05-19 11:42:01 --> Language Class Initialized
INFO - 2016-05-19 11:42:01 --> Loader Class Initialized
INFO - 2016-05-19 11:42:01 --> Helper loaded: form_helper
INFO - 2016-05-19 11:42:01 --> Database Driver Class Initialized
INFO - 2016-05-19 11:42:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:42:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:42:01 --> Email Class Initialized
INFO - 2016-05-19 11:42:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:42:01 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:42:01 --> Helper loaded: language_helper
INFO - 2016-05-19 11:42:01 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:42:01 --> Model Class Initialized
INFO - 2016-05-19 11:42:01 --> Helper loaded: date_helper
INFO - 2016-05-19 11:42:01 --> Controller Class Initialized
INFO - 2016-05-19 11:42:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:42:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:42:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:42:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:42:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:42:01 --> Model Class Initialized
INFO - 2016-05-19 11:42:01 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:42:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:42:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:42:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:42:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:42:01 --> Final output sent to browser
DEBUG - 2016-05-19 11:42:01 --> Total execution time: 0.1194
INFO - 2016-05-19 11:48:46 --> Config Class Initialized
INFO - 2016-05-19 11:48:46 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:48:46 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:48:46 --> Utf8 Class Initialized
INFO - 2016-05-19 11:48:46 --> URI Class Initialized
INFO - 2016-05-19 11:48:46 --> Router Class Initialized
INFO - 2016-05-19 11:48:46 --> Output Class Initialized
INFO - 2016-05-19 11:48:46 --> Security Class Initialized
DEBUG - 2016-05-19 11:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:48:46 --> CSRF cookie sent
INFO - 2016-05-19 11:48:46 --> Input Class Initialized
INFO - 2016-05-19 11:48:46 --> Language Class Initialized
INFO - 2016-05-19 11:48:46 --> Loader Class Initialized
INFO - 2016-05-19 11:48:46 --> Helper loaded: form_helper
INFO - 2016-05-19 11:48:46 --> Database Driver Class Initialized
INFO - 2016-05-19 11:48:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:48:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:48:46 --> Email Class Initialized
INFO - 2016-05-19 11:48:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:48:46 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:48:46 --> Helper loaded: language_helper
INFO - 2016-05-19 11:48:46 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:48:46 --> Model Class Initialized
INFO - 2016-05-19 11:48:46 --> Helper loaded: date_helper
INFO - 2016-05-19 11:48:46 --> Controller Class Initialized
INFO - 2016-05-19 11:48:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:48:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:48:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:48:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:48:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:48:46 --> Model Class Initialized
INFO - 2016-05-19 11:48:46 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:48:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:48:46 --> Final output sent to browser
DEBUG - 2016-05-19 11:48:46 --> Total execution time: 0.0483
INFO - 2016-05-19 11:48:53 --> Config Class Initialized
INFO - 2016-05-19 11:48:53 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:48:53 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:48:53 --> Utf8 Class Initialized
INFO - 2016-05-19 11:48:53 --> URI Class Initialized
INFO - 2016-05-19 11:48:53 --> Router Class Initialized
INFO - 2016-05-19 11:48:53 --> Output Class Initialized
INFO - 2016-05-19 11:48:53 --> Security Class Initialized
DEBUG - 2016-05-19 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:48:53 --> CSRF cookie sent
INFO - 2016-05-19 11:48:53 --> Input Class Initialized
INFO - 2016-05-19 11:48:53 --> Language Class Initialized
INFO - 2016-05-19 11:48:53 --> Loader Class Initialized
INFO - 2016-05-19 11:48:53 --> Helper loaded: form_helper
INFO - 2016-05-19 11:48:53 --> Database Driver Class Initialized
INFO - 2016-05-19 11:48:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:48:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:48:53 --> Email Class Initialized
INFO - 2016-05-19 11:48:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:48:53 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:48:53 --> Helper loaded: language_helper
INFO - 2016-05-19 11:48:53 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:48:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:48:53 --> Model Class Initialized
INFO - 2016-05-19 11:48:53 --> Helper loaded: date_helper
INFO - 2016-05-19 11:48:53 --> Controller Class Initialized
INFO - 2016-05-19 11:48:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:48:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:48:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:48:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:48:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:48:53 --> Model Class Initialized
INFO - 2016-05-19 11:48:53 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:48:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:48:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:48:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:48:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:48:53 --> Final output sent to browser
DEBUG - 2016-05-19 11:48:53 --> Total execution time: 0.1181
INFO - 2016-05-19 11:53:41 --> Config Class Initialized
INFO - 2016-05-19 11:53:41 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:53:41 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:53:41 --> Utf8 Class Initialized
INFO - 2016-05-19 11:53:41 --> URI Class Initialized
INFO - 2016-05-19 11:53:41 --> Router Class Initialized
INFO - 2016-05-19 11:53:41 --> Output Class Initialized
INFO - 2016-05-19 11:53:41 --> Security Class Initialized
DEBUG - 2016-05-19 11:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:53:41 --> CSRF cookie sent
INFO - 2016-05-19 11:53:41 --> Input Class Initialized
INFO - 2016-05-19 11:53:41 --> Language Class Initialized
INFO - 2016-05-19 11:53:41 --> Loader Class Initialized
INFO - 2016-05-19 11:53:41 --> Helper loaded: form_helper
INFO - 2016-05-19 11:53:41 --> Database Driver Class Initialized
INFO - 2016-05-19 11:53:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:53:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:53:41 --> Email Class Initialized
INFO - 2016-05-19 11:53:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:53:41 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:53:41 --> Helper loaded: language_helper
INFO - 2016-05-19 11:53:41 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:53:41 --> Model Class Initialized
INFO - 2016-05-19 11:53:41 --> Helper loaded: date_helper
INFO - 2016-05-19 11:53:41 --> Controller Class Initialized
INFO - 2016-05-19 11:53:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:53:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:53:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:53:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:53:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:53:41 --> Model Class Initialized
INFO - 2016-05-19 11:53:41 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:53:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:53:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:53:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:53:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:53:41 --> Final output sent to browser
DEBUG - 2016-05-19 11:53:41 --> Total execution time: 0.0417
INFO - 2016-05-19 11:55:35 --> Config Class Initialized
INFO - 2016-05-19 11:55:35 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:55:35 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:55:35 --> Utf8 Class Initialized
INFO - 2016-05-19 11:55:35 --> URI Class Initialized
INFO - 2016-05-19 11:55:35 --> Router Class Initialized
INFO - 2016-05-19 11:55:35 --> Output Class Initialized
INFO - 2016-05-19 11:55:35 --> Security Class Initialized
DEBUG - 2016-05-19 11:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:55:35 --> CSRF cookie sent
INFO - 2016-05-19 11:55:35 --> Input Class Initialized
INFO - 2016-05-19 11:55:35 --> Language Class Initialized
INFO - 2016-05-19 11:55:35 --> Loader Class Initialized
INFO - 2016-05-19 11:55:35 --> Helper loaded: form_helper
INFO - 2016-05-19 11:55:35 --> Database Driver Class Initialized
INFO - 2016-05-19 11:55:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:55:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:55:35 --> Email Class Initialized
INFO - 2016-05-19 11:55:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:55:35 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:55:35 --> Helper loaded: language_helper
INFO - 2016-05-19 11:55:35 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:55:35 --> Model Class Initialized
INFO - 2016-05-19 11:55:35 --> Helper loaded: date_helper
INFO - 2016-05-19 11:55:35 --> Controller Class Initialized
INFO - 2016-05-19 11:55:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:55:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:55:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:55:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:55:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:55:35 --> Model Class Initialized
INFO - 2016-05-19 11:55:35 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:55:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:55:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:55:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:55:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:55:35 --> Final output sent to browser
DEBUG - 2016-05-19 11:55:35 --> Total execution time: 0.0344
INFO - 2016-05-19 11:56:10 --> Config Class Initialized
INFO - 2016-05-19 11:56:10 --> Hooks Class Initialized
DEBUG - 2016-05-19 11:56:10 --> UTF-8 Support Enabled
INFO - 2016-05-19 11:56:10 --> Utf8 Class Initialized
INFO - 2016-05-19 11:56:10 --> URI Class Initialized
INFO - 2016-05-19 11:56:10 --> Router Class Initialized
INFO - 2016-05-19 11:56:10 --> Output Class Initialized
INFO - 2016-05-19 11:56:10 --> Security Class Initialized
DEBUG - 2016-05-19 11:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 11:56:10 --> CSRF cookie sent
INFO - 2016-05-19 11:56:10 --> Input Class Initialized
INFO - 2016-05-19 11:56:10 --> Language Class Initialized
INFO - 2016-05-19 11:56:10 --> Loader Class Initialized
INFO - 2016-05-19 11:56:10 --> Helper loaded: form_helper
INFO - 2016-05-19 11:56:10 --> Database Driver Class Initialized
INFO - 2016-05-19 11:56:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 11:56:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 11:56:10 --> Email Class Initialized
INFO - 2016-05-19 11:56:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 11:56:10 --> Helper loaded: cookie_helper
INFO - 2016-05-19 11:56:10 --> Helper loaded: language_helper
INFO - 2016-05-19 11:56:10 --> Helper loaded: url_helper
DEBUG - 2016-05-19 11:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 11:56:10 --> Model Class Initialized
INFO - 2016-05-19 11:56:10 --> Helper loaded: date_helper
INFO - 2016-05-19 11:56:10 --> Controller Class Initialized
INFO - 2016-05-19 11:56:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 11:56:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 11:56:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 11:56:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 11:56:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 11:56:10 --> Model Class Initialized
INFO - 2016-05-19 11:56:10 --> Helper loaded: languages_helper
INFO - 2016-05-19 11:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 11:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 11:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 11:56:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 11:56:10 --> Final output sent to browser
DEBUG - 2016-05-19 11:56:10 --> Total execution time: 0.0527
INFO - 2016-05-19 12:14:21 --> Config Class Initialized
INFO - 2016-05-19 12:14:21 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:14:21 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:14:21 --> Utf8 Class Initialized
INFO - 2016-05-19 12:14:21 --> URI Class Initialized
INFO - 2016-05-19 12:14:21 --> Router Class Initialized
INFO - 2016-05-19 12:14:21 --> Output Class Initialized
INFO - 2016-05-19 12:14:21 --> Security Class Initialized
DEBUG - 2016-05-19 12:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:14:21 --> CSRF cookie sent
INFO - 2016-05-19 12:14:21 --> Input Class Initialized
INFO - 2016-05-19 12:14:21 --> Language Class Initialized
ERROR - 2016-05-19 12:14:21 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /home/demis/www/platformadiabet/application/controllers/Diabet.php 94
INFO - 2016-05-19 12:14:34 --> Config Class Initialized
INFO - 2016-05-19 12:14:34 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:14:34 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:14:34 --> Utf8 Class Initialized
INFO - 2016-05-19 12:14:34 --> URI Class Initialized
INFO - 2016-05-19 12:14:34 --> Router Class Initialized
INFO - 2016-05-19 12:14:34 --> Output Class Initialized
INFO - 2016-05-19 12:14:34 --> Security Class Initialized
DEBUG - 2016-05-19 12:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:14:34 --> CSRF cookie sent
INFO - 2016-05-19 12:14:34 --> Input Class Initialized
INFO - 2016-05-19 12:14:34 --> Language Class Initialized
INFO - 2016-05-19 12:14:34 --> Loader Class Initialized
INFO - 2016-05-19 12:14:34 --> Helper loaded: form_helper
INFO - 2016-05-19 12:14:34 --> Database Driver Class Initialized
INFO - 2016-05-19 12:14:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:14:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:14:34 --> Email Class Initialized
INFO - 2016-05-19 12:14:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:14:34 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:14:34 --> Helper loaded: language_helper
INFO - 2016-05-19 12:14:34 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:14:34 --> Model Class Initialized
INFO - 2016-05-19 12:14:34 --> Helper loaded: date_helper
INFO - 2016-05-19 12:14:34 --> Controller Class Initialized
INFO - 2016-05-19 12:14:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:14:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:14:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:14:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:14:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:14:34 --> Model Class Initialized
INFO - 2016-05-19 12:14:34 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:14:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:14:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:14:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:14:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:14:34 --> Final output sent to browser
DEBUG - 2016-05-19 12:14:34 --> Total execution time: 0.1148
INFO - 2016-05-19 12:15:08 --> Config Class Initialized
INFO - 2016-05-19 12:15:08 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:15:08 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:15:08 --> Utf8 Class Initialized
INFO - 2016-05-19 12:15:08 --> URI Class Initialized
INFO - 2016-05-19 12:15:08 --> Router Class Initialized
INFO - 2016-05-19 12:15:08 --> Output Class Initialized
INFO - 2016-05-19 12:15:08 --> Security Class Initialized
DEBUG - 2016-05-19 12:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:15:08 --> CSRF cookie sent
INFO - 2016-05-19 12:15:08 --> Input Class Initialized
INFO - 2016-05-19 12:15:08 --> Language Class Initialized
INFO - 2016-05-19 12:15:08 --> Loader Class Initialized
INFO - 2016-05-19 12:15:08 --> Helper loaded: form_helper
INFO - 2016-05-19 12:15:08 --> Database Driver Class Initialized
INFO - 2016-05-19 12:15:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:15:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:15:08 --> Email Class Initialized
INFO - 2016-05-19 12:15:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:15:08 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:15:08 --> Helper loaded: language_helper
INFO - 2016-05-19 12:15:08 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:15:08 --> Model Class Initialized
INFO - 2016-05-19 12:15:08 --> Helper loaded: date_helper
INFO - 2016-05-19 12:15:08 --> Controller Class Initialized
INFO - 2016-05-19 12:15:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:15:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:15:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:15:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:15:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:15:08 --> Model Class Initialized
INFO - 2016-05-19 12:15:08 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:15:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:15:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:15:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:15:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:15:08 --> Final output sent to browser
DEBUG - 2016-05-19 12:15:08 --> Total execution time: 0.0642
INFO - 2016-05-19 12:16:07 --> Config Class Initialized
INFO - 2016-05-19 12:16:07 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:16:07 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:16:07 --> Utf8 Class Initialized
INFO - 2016-05-19 12:16:07 --> URI Class Initialized
INFO - 2016-05-19 12:16:07 --> Router Class Initialized
INFO - 2016-05-19 12:16:07 --> Output Class Initialized
INFO - 2016-05-19 12:16:07 --> Security Class Initialized
DEBUG - 2016-05-19 12:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:16:07 --> CSRF cookie sent
INFO - 2016-05-19 12:16:07 --> Input Class Initialized
INFO - 2016-05-19 12:16:07 --> Language Class Initialized
INFO - 2016-05-19 12:16:07 --> Loader Class Initialized
INFO - 2016-05-19 12:16:07 --> Helper loaded: form_helper
INFO - 2016-05-19 12:16:07 --> Database Driver Class Initialized
INFO - 2016-05-19 12:16:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:16:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:16:07 --> Email Class Initialized
INFO - 2016-05-19 12:16:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:16:07 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:16:07 --> Helper loaded: language_helper
INFO - 2016-05-19 12:16:07 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:16:07 --> Model Class Initialized
INFO - 2016-05-19 12:16:07 --> Helper loaded: date_helper
INFO - 2016-05-19 12:16:07 --> Controller Class Initialized
INFO - 2016-05-19 12:16:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:16:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:16:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:16:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:16:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:16:07 --> Model Class Initialized
INFO - 2016-05-19 12:16:07 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:16:07 --> Final output sent to browser
DEBUG - 2016-05-19 12:16:07 --> Total execution time: 0.0516
INFO - 2016-05-19 12:16:19 --> Config Class Initialized
INFO - 2016-05-19 12:16:19 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:16:19 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:16:19 --> Utf8 Class Initialized
INFO - 2016-05-19 12:16:19 --> URI Class Initialized
INFO - 2016-05-19 12:16:19 --> Router Class Initialized
INFO - 2016-05-19 12:16:19 --> Output Class Initialized
INFO - 2016-05-19 12:16:19 --> Security Class Initialized
DEBUG - 2016-05-19 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:16:19 --> CSRF cookie sent
INFO - 2016-05-19 12:16:19 --> CSRF token verified
INFO - 2016-05-19 12:16:19 --> Input Class Initialized
INFO - 2016-05-19 12:16:19 --> Language Class Initialized
INFO - 2016-05-19 12:16:19 --> Loader Class Initialized
INFO - 2016-05-19 12:16:19 --> Helper loaded: form_helper
INFO - 2016-05-19 12:16:19 --> Database Driver Class Initialized
INFO - 2016-05-19 12:16:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:16:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:16:19 --> Email Class Initialized
INFO - 2016-05-19 12:16:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:16:19 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:16:19 --> Helper loaded: language_helper
INFO - 2016-05-19 12:16:19 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:16:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:16:19 --> Model Class Initialized
INFO - 2016-05-19 12:16:19 --> Helper loaded: date_helper
INFO - 2016-05-19 12:16:19 --> Controller Class Initialized
INFO - 2016-05-19 12:16:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:16:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:16:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:16:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:16:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:16:19 --> Model Class Initialized
ERROR - 2016-05-19 12:16:19 --> Severity: Notice --> Undefined property: Diabet::$form_validation /home/demis/www/platformadiabet/application/controllers/Diabet.php 90
ERROR - 2016-05-19 12:16:19 --> Severity: Error --> Call to a member function set_rules() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 90
INFO - 2016-05-19 12:16:48 --> Config Class Initialized
INFO - 2016-05-19 12:16:48 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:16:48 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:16:48 --> Utf8 Class Initialized
INFO - 2016-05-19 12:16:48 --> URI Class Initialized
INFO - 2016-05-19 12:16:48 --> Router Class Initialized
INFO - 2016-05-19 12:16:48 --> Output Class Initialized
INFO - 2016-05-19 12:16:48 --> Security Class Initialized
DEBUG - 2016-05-19 12:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:17:29 --> Config Class Initialized
INFO - 2016-05-19 12:17:29 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:17:29 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:17:29 --> Utf8 Class Initialized
INFO - 2016-05-19 12:17:29 --> URI Class Initialized
INFO - 2016-05-19 12:17:29 --> Router Class Initialized
INFO - 2016-05-19 12:17:29 --> Output Class Initialized
INFO - 2016-05-19 12:17:29 --> Security Class Initialized
DEBUG - 2016-05-19 12:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:17:50 --> Config Class Initialized
INFO - 2016-05-19 12:17:50 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:17:50 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:17:50 --> Utf8 Class Initialized
INFO - 2016-05-19 12:17:50 --> URI Class Initialized
INFO - 2016-05-19 12:17:50 --> Router Class Initialized
INFO - 2016-05-19 12:17:50 --> Output Class Initialized
INFO - 2016-05-19 12:17:50 --> Security Class Initialized
DEBUG - 2016-05-19 12:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:17:50 --> CSRF cookie sent
INFO - 2016-05-19 12:17:50 --> Input Class Initialized
INFO - 2016-05-19 12:17:50 --> Language Class Initialized
INFO - 2016-05-19 12:17:50 --> Loader Class Initialized
INFO - 2016-05-19 12:17:50 --> Helper loaded: form_helper
INFO - 2016-05-19 12:17:50 --> Database Driver Class Initialized
INFO - 2016-05-19 12:17:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:17:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:17:50 --> Email Class Initialized
INFO - 2016-05-19 12:17:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:17:50 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:17:50 --> Helper loaded: language_helper
INFO - 2016-05-19 12:17:50 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:17:50 --> Model Class Initialized
INFO - 2016-05-19 12:17:50 --> Helper loaded: date_helper
INFO - 2016-05-19 12:17:50 --> Controller Class Initialized
INFO - 2016-05-19 12:17:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:17:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:17:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:17:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:17:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:17:50 --> Model Class Initialized
INFO - 2016-05-19 12:17:50 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:17:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:17:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:17:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:17:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:17:50 --> Final output sent to browser
DEBUG - 2016-05-19 12:17:50 --> Total execution time: 0.0620
INFO - 2016-05-19 12:17:55 --> Config Class Initialized
INFO - 2016-05-19 12:17:55 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:17:55 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:17:55 --> Utf8 Class Initialized
INFO - 2016-05-19 12:17:55 --> URI Class Initialized
INFO - 2016-05-19 12:17:55 --> Router Class Initialized
INFO - 2016-05-19 12:17:55 --> Output Class Initialized
INFO - 2016-05-19 12:17:55 --> Security Class Initialized
DEBUG - 2016-05-19 12:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:17:55 --> CSRF cookie sent
INFO - 2016-05-19 12:17:55 --> Input Class Initialized
INFO - 2016-05-19 12:17:55 --> Language Class Initialized
INFO - 2016-05-19 12:17:55 --> Loader Class Initialized
INFO - 2016-05-19 12:17:55 --> Helper loaded: form_helper
INFO - 2016-05-19 12:17:55 --> Database Driver Class Initialized
INFO - 2016-05-19 12:17:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:17:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:17:55 --> Email Class Initialized
INFO - 2016-05-19 12:17:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:17:55 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:17:55 --> Helper loaded: language_helper
INFO - 2016-05-19 12:17:55 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:17:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:17:55 --> Model Class Initialized
INFO - 2016-05-19 12:17:55 --> Helper loaded: date_helper
INFO - 2016-05-19 12:17:55 --> Controller Class Initialized
INFO - 2016-05-19 12:17:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:17:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:17:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:17:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:17:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:17:55 --> Model Class Initialized
INFO - 2016-05-19 12:17:55 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:17:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:17:55 --> Final output sent to browser
DEBUG - 2016-05-19 12:17:55 --> Total execution time: 0.0705
INFO - 2016-05-19 12:19:05 --> Config Class Initialized
INFO - 2016-05-19 12:19:05 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:19:05 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:19:05 --> Utf8 Class Initialized
INFO - 2016-05-19 12:19:05 --> URI Class Initialized
INFO - 2016-05-19 12:19:05 --> Router Class Initialized
INFO - 2016-05-19 12:19:05 --> Output Class Initialized
INFO - 2016-05-19 12:19:05 --> Security Class Initialized
DEBUG - 2016-05-19 12:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:19:05 --> CSRF cookie sent
INFO - 2016-05-19 12:19:05 --> Input Class Initialized
INFO - 2016-05-19 12:19:05 --> Language Class Initialized
INFO - 2016-05-19 12:19:05 --> Loader Class Initialized
INFO - 2016-05-19 12:19:05 --> Helper loaded: form_helper
INFO - 2016-05-19 12:19:05 --> Database Driver Class Initialized
INFO - 2016-05-19 12:19:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:19:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:19:05 --> Email Class Initialized
INFO - 2016-05-19 12:19:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:19:05 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:19:05 --> Helper loaded: language_helper
INFO - 2016-05-19 12:19:05 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:19:05 --> Model Class Initialized
INFO - 2016-05-19 12:19:05 --> Helper loaded: date_helper
INFO - 2016-05-19 12:19:05 --> Controller Class Initialized
INFO - 2016-05-19 12:19:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:19:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:19:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:19:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:19:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:19:05 --> Model Class Initialized
INFO - 2016-05-19 12:19:05 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:19:05 --> Final output sent to browser
DEBUG - 2016-05-19 12:19:05 --> Total execution time: 0.0584
INFO - 2016-05-19 12:19:16 --> Config Class Initialized
INFO - 2016-05-19 12:19:16 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:19:16 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:19:16 --> Utf8 Class Initialized
INFO - 2016-05-19 12:19:16 --> URI Class Initialized
INFO - 2016-05-19 12:19:16 --> Router Class Initialized
INFO - 2016-05-19 12:19:16 --> Output Class Initialized
INFO - 2016-05-19 12:19:16 --> Security Class Initialized
DEBUG - 2016-05-19 12:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:19:16 --> CSRF cookie sent
INFO - 2016-05-19 12:19:16 --> CSRF token verified
INFO - 2016-05-19 12:19:16 --> Input Class Initialized
INFO - 2016-05-19 12:19:16 --> Language Class Initialized
INFO - 2016-05-19 12:19:16 --> Loader Class Initialized
INFO - 2016-05-19 12:19:17 --> Helper loaded: form_helper
INFO - 2016-05-19 12:19:17 --> Database Driver Class Initialized
INFO - 2016-05-19 12:19:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:19:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:19:17 --> Email Class Initialized
INFO - 2016-05-19 12:19:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:19:17 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:19:17 --> Helper loaded: language_helper
INFO - 2016-05-19 12:19:17 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:19:17 --> Model Class Initialized
INFO - 2016-05-19 12:19:17 --> Helper loaded: date_helper
INFO - 2016-05-19 12:19:17 --> Controller Class Initialized
INFO - 2016-05-19 12:19:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:19:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:19:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:19:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:19:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:19:17 --> Model Class Initialized
INFO - 2016-05-19 12:19:17 --> Form Validation Class Initialized
INFO - 2016-05-19 12:19:46 --> Config Class Initialized
INFO - 2016-05-19 12:19:46 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:19:46 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:19:46 --> Utf8 Class Initialized
INFO - 2016-05-19 12:19:46 --> URI Class Initialized
INFO - 2016-05-19 12:19:46 --> Router Class Initialized
INFO - 2016-05-19 12:19:46 --> Output Class Initialized
INFO - 2016-05-19 12:19:46 --> Security Class Initialized
DEBUG - 2016-05-19 12:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:20:01 --> Config Class Initialized
INFO - 2016-05-19 12:20:01 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:20:01 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:20:01 --> Utf8 Class Initialized
INFO - 2016-05-19 12:20:01 --> URI Class Initialized
INFO - 2016-05-19 12:20:01 --> Router Class Initialized
INFO - 2016-05-19 12:20:01 --> Output Class Initialized
INFO - 2016-05-19 12:20:01 --> Security Class Initialized
DEBUG - 2016-05-19 12:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:20:01 --> CSRF cookie sent
INFO - 2016-05-19 12:20:01 --> Input Class Initialized
INFO - 2016-05-19 12:20:01 --> Language Class Initialized
INFO - 2016-05-19 12:20:01 --> Loader Class Initialized
INFO - 2016-05-19 12:20:01 --> Helper loaded: form_helper
INFO - 2016-05-19 12:20:01 --> Database Driver Class Initialized
INFO - 2016-05-19 12:20:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:20:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:20:01 --> Email Class Initialized
INFO - 2016-05-19 12:20:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:20:01 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:20:01 --> Helper loaded: language_helper
INFO - 2016-05-19 12:20:01 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:20:01 --> Model Class Initialized
INFO - 2016-05-19 12:20:01 --> Helper loaded: date_helper
INFO - 2016-05-19 12:20:01 --> Controller Class Initialized
INFO - 2016-05-19 12:20:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:20:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:20:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:20:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:20:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:20:01 --> Model Class Initialized
INFO - 2016-05-19 12:20:01 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:20:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:20:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:20:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:20:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:20:01 --> Final output sent to browser
DEBUG - 2016-05-19 12:20:01 --> Total execution time: 0.1215
INFO - 2016-05-19 12:20:07 --> Config Class Initialized
INFO - 2016-05-19 12:20:07 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:20:07 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:20:07 --> Utf8 Class Initialized
INFO - 2016-05-19 12:20:07 --> URI Class Initialized
INFO - 2016-05-19 12:20:07 --> Router Class Initialized
INFO - 2016-05-19 12:20:07 --> Output Class Initialized
INFO - 2016-05-19 12:20:07 --> Security Class Initialized
DEBUG - 2016-05-19 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:20:07 --> CSRF cookie sent
INFO - 2016-05-19 12:20:07 --> Input Class Initialized
INFO - 2016-05-19 12:20:07 --> Language Class Initialized
INFO - 2016-05-19 12:20:07 --> Loader Class Initialized
INFO - 2016-05-19 12:20:07 --> Helper loaded: form_helper
INFO - 2016-05-19 12:20:07 --> Database Driver Class Initialized
INFO - 2016-05-19 12:20:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:20:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:20:07 --> Email Class Initialized
INFO - 2016-05-19 12:20:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:20:07 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:20:07 --> Helper loaded: language_helper
INFO - 2016-05-19 12:20:07 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:20:07 --> Model Class Initialized
INFO - 2016-05-19 12:20:07 --> Helper loaded: date_helper
INFO - 2016-05-19 12:20:07 --> Controller Class Initialized
INFO - 2016-05-19 12:20:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:20:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:20:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:20:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:20:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:20:07 --> Model Class Initialized
INFO - 2016-05-19 12:20:07 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:20:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:20:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:20:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:20:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:20:07 --> Final output sent to browser
DEBUG - 2016-05-19 12:20:07 --> Total execution time: 0.0994
INFO - 2016-05-19 12:20:32 --> Config Class Initialized
INFO - 2016-05-19 12:20:32 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:20:32 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:20:32 --> Utf8 Class Initialized
INFO - 2016-05-19 12:20:32 --> URI Class Initialized
INFO - 2016-05-19 12:20:32 --> Router Class Initialized
INFO - 2016-05-19 12:20:32 --> Output Class Initialized
INFO - 2016-05-19 12:20:32 --> Security Class Initialized
DEBUG - 2016-05-19 12:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:20:32 --> CSRF cookie sent
INFO - 2016-05-19 12:20:32 --> CSRF token verified
INFO - 2016-05-19 12:20:32 --> Input Class Initialized
INFO - 2016-05-19 12:20:32 --> Language Class Initialized
INFO - 2016-05-19 12:20:32 --> Loader Class Initialized
INFO - 2016-05-19 12:20:32 --> Helper loaded: form_helper
INFO - 2016-05-19 12:20:32 --> Database Driver Class Initialized
INFO - 2016-05-19 12:20:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:20:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:20:32 --> Email Class Initialized
INFO - 2016-05-19 12:20:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:20:32 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:20:32 --> Helper loaded: language_helper
INFO - 2016-05-19 12:20:32 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:20:32 --> Model Class Initialized
INFO - 2016-05-19 12:20:32 --> Helper loaded: date_helper
INFO - 2016-05-19 12:20:32 --> Controller Class Initialized
INFO - 2016-05-19 12:20:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:20:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:20:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:20:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:20:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:20:32 --> Model Class Initialized
INFO - 2016-05-19 12:20:32 --> Form Validation Class Initialized
INFO - 2016-05-19 12:20:34 --> Config Class Initialized
INFO - 2016-05-19 12:20:34 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:20:34 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:20:34 --> Utf8 Class Initialized
INFO - 2016-05-19 12:20:34 --> URI Class Initialized
INFO - 2016-05-19 12:20:34 --> Router Class Initialized
INFO - 2016-05-19 12:20:34 --> Output Class Initialized
INFO - 2016-05-19 12:20:34 --> Security Class Initialized
DEBUG - 2016-05-19 12:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:20:34 --> CSRF cookie sent
INFO - 2016-05-19 12:20:34 --> Input Class Initialized
INFO - 2016-05-19 12:20:34 --> Language Class Initialized
INFO - 2016-05-19 12:20:34 --> Loader Class Initialized
INFO - 2016-05-19 12:20:34 --> Helper loaded: form_helper
INFO - 2016-05-19 12:20:34 --> Database Driver Class Initialized
INFO - 2016-05-19 12:20:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:20:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:20:34 --> Email Class Initialized
INFO - 2016-05-19 12:20:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:20:34 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:20:34 --> Helper loaded: language_helper
INFO - 2016-05-19 12:20:34 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:20:34 --> Model Class Initialized
INFO - 2016-05-19 12:20:34 --> Helper loaded: date_helper
INFO - 2016-05-19 12:20:34 --> Controller Class Initialized
INFO - 2016-05-19 12:20:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:20:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:20:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:20:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:20:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:20:34 --> Model Class Initialized
INFO - 2016-05-19 12:20:34 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:20:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:20:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:20:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:20:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:20:34 --> Final output sent to browser
DEBUG - 2016-05-19 12:20:34 --> Total execution time: 0.0506
INFO - 2016-05-19 12:23:01 --> Config Class Initialized
INFO - 2016-05-19 12:23:01 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:23:01 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:23:01 --> Utf8 Class Initialized
INFO - 2016-05-19 12:23:01 --> URI Class Initialized
INFO - 2016-05-19 12:23:01 --> Router Class Initialized
INFO - 2016-05-19 12:23:01 --> Output Class Initialized
INFO - 2016-05-19 12:23:01 --> Security Class Initialized
DEBUG - 2016-05-19 12:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:23:01 --> CSRF cookie sent
INFO - 2016-05-19 12:23:01 --> Input Class Initialized
INFO - 2016-05-19 12:23:01 --> Language Class Initialized
INFO - 2016-05-19 12:23:01 --> Loader Class Initialized
INFO - 2016-05-19 12:23:01 --> Helper loaded: form_helper
INFO - 2016-05-19 12:23:01 --> Database Driver Class Initialized
INFO - 2016-05-19 12:23:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:23:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:23:01 --> Email Class Initialized
INFO - 2016-05-19 12:23:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:23:01 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:23:01 --> Helper loaded: language_helper
INFO - 2016-05-19 12:23:01 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:23:01 --> Model Class Initialized
INFO - 2016-05-19 12:23:01 --> Helper loaded: date_helper
INFO - 2016-05-19 12:23:01 --> Controller Class Initialized
INFO - 2016-05-19 12:23:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:23:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:23:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:23:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:23:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:23:01 --> Model Class Initialized
INFO - 2016-05-19 12:23:01 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:23:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:23:01 --> Final output sent to browser
DEBUG - 2016-05-19 12:23:01 --> Total execution time: 0.0633
INFO - 2016-05-19 12:23:07 --> Config Class Initialized
INFO - 2016-05-19 12:23:07 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:23:07 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:23:07 --> Utf8 Class Initialized
INFO - 2016-05-19 12:23:07 --> URI Class Initialized
INFO - 2016-05-19 12:23:07 --> Router Class Initialized
INFO - 2016-05-19 12:23:07 --> Output Class Initialized
INFO - 2016-05-19 12:23:07 --> Security Class Initialized
DEBUG - 2016-05-19 12:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:23:07 --> CSRF cookie sent
INFO - 2016-05-19 12:23:07 --> CSRF token verified
INFO - 2016-05-19 12:23:07 --> Input Class Initialized
INFO - 2016-05-19 12:23:07 --> Language Class Initialized
INFO - 2016-05-19 12:23:07 --> Loader Class Initialized
INFO - 2016-05-19 12:23:07 --> Helper loaded: form_helper
INFO - 2016-05-19 12:23:07 --> Database Driver Class Initialized
INFO - 2016-05-19 12:23:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:23:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:23:07 --> Email Class Initialized
INFO - 2016-05-19 12:23:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:23:07 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:23:07 --> Helper loaded: language_helper
INFO - 2016-05-19 12:23:07 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:23:07 --> Model Class Initialized
INFO - 2016-05-19 12:23:07 --> Helper loaded: date_helper
INFO - 2016-05-19 12:23:07 --> Controller Class Initialized
INFO - 2016-05-19 12:23:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:23:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:23:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:23:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:23:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:23:07 --> Model Class Initialized
INFO - 2016-05-19 12:23:07 --> Form Validation Class Initialized
ERROR - 2016-05-19 12:23:07 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/controllers/Diabet.php 98
INFO - 2016-05-19 12:23:07 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:23:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:23:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 12:23:07 --> Severity: Notice --> Undefined variable: tokenList /home/demis/www/platformadiabet/application/views/user_area/access.php 66
ERROR - 2016-05-19 12:23:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/views/user_area/access.php 66
INFO - 2016-05-19 12:23:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:23:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:23:07 --> Final output sent to browser
DEBUG - 2016-05-19 12:23:07 --> Total execution time: 0.1204
INFO - 2016-05-19 12:23:20 --> Config Class Initialized
INFO - 2016-05-19 12:23:20 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:23:20 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:23:20 --> Utf8 Class Initialized
INFO - 2016-05-19 12:23:20 --> URI Class Initialized
INFO - 2016-05-19 12:23:20 --> Router Class Initialized
INFO - 2016-05-19 12:23:20 --> Output Class Initialized
INFO - 2016-05-19 12:23:20 --> Security Class Initialized
DEBUG - 2016-05-19 12:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:23:26 --> Config Class Initialized
INFO - 2016-05-19 12:23:26 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:23:26 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:23:26 --> Utf8 Class Initialized
INFO - 2016-05-19 12:23:26 --> URI Class Initialized
INFO - 2016-05-19 12:23:26 --> Router Class Initialized
INFO - 2016-05-19 12:23:26 --> Output Class Initialized
INFO - 2016-05-19 12:23:26 --> Security Class Initialized
DEBUG - 2016-05-19 12:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:23:26 --> CSRF cookie sent
INFO - 2016-05-19 12:23:26 --> Input Class Initialized
INFO - 2016-05-19 12:23:26 --> Language Class Initialized
INFO - 2016-05-19 12:23:26 --> Loader Class Initialized
INFO - 2016-05-19 12:23:26 --> Helper loaded: form_helper
INFO - 2016-05-19 12:23:26 --> Database Driver Class Initialized
INFO - 2016-05-19 12:23:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:23:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:23:26 --> Email Class Initialized
INFO - 2016-05-19 12:23:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:23:26 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:23:26 --> Helper loaded: language_helper
INFO - 2016-05-19 12:23:26 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:23:26 --> Model Class Initialized
INFO - 2016-05-19 12:23:26 --> Helper loaded: date_helper
INFO - 2016-05-19 12:23:26 --> Controller Class Initialized
INFO - 2016-05-19 12:23:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:23:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:23:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:23:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:23:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:23:26 --> Model Class Initialized
INFO - 2016-05-19 12:23:26 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:23:26 --> Final output sent to browser
DEBUG - 2016-05-19 12:23:26 --> Total execution time: 0.1063
INFO - 2016-05-19 12:23:31 --> Config Class Initialized
INFO - 2016-05-19 12:23:31 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:23:31 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:23:31 --> Utf8 Class Initialized
INFO - 2016-05-19 12:23:31 --> URI Class Initialized
INFO - 2016-05-19 12:23:31 --> Router Class Initialized
INFO - 2016-05-19 12:23:31 --> Output Class Initialized
INFO - 2016-05-19 12:23:31 --> Security Class Initialized
DEBUG - 2016-05-19 12:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:23:31 --> CSRF cookie sent
INFO - 2016-05-19 12:23:31 --> CSRF token verified
INFO - 2016-05-19 12:23:31 --> Input Class Initialized
INFO - 2016-05-19 12:23:31 --> Language Class Initialized
INFO - 2016-05-19 12:23:31 --> Loader Class Initialized
INFO - 2016-05-19 12:23:31 --> Helper loaded: form_helper
INFO - 2016-05-19 12:23:31 --> Database Driver Class Initialized
INFO - 2016-05-19 12:23:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:23:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:23:31 --> Email Class Initialized
INFO - 2016-05-19 12:23:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:23:31 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:23:31 --> Helper loaded: language_helper
INFO - 2016-05-19 12:23:31 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:23:31 --> Model Class Initialized
INFO - 2016-05-19 12:23:31 --> Helper loaded: date_helper
INFO - 2016-05-19 12:23:31 --> Controller Class Initialized
INFO - 2016-05-19 12:23:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:23:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:23:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:23:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:23:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:23:31 --> Model Class Initialized
INFO - 2016-05-19 12:23:31 --> Form Validation Class Initialized
INFO - 2016-05-19 12:23:31 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:23:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:23:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 12:23:31 --> Severity: Notice --> Undefined variable: tokenList /home/demis/www/platformadiabet/application/views/user_area/access.php 66
ERROR - 2016-05-19 12:23:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/views/user_area/access.php 66
INFO - 2016-05-19 12:23:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:23:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:23:31 --> Final output sent to browser
DEBUG - 2016-05-19 12:23:31 --> Total execution time: 0.0662
INFO - 2016-05-19 12:24:41 --> Config Class Initialized
INFO - 2016-05-19 12:24:41 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:24:41 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:24:41 --> Utf8 Class Initialized
INFO - 2016-05-19 12:24:41 --> URI Class Initialized
INFO - 2016-05-19 12:24:41 --> Router Class Initialized
INFO - 2016-05-19 12:24:41 --> Output Class Initialized
INFO - 2016-05-19 12:24:41 --> Security Class Initialized
DEBUG - 2016-05-19 12:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:24:41 --> CSRF cookie sent
INFO - 2016-05-19 12:24:41 --> Input Class Initialized
INFO - 2016-05-19 12:24:41 --> Language Class Initialized
INFO - 2016-05-19 12:24:41 --> Loader Class Initialized
INFO - 2016-05-19 12:24:41 --> Helper loaded: form_helper
INFO - 2016-05-19 12:24:41 --> Database Driver Class Initialized
INFO - 2016-05-19 12:24:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:24:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:24:41 --> Email Class Initialized
INFO - 2016-05-19 12:24:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:24:41 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:24:41 --> Helper loaded: language_helper
INFO - 2016-05-19 12:24:41 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:24:41 --> Model Class Initialized
INFO - 2016-05-19 12:24:41 --> Helper loaded: date_helper
INFO - 2016-05-19 12:24:41 --> Controller Class Initialized
INFO - 2016-05-19 12:24:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:24:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:24:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:24:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:24:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:24:41 --> Model Class Initialized
INFO - 2016-05-19 12:24:41 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:24:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:24:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:24:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:24:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:24:41 --> Final output sent to browser
DEBUG - 2016-05-19 12:24:41 --> Total execution time: 0.0471
INFO - 2016-05-19 12:24:47 --> Config Class Initialized
INFO - 2016-05-19 12:24:47 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:24:47 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:24:47 --> Utf8 Class Initialized
INFO - 2016-05-19 12:24:47 --> URI Class Initialized
INFO - 2016-05-19 12:24:47 --> Router Class Initialized
INFO - 2016-05-19 12:24:47 --> Output Class Initialized
INFO - 2016-05-19 12:24:47 --> Security Class Initialized
DEBUG - 2016-05-19 12:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:24:47 --> CSRF cookie sent
INFO - 2016-05-19 12:24:47 --> CSRF token verified
INFO - 2016-05-19 12:24:47 --> Input Class Initialized
INFO - 2016-05-19 12:24:47 --> Language Class Initialized
INFO - 2016-05-19 12:24:47 --> Loader Class Initialized
INFO - 2016-05-19 12:24:47 --> Helper loaded: form_helper
INFO - 2016-05-19 12:24:47 --> Database Driver Class Initialized
INFO - 2016-05-19 12:24:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:24:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:24:47 --> Email Class Initialized
INFO - 2016-05-19 12:24:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:24:47 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:24:47 --> Helper loaded: language_helper
INFO - 2016-05-19 12:24:47 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:24:47 --> Model Class Initialized
INFO - 2016-05-19 12:24:47 --> Helper loaded: date_helper
INFO - 2016-05-19 12:24:47 --> Controller Class Initialized
INFO - 2016-05-19 12:24:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:24:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:24:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:24:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:24:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:24:47 --> Model Class Initialized
INFO - 2016-05-19 12:24:47 --> Form Validation Class Initialized
INFO - 2016-05-19 12:24:47 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:24:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:24:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:24:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:24:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:24:47 --> Final output sent to browser
DEBUG - 2016-05-19 12:24:47 --> Total execution time: 0.0685
INFO - 2016-05-19 12:32:51 --> Config Class Initialized
INFO - 2016-05-19 12:32:51 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:32:51 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:32:51 --> Utf8 Class Initialized
INFO - 2016-05-19 12:32:51 --> URI Class Initialized
INFO - 2016-05-19 12:32:51 --> Router Class Initialized
INFO - 2016-05-19 12:32:51 --> Output Class Initialized
INFO - 2016-05-19 12:32:51 --> Security Class Initialized
DEBUG - 2016-05-19 12:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:32:51 --> CSRF cookie sent
INFO - 2016-05-19 12:32:51 --> Input Class Initialized
INFO - 2016-05-19 12:32:51 --> Language Class Initialized
INFO - 2016-05-19 12:32:51 --> Loader Class Initialized
INFO - 2016-05-19 12:32:51 --> Helper loaded: form_helper
INFO - 2016-05-19 12:32:51 --> Database Driver Class Initialized
INFO - 2016-05-19 12:32:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:32:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:32:51 --> Email Class Initialized
INFO - 2016-05-19 12:32:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:32:51 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:32:51 --> Helper loaded: language_helper
INFO - 2016-05-19 12:32:51 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:32:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:32:51 --> Model Class Initialized
INFO - 2016-05-19 12:32:51 --> Helper loaded: date_helper
INFO - 2016-05-19 12:32:51 --> Controller Class Initialized
INFO - 2016-05-19 12:32:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:32:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:32:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:32:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:32:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:32:51 --> Model Class Initialized
INFO - 2016-05-19 12:32:53 --> Config Class Initialized
INFO - 2016-05-19 12:32:53 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:32:53 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:32:53 --> Utf8 Class Initialized
INFO - 2016-05-19 12:32:53 --> URI Class Initialized
INFO - 2016-05-19 12:32:53 --> Router Class Initialized
INFO - 2016-05-19 12:32:53 --> Output Class Initialized
INFO - 2016-05-19 12:32:53 --> Security Class Initialized
DEBUG - 2016-05-19 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:32:53 --> CSRF cookie sent
INFO - 2016-05-19 12:32:53 --> Input Class Initialized
INFO - 2016-05-19 12:32:53 --> Language Class Initialized
INFO - 2016-05-19 12:32:53 --> Loader Class Initialized
INFO - 2016-05-19 12:32:53 --> Helper loaded: form_helper
INFO - 2016-05-19 12:32:53 --> Database Driver Class Initialized
INFO - 2016-05-19 12:32:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:32:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:32:53 --> Email Class Initialized
INFO - 2016-05-19 12:32:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:32:53 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:32:53 --> Helper loaded: language_helper
INFO - 2016-05-19 12:32:53 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:32:53 --> Model Class Initialized
INFO - 2016-05-19 12:32:53 --> Helper loaded: date_helper
INFO - 2016-05-19 12:32:53 --> Controller Class Initialized
INFO - 2016-05-19 12:32:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:32:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:32:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:32:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:32:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:32:53 --> Model Class Initialized
INFO - 2016-05-19 12:32:53 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:32:53 --> Final output sent to browser
DEBUG - 2016-05-19 12:32:53 --> Total execution time: 0.0417
INFO - 2016-05-19 12:33:11 --> Config Class Initialized
INFO - 2016-05-19 12:33:11 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:33:11 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:33:11 --> Utf8 Class Initialized
INFO - 2016-05-19 12:33:11 --> URI Class Initialized
INFO - 2016-05-19 12:33:11 --> Router Class Initialized
INFO - 2016-05-19 12:33:11 --> Output Class Initialized
INFO - 2016-05-19 12:33:11 --> Security Class Initialized
DEBUG - 2016-05-19 12:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:33:11 --> CSRF cookie sent
INFO - 2016-05-19 12:33:11 --> CSRF token verified
INFO - 2016-05-19 12:33:11 --> Input Class Initialized
INFO - 2016-05-19 12:33:11 --> Language Class Initialized
INFO - 2016-05-19 12:33:11 --> Loader Class Initialized
INFO - 2016-05-19 12:33:11 --> Helper loaded: form_helper
INFO - 2016-05-19 12:33:11 --> Database Driver Class Initialized
INFO - 2016-05-19 12:33:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:33:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:33:11 --> Email Class Initialized
INFO - 2016-05-19 12:33:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:33:11 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:33:11 --> Helper loaded: language_helper
INFO - 2016-05-19 12:33:11 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:33:11 --> Model Class Initialized
INFO - 2016-05-19 12:33:11 --> Helper loaded: date_helper
INFO - 2016-05-19 12:33:11 --> Controller Class Initialized
INFO - 2016-05-19 12:33:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:33:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:33:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:33:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:33:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:33:11 --> Model Class Initialized
INFO - 2016-05-19 12:33:11 --> Form Validation Class Initialized
INFO - 2016-05-19 12:33:11 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:33:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:33:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:33:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:33:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:33:11 --> Final output sent to browser
DEBUG - 2016-05-19 12:33:11 --> Total execution time: 0.1175
INFO - 2016-05-19 12:55:12 --> Config Class Initialized
INFO - 2016-05-19 12:55:12 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:55:12 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:55:12 --> Utf8 Class Initialized
INFO - 2016-05-19 12:55:12 --> URI Class Initialized
INFO - 2016-05-19 12:55:12 --> Router Class Initialized
INFO - 2016-05-19 12:55:12 --> Output Class Initialized
INFO - 2016-05-19 12:55:12 --> Security Class Initialized
DEBUG - 2016-05-19 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:55:12 --> CSRF cookie sent
INFO - 2016-05-19 12:55:12 --> Input Class Initialized
INFO - 2016-05-19 12:55:12 --> Language Class Initialized
ERROR - 2016-05-19 12:55:12 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /home/demis/www/platformadiabet/application/controllers/Diabet.php 100
INFO - 2016-05-19 12:58:15 --> Config Class Initialized
INFO - 2016-05-19 12:58:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:58:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:58:15 --> Utf8 Class Initialized
INFO - 2016-05-19 12:58:15 --> URI Class Initialized
DEBUG - 2016-05-19 12:58:15 --> No URI present. Default controller set.
INFO - 2016-05-19 12:58:15 --> Router Class Initialized
INFO - 2016-05-19 12:58:15 --> Output Class Initialized
INFO - 2016-05-19 12:58:15 --> Security Class Initialized
DEBUG - 2016-05-19 12:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:58:15 --> CSRF cookie sent
INFO - 2016-05-19 12:58:15 --> Input Class Initialized
INFO - 2016-05-19 12:58:15 --> Language Class Initialized
INFO - 2016-05-19 12:58:15 --> Loader Class Initialized
INFO - 2016-05-19 12:58:15 --> Helper loaded: form_helper
INFO - 2016-05-19 12:58:15 --> Database Driver Class Initialized
INFO - 2016-05-19 12:58:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:58:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:58:15 --> Email Class Initialized
INFO - 2016-05-19 12:58:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:58:15 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:58:15 --> Helper loaded: language_helper
INFO - 2016-05-19 12:58:15 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:58:15 --> Model Class Initialized
INFO - 2016-05-19 12:58:15 --> Helper loaded: date_helper
INFO - 2016-05-19 12:58:15 --> Controller Class Initialized
INFO - 2016-05-19 12:58:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:58:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:58:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:58:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:58:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:58:15 --> Config Class Initialized
INFO - 2016-05-19 12:58:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:58:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:58:15 --> Utf8 Class Initialized
INFO - 2016-05-19 12:58:15 --> URI Class Initialized
INFO - 2016-05-19 12:58:15 --> Router Class Initialized
INFO - 2016-05-19 12:58:15 --> Output Class Initialized
INFO - 2016-05-19 12:58:15 --> Security Class Initialized
DEBUG - 2016-05-19 12:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:58:15 --> CSRF cookie sent
INFO - 2016-05-19 12:58:15 --> Input Class Initialized
INFO - 2016-05-19 12:58:15 --> Language Class Initialized
INFO - 2016-05-19 12:58:15 --> Loader Class Initialized
INFO - 2016-05-19 12:58:15 --> Helper loaded: form_helper
INFO - 2016-05-19 12:58:15 --> Database Driver Class Initialized
INFO - 2016-05-19 12:58:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:58:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:58:16 --> Email Class Initialized
INFO - 2016-05-19 12:58:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:58:16 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:58:16 --> Helper loaded: language_helper
INFO - 2016-05-19 12:58:16 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:58:16 --> Model Class Initialized
INFO - 2016-05-19 12:58:16 --> Helper loaded: date_helper
INFO - 2016-05-19 12:58:16 --> Controller Class Initialized
INFO - 2016-05-19 12:58:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:58:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:58:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:58:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:58:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:58:16 --> Model Class Initialized
INFO - 2016-05-19 12:58:16 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:58:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:58:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 12:58:16 --> Severity: Notice --> Undefined variable: csrf /home/demis/www/platformadiabet/application/views/user_area/home.php 43
INFO - 2016-05-19 12:58:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 12:58:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:58:16 --> Final output sent to browser
DEBUG - 2016-05-19 12:58:16 --> Total execution time: 0.0692
INFO - 2016-05-19 12:58:41 --> Config Class Initialized
INFO - 2016-05-19 12:58:41 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:58:41 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:58:41 --> Utf8 Class Initialized
INFO - 2016-05-19 12:58:41 --> URI Class Initialized
INFO - 2016-05-19 12:58:41 --> Router Class Initialized
INFO - 2016-05-19 12:58:41 --> Output Class Initialized
INFO - 2016-05-19 12:58:41 --> Security Class Initialized
DEBUG - 2016-05-19 12:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:58:41 --> CSRF cookie sent
INFO - 2016-05-19 12:58:41 --> Input Class Initialized
INFO - 2016-05-19 12:58:41 --> Language Class Initialized
INFO - 2016-05-19 12:58:41 --> Loader Class Initialized
INFO - 2016-05-19 12:58:41 --> Helper loaded: form_helper
INFO - 2016-05-19 12:58:41 --> Database Driver Class Initialized
INFO - 2016-05-19 12:58:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:58:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:58:41 --> Email Class Initialized
INFO - 2016-05-19 12:58:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:58:41 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:58:41 --> Helper loaded: language_helper
INFO - 2016-05-19 12:58:41 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:58:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:58:41 --> Model Class Initialized
INFO - 2016-05-19 12:58:41 --> Helper loaded: date_helper
INFO - 2016-05-19 12:58:41 --> Controller Class Initialized
INFO - 2016-05-19 12:58:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:58:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:58:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:58:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:58:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:58:41 --> Model Class Initialized
INFO - 2016-05-19 12:58:41 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:58:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:58:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:58:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 12:58:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:58:41 --> Final output sent to browser
DEBUG - 2016-05-19 12:58:41 --> Total execution time: 0.0208
INFO - 2016-05-19 12:58:47 --> Config Class Initialized
INFO - 2016-05-19 12:58:47 --> Hooks Class Initialized
DEBUG - 2016-05-19 12:58:47 --> UTF-8 Support Enabled
INFO - 2016-05-19 12:58:47 --> Utf8 Class Initialized
INFO - 2016-05-19 12:58:47 --> URI Class Initialized
INFO - 2016-05-19 12:58:47 --> Router Class Initialized
INFO - 2016-05-19 12:58:47 --> Output Class Initialized
INFO - 2016-05-19 12:58:47 --> Security Class Initialized
DEBUG - 2016-05-19 12:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 12:58:47 --> CSRF cookie sent
INFO - 2016-05-19 12:58:47 --> Input Class Initialized
INFO - 2016-05-19 12:58:47 --> Language Class Initialized
INFO - 2016-05-19 12:58:47 --> Loader Class Initialized
INFO - 2016-05-19 12:58:47 --> Helper loaded: form_helper
INFO - 2016-05-19 12:58:47 --> Database Driver Class Initialized
INFO - 2016-05-19 12:58:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 12:58:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 12:58:47 --> Email Class Initialized
INFO - 2016-05-19 12:58:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 12:58:47 --> Helper loaded: cookie_helper
INFO - 2016-05-19 12:58:47 --> Helper loaded: language_helper
INFO - 2016-05-19 12:58:47 --> Helper loaded: url_helper
DEBUG - 2016-05-19 12:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 12:58:47 --> Model Class Initialized
INFO - 2016-05-19 12:58:47 --> Helper loaded: date_helper
INFO - 2016-05-19 12:58:47 --> Controller Class Initialized
INFO - 2016-05-19 12:58:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 12:58:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 12:58:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 12:58:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 12:58:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 12:58:47 --> Model Class Initialized
INFO - 2016-05-19 12:58:47 --> Helper loaded: languages_helper
INFO - 2016-05-19 12:58:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 12:58:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 12:58:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 12:58:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 12:58:47 --> Final output sent to browser
DEBUG - 2016-05-19 12:58:47 --> Total execution time: 0.0961
INFO - 2016-05-19 13:00:29 --> Config Class Initialized
INFO - 2016-05-19 13:00:29 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:00:29 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:00:29 --> Utf8 Class Initialized
INFO - 2016-05-19 13:00:29 --> URI Class Initialized
INFO - 2016-05-19 13:00:29 --> Router Class Initialized
INFO - 2016-05-19 13:00:29 --> Output Class Initialized
INFO - 2016-05-19 13:00:29 --> Security Class Initialized
DEBUG - 2016-05-19 13:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:00:29 --> CSRF cookie sent
INFO - 2016-05-19 13:00:29 --> CSRF token verified
INFO - 2016-05-19 13:00:29 --> Input Class Initialized
INFO - 2016-05-19 13:00:29 --> Language Class Initialized
INFO - 2016-05-19 13:00:29 --> Loader Class Initialized
INFO - 2016-05-19 13:00:29 --> Helper loaded: form_helper
INFO - 2016-05-19 13:00:29 --> Database Driver Class Initialized
INFO - 2016-05-19 13:00:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:00:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:00:29 --> Email Class Initialized
INFO - 2016-05-19 13:00:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:00:29 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:00:29 --> Helper loaded: language_helper
INFO - 2016-05-19 13:00:29 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:00:29 --> Model Class Initialized
INFO - 2016-05-19 13:00:29 --> Helper loaded: date_helper
INFO - 2016-05-19 13:00:29 --> Controller Class Initialized
INFO - 2016-05-19 13:00:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:00:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:00:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:00:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:00:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:00:29 --> Model Class Initialized
ERROR - 2016-05-19 13:00:29 --> Severity: Notice --> Undefined variable: token /home/demis/www/platformadiabet/application/controllers/Diabet.php 88
INFO - 2016-05-19 13:00:49 --> Config Class Initialized
INFO - 2016-05-19 13:00:49 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:00:49 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:00:49 --> Utf8 Class Initialized
INFO - 2016-05-19 13:00:49 --> URI Class Initialized
INFO - 2016-05-19 13:00:49 --> Router Class Initialized
INFO - 2016-05-19 13:00:49 --> Output Class Initialized
INFO - 2016-05-19 13:00:49 --> Security Class Initialized
DEBUG - 2016-05-19 13:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:00:55 --> Config Class Initialized
INFO - 2016-05-19 13:00:55 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:00:55 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:00:55 --> Utf8 Class Initialized
INFO - 2016-05-19 13:00:55 --> URI Class Initialized
INFO - 2016-05-19 13:00:55 --> Router Class Initialized
INFO - 2016-05-19 13:00:55 --> Output Class Initialized
INFO - 2016-05-19 13:00:55 --> Security Class Initialized
DEBUG - 2016-05-19 13:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:00:55 --> CSRF cookie sent
INFO - 2016-05-19 13:00:55 --> Input Class Initialized
INFO - 2016-05-19 13:00:55 --> Language Class Initialized
INFO - 2016-05-19 13:00:55 --> Loader Class Initialized
INFO - 2016-05-19 13:00:55 --> Helper loaded: form_helper
INFO - 2016-05-19 13:00:55 --> Database Driver Class Initialized
INFO - 2016-05-19 13:00:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:00:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:00:55 --> Email Class Initialized
INFO - 2016-05-19 13:00:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:00:55 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:00:55 --> Helper loaded: language_helper
INFO - 2016-05-19 13:00:55 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:00:55 --> Model Class Initialized
INFO - 2016-05-19 13:00:55 --> Helper loaded: date_helper
INFO - 2016-05-19 13:00:55 --> Controller Class Initialized
INFO - 2016-05-19 13:00:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:00:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:00:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:00:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:00:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:00:55 --> Model Class Initialized
INFO - 2016-05-19 13:00:55 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:00:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:00:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:00:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:00:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:00:55 --> Final output sent to browser
DEBUG - 2016-05-19 13:00:55 --> Total execution time: 0.1338
INFO - 2016-05-19 13:00:57 --> Config Class Initialized
INFO - 2016-05-19 13:00:57 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:00:57 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:00:57 --> Utf8 Class Initialized
INFO - 2016-05-19 13:00:57 --> URI Class Initialized
INFO - 2016-05-19 13:00:57 --> Router Class Initialized
INFO - 2016-05-19 13:00:57 --> Output Class Initialized
INFO - 2016-05-19 13:00:57 --> Security Class Initialized
DEBUG - 2016-05-19 13:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:00:57 --> CSRF cookie sent
INFO - 2016-05-19 13:00:57 --> Input Class Initialized
INFO - 2016-05-19 13:00:57 --> Language Class Initialized
INFO - 2016-05-19 13:00:57 --> Loader Class Initialized
INFO - 2016-05-19 13:00:57 --> Helper loaded: form_helper
INFO - 2016-05-19 13:00:57 --> Database Driver Class Initialized
INFO - 2016-05-19 13:00:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:00:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:00:57 --> Email Class Initialized
INFO - 2016-05-19 13:00:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:00:57 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:00:57 --> Helper loaded: language_helper
INFO - 2016-05-19 13:00:57 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:00:57 --> Model Class Initialized
INFO - 2016-05-19 13:00:57 --> Helper loaded: date_helper
INFO - 2016-05-19 13:00:57 --> Controller Class Initialized
INFO - 2016-05-19 13:00:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:00:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:00:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:00:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:00:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:00:57 --> Model Class Initialized
INFO - 2016-05-19 13:00:58 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 13:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:00:58 --> Final output sent to browser
DEBUG - 2016-05-19 13:00:58 --> Total execution time: 0.0894
INFO - 2016-05-19 13:01:01 --> Config Class Initialized
INFO - 2016-05-19 13:01:01 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:01:01 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:01:01 --> Utf8 Class Initialized
INFO - 2016-05-19 13:01:01 --> URI Class Initialized
INFO - 2016-05-19 13:01:01 --> Router Class Initialized
INFO - 2016-05-19 13:01:01 --> Output Class Initialized
INFO - 2016-05-19 13:01:01 --> Security Class Initialized
DEBUG - 2016-05-19 13:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:01:01 --> CSRF cookie sent
INFO - 2016-05-19 13:01:01 --> Input Class Initialized
INFO - 2016-05-19 13:01:01 --> Language Class Initialized
INFO - 2016-05-19 13:01:01 --> Loader Class Initialized
INFO - 2016-05-19 13:01:01 --> Helper loaded: form_helper
INFO - 2016-05-19 13:01:01 --> Database Driver Class Initialized
INFO - 2016-05-19 13:01:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:01:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:01:02 --> Email Class Initialized
INFO - 2016-05-19 13:01:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:01:02 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:01:02 --> Helper loaded: language_helper
INFO - 2016-05-19 13:01:02 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:01:02 --> Model Class Initialized
INFO - 2016-05-19 13:01:02 --> Helper loaded: date_helper
INFO - 2016-05-19 13:01:02 --> Controller Class Initialized
INFO - 2016-05-19 13:01:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:01:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:01:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:01:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:01:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:01:02 --> Model Class Initialized
INFO - 2016-05-19 13:01:02 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:01:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:01:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:01:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:01:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:01:02 --> Final output sent to browser
DEBUG - 2016-05-19 13:01:02 --> Total execution time: 0.1043
INFO - 2016-05-19 13:01:11 --> Config Class Initialized
INFO - 2016-05-19 13:01:11 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:01:11 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:01:11 --> Utf8 Class Initialized
INFO - 2016-05-19 13:01:11 --> URI Class Initialized
INFO - 2016-05-19 13:01:11 --> Router Class Initialized
INFO - 2016-05-19 13:01:11 --> Output Class Initialized
INFO - 2016-05-19 13:01:11 --> Security Class Initialized
DEBUG - 2016-05-19 13:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:01:11 --> CSRF cookie sent
INFO - 2016-05-19 13:01:11 --> CSRF token verified
INFO - 2016-05-19 13:01:11 --> Input Class Initialized
INFO - 2016-05-19 13:01:11 --> Language Class Initialized
INFO - 2016-05-19 13:01:11 --> Loader Class Initialized
INFO - 2016-05-19 13:01:11 --> Helper loaded: form_helper
INFO - 2016-05-19 13:01:11 --> Database Driver Class Initialized
INFO - 2016-05-19 13:01:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:01:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:01:11 --> Email Class Initialized
INFO - 2016-05-19 13:01:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:01:11 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:01:11 --> Helper loaded: language_helper
INFO - 2016-05-19 13:01:11 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:01:11 --> Model Class Initialized
INFO - 2016-05-19 13:01:11 --> Helper loaded: date_helper
INFO - 2016-05-19 13:01:11 --> Controller Class Initialized
INFO - 2016-05-19 13:01:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:01:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:01:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:01:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:01:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:01:11 --> Model Class Initialized
INFO - 2016-05-19 13:11:25 --> Config Class Initialized
INFO - 2016-05-19 13:11:25 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:11:25 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:11:25 --> Utf8 Class Initialized
INFO - 2016-05-19 13:11:25 --> URI Class Initialized
INFO - 2016-05-19 13:11:25 --> Router Class Initialized
INFO - 2016-05-19 13:11:25 --> Output Class Initialized
INFO - 2016-05-19 13:11:25 --> Security Class Initialized
DEBUG - 2016-05-19 13:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:11:25 --> CSRF cookie sent
INFO - 2016-05-19 13:11:25 --> Input Class Initialized
INFO - 2016-05-19 13:11:25 --> Language Class Initialized
INFO - 2016-05-19 13:11:25 --> Loader Class Initialized
INFO - 2016-05-19 13:11:25 --> Helper loaded: form_helper
INFO - 2016-05-19 13:11:25 --> Database Driver Class Initialized
INFO - 2016-05-19 13:11:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:11:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:11:25 --> Email Class Initialized
INFO - 2016-05-19 13:11:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:11:25 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:11:25 --> Helper loaded: language_helper
INFO - 2016-05-19 13:11:25 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:11:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:11:25 --> Model Class Initialized
INFO - 2016-05-19 13:11:25 --> Helper loaded: date_helper
INFO - 2016-05-19 13:11:25 --> Controller Class Initialized
INFO - 2016-05-19 13:11:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:11:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:11:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:11:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:11:25 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-19 13:11:25 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /home/demis/www/platformadiabet/application/models/Diabet_model.php 114
INFO - 2016-05-19 13:12:10 --> Config Class Initialized
INFO - 2016-05-19 13:12:10 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:12:10 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:12:10 --> Utf8 Class Initialized
INFO - 2016-05-19 13:12:10 --> URI Class Initialized
INFO - 2016-05-19 13:12:10 --> Router Class Initialized
INFO - 2016-05-19 13:12:10 --> Output Class Initialized
INFO - 2016-05-19 13:12:10 --> Security Class Initialized
DEBUG - 2016-05-19 13:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:12:10 --> CSRF cookie sent
INFO - 2016-05-19 13:12:10 --> Input Class Initialized
INFO - 2016-05-19 13:12:10 --> Language Class Initialized
INFO - 2016-05-19 13:12:10 --> Loader Class Initialized
INFO - 2016-05-19 13:12:10 --> Helper loaded: form_helper
INFO - 2016-05-19 13:12:10 --> Database Driver Class Initialized
INFO - 2016-05-19 13:12:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:12:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:12:10 --> Email Class Initialized
INFO - 2016-05-19 13:12:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:12:10 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:12:10 --> Helper loaded: language_helper
INFO - 2016-05-19 13:12:10 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:12:10 --> Model Class Initialized
INFO - 2016-05-19 13:12:10 --> Helper loaded: date_helper
INFO - 2016-05-19 13:12:10 --> Controller Class Initialized
INFO - 2016-05-19 13:12:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:12:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:12:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:12:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:12:10 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-19 13:12:10 --> Severity: Parsing Error --> syntax error, unexpected '")' (T_CONSTANT_ENCAPSED_STRING) /home/demis/www/platformadiabet/application/models/Diabet_model.php 119
INFO - 2016-05-19 13:13:50 --> Config Class Initialized
INFO - 2016-05-19 13:13:50 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:13:50 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:13:50 --> Utf8 Class Initialized
INFO - 2016-05-19 13:13:50 --> URI Class Initialized
INFO - 2016-05-19 13:13:50 --> Router Class Initialized
INFO - 2016-05-19 13:13:50 --> Output Class Initialized
INFO - 2016-05-19 13:13:50 --> Security Class Initialized
DEBUG - 2016-05-19 13:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:13:50 --> CSRF cookie sent
INFO - 2016-05-19 13:13:50 --> Input Class Initialized
INFO - 2016-05-19 13:13:50 --> Language Class Initialized
INFO - 2016-05-19 13:13:50 --> Loader Class Initialized
INFO - 2016-05-19 13:13:50 --> Helper loaded: form_helper
INFO - 2016-05-19 13:13:50 --> Database Driver Class Initialized
INFO - 2016-05-19 13:13:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:13:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:13:50 --> Email Class Initialized
INFO - 2016-05-19 13:13:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:13:50 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:13:50 --> Helper loaded: language_helper
INFO - 2016-05-19 13:13:50 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:13:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:13:50 --> Model Class Initialized
INFO - 2016-05-19 13:13:50 --> Helper loaded: date_helper
INFO - 2016-05-19 13:13:50 --> Controller Class Initialized
INFO - 2016-05-19 13:13:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:13:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:13:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:13:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:13:50 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-19 13:13:50 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /home/demis/www/platformadiabet/application/models/Diabet_model.php 113
INFO - 2016-05-19 13:18:08 --> Config Class Initialized
INFO - 2016-05-19 13:18:08 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:18:08 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:18:08 --> Utf8 Class Initialized
INFO - 2016-05-19 13:18:08 --> URI Class Initialized
INFO - 2016-05-19 13:18:08 --> Router Class Initialized
INFO - 2016-05-19 13:18:08 --> Output Class Initialized
INFO - 2016-05-19 13:18:08 --> Security Class Initialized
DEBUG - 2016-05-19 13:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:18:08 --> CSRF cookie sent
INFO - 2016-05-19 13:18:08 --> Input Class Initialized
INFO - 2016-05-19 13:18:08 --> Language Class Initialized
INFO - 2016-05-19 13:18:08 --> Loader Class Initialized
INFO - 2016-05-19 13:18:08 --> Helper loaded: form_helper
INFO - 2016-05-19 13:18:08 --> Database Driver Class Initialized
INFO - 2016-05-19 13:18:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:18:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:18:08 --> Email Class Initialized
INFO - 2016-05-19 13:18:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:18:08 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:18:08 --> Helper loaded: language_helper
INFO - 2016-05-19 13:18:08 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:18:08 --> Model Class Initialized
INFO - 2016-05-19 13:18:08 --> Helper loaded: date_helper
INFO - 2016-05-19 13:18:08 --> Controller Class Initialized
INFO - 2016-05-19 13:18:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:18:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:18:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:18:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:18:08 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-19 13:18:08 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
INFO - 2016-05-19 13:19:00 --> Config Class Initialized
INFO - 2016-05-19 13:19:00 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:19:00 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:19:00 --> Utf8 Class Initialized
INFO - 2016-05-19 13:19:00 --> URI Class Initialized
INFO - 2016-05-19 13:19:00 --> Router Class Initialized
INFO - 2016-05-19 13:19:00 --> Output Class Initialized
INFO - 2016-05-19 13:19:00 --> Security Class Initialized
DEBUG - 2016-05-19 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:19:00 --> CSRF cookie sent
INFO - 2016-05-19 13:19:00 --> Input Class Initialized
INFO - 2016-05-19 13:19:00 --> Language Class Initialized
INFO - 2016-05-19 13:19:00 --> Loader Class Initialized
INFO - 2016-05-19 13:19:00 --> Helper loaded: form_helper
INFO - 2016-05-19 13:19:00 --> Database Driver Class Initialized
INFO - 2016-05-19 13:19:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:19:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:19:00 --> Email Class Initialized
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:19:00 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:19:00 --> Helper loaded: language_helper
INFO - 2016-05-19 13:19:00 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:19:00 --> Model Class Initialized
INFO - 2016-05-19 13:19:00 --> Helper loaded: date_helper
INFO - 2016-05-19 13:19:00 --> Controller Class Initialized
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:19:00 --> Model Class Initialized
INFO - 2016-05-19 13:19:00 --> Config Class Initialized
INFO - 2016-05-19 13:19:00 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:19:00 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:19:00 --> Utf8 Class Initialized
INFO - 2016-05-19 13:19:00 --> URI Class Initialized
INFO - 2016-05-19 13:19:00 --> Router Class Initialized
INFO - 2016-05-19 13:19:00 --> Output Class Initialized
INFO - 2016-05-19 13:19:00 --> Security Class Initialized
DEBUG - 2016-05-19 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:19:00 --> CSRF cookie sent
INFO - 2016-05-19 13:19:00 --> Input Class Initialized
INFO - 2016-05-19 13:19:00 --> Language Class Initialized
INFO - 2016-05-19 13:19:00 --> Loader Class Initialized
INFO - 2016-05-19 13:19:00 --> Helper loaded: form_helper
INFO - 2016-05-19 13:19:00 --> Database Driver Class Initialized
INFO - 2016-05-19 13:19:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:19:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:19:00 --> Email Class Initialized
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:19:00 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:19:00 --> Helper loaded: language_helper
INFO - 2016-05-19 13:19:00 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:19:00 --> Model Class Initialized
INFO - 2016-05-19 13:19:00 --> Helper loaded: date_helper
INFO - 2016-05-19 13:19:00 --> Controller Class Initialized
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:19:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:19:00 --> Model Class Initialized
INFO - 2016-05-19 13:19:00 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:19:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:19:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:19:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:19:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:19:00 --> Final output sent to browser
DEBUG - 2016-05-19 13:19:00 --> Total execution time: 0.0239
INFO - 2016-05-19 13:19:21 --> Config Class Initialized
INFO - 2016-05-19 13:19:21 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:19:21 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:19:21 --> Utf8 Class Initialized
INFO - 2016-05-19 13:19:21 --> URI Class Initialized
INFO - 2016-05-19 13:19:21 --> Router Class Initialized
INFO - 2016-05-19 13:19:21 --> Output Class Initialized
INFO - 2016-05-19 13:19:21 --> Security Class Initialized
DEBUG - 2016-05-19 13:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:19:21 --> CSRF cookie sent
INFO - 2016-05-19 13:19:21 --> CSRF token verified
INFO - 2016-05-19 13:19:21 --> Input Class Initialized
INFO - 2016-05-19 13:19:21 --> Language Class Initialized
INFO - 2016-05-19 13:19:21 --> Loader Class Initialized
INFO - 2016-05-19 13:19:21 --> Helper loaded: form_helper
INFO - 2016-05-19 13:19:21 --> Database Driver Class Initialized
INFO - 2016-05-19 13:19:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:19:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:19:21 --> Email Class Initialized
INFO - 2016-05-19 13:19:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:19:21 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:19:21 --> Helper loaded: language_helper
INFO - 2016-05-19 13:19:21 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:19:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:19:21 --> Model Class Initialized
INFO - 2016-05-19 13:19:21 --> Helper loaded: date_helper
INFO - 2016-05-19 13:19:21 --> Controller Class Initialized
INFO - 2016-05-19 13:19:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:19:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:19:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:19:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:19:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:19:21 --> Model Class Initialized
INFO - 2016-05-19 13:19:21 --> Form Validation Class Initialized
INFO - 2016-05-19 13:19:21 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:19:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:19:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:19:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:19:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:19:21 --> Final output sent to browser
DEBUG - 2016-05-19 13:19:21 --> Total execution time: 0.0601
INFO - 2016-05-19 13:19:55 --> Config Class Initialized
INFO - 2016-05-19 13:19:55 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:19:55 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:19:55 --> Utf8 Class Initialized
INFO - 2016-05-19 13:19:55 --> URI Class Initialized
INFO - 2016-05-19 13:19:55 --> Router Class Initialized
INFO - 2016-05-19 13:19:55 --> Output Class Initialized
INFO - 2016-05-19 13:19:55 --> Security Class Initialized
DEBUG - 2016-05-19 13:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:19:55 --> CSRF cookie sent
INFO - 2016-05-19 13:19:55 --> CSRF token verified
INFO - 2016-05-19 13:19:55 --> Input Class Initialized
INFO - 2016-05-19 13:19:55 --> Language Class Initialized
INFO - 2016-05-19 13:19:55 --> Loader Class Initialized
INFO - 2016-05-19 13:19:55 --> Helper loaded: form_helper
INFO - 2016-05-19 13:19:55 --> Database Driver Class Initialized
INFO - 2016-05-19 13:19:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:19:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:19:56 --> Email Class Initialized
INFO - 2016-05-19 13:19:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:19:56 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:19:56 --> Helper loaded: language_helper
INFO - 2016-05-19 13:19:56 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:19:56 --> Model Class Initialized
INFO - 2016-05-19 13:19:56 --> Helper loaded: date_helper
INFO - 2016-05-19 13:19:56 --> Controller Class Initialized
INFO - 2016-05-19 13:19:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:19:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:19:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:19:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:19:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:19:56 --> Model Class Initialized
INFO - 2016-05-19 13:19:56 --> Form Validation Class Initialized
ERROR - 2016-05-19 13:19:56 --> Severity: Notice --> Undefined index: token /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:19:56 --> Severity: Notice --> Undefined index: fk_user /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:19:56 --> Severity: Notice --> Undefined index: name /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:19:56 --> Severity: Notice --> Undefined index: email /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:19:56 --> Severity: Notice --> Undefined index: type /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:19:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4 - Invalid query: 
         INSERT IGNORE INTO `tokens`
                (`token`, `fk_user`, `name`, `email`, `type`, `_is_active`, `_create_date` )
         VALUES
                (NULL,NULL,NULL,NULL,NULL,'1'
INFO - 2016-05-19 13:21:09 --> Config Class Initialized
INFO - 2016-05-19 13:21:09 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:21:09 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:21:09 --> Utf8 Class Initialized
INFO - 2016-05-19 13:21:09 --> URI Class Initialized
INFO - 2016-05-19 13:21:09 --> Router Class Initialized
INFO - 2016-05-19 13:21:09 --> Output Class Initialized
INFO - 2016-05-19 13:21:09 --> Security Class Initialized
DEBUG - 2016-05-19 13:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:21:09 --> CSRF cookie sent
INFO - 2016-05-19 13:21:09 --> Input Class Initialized
INFO - 2016-05-19 13:21:09 --> Language Class Initialized
INFO - 2016-05-19 13:21:09 --> Loader Class Initialized
INFO - 2016-05-19 13:21:09 --> Helper loaded: form_helper
INFO - 2016-05-19 13:21:09 --> Database Driver Class Initialized
INFO - 2016-05-19 13:21:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:21:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:21:09 --> Email Class Initialized
INFO - 2016-05-19 13:21:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:21:09 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:21:09 --> Helper loaded: language_helper
INFO - 2016-05-19 13:21:09 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:21:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:21:09 --> Model Class Initialized
INFO - 2016-05-19 13:21:09 --> Helper loaded: date_helper
INFO - 2016-05-19 13:21:09 --> Controller Class Initialized
INFO - 2016-05-19 13:21:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:21:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:21:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:21:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:21:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:21:09 --> Model Class Initialized
INFO - 2016-05-19 13:21:09 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:21:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:21:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:21:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:21:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:21:09 --> Final output sent to browser
DEBUG - 2016-05-19 13:21:09 --> Total execution time: 0.1230
INFO - 2016-05-19 13:21:19 --> Config Class Initialized
INFO - 2016-05-19 13:21:19 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:21:19 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:21:19 --> Utf8 Class Initialized
INFO - 2016-05-19 13:21:19 --> URI Class Initialized
INFO - 2016-05-19 13:21:19 --> Router Class Initialized
INFO - 2016-05-19 13:21:19 --> Output Class Initialized
INFO - 2016-05-19 13:21:19 --> Security Class Initialized
DEBUG - 2016-05-19 13:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:21:19 --> CSRF cookie sent
INFO - 2016-05-19 13:21:19 --> CSRF token verified
INFO - 2016-05-19 13:21:19 --> Input Class Initialized
INFO - 2016-05-19 13:21:19 --> Language Class Initialized
INFO - 2016-05-19 13:21:19 --> Loader Class Initialized
INFO - 2016-05-19 13:21:19 --> Helper loaded: form_helper
INFO - 2016-05-19 13:21:19 --> Database Driver Class Initialized
INFO - 2016-05-19 13:21:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:21:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:21:20 --> Email Class Initialized
INFO - 2016-05-19 13:21:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:21:20 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:21:20 --> Helper loaded: language_helper
INFO - 2016-05-19 13:21:20 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:21:20 --> Model Class Initialized
INFO - 2016-05-19 13:21:20 --> Helper loaded: date_helper
INFO - 2016-05-19 13:21:20 --> Controller Class Initialized
INFO - 2016-05-19 13:21:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:21:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:21:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:21:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:21:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:21:20 --> Model Class Initialized
INFO - 2016-05-19 13:21:20 --> Form Validation Class Initialized
INFO - 2016-05-19 13:21:20 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:21:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:21:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:21:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:21:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:21:20 --> Final output sent to browser
DEBUG - 2016-05-19 13:21:20 --> Total execution time: 0.0554
INFO - 2016-05-19 13:21:32 --> Config Class Initialized
INFO - 2016-05-19 13:21:32 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:21:32 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:21:32 --> Utf8 Class Initialized
INFO - 2016-05-19 13:21:32 --> URI Class Initialized
INFO - 2016-05-19 13:21:32 --> Router Class Initialized
INFO - 2016-05-19 13:21:32 --> Output Class Initialized
INFO - 2016-05-19 13:21:32 --> Security Class Initialized
DEBUG - 2016-05-19 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:21:32 --> CSRF cookie sent
INFO - 2016-05-19 13:21:32 --> CSRF token verified
INFO - 2016-05-19 13:21:32 --> Input Class Initialized
INFO - 2016-05-19 13:21:32 --> Language Class Initialized
INFO - 2016-05-19 13:21:32 --> Loader Class Initialized
INFO - 2016-05-19 13:21:32 --> Helper loaded: form_helper
INFO - 2016-05-19 13:21:32 --> Database Driver Class Initialized
INFO - 2016-05-19 13:21:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:21:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:21:32 --> Email Class Initialized
INFO - 2016-05-19 13:21:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:21:32 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:21:32 --> Helper loaded: language_helper
INFO - 2016-05-19 13:21:32 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:21:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:21:32 --> Model Class Initialized
INFO - 2016-05-19 13:21:32 --> Helper loaded: date_helper
INFO - 2016-05-19 13:21:32 --> Controller Class Initialized
INFO - 2016-05-19 13:21:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:21:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:21:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:21:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:21:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:21:32 --> Model Class Initialized
INFO - 2016-05-19 13:21:32 --> Form Validation Class Initialized
ERROR - 2016-05-19 13:21:32 --> Severity: Notice --> Undefined index: token /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:21:32 --> Severity: Notice --> Undefined index: fk_user /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:21:32 --> Severity: Notice --> Undefined index: name /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:21:32 --> Severity: Notice --> Undefined index: email /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:21:32 --> Severity: Notice --> Undefined index: type /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:21:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4 - Invalid query: 
         INSERT IGNORE INTO `tokens`
                (`token`, `fk_user`, `name`, `email`, `type`, `_is_active`, `_create_date` )
         VALUES
                (NULL,NULL,NULL,NULL,NULL,'1'
INFO - 2016-05-19 13:22:16 --> Config Class Initialized
INFO - 2016-05-19 13:22:16 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:22:16 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:22:16 --> Utf8 Class Initialized
INFO - 2016-05-19 13:22:16 --> URI Class Initialized
INFO - 2016-05-19 13:22:16 --> Router Class Initialized
INFO - 2016-05-19 13:22:16 --> Output Class Initialized
INFO - 2016-05-19 13:22:16 --> Security Class Initialized
DEBUG - 2016-05-19 13:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:22:16 --> CSRF cookie sent
INFO - 2016-05-19 13:22:16 --> Input Class Initialized
INFO - 2016-05-19 13:22:16 --> Language Class Initialized
INFO - 2016-05-19 13:22:16 --> Loader Class Initialized
INFO - 2016-05-19 13:22:16 --> Helper loaded: form_helper
INFO - 2016-05-19 13:22:16 --> Database Driver Class Initialized
INFO - 2016-05-19 13:22:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:22:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:22:16 --> Email Class Initialized
INFO - 2016-05-19 13:22:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:22:16 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:22:16 --> Helper loaded: language_helper
INFO - 2016-05-19 13:22:16 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:22:16 --> Model Class Initialized
INFO - 2016-05-19 13:22:16 --> Helper loaded: date_helper
INFO - 2016-05-19 13:22:16 --> Controller Class Initialized
INFO - 2016-05-19 13:22:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:22:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:22:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:22:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:22:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:22:16 --> Model Class Initialized
INFO - 2016-05-19 13:22:17 --> Config Class Initialized
INFO - 2016-05-19 13:22:17 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:22:17 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:22:17 --> Utf8 Class Initialized
INFO - 2016-05-19 13:22:17 --> URI Class Initialized
INFO - 2016-05-19 13:22:17 --> Router Class Initialized
INFO - 2016-05-19 13:22:17 --> Output Class Initialized
INFO - 2016-05-19 13:22:17 --> Security Class Initialized
DEBUG - 2016-05-19 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:22:17 --> CSRF cookie sent
INFO - 2016-05-19 13:22:17 --> Input Class Initialized
INFO - 2016-05-19 13:22:17 --> Language Class Initialized
INFO - 2016-05-19 13:22:17 --> Loader Class Initialized
INFO - 2016-05-19 13:22:17 --> Helper loaded: form_helper
INFO - 2016-05-19 13:22:17 --> Database Driver Class Initialized
INFO - 2016-05-19 13:22:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:22:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:22:17 --> Email Class Initialized
INFO - 2016-05-19 13:22:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:22:17 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:22:17 --> Helper loaded: language_helper
INFO - 2016-05-19 13:22:17 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:22:17 --> Model Class Initialized
INFO - 2016-05-19 13:22:17 --> Helper loaded: date_helper
INFO - 2016-05-19 13:22:17 --> Controller Class Initialized
INFO - 2016-05-19 13:22:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:22:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:22:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:22:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:22:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:22:17 --> Model Class Initialized
INFO - 2016-05-19 13:22:17 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:22:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:22:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:22:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:22:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:22:17 --> Final output sent to browser
DEBUG - 2016-05-19 13:22:17 --> Total execution time: 0.0811
INFO - 2016-05-19 13:22:24 --> Config Class Initialized
INFO - 2016-05-19 13:22:24 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:22:24 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:22:24 --> Utf8 Class Initialized
INFO - 2016-05-19 13:22:24 --> URI Class Initialized
INFO - 2016-05-19 13:22:24 --> Router Class Initialized
INFO - 2016-05-19 13:22:24 --> Output Class Initialized
INFO - 2016-05-19 13:22:24 --> Security Class Initialized
DEBUG - 2016-05-19 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:22:24 --> CSRF cookie sent
INFO - 2016-05-19 13:22:24 --> CSRF token verified
INFO - 2016-05-19 13:22:24 --> Input Class Initialized
INFO - 2016-05-19 13:22:24 --> Language Class Initialized
INFO - 2016-05-19 13:22:24 --> Loader Class Initialized
INFO - 2016-05-19 13:22:24 --> Helper loaded: form_helper
INFO - 2016-05-19 13:22:24 --> Database Driver Class Initialized
INFO - 2016-05-19 13:22:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:22:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:22:24 --> Email Class Initialized
INFO - 2016-05-19 13:22:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:22:24 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:22:24 --> Helper loaded: language_helper
INFO - 2016-05-19 13:22:24 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:22:24 --> Model Class Initialized
INFO - 2016-05-19 13:22:24 --> Helper loaded: date_helper
INFO - 2016-05-19 13:22:24 --> Controller Class Initialized
INFO - 2016-05-19 13:22:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:22:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:22:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:22:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:22:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:22:24 --> Model Class Initialized
INFO - 2016-05-19 13:22:24 --> Form Validation Class Initialized
INFO - 2016-05-19 13:22:24 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:22:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:22:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:22:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:22:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:22:24 --> Final output sent to browser
DEBUG - 2016-05-19 13:22:24 --> Total execution time: 0.0336
INFO - 2016-05-19 13:22:35 --> Config Class Initialized
INFO - 2016-05-19 13:22:35 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:22:35 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:22:35 --> Utf8 Class Initialized
INFO - 2016-05-19 13:22:35 --> URI Class Initialized
INFO - 2016-05-19 13:22:35 --> Router Class Initialized
INFO - 2016-05-19 13:22:35 --> Output Class Initialized
INFO - 2016-05-19 13:22:35 --> Security Class Initialized
DEBUG - 2016-05-19 13:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:22:35 --> CSRF cookie sent
INFO - 2016-05-19 13:22:35 --> CSRF token verified
INFO - 2016-05-19 13:22:35 --> Input Class Initialized
INFO - 2016-05-19 13:22:35 --> Language Class Initialized
INFO - 2016-05-19 13:22:35 --> Loader Class Initialized
INFO - 2016-05-19 13:22:35 --> Helper loaded: form_helper
INFO - 2016-05-19 13:22:35 --> Database Driver Class Initialized
INFO - 2016-05-19 13:22:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:22:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:22:35 --> Email Class Initialized
INFO - 2016-05-19 13:22:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:22:35 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:22:35 --> Helper loaded: language_helper
INFO - 2016-05-19 13:22:35 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:22:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:22:35 --> Model Class Initialized
INFO - 2016-05-19 13:22:35 --> Helper loaded: date_helper
INFO - 2016-05-19 13:22:35 --> Controller Class Initialized
INFO - 2016-05-19 13:22:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:22:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:22:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:22:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:22:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:22:35 --> Model Class Initialized
INFO - 2016-05-19 13:22:35 --> Form Validation Class Initialized
INFO - 2016-05-19 13:24:30 --> Config Class Initialized
INFO - 2016-05-19 13:24:30 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:24:30 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:24:30 --> Utf8 Class Initialized
INFO - 2016-05-19 13:24:30 --> URI Class Initialized
INFO - 2016-05-19 13:24:30 --> Router Class Initialized
INFO - 2016-05-19 13:24:30 --> Output Class Initialized
INFO - 2016-05-19 13:24:30 --> Security Class Initialized
DEBUG - 2016-05-19 13:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:24:30 --> CSRF cookie sent
INFO - 2016-05-19 13:24:30 --> Input Class Initialized
INFO - 2016-05-19 13:24:30 --> Language Class Initialized
INFO - 2016-05-19 13:24:30 --> Loader Class Initialized
INFO - 2016-05-19 13:24:30 --> Helper loaded: form_helper
INFO - 2016-05-19 13:24:30 --> Database Driver Class Initialized
INFO - 2016-05-19 13:24:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:24:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:24:30 --> Email Class Initialized
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:24:30 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:24:30 --> Helper loaded: language_helper
INFO - 2016-05-19 13:24:30 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:24:30 --> Model Class Initialized
INFO - 2016-05-19 13:24:30 --> Helper loaded: date_helper
INFO - 2016-05-19 13:24:30 --> Controller Class Initialized
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:24:30 --> Model Class Initialized
INFO - 2016-05-19 13:24:30 --> Config Class Initialized
INFO - 2016-05-19 13:24:30 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:24:30 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:24:30 --> Utf8 Class Initialized
INFO - 2016-05-19 13:24:30 --> URI Class Initialized
INFO - 2016-05-19 13:24:30 --> Router Class Initialized
INFO - 2016-05-19 13:24:30 --> Output Class Initialized
INFO - 2016-05-19 13:24:30 --> Security Class Initialized
DEBUG - 2016-05-19 13:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:24:30 --> CSRF cookie sent
INFO - 2016-05-19 13:24:30 --> Input Class Initialized
INFO - 2016-05-19 13:24:30 --> Language Class Initialized
INFO - 2016-05-19 13:24:30 --> Loader Class Initialized
INFO - 2016-05-19 13:24:30 --> Helper loaded: form_helper
INFO - 2016-05-19 13:24:30 --> Database Driver Class Initialized
INFO - 2016-05-19 13:24:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:24:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:24:30 --> Email Class Initialized
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:24:30 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:24:30 --> Helper loaded: language_helper
INFO - 2016-05-19 13:24:30 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:24:30 --> Model Class Initialized
INFO - 2016-05-19 13:24:30 --> Helper loaded: date_helper
INFO - 2016-05-19 13:24:30 --> Controller Class Initialized
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:24:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:24:30 --> Model Class Initialized
INFO - 2016-05-19 13:24:30 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:24:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:24:30 --> Final output sent to browser
DEBUG - 2016-05-19 13:24:30 --> Total execution time: 0.0383
INFO - 2016-05-19 13:24:42 --> Config Class Initialized
INFO - 2016-05-19 13:24:42 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:24:42 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:24:42 --> Utf8 Class Initialized
INFO - 2016-05-19 13:24:42 --> URI Class Initialized
INFO - 2016-05-19 13:24:42 --> Router Class Initialized
INFO - 2016-05-19 13:24:42 --> Output Class Initialized
INFO - 2016-05-19 13:24:42 --> Security Class Initialized
DEBUG - 2016-05-19 13:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:24:42 --> CSRF cookie sent
INFO - 2016-05-19 13:24:42 --> CSRF token verified
INFO - 2016-05-19 13:24:42 --> Input Class Initialized
INFO - 2016-05-19 13:24:42 --> Language Class Initialized
INFO - 2016-05-19 13:24:42 --> Loader Class Initialized
INFO - 2016-05-19 13:24:42 --> Helper loaded: form_helper
INFO - 2016-05-19 13:24:42 --> Database Driver Class Initialized
INFO - 2016-05-19 13:24:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:24:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:24:42 --> Email Class Initialized
INFO - 2016-05-19 13:24:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:24:42 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:24:42 --> Helper loaded: language_helper
INFO - 2016-05-19 13:24:42 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:24:42 --> Model Class Initialized
INFO - 2016-05-19 13:24:42 --> Helper loaded: date_helper
INFO - 2016-05-19 13:24:42 --> Controller Class Initialized
INFO - 2016-05-19 13:24:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:24:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:24:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:24:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:24:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:24:42 --> Model Class Initialized
INFO - 2016-05-19 13:24:42 --> Form Validation Class Initialized
ERROR - 2016-05-19 13:24:42 --> Severity: Notice --> Undefined index: type /home/demis/www/platformadiabet/application/models/Diabet_model.php 112
ERROR - 2016-05-19 13:24:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4 - Invalid query: 
         INSERT IGNORE INTO `tokens`
                (`token`, `fk_user`, `name`, `email`, `type`, `_is_active`, `_create_date` )
         VALUES
                ('Stlo0Ap1iXVa3Jq6djF9EsgOZRIh2CkK','2','Tadam','tadam@yahoo.com',NULL,'1'
INFO - 2016-05-19 13:25:24 --> Config Class Initialized
INFO - 2016-05-19 13:25:24 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:25:24 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:25:24 --> Utf8 Class Initialized
INFO - 2016-05-19 13:25:24 --> URI Class Initialized
INFO - 2016-05-19 13:25:24 --> Router Class Initialized
INFO - 2016-05-19 13:25:24 --> Output Class Initialized
INFO - 2016-05-19 13:25:24 --> Security Class Initialized
DEBUG - 2016-05-19 13:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:25:27 --> Config Class Initialized
INFO - 2016-05-19 13:25:27 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:25:27 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:25:27 --> Utf8 Class Initialized
INFO - 2016-05-19 13:25:27 --> URI Class Initialized
INFO - 2016-05-19 13:25:27 --> Router Class Initialized
INFO - 2016-05-19 13:25:27 --> Output Class Initialized
INFO - 2016-05-19 13:25:27 --> Security Class Initialized
DEBUG - 2016-05-19 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:25:27 --> CSRF cookie sent
INFO - 2016-05-19 13:25:27 --> Input Class Initialized
INFO - 2016-05-19 13:25:27 --> Language Class Initialized
INFO - 2016-05-19 13:25:27 --> Loader Class Initialized
INFO - 2016-05-19 13:25:27 --> Helper loaded: form_helper
INFO - 2016-05-19 13:25:27 --> Database Driver Class Initialized
INFO - 2016-05-19 13:25:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:25:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:25:27 --> Email Class Initialized
INFO - 2016-05-19 13:25:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:25:27 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:25:27 --> Helper loaded: language_helper
INFO - 2016-05-19 13:25:27 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:25:27 --> Model Class Initialized
INFO - 2016-05-19 13:25:27 --> Helper loaded: date_helper
INFO - 2016-05-19 13:25:27 --> Controller Class Initialized
INFO - 2016-05-19 13:25:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:25:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:25:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:25:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:25:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:25:27 --> Model Class Initialized
INFO - 2016-05-19 13:25:28 --> Config Class Initialized
INFO - 2016-05-19 13:25:28 --> Hooks Class Initialized
DEBUG - 2016-05-19 13:25:28 --> UTF-8 Support Enabled
INFO - 2016-05-19 13:25:28 --> Utf8 Class Initialized
INFO - 2016-05-19 13:25:28 --> URI Class Initialized
INFO - 2016-05-19 13:25:28 --> Router Class Initialized
INFO - 2016-05-19 13:25:28 --> Output Class Initialized
INFO - 2016-05-19 13:25:28 --> Security Class Initialized
DEBUG - 2016-05-19 13:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 13:25:28 --> CSRF cookie sent
INFO - 2016-05-19 13:25:28 --> Input Class Initialized
INFO - 2016-05-19 13:25:28 --> Language Class Initialized
INFO - 2016-05-19 13:25:28 --> Loader Class Initialized
INFO - 2016-05-19 13:25:28 --> Helper loaded: form_helper
INFO - 2016-05-19 13:25:28 --> Database Driver Class Initialized
INFO - 2016-05-19 13:25:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 13:25:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 13:25:28 --> Email Class Initialized
INFO - 2016-05-19 13:25:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 13:25:28 --> Helper loaded: cookie_helper
INFO - 2016-05-19 13:25:28 --> Helper loaded: language_helper
INFO - 2016-05-19 13:25:28 --> Helper loaded: url_helper
DEBUG - 2016-05-19 13:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 13:25:28 --> Model Class Initialized
INFO - 2016-05-19 13:25:28 --> Helper loaded: date_helper
INFO - 2016-05-19 13:25:28 --> Controller Class Initialized
INFO - 2016-05-19 13:25:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 13:25:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 13:25:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 13:25:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 13:25:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 13:25:28 --> Model Class Initialized
INFO - 2016-05-19 13:25:28 --> Helper loaded: languages_helper
INFO - 2016-05-19 13:25:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 13:25:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 13:25:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 13:25:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 13:25:28 --> Final output sent to browser
DEBUG - 2016-05-19 13:25:28 --> Total execution time: 0.0337
INFO - 2016-05-19 15:29:31 --> Config Class Initialized
INFO - 2016-05-19 15:29:31 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:29:31 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:29:31 --> Utf8 Class Initialized
INFO - 2016-05-19 15:29:31 --> URI Class Initialized
INFO - 2016-05-19 15:29:31 --> Router Class Initialized
INFO - 2016-05-19 15:29:31 --> Output Class Initialized
INFO - 2016-05-19 15:29:31 --> Security Class Initialized
DEBUG - 2016-05-19 15:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:29:37 --> Config Class Initialized
INFO - 2016-05-19 15:29:37 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:29:37 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:29:37 --> Utf8 Class Initialized
INFO - 2016-05-19 15:29:37 --> URI Class Initialized
INFO - 2016-05-19 15:29:37 --> Router Class Initialized
INFO - 2016-05-19 15:29:37 --> Output Class Initialized
INFO - 2016-05-19 15:29:37 --> Security Class Initialized
DEBUG - 2016-05-19 15:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:29:37 --> CSRF cookie sent
INFO - 2016-05-19 15:29:37 --> Input Class Initialized
INFO - 2016-05-19 15:29:37 --> Language Class Initialized
INFO - 2016-05-19 15:29:37 --> Loader Class Initialized
INFO - 2016-05-19 15:29:37 --> Helper loaded: form_helper
INFO - 2016-05-19 15:29:37 --> Database Driver Class Initialized
INFO - 2016-05-19 15:29:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:29:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:29:37 --> Email Class Initialized
INFO - 2016-05-19 15:29:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:29:37 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:29:37 --> Helper loaded: language_helper
INFO - 2016-05-19 15:29:37 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:29:37 --> Model Class Initialized
INFO - 2016-05-19 15:29:37 --> Helper loaded: date_helper
INFO - 2016-05-19 15:29:37 --> Controller Class Initialized
INFO - 2016-05-19 15:29:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:29:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:29:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:29:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:29:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:29:37 --> Model Class Initialized
INFO - 2016-05-19 15:29:38 --> Config Class Initialized
INFO - 2016-05-19 15:29:38 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:29:38 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:29:38 --> Utf8 Class Initialized
INFO - 2016-05-19 15:29:38 --> URI Class Initialized
INFO - 2016-05-19 15:29:38 --> Router Class Initialized
INFO - 2016-05-19 15:29:38 --> Output Class Initialized
INFO - 2016-05-19 15:29:38 --> Security Class Initialized
DEBUG - 2016-05-19 15:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:29:38 --> CSRF cookie sent
INFO - 2016-05-19 15:29:38 --> Input Class Initialized
INFO - 2016-05-19 15:29:38 --> Language Class Initialized
INFO - 2016-05-19 15:29:38 --> Loader Class Initialized
INFO - 2016-05-19 15:29:38 --> Helper loaded: form_helper
INFO - 2016-05-19 15:29:38 --> Database Driver Class Initialized
INFO - 2016-05-19 15:29:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:29:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:29:38 --> Email Class Initialized
INFO - 2016-05-19 15:29:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:29:38 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:29:38 --> Helper loaded: language_helper
INFO - 2016-05-19 15:29:38 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:29:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:29:38 --> Model Class Initialized
INFO - 2016-05-19 15:29:38 --> Helper loaded: date_helper
INFO - 2016-05-19 15:29:38 --> Controller Class Initialized
INFO - 2016-05-19 15:29:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:29:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:29:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:29:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:29:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 15:29:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:29:38 --> Form Validation Class Initialized
ERROR - 2016-05-19 15:29:38 --> Severity: Notice --> Undefined property: Auth::$callType /home/demis/www/platformadiabet/application/core/SVS_Controller.php 116
INFO - 2016-05-19 15:29:38 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:29:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-19 15:29:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-19 15:29:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-19 15:29:38 --> Final output sent to browser
DEBUG - 2016-05-19 15:29:38 --> Total execution time: 0.1025
INFO - 2016-05-19 15:30:55 --> Config Class Initialized
INFO - 2016-05-19 15:30:55 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:30:55 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:30:55 --> Utf8 Class Initialized
INFO - 2016-05-19 15:30:55 --> URI Class Initialized
INFO - 2016-05-19 15:30:55 --> Router Class Initialized
INFO - 2016-05-19 15:30:55 --> Output Class Initialized
INFO - 2016-05-19 15:30:55 --> Security Class Initialized
DEBUG - 2016-05-19 15:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:30:55 --> CSRF cookie sent
INFO - 2016-05-19 15:30:55 --> CSRF token verified
INFO - 2016-05-19 15:30:55 --> Input Class Initialized
INFO - 2016-05-19 15:30:55 --> Language Class Initialized
INFO - 2016-05-19 15:30:55 --> Loader Class Initialized
INFO - 2016-05-19 15:30:55 --> Helper loaded: form_helper
INFO - 2016-05-19 15:30:55 --> Database Driver Class Initialized
INFO - 2016-05-19 15:30:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:30:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:30:55 --> Email Class Initialized
INFO - 2016-05-19 15:30:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:30:55 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:30:55 --> Helper loaded: language_helper
INFO - 2016-05-19 15:30:55 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:30:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:30:55 --> Model Class Initialized
INFO - 2016-05-19 15:30:55 --> Helper loaded: date_helper
INFO - 2016-05-19 15:30:55 --> Controller Class Initialized
INFO - 2016-05-19 15:30:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:30:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:30:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:30:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:30:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 15:30:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:30:55 --> Form Validation Class Initialized
INFO - 2016-05-19 15:30:57 --> Config Class Initialized
INFO - 2016-05-19 15:30:57 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:30:57 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:30:57 --> Utf8 Class Initialized
INFO - 2016-05-19 15:30:57 --> URI Class Initialized
DEBUG - 2016-05-19 15:30:57 --> No URI present. Default controller set.
INFO - 2016-05-19 15:30:57 --> Router Class Initialized
INFO - 2016-05-19 15:30:57 --> Output Class Initialized
INFO - 2016-05-19 15:30:57 --> Security Class Initialized
DEBUG - 2016-05-19 15:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:30:57 --> CSRF cookie sent
INFO - 2016-05-19 15:30:57 --> Input Class Initialized
INFO - 2016-05-19 15:30:57 --> Language Class Initialized
INFO - 2016-05-19 15:30:57 --> Loader Class Initialized
INFO - 2016-05-19 15:30:57 --> Helper loaded: form_helper
INFO - 2016-05-19 15:30:57 --> Database Driver Class Initialized
INFO - 2016-05-19 15:30:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:30:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:30:57 --> Email Class Initialized
INFO - 2016-05-19 15:30:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:30:57 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:30:57 --> Helper loaded: language_helper
INFO - 2016-05-19 15:30:57 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:30:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:30:57 --> Model Class Initialized
INFO - 2016-05-19 15:30:57 --> Helper loaded: date_helper
INFO - 2016-05-19 15:30:57 --> Controller Class Initialized
INFO - 2016-05-19 15:30:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:30:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:30:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:30:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:30:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:30:58 --> Config Class Initialized
INFO - 2016-05-19 15:30:58 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:30:58 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:30:58 --> Utf8 Class Initialized
INFO - 2016-05-19 15:30:58 --> URI Class Initialized
INFO - 2016-05-19 15:30:58 --> Router Class Initialized
INFO - 2016-05-19 15:30:58 --> Output Class Initialized
INFO - 2016-05-19 15:30:58 --> Security Class Initialized
DEBUG - 2016-05-19 15:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:30:58 --> CSRF cookie sent
INFO - 2016-05-19 15:30:58 --> Input Class Initialized
INFO - 2016-05-19 15:30:58 --> Language Class Initialized
INFO - 2016-05-19 15:30:58 --> Loader Class Initialized
INFO - 2016-05-19 15:30:58 --> Helper loaded: form_helper
INFO - 2016-05-19 15:30:58 --> Database Driver Class Initialized
INFO - 2016-05-19 15:30:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:30:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:30:58 --> Email Class Initialized
INFO - 2016-05-19 15:30:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:30:58 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:30:58 --> Helper loaded: language_helper
INFO - 2016-05-19 15:30:58 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:30:58 --> Model Class Initialized
INFO - 2016-05-19 15:30:58 --> Helper loaded: date_helper
INFO - 2016-05-19 15:30:58 --> Controller Class Initialized
INFO - 2016-05-19 15:30:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:30:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:30:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:30:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:30:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:30:58 --> Model Class Initialized
INFO - 2016-05-19 15:30:58 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 15:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:30:58 --> Final output sent to browser
DEBUG - 2016-05-19 15:30:58 --> Total execution time: 0.0465
INFO - 2016-05-19 15:31:03 --> Config Class Initialized
INFO - 2016-05-19 15:31:03 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:31:03 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:31:03 --> Utf8 Class Initialized
INFO - 2016-05-19 15:31:03 --> URI Class Initialized
INFO - 2016-05-19 15:31:03 --> Router Class Initialized
INFO - 2016-05-19 15:31:03 --> Output Class Initialized
INFO - 2016-05-19 15:31:03 --> Security Class Initialized
DEBUG - 2016-05-19 15:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:31:03 --> CSRF cookie sent
INFO - 2016-05-19 15:31:03 --> Input Class Initialized
INFO - 2016-05-19 15:31:03 --> Language Class Initialized
INFO - 2016-05-19 15:31:03 --> Loader Class Initialized
INFO - 2016-05-19 15:31:03 --> Helper loaded: form_helper
INFO - 2016-05-19 15:31:03 --> Database Driver Class Initialized
INFO - 2016-05-19 15:31:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:31:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:31:04 --> Email Class Initialized
INFO - 2016-05-19 15:31:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:31:04 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:31:04 --> Helper loaded: language_helper
INFO - 2016-05-19 15:31:04 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:31:04 --> Model Class Initialized
INFO - 2016-05-19 15:31:04 --> Helper loaded: date_helper
INFO - 2016-05-19 15:31:04 --> Controller Class Initialized
INFO - 2016-05-19 15:31:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:31:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:31:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:31:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:31:04 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 15:31:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:31:04 --> Form Validation Class Initialized
INFO - 2016-05-19 15:31:04 --> Helper loaded: string_helper
INFO - 2016-05-19 15:31:04 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:31:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:31:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:31:04 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-19 15:31:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:31:04 --> Final output sent to browser
DEBUG - 2016-05-19 15:31:04 --> Total execution time: 0.1554
INFO - 2016-05-19 15:31:17 --> Config Class Initialized
INFO - 2016-05-19 15:31:17 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:31:17 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:31:17 --> Utf8 Class Initialized
INFO - 2016-05-19 15:31:17 --> URI Class Initialized
INFO - 2016-05-19 15:31:17 --> Router Class Initialized
INFO - 2016-05-19 15:31:17 --> Output Class Initialized
INFO - 2016-05-19 15:31:17 --> Security Class Initialized
DEBUG - 2016-05-19 15:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:31:17 --> CSRF cookie sent
INFO - 2016-05-19 15:31:17 --> Input Class Initialized
INFO - 2016-05-19 15:31:17 --> Language Class Initialized
INFO - 2016-05-19 15:31:17 --> Loader Class Initialized
INFO - 2016-05-19 15:31:17 --> Helper loaded: form_helper
INFO - 2016-05-19 15:31:17 --> Database Driver Class Initialized
INFO - 2016-05-19 15:31:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:31:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:31:17 --> Email Class Initialized
INFO - 2016-05-19 15:31:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:31:17 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:31:17 --> Helper loaded: language_helper
INFO - 2016-05-19 15:31:17 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:31:17 --> Model Class Initialized
INFO - 2016-05-19 15:31:17 --> Helper loaded: date_helper
INFO - 2016-05-19 15:31:17 --> Controller Class Initialized
INFO - 2016-05-19 15:31:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:31:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:31:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:31:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:31:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:31:17 --> Model Class Initialized
INFO - 2016-05-19 15:31:17 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:31:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:31:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:31:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:31:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:31:17 --> Final output sent to browser
DEBUG - 2016-05-19 15:31:17 --> Total execution time: 0.0686
INFO - 2016-05-19 15:31:59 --> Config Class Initialized
INFO - 2016-05-19 15:31:59 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:31:59 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:31:59 --> Utf8 Class Initialized
INFO - 2016-05-19 15:31:59 --> URI Class Initialized
INFO - 2016-05-19 15:31:59 --> Router Class Initialized
INFO - 2016-05-19 15:31:59 --> Output Class Initialized
INFO - 2016-05-19 15:31:59 --> Security Class Initialized
DEBUG - 2016-05-19 15:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:31:59 --> CSRF cookie sent
INFO - 2016-05-19 15:31:59 --> CSRF token verified
INFO - 2016-05-19 15:31:59 --> Input Class Initialized
INFO - 2016-05-19 15:31:59 --> Language Class Initialized
INFO - 2016-05-19 15:31:59 --> Loader Class Initialized
INFO - 2016-05-19 15:31:59 --> Helper loaded: form_helper
INFO - 2016-05-19 15:31:59 --> Database Driver Class Initialized
INFO - 2016-05-19 15:31:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:31:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:31:59 --> Email Class Initialized
INFO - 2016-05-19 15:31:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:31:59 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:31:59 --> Helper loaded: language_helper
INFO - 2016-05-19 15:31:59 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:31:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:31:59 --> Model Class Initialized
INFO - 2016-05-19 15:31:59 --> Helper loaded: date_helper
INFO - 2016-05-19 15:31:59 --> Controller Class Initialized
INFO - 2016-05-19 15:31:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:31:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:31:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:31:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:31:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:31:59 --> Model Class Initialized
INFO - 2016-05-19 15:31:59 --> Form Validation Class Initialized
INFO - 2016-05-19 15:31:59 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:31:59 --> Final output sent to browser
DEBUG - 2016-05-19 15:31:59 --> Total execution time: 0.0642
INFO - 2016-05-19 15:32:11 --> Config Class Initialized
INFO - 2016-05-19 15:32:11 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:32:11 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:32:11 --> Utf8 Class Initialized
INFO - 2016-05-19 15:32:11 --> URI Class Initialized
INFO - 2016-05-19 15:32:11 --> Router Class Initialized
INFO - 2016-05-19 15:32:11 --> Output Class Initialized
INFO - 2016-05-19 15:32:11 --> Security Class Initialized
DEBUG - 2016-05-19 15:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:32:11 --> CSRF cookie sent
INFO - 2016-05-19 15:32:11 --> CSRF token verified
INFO - 2016-05-19 15:32:11 --> Input Class Initialized
INFO - 2016-05-19 15:32:11 --> Language Class Initialized
INFO - 2016-05-19 15:32:11 --> Loader Class Initialized
INFO - 2016-05-19 15:32:11 --> Helper loaded: form_helper
INFO - 2016-05-19 15:32:11 --> Database Driver Class Initialized
INFO - 2016-05-19 15:32:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:32:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:32:11 --> Email Class Initialized
INFO - 2016-05-19 15:32:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:32:11 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:32:11 --> Helper loaded: language_helper
INFO - 2016-05-19 15:32:11 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:32:11 --> Model Class Initialized
INFO - 2016-05-19 15:32:11 --> Helper loaded: date_helper
INFO - 2016-05-19 15:32:11 --> Controller Class Initialized
INFO - 2016-05-19 15:32:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:32:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:32:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:32:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:32:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:32:11 --> Model Class Initialized
INFO - 2016-05-19 15:32:11 --> Form Validation Class Initialized
ERROR - 2016-05-19 15:32:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4 - Invalid query: 
         INSERT IGNORE INTO `tokens`
                (`token`, `fk_user`, `name`, `email`, `type`, `_is_active`, `_create_date` )
         VALUES
                ('p5q2bKntvTWw8gCs6y7cGUFEXhDjIJL1','2','Tadam','tadam@yahoo.com','doctor','1'
INFO - 2016-05-19 15:32:49 --> Config Class Initialized
INFO - 2016-05-19 15:32:49 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:32:49 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:32:49 --> Utf8 Class Initialized
INFO - 2016-05-19 15:32:49 --> URI Class Initialized
INFO - 2016-05-19 15:32:49 --> Router Class Initialized
INFO - 2016-05-19 15:32:49 --> Output Class Initialized
INFO - 2016-05-19 15:32:49 --> Security Class Initialized
DEBUG - 2016-05-19 15:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:32:49 --> CSRF cookie sent
INFO - 2016-05-19 15:32:49 --> Input Class Initialized
INFO - 2016-05-19 15:32:49 --> Language Class Initialized
INFO - 2016-05-19 15:32:49 --> Loader Class Initialized
INFO - 2016-05-19 15:32:49 --> Helper loaded: form_helper
INFO - 2016-05-19 15:32:49 --> Database Driver Class Initialized
INFO - 2016-05-19 15:32:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:32:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:32:49 --> Email Class Initialized
INFO - 2016-05-19 15:32:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:32:49 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:32:49 --> Helper loaded: language_helper
INFO - 2016-05-19 15:32:49 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:32:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:32:49 --> Model Class Initialized
INFO - 2016-05-19 15:32:49 --> Helper loaded: date_helper
INFO - 2016-05-19 15:32:49 --> Controller Class Initialized
INFO - 2016-05-19 15:32:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:32:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:32:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:32:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:32:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:32:49 --> Model Class Initialized
INFO - 2016-05-19 15:32:49 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:32:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:32:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:32:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:32:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:32:49 --> Final output sent to browser
DEBUG - 2016-05-19 15:32:49 --> Total execution time: 0.0949
INFO - 2016-05-19 15:32:53 --> Config Class Initialized
INFO - 2016-05-19 15:32:53 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:32:53 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:32:53 --> Utf8 Class Initialized
INFO - 2016-05-19 15:32:53 --> URI Class Initialized
INFO - 2016-05-19 15:32:53 --> Router Class Initialized
INFO - 2016-05-19 15:32:53 --> Output Class Initialized
INFO - 2016-05-19 15:32:53 --> Security Class Initialized
DEBUG - 2016-05-19 15:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:32:53 --> CSRF cookie sent
INFO - 2016-05-19 15:32:53 --> CSRF token verified
INFO - 2016-05-19 15:32:53 --> Input Class Initialized
INFO - 2016-05-19 15:32:53 --> Language Class Initialized
INFO - 2016-05-19 15:32:53 --> Loader Class Initialized
INFO - 2016-05-19 15:32:53 --> Helper loaded: form_helper
INFO - 2016-05-19 15:32:53 --> Database Driver Class Initialized
INFO - 2016-05-19 15:32:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:32:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:32:53 --> Email Class Initialized
INFO - 2016-05-19 15:32:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:32:53 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:32:53 --> Helper loaded: language_helper
INFO - 2016-05-19 15:32:53 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:32:53 --> Model Class Initialized
INFO - 2016-05-19 15:32:53 --> Helper loaded: date_helper
INFO - 2016-05-19 15:32:53 --> Controller Class Initialized
INFO - 2016-05-19 15:32:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:32:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:32:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:32:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:32:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:32:53 --> Model Class Initialized
INFO - 2016-05-19 15:32:53 --> Form Validation Class Initialized
INFO - 2016-05-19 15:32:53 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:32:53 --> Final output sent to browser
DEBUG - 2016-05-19 15:32:53 --> Total execution time: 0.0794
INFO - 2016-05-19 15:33:03 --> Config Class Initialized
INFO - 2016-05-19 15:33:03 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:33:03 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:33:03 --> Utf8 Class Initialized
INFO - 2016-05-19 15:33:03 --> URI Class Initialized
INFO - 2016-05-19 15:33:03 --> Router Class Initialized
INFO - 2016-05-19 15:33:03 --> Output Class Initialized
INFO - 2016-05-19 15:33:03 --> Security Class Initialized
DEBUG - 2016-05-19 15:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:33:03 --> CSRF cookie sent
INFO - 2016-05-19 15:33:03 --> CSRF token verified
INFO - 2016-05-19 15:33:03 --> Input Class Initialized
INFO - 2016-05-19 15:33:03 --> Language Class Initialized
INFO - 2016-05-19 15:33:03 --> Loader Class Initialized
INFO - 2016-05-19 15:33:03 --> Helper loaded: form_helper
INFO - 2016-05-19 15:33:03 --> Database Driver Class Initialized
INFO - 2016-05-19 15:33:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:33:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:33:03 --> Email Class Initialized
INFO - 2016-05-19 15:33:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:33:03 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:33:03 --> Helper loaded: language_helper
INFO - 2016-05-19 15:33:03 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:33:03 --> Model Class Initialized
INFO - 2016-05-19 15:33:03 --> Helper loaded: date_helper
INFO - 2016-05-19 15:33:03 --> Controller Class Initialized
INFO - 2016-05-19 15:33:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:33:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:33:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:33:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:33:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:33:03 --> Model Class Initialized
INFO - 2016-05-19 15:33:03 --> Form Validation Class Initialized
ERROR - 2016-05-19 15:33:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4 - Invalid query: 
         INSERT IGNORE INTO `tokens`
                (`token`, `fk_user`, `name`, `email`, `type`, `_is_active` )
         VALUES
                ('5PN8m2YGlDbypx6igBLvErA0jqMSeuUn','2','Tadam','tadam@yahoo.com','doctor','1'
INFO - 2016-05-19 15:33:29 --> Config Class Initialized
INFO - 2016-05-19 15:33:29 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:33:29 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:33:29 --> Utf8 Class Initialized
INFO - 2016-05-19 15:33:29 --> URI Class Initialized
INFO - 2016-05-19 15:33:29 --> Router Class Initialized
INFO - 2016-05-19 15:33:29 --> Output Class Initialized
INFO - 2016-05-19 15:33:29 --> Security Class Initialized
DEBUG - 2016-05-19 15:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:33:29 --> CSRF cookie sent
INFO - 2016-05-19 15:33:29 --> Input Class Initialized
INFO - 2016-05-19 15:33:29 --> Language Class Initialized
INFO - 2016-05-19 15:33:29 --> Loader Class Initialized
INFO - 2016-05-19 15:33:29 --> Helper loaded: form_helper
INFO - 2016-05-19 15:33:29 --> Database Driver Class Initialized
INFO - 2016-05-19 15:33:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:33:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:33:29 --> Email Class Initialized
INFO - 2016-05-19 15:33:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:33:29 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:33:29 --> Helper loaded: language_helper
INFO - 2016-05-19 15:33:29 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:33:29 --> Model Class Initialized
INFO - 2016-05-19 15:33:29 --> Helper loaded: date_helper
INFO - 2016-05-19 15:33:29 --> Controller Class Initialized
INFO - 2016-05-19 15:33:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:33:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:33:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:33:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:33:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:33:29 --> Model Class Initialized
INFO - 2016-05-19 15:33:29 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:33:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:33:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:33:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:33:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:33:29 --> Final output sent to browser
DEBUG - 2016-05-19 15:33:29 --> Total execution time: 0.0804
INFO - 2016-05-19 15:33:41 --> Config Class Initialized
INFO - 2016-05-19 15:33:41 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:33:41 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:33:41 --> Utf8 Class Initialized
INFO - 2016-05-19 15:33:41 --> URI Class Initialized
INFO - 2016-05-19 15:33:41 --> Router Class Initialized
INFO - 2016-05-19 15:33:41 --> Output Class Initialized
INFO - 2016-05-19 15:33:41 --> Security Class Initialized
DEBUG - 2016-05-19 15:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:33:41 --> CSRF cookie sent
INFO - 2016-05-19 15:33:41 --> CSRF token verified
INFO - 2016-05-19 15:33:41 --> Input Class Initialized
INFO - 2016-05-19 15:33:41 --> Language Class Initialized
INFO - 2016-05-19 15:33:41 --> Loader Class Initialized
INFO - 2016-05-19 15:33:41 --> Helper loaded: form_helper
INFO - 2016-05-19 15:33:41 --> Database Driver Class Initialized
INFO - 2016-05-19 15:33:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:33:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:33:41 --> Email Class Initialized
INFO - 2016-05-19 15:33:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:33:41 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:33:41 --> Helper loaded: language_helper
INFO - 2016-05-19 15:33:41 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:33:41 --> Model Class Initialized
INFO - 2016-05-19 15:33:41 --> Helper loaded: date_helper
INFO - 2016-05-19 15:33:41 --> Controller Class Initialized
INFO - 2016-05-19 15:33:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:33:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:33:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:33:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:33:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:33:41 --> Model Class Initialized
INFO - 2016-05-19 15:33:41 --> Form Validation Class Initialized
DEBUG - 2016-05-19 15:33:41 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:33:43 --> Config Class Initialized
INFO - 2016-05-19 15:33:43 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:33:43 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:33:43 --> Utf8 Class Initialized
INFO - 2016-05-19 15:33:43 --> URI Class Initialized
INFO - 2016-05-19 15:33:43 --> Router Class Initialized
INFO - 2016-05-19 15:33:43 --> Output Class Initialized
INFO - 2016-05-19 15:33:43 --> Security Class Initialized
DEBUG - 2016-05-19 15:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:33:43 --> CSRF cookie sent
INFO - 2016-05-19 15:33:43 --> Input Class Initialized
INFO - 2016-05-19 15:33:43 --> Language Class Initialized
INFO - 2016-05-19 15:33:43 --> Loader Class Initialized
INFO - 2016-05-19 15:33:43 --> Helper loaded: form_helper
INFO - 2016-05-19 15:33:43 --> Database Driver Class Initialized
INFO - 2016-05-19 15:33:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:33:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:33:43 --> Email Class Initialized
INFO - 2016-05-19 15:33:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:33:43 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:33:43 --> Helper loaded: language_helper
INFO - 2016-05-19 15:33:43 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:33:43 --> Model Class Initialized
INFO - 2016-05-19 15:33:43 --> Helper loaded: date_helper
INFO - 2016-05-19 15:33:43 --> Controller Class Initialized
INFO - 2016-05-19 15:33:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:33:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:33:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:33:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:33:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:33:43 --> Model Class Initialized
INFO - 2016-05-19 15:33:43 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:33:43 --> Final output sent to browser
DEBUG - 2016-05-19 15:33:43 --> Total execution time: 0.0218
INFO - 2016-05-19 15:36:37 --> Config Class Initialized
INFO - 2016-05-19 15:36:37 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:36:37 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:36:37 --> Utf8 Class Initialized
INFO - 2016-05-19 15:36:37 --> URI Class Initialized
INFO - 2016-05-19 15:36:37 --> Router Class Initialized
INFO - 2016-05-19 15:36:37 --> Output Class Initialized
INFO - 2016-05-19 15:36:37 --> Security Class Initialized
DEBUG - 2016-05-19 15:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:36:37 --> CSRF cookie sent
INFO - 2016-05-19 15:36:37 --> Input Class Initialized
INFO - 2016-05-19 15:36:37 --> Language Class Initialized
INFO - 2016-05-19 15:36:37 --> Loader Class Initialized
INFO - 2016-05-19 15:36:37 --> Helper loaded: form_helper
INFO - 2016-05-19 15:36:37 --> Database Driver Class Initialized
INFO - 2016-05-19 15:36:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:36:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:36:37 --> Email Class Initialized
INFO - 2016-05-19 15:36:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:36:37 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:36:37 --> Helper loaded: language_helper
INFO - 2016-05-19 15:36:37 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:36:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:36:37 --> Model Class Initialized
INFO - 2016-05-19 15:36:37 --> Helper loaded: date_helper
INFO - 2016-05-19 15:36:37 --> Controller Class Initialized
INFO - 2016-05-19 15:36:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:36:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:36:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:36:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:36:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:36:37 --> Model Class Initialized
INFO - 2016-05-19 15:36:37 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:36:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:36:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 15:36:37 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/views/user_area/access.php 3
INFO - 2016-05-19 15:36:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:36:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:36:37 --> Final output sent to browser
DEBUG - 2016-05-19 15:36:37 --> Total execution time: 0.1030
INFO - 2016-05-19 15:37:00 --> Config Class Initialized
INFO - 2016-05-19 15:37:00 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:37:00 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:37:00 --> Utf8 Class Initialized
INFO - 2016-05-19 15:37:00 --> URI Class Initialized
INFO - 2016-05-19 15:37:00 --> Router Class Initialized
INFO - 2016-05-19 15:37:00 --> Output Class Initialized
INFO - 2016-05-19 15:37:00 --> Security Class Initialized
DEBUG - 2016-05-19 15:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:37:00 --> CSRF cookie sent
INFO - 2016-05-19 15:37:00 --> Input Class Initialized
INFO - 2016-05-19 15:37:00 --> Language Class Initialized
INFO - 2016-05-19 15:37:00 --> Loader Class Initialized
INFO - 2016-05-19 15:37:00 --> Helper loaded: form_helper
INFO - 2016-05-19 15:37:00 --> Database Driver Class Initialized
INFO - 2016-05-19 15:37:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:37:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:37:00 --> Email Class Initialized
INFO - 2016-05-19 15:37:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:37:00 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:37:00 --> Helper loaded: language_helper
INFO - 2016-05-19 15:37:00 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:37:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:37:00 --> Model Class Initialized
INFO - 2016-05-19 15:37:00 --> Helper loaded: date_helper
INFO - 2016-05-19 15:37:00 --> Controller Class Initialized
INFO - 2016-05-19 15:37:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:37:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:37:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:37:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:37:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:37:00 --> Model Class Initialized
INFO - 2016-05-19 15:37:00 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:37:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:37:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:38:35 --> Config Class Initialized
INFO - 2016-05-19 15:38:35 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:38:35 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:38:35 --> Utf8 Class Initialized
INFO - 2016-05-19 15:38:35 --> URI Class Initialized
INFO - 2016-05-19 15:38:35 --> Router Class Initialized
INFO - 2016-05-19 15:38:35 --> Output Class Initialized
INFO - 2016-05-19 15:38:35 --> Security Class Initialized
DEBUG - 2016-05-19 15:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:38:35 --> CSRF cookie sent
INFO - 2016-05-19 15:38:35 --> Input Class Initialized
INFO - 2016-05-19 15:38:35 --> Language Class Initialized
INFO - 2016-05-19 15:38:35 --> Loader Class Initialized
INFO - 2016-05-19 15:38:35 --> Helper loaded: form_helper
INFO - 2016-05-19 15:38:35 --> Database Driver Class Initialized
INFO - 2016-05-19 15:38:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:38:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:38:36 --> Email Class Initialized
INFO - 2016-05-19 15:38:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:38:36 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:38:36 --> Helper loaded: language_helper
INFO - 2016-05-19 15:38:36 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:38:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:38:36 --> Model Class Initialized
INFO - 2016-05-19 15:38:36 --> Helper loaded: date_helper
INFO - 2016-05-19 15:38:36 --> Controller Class Initialized
INFO - 2016-05-19 15:38:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:38:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:38:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:38:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:38:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:38:36 --> Model Class Initialized
INFO - 2016-05-19 15:38:36 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:38:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:38:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:38:58 --> Config Class Initialized
INFO - 2016-05-19 15:38:58 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:38:58 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:38:58 --> Utf8 Class Initialized
INFO - 2016-05-19 15:38:58 --> URI Class Initialized
INFO - 2016-05-19 15:38:58 --> Router Class Initialized
INFO - 2016-05-19 15:38:58 --> Output Class Initialized
INFO - 2016-05-19 15:38:58 --> Security Class Initialized
DEBUG - 2016-05-19 15:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:38:58 --> CSRF cookie sent
INFO - 2016-05-19 15:38:58 --> Input Class Initialized
INFO - 2016-05-19 15:38:58 --> Language Class Initialized
INFO - 2016-05-19 15:38:58 --> Loader Class Initialized
INFO - 2016-05-19 15:38:58 --> Helper loaded: form_helper
INFO - 2016-05-19 15:38:58 --> Database Driver Class Initialized
INFO - 2016-05-19 15:38:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:38:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:38:58 --> Email Class Initialized
INFO - 2016-05-19 15:38:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:38:58 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:38:58 --> Helper loaded: language_helper
INFO - 2016-05-19 15:38:58 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:38:58 --> Model Class Initialized
INFO - 2016-05-19 15:38:58 --> Helper loaded: date_helper
INFO - 2016-05-19 15:38:58 --> Controller Class Initialized
INFO - 2016-05-19 15:38:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:38:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:38:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:38:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:38:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:38:58 --> Model Class Initialized
INFO - 2016-05-19 15:38:58 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:38:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:38:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:44:18 --> Config Class Initialized
INFO - 2016-05-19 15:44:18 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:44:18 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:44:18 --> Utf8 Class Initialized
INFO - 2016-05-19 15:44:18 --> URI Class Initialized
INFO - 2016-05-19 15:44:18 --> Router Class Initialized
INFO - 2016-05-19 15:44:18 --> Output Class Initialized
INFO - 2016-05-19 15:44:18 --> Security Class Initialized
DEBUG - 2016-05-19 15:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:44:18 --> CSRF cookie sent
INFO - 2016-05-19 15:44:18 --> Input Class Initialized
INFO - 2016-05-19 15:44:18 --> Language Class Initialized
INFO - 2016-05-19 15:44:18 --> Loader Class Initialized
INFO - 2016-05-19 15:44:18 --> Helper loaded: form_helper
INFO - 2016-05-19 15:44:18 --> Database Driver Class Initialized
INFO - 2016-05-19 15:44:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:44:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:44:18 --> Email Class Initialized
INFO - 2016-05-19 15:44:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:44:18 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:44:18 --> Helper loaded: language_helper
INFO - 2016-05-19 15:44:18 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:44:18 --> Model Class Initialized
INFO - 2016-05-19 15:44:18 --> Helper loaded: date_helper
INFO - 2016-05-19 15:44:18 --> Controller Class Initialized
INFO - 2016-05-19 15:44:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:44:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:44:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:44:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:44:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:44:18 --> Model Class Initialized
INFO - 2016-05-19 15:44:18 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:44:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:44:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:44:32 --> Config Class Initialized
INFO - 2016-05-19 15:44:32 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:44:32 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:44:32 --> Utf8 Class Initialized
INFO - 2016-05-19 15:44:32 --> URI Class Initialized
INFO - 2016-05-19 15:44:32 --> Router Class Initialized
INFO - 2016-05-19 15:44:32 --> Output Class Initialized
INFO - 2016-05-19 15:44:32 --> Security Class Initialized
DEBUG - 2016-05-19 15:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:44:32 --> CSRF cookie sent
INFO - 2016-05-19 15:44:32 --> Input Class Initialized
INFO - 2016-05-19 15:44:32 --> Language Class Initialized
INFO - 2016-05-19 15:44:32 --> Loader Class Initialized
INFO - 2016-05-19 15:44:32 --> Helper loaded: form_helper
INFO - 2016-05-19 15:44:32 --> Database Driver Class Initialized
INFO - 2016-05-19 15:44:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:44:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:44:32 --> Email Class Initialized
INFO - 2016-05-19 15:44:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:44:32 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:44:32 --> Helper loaded: language_helper
INFO - 2016-05-19 15:44:32 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:44:32 --> Model Class Initialized
INFO - 2016-05-19 15:44:32 --> Helper loaded: date_helper
INFO - 2016-05-19 15:44:32 --> Controller Class Initialized
INFO - 2016-05-19 15:44:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:44:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:44:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:44:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:44:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:44:32 --> Model Class Initialized
INFO - 2016-05-19 15:44:32 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:44:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:44:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:44:41 --> Config Class Initialized
INFO - 2016-05-19 15:44:41 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:44:41 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:44:41 --> Utf8 Class Initialized
INFO - 2016-05-19 15:44:41 --> URI Class Initialized
INFO - 2016-05-19 15:44:41 --> Router Class Initialized
INFO - 2016-05-19 15:44:41 --> Output Class Initialized
INFO - 2016-05-19 15:44:41 --> Security Class Initialized
DEBUG - 2016-05-19 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:44:41 --> CSRF cookie sent
INFO - 2016-05-19 15:44:41 --> Input Class Initialized
INFO - 2016-05-19 15:44:41 --> Language Class Initialized
INFO - 2016-05-19 15:44:41 --> Loader Class Initialized
INFO - 2016-05-19 15:44:41 --> Helper loaded: form_helper
INFO - 2016-05-19 15:44:41 --> Database Driver Class Initialized
INFO - 2016-05-19 15:44:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:44:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:44:41 --> Email Class Initialized
INFO - 2016-05-19 15:44:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:44:41 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:44:41 --> Helper loaded: language_helper
INFO - 2016-05-19 15:44:41 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:44:41 --> Model Class Initialized
INFO - 2016-05-19 15:44:41 --> Helper loaded: date_helper
INFO - 2016-05-19 15:44:41 --> Controller Class Initialized
INFO - 2016-05-19 15:44:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:44:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:44:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:44:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:44:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:44:41 --> Model Class Initialized
INFO - 2016-05-19 15:44:41 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:44:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:50:47 --> Config Class Initialized
INFO - 2016-05-19 15:50:47 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:50:47 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:50:47 --> Utf8 Class Initialized
INFO - 2016-05-19 15:50:47 --> URI Class Initialized
INFO - 2016-05-19 15:50:47 --> Router Class Initialized
INFO - 2016-05-19 15:50:47 --> Output Class Initialized
INFO - 2016-05-19 15:50:47 --> Security Class Initialized
DEBUG - 2016-05-19 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:50:47 --> CSRF cookie sent
INFO - 2016-05-19 15:50:47 --> Input Class Initialized
INFO - 2016-05-19 15:50:47 --> Language Class Initialized
INFO - 2016-05-19 15:50:47 --> Loader Class Initialized
INFO - 2016-05-19 15:50:47 --> Helper loaded: form_helper
INFO - 2016-05-19 15:50:47 --> Database Driver Class Initialized
INFO - 2016-05-19 15:50:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:50:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:50:47 --> Email Class Initialized
INFO - 2016-05-19 15:50:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:50:47 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:50:47 --> Helper loaded: language_helper
INFO - 2016-05-19 15:50:47 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:50:47 --> Model Class Initialized
INFO - 2016-05-19 15:50:47 --> Helper loaded: date_helper
INFO - 2016-05-19 15:50:47 --> Controller Class Initialized
INFO - 2016-05-19 15:50:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:50:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:50:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:50:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:50:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:50:47 --> Model Class Initialized
INFO - 2016-05-19 15:50:47 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:50:47 --> Final output sent to browser
DEBUG - 2016-05-19 15:50:47 --> Total execution time: 0.0331
INFO - 2016-05-19 15:51:02 --> Config Class Initialized
INFO - 2016-05-19 15:51:02 --> Hooks Class Initialized
DEBUG - 2016-05-19 15:51:02 --> UTF-8 Support Enabled
INFO - 2016-05-19 15:51:02 --> Utf8 Class Initialized
INFO - 2016-05-19 15:51:02 --> URI Class Initialized
INFO - 2016-05-19 15:51:02 --> Router Class Initialized
INFO - 2016-05-19 15:51:02 --> Output Class Initialized
INFO - 2016-05-19 15:51:02 --> Security Class Initialized
DEBUG - 2016-05-19 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 15:51:02 --> CSRF cookie sent
INFO - 2016-05-19 15:51:02 --> Input Class Initialized
INFO - 2016-05-19 15:51:02 --> Language Class Initialized
INFO - 2016-05-19 15:51:02 --> Loader Class Initialized
INFO - 2016-05-19 15:51:02 --> Helper loaded: form_helper
INFO - 2016-05-19 15:51:02 --> Database Driver Class Initialized
INFO - 2016-05-19 15:51:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 15:51:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 15:51:02 --> Email Class Initialized
INFO - 2016-05-19 15:51:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 15:51:02 --> Helper loaded: cookie_helper
INFO - 2016-05-19 15:51:02 --> Helper loaded: language_helper
INFO - 2016-05-19 15:51:02 --> Helper loaded: url_helper
DEBUG - 2016-05-19 15:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 15:51:02 --> Model Class Initialized
INFO - 2016-05-19 15:51:02 --> Helper loaded: date_helper
INFO - 2016-05-19 15:51:02 --> Controller Class Initialized
INFO - 2016-05-19 15:51:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 15:51:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 15:51:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 15:51:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 15:51:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 15:51:02 --> Model Class Initialized
INFO - 2016-05-19 15:51:02 --> Helper loaded: languages_helper
INFO - 2016-05-19 15:51:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 15:51:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 15:51:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 15:51:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 15:51:02 --> Final output sent to browser
DEBUG - 2016-05-19 15:51:02 --> Total execution time: 0.0536
INFO - 2016-05-19 16:10:48 --> Config Class Initialized
INFO - 2016-05-19 16:10:48 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:10:48 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:10:48 --> Utf8 Class Initialized
INFO - 2016-05-19 16:10:48 --> URI Class Initialized
INFO - 2016-05-19 16:10:48 --> Router Class Initialized
INFO - 2016-05-19 16:10:48 --> Output Class Initialized
INFO - 2016-05-19 16:10:48 --> Security Class Initialized
DEBUG - 2016-05-19 16:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:10:48 --> CSRF cookie sent
INFO - 2016-05-19 16:10:48 --> CSRF token verified
INFO - 2016-05-19 16:10:48 --> Input Class Initialized
INFO - 2016-05-19 16:10:48 --> Language Class Initialized
INFO - 2016-05-19 16:10:48 --> Loader Class Initialized
INFO - 2016-05-19 16:10:48 --> Helper loaded: form_helper
INFO - 2016-05-19 16:10:48 --> Database Driver Class Initialized
INFO - 2016-05-19 16:10:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:10:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:10:48 --> Email Class Initialized
INFO - 2016-05-19 16:10:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:10:48 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:10:48 --> Helper loaded: language_helper
INFO - 2016-05-19 16:10:48 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:10:48 --> Model Class Initialized
INFO - 2016-05-19 16:10:48 --> Helper loaded: date_helper
INFO - 2016-05-19 16:10:48 --> Controller Class Initialized
INFO - 2016-05-19 16:10:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:10:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:10:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:10:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:10:48 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-19 16:10:48 --> Severity: Parsing Error --> syntax error, unexpected '"' /home/demis/www/platformadiabet/application/models/Diabet_model.php 129
INFO - 2016-05-19 16:11:04 --> Config Class Initialized
INFO - 2016-05-19 16:11:04 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:11:04 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:11:04 --> Utf8 Class Initialized
INFO - 2016-05-19 16:11:04 --> URI Class Initialized
INFO - 2016-05-19 16:11:04 --> Router Class Initialized
INFO - 2016-05-19 16:11:04 --> Output Class Initialized
INFO - 2016-05-19 16:11:04 --> Security Class Initialized
DEBUG - 2016-05-19 16:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:11:06 --> Config Class Initialized
INFO - 2016-05-19 16:11:06 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:11:06 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:11:06 --> Utf8 Class Initialized
INFO - 2016-05-19 16:11:06 --> URI Class Initialized
INFO - 2016-05-19 16:11:06 --> Router Class Initialized
INFO - 2016-05-19 16:11:06 --> Output Class Initialized
INFO - 2016-05-19 16:11:06 --> Security Class Initialized
DEBUG - 2016-05-19 16:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:11:06 --> CSRF cookie sent
INFO - 2016-05-19 16:11:06 --> Input Class Initialized
INFO - 2016-05-19 16:11:06 --> Language Class Initialized
INFO - 2016-05-19 16:11:06 --> Loader Class Initialized
INFO - 2016-05-19 16:11:06 --> Helper loaded: form_helper
INFO - 2016-05-19 16:11:06 --> Database Driver Class Initialized
INFO - 2016-05-19 16:11:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:11:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:11:06 --> Email Class Initialized
INFO - 2016-05-19 16:11:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:11:06 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:11:06 --> Helper loaded: language_helper
INFO - 2016-05-19 16:11:06 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:11:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:11:06 --> Model Class Initialized
INFO - 2016-05-19 16:11:06 --> Helper loaded: date_helper
INFO - 2016-05-19 16:11:06 --> Controller Class Initialized
INFO - 2016-05-19 16:11:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:11:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:11:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:11:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:11:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:11:06 --> Model Class Initialized
INFO - 2016-05-19 16:11:06 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:11:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:11:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:11:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:11:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:11:06 --> Final output sent to browser
DEBUG - 2016-05-19 16:11:06 --> Total execution time: 0.0496
INFO - 2016-05-19 16:11:10 --> Config Class Initialized
INFO - 2016-05-19 16:11:10 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:11:10 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:11:10 --> Utf8 Class Initialized
INFO - 2016-05-19 16:11:10 --> URI Class Initialized
INFO - 2016-05-19 16:11:10 --> Router Class Initialized
INFO - 2016-05-19 16:11:10 --> Output Class Initialized
INFO - 2016-05-19 16:11:10 --> Security Class Initialized
DEBUG - 2016-05-19 16:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:11:10 --> CSRF cookie sent
INFO - 2016-05-19 16:11:10 --> CSRF token verified
INFO - 2016-05-19 16:11:10 --> Input Class Initialized
INFO - 2016-05-19 16:11:10 --> Language Class Initialized
INFO - 2016-05-19 16:11:10 --> Loader Class Initialized
INFO - 2016-05-19 16:11:10 --> Helper loaded: form_helper
INFO - 2016-05-19 16:11:10 --> Database Driver Class Initialized
INFO - 2016-05-19 16:11:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:11:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:11:10 --> Email Class Initialized
INFO - 2016-05-19 16:11:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:11:10 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:11:10 --> Helper loaded: language_helper
INFO - 2016-05-19 16:11:10 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:11:10 --> Model Class Initialized
INFO - 2016-05-19 16:11:10 --> Helper loaded: date_helper
INFO - 2016-05-19 16:11:10 --> Controller Class Initialized
INFO - 2016-05-19 16:11:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:11:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:11:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:11:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:11:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:11:10 --> Model Class Initialized
INFO - 2016-05-19 16:11:10 --> Form Validation Class Initialized
ERROR - 2016-05-19 16:11:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?' at line 6 - Invalid query: 
			SELECT 
				`email`
            FROM 
            	`tokens`
            WHERE 
            	`email` = ?
INFO - 2016-05-19 16:17:37 --> Config Class Initialized
INFO - 2016-05-19 16:17:37 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:17:37 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:17:37 --> Utf8 Class Initialized
INFO - 2016-05-19 16:17:37 --> URI Class Initialized
INFO - 2016-05-19 16:17:37 --> Router Class Initialized
INFO - 2016-05-19 16:17:37 --> Output Class Initialized
INFO - 2016-05-19 16:17:37 --> Security Class Initialized
DEBUG - 2016-05-19 16:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:17:37 --> CSRF cookie sent
INFO - 2016-05-19 16:17:37 --> Input Class Initialized
INFO - 2016-05-19 16:17:37 --> Language Class Initialized
INFO - 2016-05-19 16:17:37 --> Loader Class Initialized
INFO - 2016-05-19 16:17:37 --> Helper loaded: form_helper
INFO - 2016-05-19 16:17:37 --> Database Driver Class Initialized
INFO - 2016-05-19 16:17:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:17:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:17:37 --> Email Class Initialized
INFO - 2016-05-19 16:17:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:17:37 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:17:37 --> Helper loaded: language_helper
INFO - 2016-05-19 16:17:37 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:17:37 --> Model Class Initialized
INFO - 2016-05-19 16:17:37 --> Helper loaded: date_helper
INFO - 2016-05-19 16:17:37 --> Controller Class Initialized
INFO - 2016-05-19 16:17:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:17:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:17:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:17:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:17:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:17:37 --> Model Class Initialized
INFO - 2016-05-19 16:17:37 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:17:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:17:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:17:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:17:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:17:37 --> Final output sent to browser
DEBUG - 2016-05-19 16:17:37 --> Total execution time: 0.0405
INFO - 2016-05-19 16:17:45 --> Config Class Initialized
INFO - 2016-05-19 16:17:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:17:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:17:45 --> Utf8 Class Initialized
INFO - 2016-05-19 16:17:45 --> URI Class Initialized
INFO - 2016-05-19 16:17:45 --> Router Class Initialized
INFO - 2016-05-19 16:17:45 --> Output Class Initialized
INFO - 2016-05-19 16:17:45 --> Security Class Initialized
DEBUG - 2016-05-19 16:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:17:45 --> CSRF cookie sent
INFO - 2016-05-19 16:17:45 --> CSRF token verified
INFO - 2016-05-19 16:17:45 --> Input Class Initialized
INFO - 2016-05-19 16:17:45 --> Language Class Initialized
INFO - 2016-05-19 16:17:45 --> Loader Class Initialized
INFO - 2016-05-19 16:17:45 --> Helper loaded: form_helper
INFO - 2016-05-19 16:17:45 --> Database Driver Class Initialized
INFO - 2016-05-19 16:17:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:17:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:17:45 --> Email Class Initialized
INFO - 2016-05-19 16:17:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:17:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:17:45 --> Helper loaded: language_helper
INFO - 2016-05-19 16:17:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:17:45 --> Model Class Initialized
INFO - 2016-05-19 16:17:45 --> Helper loaded: date_helper
INFO - 2016-05-19 16:17:45 --> Controller Class Initialized
INFO - 2016-05-19 16:17:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:17:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:17:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:17:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:17:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:17:45 --> Model Class Initialized
INFO - 2016-05-19 16:17:45 --> Form Validation Class Initialized
INFO - 2016-05-19 16:20:57 --> Config Class Initialized
INFO - 2016-05-19 16:20:57 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:20:57 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:20:57 --> Utf8 Class Initialized
INFO - 2016-05-19 16:20:57 --> URI Class Initialized
INFO - 2016-05-19 16:20:57 --> Router Class Initialized
INFO - 2016-05-19 16:20:57 --> Output Class Initialized
INFO - 2016-05-19 16:20:57 --> Security Class Initialized
DEBUG - 2016-05-19 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:20:57 --> CSRF cookie sent
INFO - 2016-05-19 16:20:57 --> Input Class Initialized
INFO - 2016-05-19 16:20:57 --> Language Class Initialized
INFO - 2016-05-19 16:20:57 --> Loader Class Initialized
INFO - 2016-05-19 16:20:57 --> Helper loaded: form_helper
INFO - 2016-05-19 16:20:57 --> Database Driver Class Initialized
INFO - 2016-05-19 16:20:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:20:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:20:57 --> Email Class Initialized
INFO - 2016-05-19 16:20:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:20:57 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:20:57 --> Helper loaded: language_helper
INFO - 2016-05-19 16:20:57 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:20:57 --> Model Class Initialized
INFO - 2016-05-19 16:20:57 --> Helper loaded: date_helper
INFO - 2016-05-19 16:20:57 --> Controller Class Initialized
INFO - 2016-05-19 16:20:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:20:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:20:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:20:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:20:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:20:57 --> Model Class Initialized
INFO - 2016-05-19 16:20:57 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:20:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:20:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:20:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:20:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:20:57 --> Final output sent to browser
DEBUG - 2016-05-19 16:20:57 --> Total execution time: 0.0896
INFO - 2016-05-19 16:21:23 --> Config Class Initialized
INFO - 2016-05-19 16:21:23 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:21:23 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:21:23 --> Utf8 Class Initialized
INFO - 2016-05-19 16:21:23 --> URI Class Initialized
INFO - 2016-05-19 16:21:23 --> Router Class Initialized
INFO - 2016-05-19 16:21:23 --> Output Class Initialized
INFO - 2016-05-19 16:21:23 --> Security Class Initialized
DEBUG - 2016-05-19 16:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:21:23 --> CSRF cookie sent
INFO - 2016-05-19 16:21:23 --> Input Class Initialized
INFO - 2016-05-19 16:21:23 --> Language Class Initialized
INFO - 2016-05-19 16:21:23 --> Loader Class Initialized
INFO - 2016-05-19 16:21:23 --> Helper loaded: form_helper
INFO - 2016-05-19 16:21:23 --> Database Driver Class Initialized
INFO - 2016-05-19 16:21:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:21:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:21:23 --> Email Class Initialized
INFO - 2016-05-19 16:21:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:21:23 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:21:23 --> Helper loaded: language_helper
INFO - 2016-05-19 16:21:23 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:21:23 --> Model Class Initialized
INFO - 2016-05-19 16:21:23 --> Helper loaded: date_helper
INFO - 2016-05-19 16:21:23 --> Controller Class Initialized
INFO - 2016-05-19 16:21:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:21:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:21:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:21:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:21:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:21:23 --> Model Class Initialized
INFO - 2016-05-19 16:21:23 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:21:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:21:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:21:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:21:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:21:23 --> Final output sent to browser
DEBUG - 2016-05-19 16:21:23 --> Total execution time: 0.0267
INFO - 2016-05-19 16:21:28 --> Config Class Initialized
INFO - 2016-05-19 16:21:28 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:21:28 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:21:28 --> Utf8 Class Initialized
INFO - 2016-05-19 16:21:28 --> URI Class Initialized
INFO - 2016-05-19 16:21:28 --> Router Class Initialized
INFO - 2016-05-19 16:21:28 --> Output Class Initialized
INFO - 2016-05-19 16:21:28 --> Security Class Initialized
DEBUG - 2016-05-19 16:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:21:28 --> CSRF cookie sent
INFO - 2016-05-19 16:21:28 --> CSRF token verified
INFO - 2016-05-19 16:21:28 --> Input Class Initialized
INFO - 2016-05-19 16:21:28 --> Language Class Initialized
INFO - 2016-05-19 16:21:28 --> Loader Class Initialized
INFO - 2016-05-19 16:21:28 --> Helper loaded: form_helper
INFO - 2016-05-19 16:21:28 --> Database Driver Class Initialized
INFO - 2016-05-19 16:21:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:21:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:21:28 --> Email Class Initialized
INFO - 2016-05-19 16:21:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:21:28 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:21:28 --> Helper loaded: language_helper
INFO - 2016-05-19 16:21:28 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:21:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:21:28 --> Model Class Initialized
INFO - 2016-05-19 16:21:28 --> Helper loaded: date_helper
INFO - 2016-05-19 16:21:28 --> Controller Class Initialized
INFO - 2016-05-19 16:21:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:21:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:21:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:21:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:21:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:21:28 --> Model Class Initialized
INFO - 2016-05-19 16:21:28 --> Form Validation Class Initialized
ERROR - 2016-05-19 16:21:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?' at line 6 - Invalid query: 
			SELECT 
				`email`
            FROM 
            	`tokens`
            WHERE 
            	`email` = ? 
INFO - 2016-05-19 16:22:30 --> Config Class Initialized
INFO - 2016-05-19 16:22:30 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:22:30 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:22:30 --> Utf8 Class Initialized
INFO - 2016-05-19 16:22:30 --> URI Class Initialized
INFO - 2016-05-19 16:22:30 --> Router Class Initialized
INFO - 2016-05-19 16:22:30 --> Output Class Initialized
INFO - 2016-05-19 16:22:30 --> Security Class Initialized
DEBUG - 2016-05-19 16:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:22:30 --> CSRF cookie sent
INFO - 2016-05-19 16:22:30 --> Input Class Initialized
INFO - 2016-05-19 16:22:30 --> Language Class Initialized
INFO - 2016-05-19 16:22:30 --> Loader Class Initialized
INFO - 2016-05-19 16:22:30 --> Helper loaded: form_helper
INFO - 2016-05-19 16:22:30 --> Database Driver Class Initialized
INFO - 2016-05-19 16:22:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:22:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:22:30 --> Email Class Initialized
INFO - 2016-05-19 16:22:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:22:30 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:22:30 --> Helper loaded: language_helper
INFO - 2016-05-19 16:22:30 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:22:30 --> Model Class Initialized
INFO - 2016-05-19 16:22:30 --> Helper loaded: date_helper
INFO - 2016-05-19 16:22:30 --> Controller Class Initialized
INFO - 2016-05-19 16:22:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:22:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:22:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:22:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:22:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:22:30 --> Model Class Initialized
INFO - 2016-05-19 16:22:30 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:22:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:22:30 --> Final output sent to browser
DEBUG - 2016-05-19 16:22:30 --> Total execution time: 0.0353
INFO - 2016-05-19 16:22:36 --> Config Class Initialized
INFO - 2016-05-19 16:22:36 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:22:36 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:22:36 --> Utf8 Class Initialized
INFO - 2016-05-19 16:22:36 --> URI Class Initialized
INFO - 2016-05-19 16:22:36 --> Router Class Initialized
INFO - 2016-05-19 16:22:36 --> Output Class Initialized
INFO - 2016-05-19 16:22:36 --> Security Class Initialized
DEBUG - 2016-05-19 16:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:22:36 --> CSRF cookie sent
INFO - 2016-05-19 16:22:36 --> CSRF token verified
INFO - 2016-05-19 16:22:36 --> Input Class Initialized
INFO - 2016-05-19 16:22:36 --> Language Class Initialized
INFO - 2016-05-19 16:22:36 --> Loader Class Initialized
INFO - 2016-05-19 16:22:36 --> Helper loaded: form_helper
INFO - 2016-05-19 16:22:36 --> Database Driver Class Initialized
INFO - 2016-05-19 16:22:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:22:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:22:36 --> Email Class Initialized
INFO - 2016-05-19 16:22:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:22:36 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:22:36 --> Helper loaded: language_helper
INFO - 2016-05-19 16:22:36 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:22:36 --> Model Class Initialized
INFO - 2016-05-19 16:22:36 --> Helper loaded: date_helper
INFO - 2016-05-19 16:22:36 --> Controller Class Initialized
INFO - 2016-05-19 16:22:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:22:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:22:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:22:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:22:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:22:36 --> Model Class Initialized
INFO - 2016-05-19 16:22:36 --> Form Validation Class Initialized
ERROR - 2016-05-19 16:22:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 6 - Invalid query: 
			SELECT 
				`email`
            FROM 
            	`tokens`
            WHERE 
            	`email` = 
        	
INFO - 2016-05-19 16:22:51 --> Config Class Initialized
INFO - 2016-05-19 16:22:51 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:22:51 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:22:51 --> Utf8 Class Initialized
INFO - 2016-05-19 16:22:51 --> URI Class Initialized
INFO - 2016-05-19 16:22:51 --> Router Class Initialized
INFO - 2016-05-19 16:22:51 --> Output Class Initialized
INFO - 2016-05-19 16:22:51 --> Security Class Initialized
DEBUG - 2016-05-19 16:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:22:51 --> CSRF cookie sent
INFO - 2016-05-19 16:22:51 --> Input Class Initialized
INFO - 2016-05-19 16:22:51 --> Language Class Initialized
INFO - 2016-05-19 16:22:51 --> Loader Class Initialized
INFO - 2016-05-19 16:22:51 --> Helper loaded: form_helper
INFO - 2016-05-19 16:22:51 --> Database Driver Class Initialized
INFO - 2016-05-19 16:22:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:22:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:22:51 --> Email Class Initialized
INFO - 2016-05-19 16:22:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:22:51 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:22:51 --> Helper loaded: language_helper
INFO - 2016-05-19 16:22:51 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:22:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:22:51 --> Model Class Initialized
INFO - 2016-05-19 16:22:51 --> Helper loaded: date_helper
INFO - 2016-05-19 16:22:51 --> Controller Class Initialized
INFO - 2016-05-19 16:22:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:22:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:22:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:22:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:22:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:22:51 --> Model Class Initialized
INFO - 2016-05-19 16:22:51 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:22:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:22:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:22:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:22:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:22:51 --> Final output sent to browser
DEBUG - 2016-05-19 16:22:51 --> Total execution time: 0.0290
INFO - 2016-05-19 16:24:52 --> Config Class Initialized
INFO - 2016-05-19 16:24:52 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:24:52 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:24:52 --> Utf8 Class Initialized
INFO - 2016-05-19 16:24:52 --> URI Class Initialized
INFO - 2016-05-19 16:24:52 --> Router Class Initialized
INFO - 2016-05-19 16:24:52 --> Output Class Initialized
INFO - 2016-05-19 16:24:52 --> Security Class Initialized
DEBUG - 2016-05-19 16:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:24:52 --> CSRF cookie sent
INFO - 2016-05-19 16:24:52 --> CSRF token verified
INFO - 2016-05-19 16:24:52 --> Input Class Initialized
INFO - 2016-05-19 16:24:52 --> Language Class Initialized
INFO - 2016-05-19 16:24:52 --> Loader Class Initialized
INFO - 2016-05-19 16:24:52 --> Helper loaded: form_helper
INFO - 2016-05-19 16:24:52 --> Database Driver Class Initialized
INFO - 2016-05-19 16:24:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:24:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:24:52 --> Email Class Initialized
INFO - 2016-05-19 16:24:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:24:52 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:24:52 --> Helper loaded: language_helper
INFO - 2016-05-19 16:24:52 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:24:52 --> Model Class Initialized
INFO - 2016-05-19 16:24:52 --> Helper loaded: date_helper
INFO - 2016-05-19 16:24:52 --> Controller Class Initialized
INFO - 2016-05-19 16:24:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:24:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:24:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:24:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:24:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:24:52 --> Model Class Initialized
INFO - 2016-05-19 16:24:52 --> Form Validation Class Initialized
INFO - 2016-05-19 16:24:52 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:24:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:24:52 --> Final output sent to browser
DEBUG - 2016-05-19 16:24:52 --> Total execution time: 0.0684
INFO - 2016-05-19 16:25:14 --> Config Class Initialized
INFO - 2016-05-19 16:25:14 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:25:14 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:25:14 --> Utf8 Class Initialized
INFO - 2016-05-19 16:25:14 --> URI Class Initialized
INFO - 2016-05-19 16:25:14 --> Router Class Initialized
INFO - 2016-05-19 16:25:14 --> Output Class Initialized
INFO - 2016-05-19 16:25:14 --> Security Class Initialized
DEBUG - 2016-05-19 16:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:25:14 --> CSRF cookie sent
INFO - 2016-05-19 16:25:14 --> CSRF token verified
INFO - 2016-05-19 16:25:14 --> Input Class Initialized
INFO - 2016-05-19 16:25:14 --> Language Class Initialized
INFO - 2016-05-19 16:25:14 --> Loader Class Initialized
INFO - 2016-05-19 16:25:14 --> Helper loaded: form_helper
INFO - 2016-05-19 16:25:14 --> Database Driver Class Initialized
INFO - 2016-05-19 16:25:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:25:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:25:14 --> Email Class Initialized
INFO - 2016-05-19 16:25:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:25:14 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:25:14 --> Helper loaded: language_helper
INFO - 2016-05-19 16:25:14 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:25:14 --> Model Class Initialized
INFO - 2016-05-19 16:25:14 --> Helper loaded: date_helper
INFO - 2016-05-19 16:25:14 --> Controller Class Initialized
INFO - 2016-05-19 16:25:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:25:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:25:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:25:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:25:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:25:14 --> Model Class Initialized
INFO - 2016-05-19 16:25:14 --> Form Validation Class Initialized
ERROR - 2016-05-19 16:25:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@zupathemes.com' at line 6 - Invalid query: 
			SELECT 
				`email`
            FROM 
            	`tokens`
            WHERE 
            	`email` = support@zupathemes.com
        	
INFO - 2016-05-19 16:30:04 --> Config Class Initialized
INFO - 2016-05-19 16:30:04 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:30:04 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:30:04 --> Utf8 Class Initialized
INFO - 2016-05-19 16:30:04 --> URI Class Initialized
INFO - 2016-05-19 16:30:04 --> Router Class Initialized
INFO - 2016-05-19 16:30:04 --> Output Class Initialized
INFO - 2016-05-19 16:30:04 --> Security Class Initialized
DEBUG - 2016-05-19 16:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:30:04 --> CSRF cookie sent
INFO - 2016-05-19 16:30:04 --> Input Class Initialized
INFO - 2016-05-19 16:30:04 --> Language Class Initialized
INFO - 2016-05-19 16:30:04 --> Loader Class Initialized
INFO - 2016-05-19 16:30:04 --> Helper loaded: form_helper
INFO - 2016-05-19 16:30:04 --> Database Driver Class Initialized
INFO - 2016-05-19 16:30:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:30:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:30:04 --> Email Class Initialized
INFO - 2016-05-19 16:30:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:30:04 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:30:04 --> Helper loaded: language_helper
INFO - 2016-05-19 16:30:04 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:30:04 --> Model Class Initialized
INFO - 2016-05-19 16:30:04 --> Helper loaded: date_helper
INFO - 2016-05-19 16:30:04 --> Controller Class Initialized
INFO - 2016-05-19 16:30:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:30:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:30:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:30:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:30:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:30:04 --> Model Class Initialized
INFO - 2016-05-19 16:30:04 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:30:04 --> Final output sent to browser
DEBUG - 2016-05-19 16:30:04 --> Total execution time: 0.0999
INFO - 2016-05-19 16:30:15 --> Config Class Initialized
INFO - 2016-05-19 16:30:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:30:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:30:15 --> Utf8 Class Initialized
INFO - 2016-05-19 16:30:15 --> URI Class Initialized
INFO - 2016-05-19 16:30:15 --> Router Class Initialized
INFO - 2016-05-19 16:30:15 --> Output Class Initialized
INFO - 2016-05-19 16:30:15 --> Security Class Initialized
DEBUG - 2016-05-19 16:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:30:15 --> CSRF cookie sent
INFO - 2016-05-19 16:30:15 --> CSRF token verified
INFO - 2016-05-19 16:30:15 --> Input Class Initialized
INFO - 2016-05-19 16:30:15 --> Language Class Initialized
INFO - 2016-05-19 16:30:15 --> Loader Class Initialized
INFO - 2016-05-19 16:30:15 --> Helper loaded: form_helper
INFO - 2016-05-19 16:30:15 --> Database Driver Class Initialized
INFO - 2016-05-19 16:30:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:30:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:30:15 --> Email Class Initialized
INFO - 2016-05-19 16:30:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:30:15 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:30:15 --> Helper loaded: language_helper
INFO - 2016-05-19 16:30:15 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:30:15 --> Model Class Initialized
INFO - 2016-05-19 16:30:15 --> Helper loaded: date_helper
INFO - 2016-05-19 16:30:15 --> Controller Class Initialized
INFO - 2016-05-19 16:30:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:30:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:30:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:30:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:30:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:30:15 --> Model Class Initialized
INFO - 2016-05-19 16:30:15 --> Form Validation Class Initialized
ERROR - 2016-05-19 16:30:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@yahoo.com' at line 1 - Invalid query: SELECT `email` FROM `tokens` WHERE `email` = tadam@yahoo.com
INFO - 2016-05-19 16:32:23 --> Config Class Initialized
INFO - 2016-05-19 16:32:23 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:32:23 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:32:23 --> Utf8 Class Initialized
INFO - 2016-05-19 16:32:23 --> URI Class Initialized
INFO - 2016-05-19 16:32:23 --> Router Class Initialized
INFO - 2016-05-19 16:32:23 --> Output Class Initialized
INFO - 2016-05-19 16:32:23 --> Security Class Initialized
DEBUG - 2016-05-19 16:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:32:23 --> CSRF cookie sent
INFO - 2016-05-19 16:32:23 --> Input Class Initialized
INFO - 2016-05-19 16:32:23 --> Language Class Initialized
INFO - 2016-05-19 16:32:23 --> Loader Class Initialized
INFO - 2016-05-19 16:32:23 --> Helper loaded: form_helper
INFO - 2016-05-19 16:32:23 --> Database Driver Class Initialized
INFO - 2016-05-19 16:32:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:32:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:32:23 --> Email Class Initialized
INFO - 2016-05-19 16:32:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:32:23 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:32:23 --> Helper loaded: language_helper
INFO - 2016-05-19 16:32:23 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:32:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:32:23 --> Model Class Initialized
INFO - 2016-05-19 16:32:23 --> Helper loaded: date_helper
INFO - 2016-05-19 16:32:23 --> Controller Class Initialized
INFO - 2016-05-19 16:32:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:32:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:32:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:32:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:32:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:32:23 --> Model Class Initialized
INFO - 2016-05-19 16:32:23 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:32:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:32:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:32:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:32:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:32:23 --> Final output sent to browser
DEBUG - 2016-05-19 16:32:23 --> Total execution time: 0.0498
INFO - 2016-05-19 16:32:27 --> Config Class Initialized
INFO - 2016-05-19 16:32:27 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:32:27 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:32:27 --> Utf8 Class Initialized
INFO - 2016-05-19 16:32:27 --> URI Class Initialized
INFO - 2016-05-19 16:32:27 --> Router Class Initialized
INFO - 2016-05-19 16:32:27 --> Output Class Initialized
INFO - 2016-05-19 16:32:27 --> Security Class Initialized
DEBUG - 2016-05-19 16:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:32:27 --> CSRF cookie sent
INFO - 2016-05-19 16:32:27 --> Input Class Initialized
INFO - 2016-05-19 16:32:27 --> Language Class Initialized
INFO - 2016-05-19 16:32:27 --> Loader Class Initialized
INFO - 2016-05-19 16:32:27 --> Helper loaded: form_helper
INFO - 2016-05-19 16:32:27 --> Database Driver Class Initialized
INFO - 2016-05-19 16:32:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:32:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:32:27 --> Email Class Initialized
INFO - 2016-05-19 16:32:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:32:27 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:32:27 --> Helper loaded: language_helper
INFO - 2016-05-19 16:32:27 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:32:27 --> Model Class Initialized
INFO - 2016-05-19 16:32:27 --> Helper loaded: date_helper
INFO - 2016-05-19 16:32:27 --> Controller Class Initialized
INFO - 2016-05-19 16:32:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:32:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:32:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:32:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:32:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:32:27 --> Model Class Initialized
INFO - 2016-05-19 16:32:27 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:32:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:32:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:32:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:32:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:32:27 --> Final output sent to browser
DEBUG - 2016-05-19 16:32:27 --> Total execution time: 0.1010
INFO - 2016-05-19 16:32:35 --> Config Class Initialized
INFO - 2016-05-19 16:32:35 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:32:35 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:32:35 --> Utf8 Class Initialized
INFO - 2016-05-19 16:32:35 --> URI Class Initialized
INFO - 2016-05-19 16:32:35 --> Router Class Initialized
INFO - 2016-05-19 16:32:35 --> Output Class Initialized
INFO - 2016-05-19 16:32:35 --> Security Class Initialized
DEBUG - 2016-05-19 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:32:35 --> CSRF cookie sent
INFO - 2016-05-19 16:32:35 --> CSRF token verified
INFO - 2016-05-19 16:32:35 --> Input Class Initialized
INFO - 2016-05-19 16:32:35 --> Language Class Initialized
INFO - 2016-05-19 16:32:35 --> Loader Class Initialized
INFO - 2016-05-19 16:32:35 --> Helper loaded: form_helper
INFO - 2016-05-19 16:32:35 --> Database Driver Class Initialized
INFO - 2016-05-19 16:32:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:32:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:32:35 --> Email Class Initialized
INFO - 2016-05-19 16:32:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:32:35 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:32:35 --> Helper loaded: language_helper
INFO - 2016-05-19 16:32:35 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:32:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:32:35 --> Model Class Initialized
INFO - 2016-05-19 16:32:35 --> Helper loaded: date_helper
INFO - 2016-05-19 16:32:35 --> Controller Class Initialized
INFO - 2016-05-19 16:32:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:32:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:32:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:32:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:32:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:32:35 --> Model Class Initialized
INFO - 2016-05-19 16:32:35 --> Form Validation Class Initialized
INFO - 2016-05-19 16:32:35 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:32:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:32:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:32:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:32:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:32:35 --> Final output sent to browser
DEBUG - 2016-05-19 16:32:35 --> Total execution time: 0.0610
INFO - 2016-05-19 16:35:57 --> Config Class Initialized
INFO - 2016-05-19 16:35:57 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:35:57 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:35:57 --> Utf8 Class Initialized
INFO - 2016-05-19 16:35:57 --> URI Class Initialized
INFO - 2016-05-19 16:35:57 --> Router Class Initialized
INFO - 2016-05-19 16:35:57 --> Output Class Initialized
INFO - 2016-05-19 16:35:57 --> Security Class Initialized
DEBUG - 2016-05-19 16:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:00 --> Config Class Initialized
INFO - 2016-05-19 16:36:00 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:36:00 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:36:00 --> Utf8 Class Initialized
INFO - 2016-05-19 16:36:00 --> URI Class Initialized
INFO - 2016-05-19 16:36:00 --> Router Class Initialized
INFO - 2016-05-19 16:36:00 --> Output Class Initialized
INFO - 2016-05-19 16:36:00 --> Security Class Initialized
DEBUG - 2016-05-19 16:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:00 --> CSRF cookie sent
INFO - 2016-05-19 16:36:00 --> Input Class Initialized
INFO - 2016-05-19 16:36:00 --> Language Class Initialized
INFO - 2016-05-19 16:36:00 --> Loader Class Initialized
INFO - 2016-05-19 16:36:00 --> Helper loaded: form_helper
INFO - 2016-05-19 16:36:00 --> Database Driver Class Initialized
INFO - 2016-05-19 16:36:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:36:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:36:00 --> Email Class Initialized
INFO - 2016-05-19 16:36:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:36:00 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:36:00 --> Helper loaded: language_helper
INFO - 2016-05-19 16:36:00 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:36:00 --> Model Class Initialized
INFO - 2016-05-19 16:36:00 --> Helper loaded: date_helper
INFO - 2016-05-19 16:36:00 --> Controller Class Initialized
INFO - 2016-05-19 16:36:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:36:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:36:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:36:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:36:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:36:00 --> Model Class Initialized
INFO - 2016-05-19 16:36:00 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:36:00 --> Final output sent to browser
DEBUG - 2016-05-19 16:36:00 --> Total execution time: 0.0821
INFO - 2016-05-19 16:36:07 --> Config Class Initialized
INFO - 2016-05-19 16:36:07 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:36:07 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:36:07 --> Utf8 Class Initialized
INFO - 2016-05-19 16:36:07 --> URI Class Initialized
INFO - 2016-05-19 16:36:07 --> Router Class Initialized
INFO - 2016-05-19 16:36:07 --> Output Class Initialized
INFO - 2016-05-19 16:36:07 --> Security Class Initialized
DEBUG - 2016-05-19 16:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:07 --> CSRF cookie sent
INFO - 2016-05-19 16:36:07 --> CSRF token verified
INFO - 2016-05-19 16:36:07 --> Input Class Initialized
INFO - 2016-05-19 16:36:07 --> Language Class Initialized
INFO - 2016-05-19 16:36:07 --> Loader Class Initialized
INFO - 2016-05-19 16:36:07 --> Helper loaded: form_helper
INFO - 2016-05-19 16:36:07 --> Database Driver Class Initialized
INFO - 2016-05-19 16:36:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:36:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:36:07 --> Email Class Initialized
INFO - 2016-05-19 16:36:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:36:07 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:36:07 --> Helper loaded: language_helper
INFO - 2016-05-19 16:36:07 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:36:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:36:07 --> Model Class Initialized
INFO - 2016-05-19 16:36:07 --> Helper loaded: date_helper
INFO - 2016-05-19 16:36:07 --> Controller Class Initialized
INFO - 2016-05-19 16:36:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:36:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:36:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:36:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:36:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:36:07 --> Model Class Initialized
INFO - 2016-05-19 16:36:07 --> Form Validation Class Initialized
INFO - 2016-05-19 16:36:07 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:36:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:36:07 --> Final output sent to browser
DEBUG - 2016-05-19 16:36:07 --> Total execution time: 0.0442
INFO - 2016-05-19 16:36:18 --> Config Class Initialized
INFO - 2016-05-19 16:36:18 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:36:18 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:36:18 --> Utf8 Class Initialized
INFO - 2016-05-19 16:36:18 --> URI Class Initialized
INFO - 2016-05-19 16:36:18 --> Router Class Initialized
INFO - 2016-05-19 16:36:18 --> Output Class Initialized
INFO - 2016-05-19 16:36:18 --> Security Class Initialized
DEBUG - 2016-05-19 16:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:18 --> CSRF cookie sent
INFO - 2016-05-19 16:36:18 --> CSRF token verified
INFO - 2016-05-19 16:36:18 --> Input Class Initialized
INFO - 2016-05-19 16:36:18 --> Language Class Initialized
INFO - 2016-05-19 16:36:18 --> Loader Class Initialized
INFO - 2016-05-19 16:36:18 --> Helper loaded: form_helper
INFO - 2016-05-19 16:36:18 --> Database Driver Class Initialized
INFO - 2016-05-19 16:36:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:36:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:36:18 --> Email Class Initialized
INFO - 2016-05-19 16:36:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:36:18 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:36:18 --> Helper loaded: language_helper
INFO - 2016-05-19 16:36:18 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:36:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:36:18 --> Model Class Initialized
INFO - 2016-05-19 16:36:18 --> Helper loaded: date_helper
INFO - 2016-05-19 16:36:18 --> Controller Class Initialized
INFO - 2016-05-19 16:36:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:36:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:36:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:36:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:36:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:36:18 --> Model Class Initialized
INFO - 2016-05-19 16:36:18 --> Form Validation Class Initialized
INFO - 2016-05-19 16:36:18 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:36:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:36:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:36:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:36:19 --> Final output sent to browser
DEBUG - 2016-05-19 16:36:19 --> Total execution time: 0.0492
INFO - 2016-05-19 16:36:43 --> Config Class Initialized
INFO - 2016-05-19 16:36:43 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:36:43 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:36:43 --> Utf8 Class Initialized
INFO - 2016-05-19 16:36:43 --> URI Class Initialized
INFO - 2016-05-19 16:36:43 --> Router Class Initialized
INFO - 2016-05-19 16:36:43 --> Output Class Initialized
INFO - 2016-05-19 16:36:43 --> Security Class Initialized
DEBUG - 2016-05-19 16:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:43 --> CSRF cookie sent
INFO - 2016-05-19 16:36:43 --> Input Class Initialized
INFO - 2016-05-19 16:36:43 --> Language Class Initialized
INFO - 2016-05-19 16:36:43 --> Loader Class Initialized
INFO - 2016-05-19 16:36:43 --> Helper loaded: form_helper
INFO - 2016-05-19 16:36:43 --> Database Driver Class Initialized
INFO - 2016-05-19 16:36:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:36:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:36:43 --> Email Class Initialized
INFO - 2016-05-19 16:36:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:36:43 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:36:43 --> Helper loaded: language_helper
INFO - 2016-05-19 16:36:43 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:36:43 --> Model Class Initialized
INFO - 2016-05-19 16:36:43 --> Helper loaded: date_helper
INFO - 2016-05-19 16:36:43 --> Controller Class Initialized
INFO - 2016-05-19 16:36:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:36:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:36:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:36:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:36:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:36:43 --> Model Class Initialized
INFO - 2016-05-19 16:36:45 --> Config Class Initialized
INFO - 2016-05-19 16:36:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:36:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:36:45 --> Utf8 Class Initialized
INFO - 2016-05-19 16:36:45 --> URI Class Initialized
INFO - 2016-05-19 16:36:45 --> Router Class Initialized
INFO - 2016-05-19 16:36:45 --> Output Class Initialized
INFO - 2016-05-19 16:36:45 --> Security Class Initialized
DEBUG - 2016-05-19 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:45 --> CSRF cookie sent
INFO - 2016-05-19 16:36:45 --> Input Class Initialized
INFO - 2016-05-19 16:36:45 --> Language Class Initialized
INFO - 2016-05-19 16:36:45 --> Loader Class Initialized
INFO - 2016-05-19 16:36:45 --> Helper loaded: form_helper
INFO - 2016-05-19 16:36:45 --> Database Driver Class Initialized
INFO - 2016-05-19 16:36:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:36:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:36:45 --> Email Class Initialized
INFO - 2016-05-19 16:36:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:36:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:36:45 --> Helper loaded: language_helper
INFO - 2016-05-19 16:36:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:36:45 --> Model Class Initialized
INFO - 2016-05-19 16:36:45 --> Helper loaded: date_helper
INFO - 2016-05-19 16:36:45 --> Controller Class Initialized
INFO - 2016-05-19 16:36:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:36:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:36:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:36:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:36:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:36:45 --> Model Class Initialized
INFO - 2016-05-19 16:36:45 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:36:45 --> Final output sent to browser
DEBUG - 2016-05-19 16:36:45 --> Total execution time: 0.0206
INFO - 2016-05-19 16:36:50 --> Config Class Initialized
INFO - 2016-05-19 16:36:50 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:36:50 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:36:50 --> Utf8 Class Initialized
INFO - 2016-05-19 16:36:50 --> URI Class Initialized
INFO - 2016-05-19 16:36:50 --> Router Class Initialized
INFO - 2016-05-19 16:36:50 --> Output Class Initialized
INFO - 2016-05-19 16:36:50 --> Security Class Initialized
DEBUG - 2016-05-19 16:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:50 --> CSRF cookie sent
INFO - 2016-05-19 16:36:50 --> CSRF token verified
INFO - 2016-05-19 16:36:50 --> Input Class Initialized
INFO - 2016-05-19 16:36:50 --> Language Class Initialized
INFO - 2016-05-19 16:36:50 --> Loader Class Initialized
INFO - 2016-05-19 16:36:50 --> Helper loaded: form_helper
INFO - 2016-05-19 16:36:50 --> Database Driver Class Initialized
INFO - 2016-05-19 16:36:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:36:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:36:50 --> Email Class Initialized
INFO - 2016-05-19 16:36:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:36:50 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:36:50 --> Helper loaded: language_helper
INFO - 2016-05-19 16:36:50 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:36:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:36:50 --> Model Class Initialized
INFO - 2016-05-19 16:36:50 --> Helper loaded: date_helper
INFO - 2016-05-19 16:36:50 --> Controller Class Initialized
INFO - 2016-05-19 16:36:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:36:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:36:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:36:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:36:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:36:50 --> Model Class Initialized
INFO - 2016-05-19 16:36:50 --> Form Validation Class Initialized
INFO - 2016-05-19 16:36:50 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:36:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:36:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:36:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:36:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:36:50 --> Final output sent to browser
DEBUG - 2016-05-19 16:36:50 --> Total execution time: 0.0299
INFO - 2016-05-19 16:36:56 --> Config Class Initialized
INFO - 2016-05-19 16:36:56 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:36:56 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:36:56 --> Utf8 Class Initialized
INFO - 2016-05-19 16:36:56 --> URI Class Initialized
INFO - 2016-05-19 16:36:56 --> Router Class Initialized
INFO - 2016-05-19 16:36:56 --> Output Class Initialized
INFO - 2016-05-19 16:36:56 --> Security Class Initialized
DEBUG - 2016-05-19 16:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:36:56 --> CSRF cookie sent
INFO - 2016-05-19 16:36:56 --> CSRF token verified
INFO - 2016-05-19 16:36:56 --> Input Class Initialized
INFO - 2016-05-19 16:36:56 --> Language Class Initialized
INFO - 2016-05-19 16:36:56 --> Loader Class Initialized
INFO - 2016-05-19 16:36:56 --> Helper loaded: form_helper
INFO - 2016-05-19 16:36:56 --> Database Driver Class Initialized
INFO - 2016-05-19 16:36:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:36:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:36:57 --> Email Class Initialized
INFO - 2016-05-19 16:36:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:36:57 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:36:57 --> Helper loaded: language_helper
INFO - 2016-05-19 16:36:57 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:36:57 --> Model Class Initialized
INFO - 2016-05-19 16:36:57 --> Helper loaded: date_helper
INFO - 2016-05-19 16:36:57 --> Controller Class Initialized
INFO - 2016-05-19 16:36:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:36:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:36:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:36:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:36:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:36:57 --> Model Class Initialized
INFO - 2016-05-19 16:36:57 --> Form Validation Class Initialized
INFO - 2016-05-19 16:36:57 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:36:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:36:57 --> Final output sent to browser
DEBUG - 2016-05-19 16:36:57 --> Total execution time: 0.1184
INFO - 2016-05-19 16:41:07 --> Config Class Initialized
INFO - 2016-05-19 16:41:07 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:41:07 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:41:07 --> Utf8 Class Initialized
INFO - 2016-05-19 16:41:07 --> URI Class Initialized
INFO - 2016-05-19 16:41:07 --> Router Class Initialized
INFO - 2016-05-19 16:41:07 --> Output Class Initialized
INFO - 2016-05-19 16:41:07 --> Security Class Initialized
DEBUG - 2016-05-19 16:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:41:07 --> CSRF cookie sent
INFO - 2016-05-19 16:41:07 --> Input Class Initialized
INFO - 2016-05-19 16:41:07 --> Language Class Initialized
INFO - 2016-05-19 16:41:07 --> Loader Class Initialized
INFO - 2016-05-19 16:41:07 --> Helper loaded: form_helper
INFO - 2016-05-19 16:41:07 --> Database Driver Class Initialized
INFO - 2016-05-19 16:41:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:41:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:41:07 --> Email Class Initialized
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:41:07 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:41:07 --> Helper loaded: language_helper
INFO - 2016-05-19 16:41:07 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:41:07 --> Model Class Initialized
INFO - 2016-05-19 16:41:07 --> Helper loaded: date_helper
INFO - 2016-05-19 16:41:07 --> Controller Class Initialized
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:41:07 --> Model Class Initialized
INFO - 2016-05-19 16:41:07 --> Config Class Initialized
INFO - 2016-05-19 16:41:07 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:41:07 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:41:07 --> Utf8 Class Initialized
INFO - 2016-05-19 16:41:07 --> URI Class Initialized
INFO - 2016-05-19 16:41:07 --> Router Class Initialized
INFO - 2016-05-19 16:41:07 --> Output Class Initialized
INFO - 2016-05-19 16:41:07 --> Security Class Initialized
DEBUG - 2016-05-19 16:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:41:07 --> CSRF cookie sent
INFO - 2016-05-19 16:41:07 --> Input Class Initialized
INFO - 2016-05-19 16:41:07 --> Language Class Initialized
INFO - 2016-05-19 16:41:07 --> Loader Class Initialized
INFO - 2016-05-19 16:41:07 --> Helper loaded: form_helper
INFO - 2016-05-19 16:41:07 --> Database Driver Class Initialized
INFO - 2016-05-19 16:41:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:41:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:41:07 --> Email Class Initialized
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:41:07 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:41:07 --> Helper loaded: language_helper
INFO - 2016-05-19 16:41:07 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:41:07 --> Model Class Initialized
INFO - 2016-05-19 16:41:07 --> Helper loaded: date_helper
INFO - 2016-05-19 16:41:07 --> Controller Class Initialized
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:41:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:41:07 --> Model Class Initialized
INFO - 2016-05-19 16:41:07 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:41:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:41:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-19 16:41:07 --> Severity: Parsing Error --> syntax error, unexpected ''cheched'' (T_CONSTANT_ENCAPSED_STRING) /home/demis/www/platformadiabet/application/views/user_area/access.php 23
INFO - 2016-05-19 16:46:59 --> Config Class Initialized
INFO - 2016-05-19 16:46:59 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:46:59 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:46:59 --> Utf8 Class Initialized
INFO - 2016-05-19 16:46:59 --> URI Class Initialized
INFO - 2016-05-19 16:46:59 --> Router Class Initialized
INFO - 2016-05-19 16:46:59 --> Output Class Initialized
INFO - 2016-05-19 16:46:59 --> Security Class Initialized
DEBUG - 2016-05-19 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:46:59 --> CSRF cookie sent
INFO - 2016-05-19 16:46:59 --> Input Class Initialized
INFO - 2016-05-19 16:46:59 --> Language Class Initialized
INFO - 2016-05-19 16:46:59 --> Loader Class Initialized
INFO - 2016-05-19 16:46:59 --> Helper loaded: form_helper
INFO - 2016-05-19 16:46:59 --> Database Driver Class Initialized
INFO - 2016-05-19 16:46:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:46:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:46:59 --> Email Class Initialized
INFO - 2016-05-19 16:46:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:46:59 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:46:59 --> Helper loaded: language_helper
INFO - 2016-05-19 16:46:59 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:46:59 --> Model Class Initialized
INFO - 2016-05-19 16:46:59 --> Helper loaded: date_helper
INFO - 2016-05-19 16:46:59 --> Controller Class Initialized
INFO - 2016-05-19 16:46:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:46:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:46:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:46:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:46:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:46:59 --> Model Class Initialized
INFO - 2016-05-19 16:46:59 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:46:59 --> Final output sent to browser
DEBUG - 2016-05-19 16:46:59 --> Total execution time: 0.0867
INFO - 2016-05-19 16:47:16 --> Config Class Initialized
INFO - 2016-05-19 16:47:16 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:47:16 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:47:16 --> Utf8 Class Initialized
INFO - 2016-05-19 16:47:16 --> URI Class Initialized
INFO - 2016-05-19 16:47:16 --> Router Class Initialized
INFO - 2016-05-19 16:47:16 --> Output Class Initialized
INFO - 2016-05-19 16:47:16 --> Security Class Initialized
DEBUG - 2016-05-19 16:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:47:16 --> CSRF cookie sent
INFO - 2016-05-19 16:47:16 --> CSRF token verified
INFO - 2016-05-19 16:47:16 --> Input Class Initialized
INFO - 2016-05-19 16:47:16 --> Language Class Initialized
INFO - 2016-05-19 16:47:16 --> Loader Class Initialized
INFO - 2016-05-19 16:47:16 --> Helper loaded: form_helper
INFO - 2016-05-19 16:47:16 --> Database Driver Class Initialized
INFO - 2016-05-19 16:47:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:47:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:47:16 --> Email Class Initialized
INFO - 2016-05-19 16:47:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:47:16 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:47:16 --> Helper loaded: language_helper
INFO - 2016-05-19 16:47:16 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:47:16 --> Model Class Initialized
INFO - 2016-05-19 16:47:16 --> Helper loaded: date_helper
INFO - 2016-05-19 16:47:16 --> Controller Class Initialized
INFO - 2016-05-19 16:47:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:47:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:47:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:47:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:47:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:47:16 --> Model Class Initialized
INFO - 2016-05-19 16:47:16 --> Form Validation Class Initialized
INFO - 2016-05-19 16:47:16 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:47:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:47:16 --> Final output sent to browser
DEBUG - 2016-05-19 16:47:16 --> Total execution time: 0.1157
INFO - 2016-05-19 16:48:13 --> Config Class Initialized
INFO - 2016-05-19 16:48:13 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:48:13 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:48:13 --> Utf8 Class Initialized
INFO - 2016-05-19 16:48:13 --> URI Class Initialized
INFO - 2016-05-19 16:48:13 --> Router Class Initialized
INFO - 2016-05-19 16:48:13 --> Output Class Initialized
INFO - 2016-05-19 16:48:13 --> Security Class Initialized
DEBUG - 2016-05-19 16:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:48:13 --> CSRF cookie sent
INFO - 2016-05-19 16:48:13 --> Input Class Initialized
INFO - 2016-05-19 16:48:13 --> Language Class Initialized
INFO - 2016-05-19 16:48:13 --> Loader Class Initialized
INFO - 2016-05-19 16:48:13 --> Helper loaded: form_helper
INFO - 2016-05-19 16:48:13 --> Database Driver Class Initialized
INFO - 2016-05-19 16:48:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:48:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:48:13 --> Email Class Initialized
INFO - 2016-05-19 16:48:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:48:13 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:48:13 --> Helper loaded: language_helper
INFO - 2016-05-19 16:48:13 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:48:13 --> Model Class Initialized
INFO - 2016-05-19 16:48:13 --> Helper loaded: date_helper
INFO - 2016-05-19 16:48:13 --> Controller Class Initialized
INFO - 2016-05-19 16:48:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:48:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:48:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:48:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:48:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:48:13 --> Model Class Initialized
INFO - 2016-05-19 16:48:14 --> Config Class Initialized
INFO - 2016-05-19 16:48:14 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:48:14 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:48:14 --> Utf8 Class Initialized
INFO - 2016-05-19 16:48:14 --> URI Class Initialized
INFO - 2016-05-19 16:48:14 --> Router Class Initialized
INFO - 2016-05-19 16:48:14 --> Output Class Initialized
INFO - 2016-05-19 16:48:14 --> Security Class Initialized
DEBUG - 2016-05-19 16:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:48:14 --> CSRF cookie sent
INFO - 2016-05-19 16:48:14 --> Input Class Initialized
INFO - 2016-05-19 16:48:14 --> Language Class Initialized
INFO - 2016-05-19 16:48:14 --> Loader Class Initialized
INFO - 2016-05-19 16:48:14 --> Helper loaded: form_helper
INFO - 2016-05-19 16:48:14 --> Database Driver Class Initialized
INFO - 2016-05-19 16:48:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:48:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:48:14 --> Email Class Initialized
INFO - 2016-05-19 16:48:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:48:14 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:48:14 --> Helper loaded: language_helper
INFO - 2016-05-19 16:48:14 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:48:14 --> Model Class Initialized
INFO - 2016-05-19 16:48:14 --> Helper loaded: date_helper
INFO - 2016-05-19 16:48:14 --> Controller Class Initialized
INFO - 2016-05-19 16:48:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:48:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:48:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:48:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:48:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:48:14 --> Model Class Initialized
INFO - 2016-05-19 16:48:14 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:48:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:48:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:48:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:48:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:48:14 --> Final output sent to browser
DEBUG - 2016-05-19 16:48:14 --> Total execution time: 0.0225
INFO - 2016-05-19 16:48:20 --> Config Class Initialized
INFO - 2016-05-19 16:48:20 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:48:20 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:48:20 --> Utf8 Class Initialized
INFO - 2016-05-19 16:48:20 --> URI Class Initialized
INFO - 2016-05-19 16:48:20 --> Router Class Initialized
INFO - 2016-05-19 16:48:20 --> Output Class Initialized
INFO - 2016-05-19 16:48:20 --> Security Class Initialized
DEBUG - 2016-05-19 16:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:48:20 --> CSRF cookie sent
INFO - 2016-05-19 16:48:20 --> CSRF token verified
INFO - 2016-05-19 16:48:20 --> Input Class Initialized
INFO - 2016-05-19 16:48:20 --> Language Class Initialized
INFO - 2016-05-19 16:48:20 --> Loader Class Initialized
INFO - 2016-05-19 16:48:20 --> Helper loaded: form_helper
INFO - 2016-05-19 16:48:20 --> Database Driver Class Initialized
INFO - 2016-05-19 16:48:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:48:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:48:20 --> Email Class Initialized
INFO - 2016-05-19 16:48:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:48:20 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:48:20 --> Helper loaded: language_helper
INFO - 2016-05-19 16:48:20 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:48:20 --> Model Class Initialized
INFO - 2016-05-19 16:48:20 --> Helper loaded: date_helper
INFO - 2016-05-19 16:48:20 --> Controller Class Initialized
INFO - 2016-05-19 16:48:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:48:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:48:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:48:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:48:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:48:20 --> Model Class Initialized
INFO - 2016-05-19 16:48:20 --> Form Validation Class Initialized
INFO - 2016-05-19 16:48:44 --> Config Class Initialized
INFO - 2016-05-19 16:48:44 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:48:44 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:48:44 --> Utf8 Class Initialized
INFO - 2016-05-19 16:48:44 --> URI Class Initialized
INFO - 2016-05-19 16:48:44 --> Router Class Initialized
INFO - 2016-05-19 16:48:44 --> Output Class Initialized
INFO - 2016-05-19 16:48:44 --> Security Class Initialized
DEBUG - 2016-05-19 16:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:48:44 --> CSRF cookie sent
INFO - 2016-05-19 16:48:44 --> Input Class Initialized
INFO - 2016-05-19 16:48:44 --> Language Class Initialized
INFO - 2016-05-19 16:48:44 --> Loader Class Initialized
INFO - 2016-05-19 16:48:44 --> Helper loaded: form_helper
INFO - 2016-05-19 16:48:44 --> Database Driver Class Initialized
INFO - 2016-05-19 16:48:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:48:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:48:44 --> Email Class Initialized
INFO - 2016-05-19 16:48:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:48:44 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:48:44 --> Helper loaded: language_helper
INFO - 2016-05-19 16:48:44 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:48:44 --> Model Class Initialized
INFO - 2016-05-19 16:48:44 --> Helper loaded: date_helper
INFO - 2016-05-19 16:48:44 --> Controller Class Initialized
INFO - 2016-05-19 16:48:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:48:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:48:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:48:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:48:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:48:44 --> Model Class Initialized
INFO - 2016-05-19 16:48:44 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:48:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:48:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:48:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:48:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:48:44 --> Final output sent to browser
DEBUG - 2016-05-19 16:48:44 --> Total execution time: 0.0793
INFO - 2016-05-19 16:48:50 --> Config Class Initialized
INFO - 2016-05-19 16:48:50 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:48:50 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:48:50 --> Utf8 Class Initialized
INFO - 2016-05-19 16:48:50 --> URI Class Initialized
INFO - 2016-05-19 16:48:50 --> Router Class Initialized
INFO - 2016-05-19 16:48:50 --> Output Class Initialized
INFO - 2016-05-19 16:48:50 --> Security Class Initialized
DEBUG - 2016-05-19 16:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:48:50 --> CSRF cookie sent
INFO - 2016-05-19 16:48:50 --> CSRF token verified
INFO - 2016-05-19 16:48:50 --> Input Class Initialized
INFO - 2016-05-19 16:48:50 --> Language Class Initialized
INFO - 2016-05-19 16:48:50 --> Loader Class Initialized
INFO - 2016-05-19 16:48:50 --> Helper loaded: form_helper
INFO - 2016-05-19 16:48:50 --> Database Driver Class Initialized
INFO - 2016-05-19 16:48:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:48:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:48:50 --> Email Class Initialized
INFO - 2016-05-19 16:48:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:48:50 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:48:50 --> Helper loaded: language_helper
INFO - 2016-05-19 16:48:50 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:48:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:48:50 --> Model Class Initialized
INFO - 2016-05-19 16:48:50 --> Helper loaded: date_helper
INFO - 2016-05-19 16:48:50 --> Controller Class Initialized
INFO - 2016-05-19 16:48:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:48:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:48:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:48:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:48:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:48:50 --> Model Class Initialized
INFO - 2016-05-19 16:48:50 --> Form Validation Class Initialized
INFO - 2016-05-19 16:48:55 --> Config Class Initialized
INFO - 2016-05-19 16:48:55 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:48:55 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:48:55 --> Utf8 Class Initialized
INFO - 2016-05-19 16:48:55 --> URI Class Initialized
INFO - 2016-05-19 16:48:55 --> Router Class Initialized
INFO - 2016-05-19 16:48:55 --> Output Class Initialized
INFO - 2016-05-19 16:48:55 --> Security Class Initialized
DEBUG - 2016-05-19 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:48:55 --> CSRF cookie sent
INFO - 2016-05-19 16:48:55 --> Input Class Initialized
INFO - 2016-05-19 16:48:55 --> Language Class Initialized
INFO - 2016-05-19 16:48:55 --> Loader Class Initialized
INFO - 2016-05-19 16:48:55 --> Helper loaded: form_helper
INFO - 2016-05-19 16:48:55 --> Database Driver Class Initialized
INFO - 2016-05-19 16:48:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:48:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:48:55 --> Email Class Initialized
INFO - 2016-05-19 16:48:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:48:55 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:48:55 --> Helper loaded: language_helper
INFO - 2016-05-19 16:48:55 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:48:55 --> Model Class Initialized
INFO - 2016-05-19 16:48:55 --> Helper loaded: date_helper
INFO - 2016-05-19 16:48:55 --> Controller Class Initialized
INFO - 2016-05-19 16:48:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:48:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:48:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:48:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:48:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:48:55 --> Model Class Initialized
INFO - 2016-05-19 16:48:55 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:48:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:48:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:48:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:48:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:48:55 --> Final output sent to browser
DEBUG - 2016-05-19 16:48:55 --> Total execution time: 0.0897
INFO - 2016-05-19 16:49:02 --> Config Class Initialized
INFO - 2016-05-19 16:49:02 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:49:02 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:49:02 --> Utf8 Class Initialized
INFO - 2016-05-19 16:49:02 --> URI Class Initialized
INFO - 2016-05-19 16:49:02 --> Router Class Initialized
INFO - 2016-05-19 16:49:02 --> Output Class Initialized
INFO - 2016-05-19 16:49:02 --> Security Class Initialized
DEBUG - 2016-05-19 16:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:49:02 --> CSRF cookie sent
INFO - 2016-05-19 16:49:02 --> CSRF token verified
INFO - 2016-05-19 16:49:02 --> Input Class Initialized
INFO - 2016-05-19 16:49:02 --> Language Class Initialized
INFO - 2016-05-19 16:49:02 --> Loader Class Initialized
INFO - 2016-05-19 16:49:02 --> Helper loaded: form_helper
INFO - 2016-05-19 16:49:02 --> Database Driver Class Initialized
INFO - 2016-05-19 16:49:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:49:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:49:02 --> Email Class Initialized
INFO - 2016-05-19 16:49:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:49:02 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:49:02 --> Helper loaded: language_helper
INFO - 2016-05-19 16:49:02 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:49:02 --> Model Class Initialized
INFO - 2016-05-19 16:49:02 --> Helper loaded: date_helper
INFO - 2016-05-19 16:49:02 --> Controller Class Initialized
INFO - 2016-05-19 16:49:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:49:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:49:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:49:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:49:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:49:02 --> Model Class Initialized
INFO - 2016-05-19 16:49:02 --> Form Validation Class Initialized
INFO - 2016-05-19 16:49:57 --> Config Class Initialized
INFO - 2016-05-19 16:49:57 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:49:57 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:49:57 --> Utf8 Class Initialized
INFO - 2016-05-19 16:49:57 --> URI Class Initialized
INFO - 2016-05-19 16:49:57 --> Router Class Initialized
INFO - 2016-05-19 16:49:57 --> Output Class Initialized
INFO - 2016-05-19 16:49:57 --> Security Class Initialized
DEBUG - 2016-05-19 16:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:49:57 --> CSRF cookie sent
INFO - 2016-05-19 16:49:57 --> Input Class Initialized
INFO - 2016-05-19 16:49:57 --> Language Class Initialized
INFO - 2016-05-19 16:49:57 --> Loader Class Initialized
INFO - 2016-05-19 16:49:57 --> Helper loaded: form_helper
INFO - 2016-05-19 16:49:57 --> Database Driver Class Initialized
INFO - 2016-05-19 16:49:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:49:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:49:57 --> Email Class Initialized
INFO - 2016-05-19 16:49:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:49:57 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:49:57 --> Helper loaded: language_helper
INFO - 2016-05-19 16:49:57 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:49:57 --> Model Class Initialized
INFO - 2016-05-19 16:49:57 --> Helper loaded: date_helper
INFO - 2016-05-19 16:49:57 --> Controller Class Initialized
INFO - 2016-05-19 16:49:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:49:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:49:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:49:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:49:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:49:57 --> Model Class Initialized
INFO - 2016-05-19 16:49:58 --> Config Class Initialized
INFO - 2016-05-19 16:49:58 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:49:58 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:49:58 --> Utf8 Class Initialized
INFO - 2016-05-19 16:49:58 --> URI Class Initialized
INFO - 2016-05-19 16:49:58 --> Router Class Initialized
INFO - 2016-05-19 16:49:58 --> Output Class Initialized
INFO - 2016-05-19 16:49:58 --> Security Class Initialized
DEBUG - 2016-05-19 16:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:49:58 --> CSRF cookie sent
INFO - 2016-05-19 16:49:58 --> Input Class Initialized
INFO - 2016-05-19 16:49:58 --> Language Class Initialized
INFO - 2016-05-19 16:49:58 --> Loader Class Initialized
INFO - 2016-05-19 16:49:58 --> Helper loaded: form_helper
INFO - 2016-05-19 16:49:58 --> Database Driver Class Initialized
INFO - 2016-05-19 16:49:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:49:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:49:58 --> Email Class Initialized
INFO - 2016-05-19 16:49:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:49:58 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:49:58 --> Helper loaded: language_helper
INFO - 2016-05-19 16:49:58 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:49:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:49:58 --> Model Class Initialized
INFO - 2016-05-19 16:49:58 --> Helper loaded: date_helper
INFO - 2016-05-19 16:49:58 --> Controller Class Initialized
INFO - 2016-05-19 16:49:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:49:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:49:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:49:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:49:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:49:58 --> Model Class Initialized
INFO - 2016-05-19 16:49:58 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:49:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:49:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:49:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:49:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:49:58 --> Final output sent to browser
DEBUG - 2016-05-19 16:49:58 --> Total execution time: 0.0230
INFO - 2016-05-19 16:50:02 --> Config Class Initialized
INFO - 2016-05-19 16:50:02 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:50:02 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:50:02 --> Utf8 Class Initialized
INFO - 2016-05-19 16:50:02 --> URI Class Initialized
INFO - 2016-05-19 16:50:02 --> Router Class Initialized
INFO - 2016-05-19 16:50:02 --> Output Class Initialized
INFO - 2016-05-19 16:50:02 --> Security Class Initialized
DEBUG - 2016-05-19 16:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:50:02 --> CSRF cookie sent
INFO - 2016-05-19 16:50:02 --> CSRF token verified
INFO - 2016-05-19 16:50:02 --> Input Class Initialized
INFO - 2016-05-19 16:50:02 --> Language Class Initialized
INFO - 2016-05-19 16:50:02 --> Loader Class Initialized
INFO - 2016-05-19 16:50:02 --> Helper loaded: form_helper
INFO - 2016-05-19 16:50:02 --> Database Driver Class Initialized
INFO - 2016-05-19 16:50:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:50:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:50:02 --> Email Class Initialized
INFO - 2016-05-19 16:50:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:50:02 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:50:02 --> Helper loaded: language_helper
INFO - 2016-05-19 16:50:02 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:50:02 --> Model Class Initialized
INFO - 2016-05-19 16:50:02 --> Helper loaded: date_helper
INFO - 2016-05-19 16:50:02 --> Controller Class Initialized
INFO - 2016-05-19 16:50:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:50:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:50:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:50:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:50:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:50:02 --> Model Class Initialized
INFO - 2016-05-19 16:50:02 --> Form Validation Class Initialized
INFO - 2016-05-19 16:50:02 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:50:02 --> Final output sent to browser
DEBUG - 2016-05-19 16:50:02 --> Total execution time: 0.0503
INFO - 2016-05-19 16:50:08 --> Config Class Initialized
INFO - 2016-05-19 16:50:08 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:50:08 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:50:08 --> Utf8 Class Initialized
INFO - 2016-05-19 16:50:08 --> URI Class Initialized
INFO - 2016-05-19 16:50:08 --> Router Class Initialized
INFO - 2016-05-19 16:50:08 --> Output Class Initialized
INFO - 2016-05-19 16:50:08 --> Security Class Initialized
DEBUG - 2016-05-19 16:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:50:08 --> CSRF cookie sent
INFO - 2016-05-19 16:50:08 --> CSRF token verified
INFO - 2016-05-19 16:50:08 --> Input Class Initialized
INFO - 2016-05-19 16:50:08 --> Language Class Initialized
INFO - 2016-05-19 16:50:08 --> Loader Class Initialized
INFO - 2016-05-19 16:50:08 --> Helper loaded: form_helper
INFO - 2016-05-19 16:50:08 --> Database Driver Class Initialized
INFO - 2016-05-19 16:50:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:50:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:50:08 --> Email Class Initialized
INFO - 2016-05-19 16:50:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:50:08 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:50:08 --> Helper loaded: language_helper
INFO - 2016-05-19 16:50:08 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:50:08 --> Model Class Initialized
INFO - 2016-05-19 16:50:08 --> Helper loaded: date_helper
INFO - 2016-05-19 16:50:08 --> Controller Class Initialized
INFO - 2016-05-19 16:50:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:50:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:50:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:50:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:50:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:50:08 --> Model Class Initialized
INFO - 2016-05-19 16:50:08 --> Form Validation Class Initialized
INFO - 2016-05-19 16:50:29 --> Config Class Initialized
INFO - 2016-05-19 16:50:29 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:50:29 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:50:29 --> Utf8 Class Initialized
INFO - 2016-05-19 16:50:29 --> URI Class Initialized
INFO - 2016-05-19 16:50:29 --> Router Class Initialized
INFO - 2016-05-19 16:50:29 --> Output Class Initialized
INFO - 2016-05-19 16:50:29 --> Security Class Initialized
DEBUG - 2016-05-19 16:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:50:29 --> CSRF cookie sent
INFO - 2016-05-19 16:50:29 --> Input Class Initialized
INFO - 2016-05-19 16:50:29 --> Language Class Initialized
INFO - 2016-05-19 16:50:29 --> Loader Class Initialized
INFO - 2016-05-19 16:50:29 --> Helper loaded: form_helper
INFO - 2016-05-19 16:50:29 --> Database Driver Class Initialized
INFO - 2016-05-19 16:50:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:50:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:50:29 --> Email Class Initialized
INFO - 2016-05-19 16:50:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:50:29 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:50:29 --> Helper loaded: language_helper
INFO - 2016-05-19 16:50:29 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:50:29 --> Model Class Initialized
INFO - 2016-05-19 16:50:29 --> Helper loaded: date_helper
INFO - 2016-05-19 16:50:29 --> Controller Class Initialized
INFO - 2016-05-19 16:50:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:50:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:50:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:50:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:50:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:50:29 --> Model Class Initialized
INFO - 2016-05-19 16:50:29 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:50:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:50:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:50:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:50:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:50:29 --> Final output sent to browser
DEBUG - 2016-05-19 16:50:29 --> Total execution time: 0.0954
INFO - 2016-05-19 16:50:43 --> Config Class Initialized
INFO - 2016-05-19 16:50:43 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:50:43 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:50:43 --> Utf8 Class Initialized
INFO - 2016-05-19 16:50:43 --> URI Class Initialized
INFO - 2016-05-19 16:50:43 --> Router Class Initialized
INFO - 2016-05-19 16:50:43 --> Output Class Initialized
INFO - 2016-05-19 16:50:43 --> Security Class Initialized
DEBUG - 2016-05-19 16:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:50:43 --> CSRF cookie sent
INFO - 2016-05-19 16:50:43 --> CSRF token verified
INFO - 2016-05-19 16:50:43 --> Input Class Initialized
INFO - 2016-05-19 16:50:43 --> Language Class Initialized
INFO - 2016-05-19 16:50:43 --> Loader Class Initialized
INFO - 2016-05-19 16:50:43 --> Helper loaded: form_helper
INFO - 2016-05-19 16:50:43 --> Database Driver Class Initialized
INFO - 2016-05-19 16:50:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:50:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:50:43 --> Email Class Initialized
INFO - 2016-05-19 16:50:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:50:43 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:50:43 --> Helper loaded: language_helper
INFO - 2016-05-19 16:50:43 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:50:43 --> Model Class Initialized
INFO - 2016-05-19 16:50:43 --> Helper loaded: date_helper
INFO - 2016-05-19 16:50:43 --> Controller Class Initialized
INFO - 2016-05-19 16:50:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:50:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:50:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:50:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:50:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:50:43 --> Model Class Initialized
INFO - 2016-05-19 16:50:43 --> Form Validation Class Initialized
INFO - 2016-05-19 16:51:09 --> Config Class Initialized
INFO - 2016-05-19 16:51:09 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:51:09 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:51:09 --> Utf8 Class Initialized
INFO - 2016-05-19 16:51:09 --> URI Class Initialized
INFO - 2016-05-19 16:51:09 --> Router Class Initialized
INFO - 2016-05-19 16:51:09 --> Output Class Initialized
INFO - 2016-05-19 16:51:09 --> Security Class Initialized
DEBUG - 2016-05-19 16:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:51:09 --> CSRF cookie sent
INFO - 2016-05-19 16:51:09 --> Input Class Initialized
INFO - 2016-05-19 16:51:09 --> Language Class Initialized
INFO - 2016-05-19 16:51:09 --> Loader Class Initialized
INFO - 2016-05-19 16:51:09 --> Helper loaded: form_helper
INFO - 2016-05-19 16:51:09 --> Database Driver Class Initialized
INFO - 2016-05-19 16:51:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:51:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:51:09 --> Email Class Initialized
INFO - 2016-05-19 16:51:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:51:09 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:51:09 --> Helper loaded: language_helper
INFO - 2016-05-19 16:51:09 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:51:09 --> Model Class Initialized
INFO - 2016-05-19 16:51:09 --> Helper loaded: date_helper
INFO - 2016-05-19 16:51:09 --> Controller Class Initialized
INFO - 2016-05-19 16:51:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:51:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:51:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:51:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:51:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:51:09 --> Model Class Initialized
INFO - 2016-05-19 16:51:09 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:51:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:51:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:51:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:51:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:51:09 --> Final output sent to browser
DEBUG - 2016-05-19 16:51:09 --> Total execution time: 0.0754
INFO - 2016-05-19 16:51:16 --> Config Class Initialized
INFO - 2016-05-19 16:51:16 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:51:16 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:51:16 --> Utf8 Class Initialized
INFO - 2016-05-19 16:51:16 --> URI Class Initialized
INFO - 2016-05-19 16:51:16 --> Router Class Initialized
INFO - 2016-05-19 16:51:16 --> Output Class Initialized
INFO - 2016-05-19 16:51:16 --> Security Class Initialized
DEBUG - 2016-05-19 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:51:16 --> CSRF cookie sent
INFO - 2016-05-19 16:51:16 --> CSRF token verified
INFO - 2016-05-19 16:51:16 --> Input Class Initialized
INFO - 2016-05-19 16:51:16 --> Language Class Initialized
INFO - 2016-05-19 16:51:16 --> Loader Class Initialized
INFO - 2016-05-19 16:51:16 --> Helper loaded: form_helper
INFO - 2016-05-19 16:51:16 --> Database Driver Class Initialized
INFO - 2016-05-19 16:51:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:51:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:51:16 --> Email Class Initialized
INFO - 2016-05-19 16:51:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:51:16 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:51:16 --> Helper loaded: language_helper
INFO - 2016-05-19 16:51:16 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:51:16 --> Model Class Initialized
INFO - 2016-05-19 16:51:16 --> Helper loaded: date_helper
INFO - 2016-05-19 16:51:16 --> Controller Class Initialized
INFO - 2016-05-19 16:51:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:51:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:51:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:51:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:51:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:51:16 --> Model Class Initialized
INFO - 2016-05-19 16:51:16 --> Form Validation Class Initialized
INFO - 2016-05-19 16:52:12 --> Config Class Initialized
INFO - 2016-05-19 16:52:12 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:52:12 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:52:12 --> Utf8 Class Initialized
INFO - 2016-05-19 16:52:12 --> URI Class Initialized
INFO - 2016-05-19 16:52:12 --> Router Class Initialized
INFO - 2016-05-19 16:52:12 --> Output Class Initialized
INFO - 2016-05-19 16:52:12 --> Security Class Initialized
DEBUG - 2016-05-19 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:52:14 --> Config Class Initialized
INFO - 2016-05-19 16:52:14 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:52:14 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:52:14 --> Utf8 Class Initialized
INFO - 2016-05-19 16:52:14 --> URI Class Initialized
INFO - 2016-05-19 16:52:14 --> Router Class Initialized
INFO - 2016-05-19 16:52:14 --> Output Class Initialized
INFO - 2016-05-19 16:52:14 --> Security Class Initialized
DEBUG - 2016-05-19 16:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:52:14 --> CSRF cookie sent
INFO - 2016-05-19 16:52:14 --> Input Class Initialized
INFO - 2016-05-19 16:52:14 --> Language Class Initialized
INFO - 2016-05-19 16:52:14 --> Loader Class Initialized
INFO - 2016-05-19 16:52:14 --> Helper loaded: form_helper
INFO - 2016-05-19 16:52:14 --> Database Driver Class Initialized
INFO - 2016-05-19 16:52:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:52:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:52:14 --> Email Class Initialized
INFO - 2016-05-19 16:52:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:52:14 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:52:14 --> Helper loaded: language_helper
INFO - 2016-05-19 16:52:14 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:52:14 --> Model Class Initialized
INFO - 2016-05-19 16:52:14 --> Helper loaded: date_helper
INFO - 2016-05-19 16:52:14 --> Controller Class Initialized
INFO - 2016-05-19 16:52:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:52:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:52:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:52:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:52:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:52:14 --> Model Class Initialized
INFO - 2016-05-19 16:52:14 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:52:14 --> Final output sent to browser
DEBUG - 2016-05-19 16:52:14 --> Total execution time: 0.0509
INFO - 2016-05-19 16:52:20 --> Config Class Initialized
INFO - 2016-05-19 16:52:20 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:52:20 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:52:20 --> Utf8 Class Initialized
INFO - 2016-05-19 16:52:20 --> URI Class Initialized
INFO - 2016-05-19 16:52:20 --> Router Class Initialized
INFO - 2016-05-19 16:52:20 --> Output Class Initialized
INFO - 2016-05-19 16:52:20 --> Security Class Initialized
DEBUG - 2016-05-19 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:52:20 --> CSRF cookie sent
INFO - 2016-05-19 16:52:20 --> CSRF token verified
INFO - 2016-05-19 16:52:20 --> Input Class Initialized
INFO - 2016-05-19 16:52:20 --> Language Class Initialized
INFO - 2016-05-19 16:52:20 --> Loader Class Initialized
INFO - 2016-05-19 16:52:20 --> Helper loaded: form_helper
INFO - 2016-05-19 16:52:20 --> Database Driver Class Initialized
INFO - 2016-05-19 16:52:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:52:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:52:20 --> Email Class Initialized
INFO - 2016-05-19 16:52:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:52:20 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:52:20 --> Helper loaded: language_helper
INFO - 2016-05-19 16:52:20 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:52:20 --> Model Class Initialized
INFO - 2016-05-19 16:52:20 --> Helper loaded: date_helper
INFO - 2016-05-19 16:52:20 --> Controller Class Initialized
INFO - 2016-05-19 16:52:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:52:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:52:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:52:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:52:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:52:20 --> Model Class Initialized
INFO - 2016-05-19 16:52:20 --> Form Validation Class Initialized
INFO - 2016-05-19 16:54:05 --> Config Class Initialized
INFO - 2016-05-19 16:54:05 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:54:05 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:54:05 --> Utf8 Class Initialized
INFO - 2016-05-19 16:54:05 --> URI Class Initialized
INFO - 2016-05-19 16:54:05 --> Router Class Initialized
INFO - 2016-05-19 16:54:05 --> Output Class Initialized
INFO - 2016-05-19 16:54:05 --> Security Class Initialized
DEBUG - 2016-05-19 16:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:54:08 --> Config Class Initialized
INFO - 2016-05-19 16:54:08 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:54:08 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:54:08 --> Utf8 Class Initialized
INFO - 2016-05-19 16:54:08 --> URI Class Initialized
INFO - 2016-05-19 16:54:08 --> Router Class Initialized
INFO - 2016-05-19 16:54:08 --> Output Class Initialized
INFO - 2016-05-19 16:54:08 --> Security Class Initialized
DEBUG - 2016-05-19 16:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:54:08 --> CSRF cookie sent
INFO - 2016-05-19 16:54:08 --> Input Class Initialized
INFO - 2016-05-19 16:54:08 --> Language Class Initialized
INFO - 2016-05-19 16:54:08 --> Loader Class Initialized
INFO - 2016-05-19 16:54:08 --> Helper loaded: form_helper
INFO - 2016-05-19 16:54:08 --> Database Driver Class Initialized
INFO - 2016-05-19 16:54:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:54:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:54:08 --> Email Class Initialized
INFO - 2016-05-19 16:54:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:54:08 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:54:08 --> Helper loaded: language_helper
INFO - 2016-05-19 16:54:08 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:54:08 --> Model Class Initialized
INFO - 2016-05-19 16:54:08 --> Helper loaded: date_helper
INFO - 2016-05-19 16:54:08 --> Controller Class Initialized
INFO - 2016-05-19 16:54:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:54:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:54:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:54:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:54:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:54:08 --> Model Class Initialized
INFO - 2016-05-19 16:54:08 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:54:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:54:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:54:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:54:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:54:08 --> Final output sent to browser
DEBUG - 2016-05-19 16:54:08 --> Total execution time: 0.0609
INFO - 2016-05-19 16:54:13 --> Config Class Initialized
INFO - 2016-05-19 16:54:13 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:54:13 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:54:13 --> Utf8 Class Initialized
INFO - 2016-05-19 16:54:13 --> URI Class Initialized
INFO - 2016-05-19 16:54:13 --> Router Class Initialized
INFO - 2016-05-19 16:54:13 --> Output Class Initialized
INFO - 2016-05-19 16:54:13 --> Security Class Initialized
DEBUG - 2016-05-19 16:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:54:13 --> CSRF cookie sent
INFO - 2016-05-19 16:54:13 --> CSRF token verified
INFO - 2016-05-19 16:54:13 --> Input Class Initialized
INFO - 2016-05-19 16:54:13 --> Language Class Initialized
INFO - 2016-05-19 16:54:13 --> Loader Class Initialized
INFO - 2016-05-19 16:54:13 --> Helper loaded: form_helper
INFO - 2016-05-19 16:54:13 --> Database Driver Class Initialized
INFO - 2016-05-19 16:54:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:54:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:54:13 --> Email Class Initialized
INFO - 2016-05-19 16:54:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:54:13 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:54:13 --> Helper loaded: language_helper
INFO - 2016-05-19 16:54:13 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:54:13 --> Model Class Initialized
INFO - 2016-05-19 16:54:13 --> Helper loaded: date_helper
INFO - 2016-05-19 16:54:13 --> Controller Class Initialized
INFO - 2016-05-19 16:54:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:54:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:54:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:54:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:54:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:54:13 --> Model Class Initialized
INFO - 2016-05-19 16:54:13 --> Form Validation Class Initialized
INFO - 2016-05-19 16:55:13 --> Config Class Initialized
INFO - 2016-05-19 16:55:13 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:55:13 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:55:13 --> Utf8 Class Initialized
INFO - 2016-05-19 16:55:13 --> URI Class Initialized
INFO - 2016-05-19 16:55:13 --> Router Class Initialized
INFO - 2016-05-19 16:55:13 --> Output Class Initialized
INFO - 2016-05-19 16:55:13 --> Security Class Initialized
DEBUG - 2016-05-19 16:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:55:15 --> Config Class Initialized
INFO - 2016-05-19 16:55:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:55:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:55:15 --> Utf8 Class Initialized
INFO - 2016-05-19 16:55:15 --> URI Class Initialized
INFO - 2016-05-19 16:55:15 --> Router Class Initialized
INFO - 2016-05-19 16:55:15 --> Output Class Initialized
INFO - 2016-05-19 16:55:15 --> Security Class Initialized
DEBUG - 2016-05-19 16:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:55:15 --> CSRF cookie sent
INFO - 2016-05-19 16:55:15 --> Input Class Initialized
INFO - 2016-05-19 16:55:15 --> Language Class Initialized
INFO - 2016-05-19 16:55:15 --> Loader Class Initialized
INFO - 2016-05-19 16:55:15 --> Helper loaded: form_helper
INFO - 2016-05-19 16:55:15 --> Database Driver Class Initialized
INFO - 2016-05-19 16:55:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:55:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:55:15 --> Email Class Initialized
INFO - 2016-05-19 16:55:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:55:15 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:55:15 --> Helper loaded: language_helper
INFO - 2016-05-19 16:55:15 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:55:15 --> Model Class Initialized
INFO - 2016-05-19 16:55:15 --> Helper loaded: date_helper
INFO - 2016-05-19 16:55:15 --> Controller Class Initialized
INFO - 2016-05-19 16:55:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:55:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:55:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:55:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:55:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:55:15 --> Model Class Initialized
INFO - 2016-05-19 16:55:15 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:55:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:55:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:55:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:55:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:55:15 --> Final output sent to browser
DEBUG - 2016-05-19 16:55:15 --> Total execution time: 0.0450
INFO - 2016-05-19 16:55:21 --> Config Class Initialized
INFO - 2016-05-19 16:55:21 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:55:21 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:55:21 --> Utf8 Class Initialized
INFO - 2016-05-19 16:55:21 --> URI Class Initialized
INFO - 2016-05-19 16:55:21 --> Router Class Initialized
INFO - 2016-05-19 16:55:21 --> Output Class Initialized
INFO - 2016-05-19 16:55:21 --> Security Class Initialized
DEBUG - 2016-05-19 16:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:55:21 --> CSRF cookie sent
INFO - 2016-05-19 16:55:21 --> CSRF token verified
INFO - 2016-05-19 16:55:21 --> Input Class Initialized
INFO - 2016-05-19 16:55:21 --> Language Class Initialized
INFO - 2016-05-19 16:55:21 --> Loader Class Initialized
INFO - 2016-05-19 16:55:21 --> Helper loaded: form_helper
INFO - 2016-05-19 16:55:21 --> Database Driver Class Initialized
INFO - 2016-05-19 16:55:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:55:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:55:21 --> Email Class Initialized
INFO - 2016-05-19 16:55:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:55:21 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:55:21 --> Helper loaded: language_helper
INFO - 2016-05-19 16:55:21 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:55:21 --> Model Class Initialized
INFO - 2016-05-19 16:55:21 --> Helper loaded: date_helper
INFO - 2016-05-19 16:55:21 --> Controller Class Initialized
INFO - 2016-05-19 16:55:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:55:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:55:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:55:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:55:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:55:21 --> Model Class Initialized
INFO - 2016-05-19 16:55:21 --> Form Validation Class Initialized
INFO - 2016-05-19 16:55:45 --> Config Class Initialized
INFO - 2016-05-19 16:55:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:55:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:55:45 --> Utf8 Class Initialized
INFO - 2016-05-19 16:55:45 --> URI Class Initialized
INFO - 2016-05-19 16:55:45 --> Router Class Initialized
INFO - 2016-05-19 16:55:45 --> Output Class Initialized
INFO - 2016-05-19 16:55:45 --> Security Class Initialized
DEBUG - 2016-05-19 16:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:55:45 --> CSRF cookie sent
INFO - 2016-05-19 16:55:45 --> Input Class Initialized
INFO - 2016-05-19 16:55:45 --> Language Class Initialized
INFO - 2016-05-19 16:55:45 --> Loader Class Initialized
INFO - 2016-05-19 16:55:45 --> Helper loaded: form_helper
INFO - 2016-05-19 16:55:45 --> Database Driver Class Initialized
INFO - 2016-05-19 16:55:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:55:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:55:45 --> Email Class Initialized
INFO - 2016-05-19 16:55:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:55:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:55:45 --> Helper loaded: language_helper
INFO - 2016-05-19 16:55:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:55:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:55:45 --> Model Class Initialized
INFO - 2016-05-19 16:55:45 --> Helper loaded: date_helper
INFO - 2016-05-19 16:55:45 --> Controller Class Initialized
INFO - 2016-05-19 16:55:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:55:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:55:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:55:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:55:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:55:45 --> Model Class Initialized
INFO - 2016-05-19 16:55:45 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:55:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:55:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:55:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:55:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:55:45 --> Final output sent to browser
DEBUG - 2016-05-19 16:55:45 --> Total execution time: 0.0590
INFO - 2016-05-19 16:55:51 --> Config Class Initialized
INFO - 2016-05-19 16:55:51 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:55:51 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:55:51 --> Utf8 Class Initialized
INFO - 2016-05-19 16:55:51 --> URI Class Initialized
INFO - 2016-05-19 16:55:51 --> Router Class Initialized
INFO - 2016-05-19 16:55:51 --> Output Class Initialized
INFO - 2016-05-19 16:55:51 --> Security Class Initialized
DEBUG - 2016-05-19 16:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:55:51 --> CSRF cookie sent
INFO - 2016-05-19 16:55:51 --> CSRF token verified
INFO - 2016-05-19 16:55:51 --> Input Class Initialized
INFO - 2016-05-19 16:55:51 --> Language Class Initialized
INFO - 2016-05-19 16:55:51 --> Loader Class Initialized
INFO - 2016-05-19 16:55:51 --> Helper loaded: form_helper
INFO - 2016-05-19 16:55:51 --> Database Driver Class Initialized
INFO - 2016-05-19 16:55:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:55:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:55:51 --> Email Class Initialized
INFO - 2016-05-19 16:55:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:55:51 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:55:51 --> Helper loaded: language_helper
INFO - 2016-05-19 16:55:51 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:55:51 --> Model Class Initialized
INFO - 2016-05-19 16:55:51 --> Helper loaded: date_helper
INFO - 2016-05-19 16:55:51 --> Controller Class Initialized
INFO - 2016-05-19 16:55:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:55:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:55:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:55:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:55:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:55:51 --> Model Class Initialized
INFO - 2016-05-19 16:55:51 --> Form Validation Class Initialized
INFO - 2016-05-19 16:56:20 --> Config Class Initialized
INFO - 2016-05-19 16:56:20 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:56:20 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:56:20 --> Utf8 Class Initialized
INFO - 2016-05-19 16:56:20 --> URI Class Initialized
INFO - 2016-05-19 16:56:20 --> Router Class Initialized
INFO - 2016-05-19 16:56:20 --> Output Class Initialized
INFO - 2016-05-19 16:56:20 --> Security Class Initialized
DEBUG - 2016-05-19 16:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:56:20 --> CSRF cookie sent
INFO - 2016-05-19 16:56:20 --> Input Class Initialized
INFO - 2016-05-19 16:56:20 --> Language Class Initialized
INFO - 2016-05-19 16:56:20 --> Loader Class Initialized
INFO - 2016-05-19 16:56:20 --> Helper loaded: form_helper
INFO - 2016-05-19 16:56:20 --> Database Driver Class Initialized
INFO - 2016-05-19 16:56:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:56:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:56:20 --> Email Class Initialized
INFO - 2016-05-19 16:56:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:56:20 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:56:20 --> Helper loaded: language_helper
INFO - 2016-05-19 16:56:20 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:56:20 --> Model Class Initialized
INFO - 2016-05-19 16:56:20 --> Helper loaded: date_helper
INFO - 2016-05-19 16:56:20 --> Controller Class Initialized
INFO - 2016-05-19 16:56:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:56:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:56:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:56:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:56:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:56:20 --> Model Class Initialized
INFO - 2016-05-19 16:56:20 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:56:20 --> Final output sent to browser
DEBUG - 2016-05-19 16:56:20 --> Total execution time: 0.0580
INFO - 2016-05-19 16:56:28 --> Config Class Initialized
INFO - 2016-05-19 16:56:28 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:56:28 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:56:28 --> Utf8 Class Initialized
INFO - 2016-05-19 16:56:28 --> URI Class Initialized
INFO - 2016-05-19 16:56:28 --> Router Class Initialized
INFO - 2016-05-19 16:56:28 --> Output Class Initialized
INFO - 2016-05-19 16:56:28 --> Security Class Initialized
DEBUG - 2016-05-19 16:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:56:28 --> CSRF cookie sent
INFO - 2016-05-19 16:56:28 --> CSRF token verified
INFO - 2016-05-19 16:56:28 --> Input Class Initialized
INFO - 2016-05-19 16:56:28 --> Language Class Initialized
INFO - 2016-05-19 16:56:28 --> Loader Class Initialized
INFO - 2016-05-19 16:56:28 --> Helper loaded: form_helper
INFO - 2016-05-19 16:56:28 --> Database Driver Class Initialized
INFO - 2016-05-19 16:56:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:56:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:56:28 --> Email Class Initialized
INFO - 2016-05-19 16:56:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:56:28 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:56:28 --> Helper loaded: language_helper
INFO - 2016-05-19 16:56:28 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:56:28 --> Model Class Initialized
INFO - 2016-05-19 16:56:28 --> Helper loaded: date_helper
INFO - 2016-05-19 16:56:28 --> Controller Class Initialized
INFO - 2016-05-19 16:56:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:56:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:56:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:56:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:56:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:56:28 --> Model Class Initialized
INFO - 2016-05-19 16:56:28 --> Form Validation Class Initialized
INFO - 2016-05-19 16:58:14 --> Config Class Initialized
INFO - 2016-05-19 16:58:14 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:58:14 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:58:14 --> Utf8 Class Initialized
INFO - 2016-05-19 16:58:14 --> URI Class Initialized
INFO - 2016-05-19 16:58:14 --> Router Class Initialized
INFO - 2016-05-19 16:58:14 --> Output Class Initialized
INFO - 2016-05-19 16:58:14 --> Security Class Initialized
DEBUG - 2016-05-19 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:58:17 --> Config Class Initialized
INFO - 2016-05-19 16:58:17 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:58:17 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:58:17 --> Utf8 Class Initialized
INFO - 2016-05-19 16:58:17 --> URI Class Initialized
INFO - 2016-05-19 16:58:17 --> Router Class Initialized
INFO - 2016-05-19 16:58:17 --> Output Class Initialized
INFO - 2016-05-19 16:58:17 --> Security Class Initialized
DEBUG - 2016-05-19 16:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:58:17 --> CSRF cookie sent
INFO - 2016-05-19 16:58:17 --> Input Class Initialized
INFO - 2016-05-19 16:58:17 --> Language Class Initialized
INFO - 2016-05-19 16:58:17 --> Loader Class Initialized
INFO - 2016-05-19 16:58:17 --> Helper loaded: form_helper
INFO - 2016-05-19 16:58:17 --> Database Driver Class Initialized
INFO - 2016-05-19 16:58:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:58:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:58:17 --> Email Class Initialized
INFO - 2016-05-19 16:58:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:58:17 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:58:17 --> Helper loaded: language_helper
INFO - 2016-05-19 16:58:17 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:58:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:58:17 --> Model Class Initialized
INFO - 2016-05-19 16:58:17 --> Helper loaded: date_helper
INFO - 2016-05-19 16:58:17 --> Controller Class Initialized
INFO - 2016-05-19 16:58:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:58:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:58:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:58:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:58:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:58:17 --> Model Class Initialized
INFO - 2016-05-19 16:58:17 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:58:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:58:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:58:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:58:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:58:17 --> Final output sent to browser
DEBUG - 2016-05-19 16:58:17 --> Total execution time: 0.1017
INFO - 2016-05-19 16:58:26 --> Config Class Initialized
INFO - 2016-05-19 16:58:26 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:58:26 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:58:26 --> Utf8 Class Initialized
INFO - 2016-05-19 16:58:26 --> URI Class Initialized
INFO - 2016-05-19 16:58:26 --> Router Class Initialized
INFO - 2016-05-19 16:58:26 --> Output Class Initialized
INFO - 2016-05-19 16:58:26 --> Security Class Initialized
DEBUG - 2016-05-19 16:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:58:26 --> CSRF cookie sent
INFO - 2016-05-19 16:58:26 --> CSRF token verified
INFO - 2016-05-19 16:58:26 --> Input Class Initialized
INFO - 2016-05-19 16:58:26 --> Language Class Initialized
INFO - 2016-05-19 16:58:26 --> Loader Class Initialized
INFO - 2016-05-19 16:58:26 --> Helper loaded: form_helper
INFO - 2016-05-19 16:58:26 --> Database Driver Class Initialized
INFO - 2016-05-19 16:58:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:58:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:58:26 --> Email Class Initialized
INFO - 2016-05-19 16:58:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:58:26 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:58:26 --> Helper loaded: language_helper
INFO - 2016-05-19 16:58:26 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:58:26 --> Model Class Initialized
INFO - 2016-05-19 16:58:26 --> Helper loaded: date_helper
INFO - 2016-05-19 16:58:26 --> Controller Class Initialized
INFO - 2016-05-19 16:58:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:58:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:58:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:58:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:58:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:58:26 --> Model Class Initialized
INFO - 2016-05-19 16:58:26 --> Form Validation Class Initialized
INFO - 2016-05-19 16:59:03 --> Config Class Initialized
INFO - 2016-05-19 16:59:03 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:59:03 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:59:03 --> Utf8 Class Initialized
INFO - 2016-05-19 16:59:03 --> URI Class Initialized
INFO - 2016-05-19 16:59:03 --> Router Class Initialized
INFO - 2016-05-19 16:59:03 --> Output Class Initialized
INFO - 2016-05-19 16:59:03 --> Security Class Initialized
DEBUG - 2016-05-19 16:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:59:03 --> CSRF cookie sent
INFO - 2016-05-19 16:59:03 --> Input Class Initialized
INFO - 2016-05-19 16:59:03 --> Language Class Initialized
INFO - 2016-05-19 16:59:03 --> Loader Class Initialized
INFO - 2016-05-19 16:59:03 --> Helper loaded: form_helper
INFO - 2016-05-19 16:59:03 --> Database Driver Class Initialized
INFO - 2016-05-19 16:59:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:59:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:59:03 --> Email Class Initialized
INFO - 2016-05-19 16:59:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:59:03 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:59:03 --> Helper loaded: language_helper
INFO - 2016-05-19 16:59:03 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:59:03 --> Model Class Initialized
INFO - 2016-05-19 16:59:03 --> Helper loaded: date_helper
INFO - 2016-05-19 16:59:03 --> Controller Class Initialized
INFO - 2016-05-19 16:59:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:59:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:59:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:59:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:59:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:59:03 --> Model Class Initialized
INFO - 2016-05-19 16:59:03 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:59:03 --> Final output sent to browser
DEBUG - 2016-05-19 16:59:03 --> Total execution time: 0.0531
INFO - 2016-05-19 16:59:10 --> Config Class Initialized
INFO - 2016-05-19 16:59:10 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:59:10 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:59:10 --> Utf8 Class Initialized
INFO - 2016-05-19 16:59:10 --> URI Class Initialized
INFO - 2016-05-19 16:59:10 --> Router Class Initialized
INFO - 2016-05-19 16:59:10 --> Output Class Initialized
INFO - 2016-05-19 16:59:10 --> Security Class Initialized
DEBUG - 2016-05-19 16:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:59:10 --> CSRF cookie sent
INFO - 2016-05-19 16:59:10 --> CSRF token verified
INFO - 2016-05-19 16:59:10 --> Input Class Initialized
INFO - 2016-05-19 16:59:10 --> Language Class Initialized
INFO - 2016-05-19 16:59:10 --> Loader Class Initialized
INFO - 2016-05-19 16:59:10 --> Helper loaded: form_helper
INFO - 2016-05-19 16:59:10 --> Database Driver Class Initialized
INFO - 2016-05-19 16:59:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:59:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:59:10 --> Email Class Initialized
INFO - 2016-05-19 16:59:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:59:10 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:59:10 --> Helper loaded: language_helper
INFO - 2016-05-19 16:59:10 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:59:10 --> Model Class Initialized
INFO - 2016-05-19 16:59:10 --> Helper loaded: date_helper
INFO - 2016-05-19 16:59:10 --> Controller Class Initialized
INFO - 2016-05-19 16:59:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:59:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:59:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:59:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:59:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:59:10 --> Model Class Initialized
INFO - 2016-05-19 16:59:10 --> Form Validation Class Initialized
INFO - 2016-05-19 16:59:38 --> Config Class Initialized
INFO - 2016-05-19 16:59:38 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:59:38 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:59:38 --> Utf8 Class Initialized
INFO - 2016-05-19 16:59:38 --> URI Class Initialized
INFO - 2016-05-19 16:59:38 --> Router Class Initialized
INFO - 2016-05-19 16:59:38 --> Output Class Initialized
INFO - 2016-05-19 16:59:38 --> Security Class Initialized
DEBUG - 2016-05-19 16:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:59:38 --> CSRF cookie sent
INFO - 2016-05-19 16:59:38 --> Input Class Initialized
INFO - 2016-05-19 16:59:38 --> Language Class Initialized
INFO - 2016-05-19 16:59:38 --> Loader Class Initialized
INFO - 2016-05-19 16:59:38 --> Helper loaded: form_helper
INFO - 2016-05-19 16:59:38 --> Database Driver Class Initialized
INFO - 2016-05-19 16:59:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:59:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:59:38 --> Email Class Initialized
INFO - 2016-05-19 16:59:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:59:38 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:59:38 --> Helper loaded: language_helper
INFO - 2016-05-19 16:59:38 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:59:38 --> Model Class Initialized
INFO - 2016-05-19 16:59:38 --> Helper loaded: date_helper
INFO - 2016-05-19 16:59:38 --> Controller Class Initialized
INFO - 2016-05-19 16:59:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:59:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:59:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:59:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:59:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:59:38 --> Model Class Initialized
INFO - 2016-05-19 16:59:38 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:59:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:59:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:59:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:59:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:59:38 --> Final output sent to browser
DEBUG - 2016-05-19 16:59:38 --> Total execution time: 0.0538
INFO - 2016-05-19 16:59:44 --> Config Class Initialized
INFO - 2016-05-19 16:59:44 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:59:44 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:59:44 --> Utf8 Class Initialized
INFO - 2016-05-19 16:59:44 --> URI Class Initialized
INFO - 2016-05-19 16:59:44 --> Router Class Initialized
INFO - 2016-05-19 16:59:44 --> Output Class Initialized
INFO - 2016-05-19 16:59:44 --> Security Class Initialized
DEBUG - 2016-05-19 16:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:59:44 --> CSRF cookie sent
INFO - 2016-05-19 16:59:44 --> CSRF token verified
INFO - 2016-05-19 16:59:44 --> Input Class Initialized
INFO - 2016-05-19 16:59:44 --> Language Class Initialized
INFO - 2016-05-19 16:59:44 --> Loader Class Initialized
INFO - 2016-05-19 16:59:44 --> Helper loaded: form_helper
INFO - 2016-05-19 16:59:44 --> Database Driver Class Initialized
INFO - 2016-05-19 16:59:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:59:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:59:44 --> Email Class Initialized
INFO - 2016-05-19 16:59:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:59:44 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:59:44 --> Helper loaded: language_helper
INFO - 2016-05-19 16:59:44 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:59:44 --> Model Class Initialized
INFO - 2016-05-19 16:59:44 --> Helper loaded: date_helper
INFO - 2016-05-19 16:59:44 --> Controller Class Initialized
INFO - 2016-05-19 16:59:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:59:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:59:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:59:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:59:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:59:44 --> Model Class Initialized
INFO - 2016-05-19 16:59:44 --> Form Validation Class Initialized
INFO - 2016-05-19 16:59:45 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:59:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:59:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:59:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:59:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:59:45 --> Final output sent to browser
DEBUG - 2016-05-19 16:59:45 --> Total execution time: 0.1161
INFO - 2016-05-19 16:59:56 --> Config Class Initialized
INFO - 2016-05-19 16:59:56 --> Hooks Class Initialized
DEBUG - 2016-05-19 16:59:56 --> UTF-8 Support Enabled
INFO - 2016-05-19 16:59:56 --> Utf8 Class Initialized
INFO - 2016-05-19 16:59:56 --> URI Class Initialized
INFO - 2016-05-19 16:59:56 --> Router Class Initialized
INFO - 2016-05-19 16:59:56 --> Output Class Initialized
INFO - 2016-05-19 16:59:56 --> Security Class Initialized
DEBUG - 2016-05-19 16:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 16:59:56 --> CSRF cookie sent
INFO - 2016-05-19 16:59:56 --> CSRF token verified
INFO - 2016-05-19 16:59:56 --> Input Class Initialized
INFO - 2016-05-19 16:59:56 --> Language Class Initialized
INFO - 2016-05-19 16:59:56 --> Loader Class Initialized
INFO - 2016-05-19 16:59:56 --> Helper loaded: form_helper
INFO - 2016-05-19 16:59:56 --> Database Driver Class Initialized
INFO - 2016-05-19 16:59:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 16:59:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 16:59:56 --> Email Class Initialized
INFO - 2016-05-19 16:59:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 16:59:56 --> Helper loaded: cookie_helper
INFO - 2016-05-19 16:59:56 --> Helper loaded: language_helper
INFO - 2016-05-19 16:59:56 --> Helper loaded: url_helper
DEBUG - 2016-05-19 16:59:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 16:59:56 --> Model Class Initialized
INFO - 2016-05-19 16:59:56 --> Helper loaded: date_helper
INFO - 2016-05-19 16:59:56 --> Controller Class Initialized
INFO - 2016-05-19 16:59:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 16:59:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 16:59:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 16:59:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 16:59:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 16:59:56 --> Model Class Initialized
INFO - 2016-05-19 16:59:56 --> Form Validation Class Initialized
INFO - 2016-05-19 16:59:56 --> Helper loaded: languages_helper
INFO - 2016-05-19 16:59:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 16:59:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 16:59:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 16:59:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 16:59:56 --> Final output sent to browser
DEBUG - 2016-05-19 16:59:56 --> Total execution time: 0.0777
INFO - 2016-05-19 17:02:57 --> Config Class Initialized
INFO - 2016-05-19 17:02:57 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:02:57 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:02:57 --> Utf8 Class Initialized
INFO - 2016-05-19 17:02:57 --> URI Class Initialized
INFO - 2016-05-19 17:02:57 --> Router Class Initialized
INFO - 2016-05-19 17:02:57 --> Output Class Initialized
INFO - 2016-05-19 17:02:57 --> Security Class Initialized
DEBUG - 2016-05-19 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:02:57 --> CSRF cookie sent
INFO - 2016-05-19 17:02:57 --> Input Class Initialized
INFO - 2016-05-19 17:02:57 --> Language Class Initialized
INFO - 2016-05-19 17:02:57 --> Loader Class Initialized
INFO - 2016-05-19 17:02:57 --> Helper loaded: form_helper
INFO - 2016-05-19 17:02:57 --> Database Driver Class Initialized
INFO - 2016-05-19 17:02:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:02:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:02:57 --> Email Class Initialized
INFO - 2016-05-19 17:02:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:02:57 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:02:57 --> Helper loaded: language_helper
INFO - 2016-05-19 17:02:57 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:02:57 --> Model Class Initialized
INFO - 2016-05-19 17:02:57 --> Helper loaded: date_helper
INFO - 2016-05-19 17:02:57 --> Controller Class Initialized
INFO - 2016-05-19 17:02:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:02:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:02:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:02:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:02:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:02:57 --> Model Class Initialized
INFO - 2016-05-19 17:02:57 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:02:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:02:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:02:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:02:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:02:57 --> Final output sent to browser
DEBUG - 2016-05-19 17:02:57 --> Total execution time: 0.1022
INFO - 2016-05-19 17:03:15 --> Config Class Initialized
INFO - 2016-05-19 17:03:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:03:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:03:15 --> Utf8 Class Initialized
INFO - 2016-05-19 17:03:15 --> URI Class Initialized
INFO - 2016-05-19 17:03:15 --> Router Class Initialized
INFO - 2016-05-19 17:03:15 --> Output Class Initialized
INFO - 2016-05-19 17:03:15 --> Security Class Initialized
DEBUG - 2016-05-19 17:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:03:15 --> CSRF cookie sent
INFO - 2016-05-19 17:03:15 --> CSRF token verified
INFO - 2016-05-19 17:03:15 --> Input Class Initialized
INFO - 2016-05-19 17:03:15 --> Language Class Initialized
INFO - 2016-05-19 17:03:15 --> Loader Class Initialized
INFO - 2016-05-19 17:03:15 --> Helper loaded: form_helper
INFO - 2016-05-19 17:03:15 --> Database Driver Class Initialized
INFO - 2016-05-19 17:03:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:03:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:03:15 --> Email Class Initialized
INFO - 2016-05-19 17:03:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:03:15 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:03:15 --> Helper loaded: language_helper
INFO - 2016-05-19 17:03:15 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:03:15 --> Model Class Initialized
INFO - 2016-05-19 17:03:15 --> Helper loaded: date_helper
INFO - 2016-05-19 17:03:15 --> Controller Class Initialized
INFO - 2016-05-19 17:03:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:03:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:03:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:03:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:03:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:03:16 --> Model Class Initialized
INFO - 2016-05-19 17:03:16 --> Form Validation Class Initialized
ERROR - 2016-05-19 17:03:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@yahoo.com' at line 1 - Invalid query: SELECT `email` FROM `tokens` WHERE `fk_user` = 2 AND `email` = tadam@yahoo.com 
INFO - 2016-05-19 17:03:45 --> Config Class Initialized
INFO - 2016-05-19 17:03:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:03:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:03:45 --> Utf8 Class Initialized
INFO - 2016-05-19 17:03:45 --> URI Class Initialized
INFO - 2016-05-19 17:03:45 --> Router Class Initialized
INFO - 2016-05-19 17:03:45 --> Output Class Initialized
INFO - 2016-05-19 17:03:45 --> Security Class Initialized
DEBUG - 2016-05-19 17:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:03:45 --> CSRF cookie sent
INFO - 2016-05-19 17:03:45 --> Input Class Initialized
INFO - 2016-05-19 17:03:45 --> Language Class Initialized
INFO - 2016-05-19 17:03:45 --> Loader Class Initialized
INFO - 2016-05-19 17:03:45 --> Helper loaded: form_helper
INFO - 2016-05-19 17:03:45 --> Database Driver Class Initialized
INFO - 2016-05-19 17:03:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:03:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:03:45 --> Email Class Initialized
INFO - 2016-05-19 17:03:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:03:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:03:45 --> Helper loaded: language_helper
INFO - 2016-05-19 17:03:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:03:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:03:45 --> Model Class Initialized
INFO - 2016-05-19 17:03:45 --> Helper loaded: date_helper
INFO - 2016-05-19 17:03:45 --> Controller Class Initialized
INFO - 2016-05-19 17:03:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:03:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:03:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:03:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:03:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:03:45 --> Model Class Initialized
INFO - 2016-05-19 17:03:45 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:03:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:03:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:03:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:03:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:03:45 --> Final output sent to browser
DEBUG - 2016-05-19 17:03:45 --> Total execution time: 0.1091
INFO - 2016-05-19 17:03:52 --> Config Class Initialized
INFO - 2016-05-19 17:03:52 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:03:52 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:03:52 --> Utf8 Class Initialized
INFO - 2016-05-19 17:03:52 --> URI Class Initialized
INFO - 2016-05-19 17:03:52 --> Router Class Initialized
INFO - 2016-05-19 17:03:52 --> Output Class Initialized
INFO - 2016-05-19 17:03:52 --> Security Class Initialized
DEBUG - 2016-05-19 17:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:03:52 --> CSRF cookie sent
INFO - 2016-05-19 17:03:52 --> CSRF token verified
INFO - 2016-05-19 17:03:52 --> Input Class Initialized
INFO - 2016-05-19 17:03:52 --> Language Class Initialized
INFO - 2016-05-19 17:03:52 --> Loader Class Initialized
INFO - 2016-05-19 17:03:52 --> Helper loaded: form_helper
INFO - 2016-05-19 17:03:52 --> Database Driver Class Initialized
INFO - 2016-05-19 17:03:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:03:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:03:52 --> Email Class Initialized
INFO - 2016-05-19 17:03:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:03:52 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:03:52 --> Helper loaded: language_helper
INFO - 2016-05-19 17:03:52 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:03:52 --> Model Class Initialized
INFO - 2016-05-19 17:03:52 --> Helper loaded: date_helper
INFO - 2016-05-19 17:03:52 --> Controller Class Initialized
INFO - 2016-05-19 17:03:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:03:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:03:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:03:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:03:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:03:52 --> Model Class Initialized
INFO - 2016-05-19 17:03:52 --> Form Validation Class Initialized
INFO - 2016-05-19 17:03:52 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:03:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:03:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:03:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:03:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:03:52 --> Final output sent to browser
DEBUG - 2016-05-19 17:03:52 --> Total execution time: 0.0804
INFO - 2016-05-19 17:17:38 --> Config Class Initialized
INFO - 2016-05-19 17:17:38 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:17:38 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:17:38 --> Utf8 Class Initialized
INFO - 2016-05-19 17:17:38 --> URI Class Initialized
INFO - 2016-05-19 17:17:38 --> Router Class Initialized
INFO - 2016-05-19 17:17:38 --> Output Class Initialized
INFO - 2016-05-19 17:17:38 --> Security Class Initialized
DEBUG - 2016-05-19 17:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:17:38 --> CSRF cookie sent
INFO - 2016-05-19 17:17:38 --> CSRF token verified
INFO - 2016-05-19 17:17:38 --> Input Class Initialized
INFO - 2016-05-19 17:17:38 --> Language Class Initialized
INFO - 2016-05-19 17:17:38 --> Loader Class Initialized
INFO - 2016-05-19 17:17:38 --> Helper loaded: form_helper
INFO - 2016-05-19 17:17:38 --> Database Driver Class Initialized
INFO - 2016-05-19 17:17:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:17:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:17:38 --> Email Class Initialized
INFO - 2016-05-19 17:17:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:17:38 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:17:38 --> Helper loaded: language_helper
INFO - 2016-05-19 17:17:38 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:17:38 --> Model Class Initialized
INFO - 2016-05-19 17:17:38 --> Helper loaded: date_helper
INFO - 2016-05-19 17:17:38 --> Controller Class Initialized
INFO - 2016-05-19 17:17:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:17:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:17:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:17:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:17:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:17:38 --> Model Class Initialized
INFO - 2016-05-19 17:17:38 --> Form Validation Class Initialized
ERROR - 2016-05-19 17:17:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 121
ERROR - 2016-05-19 17:17:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 122
ERROR - 2016-05-19 17:17:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 123
ERROR - 2016-05-19 17:17:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 124
ERROR - 2016-05-19 17:17:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 125
ERROR - 2016-05-19 17:17:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 131
DEBUG - 2016-05-19 17:17:38 --> Email class already loaded. Second attempt ignored.
ERROR - 2016-05-19 17:17:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/demis/www/platformadiabet/system/core/Exceptions.php:272) /home/demis/www/platformadiabet/system/helpers/url_helper.php 561
INFO - 2016-05-19 17:19:12 --> Config Class Initialized
INFO - 2016-05-19 17:19:12 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:19:12 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:19:12 --> Utf8 Class Initialized
INFO - 2016-05-19 17:19:12 --> URI Class Initialized
INFO - 2016-05-19 17:19:12 --> Router Class Initialized
INFO - 2016-05-19 17:19:12 --> Output Class Initialized
INFO - 2016-05-19 17:19:12 --> Security Class Initialized
DEBUG - 2016-05-19 17:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:19:18 --> Config Class Initialized
INFO - 2016-05-19 17:19:18 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:19:18 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:19:18 --> Utf8 Class Initialized
INFO - 2016-05-19 17:19:18 --> URI Class Initialized
INFO - 2016-05-19 17:19:18 --> Router Class Initialized
INFO - 2016-05-19 17:19:18 --> Output Class Initialized
INFO - 2016-05-19 17:19:18 --> Security Class Initialized
DEBUG - 2016-05-19 17:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:19:18 --> CSRF cookie sent
INFO - 2016-05-19 17:19:18 --> Input Class Initialized
INFO - 2016-05-19 17:19:18 --> Language Class Initialized
INFO - 2016-05-19 17:19:18 --> Loader Class Initialized
INFO - 2016-05-19 17:19:18 --> Helper loaded: form_helper
INFO - 2016-05-19 17:19:18 --> Database Driver Class Initialized
INFO - 2016-05-19 17:19:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:19:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:19:18 --> Email Class Initialized
INFO - 2016-05-19 17:19:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:19:18 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:19:18 --> Helper loaded: language_helper
INFO - 2016-05-19 17:19:18 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:19:18 --> Model Class Initialized
INFO - 2016-05-19 17:19:18 --> Helper loaded: date_helper
INFO - 2016-05-19 17:19:18 --> Controller Class Initialized
INFO - 2016-05-19 17:19:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:19:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:19:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:19:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:19:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:19:18 --> Model Class Initialized
INFO - 2016-05-19 17:19:18 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:19:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:19:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:19:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:19:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:19:18 --> Final output sent to browser
DEBUG - 2016-05-19 17:19:18 --> Total execution time: 0.1382
INFO - 2016-05-19 17:19:28 --> Config Class Initialized
INFO - 2016-05-19 17:19:28 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:19:28 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:19:28 --> Utf8 Class Initialized
INFO - 2016-05-19 17:19:28 --> URI Class Initialized
INFO - 2016-05-19 17:19:28 --> Router Class Initialized
INFO - 2016-05-19 17:19:28 --> Output Class Initialized
INFO - 2016-05-19 17:19:28 --> Security Class Initialized
DEBUG - 2016-05-19 17:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:19:28 --> CSRF cookie sent
INFO - 2016-05-19 17:19:28 --> CSRF token verified
INFO - 2016-05-19 17:19:28 --> Input Class Initialized
INFO - 2016-05-19 17:19:28 --> Language Class Initialized
INFO - 2016-05-19 17:19:28 --> Loader Class Initialized
INFO - 2016-05-19 17:19:28 --> Helper loaded: form_helper
INFO - 2016-05-19 17:19:28 --> Database Driver Class Initialized
INFO - 2016-05-19 17:19:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:19:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:19:28 --> Email Class Initialized
INFO - 2016-05-19 17:19:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:19:28 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:19:28 --> Helper loaded: language_helper
INFO - 2016-05-19 17:19:28 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:19:28 --> Model Class Initialized
INFO - 2016-05-19 17:19:28 --> Helper loaded: date_helper
INFO - 2016-05-19 17:19:28 --> Controller Class Initialized
INFO - 2016-05-19 17:19:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:19:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:19:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:19:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:19:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:19:28 --> Model Class Initialized
INFO - 2016-05-19 17:19:28 --> Form Validation Class Initialized
ERROR - 2016-05-19 17:19:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 131
ERROR - 2016-05-19 17:19:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'joWcfyA5u1a3t6LmVJdQOi7pYKGvPNsk'',
            ''2'',
            ''Tadam'',
  ' at line 13 - Invalid query: 
        INSERT INTO 
        	`tokens`
            (
            `token`,
            `fk_user`,
            `name`,
            `email`,
            `type`,
            `_is_active` 
            )
	    VALUES
            (
            ''joWcfyA5u1a3t6LmVJdQOi7pYKGvPNsk'',
            ''2'',
            ''Tadam'',
            ''tadam@yahoo.com'',
            ''family'',
            '1'
            )
		ON 
			DUPLICATE KEY 
		UPDATE
			`email` = '->escape(tadam@yahoo.com)'
		
INFO - 2016-05-19 17:20:59 --> Config Class Initialized
INFO - 2016-05-19 17:20:59 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:20:59 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:20:59 --> Utf8 Class Initialized
INFO - 2016-05-19 17:20:59 --> URI Class Initialized
INFO - 2016-05-19 17:20:59 --> Router Class Initialized
INFO - 2016-05-19 17:20:59 --> Output Class Initialized
INFO - 2016-05-19 17:20:59 --> Security Class Initialized
DEBUG - 2016-05-19 17:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:20:59 --> CSRF cookie sent
INFO - 2016-05-19 17:20:59 --> Input Class Initialized
INFO - 2016-05-19 17:20:59 --> Language Class Initialized
INFO - 2016-05-19 17:20:59 --> Loader Class Initialized
INFO - 2016-05-19 17:20:59 --> Helper loaded: form_helper
INFO - 2016-05-19 17:20:59 --> Database Driver Class Initialized
INFO - 2016-05-19 17:20:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:20:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:20:59 --> Email Class Initialized
INFO - 2016-05-19 17:20:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:20:59 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:20:59 --> Helper loaded: language_helper
INFO - 2016-05-19 17:20:59 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:20:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:20:59 --> Model Class Initialized
INFO - 2016-05-19 17:20:59 --> Helper loaded: date_helper
INFO - 2016-05-19 17:20:59 --> Controller Class Initialized
INFO - 2016-05-19 17:20:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:20:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:20:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:20:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:20:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:20:59 --> Model Class Initialized
INFO - 2016-05-19 17:20:59 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:20:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:20:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:20:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:20:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:20:59 --> Final output sent to browser
DEBUG - 2016-05-19 17:20:59 --> Total execution time: 0.0489
INFO - 2016-05-19 17:21:08 --> Config Class Initialized
INFO - 2016-05-19 17:21:08 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:21:08 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:21:08 --> Utf8 Class Initialized
INFO - 2016-05-19 17:21:08 --> URI Class Initialized
INFO - 2016-05-19 17:21:08 --> Router Class Initialized
INFO - 2016-05-19 17:21:08 --> Output Class Initialized
INFO - 2016-05-19 17:21:08 --> Security Class Initialized
DEBUG - 2016-05-19 17:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:21:08 --> CSRF cookie sent
INFO - 2016-05-19 17:21:08 --> CSRF token verified
INFO - 2016-05-19 17:21:08 --> Input Class Initialized
INFO - 2016-05-19 17:21:08 --> Language Class Initialized
INFO - 2016-05-19 17:21:08 --> Loader Class Initialized
INFO - 2016-05-19 17:21:08 --> Helper loaded: form_helper
INFO - 2016-05-19 17:21:08 --> Database Driver Class Initialized
INFO - 2016-05-19 17:21:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:21:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:21:08 --> Email Class Initialized
INFO - 2016-05-19 17:21:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:21:08 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:21:08 --> Helper loaded: language_helper
INFO - 2016-05-19 17:21:08 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:21:08 --> Model Class Initialized
INFO - 2016-05-19 17:21:08 --> Helper loaded: date_helper
INFO - 2016-05-19 17:21:08 --> Controller Class Initialized
INFO - 2016-05-19 17:21:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:21:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:21:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:21:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:21:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:21:08 --> Model Class Initialized
INFO - 2016-05-19 17:21:08 --> Form Validation Class Initialized
ERROR - 2016-05-19 17:21:08 --> Severity: 4096 --> Object of class CI_DB_mysqli_driver could not be converted to string /home/demis/www/platformadiabet/application/models/Diabet_model.php 131
DEBUG - 2016-05-19 17:21:09 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:21:11 --> Config Class Initialized
INFO - 2016-05-19 17:21:11 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:21:11 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:21:11 --> Utf8 Class Initialized
INFO - 2016-05-19 17:21:11 --> URI Class Initialized
INFO - 2016-05-19 17:21:11 --> Router Class Initialized
INFO - 2016-05-19 17:21:11 --> Output Class Initialized
INFO - 2016-05-19 17:21:11 --> Security Class Initialized
DEBUG - 2016-05-19 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:21:11 --> CSRF cookie sent
INFO - 2016-05-19 17:21:11 --> Input Class Initialized
INFO - 2016-05-19 17:21:11 --> Language Class Initialized
INFO - 2016-05-19 17:21:11 --> Loader Class Initialized
INFO - 2016-05-19 17:21:11 --> Helper loaded: form_helper
INFO - 2016-05-19 17:21:11 --> Database Driver Class Initialized
INFO - 2016-05-19 17:21:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:21:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:21:11 --> Email Class Initialized
INFO - 2016-05-19 17:21:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:21:11 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:21:11 --> Helper loaded: language_helper
INFO - 2016-05-19 17:21:11 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:21:11 --> Model Class Initialized
INFO - 2016-05-19 17:21:11 --> Helper loaded: date_helper
INFO - 2016-05-19 17:21:11 --> Controller Class Initialized
INFO - 2016-05-19 17:21:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:21:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:21:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:21:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:21:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:21:11 --> Model Class Initialized
INFO - 2016-05-19 17:21:11 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:21:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:21:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:21:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:21:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:21:11 --> Final output sent to browser
DEBUG - 2016-05-19 17:21:11 --> Total execution time: 0.0539
INFO - 2016-05-19 17:22:31 --> Config Class Initialized
INFO - 2016-05-19 17:22:31 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:22:31 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:22:31 --> Utf8 Class Initialized
INFO - 2016-05-19 17:22:31 --> URI Class Initialized
INFO - 2016-05-19 17:22:31 --> Router Class Initialized
INFO - 2016-05-19 17:22:31 --> Output Class Initialized
INFO - 2016-05-19 17:22:31 --> Security Class Initialized
DEBUG - 2016-05-19 17:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:22:31 --> CSRF cookie sent
INFO - 2016-05-19 17:22:31 --> Input Class Initialized
INFO - 2016-05-19 17:22:31 --> Language Class Initialized
INFO - 2016-05-19 17:22:31 --> Loader Class Initialized
INFO - 2016-05-19 17:22:31 --> Helper loaded: form_helper
INFO - 2016-05-19 17:22:31 --> Database Driver Class Initialized
INFO - 2016-05-19 17:22:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:22:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:22:31 --> Email Class Initialized
INFO - 2016-05-19 17:22:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:22:31 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:22:31 --> Helper loaded: language_helper
INFO - 2016-05-19 17:22:31 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:22:31 --> Model Class Initialized
INFO - 2016-05-19 17:22:31 --> Helper loaded: date_helper
INFO - 2016-05-19 17:22:32 --> Controller Class Initialized
INFO - 2016-05-19 17:22:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:22:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:22:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:22:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:22:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:22:32 --> Model Class Initialized
INFO - 2016-05-19 17:22:32 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:22:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:22:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:22:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:22:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:22:32 --> Final output sent to browser
DEBUG - 2016-05-19 17:22:32 --> Total execution time: 0.0839
INFO - 2016-05-19 17:23:07 --> Config Class Initialized
INFO - 2016-05-19 17:23:07 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:23:07 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:23:07 --> Utf8 Class Initialized
INFO - 2016-05-19 17:23:07 --> URI Class Initialized
INFO - 2016-05-19 17:23:07 --> Router Class Initialized
INFO - 2016-05-19 17:23:07 --> Output Class Initialized
INFO - 2016-05-19 17:23:07 --> Security Class Initialized
DEBUG - 2016-05-19 17:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:23:07 --> CSRF cookie sent
INFO - 2016-05-19 17:23:07 --> CSRF token verified
INFO - 2016-05-19 17:23:07 --> Input Class Initialized
INFO - 2016-05-19 17:23:07 --> Language Class Initialized
INFO - 2016-05-19 17:23:07 --> Loader Class Initialized
INFO - 2016-05-19 17:23:07 --> Helper loaded: form_helper
INFO - 2016-05-19 17:23:07 --> Database Driver Class Initialized
INFO - 2016-05-19 17:23:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:23:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:23:07 --> Email Class Initialized
INFO - 2016-05-19 17:23:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:23:07 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:23:07 --> Helper loaded: language_helper
INFO - 2016-05-19 17:23:07 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:23:07 --> Model Class Initialized
INFO - 2016-05-19 17:23:07 --> Helper loaded: date_helper
INFO - 2016-05-19 17:23:07 --> Controller Class Initialized
INFO - 2016-05-19 17:23:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:23:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:23:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:23:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:23:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:23:07 --> Model Class Initialized
INFO - 2016-05-19 17:23:07 --> Form Validation Class Initialized
DEBUG - 2016-05-19 17:23:07 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:23:08 --> Config Class Initialized
INFO - 2016-05-19 17:23:08 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:23:08 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:23:08 --> Utf8 Class Initialized
INFO - 2016-05-19 17:23:08 --> URI Class Initialized
INFO - 2016-05-19 17:23:08 --> Router Class Initialized
INFO - 2016-05-19 17:23:08 --> Output Class Initialized
INFO - 2016-05-19 17:23:08 --> Security Class Initialized
DEBUG - 2016-05-19 17:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:23:08 --> CSRF cookie sent
INFO - 2016-05-19 17:23:08 --> Input Class Initialized
INFO - 2016-05-19 17:23:08 --> Language Class Initialized
INFO - 2016-05-19 17:23:08 --> Loader Class Initialized
INFO - 2016-05-19 17:23:08 --> Helper loaded: form_helper
INFO - 2016-05-19 17:23:08 --> Database Driver Class Initialized
INFO - 2016-05-19 17:23:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:23:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:23:08 --> Email Class Initialized
INFO - 2016-05-19 17:23:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:23:08 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:23:08 --> Helper loaded: language_helper
INFO - 2016-05-19 17:23:08 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:23:08 --> Model Class Initialized
INFO - 2016-05-19 17:23:08 --> Helper loaded: date_helper
INFO - 2016-05-19 17:23:08 --> Controller Class Initialized
INFO - 2016-05-19 17:23:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:23:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:23:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:23:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:23:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:23:08 --> Model Class Initialized
INFO - 2016-05-19 17:23:08 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:23:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:23:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:23:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:23:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:23:08 --> Final output sent to browser
DEBUG - 2016-05-19 17:23:08 --> Total execution time: 0.0252
INFO - 2016-05-19 17:24:29 --> Config Class Initialized
INFO - 2016-05-19 17:24:29 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:24:29 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:24:29 --> Utf8 Class Initialized
INFO - 2016-05-19 17:24:29 --> URI Class Initialized
INFO - 2016-05-19 17:24:29 --> Router Class Initialized
INFO - 2016-05-19 17:24:29 --> Output Class Initialized
INFO - 2016-05-19 17:24:29 --> Security Class Initialized
DEBUG - 2016-05-19 17:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:24:29 --> CSRF cookie sent
INFO - 2016-05-19 17:24:29 --> CSRF token verified
INFO - 2016-05-19 17:24:29 --> Input Class Initialized
INFO - 2016-05-19 17:24:29 --> Language Class Initialized
INFO - 2016-05-19 17:24:29 --> Loader Class Initialized
INFO - 2016-05-19 17:24:29 --> Helper loaded: form_helper
INFO - 2016-05-19 17:24:29 --> Database Driver Class Initialized
INFO - 2016-05-19 17:24:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:24:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:24:29 --> Email Class Initialized
INFO - 2016-05-19 17:24:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:24:29 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:24:29 --> Helper loaded: language_helper
INFO - 2016-05-19 17:24:29 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:24:29 --> Model Class Initialized
INFO - 2016-05-19 17:24:29 --> Helper loaded: date_helper
INFO - 2016-05-19 17:24:29 --> Controller Class Initialized
INFO - 2016-05-19 17:24:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:24:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:24:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:24:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:24:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:24:29 --> Model Class Initialized
INFO - 2016-05-19 17:24:29 --> Form Validation Class Initialized
INFO - 2016-05-19 17:24:42 --> Config Class Initialized
INFO - 2016-05-19 17:24:42 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:24:42 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:24:42 --> Utf8 Class Initialized
INFO - 2016-05-19 17:24:42 --> URI Class Initialized
INFO - 2016-05-19 17:24:42 --> Router Class Initialized
INFO - 2016-05-19 17:24:42 --> Output Class Initialized
INFO - 2016-05-19 17:24:42 --> Security Class Initialized
DEBUG - 2016-05-19 17:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:24:42 --> CSRF cookie sent
INFO - 2016-05-19 17:24:42 --> Input Class Initialized
INFO - 2016-05-19 17:24:42 --> Language Class Initialized
INFO - 2016-05-19 17:24:42 --> Loader Class Initialized
INFO - 2016-05-19 17:24:42 --> Helper loaded: form_helper
INFO - 2016-05-19 17:24:42 --> Database Driver Class Initialized
INFO - 2016-05-19 17:24:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:24:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:24:42 --> Email Class Initialized
INFO - 2016-05-19 17:24:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:24:42 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:24:42 --> Helper loaded: language_helper
INFO - 2016-05-19 17:24:42 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:24:42 --> Model Class Initialized
INFO - 2016-05-19 17:24:42 --> Helper loaded: date_helper
INFO - 2016-05-19 17:24:42 --> Controller Class Initialized
INFO - 2016-05-19 17:24:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:24:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:24:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:24:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:24:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:24:42 --> Model Class Initialized
INFO - 2016-05-19 17:24:42 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:24:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:24:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:24:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:24:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:24:43 --> Final output sent to browser
DEBUG - 2016-05-19 17:24:43 --> Total execution time: 0.0803
INFO - 2016-05-19 17:24:53 --> Config Class Initialized
INFO - 2016-05-19 17:24:53 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:24:53 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:24:53 --> Utf8 Class Initialized
INFO - 2016-05-19 17:24:53 --> URI Class Initialized
INFO - 2016-05-19 17:24:53 --> Router Class Initialized
INFO - 2016-05-19 17:24:53 --> Output Class Initialized
INFO - 2016-05-19 17:24:53 --> Security Class Initialized
DEBUG - 2016-05-19 17:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:24:53 --> CSRF cookie sent
INFO - 2016-05-19 17:24:53 --> Input Class Initialized
INFO - 2016-05-19 17:24:53 --> Language Class Initialized
INFO - 2016-05-19 17:24:53 --> Loader Class Initialized
INFO - 2016-05-19 17:24:53 --> Helper loaded: form_helper
INFO - 2016-05-19 17:24:53 --> Database Driver Class Initialized
INFO - 2016-05-19 17:24:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:24:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:24:53 --> Email Class Initialized
INFO - 2016-05-19 17:24:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:24:53 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:24:53 --> Helper loaded: language_helper
INFO - 2016-05-19 17:24:53 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:24:53 --> Model Class Initialized
INFO - 2016-05-19 17:24:53 --> Helper loaded: date_helper
INFO - 2016-05-19 17:24:53 --> Controller Class Initialized
INFO - 2016-05-19 17:24:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:24:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:24:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:24:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:24:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:24:53 --> Model Class Initialized
INFO - 2016-05-19 17:24:53 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:24:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:24:53 --> Final output sent to browser
DEBUG - 2016-05-19 17:24:53 --> Total execution time: 0.0734
INFO - 2016-05-19 17:25:45 --> Config Class Initialized
INFO - 2016-05-19 17:25:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:25:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:25:45 --> Utf8 Class Initialized
INFO - 2016-05-19 17:25:45 --> URI Class Initialized
INFO - 2016-05-19 17:25:45 --> Router Class Initialized
INFO - 2016-05-19 17:25:45 --> Output Class Initialized
INFO - 2016-05-19 17:25:45 --> Security Class Initialized
DEBUG - 2016-05-19 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:25:45 --> CSRF cookie sent
INFO - 2016-05-19 17:25:45 --> Input Class Initialized
INFO - 2016-05-19 17:25:45 --> Language Class Initialized
INFO - 2016-05-19 17:25:45 --> Loader Class Initialized
INFO - 2016-05-19 17:25:45 --> Helper loaded: form_helper
INFO - 2016-05-19 17:25:45 --> Database Driver Class Initialized
INFO - 2016-05-19 17:25:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:25:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:25:45 --> Email Class Initialized
INFO - 2016-05-19 17:25:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:25:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:25:45 --> Helper loaded: language_helper
INFO - 2016-05-19 17:25:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:25:45 --> Model Class Initialized
INFO - 2016-05-19 17:25:45 --> Helper loaded: date_helper
INFO - 2016-05-19 17:25:45 --> Controller Class Initialized
INFO - 2016-05-19 17:25:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:25:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:25:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:25:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:25:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:25:45 --> Model Class Initialized
INFO - 2016-05-19 17:25:45 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:25:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:25:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:25:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:25:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:25:45 --> Final output sent to browser
DEBUG - 2016-05-19 17:25:45 --> Total execution time: 0.0835
INFO - 2016-05-19 17:26:15 --> Config Class Initialized
INFO - 2016-05-19 17:26:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:26:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:26:15 --> Utf8 Class Initialized
INFO - 2016-05-19 17:26:15 --> URI Class Initialized
INFO - 2016-05-19 17:26:15 --> Router Class Initialized
INFO - 2016-05-19 17:26:15 --> Output Class Initialized
INFO - 2016-05-19 17:26:15 --> Security Class Initialized
DEBUG - 2016-05-19 17:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:26:15 --> CSRF cookie sent
INFO - 2016-05-19 17:26:15 --> CSRF token verified
INFO - 2016-05-19 17:26:15 --> Input Class Initialized
INFO - 2016-05-19 17:26:15 --> Language Class Initialized
INFO - 2016-05-19 17:26:15 --> Loader Class Initialized
INFO - 2016-05-19 17:26:15 --> Helper loaded: form_helper
INFO - 2016-05-19 17:26:15 --> Database Driver Class Initialized
INFO - 2016-05-19 17:26:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:26:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:26:15 --> Email Class Initialized
INFO - 2016-05-19 17:26:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:26:15 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:26:15 --> Helper loaded: language_helper
INFO - 2016-05-19 17:26:15 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:26:15 --> Model Class Initialized
INFO - 2016-05-19 17:26:15 --> Helper loaded: date_helper
INFO - 2016-05-19 17:26:15 --> Controller Class Initialized
INFO - 2016-05-19 17:26:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:26:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:26:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:26:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:26:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:26:15 --> Model Class Initialized
INFO - 2016-05-19 17:26:15 --> Form Validation Class Initialized
DEBUG - 2016-05-19 17:26:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:26:17 --> Config Class Initialized
INFO - 2016-05-19 17:26:17 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:26:17 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:26:17 --> Utf8 Class Initialized
INFO - 2016-05-19 17:26:17 --> URI Class Initialized
INFO - 2016-05-19 17:26:17 --> Router Class Initialized
INFO - 2016-05-19 17:26:17 --> Output Class Initialized
INFO - 2016-05-19 17:26:17 --> Security Class Initialized
DEBUG - 2016-05-19 17:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:26:17 --> CSRF cookie sent
INFO - 2016-05-19 17:26:17 --> Input Class Initialized
INFO - 2016-05-19 17:26:17 --> Language Class Initialized
INFO - 2016-05-19 17:26:17 --> Loader Class Initialized
INFO - 2016-05-19 17:26:17 --> Helper loaded: form_helper
INFO - 2016-05-19 17:26:17 --> Database Driver Class Initialized
INFO - 2016-05-19 17:26:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:26:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:26:17 --> Email Class Initialized
INFO - 2016-05-19 17:26:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:26:17 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:26:17 --> Helper loaded: language_helper
INFO - 2016-05-19 17:26:17 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:26:17 --> Model Class Initialized
INFO - 2016-05-19 17:26:17 --> Helper loaded: date_helper
INFO - 2016-05-19 17:26:17 --> Controller Class Initialized
INFO - 2016-05-19 17:26:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:26:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:26:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:26:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:26:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:26:17 --> Model Class Initialized
INFO - 2016-05-19 17:26:17 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:26:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:26:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:26:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:26:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:26:17 --> Final output sent to browser
DEBUG - 2016-05-19 17:26:17 --> Total execution time: 0.0314
INFO - 2016-05-19 17:44:55 --> Config Class Initialized
INFO - 2016-05-19 17:44:55 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:44:55 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:44:55 --> Utf8 Class Initialized
INFO - 2016-05-19 17:44:55 --> URI Class Initialized
INFO - 2016-05-19 17:44:55 --> Router Class Initialized
INFO - 2016-05-19 17:44:55 --> Output Class Initialized
INFO - 2016-05-19 17:44:55 --> Security Class Initialized
DEBUG - 2016-05-19 17:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:44:55 --> CSRF cookie sent
INFO - 2016-05-19 17:44:55 --> Input Class Initialized
INFO - 2016-05-19 17:44:55 --> Language Class Initialized
INFO - 2016-05-19 17:44:55 --> Loader Class Initialized
INFO - 2016-05-19 17:44:55 --> Helper loaded: form_helper
INFO - 2016-05-19 17:44:55 --> Database Driver Class Initialized
INFO - 2016-05-19 17:44:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:44:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:44:55 --> Email Class Initialized
INFO - 2016-05-19 17:44:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:44:55 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:44:55 --> Helper loaded: language_helper
INFO - 2016-05-19 17:44:55 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:44:55 --> Model Class Initialized
INFO - 2016-05-19 17:44:55 --> Helper loaded: date_helper
INFO - 2016-05-19 17:44:55 --> Controller Class Initialized
INFO - 2016-05-19 17:44:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:44:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:44:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:44:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:44:55 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-19 17:44:55 --> Severity: Compile Error --> Cannot redeclare Diabet_model::checkEmail() /home/demis/www/platformadiabet/application/models/Diabet_model.php 158
INFO - 2016-05-19 17:45:37 --> Config Class Initialized
INFO - 2016-05-19 17:45:37 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:45:37 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:45:37 --> Utf8 Class Initialized
INFO - 2016-05-19 17:45:37 --> URI Class Initialized
INFO - 2016-05-19 17:45:37 --> Router Class Initialized
INFO - 2016-05-19 17:45:37 --> Output Class Initialized
INFO - 2016-05-19 17:45:37 --> Security Class Initialized
DEBUG - 2016-05-19 17:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:45:37 --> CSRF cookie sent
INFO - 2016-05-19 17:45:37 --> Input Class Initialized
INFO - 2016-05-19 17:45:37 --> Language Class Initialized
INFO - 2016-05-19 17:45:37 --> Loader Class Initialized
INFO - 2016-05-19 17:45:37 --> Helper loaded: form_helper
INFO - 2016-05-19 17:45:37 --> Database Driver Class Initialized
INFO - 2016-05-19 17:45:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:45:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:45:37 --> Email Class Initialized
INFO - 2016-05-19 17:45:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:45:37 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:45:37 --> Helper loaded: language_helper
INFO - 2016-05-19 17:45:37 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:45:37 --> Model Class Initialized
INFO - 2016-05-19 17:45:37 --> Helper loaded: date_helper
INFO - 2016-05-19 17:45:37 --> Controller Class Initialized
INFO - 2016-05-19 17:45:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:45:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:45:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:45:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:45:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:45:37 --> Model Class Initialized
INFO - 2016-05-19 17:45:37 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:45:37 --> Final output sent to browser
DEBUG - 2016-05-19 17:45:37 --> Total execution time: 0.0483
INFO - 2016-05-19 17:46:27 --> Config Class Initialized
INFO - 2016-05-19 17:46:27 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:46:27 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:46:27 --> Utf8 Class Initialized
INFO - 2016-05-19 17:46:27 --> URI Class Initialized
INFO - 2016-05-19 17:46:27 --> Router Class Initialized
INFO - 2016-05-19 17:46:27 --> Output Class Initialized
INFO - 2016-05-19 17:46:27 --> Security Class Initialized
DEBUG - 2016-05-19 17:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:46:27 --> CSRF cookie sent
INFO - 2016-05-19 17:46:27 --> Input Class Initialized
INFO - 2016-05-19 17:46:27 --> Language Class Initialized
INFO - 2016-05-19 17:46:27 --> Loader Class Initialized
INFO - 2016-05-19 17:46:27 --> Helper loaded: form_helper
INFO - 2016-05-19 17:46:27 --> Database Driver Class Initialized
INFO - 2016-05-19 17:46:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:46:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:46:27 --> Email Class Initialized
INFO - 2016-05-19 17:46:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:46:27 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:46:27 --> Helper loaded: language_helper
INFO - 2016-05-19 17:46:27 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:46:27 --> Model Class Initialized
INFO - 2016-05-19 17:46:27 --> Helper loaded: date_helper
INFO - 2016-05-19 17:46:27 --> Controller Class Initialized
INFO - 2016-05-19 17:46:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:46:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:46:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:46:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:46:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:46:27 --> Model Class Initialized
INFO - 2016-05-19 17:46:27 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:46:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:46:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:46:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:46:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:46:27 --> Final output sent to browser
DEBUG - 2016-05-19 17:46:27 --> Total execution time: 0.0666
INFO - 2016-05-19 17:46:44 --> Config Class Initialized
INFO - 2016-05-19 17:46:44 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:46:44 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:46:44 --> Utf8 Class Initialized
INFO - 2016-05-19 17:46:44 --> URI Class Initialized
INFO - 2016-05-19 17:46:44 --> Router Class Initialized
INFO - 2016-05-19 17:46:44 --> Output Class Initialized
INFO - 2016-05-19 17:46:44 --> Security Class Initialized
DEBUG - 2016-05-19 17:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:46:44 --> CSRF cookie sent
INFO - 2016-05-19 17:46:44 --> CSRF token verified
INFO - 2016-05-19 17:46:44 --> Input Class Initialized
INFO - 2016-05-19 17:46:44 --> Language Class Initialized
INFO - 2016-05-19 17:46:44 --> Loader Class Initialized
INFO - 2016-05-19 17:46:44 --> Helper loaded: form_helper
INFO - 2016-05-19 17:46:44 --> Database Driver Class Initialized
INFO - 2016-05-19 17:46:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:46:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:46:44 --> Email Class Initialized
INFO - 2016-05-19 17:46:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:46:44 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:46:44 --> Helper loaded: language_helper
INFO - 2016-05-19 17:46:44 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:46:44 --> Model Class Initialized
INFO - 2016-05-19 17:46:44 --> Helper loaded: date_helper
INFO - 2016-05-19 17:46:44 --> Controller Class Initialized
INFO - 2016-05-19 17:46:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:46:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:46:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:46:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:46:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:46:44 --> Model Class Initialized
INFO - 2016-05-19 17:46:44 --> Form Validation Class Initialized
DEBUG - 2016-05-19 17:46:44 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:46:47 --> Config Class Initialized
INFO - 2016-05-19 17:46:47 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:46:47 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:46:47 --> Utf8 Class Initialized
INFO - 2016-05-19 17:46:47 --> URI Class Initialized
INFO - 2016-05-19 17:46:47 --> Router Class Initialized
INFO - 2016-05-19 17:46:47 --> Output Class Initialized
INFO - 2016-05-19 17:46:47 --> Security Class Initialized
DEBUG - 2016-05-19 17:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:46:47 --> CSRF cookie sent
INFO - 2016-05-19 17:46:47 --> Input Class Initialized
INFO - 2016-05-19 17:46:47 --> Language Class Initialized
INFO - 2016-05-19 17:46:47 --> Loader Class Initialized
INFO - 2016-05-19 17:46:47 --> Helper loaded: form_helper
INFO - 2016-05-19 17:46:47 --> Database Driver Class Initialized
INFO - 2016-05-19 17:46:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:46:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:46:47 --> Email Class Initialized
INFO - 2016-05-19 17:46:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:46:47 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:46:47 --> Helper loaded: language_helper
INFO - 2016-05-19 17:46:47 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:46:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:46:47 --> Model Class Initialized
INFO - 2016-05-19 17:46:47 --> Helper loaded: date_helper
INFO - 2016-05-19 17:46:47 --> Controller Class Initialized
INFO - 2016-05-19 17:46:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:46:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:46:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:46:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:46:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:46:47 --> Model Class Initialized
INFO - 2016-05-19 17:46:47 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:46:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:46:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:46:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:46:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:46:47 --> Final output sent to browser
DEBUG - 2016-05-19 17:46:47 --> Total execution time: 0.0764
INFO - 2016-05-19 17:50:21 --> Config Class Initialized
INFO - 2016-05-19 17:50:21 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:50:21 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:50:21 --> Utf8 Class Initialized
INFO - 2016-05-19 17:50:21 --> URI Class Initialized
INFO - 2016-05-19 17:50:21 --> Router Class Initialized
INFO - 2016-05-19 17:50:21 --> Output Class Initialized
INFO - 2016-05-19 17:50:21 --> Security Class Initialized
DEBUG - 2016-05-19 17:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:50:21 --> CSRF cookie sent
INFO - 2016-05-19 17:50:21 --> Input Class Initialized
INFO - 2016-05-19 17:50:21 --> Language Class Initialized
INFO - 2016-05-19 17:50:21 --> Loader Class Initialized
INFO - 2016-05-19 17:50:21 --> Helper loaded: form_helper
INFO - 2016-05-19 17:50:21 --> Database Driver Class Initialized
INFO - 2016-05-19 17:50:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:50:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:50:21 --> Email Class Initialized
INFO - 2016-05-19 17:50:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:50:21 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:50:21 --> Helper loaded: language_helper
INFO - 2016-05-19 17:50:21 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:50:21 --> Model Class Initialized
INFO - 2016-05-19 17:50:21 --> Helper loaded: date_helper
INFO - 2016-05-19 17:50:21 --> Controller Class Initialized
INFO - 2016-05-19 17:50:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:50:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:50:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:50:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:50:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:50:21 --> Model Class Initialized
INFO - 2016-05-19 17:50:21 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:50:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:50:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:50:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:50:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:50:21 --> Final output sent to browser
DEBUG - 2016-05-19 17:50:21 --> Total execution time: 0.0457
INFO - 2016-05-19 17:50:42 --> Config Class Initialized
INFO - 2016-05-19 17:50:42 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:50:42 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:50:42 --> Utf8 Class Initialized
INFO - 2016-05-19 17:50:42 --> URI Class Initialized
INFO - 2016-05-19 17:50:42 --> Router Class Initialized
INFO - 2016-05-19 17:50:42 --> Output Class Initialized
INFO - 2016-05-19 17:50:42 --> Security Class Initialized
DEBUG - 2016-05-19 17:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:50:42 --> CSRF cookie sent
INFO - 2016-05-19 17:50:42 --> CSRF token verified
INFO - 2016-05-19 17:50:42 --> Input Class Initialized
INFO - 2016-05-19 17:50:42 --> Language Class Initialized
INFO - 2016-05-19 17:50:42 --> Loader Class Initialized
INFO - 2016-05-19 17:50:42 --> Helper loaded: form_helper
INFO - 2016-05-19 17:50:42 --> Database Driver Class Initialized
INFO - 2016-05-19 17:50:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:50:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:50:42 --> Email Class Initialized
INFO - 2016-05-19 17:50:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:50:42 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:50:42 --> Helper loaded: language_helper
INFO - 2016-05-19 17:50:42 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:50:42 --> Model Class Initialized
INFO - 2016-05-19 17:50:42 --> Helper loaded: date_helper
INFO - 2016-05-19 17:50:42 --> Controller Class Initialized
INFO - 2016-05-19 17:50:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:50:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:50:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:50:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:50:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:50:42 --> Model Class Initialized
INFO - 2016-05-19 17:50:42 --> Form Validation Class Initialized
DEBUG - 2016-05-19 17:50:42 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:50:44 --> Config Class Initialized
INFO - 2016-05-19 17:50:44 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:50:44 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:50:44 --> Utf8 Class Initialized
INFO - 2016-05-19 17:50:44 --> URI Class Initialized
INFO - 2016-05-19 17:50:44 --> Router Class Initialized
INFO - 2016-05-19 17:50:44 --> Output Class Initialized
INFO - 2016-05-19 17:50:44 --> Security Class Initialized
DEBUG - 2016-05-19 17:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:50:44 --> CSRF cookie sent
INFO - 2016-05-19 17:50:44 --> Input Class Initialized
INFO - 2016-05-19 17:50:44 --> Language Class Initialized
INFO - 2016-05-19 17:50:44 --> Loader Class Initialized
INFO - 2016-05-19 17:50:44 --> Helper loaded: form_helper
INFO - 2016-05-19 17:50:44 --> Database Driver Class Initialized
INFO - 2016-05-19 17:50:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:50:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:50:44 --> Email Class Initialized
INFO - 2016-05-19 17:50:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:50:44 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:50:44 --> Helper loaded: language_helper
INFO - 2016-05-19 17:50:44 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:50:44 --> Model Class Initialized
INFO - 2016-05-19 17:50:44 --> Helper loaded: date_helper
INFO - 2016-05-19 17:50:44 --> Controller Class Initialized
INFO - 2016-05-19 17:50:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:50:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:50:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:50:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:50:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:50:44 --> Model Class Initialized
INFO - 2016-05-19 17:50:44 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:50:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:50:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:50:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:50:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:50:44 --> Final output sent to browser
DEBUG - 2016-05-19 17:50:44 --> Total execution time: 0.0722
INFO - 2016-05-19 17:51:15 --> Config Class Initialized
INFO - 2016-05-19 17:51:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:51:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:51:15 --> Utf8 Class Initialized
INFO - 2016-05-19 17:51:15 --> URI Class Initialized
INFO - 2016-05-19 17:51:15 --> Router Class Initialized
INFO - 2016-05-19 17:51:15 --> Output Class Initialized
INFO - 2016-05-19 17:51:15 --> Security Class Initialized
DEBUG - 2016-05-19 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:51:15 --> CSRF cookie sent
INFO - 2016-05-19 17:51:15 --> CSRF token verified
INFO - 2016-05-19 17:51:15 --> Input Class Initialized
INFO - 2016-05-19 17:51:15 --> Language Class Initialized
INFO - 2016-05-19 17:51:15 --> Loader Class Initialized
INFO - 2016-05-19 17:51:15 --> Helper loaded: form_helper
INFO - 2016-05-19 17:51:15 --> Database Driver Class Initialized
INFO - 2016-05-19 17:51:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:51:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:51:15 --> Email Class Initialized
INFO - 2016-05-19 17:51:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:51:15 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:51:15 --> Helper loaded: language_helper
INFO - 2016-05-19 17:51:15 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:51:15 --> Model Class Initialized
INFO - 2016-05-19 17:51:15 --> Helper loaded: date_helper
INFO - 2016-05-19 17:51:15 --> Controller Class Initialized
INFO - 2016-05-19 17:51:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:51:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:51:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:51:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:51:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:51:15 --> Model Class Initialized
INFO - 2016-05-19 17:51:15 --> Form Validation Class Initialized
DEBUG - 2016-05-19 17:51:15 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:51:17 --> Config Class Initialized
INFO - 2016-05-19 17:51:17 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:51:17 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:51:17 --> Utf8 Class Initialized
INFO - 2016-05-19 17:51:17 --> URI Class Initialized
INFO - 2016-05-19 17:51:17 --> Router Class Initialized
INFO - 2016-05-19 17:51:17 --> Output Class Initialized
INFO - 2016-05-19 17:51:17 --> Security Class Initialized
DEBUG - 2016-05-19 17:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:51:17 --> CSRF cookie sent
INFO - 2016-05-19 17:51:17 --> Input Class Initialized
INFO - 2016-05-19 17:51:17 --> Language Class Initialized
INFO - 2016-05-19 17:51:17 --> Loader Class Initialized
INFO - 2016-05-19 17:51:17 --> Helper loaded: form_helper
INFO - 2016-05-19 17:51:17 --> Database Driver Class Initialized
INFO - 2016-05-19 17:51:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:51:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:51:17 --> Email Class Initialized
INFO - 2016-05-19 17:51:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:51:17 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:51:17 --> Helper loaded: language_helper
INFO - 2016-05-19 17:51:17 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:51:17 --> Model Class Initialized
INFO - 2016-05-19 17:51:17 --> Helper loaded: date_helper
INFO - 2016-05-19 17:51:17 --> Controller Class Initialized
INFO - 2016-05-19 17:51:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:51:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:51:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:51:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:51:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:51:17 --> Model Class Initialized
INFO - 2016-05-19 17:51:17 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:51:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:51:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:51:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:51:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:51:17 --> Final output sent to browser
DEBUG - 2016-05-19 17:51:17 --> Total execution time: 0.0494
INFO - 2016-05-19 17:52:58 --> Config Class Initialized
INFO - 2016-05-19 17:52:58 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:52:58 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:52:58 --> Utf8 Class Initialized
INFO - 2016-05-19 17:52:58 --> URI Class Initialized
INFO - 2016-05-19 17:52:58 --> Router Class Initialized
INFO - 2016-05-19 17:52:58 --> Output Class Initialized
INFO - 2016-05-19 17:52:58 --> Security Class Initialized
DEBUG - 2016-05-19 17:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:52:59 --> CSRF cookie sent
INFO - 2016-05-19 17:52:59 --> Input Class Initialized
INFO - 2016-05-19 17:52:59 --> Language Class Initialized
INFO - 2016-05-19 17:52:59 --> Loader Class Initialized
INFO - 2016-05-19 17:52:59 --> Helper loaded: form_helper
INFO - 2016-05-19 17:52:59 --> Database Driver Class Initialized
INFO - 2016-05-19 17:52:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:52:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:52:59 --> Email Class Initialized
INFO - 2016-05-19 17:52:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:52:59 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:52:59 --> Helper loaded: language_helper
INFO - 2016-05-19 17:52:59 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:52:59 --> Model Class Initialized
INFO - 2016-05-19 17:52:59 --> Helper loaded: date_helper
INFO - 2016-05-19 17:52:59 --> Controller Class Initialized
INFO - 2016-05-19 17:52:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:52:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:52:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:52:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:52:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:52:59 --> Model Class Initialized
INFO - 2016-05-19 17:52:59 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:52:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:52:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:52:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:52:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:52:59 --> Final output sent to browser
DEBUG - 2016-05-19 17:52:59 --> Total execution time: 0.3045
INFO - 2016-05-19 17:53:12 --> Config Class Initialized
INFO - 2016-05-19 17:53:12 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:53:12 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:53:12 --> Utf8 Class Initialized
INFO - 2016-05-19 17:53:12 --> URI Class Initialized
INFO - 2016-05-19 17:53:12 --> Router Class Initialized
INFO - 2016-05-19 17:53:12 --> Output Class Initialized
INFO - 2016-05-19 17:53:12 --> Security Class Initialized
DEBUG - 2016-05-19 17:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:53:12 --> CSRF cookie sent
INFO - 2016-05-19 17:53:12 --> CSRF token verified
INFO - 2016-05-19 17:53:12 --> Input Class Initialized
INFO - 2016-05-19 17:53:12 --> Language Class Initialized
INFO - 2016-05-19 17:53:12 --> Loader Class Initialized
INFO - 2016-05-19 17:53:12 --> Helper loaded: form_helper
INFO - 2016-05-19 17:53:12 --> Database Driver Class Initialized
INFO - 2016-05-19 17:53:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:53:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:53:12 --> Email Class Initialized
INFO - 2016-05-19 17:53:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:53:12 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:53:12 --> Helper loaded: language_helper
INFO - 2016-05-19 17:53:12 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:53:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:53:12 --> Model Class Initialized
INFO - 2016-05-19 17:53:12 --> Helper loaded: date_helper
INFO - 2016-05-19 17:53:12 --> Controller Class Initialized
INFO - 2016-05-19 17:53:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:53:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:53:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:53:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:53:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:53:12 --> Model Class Initialized
INFO - 2016-05-19 17:53:12 --> Form Validation Class Initialized
DEBUG - 2016-05-19 17:53:12 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:53:15 --> Config Class Initialized
INFO - 2016-05-19 17:53:15 --> Hooks Class Initialized
DEBUG - 2016-05-19 17:53:15 --> UTF-8 Support Enabled
INFO - 2016-05-19 17:53:15 --> Utf8 Class Initialized
INFO - 2016-05-19 17:53:15 --> URI Class Initialized
INFO - 2016-05-19 17:53:15 --> Router Class Initialized
INFO - 2016-05-19 17:53:15 --> Output Class Initialized
INFO - 2016-05-19 17:53:15 --> Security Class Initialized
DEBUG - 2016-05-19 17:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 17:53:15 --> CSRF cookie sent
INFO - 2016-05-19 17:53:15 --> Input Class Initialized
INFO - 2016-05-19 17:53:15 --> Language Class Initialized
INFO - 2016-05-19 17:53:15 --> Loader Class Initialized
INFO - 2016-05-19 17:53:15 --> Helper loaded: form_helper
INFO - 2016-05-19 17:53:15 --> Database Driver Class Initialized
INFO - 2016-05-19 17:53:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 17:53:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 17:53:15 --> Email Class Initialized
INFO - 2016-05-19 17:53:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 17:53:15 --> Helper loaded: cookie_helper
INFO - 2016-05-19 17:53:15 --> Helper loaded: language_helper
INFO - 2016-05-19 17:53:15 --> Helper loaded: url_helper
DEBUG - 2016-05-19 17:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 17:53:15 --> Model Class Initialized
INFO - 2016-05-19 17:53:15 --> Helper loaded: date_helper
INFO - 2016-05-19 17:53:15 --> Controller Class Initialized
INFO - 2016-05-19 17:53:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 17:53:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 17:53:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 17:53:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 17:53:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 17:53:15 --> Model Class Initialized
INFO - 2016-05-19 17:53:15 --> Helper loaded: languages_helper
INFO - 2016-05-19 17:53:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 17:53:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 17:53:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 17:53:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 17:53:15 --> Final output sent to browser
DEBUG - 2016-05-19 17:53:15 --> Total execution time: 0.0525
INFO - 2016-05-19 18:03:22 --> Config Class Initialized
INFO - 2016-05-19 18:03:22 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:03:22 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:03:22 --> Utf8 Class Initialized
INFO - 2016-05-19 18:03:22 --> URI Class Initialized
INFO - 2016-05-19 18:03:22 --> Router Class Initialized
INFO - 2016-05-19 18:03:22 --> Output Class Initialized
INFO - 2016-05-19 18:03:22 --> Security Class Initialized
DEBUG - 2016-05-19 18:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:03:22 --> CSRF cookie sent
INFO - 2016-05-19 18:03:22 --> Input Class Initialized
INFO - 2016-05-19 18:03:22 --> Language Class Initialized
INFO - 2016-05-19 18:03:22 --> Loader Class Initialized
INFO - 2016-05-19 18:03:22 --> Helper loaded: form_helper
INFO - 2016-05-19 18:03:22 --> Database Driver Class Initialized
INFO - 2016-05-19 18:03:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:03:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:03:22 --> Email Class Initialized
INFO - 2016-05-19 18:03:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:03:22 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:03:22 --> Helper loaded: language_helper
INFO - 2016-05-19 18:03:22 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:03:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:03:22 --> Model Class Initialized
INFO - 2016-05-19 18:03:22 --> Helper loaded: date_helper
INFO - 2016-05-19 18:03:22 --> Controller Class Initialized
INFO - 2016-05-19 18:03:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:03:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:03:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:03:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:03:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:03:22 --> Model Class Initialized
INFO - 2016-05-19 18:03:22 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:03:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:03:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:03:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:03:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:03:22 --> Final output sent to browser
DEBUG - 2016-05-19 18:03:22 --> Total execution time: 0.0946
INFO - 2016-05-19 18:04:11 --> Config Class Initialized
INFO - 2016-05-19 18:04:11 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:04:11 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:04:11 --> Utf8 Class Initialized
INFO - 2016-05-19 18:04:11 --> URI Class Initialized
INFO - 2016-05-19 18:04:11 --> Router Class Initialized
INFO - 2016-05-19 18:04:11 --> Output Class Initialized
INFO - 2016-05-19 18:04:11 --> Security Class Initialized
DEBUG - 2016-05-19 18:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:04:11 --> CSRF cookie sent
INFO - 2016-05-19 18:04:11 --> Input Class Initialized
INFO - 2016-05-19 18:04:11 --> Language Class Initialized
INFO - 2016-05-19 18:04:11 --> Loader Class Initialized
INFO - 2016-05-19 18:04:11 --> Helper loaded: form_helper
INFO - 2016-05-19 18:04:11 --> Database Driver Class Initialized
INFO - 2016-05-19 18:04:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:04:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:04:11 --> Email Class Initialized
INFO - 2016-05-19 18:04:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:04:11 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:04:11 --> Helper loaded: language_helper
INFO - 2016-05-19 18:04:11 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:04:11 --> Model Class Initialized
INFO - 2016-05-19 18:04:11 --> Helper loaded: date_helper
INFO - 2016-05-19 18:04:11 --> Controller Class Initialized
INFO - 2016-05-19 18:04:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:04:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:04:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:04:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:04:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:04:11 --> Model Class Initialized
INFO - 2016-05-19 18:04:11 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:04:11 --> Final output sent to browser
DEBUG - 2016-05-19 18:04:11 --> Total execution time: 0.0590
INFO - 2016-05-19 18:05:35 --> Config Class Initialized
INFO - 2016-05-19 18:05:35 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:05:35 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:05:35 --> Utf8 Class Initialized
INFO - 2016-05-19 18:05:35 --> URI Class Initialized
INFO - 2016-05-19 18:05:35 --> Router Class Initialized
INFO - 2016-05-19 18:05:35 --> Output Class Initialized
INFO - 2016-05-19 18:05:35 --> Security Class Initialized
DEBUG - 2016-05-19 18:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:05:35 --> CSRF cookie sent
INFO - 2016-05-19 18:05:35 --> Input Class Initialized
INFO - 2016-05-19 18:05:35 --> Language Class Initialized
INFO - 2016-05-19 18:05:35 --> Loader Class Initialized
INFO - 2016-05-19 18:05:35 --> Helper loaded: form_helper
INFO - 2016-05-19 18:05:35 --> Database Driver Class Initialized
INFO - 2016-05-19 18:05:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:05:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:05:35 --> Email Class Initialized
INFO - 2016-05-19 18:05:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:05:35 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:05:35 --> Helper loaded: language_helper
INFO - 2016-05-19 18:05:35 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:05:35 --> Model Class Initialized
INFO - 2016-05-19 18:05:35 --> Helper loaded: date_helper
INFO - 2016-05-19 18:05:35 --> Controller Class Initialized
INFO - 2016-05-19 18:05:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:05:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:05:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:05:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:05:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:05:35 --> Model Class Initialized
INFO - 2016-05-19 18:05:35 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:05:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:05:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:05:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:05:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:05:35 --> Final output sent to browser
DEBUG - 2016-05-19 18:05:35 --> Total execution time: 0.0969
INFO - 2016-05-19 18:05:54 --> Config Class Initialized
INFO - 2016-05-19 18:05:54 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:05:54 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:05:54 --> Utf8 Class Initialized
INFO - 2016-05-19 18:05:54 --> URI Class Initialized
INFO - 2016-05-19 18:05:54 --> Router Class Initialized
INFO - 2016-05-19 18:05:54 --> Output Class Initialized
INFO - 2016-05-19 18:05:54 --> Security Class Initialized
DEBUG - 2016-05-19 18:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:05:54 --> CSRF cookie sent
INFO - 2016-05-19 18:05:54 --> Input Class Initialized
INFO - 2016-05-19 18:05:54 --> Language Class Initialized
INFO - 2016-05-19 18:05:54 --> Loader Class Initialized
INFO - 2016-05-19 18:05:54 --> Helper loaded: form_helper
INFO - 2016-05-19 18:05:54 --> Database Driver Class Initialized
INFO - 2016-05-19 18:05:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:05:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:05:54 --> Email Class Initialized
INFO - 2016-05-19 18:05:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:05:54 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:05:54 --> Helper loaded: language_helper
INFO - 2016-05-19 18:05:54 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:05:54 --> Model Class Initialized
INFO - 2016-05-19 18:05:54 --> Helper loaded: date_helper
INFO - 2016-05-19 18:05:54 --> Controller Class Initialized
INFO - 2016-05-19 18:05:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:05:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:05:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:05:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:05:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:05:54 --> Model Class Initialized
INFO - 2016-05-19 18:05:54 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:05:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:05:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:05:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:05:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:05:54 --> Final output sent to browser
DEBUG - 2016-05-19 18:05:54 --> Total execution time: 0.0669
INFO - 2016-05-19 18:07:45 --> Config Class Initialized
INFO - 2016-05-19 18:07:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:07:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:07:45 --> Utf8 Class Initialized
INFO - 2016-05-19 18:07:45 --> URI Class Initialized
INFO - 2016-05-19 18:07:45 --> Router Class Initialized
INFO - 2016-05-19 18:07:45 --> Output Class Initialized
INFO - 2016-05-19 18:07:45 --> Security Class Initialized
DEBUG - 2016-05-19 18:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:07:45 --> CSRF cookie sent
INFO - 2016-05-19 18:07:45 --> Input Class Initialized
INFO - 2016-05-19 18:07:45 --> Language Class Initialized
INFO - 2016-05-19 18:07:45 --> Loader Class Initialized
INFO - 2016-05-19 18:07:45 --> Helper loaded: form_helper
INFO - 2016-05-19 18:07:45 --> Database Driver Class Initialized
INFO - 2016-05-19 18:07:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:07:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:07:45 --> Email Class Initialized
INFO - 2016-05-19 18:07:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:07:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:07:45 --> Helper loaded: language_helper
INFO - 2016-05-19 18:07:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:07:45 --> Model Class Initialized
INFO - 2016-05-19 18:07:45 --> Helper loaded: date_helper
INFO - 2016-05-19 18:07:45 --> Controller Class Initialized
INFO - 2016-05-19 18:07:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:07:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:07:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:07:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:07:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:07:45 --> Model Class Initialized
INFO - 2016-05-19 18:07:45 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:07:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:07:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:07:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:07:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:07:45 --> Final output sent to browser
DEBUG - 2016-05-19 18:07:45 --> Total execution time: 0.0763
INFO - 2016-05-19 18:08:03 --> Config Class Initialized
INFO - 2016-05-19 18:08:03 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:08:03 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:08:03 --> Utf8 Class Initialized
INFO - 2016-05-19 18:08:03 --> URI Class Initialized
INFO - 2016-05-19 18:08:03 --> Router Class Initialized
INFO - 2016-05-19 18:08:03 --> Output Class Initialized
INFO - 2016-05-19 18:08:03 --> Security Class Initialized
DEBUG - 2016-05-19 18:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:08:03 --> CSRF cookie sent
INFO - 2016-05-19 18:08:03 --> Input Class Initialized
INFO - 2016-05-19 18:08:03 --> Language Class Initialized
INFO - 2016-05-19 18:08:03 --> Loader Class Initialized
INFO - 2016-05-19 18:08:03 --> Helper loaded: form_helper
INFO - 2016-05-19 18:08:03 --> Database Driver Class Initialized
INFO - 2016-05-19 18:08:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:08:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:08:03 --> Email Class Initialized
INFO - 2016-05-19 18:08:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:08:03 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:08:03 --> Helper loaded: language_helper
INFO - 2016-05-19 18:08:03 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:08:03 --> Model Class Initialized
INFO - 2016-05-19 18:08:03 --> Helper loaded: date_helper
INFO - 2016-05-19 18:08:03 --> Controller Class Initialized
INFO - 2016-05-19 18:08:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:08:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:08:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:08:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:08:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:08:03 --> Model Class Initialized
INFO - 2016-05-19 18:08:03 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:08:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:08:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:08:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:08:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:08:03 --> Final output sent to browser
DEBUG - 2016-05-19 18:08:03 --> Total execution time: 0.0798
INFO - 2016-05-19 18:21:02 --> Config Class Initialized
INFO - 2016-05-19 18:21:02 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:21:02 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:21:02 --> Utf8 Class Initialized
INFO - 2016-05-19 18:21:02 --> URI Class Initialized
INFO - 2016-05-19 18:21:02 --> Router Class Initialized
INFO - 2016-05-19 18:21:02 --> Output Class Initialized
INFO - 2016-05-19 18:21:02 --> Security Class Initialized
DEBUG - 2016-05-19 18:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:21:02 --> CSRF cookie sent
INFO - 2016-05-19 18:21:02 --> Input Class Initialized
INFO - 2016-05-19 18:21:02 --> Language Class Initialized
INFO - 2016-05-19 18:21:02 --> Loader Class Initialized
INFO - 2016-05-19 18:21:02 --> Helper loaded: form_helper
INFO - 2016-05-19 18:21:02 --> Database Driver Class Initialized
INFO - 2016-05-19 18:21:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:21:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:21:02 --> Email Class Initialized
INFO - 2016-05-19 18:21:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:21:02 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:21:02 --> Helper loaded: language_helper
INFO - 2016-05-19 18:21:02 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:21:02 --> Model Class Initialized
INFO - 2016-05-19 18:21:02 --> Helper loaded: date_helper
INFO - 2016-05-19 18:21:02 --> Controller Class Initialized
INFO - 2016-05-19 18:21:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:21:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:21:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:21:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:21:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:21:02 --> Model Class Initialized
INFO - 2016-05-19 18:21:02 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:21:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:21:02 --> Final output sent to browser
DEBUG - 2016-05-19 18:21:02 --> Total execution time: 0.0790
INFO - 2016-05-19 18:22:02 --> Config Class Initialized
INFO - 2016-05-19 18:22:02 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:22:02 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:22:02 --> Utf8 Class Initialized
INFO - 2016-05-19 18:22:02 --> URI Class Initialized
INFO - 2016-05-19 18:22:02 --> Router Class Initialized
INFO - 2016-05-19 18:22:02 --> Output Class Initialized
INFO - 2016-05-19 18:22:02 --> Security Class Initialized
DEBUG - 2016-05-19 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:22:02 --> CSRF cookie sent
INFO - 2016-05-19 18:22:02 --> Input Class Initialized
INFO - 2016-05-19 18:22:02 --> Language Class Initialized
INFO - 2016-05-19 18:22:02 --> Loader Class Initialized
INFO - 2016-05-19 18:22:02 --> Helper loaded: form_helper
INFO - 2016-05-19 18:22:02 --> Database Driver Class Initialized
INFO - 2016-05-19 18:22:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:22:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:22:02 --> Email Class Initialized
INFO - 2016-05-19 18:22:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:22:02 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:22:02 --> Helper loaded: language_helper
INFO - 2016-05-19 18:22:02 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:22:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:22:02 --> Model Class Initialized
INFO - 2016-05-19 18:22:02 --> Helper loaded: date_helper
INFO - 2016-05-19 18:22:02 --> Controller Class Initialized
INFO - 2016-05-19 18:22:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:22:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:22:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:22:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:22:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:22:02 --> Model Class Initialized
INFO - 2016-05-19 18:22:02 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:22:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:22:02 --> Final output sent to browser
DEBUG - 2016-05-19 18:22:02 --> Total execution time: 0.0248
INFO - 2016-05-19 18:24:18 --> Config Class Initialized
INFO - 2016-05-19 18:24:18 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:24:18 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:24:18 --> Utf8 Class Initialized
INFO - 2016-05-19 18:24:18 --> URI Class Initialized
INFO - 2016-05-19 18:24:18 --> Router Class Initialized
INFO - 2016-05-19 18:24:18 --> Output Class Initialized
INFO - 2016-05-19 18:24:18 --> Security Class Initialized
DEBUG - 2016-05-19 18:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:24:18 --> CSRF cookie sent
INFO - 2016-05-19 18:24:18 --> Input Class Initialized
INFO - 2016-05-19 18:24:18 --> Language Class Initialized
INFO - 2016-05-19 18:24:18 --> Loader Class Initialized
INFO - 2016-05-19 18:24:18 --> Helper loaded: form_helper
INFO - 2016-05-19 18:24:18 --> Database Driver Class Initialized
INFO - 2016-05-19 18:24:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:24:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:24:18 --> Email Class Initialized
INFO - 2016-05-19 18:24:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:24:18 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:24:18 --> Helper loaded: language_helper
INFO - 2016-05-19 18:24:18 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:24:18 --> Model Class Initialized
INFO - 2016-05-19 18:24:18 --> Helper loaded: date_helper
INFO - 2016-05-19 18:24:18 --> Controller Class Initialized
INFO - 2016-05-19 18:24:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:24:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:24:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:24:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:24:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:24:18 --> Model Class Initialized
INFO - 2016-05-19 18:24:18 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:24:18 --> Final output sent to browser
DEBUG - 2016-05-19 18:24:18 --> Total execution time: 0.0321
INFO - 2016-05-19 18:24:24 --> Config Class Initialized
INFO - 2016-05-19 18:24:24 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:24:24 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:24:24 --> Utf8 Class Initialized
INFO - 2016-05-19 18:24:24 --> URI Class Initialized
INFO - 2016-05-19 18:24:24 --> Router Class Initialized
INFO - 2016-05-19 18:24:24 --> Output Class Initialized
INFO - 2016-05-19 18:24:24 --> Security Class Initialized
DEBUG - 2016-05-19 18:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:24:24 --> CSRF cookie sent
INFO - 2016-05-19 18:24:24 --> Input Class Initialized
INFO - 2016-05-19 18:24:24 --> Language Class Initialized
INFO - 2016-05-19 18:24:24 --> Loader Class Initialized
INFO - 2016-05-19 18:24:24 --> Helper loaded: form_helper
INFO - 2016-05-19 18:24:24 --> Database Driver Class Initialized
INFO - 2016-05-19 18:24:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:24:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:24:24 --> Email Class Initialized
INFO - 2016-05-19 18:24:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:24:24 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:24:24 --> Helper loaded: language_helper
INFO - 2016-05-19 18:24:24 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:24:24 --> Model Class Initialized
INFO - 2016-05-19 18:24:24 --> Helper loaded: date_helper
INFO - 2016-05-19 18:24:24 --> Controller Class Initialized
INFO - 2016-05-19 18:24:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:24:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:24:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:24:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:24:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:24:24 --> Model Class Initialized
INFO - 2016-05-19 18:30:45 --> Config Class Initialized
INFO - 2016-05-19 18:30:45 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:30:45 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:30:45 --> Utf8 Class Initialized
INFO - 2016-05-19 18:30:45 --> URI Class Initialized
INFO - 2016-05-19 18:30:45 --> Router Class Initialized
INFO - 2016-05-19 18:30:45 --> Output Class Initialized
INFO - 2016-05-19 18:30:45 --> Security Class Initialized
DEBUG - 2016-05-19 18:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:30:45 --> CSRF cookie sent
INFO - 2016-05-19 18:30:45 --> Input Class Initialized
INFO - 2016-05-19 18:30:45 --> Language Class Initialized
INFO - 2016-05-19 18:30:45 --> Loader Class Initialized
INFO - 2016-05-19 18:30:45 --> Helper loaded: form_helper
INFO - 2016-05-19 18:30:45 --> Database Driver Class Initialized
INFO - 2016-05-19 18:30:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:30:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:30:45 --> Email Class Initialized
INFO - 2016-05-19 18:30:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:30:45 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:30:45 --> Helper loaded: language_helper
INFO - 2016-05-19 18:30:45 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:30:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:30:45 --> Model Class Initialized
INFO - 2016-05-19 18:30:45 --> Helper loaded: date_helper
INFO - 2016-05-19 18:30:45 --> Controller Class Initialized
INFO - 2016-05-19 18:30:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:30:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:30:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:30:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:30:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:30:45 --> Model Class Initialized
INFO - 2016-05-19 18:30:46 --> Config Class Initialized
INFO - 2016-05-19 18:30:46 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:30:46 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:30:46 --> Utf8 Class Initialized
INFO - 2016-05-19 18:30:46 --> URI Class Initialized
INFO - 2016-05-19 18:30:46 --> Router Class Initialized
INFO - 2016-05-19 18:30:46 --> Output Class Initialized
INFO - 2016-05-19 18:30:46 --> Security Class Initialized
DEBUG - 2016-05-19 18:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:30:46 --> CSRF cookie sent
INFO - 2016-05-19 18:30:46 --> Input Class Initialized
INFO - 2016-05-19 18:30:46 --> Language Class Initialized
INFO - 2016-05-19 18:30:46 --> Loader Class Initialized
INFO - 2016-05-19 18:30:46 --> Helper loaded: form_helper
INFO - 2016-05-19 18:30:46 --> Database Driver Class Initialized
INFO - 2016-05-19 18:30:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:30:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:30:46 --> Email Class Initialized
INFO - 2016-05-19 18:30:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:30:46 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:30:46 --> Helper loaded: language_helper
INFO - 2016-05-19 18:30:46 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:30:46 --> Model Class Initialized
INFO - 2016-05-19 18:30:46 --> Helper loaded: date_helper
INFO - 2016-05-19 18:30:46 --> Controller Class Initialized
INFO - 2016-05-19 18:30:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:30:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:30:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:30:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:30:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:30:46 --> Model Class Initialized
INFO - 2016-05-19 18:30:46 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:30:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:30:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:30:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:30:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:30:46 --> Final output sent to browser
DEBUG - 2016-05-19 18:30:46 --> Total execution time: 0.0681
INFO - 2016-05-19 18:31:59 --> Config Class Initialized
INFO - 2016-05-19 18:31:59 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:31:59 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:31:59 --> Utf8 Class Initialized
INFO - 2016-05-19 18:31:59 --> URI Class Initialized
INFO - 2016-05-19 18:31:59 --> Router Class Initialized
INFO - 2016-05-19 18:31:59 --> Output Class Initialized
INFO - 2016-05-19 18:31:59 --> Security Class Initialized
DEBUG - 2016-05-19 18:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:31:59 --> CSRF cookie sent
INFO - 2016-05-19 18:31:59 --> Input Class Initialized
INFO - 2016-05-19 18:31:59 --> Language Class Initialized
INFO - 2016-05-19 18:31:59 --> Loader Class Initialized
INFO - 2016-05-19 18:31:59 --> Helper loaded: form_helper
INFO - 2016-05-19 18:31:59 --> Database Driver Class Initialized
INFO - 2016-05-19 18:31:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:31:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:31:59 --> Email Class Initialized
INFO - 2016-05-19 18:31:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:31:59 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:31:59 --> Helper loaded: language_helper
INFO - 2016-05-19 18:31:59 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:31:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:31:59 --> Model Class Initialized
INFO - 2016-05-19 18:31:59 --> Helper loaded: date_helper
INFO - 2016-05-19 18:31:59 --> Controller Class Initialized
INFO - 2016-05-19 18:31:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:31:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:31:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:31:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:31:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:31:59 --> Model Class Initialized
INFO - 2016-05-19 18:31:59 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:31:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:31:59 --> Final output sent to browser
DEBUG - 2016-05-19 18:31:59 --> Total execution time: 0.0973
INFO - 2016-05-19 18:33:14 --> Config Class Initialized
INFO - 2016-05-19 18:33:14 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:33:14 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:33:14 --> Utf8 Class Initialized
INFO - 2016-05-19 18:33:14 --> URI Class Initialized
INFO - 2016-05-19 18:33:14 --> Router Class Initialized
INFO - 2016-05-19 18:33:14 --> Output Class Initialized
INFO - 2016-05-19 18:33:14 --> Security Class Initialized
DEBUG - 2016-05-19 18:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:33:14 --> CSRF cookie sent
INFO - 2016-05-19 18:33:14 --> Input Class Initialized
INFO - 2016-05-19 18:33:14 --> Language Class Initialized
INFO - 2016-05-19 18:33:14 --> Loader Class Initialized
INFO - 2016-05-19 18:33:14 --> Helper loaded: form_helper
INFO - 2016-05-19 18:33:14 --> Database Driver Class Initialized
INFO - 2016-05-19 18:33:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:33:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:33:14 --> Email Class Initialized
INFO - 2016-05-19 18:33:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:33:14 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:33:14 --> Helper loaded: language_helper
INFO - 2016-05-19 18:33:14 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:33:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:33:14 --> Model Class Initialized
INFO - 2016-05-19 18:33:14 --> Helper loaded: date_helper
INFO - 2016-05-19 18:33:14 --> Controller Class Initialized
INFO - 2016-05-19 18:33:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:33:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:33:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:33:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:33:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:33:14 --> Model Class Initialized
INFO - 2016-05-19 18:33:14 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:33:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:33:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:33:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:33:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:33:14 --> Final output sent to browser
DEBUG - 2016-05-19 18:33:14 --> Total execution time: 0.0243
INFO - 2016-05-19 18:33:30 --> Config Class Initialized
INFO - 2016-05-19 18:33:30 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:33:30 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:33:30 --> Utf8 Class Initialized
INFO - 2016-05-19 18:33:30 --> URI Class Initialized
INFO - 2016-05-19 18:33:30 --> Router Class Initialized
INFO - 2016-05-19 18:33:30 --> Output Class Initialized
INFO - 2016-05-19 18:33:30 --> Security Class Initialized
DEBUG - 2016-05-19 18:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:33:30 --> CSRF cookie sent
INFO - 2016-05-19 18:33:30 --> Input Class Initialized
INFO - 2016-05-19 18:33:30 --> Language Class Initialized
INFO - 2016-05-19 18:33:30 --> Loader Class Initialized
INFO - 2016-05-19 18:33:30 --> Helper loaded: form_helper
INFO - 2016-05-19 18:33:30 --> Database Driver Class Initialized
INFO - 2016-05-19 18:33:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:33:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:33:30 --> Email Class Initialized
INFO - 2016-05-19 18:33:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:33:30 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:33:30 --> Helper loaded: language_helper
INFO - 2016-05-19 18:33:30 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:33:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:33:30 --> Model Class Initialized
INFO - 2016-05-19 18:33:30 --> Helper loaded: date_helper
INFO - 2016-05-19 18:33:30 --> Controller Class Initialized
INFO - 2016-05-19 18:33:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:33:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:33:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:33:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:33:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:33:30 --> Model Class Initialized
INFO - 2016-05-19 18:33:34 --> Config Class Initialized
INFO - 2016-05-19 18:33:34 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:33:34 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:33:34 --> Utf8 Class Initialized
INFO - 2016-05-19 18:33:34 --> URI Class Initialized
INFO - 2016-05-19 18:33:34 --> Router Class Initialized
INFO - 2016-05-19 18:33:34 --> Output Class Initialized
INFO - 2016-05-19 18:33:34 --> Security Class Initialized
DEBUG - 2016-05-19 18:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:33:34 --> CSRF cookie sent
INFO - 2016-05-19 18:33:34 --> Input Class Initialized
INFO - 2016-05-19 18:33:34 --> Language Class Initialized
INFO - 2016-05-19 18:33:34 --> Loader Class Initialized
INFO - 2016-05-19 18:33:34 --> Helper loaded: form_helper
INFO - 2016-05-19 18:33:34 --> Database Driver Class Initialized
INFO - 2016-05-19 18:33:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:33:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:33:34 --> Email Class Initialized
INFO - 2016-05-19 18:33:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:33:34 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:33:34 --> Helper loaded: language_helper
INFO - 2016-05-19 18:33:34 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:33:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:33:34 --> Model Class Initialized
INFO - 2016-05-19 18:33:34 --> Helper loaded: date_helper
INFO - 2016-05-19 18:33:34 --> Controller Class Initialized
INFO - 2016-05-19 18:33:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:33:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:33:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:33:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:33:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:33:34 --> Model Class Initialized
INFO - 2016-05-19 18:33:34 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:33:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:33:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:33:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:33:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:33:34 --> Final output sent to browser
DEBUG - 2016-05-19 18:33:34 --> Total execution time: 0.0268
INFO - 2016-05-19 18:36:42 --> Config Class Initialized
INFO - 2016-05-19 18:36:42 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:36:42 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:36:42 --> Utf8 Class Initialized
INFO - 2016-05-19 18:36:42 --> URI Class Initialized
INFO - 2016-05-19 18:36:42 --> Router Class Initialized
INFO - 2016-05-19 18:36:42 --> Output Class Initialized
INFO - 2016-05-19 18:36:42 --> Security Class Initialized
DEBUG - 2016-05-19 18:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:36:42 --> CSRF cookie sent
INFO - 2016-05-19 18:36:42 --> Input Class Initialized
INFO - 2016-05-19 18:36:42 --> Language Class Initialized
INFO - 2016-05-19 18:36:42 --> Loader Class Initialized
INFO - 2016-05-19 18:36:42 --> Helper loaded: form_helper
INFO - 2016-05-19 18:36:42 --> Database Driver Class Initialized
INFO - 2016-05-19 18:36:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:36:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:36:42 --> Email Class Initialized
INFO - 2016-05-19 18:36:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:36:42 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:36:42 --> Helper loaded: language_helper
INFO - 2016-05-19 18:36:42 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:36:42 --> Model Class Initialized
INFO - 2016-05-19 18:36:42 --> Helper loaded: date_helper
INFO - 2016-05-19 18:36:42 --> Controller Class Initialized
INFO - 2016-05-19 18:36:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:36:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:36:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:36:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:36:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:36:42 --> Model Class Initialized
INFO - 2016-05-19 18:36:42 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:36:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:36:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:36:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-19 18:36:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:36:43 --> Final output sent to browser
DEBUG - 2016-05-19 18:36:43 --> Total execution time: 0.0327
INFO - 2016-05-19 18:38:19 --> Config Class Initialized
INFO - 2016-05-19 18:38:19 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:38:19 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:38:19 --> Utf8 Class Initialized
INFO - 2016-05-19 18:38:19 --> URI Class Initialized
DEBUG - 2016-05-19 18:38:19 --> No URI present. Default controller set.
INFO - 2016-05-19 18:38:19 --> Router Class Initialized
INFO - 2016-05-19 18:38:19 --> Output Class Initialized
INFO - 2016-05-19 18:38:19 --> Security Class Initialized
DEBUG - 2016-05-19 18:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:38:19 --> CSRF cookie sent
INFO - 2016-05-19 18:38:19 --> Input Class Initialized
INFO - 2016-05-19 18:38:19 --> Language Class Initialized
INFO - 2016-05-19 18:38:19 --> Loader Class Initialized
INFO - 2016-05-19 18:38:19 --> Helper loaded: form_helper
INFO - 2016-05-19 18:38:19 --> Database Driver Class Initialized
INFO - 2016-05-19 18:38:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:38:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:38:19 --> Email Class Initialized
INFO - 2016-05-19 18:38:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:38:19 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:38:19 --> Helper loaded: language_helper
INFO - 2016-05-19 18:38:19 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:38:19 --> Model Class Initialized
INFO - 2016-05-19 18:38:19 --> Helper loaded: date_helper
INFO - 2016-05-19 18:38:19 --> Controller Class Initialized
INFO - 2016-05-19 18:38:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:38:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:38:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:38:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:38:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:38:20 --> Config Class Initialized
INFO - 2016-05-19 18:38:20 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:38:20 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:38:20 --> Utf8 Class Initialized
INFO - 2016-05-19 18:38:20 --> URI Class Initialized
INFO - 2016-05-19 18:38:20 --> Router Class Initialized
INFO - 2016-05-19 18:38:20 --> Output Class Initialized
INFO - 2016-05-19 18:38:20 --> Security Class Initialized
DEBUG - 2016-05-19 18:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:38:20 --> CSRF cookie sent
INFO - 2016-05-19 18:38:20 --> Input Class Initialized
INFO - 2016-05-19 18:38:20 --> Language Class Initialized
INFO - 2016-05-19 18:38:20 --> Loader Class Initialized
INFO - 2016-05-19 18:38:20 --> Helper loaded: form_helper
INFO - 2016-05-19 18:38:20 --> Database Driver Class Initialized
INFO - 2016-05-19 18:38:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:38:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:38:20 --> Email Class Initialized
INFO - 2016-05-19 18:38:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:38:20 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:38:20 --> Helper loaded: language_helper
INFO - 2016-05-19 18:38:20 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:38:20 --> Model Class Initialized
INFO - 2016-05-19 18:38:20 --> Helper loaded: date_helper
INFO - 2016-05-19 18:38:20 --> Controller Class Initialized
INFO - 2016-05-19 18:38:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:38:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:38:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:38:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:38:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:38:20 --> Model Class Initialized
INFO - 2016-05-19 18:38:20 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:38:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:38:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:38:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 18:38:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:38:20 --> Final output sent to browser
DEBUG - 2016-05-19 18:38:20 --> Total execution time: 0.0831
INFO - 2016-05-19 18:40:16 --> Config Class Initialized
INFO - 2016-05-19 18:40:16 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:40:16 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:40:16 --> Utf8 Class Initialized
INFO - 2016-05-19 18:40:16 --> URI Class Initialized
INFO - 2016-05-19 18:40:16 --> Router Class Initialized
INFO - 2016-05-19 18:40:16 --> Output Class Initialized
INFO - 2016-05-19 18:40:16 --> Security Class Initialized
DEBUG - 2016-05-19 18:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:40:16 --> CSRF cookie sent
INFO - 2016-05-19 18:40:16 --> Input Class Initialized
INFO - 2016-05-19 18:40:16 --> Language Class Initialized
INFO - 2016-05-19 18:40:16 --> Loader Class Initialized
INFO - 2016-05-19 18:40:16 --> Helper loaded: form_helper
INFO - 2016-05-19 18:40:16 --> Database Driver Class Initialized
INFO - 2016-05-19 18:40:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:40:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:40:16 --> Email Class Initialized
INFO - 2016-05-19 18:40:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:40:16 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:40:16 --> Helper loaded: language_helper
INFO - 2016-05-19 18:40:16 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:40:16 --> Model Class Initialized
INFO - 2016-05-19 18:40:16 --> Helper loaded: date_helper
INFO - 2016-05-19 18:40:16 --> Controller Class Initialized
INFO - 2016-05-19 18:40:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:40:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:40:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:40:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:40:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:40:16 --> Model Class Initialized
INFO - 2016-05-19 18:40:16 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:40:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:40:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:40:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 18:40:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:40:16 --> Final output sent to browser
DEBUG - 2016-05-19 18:40:16 --> Total execution time: 0.0391
INFO - 2016-05-19 18:40:49 --> Config Class Initialized
INFO - 2016-05-19 18:40:49 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:40:49 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:40:49 --> Utf8 Class Initialized
INFO - 2016-05-19 18:40:49 --> URI Class Initialized
INFO - 2016-05-19 18:40:49 --> Router Class Initialized
INFO - 2016-05-19 18:40:49 --> Output Class Initialized
INFO - 2016-05-19 18:40:49 --> Security Class Initialized
DEBUG - 2016-05-19 18:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:40:49 --> CSRF cookie sent
INFO - 2016-05-19 18:40:49 --> Input Class Initialized
INFO - 2016-05-19 18:40:49 --> Language Class Initialized
INFO - 2016-05-19 18:40:49 --> Loader Class Initialized
INFO - 2016-05-19 18:40:49 --> Helper loaded: form_helper
INFO - 2016-05-19 18:40:49 --> Database Driver Class Initialized
INFO - 2016-05-19 18:40:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:40:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:40:49 --> Email Class Initialized
INFO - 2016-05-19 18:40:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:40:49 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:40:49 --> Helper loaded: language_helper
INFO - 2016-05-19 18:40:49 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:40:49 --> Model Class Initialized
INFO - 2016-05-19 18:40:49 --> Helper loaded: date_helper
INFO - 2016-05-19 18:40:49 --> Controller Class Initialized
INFO - 2016-05-19 18:40:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:40:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:40:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:40:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:40:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:40:49 --> Model Class Initialized
INFO - 2016-05-19 18:40:49 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 18:40:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:40:49 --> Final output sent to browser
DEBUG - 2016-05-19 18:40:49 --> Total execution time: 0.0619
INFO - 2016-05-19 18:40:54 --> Config Class Initialized
INFO - 2016-05-19 18:40:54 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:40:54 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:40:54 --> Utf8 Class Initialized
INFO - 2016-05-19 18:40:54 --> URI Class Initialized
INFO - 2016-05-19 18:40:54 --> Router Class Initialized
INFO - 2016-05-19 18:40:54 --> Output Class Initialized
INFO - 2016-05-19 18:40:54 --> Security Class Initialized
DEBUG - 2016-05-19 18:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:40:54 --> CSRF cookie sent
INFO - 2016-05-19 18:40:54 --> Input Class Initialized
INFO - 2016-05-19 18:40:54 --> Language Class Initialized
INFO - 2016-05-19 18:40:54 --> Loader Class Initialized
INFO - 2016-05-19 18:40:54 --> Helper loaded: form_helper
INFO - 2016-05-19 18:40:54 --> Database Driver Class Initialized
INFO - 2016-05-19 18:40:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:40:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:40:54 --> Email Class Initialized
INFO - 2016-05-19 18:40:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:40:54 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:40:54 --> Helper loaded: language_helper
INFO - 2016-05-19 18:40:54 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:40:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:40:54 --> Model Class Initialized
INFO - 2016-05-19 18:40:54 --> Helper loaded: date_helper
INFO - 2016-05-19 18:40:54 --> Controller Class Initialized
INFO - 2016-05-19 18:40:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:40:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:40:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:40:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:40:54 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 18:40:54 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:40:54 --> Form Validation Class Initialized
INFO - 2016-05-19 18:40:55 --> Config Class Initialized
INFO - 2016-05-19 18:40:55 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:40:55 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:40:55 --> Utf8 Class Initialized
INFO - 2016-05-19 18:40:55 --> URI Class Initialized
INFO - 2016-05-19 18:40:55 --> Router Class Initialized
INFO - 2016-05-19 18:40:55 --> Output Class Initialized
INFO - 2016-05-19 18:40:55 --> Security Class Initialized
DEBUG - 2016-05-19 18:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:40:55 --> CSRF cookie sent
INFO - 2016-05-19 18:40:55 --> Input Class Initialized
INFO - 2016-05-19 18:40:55 --> Language Class Initialized
INFO - 2016-05-19 18:40:55 --> Loader Class Initialized
INFO - 2016-05-19 18:40:55 --> Helper loaded: form_helper
INFO - 2016-05-19 18:40:55 --> Database Driver Class Initialized
INFO - 2016-05-19 18:40:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:40:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:40:55 --> Email Class Initialized
INFO - 2016-05-19 18:40:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:40:55 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:40:55 --> Helper loaded: language_helper
INFO - 2016-05-19 18:40:55 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:40:55 --> Model Class Initialized
INFO - 2016-05-19 18:40:55 --> Helper loaded: date_helper
INFO - 2016-05-19 18:40:55 --> Controller Class Initialized
INFO - 2016-05-19 18:40:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:40:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:40:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:40:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:40:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 18:40:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:40:55 --> Form Validation Class Initialized
ERROR - 2016-05-19 18:40:55 --> Severity: Notice --> Undefined property: Auth::$callType /home/demis/www/platformadiabet/application/core/SVS_Controller.php 116
INFO - 2016-05-19 18:40:55 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:40:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-19 18:40:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-19 18:40:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-19 18:40:55 --> Final output sent to browser
DEBUG - 2016-05-19 18:40:55 --> Total execution time: 0.0304
INFO - 2016-05-19 18:41:22 --> Config Class Initialized
INFO - 2016-05-19 18:41:22 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:41:22 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:41:22 --> Utf8 Class Initialized
INFO - 2016-05-19 18:41:22 --> URI Class Initialized
INFO - 2016-05-19 18:41:22 --> Router Class Initialized
INFO - 2016-05-19 18:41:22 --> Output Class Initialized
INFO - 2016-05-19 18:41:22 --> Security Class Initialized
DEBUG - 2016-05-19 18:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:41:22 --> CSRF cookie sent
INFO - 2016-05-19 18:41:22 --> CSRF token verified
INFO - 2016-05-19 18:41:22 --> Input Class Initialized
INFO - 2016-05-19 18:41:22 --> Language Class Initialized
INFO - 2016-05-19 18:41:22 --> Loader Class Initialized
INFO - 2016-05-19 18:41:22 --> Helper loaded: form_helper
INFO - 2016-05-19 18:41:22 --> Database Driver Class Initialized
INFO - 2016-05-19 18:41:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:41:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:41:22 --> Email Class Initialized
INFO - 2016-05-19 18:41:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:41:22 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:41:22 --> Helper loaded: language_helper
INFO - 2016-05-19 18:41:22 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:41:22 --> Model Class Initialized
INFO - 2016-05-19 18:41:22 --> Helper loaded: date_helper
INFO - 2016-05-19 18:41:22 --> Controller Class Initialized
INFO - 2016-05-19 18:41:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:41:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:41:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:41:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:41:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-19 18:41:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:41:22 --> Form Validation Class Initialized
INFO - 2016-05-19 18:41:25 --> Config Class Initialized
INFO - 2016-05-19 18:41:25 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:41:25 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:41:25 --> Utf8 Class Initialized
INFO - 2016-05-19 18:41:25 --> URI Class Initialized
DEBUG - 2016-05-19 18:41:25 --> No URI present. Default controller set.
INFO - 2016-05-19 18:41:25 --> Router Class Initialized
INFO - 2016-05-19 18:41:25 --> Output Class Initialized
INFO - 2016-05-19 18:41:25 --> Security Class Initialized
DEBUG - 2016-05-19 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:41:25 --> CSRF cookie sent
INFO - 2016-05-19 18:41:25 --> Input Class Initialized
INFO - 2016-05-19 18:41:25 --> Language Class Initialized
INFO - 2016-05-19 18:41:25 --> Loader Class Initialized
INFO - 2016-05-19 18:41:25 --> Helper loaded: form_helper
INFO - 2016-05-19 18:41:25 --> Database Driver Class Initialized
INFO - 2016-05-19 18:41:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:41:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:41:25 --> Email Class Initialized
INFO - 2016-05-19 18:41:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:41:25 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:41:25 --> Helper loaded: language_helper
INFO - 2016-05-19 18:41:25 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:41:25 --> Model Class Initialized
INFO - 2016-05-19 18:41:25 --> Helper loaded: date_helper
INFO - 2016-05-19 18:41:25 --> Controller Class Initialized
INFO - 2016-05-19 18:41:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:41:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:41:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:41:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:41:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:41:26 --> Config Class Initialized
INFO - 2016-05-19 18:41:26 --> Hooks Class Initialized
DEBUG - 2016-05-19 18:41:26 --> UTF-8 Support Enabled
INFO - 2016-05-19 18:41:26 --> Utf8 Class Initialized
INFO - 2016-05-19 18:41:26 --> URI Class Initialized
INFO - 2016-05-19 18:41:26 --> Router Class Initialized
INFO - 2016-05-19 18:41:26 --> Output Class Initialized
INFO - 2016-05-19 18:41:26 --> Security Class Initialized
DEBUG - 2016-05-19 18:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-19 18:41:26 --> CSRF cookie sent
INFO - 2016-05-19 18:41:26 --> Input Class Initialized
INFO - 2016-05-19 18:41:26 --> Language Class Initialized
INFO - 2016-05-19 18:41:26 --> Loader Class Initialized
INFO - 2016-05-19 18:41:26 --> Helper loaded: form_helper
INFO - 2016-05-19 18:41:26 --> Database Driver Class Initialized
INFO - 2016-05-19 18:41:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-19 18:41:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-19 18:41:26 --> Email Class Initialized
INFO - 2016-05-19 18:41:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-19 18:41:26 --> Helper loaded: cookie_helper
INFO - 2016-05-19 18:41:26 --> Helper loaded: language_helper
INFO - 2016-05-19 18:41:26 --> Helper loaded: url_helper
DEBUG - 2016-05-19 18:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-19 18:41:26 --> Model Class Initialized
INFO - 2016-05-19 18:41:26 --> Helper loaded: date_helper
INFO - 2016-05-19 18:41:26 --> Controller Class Initialized
INFO - 2016-05-19 18:41:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-19 18:41:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-19 18:41:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-19 18:41:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-19 18:41:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-19 18:41:26 --> Model Class Initialized
INFO - 2016-05-19 18:41:26 --> Helper loaded: languages_helper
INFO - 2016-05-19 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-19 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-19 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-19 18:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-19 18:41:26 --> Final output sent to browser
DEBUG - 2016-05-19 18:41:26 --> Total execution time: 0.0625
