<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-23 03:51:46 --> Config Class Initialized
INFO - 2016-06-23 03:51:46 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:51:46 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:51:46 --> Utf8 Class Initialized
INFO - 2016-06-23 03:51:46 --> URI Class Initialized
DEBUG - 2016-06-23 03:51:46 --> No URI present. Default controller set.
INFO - 2016-06-23 03:51:46 --> Router Class Initialized
INFO - 2016-06-23 03:51:46 --> Output Class Initialized
INFO - 2016-06-23 03:51:46 --> Security Class Initialized
DEBUG - 2016-06-23 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:51:46 --> Input Class Initialized
INFO - 2016-06-23 03:51:46 --> Language Class Initialized
INFO - 2016-06-23 03:51:46 --> Loader Class Initialized
INFO - 2016-06-23 03:51:46 --> Helper loaded: form_helper
INFO - 2016-06-23 03:51:47 --> Database Driver Class Initialized
INFO - 2016-06-23 03:51:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:51:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:51:47 --> Email Class Initialized
INFO - 2016-06-23 03:51:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:51:47 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:51:47 --> Helper loaded: language_helper
INFO - 2016-06-23 03:51:47 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:51:47 --> Model Class Initialized
INFO - 2016-06-23 03:51:47 --> Helper loaded: date_helper
INFO - 2016-06-23 03:51:47 --> Controller Class Initialized
INFO - 2016-06-23 03:51:47 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:51:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:51:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:51:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:51:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:51:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:51:47 --> Model Class Initialized
INFO - 2016-06-23 06:51:47 --> Form Validation Class Initialized
INFO - 2016-06-23 06:51:47 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 06:51:47 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 06:51:47 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 06:51:47 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 06:51:47 --> Final output sent to browser
DEBUG - 2016-06-23 06:51:47 --> Total execution time: 0.7891
INFO - 2016-06-23 03:51:49 --> Config Class Initialized
INFO - 2016-06-23 03:51:49 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:51:49 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:51:49 --> Utf8 Class Initialized
INFO - 2016-06-23 03:51:49 --> URI Class Initialized
INFO - 2016-06-23 03:51:49 --> Router Class Initialized
INFO - 2016-06-23 03:51:49 --> Output Class Initialized
INFO - 2016-06-23 03:51:49 --> Security Class Initialized
DEBUG - 2016-06-23 03:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:51:49 --> Input Class Initialized
INFO - 2016-06-23 03:51:49 --> Language Class Initialized
INFO - 2016-06-23 03:51:49 --> Loader Class Initialized
INFO - 2016-06-23 03:51:49 --> Helper loaded: form_helper
INFO - 2016-06-23 03:51:49 --> Database Driver Class Initialized
INFO - 2016-06-23 03:51:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:51:49 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:51:49 --> Email Class Initialized
INFO - 2016-06-23 03:51:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:51:49 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:51:49 --> Helper loaded: language_helper
INFO - 2016-06-23 03:51:49 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:51:49 --> Model Class Initialized
INFO - 2016-06-23 03:51:49 --> Helper loaded: date_helper
INFO - 2016-06-23 03:51:49 --> Controller Class Initialized
INFO - 2016-06-23 03:51:49 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:51:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:51:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:51:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:51:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:51:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:51:49 --> Model Class Initialized
INFO - 2016-06-23 06:51:49 --> Final output sent to browser
DEBUG - 2016-06-23 06:51:49 --> Total execution time: 0.2563
INFO - 2016-06-23 03:52:02 --> Config Class Initialized
INFO - 2016-06-23 03:52:02 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:52:02 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:52:02 --> Utf8 Class Initialized
INFO - 2016-06-23 03:52:02 --> URI Class Initialized
INFO - 2016-06-23 03:52:02 --> Router Class Initialized
INFO - 2016-06-23 03:52:02 --> Output Class Initialized
INFO - 2016-06-23 03:52:02 --> Security Class Initialized
DEBUG - 2016-06-23 03:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:52:02 --> Input Class Initialized
INFO - 2016-06-23 03:52:02 --> Language Class Initialized
INFO - 2016-06-23 03:52:02 --> Loader Class Initialized
INFO - 2016-06-23 03:52:02 --> Helper loaded: form_helper
INFO - 2016-06-23 03:52:02 --> Database Driver Class Initialized
INFO - 2016-06-23 03:52:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:52:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:52:02 --> Email Class Initialized
INFO - 2016-06-23 03:52:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:52:02 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:52:02 --> Helper loaded: language_helper
INFO - 2016-06-23 03:52:02 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:52:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:52:02 --> Model Class Initialized
INFO - 2016-06-23 03:52:02 --> Helper loaded: date_helper
INFO - 2016-06-23 03:52:02 --> Controller Class Initialized
INFO - 2016-06-23 03:52:02 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:52:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:52:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:52:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:52:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:52:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 06:52:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 06:52:02 --> Form Validation Class Initialized
DEBUG - 2016-06-23 06:52:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-23 06:52:02 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 06:52:02 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 06:52:02 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 06:52:02 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 06:52:02 --> Final output sent to browser
DEBUG - 2016-06-23 06:52:02 --> Total execution time: 0.1469
INFO - 2016-06-23 03:52:03 --> Config Class Initialized
INFO - 2016-06-23 03:52:03 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:52:03 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:52:03 --> Utf8 Class Initialized
INFO - 2016-06-23 03:52:03 --> URI Class Initialized
INFO - 2016-06-23 03:52:03 --> Router Class Initialized
INFO - 2016-06-23 03:52:03 --> Output Class Initialized
INFO - 2016-06-23 03:52:03 --> Security Class Initialized
DEBUG - 2016-06-23 03:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:52:03 --> Input Class Initialized
INFO - 2016-06-23 03:52:03 --> Language Class Initialized
INFO - 2016-06-23 03:52:03 --> Loader Class Initialized
INFO - 2016-06-23 03:52:03 --> Helper loaded: form_helper
INFO - 2016-06-23 03:52:03 --> Database Driver Class Initialized
INFO - 2016-06-23 03:52:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:52:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:52:03 --> Email Class Initialized
INFO - 2016-06-23 03:52:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:52:03 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:52:03 --> Helper loaded: language_helper
INFO - 2016-06-23 03:52:03 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:52:03 --> Model Class Initialized
INFO - 2016-06-23 03:52:03 --> Helper loaded: date_helper
INFO - 2016-06-23 03:52:03 --> Controller Class Initialized
INFO - 2016-06-23 03:52:03 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:52:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:52:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:52:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:52:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:52:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:52:03 --> Model Class Initialized
INFO - 2016-06-23 06:52:03 --> Final output sent to browser
DEBUG - 2016-06-23 06:52:03 --> Total execution time: 0.0824
INFO - 2016-06-23 03:52:09 --> Config Class Initialized
INFO - 2016-06-23 03:52:09 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:52:09 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:52:09 --> Utf8 Class Initialized
INFO - 2016-06-23 03:52:09 --> URI Class Initialized
INFO - 2016-06-23 03:52:10 --> Router Class Initialized
INFO - 2016-06-23 03:52:10 --> Output Class Initialized
INFO - 2016-06-23 03:52:10 --> Security Class Initialized
DEBUG - 2016-06-23 03:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:52:10 --> Input Class Initialized
INFO - 2016-06-23 03:52:10 --> Language Class Initialized
INFO - 2016-06-23 03:52:10 --> Loader Class Initialized
INFO - 2016-06-23 03:52:10 --> Helper loaded: form_helper
INFO - 2016-06-23 03:52:10 --> Database Driver Class Initialized
INFO - 2016-06-23 03:52:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:52:10 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:52:10 --> Email Class Initialized
INFO - 2016-06-23 03:52:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:52:10 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:52:10 --> Helper loaded: language_helper
INFO - 2016-06-23 03:52:10 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:52:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:52:10 --> Model Class Initialized
INFO - 2016-06-23 03:52:10 --> Helper loaded: date_helper
INFO - 2016-06-23 03:52:10 --> Controller Class Initialized
INFO - 2016-06-23 03:52:10 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:52:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:52:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:52:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:52:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:52:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 06:52:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 06:52:10 --> Form Validation Class Initialized
INFO - 2016-06-23 06:52:10 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 06:52:10 --> File loaded: /home/diabet/public_html/application/views/auth/create_user.php
INFO - 2016-06-23 06:52:10 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 06:52:10 --> Final output sent to browser
DEBUG - 2016-06-23 06:52:10 --> Total execution time: 0.1118
INFO - 2016-06-23 03:52:35 --> Config Class Initialized
INFO - 2016-06-23 03:52:35 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:52:35 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:52:35 --> Utf8 Class Initialized
INFO - 2016-06-23 03:52:35 --> URI Class Initialized
INFO - 2016-06-23 03:52:35 --> Router Class Initialized
INFO - 2016-06-23 03:52:35 --> Output Class Initialized
INFO - 2016-06-23 03:52:35 --> Security Class Initialized
DEBUG - 2016-06-23 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:52:35 --> Input Class Initialized
INFO - 2016-06-23 03:52:35 --> Language Class Initialized
INFO - 2016-06-23 03:52:35 --> Loader Class Initialized
INFO - 2016-06-23 03:52:35 --> Helper loaded: form_helper
INFO - 2016-06-23 03:52:35 --> Database Driver Class Initialized
INFO - 2016-06-23 03:52:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:52:35 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:52:35 --> Email Class Initialized
INFO - 2016-06-23 03:52:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:52:35 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:52:35 --> Helper loaded: language_helper
INFO - 2016-06-23 03:52:35 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:52:35 --> Model Class Initialized
INFO - 2016-06-23 03:52:35 --> Helper loaded: date_helper
INFO - 2016-06-23 03:52:35 --> Controller Class Initialized
INFO - 2016-06-23 03:52:35 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:52:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:52:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:52:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:52:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:52:35 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 06:52:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 06:52:35 --> Form Validation Class Initialized
INFO - 2016-06-23 06:52:35 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 06:52:35 --> File loaded: /home/diabet/public_html/application/views/auth/create_user.php
INFO - 2016-06-23 06:52:35 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 06:52:35 --> Final output sent to browser
DEBUG - 2016-06-23 06:52:35 --> Total execution time: 0.1574
INFO - 2016-06-23 03:52:53 --> Config Class Initialized
INFO - 2016-06-23 03:52:53 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:52:53 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:52:53 --> Utf8 Class Initialized
INFO - 2016-06-23 03:52:53 --> URI Class Initialized
DEBUG - 2016-06-23 03:52:53 --> No URI present. Default controller set.
INFO - 2016-06-23 03:52:53 --> Router Class Initialized
INFO - 2016-06-23 03:52:53 --> Output Class Initialized
INFO - 2016-06-23 03:52:53 --> Security Class Initialized
DEBUG - 2016-06-23 03:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:52:53 --> Input Class Initialized
INFO - 2016-06-23 03:52:53 --> Language Class Initialized
INFO - 2016-06-23 03:52:53 --> Loader Class Initialized
INFO - 2016-06-23 03:52:53 --> Helper loaded: form_helper
INFO - 2016-06-23 03:52:53 --> Database Driver Class Initialized
INFO - 2016-06-23 03:52:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:52:53 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:52:53 --> Email Class Initialized
INFO - 2016-06-23 03:52:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:52:53 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:52:53 --> Helper loaded: language_helper
INFO - 2016-06-23 03:52:53 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:52:53 --> Model Class Initialized
INFO - 2016-06-23 03:52:53 --> Helper loaded: date_helper
INFO - 2016-06-23 03:52:53 --> Controller Class Initialized
INFO - 2016-06-23 03:52:53 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:52:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:52:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:52:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:52:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:52:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:52:53 --> Model Class Initialized
INFO - 2016-06-23 06:52:53 --> Form Validation Class Initialized
INFO - 2016-06-23 06:52:53 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 06:52:53 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 06:52:53 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 06:52:53 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 06:52:53 --> Final output sent to browser
DEBUG - 2016-06-23 06:52:53 --> Total execution time: 0.0984
INFO - 2016-06-23 03:52:54 --> Config Class Initialized
INFO - 2016-06-23 03:52:54 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:52:54 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:52:54 --> Utf8 Class Initialized
INFO - 2016-06-23 03:52:54 --> URI Class Initialized
INFO - 2016-06-23 03:52:54 --> Router Class Initialized
INFO - 2016-06-23 03:52:54 --> Output Class Initialized
INFO - 2016-06-23 03:52:54 --> Security Class Initialized
DEBUG - 2016-06-23 03:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:52:54 --> Input Class Initialized
INFO - 2016-06-23 03:52:54 --> Language Class Initialized
INFO - 2016-06-23 03:52:54 --> Loader Class Initialized
INFO - 2016-06-23 03:52:54 --> Helper loaded: form_helper
INFO - 2016-06-23 03:52:54 --> Database Driver Class Initialized
INFO - 2016-06-23 03:52:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:52:54 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:52:54 --> Email Class Initialized
INFO - 2016-06-23 03:52:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:52:54 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:52:54 --> Helper loaded: language_helper
INFO - 2016-06-23 03:52:54 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:52:54 --> Model Class Initialized
INFO - 2016-06-23 03:52:54 --> Helper loaded: date_helper
INFO - 2016-06-23 03:52:54 --> Controller Class Initialized
INFO - 2016-06-23 03:52:54 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:52:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:52:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:52:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:52:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:52:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:52:54 --> Model Class Initialized
INFO - 2016-06-23 06:52:54 --> Final output sent to browser
DEBUG - 2016-06-23 06:52:54 --> Total execution time: 0.0820
INFO - 2016-06-23 03:53:18 --> Config Class Initialized
INFO - 2016-06-23 03:53:18 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:18 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:18 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:18 --> URI Class Initialized
INFO - 2016-06-23 03:53:18 --> Router Class Initialized
INFO - 2016-06-23 03:53:18 --> Output Class Initialized
INFO - 2016-06-23 03:53:18 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:18 --> Input Class Initialized
INFO - 2016-06-23 03:53:18 --> Language Class Initialized
INFO - 2016-06-23 03:53:18 --> Loader Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:18 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:18 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:18 --> Email Class Initialized
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:18 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:18 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:18 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:18 --> Model Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:18 --> Controller Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 06:53:18 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 06:53:18 --> Form Validation Class Initialized
DEBUG - 2016-06-23 06:53:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:18 --> Config Class Initialized
INFO - 2016-06-23 03:53:18 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:18 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:18 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:18 --> URI Class Initialized
DEBUG - 2016-06-23 03:53:18 --> No URI present. Default controller set.
INFO - 2016-06-23 03:53:18 --> Router Class Initialized
INFO - 2016-06-23 03:53:18 --> Output Class Initialized
INFO - 2016-06-23 03:53:18 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:18 --> Input Class Initialized
INFO - 2016-06-23 03:53:18 --> Language Class Initialized
INFO - 2016-06-23 03:53:18 --> Loader Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:18 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:18 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:18 --> Email Class Initialized
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:18 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:18 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:18 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:18 --> Model Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:18 --> Controller Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 03:53:18 --> Config Class Initialized
INFO - 2016-06-23 03:53:18 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:18 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:18 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:18 --> URI Class Initialized
INFO - 2016-06-23 03:53:18 --> Router Class Initialized
INFO - 2016-06-23 03:53:18 --> Output Class Initialized
INFO - 2016-06-23 03:53:18 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:18 --> Input Class Initialized
INFO - 2016-06-23 03:53:18 --> Language Class Initialized
INFO - 2016-06-23 03:53:18 --> Loader Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:18 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:18 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:18 --> Email Class Initialized
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:18 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:18 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:18 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:18 --> Model Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:18 --> Controller Class Initialized
INFO - 2016-06-23 03:53:18 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:53:18 --> Model Class Initialized
INFO - 2016-06-23 06:53:18 --> Form Validation Class Initialized
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 06:53:18 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 06:53:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 06:53:19 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 06:53:19 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 06:53:19 --> Final output sent to browser
DEBUG - 2016-06-23 06:53:19 --> Total execution time: 0.2187
INFO - 2016-06-23 03:53:20 --> Config Class Initialized
INFO - 2016-06-23 03:53:20 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:20 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:20 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:20 --> URI Class Initialized
INFO - 2016-06-23 03:53:20 --> Router Class Initialized
INFO - 2016-06-23 03:53:20 --> Output Class Initialized
INFO - 2016-06-23 03:53:20 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:20 --> Input Class Initialized
INFO - 2016-06-23 03:53:20 --> Language Class Initialized
INFO - 2016-06-23 03:53:20 --> Loader Class Initialized
INFO - 2016-06-23 03:53:20 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:20 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:20 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:20 --> Email Class Initialized
INFO - 2016-06-23 03:53:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:20 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:20 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:20 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:20 --> Model Class Initialized
INFO - 2016-06-23 03:53:20 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:20 --> Controller Class Initialized
INFO - 2016-06-23 03:53:20 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:53:20 --> Model Class Initialized
INFO - 2016-06-23 06:53:20 --> Form Validation Class Initialized
INFO - 2016-06-23 06:53:20 --> Final output sent to browser
DEBUG - 2016-06-23 06:53:20 --> Total execution time: 0.1023
INFO - 2016-06-23 03:53:35 --> Config Class Initialized
INFO - 2016-06-23 03:53:35 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:35 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:35 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:35 --> URI Class Initialized
INFO - 2016-06-23 03:53:35 --> Router Class Initialized
INFO - 2016-06-23 03:53:35 --> Output Class Initialized
INFO - 2016-06-23 03:53:35 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:36 --> Input Class Initialized
INFO - 2016-06-23 03:53:36 --> Language Class Initialized
INFO - 2016-06-23 03:53:36 --> Loader Class Initialized
INFO - 2016-06-23 03:53:36 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:36 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:36 --> Email Class Initialized
INFO - 2016-06-23 03:53:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:36 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:36 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:36 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:36 --> Model Class Initialized
INFO - 2016-06-23 03:53:36 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:36 --> Controller Class Initialized
INFO - 2016-06-23 03:53:36 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:53:36 --> Model Class Initialized
INFO - 2016-06-23 06:53:36 --> Form Validation Class Initialized
INFO - 2016-06-23 06:53:36 --> Helper loaded: sort_array_helper
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-23 06:53:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 06:53:36 --> Final output sent to browser
DEBUG - 2016-06-23 06:53:36 --> Total execution time: 0.3111
INFO - 2016-06-23 03:53:43 --> Config Class Initialized
INFO - 2016-06-23 03:53:43 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:43 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:43 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:43 --> URI Class Initialized
INFO - 2016-06-23 03:53:43 --> Router Class Initialized
INFO - 2016-06-23 03:53:43 --> Output Class Initialized
INFO - 2016-06-23 03:53:43 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:43 --> Input Class Initialized
INFO - 2016-06-23 03:53:43 --> Language Class Initialized
INFO - 2016-06-23 03:53:43 --> Loader Class Initialized
INFO - 2016-06-23 03:53:43 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:43 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:43 --> Email Class Initialized
INFO - 2016-06-23 03:53:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:43 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:43 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:43 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:43 --> Model Class Initialized
INFO - 2016-06-23 03:53:43 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:43 --> Controller Class Initialized
INFO - 2016-06-23 03:53:43 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:53:43 --> Model Class Initialized
INFO - 2016-06-23 06:53:43 --> Form Validation Class Initialized
DEBUG - 2016-06-23 06:53:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:44 --> Config Class Initialized
INFO - 2016-06-23 03:53:44 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:44 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:44 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:44 --> URI Class Initialized
INFO - 2016-06-23 03:53:44 --> Router Class Initialized
INFO - 2016-06-23 03:53:44 --> Output Class Initialized
INFO - 2016-06-23 03:53:44 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:44 --> Input Class Initialized
INFO - 2016-06-23 03:53:44 --> Language Class Initialized
INFO - 2016-06-23 03:53:44 --> Loader Class Initialized
INFO - 2016-06-23 03:53:44 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:44 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:44 --> Email Class Initialized
INFO - 2016-06-23 03:53:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:44 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:44 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:44 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:44 --> Model Class Initialized
INFO - 2016-06-23 03:53:44 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:44 --> Controller Class Initialized
INFO - 2016-06-23 03:53:44 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:53:44 --> Model Class Initialized
INFO - 2016-06-23 06:53:44 --> Form Validation Class Initialized
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 06:53:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 06:53:44 --> Final output sent to browser
DEBUG - 2016-06-23 06:53:44 --> Total execution time: 0.1068
INFO - 2016-06-23 03:53:45 --> Config Class Initialized
INFO - 2016-06-23 03:53:45 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:53:45 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:53:45 --> Utf8 Class Initialized
INFO - 2016-06-23 03:53:45 --> URI Class Initialized
INFO - 2016-06-23 03:53:45 --> Router Class Initialized
INFO - 2016-06-23 03:53:45 --> Output Class Initialized
INFO - 2016-06-23 03:53:45 --> Security Class Initialized
DEBUG - 2016-06-23 03:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:53:45 --> Input Class Initialized
INFO - 2016-06-23 03:53:45 --> Language Class Initialized
INFO - 2016-06-23 03:53:45 --> Loader Class Initialized
INFO - 2016-06-23 03:53:45 --> Helper loaded: form_helper
INFO - 2016-06-23 03:53:45 --> Database Driver Class Initialized
INFO - 2016-06-23 03:53:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:53:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:53:45 --> Email Class Initialized
INFO - 2016-06-23 03:53:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:53:45 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:53:45 --> Helper loaded: language_helper
INFO - 2016-06-23 03:53:45 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:53:45 --> Model Class Initialized
INFO - 2016-06-23 03:53:45 --> Helper loaded: date_helper
INFO - 2016-06-23 03:53:45 --> Controller Class Initialized
INFO - 2016-06-23 03:53:45 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:53:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:53:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:53:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:53:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:53:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:53:45 --> Model Class Initialized
INFO - 2016-06-23 06:53:45 --> Form Validation Class Initialized
INFO - 2016-06-23 06:53:45 --> Final output sent to browser
DEBUG - 2016-06-23 06:53:45 --> Total execution time: 0.1035
INFO - 2016-06-23 03:54:07 --> Config Class Initialized
INFO - 2016-06-23 03:54:07 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:54:07 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:54:07 --> Utf8 Class Initialized
INFO - 2016-06-23 03:54:07 --> URI Class Initialized
INFO - 2016-06-23 03:54:07 --> Router Class Initialized
INFO - 2016-06-23 03:54:07 --> Output Class Initialized
INFO - 2016-06-23 03:54:07 --> Security Class Initialized
DEBUG - 2016-06-23 03:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:54:07 --> Input Class Initialized
INFO - 2016-06-23 03:54:07 --> Language Class Initialized
INFO - 2016-06-23 03:54:07 --> Loader Class Initialized
INFO - 2016-06-23 03:54:07 --> Helper loaded: form_helper
INFO - 2016-06-23 03:54:07 --> Database Driver Class Initialized
INFO - 2016-06-23 03:54:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:54:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:54:07 --> Email Class Initialized
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:54:07 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:54:07 --> Helper loaded: language_helper
INFO - 2016-06-23 03:54:07 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:54:07 --> Model Class Initialized
INFO - 2016-06-23 03:54:07 --> Helper loaded: date_helper
INFO - 2016-06-23 03:54:07 --> Controller Class Initialized
INFO - 2016-06-23 03:54:07 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 06:54:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 06:54:07 --> Form Validation Class Initialized
INFO - 2016-06-23 03:54:07 --> Config Class Initialized
INFO - 2016-06-23 03:54:07 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:54:07 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:54:07 --> Utf8 Class Initialized
INFO - 2016-06-23 03:54:07 --> URI Class Initialized
DEBUG - 2016-06-23 03:54:07 --> No URI present. Default controller set.
INFO - 2016-06-23 03:54:07 --> Router Class Initialized
INFO - 2016-06-23 03:54:07 --> Output Class Initialized
INFO - 2016-06-23 03:54:07 --> Security Class Initialized
DEBUG - 2016-06-23 03:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:54:07 --> Input Class Initialized
INFO - 2016-06-23 03:54:07 --> Language Class Initialized
INFO - 2016-06-23 03:54:07 --> Loader Class Initialized
INFO - 2016-06-23 03:54:07 --> Helper loaded: form_helper
INFO - 2016-06-23 03:54:07 --> Database Driver Class Initialized
INFO - 2016-06-23 03:54:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:54:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:54:07 --> Email Class Initialized
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:54:07 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:54:07 --> Helper loaded: language_helper
INFO - 2016-06-23 03:54:07 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:54:07 --> Model Class Initialized
INFO - 2016-06-23 03:54:07 --> Helper loaded: date_helper
INFO - 2016-06-23 03:54:07 --> Controller Class Initialized
INFO - 2016-06-23 03:54:07 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:54:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:54:07 --> Model Class Initialized
INFO - 2016-06-23 06:54:07 --> Form Validation Class Initialized
INFO - 2016-06-23 06:54:07 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 06:54:07 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 06:54:07 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 06:54:07 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 06:54:07 --> Final output sent to browser
DEBUG - 2016-06-23 06:54:07 --> Total execution time: 0.0829
INFO - 2016-06-23 03:54:08 --> Config Class Initialized
INFO - 2016-06-23 03:54:08 --> Hooks Class Initialized
DEBUG - 2016-06-23 03:54:08 --> UTF-8 Support Enabled
INFO - 2016-06-23 03:54:08 --> Utf8 Class Initialized
INFO - 2016-06-23 03:54:08 --> URI Class Initialized
INFO - 2016-06-23 03:54:08 --> Router Class Initialized
INFO - 2016-06-23 03:54:08 --> Output Class Initialized
INFO - 2016-06-23 03:54:08 --> Security Class Initialized
DEBUG - 2016-06-23 03:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 03:54:08 --> Input Class Initialized
INFO - 2016-06-23 03:54:08 --> Language Class Initialized
INFO - 2016-06-23 03:54:08 --> Loader Class Initialized
INFO - 2016-06-23 03:54:08 --> Helper loaded: form_helper
INFO - 2016-06-23 03:54:08 --> Database Driver Class Initialized
INFO - 2016-06-23 03:54:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 03:54:08 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 03:54:08 --> Email Class Initialized
INFO - 2016-06-23 03:54:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 03:54:08 --> Helper loaded: cookie_helper
INFO - 2016-06-23 03:54:08 --> Helper loaded: language_helper
INFO - 2016-06-23 03:54:08 --> Helper loaded: url_helper
DEBUG - 2016-06-23 03:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 03:54:08 --> Model Class Initialized
INFO - 2016-06-23 03:54:08 --> Helper loaded: date_helper
INFO - 2016-06-23 03:54:08 --> Controller Class Initialized
INFO - 2016-06-23 03:54:08 --> Helper loaded: languages_helper
INFO - 2016-06-23 03:54:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 03:54:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 03:54:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 03:54:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 03:54:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 06:54:08 --> Model Class Initialized
INFO - 2016-06-23 06:54:08 --> Final output sent to browser
DEBUG - 2016-06-23 06:54:08 --> Total execution time: 0.0785
INFO - 2016-06-23 10:00:29 --> Config Class Initialized
INFO - 2016-06-23 10:00:29 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:00:29 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:00:29 --> Utf8 Class Initialized
INFO - 2016-06-23 10:00:29 --> URI Class Initialized
DEBUG - 2016-06-23 10:00:29 --> No URI present. Default controller set.
INFO - 2016-06-23 10:00:29 --> Router Class Initialized
INFO - 2016-06-23 10:00:29 --> Output Class Initialized
INFO - 2016-06-23 10:00:29 --> Security Class Initialized
DEBUG - 2016-06-23 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:00:29 --> Input Class Initialized
INFO - 2016-06-23 10:00:29 --> Language Class Initialized
INFO - 2016-06-23 10:00:29 --> Loader Class Initialized
INFO - 2016-06-23 10:00:29 --> Helper loaded: form_helper
INFO - 2016-06-23 10:00:29 --> Database Driver Class Initialized
INFO - 2016-06-23 10:00:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:00:29 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:00:29 --> Email Class Initialized
INFO - 2016-06-23 10:00:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:00:29 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:00:29 --> Helper loaded: language_helper
INFO - 2016-06-23 10:00:29 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:00:29 --> Model Class Initialized
INFO - 2016-06-23 10:00:29 --> Helper loaded: date_helper
INFO - 2016-06-23 10:00:29 --> Controller Class Initialized
INFO - 2016-06-23 10:00:29 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:00:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:00:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:00:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:00:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:00:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:00:29 --> Model Class Initialized
INFO - 2016-06-23 13:00:29 --> Form Validation Class Initialized
INFO - 2016-06-23 13:00:29 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 13:00:29 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 13:00:29 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 13:00:29 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 13:00:29 --> Final output sent to browser
DEBUG - 2016-06-23 13:00:29 --> Total execution time: 0.0786
INFO - 2016-06-23 10:00:31 --> Config Class Initialized
INFO - 2016-06-23 10:00:31 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:00:31 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:00:31 --> Utf8 Class Initialized
INFO - 2016-06-23 10:00:31 --> URI Class Initialized
INFO - 2016-06-23 10:00:31 --> Router Class Initialized
INFO - 2016-06-23 10:00:31 --> Output Class Initialized
INFO - 2016-06-23 10:00:31 --> Security Class Initialized
DEBUG - 2016-06-23 10:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:00:31 --> Input Class Initialized
INFO - 2016-06-23 10:00:31 --> Language Class Initialized
INFO - 2016-06-23 10:00:31 --> Loader Class Initialized
INFO - 2016-06-23 10:00:31 --> Helper loaded: form_helper
INFO - 2016-06-23 10:00:31 --> Database Driver Class Initialized
INFO - 2016-06-23 10:00:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:00:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:00:31 --> Email Class Initialized
INFO - 2016-06-23 10:00:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:00:31 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:00:31 --> Helper loaded: language_helper
INFO - 2016-06-23 10:00:31 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:00:31 --> Model Class Initialized
INFO - 2016-06-23 10:00:31 --> Helper loaded: date_helper
INFO - 2016-06-23 10:00:31 --> Controller Class Initialized
INFO - 2016-06-23 10:00:31 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:00:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:00:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:00:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:00:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:00:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:00:31 --> Model Class Initialized
INFO - 2016-06-23 13:00:31 --> Final output sent to browser
DEBUG - 2016-06-23 13:00:31 --> Total execution time: 0.0809
INFO - 2016-06-23 10:00:31 --> Config Class Initialized
INFO - 2016-06-23 10:00:31 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:00:31 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:00:31 --> Utf8 Class Initialized
INFO - 2016-06-23 10:00:31 --> URI Class Initialized
INFO - 2016-06-23 10:00:31 --> Router Class Initialized
INFO - 2016-06-23 10:00:31 --> Output Class Initialized
INFO - 2016-06-23 10:00:31 --> Security Class Initialized
DEBUG - 2016-06-23 10:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:00:31 --> Input Class Initialized
INFO - 2016-06-23 10:00:31 --> Language Class Initialized
ERROR - 2016-06-23 10:00:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-23 10:23:42 --> Config Class Initialized
INFO - 2016-06-23 10:23:42 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:23:42 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:23:42 --> Utf8 Class Initialized
INFO - 2016-06-23 10:23:42 --> URI Class Initialized
DEBUG - 2016-06-23 10:23:42 --> No URI present. Default controller set.
INFO - 2016-06-23 10:23:42 --> Router Class Initialized
INFO - 2016-06-23 10:23:42 --> Output Class Initialized
INFO - 2016-06-23 10:23:42 --> Security Class Initialized
DEBUG - 2016-06-23 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:23:42 --> Input Class Initialized
INFO - 2016-06-23 10:23:42 --> Language Class Initialized
INFO - 2016-06-23 10:23:42 --> Loader Class Initialized
INFO - 2016-06-23 10:23:42 --> Helper loaded: form_helper
INFO - 2016-06-23 10:23:42 --> Database Driver Class Initialized
INFO - 2016-06-23 10:23:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:23:42 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:23:42 --> Email Class Initialized
INFO - 2016-06-23 10:23:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:23:42 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:23:42 --> Helper loaded: language_helper
INFO - 2016-06-23 10:23:42 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:23:42 --> Model Class Initialized
INFO - 2016-06-23 10:23:42 --> Helper loaded: date_helper
INFO - 2016-06-23 10:23:42 --> Controller Class Initialized
INFO - 2016-06-23 10:23:42 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:23:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:23:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:23:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:23:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:23:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:23:42 --> Model Class Initialized
INFO - 2016-06-23 13:23:42 --> Form Validation Class Initialized
INFO - 2016-06-23 13:23:42 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 13:23:42 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 13:23:42 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 13:23:42 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 13:23:42 --> Final output sent to browser
DEBUG - 2016-06-23 13:23:42 --> Total execution time: 0.0932
INFO - 2016-06-23 10:24:06 --> Config Class Initialized
INFO - 2016-06-23 10:24:06 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:24:06 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:24:06 --> Utf8 Class Initialized
INFO - 2016-06-23 10:24:06 --> URI Class Initialized
INFO - 2016-06-23 10:24:07 --> Router Class Initialized
INFO - 2016-06-23 10:24:07 --> Output Class Initialized
INFO - 2016-06-23 10:24:07 --> Security Class Initialized
DEBUG - 2016-06-23 10:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:24:07 --> Input Class Initialized
INFO - 2016-06-23 10:24:07 --> Language Class Initialized
INFO - 2016-06-23 10:24:07 --> Loader Class Initialized
INFO - 2016-06-23 10:24:07 --> Helper loaded: form_helper
INFO - 2016-06-23 10:24:07 --> Database Driver Class Initialized
INFO - 2016-06-23 10:24:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:24:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:24:07 --> Email Class Initialized
INFO - 2016-06-23 10:24:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:24:07 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:24:07 --> Helper loaded: language_helper
INFO - 2016-06-23 10:24:07 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:24:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:24:07 --> Model Class Initialized
INFO - 2016-06-23 10:24:07 --> Helper loaded: date_helper
INFO - 2016-06-23 10:24:07 --> Controller Class Initialized
INFO - 2016-06-23 10:24:07 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:24:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:24:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:24:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:24:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:24:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:24:07 --> Model Class Initialized
INFO - 2016-06-23 13:24:07 --> Final output sent to browser
DEBUG - 2016-06-23 13:24:07 --> Total execution time: 0.0911
INFO - 2016-06-23 10:24:11 --> Config Class Initialized
INFO - 2016-06-23 10:24:11 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:24:11 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:24:11 --> Utf8 Class Initialized
INFO - 2016-06-23 10:24:11 --> URI Class Initialized
INFO - 2016-06-23 10:24:11 --> Router Class Initialized
INFO - 2016-06-23 10:24:11 --> Output Class Initialized
INFO - 2016-06-23 10:24:11 --> Security Class Initialized
DEBUG - 2016-06-23 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:24:11 --> Input Class Initialized
INFO - 2016-06-23 10:24:11 --> Language Class Initialized
ERROR - 2016-06-23 10:24:11 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-23 10:24:11 --> Config Class Initialized
INFO - 2016-06-23 10:24:11 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:24:11 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:24:11 --> Utf8 Class Initialized
INFO - 2016-06-23 10:24:11 --> URI Class Initialized
INFO - 2016-06-23 10:24:11 --> Router Class Initialized
INFO - 2016-06-23 10:24:11 --> Output Class Initialized
INFO - 2016-06-23 10:24:11 --> Security Class Initialized
DEBUG - 2016-06-23 10:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:24:11 --> Input Class Initialized
INFO - 2016-06-23 10:24:11 --> Language Class Initialized
ERROR - 2016-06-23 10:24:11 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-23 10:24:24 --> Config Class Initialized
INFO - 2016-06-23 10:24:24 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:24:24 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:24:24 --> Utf8 Class Initialized
INFO - 2016-06-23 10:24:24 --> URI Class Initialized
INFO - 2016-06-23 10:24:24 --> Router Class Initialized
INFO - 2016-06-23 10:24:24 --> Output Class Initialized
INFO - 2016-06-23 10:24:24 --> Security Class Initialized
DEBUG - 2016-06-23 10:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:24:24 --> Input Class Initialized
INFO - 2016-06-23 10:24:24 --> Language Class Initialized
INFO - 2016-06-23 10:24:24 --> Loader Class Initialized
INFO - 2016-06-23 10:24:24 --> Helper loaded: form_helper
INFO - 2016-06-23 10:24:24 --> Database Driver Class Initialized
INFO - 2016-06-23 10:24:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:24:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:24:24 --> Email Class Initialized
INFO - 2016-06-23 10:24:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:24:24 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:24:24 --> Helper loaded: language_helper
INFO - 2016-06-23 10:24:24 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:24:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:24:24 --> Model Class Initialized
INFO - 2016-06-23 10:24:24 --> Helper loaded: date_helper
INFO - 2016-06-23 10:24:24 --> Controller Class Initialized
INFO - 2016-06-23 10:24:24 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:24:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:24:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:24:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:24:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:24:24 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 13:24:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 13:24:24 --> Form Validation Class Initialized
INFO - 2016-06-23 13:24:24 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 13:24:24 --> File loaded: /home/diabet/public_html/application/views/auth/create_user.php
INFO - 2016-06-23 13:24:24 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 13:24:24 --> Final output sent to browser
DEBUG - 2016-06-23 13:24:24 --> Total execution time: 0.1242
INFO - 2016-06-23 10:25:39 --> Config Class Initialized
INFO - 2016-06-23 10:25:39 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:25:39 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:25:39 --> Utf8 Class Initialized
INFO - 2016-06-23 10:25:39 --> URI Class Initialized
INFO - 2016-06-23 10:25:39 --> Router Class Initialized
INFO - 2016-06-23 10:25:39 --> Output Class Initialized
INFO - 2016-06-23 10:25:39 --> Security Class Initialized
DEBUG - 2016-06-23 10:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:25:39 --> Input Class Initialized
INFO - 2016-06-23 10:25:39 --> Language Class Initialized
INFO - 2016-06-23 10:25:39 --> Loader Class Initialized
INFO - 2016-06-23 10:25:39 --> Helper loaded: form_helper
INFO - 2016-06-23 10:25:39 --> Database Driver Class Initialized
INFO - 2016-06-23 10:25:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:25:39 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:25:40 --> Email Class Initialized
INFO - 2016-06-23 10:25:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:25:40 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:25:40 --> Helper loaded: language_helper
INFO - 2016-06-23 10:25:40 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:25:40 --> Model Class Initialized
INFO - 2016-06-23 10:25:40 --> Helper loaded: date_helper
INFO - 2016-06-23 10:25:40 --> Controller Class Initialized
INFO - 2016-06-23 10:25:40 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:25:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:25:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:25:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:25:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:25:40 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 13:25:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 13:25:40 --> Form Validation Class Initialized
INFO - 2016-06-23 13:25:40 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 13:25:40 --> File loaded: /home/diabet/public_html/application/views/auth/create_user.php
INFO - 2016-06-23 13:25:40 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 13:25:40 --> Final output sent to browser
DEBUG - 2016-06-23 13:25:40 --> Total execution time: 0.1364
INFO - 2016-06-23 10:26:07 --> Config Class Initialized
INFO - 2016-06-23 10:26:07 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:26:07 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:26:07 --> Utf8 Class Initialized
INFO - 2016-06-23 10:26:07 --> URI Class Initialized
INFO - 2016-06-23 10:26:07 --> Router Class Initialized
INFO - 2016-06-23 10:26:07 --> Output Class Initialized
INFO - 2016-06-23 10:26:07 --> Security Class Initialized
DEBUG - 2016-06-23 10:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:26:07 --> Input Class Initialized
INFO - 2016-06-23 10:26:07 --> Language Class Initialized
INFO - 2016-06-23 10:26:07 --> Loader Class Initialized
INFO - 2016-06-23 10:26:07 --> Helper loaded: form_helper
INFO - 2016-06-23 10:26:07 --> Database Driver Class Initialized
INFO - 2016-06-23 10:26:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:26:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:26:07 --> Email Class Initialized
INFO - 2016-06-23 10:26:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:26:07 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:26:07 --> Helper loaded: language_helper
INFO - 2016-06-23 10:26:07 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:26:07 --> Model Class Initialized
INFO - 2016-06-23 10:26:07 --> Helper loaded: date_helper
INFO - 2016-06-23 10:26:07 --> Controller Class Initialized
INFO - 2016-06-23 10:26:07 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:26:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:26:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:26:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:26:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:26:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 13:26:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 13:26:07 --> Form Validation Class Initialized
INFO - 2016-06-23 10:26:08 --> Config Class Initialized
INFO - 2016-06-23 10:26:08 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:26:08 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:26:08 --> Utf8 Class Initialized
INFO - 2016-06-23 10:26:08 --> URI Class Initialized
INFO - 2016-06-23 10:26:08 --> Router Class Initialized
INFO - 2016-06-23 10:26:08 --> Output Class Initialized
INFO - 2016-06-23 10:26:08 --> Security Class Initialized
DEBUG - 2016-06-23 10:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:26:08 --> Input Class Initialized
INFO - 2016-06-23 10:26:08 --> Language Class Initialized
INFO - 2016-06-23 10:26:08 --> Loader Class Initialized
INFO - 2016-06-23 10:26:08 --> Helper loaded: form_helper
INFO - 2016-06-23 10:26:08 --> Database Driver Class Initialized
INFO - 2016-06-23 10:26:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:26:08 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:26:08 --> Email Class Initialized
INFO - 2016-06-23 10:26:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:26:08 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:26:08 --> Helper loaded: language_helper
INFO - 2016-06-23 10:26:08 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:26:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:26:08 --> Model Class Initialized
INFO - 2016-06-23 10:26:08 --> Helper loaded: date_helper
INFO - 2016-06-23 10:26:08 --> Controller Class Initialized
INFO - 2016-06-23 10:26:08 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:26:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:26:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:26:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:26:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:26:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:26:08 --> Model Class Initialized
INFO - 2016-06-23 13:26:08 --> Form Validation Class Initialized
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 13:26:08 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 13:26:08 --> Final output sent to browser
DEBUG - 2016-06-23 13:26:08 --> Total execution time: 0.1010
INFO - 2016-06-23 10:26:30 --> Config Class Initialized
INFO - 2016-06-23 10:26:30 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:26:30 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:26:30 --> Utf8 Class Initialized
INFO - 2016-06-23 10:26:30 --> URI Class Initialized
INFO - 2016-06-23 10:26:30 --> Router Class Initialized
INFO - 2016-06-23 10:26:30 --> Output Class Initialized
INFO - 2016-06-23 10:26:30 --> Security Class Initialized
DEBUG - 2016-06-23 10:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:26:30 --> Input Class Initialized
INFO - 2016-06-23 10:26:30 --> Language Class Initialized
INFO - 2016-06-23 10:26:31 --> Loader Class Initialized
INFO - 2016-06-23 10:26:31 --> Helper loaded: form_helper
INFO - 2016-06-23 10:26:31 --> Database Driver Class Initialized
INFO - 2016-06-23 10:26:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:26:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:26:31 --> Email Class Initialized
INFO - 2016-06-23 10:26:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:26:31 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:26:31 --> Helper loaded: language_helper
INFO - 2016-06-23 10:26:31 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:26:31 --> Model Class Initialized
INFO - 2016-06-23 10:26:31 --> Helper loaded: date_helper
INFO - 2016-06-23 10:26:31 --> Controller Class Initialized
INFO - 2016-06-23 10:26:31 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:26:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:26:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:26:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:26:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:26:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:26:31 --> Model Class Initialized
INFO - 2016-06-23 13:26:31 --> Form Validation Class Initialized
INFO - 2016-06-23 13:26:31 --> Final output sent to browser
DEBUG - 2016-06-23 13:26:31 --> Total execution time: 0.0929
INFO - 2016-06-23 10:26:38 --> Config Class Initialized
INFO - 2016-06-23 10:26:38 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:26:38 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:26:38 --> Utf8 Class Initialized
INFO - 2016-06-23 10:26:38 --> URI Class Initialized
INFO - 2016-06-23 10:26:38 --> Router Class Initialized
INFO - 2016-06-23 10:26:38 --> Output Class Initialized
INFO - 2016-06-23 10:26:38 --> Security Class Initialized
DEBUG - 2016-06-23 10:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:26:38 --> Input Class Initialized
INFO - 2016-06-23 10:26:38 --> Language Class Initialized
INFO - 2016-06-23 10:26:38 --> Loader Class Initialized
INFO - 2016-06-23 10:26:38 --> Helper loaded: form_helper
INFO - 2016-06-23 10:26:38 --> Database Driver Class Initialized
INFO - 2016-06-23 10:26:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:26:38 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:26:38 --> Email Class Initialized
INFO - 2016-06-23 10:26:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:26:38 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:26:38 --> Helper loaded: language_helper
INFO - 2016-06-23 10:26:38 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:26:38 --> Model Class Initialized
INFO - 2016-06-23 10:26:38 --> Helper loaded: date_helper
INFO - 2016-06-23 10:26:38 --> Controller Class Initialized
INFO - 2016-06-23 10:26:38 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:26:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:26:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:26:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:26:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:26:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:26:38 --> Model Class Initialized
INFO - 2016-06-23 13:26:38 --> Form Validation Class Initialized
INFO - 2016-06-23 13:26:38 --> Helper loaded: sort_array_helper
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-23 13:26:38 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 13:26:38 --> Final output sent to browser
DEBUG - 2016-06-23 13:26:38 --> Total execution time: 0.0940
INFO - 2016-06-23 10:27:42 --> Config Class Initialized
INFO - 2016-06-23 10:27:42 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:27:42 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:27:42 --> Utf8 Class Initialized
INFO - 2016-06-23 10:27:42 --> URI Class Initialized
INFO - 2016-06-23 10:27:42 --> Router Class Initialized
INFO - 2016-06-23 10:27:42 --> Output Class Initialized
INFO - 2016-06-23 10:27:42 --> Security Class Initialized
DEBUG - 2016-06-23 10:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:27:43 --> Input Class Initialized
INFO - 2016-06-23 10:27:43 --> Language Class Initialized
INFO - 2016-06-23 10:27:43 --> Loader Class Initialized
INFO - 2016-06-23 10:27:43 --> Helper loaded: form_helper
INFO - 2016-06-23 10:27:43 --> Database Driver Class Initialized
INFO - 2016-06-23 10:27:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:27:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:27:43 --> Email Class Initialized
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:27:43 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:27:43 --> Helper loaded: language_helper
INFO - 2016-06-23 10:27:43 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:27:43 --> Model Class Initialized
INFO - 2016-06-23 10:27:43 --> Helper loaded: date_helper
INFO - 2016-06-23 10:27:43 --> Controller Class Initialized
INFO - 2016-06-23 10:27:43 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:27:43 --> Model Class Initialized
INFO - 2016-06-23 13:27:43 --> Form Validation Class Initialized
DEBUG - 2016-06-23 13:27:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:27:43 --> Config Class Initialized
INFO - 2016-06-23 10:27:43 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:27:43 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:27:43 --> Utf8 Class Initialized
INFO - 2016-06-23 10:27:43 --> URI Class Initialized
INFO - 2016-06-23 10:27:43 --> Router Class Initialized
INFO - 2016-06-23 10:27:43 --> Output Class Initialized
INFO - 2016-06-23 10:27:43 --> Security Class Initialized
DEBUG - 2016-06-23 10:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:27:43 --> Input Class Initialized
INFO - 2016-06-23 10:27:43 --> Language Class Initialized
INFO - 2016-06-23 10:27:43 --> Loader Class Initialized
INFO - 2016-06-23 10:27:43 --> Helper loaded: form_helper
INFO - 2016-06-23 10:27:43 --> Database Driver Class Initialized
INFO - 2016-06-23 10:27:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:27:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:27:43 --> Email Class Initialized
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:27:43 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:27:43 --> Helper loaded: language_helper
INFO - 2016-06-23 10:27:43 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:27:43 --> Model Class Initialized
INFO - 2016-06-23 10:27:43 --> Helper loaded: date_helper
INFO - 2016-06-23 10:27:43 --> Controller Class Initialized
INFO - 2016-06-23 10:27:43 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:27:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:27:43 --> Model Class Initialized
INFO - 2016-06-23 13:27:43 --> Form Validation Class Initialized
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 13:27:43 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 13:27:43 --> Final output sent to browser
DEBUG - 2016-06-23 13:27:43 --> Total execution time: 0.1033
INFO - 2016-06-23 10:28:19 --> Config Class Initialized
INFO - 2016-06-23 10:28:19 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:28:19 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:28:19 --> Utf8 Class Initialized
INFO - 2016-06-23 10:28:19 --> URI Class Initialized
INFO - 2016-06-23 10:28:19 --> Router Class Initialized
INFO - 2016-06-23 10:28:19 --> Output Class Initialized
INFO - 2016-06-23 10:28:19 --> Security Class Initialized
DEBUG - 2016-06-23 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:28:19 --> Input Class Initialized
INFO - 2016-06-23 10:28:19 --> Language Class Initialized
INFO - 2016-06-23 10:28:19 --> Loader Class Initialized
INFO - 2016-06-23 10:28:19 --> Helper loaded: form_helper
INFO - 2016-06-23 10:28:19 --> Database Driver Class Initialized
INFO - 2016-06-23 10:28:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:28:19 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:28:19 --> Email Class Initialized
INFO - 2016-06-23 10:28:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:28:19 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:28:19 --> Helper loaded: language_helper
INFO - 2016-06-23 10:28:19 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:28:19 --> Model Class Initialized
INFO - 2016-06-23 10:28:19 --> Helper loaded: date_helper
INFO - 2016-06-23 10:28:19 --> Controller Class Initialized
INFO - 2016-06-23 10:28:19 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:28:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:28:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:28:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:28:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:28:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:28:19 --> Model Class Initialized
INFO - 2016-06-23 13:28:19 --> Form Validation Class Initialized
INFO - 2016-06-23 13:28:19 --> Final output sent to browser
DEBUG - 2016-06-23 13:28:19 --> Total execution time: 0.1052
INFO - 2016-06-23 10:28:41 --> Config Class Initialized
INFO - 2016-06-23 10:28:41 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:28:41 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:28:41 --> Utf8 Class Initialized
INFO - 2016-06-23 10:28:41 --> URI Class Initialized
INFO - 2016-06-23 10:28:41 --> Router Class Initialized
INFO - 2016-06-23 10:28:41 --> Output Class Initialized
INFO - 2016-06-23 10:28:41 --> Security Class Initialized
DEBUG - 2016-06-23 10:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:28:41 --> Input Class Initialized
INFO - 2016-06-23 10:28:41 --> Language Class Initialized
INFO - 2016-06-23 10:28:41 --> Loader Class Initialized
INFO - 2016-06-23 10:28:41 --> Helper loaded: form_helper
INFO - 2016-06-23 10:28:41 --> Database Driver Class Initialized
INFO - 2016-06-23 10:28:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:28:41 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:28:41 --> Email Class Initialized
INFO - 2016-06-23 10:28:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:28:41 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:28:41 --> Helper loaded: language_helper
INFO - 2016-06-23 10:28:41 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:28:41 --> Model Class Initialized
INFO - 2016-06-23 10:28:41 --> Helper loaded: date_helper
INFO - 2016-06-23 10:28:41 --> Controller Class Initialized
INFO - 2016-06-23 10:28:41 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:28:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:28:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:28:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:28:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:28:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:28:41 --> Model Class Initialized
INFO - 2016-06-23 13:28:41 --> Form Validation Class Initialized
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 13:28:42 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 13:28:42 --> Final output sent to browser
DEBUG - 2016-06-23 13:28:42 --> Total execution time: 0.1024
INFO - 2016-06-23 10:29:01 --> Config Class Initialized
INFO - 2016-06-23 10:29:01 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:29:01 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:29:01 --> Utf8 Class Initialized
INFO - 2016-06-23 10:29:01 --> URI Class Initialized
INFO - 2016-06-23 10:29:01 --> Router Class Initialized
INFO - 2016-06-23 10:29:01 --> Output Class Initialized
INFO - 2016-06-23 10:29:01 --> Security Class Initialized
DEBUG - 2016-06-23 10:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:29:01 --> Input Class Initialized
INFO - 2016-06-23 10:29:01 --> Language Class Initialized
INFO - 2016-06-23 10:29:01 --> Loader Class Initialized
INFO - 2016-06-23 10:29:01 --> Helper loaded: form_helper
INFO - 2016-06-23 10:29:01 --> Database Driver Class Initialized
INFO - 2016-06-23 10:29:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:29:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:29:01 --> Email Class Initialized
INFO - 2016-06-23 10:29:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:29:01 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:29:01 --> Helper loaded: language_helper
INFO - 2016-06-23 10:29:01 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:29:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:29:01 --> Model Class Initialized
INFO - 2016-06-23 10:29:01 --> Helper loaded: date_helper
INFO - 2016-06-23 10:29:01 --> Controller Class Initialized
INFO - 2016-06-23 10:29:01 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:29:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:29:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:29:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:29:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:29:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:29:01 --> Model Class Initialized
INFO - 2016-06-23 13:29:01 --> Form Validation Class Initialized
INFO - 2016-06-23 13:29:01 --> Final output sent to browser
DEBUG - 2016-06-23 13:29:01 --> Total execution time: 0.1017
INFO - 2016-06-23 10:33:05 --> Config Class Initialized
INFO - 2016-06-23 10:33:05 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:33:05 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:33:05 --> Utf8 Class Initialized
INFO - 2016-06-23 10:33:05 --> URI Class Initialized
INFO - 2016-06-23 10:33:05 --> Router Class Initialized
INFO - 2016-06-23 10:33:05 --> Output Class Initialized
INFO - 2016-06-23 10:33:05 --> Security Class Initialized
DEBUG - 2016-06-23 10:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:33:05 --> Input Class Initialized
INFO - 2016-06-23 10:33:05 --> Language Class Initialized
INFO - 2016-06-23 10:33:05 --> Loader Class Initialized
INFO - 2016-06-23 10:33:05 --> Helper loaded: form_helper
INFO - 2016-06-23 10:33:05 --> Database Driver Class Initialized
INFO - 2016-06-23 10:33:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:33:05 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:33:05 --> Email Class Initialized
INFO - 2016-06-23 10:33:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:33:05 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:33:05 --> Helper loaded: language_helper
INFO - 2016-06-23 10:33:05 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:33:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:33:05 --> Model Class Initialized
INFO - 2016-06-23 10:33:05 --> Helper loaded: date_helper
INFO - 2016-06-23 10:33:05 --> Controller Class Initialized
INFO - 2016-06-23 10:33:05 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:33:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:33:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:33:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:33:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:33:05 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 13:33:05 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 13:33:05 --> Form Validation Class Initialized
INFO - 2016-06-23 10:33:06 --> Config Class Initialized
INFO - 2016-06-23 10:33:06 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:33:06 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:33:06 --> Utf8 Class Initialized
INFO - 2016-06-23 10:33:06 --> URI Class Initialized
DEBUG - 2016-06-23 10:33:06 --> No URI present. Default controller set.
INFO - 2016-06-23 10:33:06 --> Router Class Initialized
INFO - 2016-06-23 10:33:06 --> Output Class Initialized
INFO - 2016-06-23 10:33:06 --> Security Class Initialized
DEBUG - 2016-06-23 10:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:33:06 --> Input Class Initialized
INFO - 2016-06-23 10:33:06 --> Language Class Initialized
INFO - 2016-06-23 10:33:06 --> Loader Class Initialized
INFO - 2016-06-23 10:33:06 --> Helper loaded: form_helper
INFO - 2016-06-23 10:33:06 --> Database Driver Class Initialized
INFO - 2016-06-23 10:33:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:33:06 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:33:06 --> Email Class Initialized
INFO - 2016-06-23 10:33:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:33:06 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:33:06 --> Helper loaded: language_helper
INFO - 2016-06-23 10:33:06 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:33:06 --> Model Class Initialized
INFO - 2016-06-23 10:33:06 --> Helper loaded: date_helper
INFO - 2016-06-23 10:33:06 --> Controller Class Initialized
INFO - 2016-06-23 10:33:06 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:33:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:33:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:33:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:33:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:33:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:33:06 --> Model Class Initialized
INFO - 2016-06-23 13:33:06 --> Form Validation Class Initialized
INFO - 2016-06-23 13:33:06 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 13:33:06 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 13:33:06 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 13:33:06 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 13:33:06 --> Final output sent to browser
DEBUG - 2016-06-23 13:33:06 --> Total execution time: 0.0806
INFO - 2016-06-23 10:33:08 --> Config Class Initialized
INFO - 2016-06-23 10:33:08 --> Hooks Class Initialized
DEBUG - 2016-06-23 10:33:08 --> UTF-8 Support Enabled
INFO - 2016-06-23 10:33:08 --> Utf8 Class Initialized
INFO - 2016-06-23 10:33:08 --> URI Class Initialized
INFO - 2016-06-23 10:33:08 --> Router Class Initialized
INFO - 2016-06-23 10:33:08 --> Output Class Initialized
INFO - 2016-06-23 10:33:08 --> Security Class Initialized
DEBUG - 2016-06-23 10:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 10:33:08 --> Input Class Initialized
INFO - 2016-06-23 10:33:08 --> Language Class Initialized
INFO - 2016-06-23 10:33:08 --> Loader Class Initialized
INFO - 2016-06-23 10:33:08 --> Helper loaded: form_helper
INFO - 2016-06-23 10:33:08 --> Database Driver Class Initialized
INFO - 2016-06-23 10:33:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 10:33:08 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 10:33:08 --> Email Class Initialized
INFO - 2016-06-23 10:33:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 10:33:08 --> Helper loaded: cookie_helper
INFO - 2016-06-23 10:33:08 --> Helper loaded: language_helper
INFO - 2016-06-23 10:33:08 --> Helper loaded: url_helper
DEBUG - 2016-06-23 10:33:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 10:33:09 --> Model Class Initialized
INFO - 2016-06-23 10:33:09 --> Helper loaded: date_helper
INFO - 2016-06-23 10:33:09 --> Controller Class Initialized
INFO - 2016-06-23 10:33:09 --> Helper loaded: languages_helper
INFO - 2016-06-23 10:33:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 10:33:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 10:33:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 10:33:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 10:33:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 13:33:09 --> Model Class Initialized
INFO - 2016-06-23 13:33:09 --> Final output sent to browser
DEBUG - 2016-06-23 13:33:09 --> Total execution time: 0.0814
INFO - 2016-06-23 18:42:37 --> Config Class Initialized
INFO - 2016-06-23 18:42:37 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:42:37 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:42:37 --> Utf8 Class Initialized
INFO - 2016-06-23 18:42:37 --> URI Class Initialized
INFO - 2016-06-23 18:42:37 --> Router Class Initialized
INFO - 2016-06-23 18:42:37 --> Output Class Initialized
INFO - 2016-06-23 18:42:37 --> Security Class Initialized
DEBUG - 2016-06-23 18:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:42:37 --> Input Class Initialized
INFO - 2016-06-23 18:42:37 --> Language Class Initialized
INFO - 2016-06-23 18:42:37 --> Loader Class Initialized
INFO - 2016-06-23 18:42:37 --> Helper loaded: form_helper
INFO - 2016-06-23 18:42:37 --> Database Driver Class Initialized
INFO - 2016-06-23 18:42:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:42:37 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:42:37 --> Email Class Initialized
INFO - 2016-06-23 18:42:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:42:37 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:42:37 --> Helper loaded: language_helper
INFO - 2016-06-23 18:42:37 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:42:37 --> Model Class Initialized
INFO - 2016-06-23 18:42:37 --> Helper loaded: date_helper
INFO - 2016-06-23 18:42:37 --> Controller Class Initialized
INFO - 2016-06-23 18:42:37 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:42:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:42:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:42:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:42:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:42:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:42:37 --> Model Class Initialized
INFO - 2016-06-23 21:42:37 --> Form Validation Class Initialized
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_user_data.php
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 21:42:37 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:42:37 --> Final output sent to browser
DEBUG - 2016-06-23 21:42:37 --> Total execution time: 0.1626
INFO - 2016-06-23 18:42:43 --> Config Class Initialized
INFO - 2016-06-23 18:42:43 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:42:43 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:42:43 --> Utf8 Class Initialized
INFO - 2016-06-23 18:42:43 --> URI Class Initialized
INFO - 2016-06-23 18:42:43 --> Router Class Initialized
INFO - 2016-06-23 18:42:43 --> Output Class Initialized
INFO - 2016-06-23 18:42:43 --> Security Class Initialized
DEBUG - 2016-06-23 18:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:42:43 --> Input Class Initialized
INFO - 2016-06-23 18:42:43 --> Language Class Initialized
INFO - 2016-06-23 18:42:43 --> Loader Class Initialized
INFO - 2016-06-23 18:42:43 --> Helper loaded: form_helper
INFO - 2016-06-23 18:42:43 --> Database Driver Class Initialized
INFO - 2016-06-23 18:42:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:42:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:42:43 --> Email Class Initialized
INFO - 2016-06-23 18:42:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:42:43 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:42:43 --> Helper loaded: language_helper
INFO - 2016-06-23 18:42:43 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:42:43 --> Model Class Initialized
INFO - 2016-06-23 18:42:43 --> Helper loaded: date_helper
INFO - 2016-06-23 18:42:43 --> Controller Class Initialized
INFO - 2016-06-23 18:42:43 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:42:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:42:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:42:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:42:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:42:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:42:43 --> Model Class Initialized
INFO - 2016-06-23 21:42:43 --> Form Validation Class Initialized
INFO - 2016-06-23 21:42:43 --> Final output sent to browser
DEBUG - 2016-06-23 21:42:43 --> Total execution time: 0.0845
INFO - 2016-06-23 18:43:13 --> Config Class Initialized
INFO - 2016-06-23 18:43:13 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:43:13 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:43:13 --> Utf8 Class Initialized
INFO - 2016-06-23 18:43:13 --> URI Class Initialized
INFO - 2016-06-23 18:43:13 --> Router Class Initialized
INFO - 2016-06-23 18:43:13 --> Output Class Initialized
INFO - 2016-06-23 18:43:13 --> Security Class Initialized
DEBUG - 2016-06-23 18:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:43:13 --> Input Class Initialized
INFO - 2016-06-23 18:43:13 --> Language Class Initialized
INFO - 2016-06-23 18:43:13 --> Loader Class Initialized
INFO - 2016-06-23 18:43:13 --> Helper loaded: form_helper
INFO - 2016-06-23 18:43:13 --> Database Driver Class Initialized
INFO - 2016-06-23 18:43:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:43:13 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:43:13 --> Email Class Initialized
INFO - 2016-06-23 18:43:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:43:13 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:43:13 --> Helper loaded: language_helper
INFO - 2016-06-23 18:43:13 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:43:13 --> Model Class Initialized
INFO - 2016-06-23 18:43:13 --> Helper loaded: date_helper
INFO - 2016-06-23 18:43:13 --> Controller Class Initialized
INFO - 2016-06-23 18:43:13 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:43:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:43:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:43:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:43:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:43:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:43:13 --> Model Class Initialized
INFO - 2016-06-23 21:43:13 --> Form Validation Class Initialized
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_user_data.php
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 21:43:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:43:13 --> Final output sent to browser
DEBUG - 2016-06-23 21:43:13 --> Total execution time: 0.1041
INFO - 2016-06-23 18:43:17 --> Config Class Initialized
INFO - 2016-06-23 18:43:17 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:43:17 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:43:17 --> Utf8 Class Initialized
INFO - 2016-06-23 18:43:17 --> URI Class Initialized
INFO - 2016-06-23 18:43:17 --> Router Class Initialized
INFO - 2016-06-23 18:43:17 --> Output Class Initialized
INFO - 2016-06-23 18:43:17 --> Security Class Initialized
DEBUG - 2016-06-23 18:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:43:17 --> Input Class Initialized
INFO - 2016-06-23 18:43:17 --> Language Class Initialized
INFO - 2016-06-23 18:43:17 --> Loader Class Initialized
INFO - 2016-06-23 18:43:17 --> Helper loaded: form_helper
INFO - 2016-06-23 18:43:17 --> Database Driver Class Initialized
INFO - 2016-06-23 18:43:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:43:17 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:43:17 --> Email Class Initialized
INFO - 2016-06-23 18:43:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:43:17 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:43:17 --> Helper loaded: language_helper
INFO - 2016-06-23 18:43:17 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:43:17 --> Model Class Initialized
INFO - 2016-06-23 18:43:17 --> Helper loaded: date_helper
INFO - 2016-06-23 18:43:17 --> Controller Class Initialized
INFO - 2016-06-23 18:43:17 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:43:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:43:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:43:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:43:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:43:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:43:17 --> Model Class Initialized
INFO - 2016-06-23 21:43:17 --> Form Validation Class Initialized
INFO - 2016-06-23 21:43:17 --> Final output sent to browser
DEBUG - 2016-06-23 21:43:17 --> Total execution time: 0.0895
INFO - 2016-06-23 18:43:20 --> Config Class Initialized
INFO - 2016-06-23 18:43:20 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:43:20 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:43:20 --> Utf8 Class Initialized
INFO - 2016-06-23 18:43:20 --> URI Class Initialized
INFO - 2016-06-23 18:43:20 --> Router Class Initialized
INFO - 2016-06-23 18:43:20 --> Output Class Initialized
INFO - 2016-06-23 18:43:20 --> Security Class Initialized
DEBUG - 2016-06-23 18:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:43:20 --> Input Class Initialized
INFO - 2016-06-23 18:43:20 --> Language Class Initialized
INFO - 2016-06-23 18:43:20 --> Loader Class Initialized
INFO - 2016-06-23 18:43:20 --> Helper loaded: form_helper
INFO - 2016-06-23 18:43:20 --> Database Driver Class Initialized
INFO - 2016-06-23 18:43:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:43:20 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:43:20 --> Email Class Initialized
INFO - 2016-06-23 18:43:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:43:20 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:43:20 --> Helper loaded: language_helper
INFO - 2016-06-23 18:43:20 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:43:20 --> Model Class Initialized
INFO - 2016-06-23 18:43:20 --> Helper loaded: date_helper
INFO - 2016-06-23 18:43:20 --> Controller Class Initialized
INFO - 2016-06-23 18:43:20 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:43:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:43:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:43:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:43:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:43:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:43:20 --> Model Class Initialized
INFO - 2016-06-23 21:43:20 --> Form Validation Class Initialized
INFO - 2016-06-23 21:43:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:43:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/lista_persoanelor_cu_access.php
INFO - 2016-06-23 21:43:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:43:20 --> File loaded: /home/diabet/public_html/application/views/user_area/listaAcces.php
INFO - 2016-06-23 21:43:20 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:43:20 --> Final output sent to browser
DEBUG - 2016-06-23 21:43:20 --> Total execution time: 0.1208
INFO - 2016-06-23 18:48:21 --> Config Class Initialized
INFO - 2016-06-23 18:48:21 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:48:21 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:48:21 --> Utf8 Class Initialized
INFO - 2016-06-23 18:48:21 --> URI Class Initialized
INFO - 2016-06-23 18:48:21 --> Router Class Initialized
INFO - 2016-06-23 18:48:21 --> Output Class Initialized
INFO - 2016-06-23 18:48:21 --> Security Class Initialized
DEBUG - 2016-06-23 18:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:48:21 --> Input Class Initialized
INFO - 2016-06-23 18:48:21 --> Language Class Initialized
INFO - 2016-06-23 18:48:21 --> Loader Class Initialized
INFO - 2016-06-23 18:48:21 --> Helper loaded: form_helper
INFO - 2016-06-23 18:48:21 --> Database Driver Class Initialized
INFO - 2016-06-23 18:48:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:48:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:48:21 --> Email Class Initialized
INFO - 2016-06-23 18:48:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:48:21 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:48:21 --> Helper loaded: language_helper
INFO - 2016-06-23 18:48:21 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:48:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:48:21 --> Model Class Initialized
INFO - 2016-06-23 18:48:21 --> Helper loaded: date_helper
INFO - 2016-06-23 18:48:21 --> Controller Class Initialized
INFO - 2016-06-23 18:48:21 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:48:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:48:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:48:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:48:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:48:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 21:48:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 21:48:21 --> Form Validation Class Initialized
DEBUG - 2016-06-23 21:48:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-23 21:48:21 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 21:48:21 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 21:48:21 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 21:48:21 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 21:48:21 --> Final output sent to browser
DEBUG - 2016-06-23 21:48:21 --> Total execution time: 0.1078
INFO - 2016-06-23 18:48:23 --> Config Class Initialized
INFO - 2016-06-23 18:48:23 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:48:23 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:48:23 --> Utf8 Class Initialized
INFO - 2016-06-23 18:48:23 --> URI Class Initialized
INFO - 2016-06-23 18:48:23 --> Router Class Initialized
INFO - 2016-06-23 18:48:23 --> Output Class Initialized
INFO - 2016-06-23 18:48:23 --> Security Class Initialized
DEBUG - 2016-06-23 18:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:48:23 --> Input Class Initialized
INFO - 2016-06-23 18:48:23 --> Language Class Initialized
INFO - 2016-06-23 18:48:23 --> Loader Class Initialized
INFO - 2016-06-23 18:48:23 --> Helper loaded: form_helper
INFO - 2016-06-23 18:48:23 --> Database Driver Class Initialized
INFO - 2016-06-23 18:48:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:48:23 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:48:23 --> Email Class Initialized
INFO - 2016-06-23 18:48:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:48:23 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:48:23 --> Helper loaded: language_helper
INFO - 2016-06-23 18:48:23 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:48:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:48:23 --> Model Class Initialized
INFO - 2016-06-23 18:48:23 --> Helper loaded: date_helper
INFO - 2016-06-23 18:48:23 --> Controller Class Initialized
INFO - 2016-06-23 18:48:23 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:48:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:48:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:48:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:48:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:48:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:48:23 --> Model Class Initialized
INFO - 2016-06-23 21:48:23 --> Final output sent to browser
DEBUG - 2016-06-23 21:48:23 --> Total execution time: 0.1307
INFO - 2016-06-23 18:48:45 --> Config Class Initialized
INFO - 2016-06-23 18:48:45 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:48:45 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:48:45 --> Utf8 Class Initialized
INFO - 2016-06-23 18:48:45 --> URI Class Initialized
INFO - 2016-06-23 18:48:45 --> Router Class Initialized
INFO - 2016-06-23 18:48:45 --> Output Class Initialized
INFO - 2016-06-23 18:48:45 --> Security Class Initialized
DEBUG - 2016-06-23 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:48:45 --> Input Class Initialized
INFO - 2016-06-23 18:48:45 --> Language Class Initialized
INFO - 2016-06-23 18:48:45 --> Loader Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: form_helper
INFO - 2016-06-23 18:48:45 --> Database Driver Class Initialized
INFO - 2016-06-23 18:48:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:48:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:48:45 --> Email Class Initialized
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:48:45 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:48:45 --> Helper loaded: language_helper
INFO - 2016-06-23 18:48:45 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:48:45 --> Model Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: date_helper
INFO - 2016-06-23 18:48:45 --> Controller Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 21:48:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 21:48:45 --> Form Validation Class Initialized
DEBUG - 2016-06-23 21:48:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:48:45 --> Config Class Initialized
INFO - 2016-06-23 18:48:45 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:48:45 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:48:45 --> Utf8 Class Initialized
INFO - 2016-06-23 18:48:45 --> URI Class Initialized
DEBUG - 2016-06-23 18:48:45 --> No URI present. Default controller set.
INFO - 2016-06-23 18:48:45 --> Router Class Initialized
INFO - 2016-06-23 18:48:45 --> Output Class Initialized
INFO - 2016-06-23 18:48:45 --> Security Class Initialized
DEBUG - 2016-06-23 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:48:45 --> Input Class Initialized
INFO - 2016-06-23 18:48:45 --> Language Class Initialized
INFO - 2016-06-23 18:48:45 --> Loader Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: form_helper
INFO - 2016-06-23 18:48:45 --> Database Driver Class Initialized
INFO - 2016-06-23 18:48:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:48:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:48:45 --> Email Class Initialized
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:48:45 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:48:45 --> Helper loaded: language_helper
INFO - 2016-06-23 18:48:45 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:48:45 --> Model Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: date_helper
INFO - 2016-06-23 18:48:45 --> Controller Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 18:48:45 --> Config Class Initialized
INFO - 2016-06-23 18:48:45 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:48:45 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:48:45 --> Utf8 Class Initialized
INFO - 2016-06-23 18:48:45 --> URI Class Initialized
INFO - 2016-06-23 18:48:45 --> Router Class Initialized
INFO - 2016-06-23 18:48:45 --> Output Class Initialized
INFO - 2016-06-23 18:48:45 --> Security Class Initialized
DEBUG - 2016-06-23 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:48:45 --> Input Class Initialized
INFO - 2016-06-23 18:48:45 --> Language Class Initialized
INFO - 2016-06-23 18:48:45 --> Loader Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: form_helper
INFO - 2016-06-23 18:48:45 --> Database Driver Class Initialized
INFO - 2016-06-23 18:48:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:48:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:48:45 --> Email Class Initialized
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:48:45 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:48:45 --> Helper loaded: language_helper
INFO - 2016-06-23 18:48:45 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:48:45 --> Model Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: date_helper
INFO - 2016-06-23 18:48:45 --> Controller Class Initialized
INFO - 2016-06-23 18:48:45 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:48:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:48:45 --> Model Class Initialized
INFO - 2016-06-23 21:48:45 --> Form Validation Class Initialized
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 21:48:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:48:45 --> Final output sent to browser
DEBUG - 2016-06-23 21:48:45 --> Total execution time: 0.1063
INFO - 2016-06-23 18:48:47 --> Config Class Initialized
INFO - 2016-06-23 18:48:47 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:48:47 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:48:47 --> Utf8 Class Initialized
INFO - 2016-06-23 18:48:47 --> URI Class Initialized
INFO - 2016-06-23 18:48:47 --> Router Class Initialized
INFO - 2016-06-23 18:48:47 --> Output Class Initialized
INFO - 2016-06-23 18:48:47 --> Security Class Initialized
DEBUG - 2016-06-23 18:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:48:47 --> Input Class Initialized
INFO - 2016-06-23 18:48:47 --> Language Class Initialized
INFO - 2016-06-23 18:48:47 --> Loader Class Initialized
INFO - 2016-06-23 18:48:47 --> Helper loaded: form_helper
INFO - 2016-06-23 18:48:47 --> Database Driver Class Initialized
INFO - 2016-06-23 18:48:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:48:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:48:47 --> Email Class Initialized
INFO - 2016-06-23 18:48:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:48:47 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:48:47 --> Helper loaded: language_helper
INFO - 2016-06-23 18:48:47 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:48:47 --> Model Class Initialized
INFO - 2016-06-23 18:48:47 --> Helper loaded: date_helper
INFO - 2016-06-23 18:48:47 --> Controller Class Initialized
INFO - 2016-06-23 18:48:47 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:48:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:48:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:48:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:48:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:48:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:48:47 --> Model Class Initialized
INFO - 2016-06-23 21:48:47 --> Form Validation Class Initialized
INFO - 2016-06-23 21:48:47 --> Final output sent to browser
DEBUG - 2016-06-23 21:48:47 --> Total execution time: 0.0887
INFO - 2016-06-23 18:50:13 --> Config Class Initialized
INFO - 2016-06-23 18:50:13 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:50:13 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:50:13 --> Utf8 Class Initialized
INFO - 2016-06-23 18:50:13 --> URI Class Initialized
INFO - 2016-06-23 18:50:13 --> Router Class Initialized
INFO - 2016-06-23 18:50:13 --> Output Class Initialized
INFO - 2016-06-23 18:50:13 --> Security Class Initialized
DEBUG - 2016-06-23 18:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:50:13 --> Input Class Initialized
INFO - 2016-06-23 18:50:13 --> Language Class Initialized
INFO - 2016-06-23 18:50:13 --> Loader Class Initialized
INFO - 2016-06-23 18:50:13 --> Helper loaded: form_helper
INFO - 2016-06-23 18:50:13 --> Database Driver Class Initialized
INFO - 2016-06-23 18:50:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:50:13 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:50:13 --> Email Class Initialized
INFO - 2016-06-23 18:50:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:50:13 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:50:13 --> Helper loaded: language_helper
INFO - 2016-06-23 18:50:13 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:50:13 --> Model Class Initialized
INFO - 2016-06-23 18:50:13 --> Helper loaded: date_helper
INFO - 2016-06-23 18:50:13 --> Controller Class Initialized
INFO - 2016-06-23 18:50:13 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:50:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:50:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:50:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:50:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:50:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:50:13 --> Model Class Initialized
INFO - 2016-06-23 21:50:13 --> Form Validation Class Initialized
INFO - 2016-06-23 21:50:13 --> Helper loaded: sort_array_helper
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-23 21:50:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:50:13 --> Final output sent to browser
DEBUG - 2016-06-23 21:50:13 --> Total execution time: 0.1054
INFO - 2016-06-23 18:50:21 --> Config Class Initialized
INFO - 2016-06-23 18:50:21 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:50:21 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:50:21 --> Utf8 Class Initialized
INFO - 2016-06-23 18:50:21 --> URI Class Initialized
INFO - 2016-06-23 18:50:21 --> Router Class Initialized
INFO - 2016-06-23 18:50:21 --> Output Class Initialized
INFO - 2016-06-23 18:50:21 --> Security Class Initialized
DEBUG - 2016-06-23 18:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:50:21 --> Input Class Initialized
INFO - 2016-06-23 18:50:21 --> Language Class Initialized
INFO - 2016-06-23 18:50:21 --> Loader Class Initialized
INFO - 2016-06-23 18:50:21 --> Helper loaded: form_helper
INFO - 2016-06-23 18:50:21 --> Database Driver Class Initialized
INFO - 2016-06-23 18:50:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:50:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:50:21 --> Email Class Initialized
INFO - 2016-06-23 18:50:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:50:21 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:50:21 --> Helper loaded: language_helper
INFO - 2016-06-23 18:50:21 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:50:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:50:21 --> Model Class Initialized
INFO - 2016-06-23 18:50:21 --> Helper loaded: date_helper
INFO - 2016-06-23 18:50:21 --> Controller Class Initialized
INFO - 2016-06-23 18:50:21 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:50:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:50:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:50:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:50:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:50:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:50:21 --> Model Class Initialized
INFO - 2016-06-23 21:50:21 --> Form Validation Class Initialized
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 21:50:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:50:21 --> Final output sent to browser
DEBUG - 2016-06-23 21:50:21 --> Total execution time: 0.1185
INFO - 2016-06-23 18:50:22 --> Config Class Initialized
INFO - 2016-06-23 18:50:22 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:50:22 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:50:22 --> Utf8 Class Initialized
INFO - 2016-06-23 18:50:22 --> URI Class Initialized
INFO - 2016-06-23 18:50:22 --> Router Class Initialized
INFO - 2016-06-23 18:50:22 --> Output Class Initialized
INFO - 2016-06-23 18:50:22 --> Security Class Initialized
DEBUG - 2016-06-23 18:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:50:22 --> Input Class Initialized
INFO - 2016-06-23 18:50:22 --> Language Class Initialized
INFO - 2016-06-23 18:50:22 --> Loader Class Initialized
INFO - 2016-06-23 18:50:22 --> Helper loaded: form_helper
INFO - 2016-06-23 18:50:22 --> Database Driver Class Initialized
INFO - 2016-06-23 18:50:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:50:22 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:50:22 --> Email Class Initialized
INFO - 2016-06-23 18:50:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:50:22 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:50:22 --> Helper loaded: language_helper
INFO - 2016-06-23 18:50:22 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:50:22 --> Model Class Initialized
INFO - 2016-06-23 18:50:22 --> Helper loaded: date_helper
INFO - 2016-06-23 18:50:22 --> Controller Class Initialized
INFO - 2016-06-23 18:50:22 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:50:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:50:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:50:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:50:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:50:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:50:22 --> Model Class Initialized
INFO - 2016-06-23 21:50:22 --> Form Validation Class Initialized
INFO - 2016-06-23 21:50:22 --> Final output sent to browser
DEBUG - 2016-06-23 21:50:22 --> Total execution time: 0.0960
INFO - 2016-06-23 18:50:48 --> Config Class Initialized
INFO - 2016-06-23 18:50:48 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:50:48 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:50:48 --> Utf8 Class Initialized
INFO - 2016-06-23 18:50:48 --> URI Class Initialized
INFO - 2016-06-23 18:50:48 --> Router Class Initialized
INFO - 2016-06-23 18:50:48 --> Output Class Initialized
INFO - 2016-06-23 18:50:48 --> Security Class Initialized
DEBUG - 2016-06-23 18:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:50:48 --> Input Class Initialized
INFO - 2016-06-23 18:50:48 --> Language Class Initialized
INFO - 2016-06-23 18:50:48 --> Loader Class Initialized
INFO - 2016-06-23 18:50:48 --> Helper loaded: form_helper
INFO - 2016-06-23 18:50:48 --> Database Driver Class Initialized
INFO - 2016-06-23 18:50:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:50:48 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:50:48 --> Email Class Initialized
INFO - 2016-06-23 18:50:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:50:48 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:50:48 --> Helper loaded: language_helper
INFO - 2016-06-23 18:50:48 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:50:48 --> Model Class Initialized
INFO - 2016-06-23 18:50:48 --> Helper loaded: date_helper
INFO - 2016-06-23 18:50:48 --> Controller Class Initialized
INFO - 2016-06-23 18:50:48 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:50:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:50:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:50:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:50:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:50:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:50:48 --> Model Class Initialized
INFO - 2016-06-23 21:50:48 --> Form Validation Class Initialized
INFO - 2016-06-23 21:50:48 --> Helper loaded: sort_array_helper
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-23 21:50:48 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:50:48 --> Final output sent to browser
DEBUG - 2016-06-23 21:50:48 --> Total execution time: 0.0879
INFO - 2016-06-23 18:51:02 --> Config Class Initialized
INFO - 2016-06-23 18:51:02 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:02 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:02 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:02 --> URI Class Initialized
INFO - 2016-06-23 18:51:02 --> Router Class Initialized
INFO - 2016-06-23 18:51:02 --> Output Class Initialized
INFO - 2016-06-23 18:51:02 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:02 --> Input Class Initialized
INFO - 2016-06-23 18:51:02 --> Language Class Initialized
INFO - 2016-06-23 18:51:02 --> Loader Class Initialized
INFO - 2016-06-23 18:51:02 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:02 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:02 --> Email Class Initialized
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:02 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:02 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:02 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:02 --> Model Class Initialized
INFO - 2016-06-23 18:51:02 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:02 --> Controller Class Initialized
INFO - 2016-06-23 18:51:02 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:51:02 --> Model Class Initialized
INFO - 2016-06-23 21:51:02 --> Form Validation Class Initialized
DEBUG - 2016-06-23 21:51:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:02 --> Config Class Initialized
INFO - 2016-06-23 18:51:02 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:02 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:02 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:02 --> URI Class Initialized
INFO - 2016-06-23 18:51:02 --> Router Class Initialized
INFO - 2016-06-23 18:51:02 --> Output Class Initialized
INFO - 2016-06-23 18:51:02 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:02 --> Input Class Initialized
INFO - 2016-06-23 18:51:02 --> Language Class Initialized
INFO - 2016-06-23 18:51:02 --> Loader Class Initialized
INFO - 2016-06-23 18:51:02 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:02 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:02 --> Email Class Initialized
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:02 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:02 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:02 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:02 --> Model Class Initialized
INFO - 2016-06-23 18:51:02 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:02 --> Controller Class Initialized
INFO - 2016-06-23 18:51:02 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:51:02 --> Model Class Initialized
INFO - 2016-06-23 21:51:02 --> Form Validation Class Initialized
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 21:51:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:51:02 --> Final output sent to browser
DEBUG - 2016-06-23 21:51:02 --> Total execution time: 0.1079
INFO - 2016-06-23 18:51:03 --> Config Class Initialized
INFO - 2016-06-23 18:51:03 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:03 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:03 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:03 --> URI Class Initialized
INFO - 2016-06-23 18:51:03 --> Router Class Initialized
INFO - 2016-06-23 18:51:03 --> Output Class Initialized
INFO - 2016-06-23 18:51:03 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:03 --> Input Class Initialized
INFO - 2016-06-23 18:51:03 --> Language Class Initialized
INFO - 2016-06-23 18:51:03 --> Loader Class Initialized
INFO - 2016-06-23 18:51:03 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:03 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:03 --> Email Class Initialized
INFO - 2016-06-23 18:51:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:03 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:03 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:03 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:03 --> Model Class Initialized
INFO - 2016-06-23 18:51:03 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:03 --> Controller Class Initialized
INFO - 2016-06-23 18:51:03 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:51:03 --> Model Class Initialized
INFO - 2016-06-23 21:51:04 --> Form Validation Class Initialized
INFO - 2016-06-23 21:51:04 --> Final output sent to browser
DEBUG - 2016-06-23 21:51:04 --> Total execution time: 0.0959
INFO - 2016-06-23 18:51:14 --> Config Class Initialized
INFO - 2016-06-23 18:51:14 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:14 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:14 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:14 --> URI Class Initialized
INFO - 2016-06-23 18:51:14 --> Router Class Initialized
INFO - 2016-06-23 18:51:14 --> Output Class Initialized
INFO - 2016-06-23 18:51:14 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:14 --> Input Class Initialized
INFO - 2016-06-23 18:51:14 --> Language Class Initialized
INFO - 2016-06-23 18:51:14 --> Loader Class Initialized
INFO - 2016-06-23 18:51:14 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:14 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:14 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:14 --> Email Class Initialized
INFO - 2016-06-23 18:51:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:14 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:14 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:14 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:14 --> Model Class Initialized
INFO - 2016-06-23 18:51:14 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:14 --> Controller Class Initialized
INFO - 2016-06-23 18:51:14 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:51:14 --> Model Class Initialized
INFO - 2016-06-23 21:51:14 --> Form Validation Class Initialized
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-23 21:51:14 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-23 21:51:14 --> Final output sent to browser
DEBUG - 2016-06-23 21:51:14 --> Total execution time: 0.1084
INFO - 2016-06-23 18:51:16 --> Config Class Initialized
INFO - 2016-06-23 18:51:16 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:16 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:16 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:16 --> URI Class Initialized
INFO - 2016-06-23 18:51:16 --> Router Class Initialized
INFO - 2016-06-23 18:51:16 --> Output Class Initialized
INFO - 2016-06-23 18:51:16 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:16 --> Input Class Initialized
INFO - 2016-06-23 18:51:16 --> Language Class Initialized
INFO - 2016-06-23 18:51:16 --> Loader Class Initialized
INFO - 2016-06-23 18:51:16 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:16 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:16 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:16 --> Email Class Initialized
INFO - 2016-06-23 18:51:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:16 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:16 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:16 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:16 --> Model Class Initialized
INFO - 2016-06-23 18:51:16 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:16 --> Controller Class Initialized
INFO - 2016-06-23 18:51:16 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:51:16 --> Model Class Initialized
INFO - 2016-06-23 21:51:16 --> Form Validation Class Initialized
INFO - 2016-06-23 21:51:16 --> Final output sent to browser
DEBUG - 2016-06-23 21:51:16 --> Total execution time: 0.0916
INFO - 2016-06-23 18:51:24 --> Config Class Initialized
INFO - 2016-06-23 18:51:24 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:24 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:24 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:24 --> URI Class Initialized
INFO - 2016-06-23 18:51:24 --> Router Class Initialized
INFO - 2016-06-23 18:51:24 --> Output Class Initialized
INFO - 2016-06-23 18:51:24 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:24 --> Input Class Initialized
INFO - 2016-06-23 18:51:24 --> Language Class Initialized
INFO - 2016-06-23 18:51:24 --> Loader Class Initialized
INFO - 2016-06-23 18:51:24 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:24 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:24 --> Email Class Initialized
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:24 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:24 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:24 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:24 --> Model Class Initialized
INFO - 2016-06-23 18:51:24 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:24 --> Controller Class Initialized
INFO - 2016-06-23 18:51:24 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-23 21:51:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-23 21:51:24 --> Form Validation Class Initialized
INFO - 2016-06-23 18:51:24 --> Config Class Initialized
INFO - 2016-06-23 18:51:24 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:24 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:24 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:24 --> URI Class Initialized
DEBUG - 2016-06-23 18:51:24 --> No URI present. Default controller set.
INFO - 2016-06-23 18:51:24 --> Router Class Initialized
INFO - 2016-06-23 18:51:24 --> Output Class Initialized
INFO - 2016-06-23 18:51:24 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:24 --> Input Class Initialized
INFO - 2016-06-23 18:51:24 --> Language Class Initialized
INFO - 2016-06-23 18:51:24 --> Loader Class Initialized
INFO - 2016-06-23 18:51:24 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:24 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:24 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:24 --> Email Class Initialized
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:24 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:24 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:24 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:24 --> Model Class Initialized
INFO - 2016-06-23 18:51:24 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:24 --> Controller Class Initialized
INFO - 2016-06-23 18:51:24 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:51:24 --> Model Class Initialized
INFO - 2016-06-23 21:51:24 --> Form Validation Class Initialized
INFO - 2016-06-23 21:51:24 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-23 21:51:24 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-23 21:51:24 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-23 21:51:24 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-23 21:51:24 --> Final output sent to browser
DEBUG - 2016-06-23 21:51:24 --> Total execution time: 0.0953
INFO - 2016-06-23 18:51:26 --> Config Class Initialized
INFO - 2016-06-23 18:51:26 --> Hooks Class Initialized
DEBUG - 2016-06-23 18:51:26 --> UTF-8 Support Enabled
INFO - 2016-06-23 18:51:26 --> Utf8 Class Initialized
INFO - 2016-06-23 18:51:26 --> URI Class Initialized
INFO - 2016-06-23 18:51:26 --> Router Class Initialized
INFO - 2016-06-23 18:51:26 --> Output Class Initialized
INFO - 2016-06-23 18:51:26 --> Security Class Initialized
DEBUG - 2016-06-23 18:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-23 18:51:26 --> Input Class Initialized
INFO - 2016-06-23 18:51:26 --> Language Class Initialized
INFO - 2016-06-23 18:51:26 --> Loader Class Initialized
INFO - 2016-06-23 18:51:26 --> Helper loaded: form_helper
INFO - 2016-06-23 18:51:26 --> Database Driver Class Initialized
INFO - 2016-06-23 18:51:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-23 18:51:26 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-23 18:51:26 --> Email Class Initialized
INFO - 2016-06-23 18:51:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-23 18:51:26 --> Helper loaded: cookie_helper
INFO - 2016-06-23 18:51:26 --> Helper loaded: language_helper
INFO - 2016-06-23 18:51:26 --> Helper loaded: url_helper
DEBUG - 2016-06-23 18:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-23 18:51:26 --> Model Class Initialized
INFO - 2016-06-23 18:51:26 --> Helper loaded: date_helper
INFO - 2016-06-23 18:51:26 --> Controller Class Initialized
INFO - 2016-06-23 18:51:26 --> Helper loaded: languages_helper
INFO - 2016-06-23 18:51:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-23 18:51:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-23 18:51:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-23 18:51:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-23 18:51:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-23 21:51:26 --> Model Class Initialized
INFO - 2016-06-23 21:51:26 --> Final output sent to browser
DEBUG - 2016-06-23 21:51:26 --> Total execution time: 0.0808
