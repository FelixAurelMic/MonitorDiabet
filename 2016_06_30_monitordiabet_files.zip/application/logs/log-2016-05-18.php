<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-05-18 08:59:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 08:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 08:59:36 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 14
DEBUG - 2016-05-18 08:59:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 08:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 08:59:36 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 14
DEBUG - 2016-05-18 08:59:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 08:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 08:59:36 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 14
DEBUG - 2016-05-18 09:01:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:01:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:01:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:01:05 --> Total execution time: 0.5544
DEBUG - 2016-05-18 09:09:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:09:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:09:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:09:52 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:09:52 --> Severity: Notice --> Undefined variable: languages /home/demis/www/platformadiabet/application/views/public/res/header.php 45
DEBUG - 2016-05-18 09:09:52 --> Total execution time: 0.0582
DEBUG - 2016-05-18 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:10:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:10:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:10:28 --> Total execution time: 0.0287
DEBUG - 2016-05-18 09:12:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:12:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:12:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:17:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:17:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:17:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:17:14 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:17:14 --> Severity: Notice --> Undefined property: Auth::$lang_format /home/demis/www/platformadiabet/application/core/SVS_Controller.php 104
DEBUG - 2016-05-18 09:17:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:17:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:17:49 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:17:49 --> Severity: Notice --> Undefined variable: user_lang /home/demis/www/platformadiabet/application/core/SVS_Controller.php 106
ERROR - 2016-05-18 09:17:49 --> Severity: Notice --> Undefined variable: user_lang /home/demis/www/platformadiabet/application/core/SVS_Controller.php 106
ERROR - 2016-05-18 09:17:49 --> Severity: Notice --> Undefined variable: user_lang /home/demis/www/platformadiabet/application/core/SVS_Controller.php 106
ERROR - 2016-05-18 09:17:49 --> Severity: Notice --> Undefined variable: user_lang /home/demis/www/platformadiabet/application/core/SVS_Controller.php 106
DEBUG - 2016-05-18 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:25:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:25:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:25:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:25:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:25:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:25:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:25:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:25:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:26:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:26:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:26:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:27:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:27:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:28:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:28:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:28:45 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:28:45 --> Severity: Error --> Call to undefined method Auth::set_languages() /home/demis/www/platformadiabet/application/core/SVS_Controller.php 61
DEBUG - 2016-05-18 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:29:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:29:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:29:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:29:02 --> Total execution time: 0.0087
DEBUG - 2016-05-18 09:42:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:42:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:42:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:42:24 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:42:24 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 94
ERROR - 2016-05-18 09:42:24 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 94
DEBUG - 2016-05-18 09:42:24 --> Total execution time: 0.0291
DEBUG - 2016-05-18 09:43:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:43:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:43:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:43:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:43:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:43:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:43:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:44:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:44:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:44:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:44:05 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:44:05 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 93
ERROR - 2016-05-18 09:44:05 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 93
DEBUG - 2016-05-18 09:44:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:44:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:44:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:44:25 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:44:25 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 93
ERROR - 2016-05-18 09:44:25 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 93
ERROR - 2016-05-18 09:44:25 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/core/SVS_Controller.php 96
DEBUG - 2016-05-18 09:44:25 --> Total execution time: 0.0101
DEBUG - 2016-05-18 09:45:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:45:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:45:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:45:06 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:45:06 --> Severity: Error --> Call to undefined function arrray() /home/demis/www/platformadiabet/application/core/SVS_Controller.php 92
DEBUG - 2016-05-18 09:46:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:46:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:46:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:46:35 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:46:35 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 94
ERROR - 2016-05-18 09:46:36 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 94
ERROR - 2016-05-18 09:46:36 --> Severity: Notice --> Undefined index: languages /home/demis/www/platformadiabet/application/core/SVS_Controller.php 97
DEBUG - 2016-05-18 09:46:36 --> Total execution time: 0.0381
DEBUG - 2016-05-18 09:47:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:47:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:47:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:47:01 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:47:01 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 95
ERROR - 2016-05-18 09:47:01 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 95
ERROR - 2016-05-18 09:47:01 --> Severity: Notice --> Undefined index: languages /home/demis/www/platformadiabet/application/core/SVS_Controller.php 98
DEBUG - 2016-05-18 09:47:01 --> Total execution time: 0.0408
DEBUG - 2016-05-18 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:48:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:48:31 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 09:48:31 --> Severity: Notice --> Undefined index: languages /home/demis/www/platformadiabet/application/core/SVS_Controller.php 97
DEBUG - 2016-05-18 09:48:31 --> Total execution time: 0.0334
DEBUG - 2016-05-18 09:48:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:48:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:48:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:48:52 --> Total execution time: 0.0436
DEBUG - 2016-05-18 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:48:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:48:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:48:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:48:59 --> Total execution time: 0.0442
DEBUG - 2016-05-18 09:49:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:49:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:49:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:49:34 --> Total execution time: 0.0586
DEBUG - 2016-05-18 09:49:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:49:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:49:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:49:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:49:57 --> Total execution time: 0.0385
DEBUG - 2016-05-18 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:50:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:50:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:50:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:50:35 --> Total execution time: 0.0494
DEBUG - 2016-05-18 09:53:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:53:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:53:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:53:36 --> Total execution time: 0.0324
DEBUG - 2016-05-18 09:55:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:55:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:55:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:55:15 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:55:15 --> Total execution time: 0.0721
DEBUG - 2016-05-18 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:56:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:56:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:56:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:56:05 --> Total execution time: 0.0359
DEBUG - 2016-05-18 09:56:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:56:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:56:19 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:56:19 --> Total execution time: 0.0530
DEBUG - 2016-05-18 09:57:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:57:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:57:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:57:16 --> Total execution time: 0.0303
DEBUG - 2016-05-18 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 09:58:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 09:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:58:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 09:58:44 --> Total execution time: 0.0289
DEBUG - 2016-05-18 10:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:01:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:01:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:01:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:01:41 --> Total execution time: 0.0403
DEBUG - 2016-05-18 10:01:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:03:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:03:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:03:29 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:03:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:03:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:03:29 --> Total execution time: 0.0999
DEBUG - 2016-05-18 10:03:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:03:36 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:17:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:17:01 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:17:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:17:01 --> Total execution time: 0.0990
DEBUG - 2016-05-18 10:17:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:17:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:17:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:17:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:17:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:17:53 --> Total execution time: 0.0115
DEBUG - 2016-05-18 10:18:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:18:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:18:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:21:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:21:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:21:12 --> Total execution time: 0.0461
DEBUG - 2016-05-18 10:21:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:21:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:21:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:21:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:21:44 --> Total execution time: 0.0588
DEBUG - 2016-05-18 10:22:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:22:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:22:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:22:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:22:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:22:01 --> Total execution time: 0.0093
DEBUG - 2016-05-18 10:22:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 10:22:12 --> 404 Page Not Found: Website/language
DEBUG - 2016-05-18 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 10:22:24 --> 404 Page Not Found: Website/language
DEBUG - 2016-05-18 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:03 --> Total execution time: 0.0338
DEBUG - 2016-05-18 10:23:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 10:23:27 --> 404 Page Not Found: Website/set-language
DEBUG - 2016-05-18 10:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:35 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:35 --> Total execution time: 0.0622
DEBUG - 2016-05-18 10:23:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:42 --> Total execution time: 0.0248
DEBUG - 2016-05-18 10:23:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:47 --> Total execution time: 0.0444
DEBUG - 2016-05-18 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:52 --> Total execution time: 0.0464
DEBUG - 2016-05-18 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:55 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:55 --> Total execution time: 0.0533
DEBUG - 2016-05-18 10:23:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:23:58 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:23:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:23:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:23:58 --> Total execution time: 0.0295
DEBUG - 2016-05-18 10:24:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:24:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:24:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:24:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:24:02 --> Total execution time: 0.0647
DEBUG - 2016-05-18 10:24:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:24:06 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:24:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:24:06 --> Total execution time: 0.0511
DEBUG - 2016-05-18 10:24:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:24:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:24:12 --> Total execution time: 2.3759
DEBUG - 2016-05-18 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:24:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:24:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:25:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:25:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:25:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:25:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:26:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:26:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:27:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:27:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:27:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:27:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:27:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:27:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:34:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:34:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:34:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:34:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:34:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:35:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:35:23 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:35:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:35:23 --> Total execution time: 0.0507
DEBUG - 2016-05-18 10:35:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:36:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:36:26 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:36:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:36:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:36:26 --> Total execution time: 0.0327
DEBUG - 2016-05-18 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:36:30 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:36:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:36:30 --> Total execution time: 0.0440
DEBUG - 2016-05-18 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:37:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:37:30 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:37:30 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:37:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:37:30 --> Total execution time: 0.0214
DEBUG - 2016-05-18 10:37:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:42:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:42:59 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:42:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:42:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:42:59 --> Total execution time: 0.0514
DEBUG - 2016-05-18 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:43:47 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:43:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:43:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:43:47 --> Total execution time: 0.0467
DEBUG - 2016-05-18 10:43:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:44:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:44:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:44:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:45:01 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:45:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:45:01 --> Total execution time: 0.0103
DEBUG - 2016-05-18 10:45:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:49:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:49:26 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:49:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:49:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 10:49:26 --> Severity: Notice --> Undefined variable: csrf /home/demis/www/platformadiabet/application/views/public/res/header.php 55
DEBUG - 2016-05-18 10:49:26 --> Total execution time: 0.0347
DEBUG - 2016-05-18 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:53:41 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:53:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:53:41 --> Total execution time: 0.0385
DEBUG - 2016-05-18 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:53:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:53:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:54:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:54:19 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:54:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:54:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:54:19 --> Total execution time: 0.0114
DEBUG - 2016-05-18 10:54:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:54:24 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:54:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:54:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:54:24 --> Total execution time: 0.0370
DEBUG - 2016-05-18 10:54:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:54:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:54:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:54:29 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:54:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:54:29 --> Total execution time: 0.0416
DEBUG - 2016-05-18 10:58:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:58:15 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:58:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:58:15 --> Total execution time: 0.1572
DEBUG - 2016-05-18 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 10:59:32 --> No URI present. Default controller set.
DEBUG - 2016-05-18 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 10:59:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 10:59:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 10:59:32 --> Total execution time: 0.0331
DEBUG - 2016-05-18 11:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:01:15 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:01:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:01:15 --> Total execution time: 0.0388
DEBUG - 2016-05-18 11:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:02:09 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:02:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:02:09 --> Total execution time: 0.0407
DEBUG - 2016-05-18 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:02:52 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:02:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:02:52 --> Total execution time: 0.0319
DEBUG - 2016-05-18 11:04:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:04:55 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:04:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:04:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:05:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:05:19 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:05:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:05:58 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:05:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:05:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:05:58 --> Total execution time: 0.0430
DEBUG - 2016-05-18 11:06:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:06:05 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:06:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:06:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:06:17 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:06:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:06:17 --> Total execution time: 0.0326
DEBUG - 2016-05-18 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:06:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:06:21 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:06:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:06:21 --> Total execution time: 0.0287
DEBUG - 2016-05-18 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:06:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:06:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:06:34 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:06:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:06:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:06:34 --> Total execution time: 0.0173
DEBUG - 2016-05-18 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:08:54 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:08:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:08:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 11:08:54 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /home/demis/www/platformadiabet/application/views/public/res/header.php 47
DEBUG - 2016-05-18 11:12:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:12:14 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:12:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:12:14 --> Total execution time: 0.0762
DEBUG - 2016-05-18 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:12:40 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:12:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:12:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:12:40 --> Total execution time: 0.0544
DEBUG - 2016-05-18 11:13:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:13:49 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:13:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:13:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 11:13:49 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /home/demis/www/platformadiabet/application/views/public/res/header.php 46
DEBUG - 2016-05-18 11:14:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:14:00 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:14:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:14:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:14:00 --> Total execution time: 0.0089
DEBUG - 2016-05-18 11:14:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:14:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:14:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:14:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:14:20 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:14:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:14:20 --> Total execution time: 0.0092
DEBUG - 2016-05-18 11:17:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:17:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:17:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:17:37 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 11:17:37 --> Could not find the language line "create_user_new"
ERROR - 2016-05-18 11:17:37 --> Could not find the language line "create_user_new_description"
ERROR - 2016-05-18 11:17:37 --> Could not find the language line "create_user_new_register"
DEBUG - 2016-05-18 11:17:37 --> Total execution time: 0.0599
DEBUG - 2016-05-18 11:21:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:21:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:21:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:21:26 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 11:21:26 --> Could not find the language line "create_user_new"
ERROR - 2016-05-18 11:21:26 --> Could not find the language line "create_user_new_description"
ERROR - 2016-05-18 11:21:26 --> Could not find the language line "create_user_new_register"
DEBUG - 2016-05-18 11:21:26 --> Total execution time: 0.0574
DEBUG - 2016-05-18 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:21:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:21:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:21:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:21:35 --> Total execution time: 0.0271
DEBUG - 2016-05-18 11:23:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:23:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:23:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:23:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:23:14 --> Total execution time: 0.0438
DEBUG - 2016-05-18 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:24:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:24:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:24:01 --> Total execution time: 0.0518
DEBUG - 2016-05-18 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 11:30:13 --> 404 Page Not Found: Auth/index2.html
DEBUG - 2016-05-18 11:30:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:30:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:30:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:30:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:30:45 --> Total execution time: 0.0339
DEBUG - 2016-05-18 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:30:47 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:30:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:30:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 11:30:47 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 11:30:47 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 11:30:47 --> Total execution time: 0.0162
DEBUG - 2016-05-18 11:31:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:31:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:31:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:31:32 --> No URI present. Default controller set.
DEBUG - 2016-05-18 11:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:31:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:31:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 11:31:32 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 11:31:32 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 11:31:32 --> Total execution time: 0.0844
DEBUG - 2016-05-18 11:31:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 11:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 11:31:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 11:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 11:31:47 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 11:31:47 --> Could not find the language line "create_user_new"
ERROR - 2016-05-18 11:31:47 --> Could not find the language line "create_user_new_description"
ERROR - 2016-05-18 11:31:47 --> Could not find the language line "create_user_new_register"
DEBUG - 2016-05-18 11:31:47 --> Total execution time: 0.0277
DEBUG - 2016-05-18 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:06:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:06:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 12:06:50 --> Severity: Warning --> Missing argument 1 for CI_Lang::load(), called in /home/demis/www/platformadiabet/application/core/SVS_Controller.php on line 10 and defined /home/demis/www/platformadiabet/system/core/Lang.php 88
ERROR - 2016-05-18 12:06:50 --> Severity: Notice --> Undefined variable: langfile /home/demis/www/platformadiabet/system/core/Lang.php 90
ERROR - 2016-05-18 12:06:50 --> Severity: Notice --> Undefined variable: langfile /home/demis/www/platformadiabet/system/core/Lang.php 100
DEBUG - 2016-05-18 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:08:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:08:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:11:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:11:41 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-18 12:11:41 --> Could not find the language line "create_user_new"
ERROR - 2016-05-18 12:11:41 --> Could not find the language line "create_user_new_description"
ERROR - 2016-05-18 12:11:41 --> Could not find the language line "create_user_new_register"
DEBUG - 2016-05-18 12:11:41 --> Total execution time: 0.0708
DEBUG - 2016-05-18 12:11:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:11:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:11:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:11:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:11:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:11:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:11:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:11:48 --> Total execution time: 0.0323
DEBUG - 2016-05-18 12:12:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:12:06 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:12:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:12:06 --> Total execution time: 0.0598
DEBUG - 2016-05-18 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:13:52 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:13:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:13:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:13:52 --> Total execution time: 0.0690
DEBUG - 2016-05-18 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:14:02 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:14:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:14:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:14:02 --> Total execution time: 0.0341
DEBUG - 2016-05-18 12:17:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:17:32 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:17:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:17:32 --> Total execution time: 0.0430
DEBUG - 2016-05-18 12:17:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:17:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:17:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:17:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:17:39 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:17:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:17:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:18:05 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:18:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:18:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 12:18:05 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 12:18:05 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 12:18:05 --> Total execution time: 0.0271
DEBUG - 2016-05-18 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:18:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:18:10 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:18:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:18:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 12:18:10 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 12:18:10 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 12:18:10 --> Total execution time: 0.0408
DEBUG - 2016-05-18 12:18:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:18:17 --> No URI present. Default controller set.
DEBUG - 2016-05-18 12:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:18:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:18:17 --> Total execution time: 0.0098
DEBUG - 2016-05-18 12:18:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 12:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 12:18:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 12:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:18:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 12:18:31 --> Total execution time: 0.0695
DEBUG - 2016-05-18 13:08:56 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:08:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 13:08:56 --> 404 Page Not Found: Api/crateuser
DEBUG - 2016-05-18 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 13:09:05 --> 404 Page Not Found: Api/createuser
DEBUG - 2016-05-18 13:15:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:15:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:15:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:15:14 --> Severity: Error --> Call to undefined method Api::view() /home/demis/www/platformadiabet/application/controllers/Api.php 23
DEBUG - 2016-05-18 13:15:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:15:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:15:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:17:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:17:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:17:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:17:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:17:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:18:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:18:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:18:01 --> Severity: Warning --> SimpleXMLElement::addChild(): Element name is required /home/demis/www/platformadiabet/application/core/SVS_Controller.php 37
DEBUG - 2016-05-18 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:21:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:21:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:21:25 --> Severity: Error --> Call to undefined function array_to_xml() /home/demis/www/platformadiabet/application/core/SVS_Controller.php 36
DEBUG - 2016-05-18 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:21:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:21:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:21:52 --> Severity: 4096 --> Argument 2 passed to SVS_Controller::array_to_xml() must be an instance of SimpleXMLElement, none given, called in /home/demis/www/platformadiabet/application/core/SVS_Controller.php on line 36 and defined /home/demis/www/platformadiabet/application/core/SVS_Controller.php 63
ERROR - 2016-05-18 13:21:52 --> Severity: Notice --> Undefined variable: xml /home/demis/www/platformadiabet/application/core/SVS_Controller.php 68
ERROR - 2016-05-18 13:21:52 --> Severity: Error --> Call to a member function addChild() on null /home/demis/www/platformadiabet/application/core/SVS_Controller.php 68
DEBUG - 2016-05-18 13:22:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:22:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 13:22:37 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /home/demis/www/platformadiabet/application/core/SVS_Controller.php 37
DEBUG - 2016-05-18 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:22:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:22:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:22:49 --> Severity: error --> Exception: SimpleXMLElement::__construct() expects at least 1 parameter, 0 given /home/demis/www/platformadiabet/application/core/SVS_Controller.php 36
DEBUG - 2016-05-18 13:23:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:23:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:23:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:23:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:23:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:36:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:42:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:42:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:42:48 --> Severity: Error --> Call to undefined method Api::viewXML() /home/demis/www/platformadiabet/application/core/SVS_Controller.php 30
DEBUG - 2016-05-18 13:43:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:43:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:43:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:45:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:45:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 13:46:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:46:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:46:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:46:26 --> Severity: Error --> Call to undefined method Diabet_model::checkToken() /home/demis/www/platformadiabet/application/controllers/Api.php 36
DEBUG - 2016-05-18 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:47:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:47:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:47:09 --> File '404' doesn't exist.
DEBUG - 2016-05-18 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:48:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:48:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:48:13 --> File '404' doesn't exist.
DEBUG - 2016-05-18 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:56:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:56:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:56:45 --> File '404' doesn't exist.
DEBUG - 2016-05-18 13:58:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:58:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:58:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:58:20 --> File '404' doesn't exist.
DEBUG - 2016-05-18 13:58:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:58:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:58:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 13:58:22 --> File '404' doesn't exist.
DEBUG - 2016-05-18 13:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 13:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 13:58:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 13:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:00:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:00:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:00:22 --> Severity: Notice --> Undefined variable: folderLocationres /home/demis/www/platformadiabet/application/core/SVS_Controller.php 63
DEBUG - 2016-05-18 14:00:30 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:00:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:00:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:00:30 --> Severity: Notice --> Undefined variable: page_class /home/demis/www/platformadiabet/application/views/public/res/header.php 22
ERROR - 2016-05-18 14:00:30 --> Severity: Notice --> Undefined variable: languages /home/demis/www/platformadiabet/application/views/public/res/header.php 44
DEBUG - 2016-05-18 14:00:30 --> Total execution time: 0.0452
DEBUG - 2016-05-18 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:01:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:01:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:01:46 --> Severity: Notice --> Undefined variable: page_class /home/demis/www/platformadiabet/application/views/public/res/header.php 22
ERROR - 2016-05-18 14:01:46 --> Severity: Notice --> Undefined variable: languages /home/demis/www/platformadiabet/application/views/public/res/header.php 44
DEBUG - 2016-05-18 14:01:46 --> Total execution time: 0.0434
DEBUG - 2016-05-18 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:02:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:02:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:02:28 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/demis/www/platformadiabet/application/views/public/res/header.php 22
DEBUG - 2016-05-18 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:03:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:03:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:03:01 --> Severity: Notice --> Undefined variable: languages /home/demis/www/platformadiabet/application/views/public/res/header.php 44
DEBUG - 2016-05-18 14:03:01 --> Total execution time: 0.0464
DEBUG - 2016-05-18 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:05:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:05:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:05:05 --> Severity: Notice --> Undefined variable: languages /home/demis/www/platformadiabet/application/views/public/res/header.php 44
DEBUG - 2016-05-18 14:05:05 --> Total execution time: 0.0602
DEBUG - 2016-05-18 14:05:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:05:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:05:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:05:52 --> Total execution time: 0.0544
DEBUG - 2016-05-18 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:05:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:05:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:05:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:05:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:05:57 --> Total execution time: 0.0230
DEBUG - 2016-05-18 14:06:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:06:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:06:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:06:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:06:02 --> Total execution time: 0.0301
DEBUG - 2016-05-18 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:08:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:08:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:08:28 --> Mesaj request invalid
DEBUG - 2016-05-18 14:09:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:09:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:09:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:09:20 --> Mesaj request invalid
DEBUG - 2016-05-18 14:09:20 --> Total execution time: 0.0427
DEBUG - 2016-05-18 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:09:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:09:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:09:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:09:23 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:09:23 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:09:23 --> Mesaj request invalid
ERROR - 2016-05-18 14:09:23 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:09:23 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:09:23 --> Total execution time: 0.0211
DEBUG - 2016-05-18 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:09:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:09:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:09:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:09:26 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:09:26 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:09:26 --> Mesaj request invalid
ERROR - 2016-05-18 14:09:26 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:09:26 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:09:26 --> Total execution time: 0.0339
DEBUG - 2016-05-18 14:10:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:10:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:10:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:10:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:10:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:10:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:10:36 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:10:36 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:10:36 --> Mesaj request invalid
ERROR - 2016-05-18 14:10:36 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:10:36 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:10:36 --> Total execution time: 0.0481
DEBUG - 2016-05-18 14:10:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:10:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:10:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:10:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:10:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:10:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:10:39 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:10:39 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:10:39 --> Mesaj request invalid
ERROR - 2016-05-18 14:10:39 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:10:39 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:10:39 --> Total execution time: 0.0182
DEBUG - 2016-05-18 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:11:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:11:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:11:04 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:11:04 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:11:04 --> Mesaj request invalid
ERROR - 2016-05-18 14:11:04 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:11:04 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:11:04 --> Total execution time: 0.0487
DEBUG - 2016-05-18 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:12:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:12:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:12:27 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:12:27 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:12:27 --> Mesaj request invalid
ERROR - 2016-05-18 14:12:27 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:12:27 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:12:27 --> Total execution time: 0.0380
DEBUG - 2016-05-18 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:12:37 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:12:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:12:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:12:37 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:12:37 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:12:37 --> Total execution time: 0.0323
DEBUG - 2016-05-18 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:12:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:12:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:12:42 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:12:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:12:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:12:42 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:12:42 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:12:42 --> Total execution time: 0.0136
DEBUG - 2016-05-18 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:12:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:12:47 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:12:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:12:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:12:47 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:12:47 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:12:47 --> Total execution time: 0.0224
DEBUG - 2016-05-18 14:12:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:12:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:12:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:12:51 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:12:51 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:12:51 --> Mesaj request invalid
ERROR - 2016-05-18 14:12:51 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:12:51 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:12:51 --> Total execution time: 0.0323
DEBUG - 2016-05-18 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:13:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:13:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:13:45 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:13:45 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:13:45 --> Mesaj request invalid
ERROR - 2016-05-18 14:13:45 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:13:45 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:13:45 --> Total execution time: 0.0514
DEBUG - 2016-05-18 14:13:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:13:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:13:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:13:53 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:13:53 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:13:53 --> Mesaj request invalid
ERROR - 2016-05-18 14:13:53 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:13:53 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:13:53 --> Total execution time: 0.0394
DEBUG - 2016-05-18 14:14:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:14:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:14:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:14:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:14:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:14:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:14:34 --> Mesaj request invalid
DEBUG - 2016-05-18 14:14:34 --> Total execution time: 0.0402
DEBUG - 2016-05-18 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:14:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:14:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:14:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:14:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:14:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:14:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:15:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:15:07 --> File '404' doesn't exist.
ERROR - 2016-05-18 14:15:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-18 14:15:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-18 14:15:07 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 14:15:07 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 14:15:07 --> 
ERROR - 2016-05-18 14:15:07 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:15:07 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:15:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:15:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:15:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:16 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:15:16 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:15:16 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:15:16 --> Total execution time: 0.0313
DEBUG - 2016-05-18 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:15:19 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:15:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:15:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:15:19 --> Could not find the language line "login_heading"
ERROR - 2016-05-18 14:15:19 --> Could not find the language line "create_user_heading"
DEBUG - 2016-05-18 14:15:19 --> Total execution time: 0.0306
DEBUG - 2016-05-18 14:16:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:16:17 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:16:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:16:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:16:17 --> Total execution time: 0.0712
DEBUG - 2016-05-18 14:19:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:19:18 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:19:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:19:18 --> Total execution time: 0.0573
DEBUG - 2016-05-18 14:19:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:19:23 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:19:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:19:23 --> Total execution time: 0.0453
DEBUG - 2016-05-18 14:20:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:20:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:20:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:20:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:20:31 --> Total execution time: 0.0493
DEBUG - 2016-05-18 14:21:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:21:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:21:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:21:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:21:03 --> Total execution time: 0.0564
DEBUG - 2016-05-18 14:21:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:21:05 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:21:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:21:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:21:05 --> Total execution time: 0.0732
DEBUG - 2016-05-18 14:21:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:21:15 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:21:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:21:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:21:16 --> Total execution time: 0.0587
DEBUG - 2016-05-18 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:21:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:21:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:21:20 --> Total execution time: 0.0593
DEBUG - 2016-05-18 14:21:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:21:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:23:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:23:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:23:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:26:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:26:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:26:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:26:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:26:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:26:11 --> Mesaj token invalid
DEBUG - 2016-05-18 14:35:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:35:37 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:35:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:37 --> Total execution time: 0.0665
DEBUG - 2016-05-18 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:35:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:39 --> Total execution time: 0.0118
DEBUG - 2016-05-18 14:35:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:35:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:35:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:35:52 --> No URI present. Default controller set.
DEBUG - 2016-05-18 14:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:35:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:35:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:35:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:53 --> Total execution time: 0.0359
DEBUG - 2016-05-18 14:35:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 14:35:57 --> 404 Page Not Found: Auth/edit
DEBUG - 2016-05-18 14:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:35:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:35:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:35:59 --> Total execution time: 0.0621
DEBUG - 2016-05-18 14:36:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:36:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:36:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:36:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:36:01 --> Total execution time: 0.0376
DEBUG - 2016-05-18 14:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:36:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:36:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:36:05 --> Total execution time: 0.0261
DEBUG - 2016-05-18 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:41:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:41:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:41:09 --> Total execution time: 0.0976
DEBUG - 2016-05-18 14:41:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:41:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:41:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:41:11 --> Severity: Notice --> Undefined property: Diabet::$diabet_model /home/demis/www/platformadiabet/application/controllers/Diabet.php 23
ERROR - 2016-05-18 14:41:11 --> Severity: Error --> Call to a member function getTokens() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 23
DEBUG - 2016-05-18 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:41:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:41:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:41:37 --> Severity: Notice --> Undefined property: Diabet::$diabet_model /home/demis/www/platformadiabet/application/controllers/Diabet.php 24
ERROR - 2016-05-18 14:41:37 --> Severity: Error --> Call to a member function getTokens() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 24
DEBUG - 2016-05-18 14:42:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:42:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:42:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:42:06 --> Severity: Error --> Call to undefined method Diabet_model::getTokens() /home/demis/www/platformadiabet/application/controllers/Diabet.php 24
DEBUG - 2016-05-18 14:51:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:51:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:51:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:51:12 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/models/Diabet_model.php 73
DEBUG - 2016-05-18 14:51:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:51:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:51:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:51:22 --> Severity: Warning --> Missing argument 1 for Diabet_model::getTokens(), called in /home/demis/www/platformadiabet/application/controllers/Diabet.php on line 24 and defined /home/demis/www/platformadiabet/application/models/Diabet_model.php 43
ERROR - 2016-05-18 14:51:22 --> Severity: Warning --> Missing argument 2 for Diabet_model::getTokens(), called in /home/demis/www/platformadiabet/application/controllers/Diabet.php on line 24 and defined /home/demis/www/platformadiabet/application/models/Diabet_model.php 43
ERROR - 2016-05-18 14:51:22 --> Severity: Notice --> Undefined variable: limit /home/demis/www/platformadiabet/application/models/Diabet_model.php 65
ERROR - 2016-05-18 14:51:22 --> Severity: Notice --> Undefined variable: offset /home/demis/www/platformadiabet/application/models/Diabet_model.php 66
ERROR - 2016-05-18 14:51:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 10 - Invalid query: 
			SELECT
				`fk_user`,
				`name`,
				`email`,
				`type`
			FROM
				`tokens`
			WHERE
				`token` = '?'
			LIMIT , 
			
DEBUG - 2016-05-18 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:51:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:51:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:51:35 --> Total execution time: 0.0593
DEBUG - 2016-05-18 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:51:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:51:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:51:39 --> Total execution time: 0.0584
DEBUG - 2016-05-18 14:52:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:52:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:52:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Undefined property: mysqli::$token /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Undefined property: mysqli_result::$token /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:52:53 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
DEBUG - 2016-05-18 14:52:53 --> Total execution time: 0.0616
DEBUG - 2016-05-18 14:53:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:53:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:53:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:53:09 --> Severity: Error --> Call to undefined method mysqli::row() /home/demis/www/platformadiabet/application/views/user_area/access.php 15
DEBUG - 2016-05-18 14:53:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:53:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:53:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:53:16 --> Severity: Error --> Call to undefined method mysqli::fetch() /home/demis/www/platformadiabet/application/views/user_area/access.php 15
DEBUG - 2016-05-18 14:54:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:54:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:54:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:54:26 --> Total execution time: 0.0816
DEBUG - 2016-05-18 14:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:54:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:54:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:54:43 --> Total execution time: 0.0608
DEBUG - 2016-05-18 14:56:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:56:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:56:43 --> Total execution time: 0.0720
DEBUG - 2016-05-18 14:56:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:56:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:56:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:56:44 --> Total execution time: 0.0234
DEBUG - 2016-05-18 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:57:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:57:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:57:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:57:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:57:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:57:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:57:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:57:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:57:34 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/views/user_area/access.php 15
DEBUG - 2016-05-18 14:57:34 --> Total execution time: 0.0351
DEBUG - 2016-05-18 14:58:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:58:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:58:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:58:03 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
ERROR - 2016-05-18 14:58:03 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 15
DEBUG - 2016-05-18 14:58:03 --> Total execution time: 0.0536
DEBUG - 2016-05-18 14:58:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:58:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:58:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 14:58:08 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 16
ERROR - 2016-05-18 14:58:08 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 16
DEBUG - 2016-05-18 14:58:08 --> Total execution time: 0.0234
DEBUG - 2016-05-18 14:58:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:58:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:58:22 --> Total execution time: 0.0489
DEBUG - 2016-05-18 14:58:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:58:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:59:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:59:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:59:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:59:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:59:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:59:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:59:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 14:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 14:59:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 14:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:00:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:00:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:00:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:00:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:00:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:00:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:00:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:00:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:00:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:00:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:00:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:01:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:01:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:01:09 --> Query error: Unknown column 'fk2_user' in 'field list' - Invalid query: 
			SELECT
				`fk2_user`,
				`name`,
				`email`,
				`type`
			FROM
				`tokens`
			WHERE
				`fk_user` = '2'
			LIMIT 30, 0
			
DEBUG - 2016-05-18 15:01:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:01:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:01:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:01:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:01:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:01:43 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/access.php 16
DEBUG - 2016-05-18 15:01:43 --> Total execution time: 0.0574
DEBUG - 2016-05-18 15:02:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:02:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:02:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:02:01 --> Severity: Notice --> Undefined index: token /home/demis/www/platformadiabet/application/views/user_area/access.php 16
DEBUG - 2016-05-18 15:02:02 --> Total execution time: 0.0450
DEBUG - 2016-05-18 15:02:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:02:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:02:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:02:17 --> Total execution time: 0.0167
DEBUG - 2016-05-18 15:02:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:02:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:02:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:02:55 --> Total execution time: 0.0516
DEBUG - 2016-05-18 15:03:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:03:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:03:02 --> Total execution time: 0.0328
DEBUG - 2016-05-18 15:26:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:26:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:26:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:26:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:27:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:28:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:28:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:28:08 --> Query error: Table 'diabetplatform.use2rs' doesn't exist - Invalid query: 
			SELECT 
				`id`
			FROM 
				`use2rs`
			WHERE 
				`apikey` = '?'
			LIMIT 1
		
DEBUG - 2016-05-18 15:28:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:28:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:28:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:28:23 --> Query error: Table 'diabetplatform.use2rs' doesn't exist - Invalid query: 
			SELECT 
				`id`
			FROM 
				`use2rs`
			WHERE 
				`apikey` = 'kUrP19eTWsacVXCSRnmpj2Q6bhifY0A3'
			LIMIT 1
		
DEBUG - 2016-05-18 15:28:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:28:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:28:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:28:26 --> Query error: Unknown column '_is_active' in 'where clause' - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = '2'
			AND
				`_is_active` = 1
			
DEBUG - 2016-05-18 15:29:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:29:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:29:39 --> Total execution time: 0.0541
DEBUG - 2016-05-18 15:29:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:29:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:29:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:29:40 --> Total execution time: 0.0470
DEBUG - 2016-05-18 15:32:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:32:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 15:32:04 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) /home/demis/www/platformadiabet/application/controllers/Api.php 8
DEBUG - 2016-05-18 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 15:32:16 --> Severity: Parsing Error --> syntax error, unexpected '$outputFormat' (T_VARIABLE), expecting function (T_FUNCTION) /home/demis/www/platformadiabet/application/controllers/Api.php 8
DEBUG - 2016-05-18 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:32:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 15:32:26 --> Severity: Parsing Error --> syntax error, unexpected 'outputFormat' (T_STRING), expecting function (T_FUNCTION) /home/demis/www/platformadiabet/application/controllers/Api.php 8
DEBUG - 2016-05-18 15:33:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:33:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:33:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:33:05 --> Severity: Notice --> Undefined variable: tokenList /home/demis/www/platformadiabet/application/views/user_area/access.php 14
ERROR - 2016-05-18 15:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/demis/www/platformadiabet/application/views/user_area/access.php 14
DEBUG - 2016-05-18 15:33:05 --> Total execution time: 0.0813
DEBUG - 2016-05-18 15:33:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:33:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:42:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:42:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:42:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:42:37 --> Severity: Error --> Call to undefined method Api::initializeApiCall() /home/demis/www/platformadiabet/application/controllers/Api.php 16
DEBUG - 2016-05-18 15:42:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 15:42:46 --> 404 Page Not Found: Diabet/getTokens
DEBUG - 2016-05-18 15:43:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:43:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:43:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:43:20 --> Severity: Notice --> Undefined property: Diabet::$Diabet_model /home/demis/www/platformadiabet/application/controllers/Diabet.php 42
ERROR - 2016-05-18 15:43:20 --> Severity: Error --> Call to a member function checkApi() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 42
DEBUG - 2016-05-18 15:43:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:43:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:43:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:43:58 --> Severity: Error --> Call to undefined method Diabet::initializeStandardCall() /home/demis/www/platformadiabet/application/controllers/Diabet.php 20
DEBUG - 2016-05-18 15:44:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:44:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:44:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:44:09 --> Severity: Notice --> Constant USER_ID already defined /home/demis/www/platformadiabet/application/controllers/Diabet.php 80
DEBUG - 2016-05-18 15:44:09 --> Total execution time: 0.0389
DEBUG - 2016-05-18 15:45:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:45:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:45:12 --> Total execution time: 0.0571
DEBUG - 2016-05-18 15:45:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:45:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:45:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:45:16 --> Total execution time: 0.0423
DEBUG - 2016-05-18 15:45:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:45:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:45:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:45:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:45:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:45:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:45:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:46:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:46:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:46:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:46:00 --> Total execution time: 0.0414
DEBUG - 2016-05-18 15:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 15:47:25 --> 404 Page Not Found: Api/getT_tokens
DEBUG - 2016-05-18 15:47:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:47:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:47:28 --> Total execution time: 0.0640
DEBUG - 2016-05-18 15:47:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:47:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:47:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:48:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:48:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:48:58 --> Mesaj token invalid
DEBUG - 2016-05-18 15:49:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:49:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:49:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:49:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:49:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:49:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:50:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:50:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:51:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:51:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 15:51:42 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 40
DEBUG - 2016-05-18 15:51:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:51:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:51:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:51:51 --> Mesaj token invalid
DEBUG - 2016-05-18 15:52:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:52:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:52:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:52:37 --> Mesaj token invalid
DEBUG - 2016-05-18 15:53:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:53:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:53:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:53:14 --> Mesaj token invalid
DEBUG - 2016-05-18 15:53:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:53:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:53:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:53:46 --> Mesaj token invalid
DEBUG - 2016-05-18 15:53:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:53:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:53:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:53:47 --> Mesaj token invalid
DEBUG - 2016-05-18 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:54:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:54:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:54:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:54:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 15:55:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:55:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:55:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:55:24 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:20 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:21 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:21 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:42 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:47 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:48 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:54 --> Mesaj token invalid
DEBUG - 2016-05-18 15:56:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:56:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:56:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:56:55 --> Mesaj token invalid
DEBUG - 2016-05-18 15:57:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:57:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:57:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:57:08 --> Mesaj token invalid
DEBUG - 2016-05-18 15:57:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:57:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:57:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:57:15 --> Mesaj token invalid
DEBUG - 2016-05-18 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:57:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:57:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:57:16 --> Mesaj token invalid
DEBUG - 2016-05-18 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:57:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:57:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:57:27 --> Mesaj token invalid
DEBUG - 2016-05-18 15:57:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:57:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:57:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:57:38 --> Mesaj token invalid
DEBUG - 2016-05-18 15:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:57:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:57:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:57:43 --> Mesaj token invalid
DEBUG - 2016-05-18 15:57:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:57:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:57:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:57:52 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:18 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:30 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:30 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:31 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:31 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:31 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:31 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:31 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:44 --> Mesaj token invalid
DEBUG - 2016-05-18 15:58:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:58:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:58:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:58:45 --> Mesaj token invalid
DEBUG - 2016-05-18 15:59:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:59:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:59:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:59:08 --> Mesaj token invalid
DEBUG - 2016-05-18 15:59:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:59:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:59:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:59:09 --> Mesaj token invalid
DEBUG - 2016-05-18 15:59:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:59:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:59:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:59:12 --> Mesaj token invalid
DEBUG - 2016-05-18 15:59:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 15:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 15:59:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 15:59:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 15:59:45 --> Mesaj token invalid
DEBUG - 2016-05-18 16:00:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:00:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:00:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:00:00 --> Mesaj token invalid
DEBUG - 2016-05-18 16:00:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:00:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:00:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:00:00 --> Mesaj token invalid
DEBUG - 2016-05-18 16:00:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:00:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:00:40 --> Total execution time: 0.0729
DEBUG - 2016-05-18 16:01:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:01:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:01:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:01:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:01:15 --> Mesaj token invalid
ERROR - 2016-05-18 16:01:15 --> Mesaj nu are access
DEBUG - 2016-05-18 16:01:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:01:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:01:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:01:27 --> Mesaj token invalid
DEBUG - 2016-05-18 16:02:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:02:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:02:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:02:12 --> Mesaj token invalid
ERROR - 2016-05-18 16:02:12 --> Mesaj nu are access
DEBUG - 2016-05-18 16:02:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:02:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:02:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:02:32 --> Mesaj token invalid
DEBUG - 2016-05-18 16:02:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:02:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:02:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:02:46 --> Mesaj token invalid
DEBUG - 2016-05-18 16:03:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 16:03:45 --> 404 Page Not Found: Diabet/aceesw
DEBUG - 2016-05-18 16:03:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 16:03:48 --> 404 Page Not Found: Diabet/acees
DEBUG - 2016-05-18 16:03:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:03:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:03:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:03:53 --> Mesaj token invalid
DEBUG - 2016-05-18 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:04:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:04:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:04:06 --> Mesaj token invalid
DEBUG - 2016-05-18 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:05:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:05:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:05:39 --> Mesaj token invalid
DEBUG - 2016-05-18 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:06:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:06:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:06:34 --> Mesaj token invalid
DEBUG - 2016-05-18 16:06:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:06:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:06:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:06:40 --> Mesaj token invalid
DEBUG - 2016-05-18 16:07:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:07:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:07:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:07:35 --> Mesaj nu are access
DEBUG - 2016-05-18 16:08:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:08:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:08:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:08:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:08:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:08:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:08:35 --> Severity: Notice --> Undefined variable: checkToken /home/demis/www/platformadiabet/application/controllers/Diabet.php 71
ERROR - 2016-05-18 16:08:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?
			AND
				`_is_active` = 1' at line 6 - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_is_active` = 1
			
DEBUG - 2016-05-18 16:08:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:08:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:08:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:08:50 --> Total execution time: 0.0456
DEBUG - 2016-05-18 16:10:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:10:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:10:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:10:55 --> Mesaj nu are access
DEBUG - 2016-05-18 16:11:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:11:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:11:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:11:04 --> Mesaj nu are access
DEBUG - 2016-05-18 16:11:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:11:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:11:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:11:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:11:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:11:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:11:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:11:39 --> Mesaj nu are access
DEBUG - 2016-05-18 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:11:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:11:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:11:43 --> Mesaj nu are access
DEBUG - 2016-05-18 16:11:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:11:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:11:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:11:57 --> Mesaj nu are access
DEBUG - 2016-05-18 16:13:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:13:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:13:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:13:50 --> Mesaj nu are access
DEBUG - 2016-05-18 16:15:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:15:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:15:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:15:03 --> Mesaj nu are access
DEBUG - 2016-05-18 16:15:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:15:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:15:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:15:03 --> Mesaj nu are access
DEBUG - 2016-05-18 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:15:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:15:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:15:28 --> Mesaj nu are access
ERROR - 2016-05-18 16:15:28 --> Severity: Notice --> Undefined variable: folderLocation /home/demis/www/platformadiabet/application/core/SVS_Controller.php 57
DEBUG - 2016-05-18 16:15:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-18 16:15:47 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/demis/www/platformadiabet/application/core/SVS_Controller.php 42
DEBUG - 2016-05-18 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:15:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:15:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:15:57 --> Mesaj nu are access
DEBUG - 2016-05-18 16:16:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:16:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:16:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:16:33 --> Mesaj nu are access
DEBUG - 2016-05-18 16:18:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:18:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:18:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:18:02 --> Test
ERROR - 2016-05-18 16:18:02 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 54
ERROR - 2016-05-18 16:18:02 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 73
DEBUG - 2016-05-18 16:18:02 --> Total execution time: 0.0365
DEBUG - 2016-05-18 16:18:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:18:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:18:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:18:10 --> Test
DEBUG - 2016-05-18 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:18:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:18:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:18:44 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/core/SVS_Controller.php 57
ERROR - 2016-05-18 16:18:44 --> Severity: Notice --> Undefined variable: page_title /home/demis/www/platformadiabet/application/views/user_area/res/header.php 6
ERROR - 2016-05-18 16:18:44 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/core/SVS_Controller.php 58
ERROR - 2016-05-18 16:18:44 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:18:44 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
ERROR - 2016-05-18 16:18:44 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/core/SVS_Controller.php 59
DEBUG - 2016-05-18 16:18:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:18:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:18:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:18:52 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:18:52 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
DEBUG - 2016-05-18 16:19:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:19:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:19:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:19:21 --> Mesaj nu are access
DEBUG - 2016-05-18 16:19:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:19:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:19:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:19:23 --> Mesaj nu are access
DEBUG - 2016-05-18 16:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:19:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:19:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:19:45 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 16:19:45 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 16:19:45 --> Mesaj nu are access
DEBUG - 2016-05-18 16:25:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:25:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:25:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:25:34 --> test
DEBUG - 2016-05-18 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:25:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:25:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:25:44 --> test
DEBUG - 2016-05-18 16:25:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:25:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:25:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:26:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:26:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:26:35 --> test
DEBUG - 2016-05-18 16:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:26:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:26:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:26:50 --> test
DEBUG - 2016-05-18 16:26:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:26:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:26:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-18 16:26:55 --> Total execution time: 0.0238
DEBUG - 2016-05-18 16:27:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:27:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:27:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:27:09 --> Could not find the language line "error_general_title"
ERROR - 2016-05-18 16:27:09 --> Could not find the language line "error_page_title"
ERROR - 2016-05-18 16:27:09 --> test
DEBUG - 2016-05-18 16:27:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:27:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:27:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:27:29 --> test
DEBUG - 2016-05-18 16:27:29 --> Total execution time: 0.0441
DEBUG - 2016-05-18 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:27:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:27:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:27:53 --> test
DEBUG - 2016-05-18 16:28:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:28:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:28:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:28:04 --> test
DEBUG - 2016-05-18 16:28:04 --> Total execution time: 0.0456
DEBUG - 2016-05-18 16:28:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:28:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:28:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:28:54 --> test
DEBUG - 2016-05-18 16:28:54 --> Total execution time: 0.0537
DEBUG - 2016-05-18 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:29:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:29:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:29:02 --> test
DEBUG - 2016-05-18 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:29:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:29:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:29:33 --> test
DEBUG - 2016-05-18 16:29:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:29:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:29:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:29:44 --> test
DEBUG - 2016-05-18 16:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:31:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:31:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:31:35 --> test
DEBUG - 2016-05-18 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:31:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:31:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:31:37 --> test
DEBUG - 2016-05-18 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:31:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:31:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:31:37 --> test
DEBUG - 2016-05-18 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:31:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:31:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:31:37 --> test
DEBUG - 2016-05-18 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:31:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:31:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:31:38 --> test
DEBUG - 2016-05-18 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-18 16:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-18 16:31:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-18 16:31:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-18 16:31:38 --> test
INFO - 2016-05-18 16:32:06 --> Config Class Initialized
INFO - 2016-05-18 16:32:06 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:32:06 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:32:06 --> Utf8 Class Initialized
INFO - 2016-05-18 16:32:06 --> URI Class Initialized
INFO - 2016-05-18 16:32:06 --> Router Class Initialized
INFO - 2016-05-18 16:32:06 --> Output Class Initialized
INFO - 2016-05-18 16:32:06 --> Security Class Initialized
DEBUG - 2016-05-18 16:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:32:06 --> CSRF cookie sent
INFO - 2016-05-18 16:32:06 --> Input Class Initialized
INFO - 2016-05-18 16:32:06 --> Language Class Initialized
INFO - 2016-05-18 16:32:06 --> Loader Class Initialized
INFO - 2016-05-18 16:32:06 --> Helper loaded: form_helper
INFO - 2016-05-18 16:32:06 --> Database Driver Class Initialized
INFO - 2016-05-18 16:32:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:32:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:32:06 --> Email Class Initialized
INFO - 2016-05-18 16:32:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:32:06 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:32:06 --> Helper loaded: language_helper
INFO - 2016-05-18 16:32:06 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:32:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:32:06 --> Model Class Initialized
INFO - 2016-05-18 16:32:06 --> Helper loaded: date_helper
INFO - 2016-05-18 16:32:06 --> Controller Class Initialized
INFO - 2016-05-18 16:32:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:32:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:32:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:32:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:32:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:32:06 --> Model Class Initialized
INFO - 2016-05-18 16:32:06 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:32:06 --> test
INFO - 2016-05-18 16:32:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area//res/header.php
INFO - 2016-05-18 16:32:06 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:32:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area//res/footer.php
INFO - 2016-05-18 16:32:51 --> Config Class Initialized
INFO - 2016-05-18 16:32:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:32:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:32:51 --> Utf8 Class Initialized
INFO - 2016-05-18 16:32:51 --> URI Class Initialized
INFO - 2016-05-18 16:32:51 --> Router Class Initialized
INFO - 2016-05-18 16:32:51 --> Output Class Initialized
INFO - 2016-05-18 16:32:51 --> Security Class Initialized
DEBUG - 2016-05-18 16:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:32:51 --> CSRF cookie sent
INFO - 2016-05-18 16:32:51 --> Input Class Initialized
INFO - 2016-05-18 16:32:51 --> Language Class Initialized
INFO - 2016-05-18 16:32:51 --> Loader Class Initialized
INFO - 2016-05-18 16:32:51 --> Helper loaded: form_helper
INFO - 2016-05-18 16:32:51 --> Database Driver Class Initialized
INFO - 2016-05-18 16:32:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:32:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:32:51 --> Email Class Initialized
INFO - 2016-05-18 16:32:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:32:51 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:32:51 --> Helper loaded: language_helper
INFO - 2016-05-18 16:32:51 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:32:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:32:51 --> Model Class Initialized
INFO - 2016-05-18 16:32:51 --> Helper loaded: date_helper
INFO - 2016-05-18 16:32:51 --> Controller Class Initialized
INFO - 2016-05-18 16:32:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:32:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:32:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:32:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:32:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:32:51 --> Model Class Initialized
INFO - 2016-05-18 16:32:51 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:32:51 --> test
INFO - 2016-05-18 16:32:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:32:51 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:32:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:32:52 --> Config Class Initialized
INFO - 2016-05-18 16:32:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:32:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:32:52 --> Utf8 Class Initialized
INFO - 2016-05-18 16:32:52 --> URI Class Initialized
INFO - 2016-05-18 16:32:52 --> Router Class Initialized
INFO - 2016-05-18 16:32:52 --> Output Class Initialized
INFO - 2016-05-18 16:32:52 --> Security Class Initialized
DEBUG - 2016-05-18 16:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:32:52 --> CSRF cookie sent
INFO - 2016-05-18 16:32:52 --> Input Class Initialized
INFO - 2016-05-18 16:32:52 --> Language Class Initialized
INFO - 2016-05-18 16:32:52 --> Loader Class Initialized
INFO - 2016-05-18 16:32:52 --> Helper loaded: form_helper
INFO - 2016-05-18 16:32:52 --> Database Driver Class Initialized
INFO - 2016-05-18 16:32:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:32:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:32:52 --> Email Class Initialized
INFO - 2016-05-18 16:32:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:32:52 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:32:52 --> Helper loaded: language_helper
INFO - 2016-05-18 16:32:52 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:32:52 --> Model Class Initialized
INFO - 2016-05-18 16:32:52 --> Helper loaded: date_helper
INFO - 2016-05-18 16:32:52 --> Controller Class Initialized
INFO - 2016-05-18 16:32:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:32:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:32:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:32:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:32:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:32:52 --> Model Class Initialized
INFO - 2016-05-18 16:32:52 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:32:52 --> test
INFO - 2016-05-18 16:32:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:32:52 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:32:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:39:28 --> Config Class Initialized
INFO - 2016-05-18 16:39:28 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:39:28 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:39:28 --> Utf8 Class Initialized
INFO - 2016-05-18 16:39:28 --> URI Class Initialized
INFO - 2016-05-18 16:39:28 --> Router Class Initialized
INFO - 2016-05-18 16:39:28 --> Output Class Initialized
INFO - 2016-05-18 16:39:28 --> Security Class Initialized
DEBUG - 2016-05-18 16:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:39:28 --> CSRF cookie sent
INFO - 2016-05-18 16:39:28 --> Input Class Initialized
INFO - 2016-05-18 16:39:28 --> Language Class Initialized
INFO - 2016-05-18 16:39:28 --> Loader Class Initialized
INFO - 2016-05-18 16:39:28 --> Helper loaded: form_helper
INFO - 2016-05-18 16:39:28 --> Database Driver Class Initialized
INFO - 2016-05-18 16:39:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:39:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:39:28 --> Email Class Initialized
INFO - 2016-05-18 16:39:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:39:28 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:39:28 --> Helper loaded: language_helper
INFO - 2016-05-18 16:39:28 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:39:28 --> Model Class Initialized
INFO - 2016-05-18 16:39:28 --> Helper loaded: date_helper
INFO - 2016-05-18 16:39:28 --> Controller Class Initialized
INFO - 2016-05-18 16:39:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:39:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:39:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:39:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:39:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:39:28 --> Model Class Initialized
INFO - 2016-05-18 16:39:28 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:39:28 --> test
INFO - 2016-05-18 16:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:39:29 --> Config Class Initialized
INFO - 2016-05-18 16:39:29 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:39:29 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:39:29 --> Utf8 Class Initialized
INFO - 2016-05-18 16:39:29 --> URI Class Initialized
INFO - 2016-05-18 16:39:29 --> Router Class Initialized
INFO - 2016-05-18 16:39:29 --> Output Class Initialized
INFO - 2016-05-18 16:39:29 --> Security Class Initialized
DEBUG - 2016-05-18 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:39:29 --> CSRF cookie sent
INFO - 2016-05-18 16:39:29 --> Input Class Initialized
INFO - 2016-05-18 16:39:29 --> Language Class Initialized
INFO - 2016-05-18 16:39:29 --> Loader Class Initialized
INFO - 2016-05-18 16:39:29 --> Helper loaded: form_helper
INFO - 2016-05-18 16:39:29 --> Database Driver Class Initialized
INFO - 2016-05-18 16:39:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:39:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:39:29 --> Email Class Initialized
INFO - 2016-05-18 16:39:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:39:29 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:39:29 --> Helper loaded: language_helper
INFO - 2016-05-18 16:39:29 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:39:29 --> Model Class Initialized
INFO - 2016-05-18 16:39:29 --> Helper loaded: date_helper
INFO - 2016-05-18 16:39:29 --> Controller Class Initialized
INFO - 2016-05-18 16:39:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:39:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:39:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:39:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:39:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:39:29 --> Model Class Initialized
INFO - 2016-05-18 16:39:29 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:39:29 --> test
INFO - 2016-05-18 16:39:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:39:29 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:39:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:39:36 --> Config Class Initialized
INFO - 2016-05-18 16:39:36 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:39:36 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:39:36 --> Utf8 Class Initialized
INFO - 2016-05-18 16:39:36 --> URI Class Initialized
INFO - 2016-05-18 16:39:36 --> Router Class Initialized
INFO - 2016-05-18 16:39:36 --> Output Class Initialized
INFO - 2016-05-18 16:39:36 --> Security Class Initialized
DEBUG - 2016-05-18 16:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:39:36 --> CSRF cookie sent
INFO - 2016-05-18 16:39:36 --> Input Class Initialized
INFO - 2016-05-18 16:39:36 --> Language Class Initialized
INFO - 2016-05-18 16:39:36 --> Loader Class Initialized
INFO - 2016-05-18 16:39:36 --> Helper loaded: form_helper
INFO - 2016-05-18 16:39:36 --> Database Driver Class Initialized
INFO - 2016-05-18 16:39:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:39:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:39:36 --> Email Class Initialized
INFO - 2016-05-18 16:39:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:39:36 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:39:36 --> Helper loaded: language_helper
INFO - 2016-05-18 16:39:36 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:39:36 --> Model Class Initialized
INFO - 2016-05-18 16:39:36 --> Helper loaded: date_helper
INFO - 2016-05-18 16:39:36 --> Controller Class Initialized
INFO - 2016-05-18 16:39:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:39:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:39:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:39:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:39:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:39:36 --> Model Class Initialized
INFO - 2016-05-18 16:39:36 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:39:36 --> test
INFO - 2016-05-18 16:39:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:41:55 --> Config Class Initialized
INFO - 2016-05-18 16:41:55 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:41:55 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:41:55 --> Utf8 Class Initialized
INFO - 2016-05-18 16:41:55 --> URI Class Initialized
INFO - 2016-05-18 16:41:55 --> Router Class Initialized
INFO - 2016-05-18 16:41:55 --> Output Class Initialized
INFO - 2016-05-18 16:41:55 --> Security Class Initialized
DEBUG - 2016-05-18 16:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:41:55 --> CSRF cookie sent
INFO - 2016-05-18 16:41:55 --> Input Class Initialized
INFO - 2016-05-18 16:41:55 --> Language Class Initialized
INFO - 2016-05-18 16:41:55 --> Loader Class Initialized
INFO - 2016-05-18 16:41:55 --> Helper loaded: form_helper
INFO - 2016-05-18 16:41:55 --> Database Driver Class Initialized
INFO - 2016-05-18 16:41:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:41:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:41:55 --> Email Class Initialized
INFO - 2016-05-18 16:41:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:41:55 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:41:55 --> Helper loaded: language_helper
INFO - 2016-05-18 16:41:55 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:41:55 --> Model Class Initialized
INFO - 2016-05-18 16:41:55 --> Helper loaded: date_helper
INFO - 2016-05-18 16:41:55 --> Controller Class Initialized
INFO - 2016-05-18 16:41:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:41:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:41:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:41:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:41:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:41:55 --> Model Class Initialized
INFO - 2016-05-18 16:41:55 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:41:55 --> test
INFO - 2016-05-18 16:41:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:41:55 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:41:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:42:08 --> Config Class Initialized
INFO - 2016-05-18 16:42:08 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:08 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:08 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:08 --> URI Class Initialized
INFO - 2016-05-18 16:42:08 --> Router Class Initialized
INFO - 2016-05-18 16:42:08 --> Output Class Initialized
INFO - 2016-05-18 16:42:08 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:08 --> CSRF cookie sent
INFO - 2016-05-18 16:42:08 --> Input Class Initialized
INFO - 2016-05-18 16:42:08 --> Language Class Initialized
INFO - 2016-05-18 16:42:08 --> Loader Class Initialized
INFO - 2016-05-18 16:42:08 --> Helper loaded: form_helper
INFO - 2016-05-18 16:42:08 --> Database Driver Class Initialized
INFO - 2016-05-18 16:42:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:42:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:42:08 --> Email Class Initialized
INFO - 2016-05-18 16:42:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:42:08 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:42:08 --> Helper loaded: language_helper
INFO - 2016-05-18 16:42:08 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:42:08 --> Model Class Initialized
INFO - 2016-05-18 16:42:08 --> Helper loaded: date_helper
INFO - 2016-05-18 16:42:08 --> Controller Class Initialized
INFO - 2016-05-18 16:42:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:42:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:42:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:42:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:42:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:42:08 --> Model Class Initialized
INFO - 2016-05-18 16:42:08 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:42:08 --> test
INFO - 2016-05-18 16:42:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:42:08 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:42:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:42:22 --> Config Class Initialized
INFO - 2016-05-18 16:42:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:22 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:22 --> URI Class Initialized
INFO - 2016-05-18 16:42:22 --> Router Class Initialized
INFO - 2016-05-18 16:42:22 --> Output Class Initialized
INFO - 2016-05-18 16:42:22 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:22 --> CSRF cookie sent
INFO - 2016-05-18 16:42:22 --> Input Class Initialized
INFO - 2016-05-18 16:42:22 --> Language Class Initialized
ERROR - 2016-05-18 16:42:22 --> 404 Page Not Found: Api/gettokens
INFO - 2016-05-18 16:42:29 --> Config Class Initialized
INFO - 2016-05-18 16:42:29 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:29 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:29 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:29 --> URI Class Initialized
INFO - 2016-05-18 16:42:29 --> Router Class Initialized
INFO - 2016-05-18 16:42:29 --> Output Class Initialized
INFO - 2016-05-18 16:42:29 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:29 --> CSRF cookie sent
INFO - 2016-05-18 16:42:29 --> Input Class Initialized
INFO - 2016-05-18 16:42:29 --> Language Class Initialized
ERROR - 2016-05-18 16:42:29 --> 404 Page Not Found: Api/getTokens
INFO - 2016-05-18 16:42:33 --> Config Class Initialized
INFO - 2016-05-18 16:42:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:33 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:33 --> URI Class Initialized
INFO - 2016-05-18 16:42:33 --> Router Class Initialized
INFO - 2016-05-18 16:42:33 --> Output Class Initialized
INFO - 2016-05-18 16:42:33 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:33 --> CSRF cookie sent
INFO - 2016-05-18 16:42:33 --> Input Class Initialized
INFO - 2016-05-18 16:42:33 --> Language Class Initialized
ERROR - 2016-05-18 16:42:33 --> 404 Page Not Found: Api/getTokens
INFO - 2016-05-18 16:42:38 --> Config Class Initialized
INFO - 2016-05-18 16:42:38 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:38 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:38 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:38 --> URI Class Initialized
INFO - 2016-05-18 16:42:38 --> Router Class Initialized
INFO - 2016-05-18 16:42:38 --> Output Class Initialized
INFO - 2016-05-18 16:42:38 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:38 --> CSRF cookie sent
INFO - 2016-05-18 16:42:38 --> Input Class Initialized
INFO - 2016-05-18 16:42:38 --> Language Class Initialized
INFO - 2016-05-18 16:42:38 --> Loader Class Initialized
INFO - 2016-05-18 16:42:38 --> Helper loaded: form_helper
INFO - 2016-05-18 16:42:38 --> Database Driver Class Initialized
INFO - 2016-05-18 16:42:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:42:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:42:38 --> Email Class Initialized
INFO - 2016-05-18 16:42:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:42:38 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:42:38 --> Helper loaded: language_helper
INFO - 2016-05-18 16:42:38 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:42:38 --> Model Class Initialized
INFO - 2016-05-18 16:42:38 --> Helper loaded: date_helper
INFO - 2016-05-18 16:42:38 --> Controller Class Initialized
INFO - 2016-05-18 16:42:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:42:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:42:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:42:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:42:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:42:38 --> Model Class Initialized
INFO - 2016-05-18 16:42:38 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:42:38 --> test
INFO - 2016-05-18 16:42:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:42:38 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:42:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:42:57 --> Config Class Initialized
INFO - 2016-05-18 16:42:57 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:57 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:57 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:57 --> URI Class Initialized
INFO - 2016-05-18 16:42:57 --> Router Class Initialized
INFO - 2016-05-18 16:42:57 --> Output Class Initialized
INFO - 2016-05-18 16:42:57 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:57 --> CSRF cookie sent
INFO - 2016-05-18 16:42:57 --> Input Class Initialized
INFO - 2016-05-18 16:42:57 --> Language Class Initialized
INFO - 2016-05-18 16:42:57 --> Loader Class Initialized
INFO - 2016-05-18 16:42:57 --> Helper loaded: form_helper
INFO - 2016-05-18 16:42:57 --> Database Driver Class Initialized
INFO - 2016-05-18 16:42:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:42:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:42:57 --> Email Class Initialized
INFO - 2016-05-18 16:42:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:42:57 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:42:57 --> Helper loaded: language_helper
INFO - 2016-05-18 16:42:57 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:42:57 --> Model Class Initialized
INFO - 2016-05-18 16:42:57 --> Helper loaded: date_helper
INFO - 2016-05-18 16:42:57 --> Controller Class Initialized
INFO - 2016-05-18 16:42:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:42:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:42:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:42:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:42:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:42:57 --> Model Class Initialized
INFO - 2016-05-18 16:42:57 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:42:57 --> test
INFO - 2016-05-18 16:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:42:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:42:58 --> Config Class Initialized
INFO - 2016-05-18 16:42:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:58 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:58 --> URI Class Initialized
INFO - 2016-05-18 16:42:58 --> Router Class Initialized
INFO - 2016-05-18 16:42:58 --> Output Class Initialized
INFO - 2016-05-18 16:42:58 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:58 --> CSRF cookie sent
INFO - 2016-05-18 16:42:58 --> Input Class Initialized
INFO - 2016-05-18 16:42:58 --> Language Class Initialized
INFO - 2016-05-18 16:42:58 --> Loader Class Initialized
INFO - 2016-05-18 16:42:58 --> Helper loaded: form_helper
INFO - 2016-05-18 16:42:58 --> Database Driver Class Initialized
INFO - 2016-05-18 16:42:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:42:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:42:58 --> Email Class Initialized
INFO - 2016-05-18 16:42:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:42:58 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:42:58 --> Helper loaded: language_helper
INFO - 2016-05-18 16:42:58 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:42:58 --> Model Class Initialized
INFO - 2016-05-18 16:42:58 --> Helper loaded: date_helper
INFO - 2016-05-18 16:42:58 --> Controller Class Initialized
INFO - 2016-05-18 16:42:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:42:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:42:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:42:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:42:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:42:58 --> Model Class Initialized
INFO - 2016-05-18 16:42:58 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:42:58 --> test
INFO - 2016-05-18 16:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:42:59 --> Config Class Initialized
INFO - 2016-05-18 16:42:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:42:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:42:59 --> Utf8 Class Initialized
INFO - 2016-05-18 16:42:59 --> URI Class Initialized
INFO - 2016-05-18 16:42:59 --> Router Class Initialized
INFO - 2016-05-18 16:42:59 --> Output Class Initialized
INFO - 2016-05-18 16:42:59 --> Security Class Initialized
DEBUG - 2016-05-18 16:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:42:59 --> CSRF cookie sent
INFO - 2016-05-18 16:42:59 --> Input Class Initialized
INFO - 2016-05-18 16:42:59 --> Language Class Initialized
INFO - 2016-05-18 16:42:59 --> Loader Class Initialized
INFO - 2016-05-18 16:42:59 --> Helper loaded: form_helper
INFO - 2016-05-18 16:42:59 --> Database Driver Class Initialized
INFO - 2016-05-18 16:42:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:42:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:42:59 --> Email Class Initialized
INFO - 2016-05-18 16:42:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:42:59 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:42:59 --> Helper loaded: language_helper
INFO - 2016-05-18 16:42:59 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:42:59 --> Model Class Initialized
INFO - 2016-05-18 16:42:59 --> Helper loaded: date_helper
INFO - 2016-05-18 16:42:59 --> Controller Class Initialized
INFO - 2016-05-18 16:42:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:42:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:42:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:42:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:42:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:42:59 --> Model Class Initialized
INFO - 2016-05-18 16:42:59 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:42:59 --> test
INFO - 2016-05-18 16:42:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:42:59 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:42:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:43:04 --> Config Class Initialized
INFO - 2016-05-18 16:43:04 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:43:04 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:43:04 --> Utf8 Class Initialized
INFO - 2016-05-18 16:43:04 --> URI Class Initialized
INFO - 2016-05-18 16:43:04 --> Router Class Initialized
INFO - 2016-05-18 16:43:04 --> Output Class Initialized
INFO - 2016-05-18 16:43:04 --> Security Class Initialized
DEBUG - 2016-05-18 16:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:43:04 --> CSRF cookie sent
INFO - 2016-05-18 16:43:04 --> Input Class Initialized
INFO - 2016-05-18 16:43:04 --> Language Class Initialized
INFO - 2016-05-18 16:43:04 --> Loader Class Initialized
INFO - 2016-05-18 16:43:04 --> Helper loaded: form_helper
INFO - 2016-05-18 16:43:04 --> Database Driver Class Initialized
INFO - 2016-05-18 16:43:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:43:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:43:04 --> Email Class Initialized
INFO - 2016-05-18 16:43:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:43:04 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:43:04 --> Helper loaded: language_helper
INFO - 2016-05-18 16:43:04 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:43:04 --> Model Class Initialized
INFO - 2016-05-18 16:43:04 --> Helper loaded: date_helper
INFO - 2016-05-18 16:43:04 --> Controller Class Initialized
INFO - 2016-05-18 16:43:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:43:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:43:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:43:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:43:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:43:04 --> Model Class Initialized
INFO - 2016-05-18 16:43:04 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:43:04 --> test
INFO - 2016-05-18 16:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:43:41 --> Config Class Initialized
INFO - 2016-05-18 16:43:41 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:43:41 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:43:41 --> Utf8 Class Initialized
INFO - 2016-05-18 16:43:41 --> URI Class Initialized
INFO - 2016-05-18 16:43:41 --> Router Class Initialized
INFO - 2016-05-18 16:43:41 --> Output Class Initialized
INFO - 2016-05-18 16:43:41 --> Security Class Initialized
DEBUG - 2016-05-18 16:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:43:41 --> CSRF cookie sent
INFO - 2016-05-18 16:43:41 --> Input Class Initialized
INFO - 2016-05-18 16:43:41 --> Language Class Initialized
INFO - 2016-05-18 16:43:41 --> Loader Class Initialized
INFO - 2016-05-18 16:43:41 --> Helper loaded: form_helper
INFO - 2016-05-18 16:43:41 --> Database Driver Class Initialized
INFO - 2016-05-18 16:43:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:43:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:43:41 --> Email Class Initialized
INFO - 2016-05-18 16:43:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:43:41 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:43:41 --> Helper loaded: language_helper
INFO - 2016-05-18 16:43:41 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:43:41 --> Model Class Initialized
INFO - 2016-05-18 16:43:41 --> Helper loaded: date_helper
INFO - 2016-05-18 16:43:41 --> Controller Class Initialized
INFO - 2016-05-18 16:43:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:43:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:43:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:43:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:43:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:43:41 --> Model Class Initialized
INFO - 2016-05-18 16:43:47 --> Config Class Initialized
INFO - 2016-05-18 16:43:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:43:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:43:47 --> Utf8 Class Initialized
INFO - 2016-05-18 16:43:47 --> URI Class Initialized
INFO - 2016-05-18 16:43:47 --> Router Class Initialized
INFO - 2016-05-18 16:43:47 --> Output Class Initialized
INFO - 2016-05-18 16:43:47 --> Security Class Initialized
DEBUG - 2016-05-18 16:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:43:47 --> CSRF cookie sent
INFO - 2016-05-18 16:43:47 --> Input Class Initialized
INFO - 2016-05-18 16:43:47 --> Language Class Initialized
INFO - 2016-05-18 16:43:47 --> Loader Class Initialized
INFO - 2016-05-18 16:43:47 --> Helper loaded: form_helper
INFO - 2016-05-18 16:43:47 --> Database Driver Class Initialized
INFO - 2016-05-18 16:43:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:43:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:43:47 --> Email Class Initialized
INFO - 2016-05-18 16:43:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:43:47 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:43:47 --> Helper loaded: language_helper
INFO - 2016-05-18 16:43:47 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:43:47 --> Model Class Initialized
INFO - 2016-05-18 16:43:47 --> Helper loaded: date_helper
INFO - 2016-05-18 16:43:47 --> Controller Class Initialized
INFO - 2016-05-18 16:43:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:43:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:43:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:43:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:43:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:43:47 --> Model Class Initialized
INFO - 2016-05-18 16:43:57 --> Config Class Initialized
INFO - 2016-05-18 16:43:57 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:43:57 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:43:57 --> Utf8 Class Initialized
INFO - 2016-05-18 16:43:57 --> URI Class Initialized
INFO - 2016-05-18 16:43:57 --> Router Class Initialized
INFO - 2016-05-18 16:43:57 --> Output Class Initialized
INFO - 2016-05-18 16:43:57 --> Security Class Initialized
DEBUG - 2016-05-18 16:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:43:57 --> CSRF cookie sent
INFO - 2016-05-18 16:43:57 --> Input Class Initialized
INFO - 2016-05-18 16:43:57 --> Language Class Initialized
INFO - 2016-05-18 16:43:57 --> Loader Class Initialized
INFO - 2016-05-18 16:43:57 --> Helper loaded: form_helper
INFO - 2016-05-18 16:43:57 --> Database Driver Class Initialized
INFO - 2016-05-18 16:43:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:43:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:43:57 --> Email Class Initialized
INFO - 2016-05-18 16:43:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:43:57 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:43:57 --> Helper loaded: language_helper
INFO - 2016-05-18 16:43:57 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:43:57 --> Model Class Initialized
INFO - 2016-05-18 16:43:57 --> Helper loaded: date_helper
INFO - 2016-05-18 16:43:57 --> Controller Class Initialized
INFO - 2016-05-18 16:43:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:43:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:43:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:43:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:43:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:43:57 --> Model Class Initialized
INFO - 2016-05-18 16:44:01 --> Config Class Initialized
INFO - 2016-05-18 16:44:01 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:44:01 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:44:01 --> Utf8 Class Initialized
INFO - 2016-05-18 16:44:01 --> URI Class Initialized
INFO - 2016-05-18 16:44:01 --> Router Class Initialized
INFO - 2016-05-18 16:44:01 --> Output Class Initialized
INFO - 2016-05-18 16:44:01 --> Security Class Initialized
DEBUG - 2016-05-18 16:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:44:01 --> CSRF cookie sent
INFO - 2016-05-18 16:44:01 --> Input Class Initialized
INFO - 2016-05-18 16:44:01 --> Language Class Initialized
INFO - 2016-05-18 16:44:01 --> Loader Class Initialized
INFO - 2016-05-18 16:44:01 --> Helper loaded: form_helper
INFO - 2016-05-18 16:44:01 --> Database Driver Class Initialized
INFO - 2016-05-18 16:44:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:44:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:44:01 --> Email Class Initialized
INFO - 2016-05-18 16:44:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:44:01 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:44:01 --> Helper loaded: language_helper
INFO - 2016-05-18 16:44:01 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:44:01 --> Model Class Initialized
INFO - 2016-05-18 16:44:01 --> Helper loaded: date_helper
INFO - 2016-05-18 16:44:01 --> Controller Class Initialized
INFO - 2016-05-18 16:44:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:44:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:44:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:44:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:44:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:44:01 --> Model Class Initialized
INFO - 2016-05-18 16:44:01 --> Helper loaded: languages_helper
INFO - 2016-05-18 16:44:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:44:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 16:44:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 16:44:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:44:01 --> Final output sent to browser
DEBUG - 2016-05-18 16:44:01 --> Total execution time: 0.0251
INFO - 2016-05-18 16:44:27 --> Config Class Initialized
INFO - 2016-05-18 16:44:27 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:44:27 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:44:27 --> Utf8 Class Initialized
INFO - 2016-05-18 16:44:27 --> URI Class Initialized
INFO - 2016-05-18 16:44:27 --> Router Class Initialized
INFO - 2016-05-18 16:44:27 --> Output Class Initialized
INFO - 2016-05-18 16:44:27 --> Security Class Initialized
DEBUG - 2016-05-18 16:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:44:27 --> CSRF cookie sent
INFO - 2016-05-18 16:44:27 --> Input Class Initialized
INFO - 2016-05-18 16:44:27 --> Language Class Initialized
ERROR - 2016-05-18 16:44:27 --> 404 Page Not Found: Api/get_tokens
INFO - 2016-05-18 16:44:38 --> Config Class Initialized
INFO - 2016-05-18 16:44:38 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:44:38 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:44:38 --> Utf8 Class Initialized
INFO - 2016-05-18 16:44:38 --> URI Class Initialized
INFO - 2016-05-18 16:44:38 --> Router Class Initialized
INFO - 2016-05-18 16:44:38 --> Output Class Initialized
INFO - 2016-05-18 16:44:38 --> Security Class Initialized
DEBUG - 2016-05-18 16:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:44:38 --> CSRF cookie sent
INFO - 2016-05-18 16:44:38 --> Input Class Initialized
INFO - 2016-05-18 16:44:38 --> Language Class Initialized
INFO - 2016-05-18 16:44:38 --> Loader Class Initialized
INFO - 2016-05-18 16:44:38 --> Helper loaded: form_helper
INFO - 2016-05-18 16:44:38 --> Database Driver Class Initialized
INFO - 2016-05-18 16:44:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:44:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:44:38 --> Email Class Initialized
INFO - 2016-05-18 16:44:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:44:38 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:44:38 --> Helper loaded: language_helper
INFO - 2016-05-18 16:44:38 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:44:38 --> Model Class Initialized
INFO - 2016-05-18 16:44:38 --> Helper loaded: date_helper
INFO - 2016-05-18 16:44:38 --> Controller Class Initialized
INFO - 2016-05-18 16:44:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:44:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:44:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:44:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:44:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:44:38 --> Model Class Initialized
INFO - 2016-05-18 16:44:38 --> Helper loaded: languages_helper
INFO - 2016-05-18 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:44:38 --> Final output sent to browser
DEBUG - 2016-05-18 16:44:38 --> Total execution time: 0.1018
INFO - 2016-05-18 16:45:33 --> Config Class Initialized
INFO - 2016-05-18 16:45:33 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:45:33 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:45:33 --> Utf8 Class Initialized
INFO - 2016-05-18 16:45:33 --> URI Class Initialized
INFO - 2016-05-18 16:45:33 --> Router Class Initialized
INFO - 2016-05-18 16:45:33 --> Output Class Initialized
INFO - 2016-05-18 16:45:33 --> Security Class Initialized
DEBUG - 2016-05-18 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:45:33 --> CSRF cookie sent
INFO - 2016-05-18 16:45:33 --> Input Class Initialized
INFO - 2016-05-18 16:45:33 --> Language Class Initialized
INFO - 2016-05-18 16:45:33 --> Loader Class Initialized
INFO - 2016-05-18 16:45:33 --> Helper loaded: form_helper
INFO - 2016-05-18 16:45:33 --> Database Driver Class Initialized
INFO - 2016-05-18 16:45:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:45:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:45:33 --> Email Class Initialized
INFO - 2016-05-18 16:45:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:45:33 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:45:33 --> Helper loaded: language_helper
INFO - 2016-05-18 16:45:33 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:45:33 --> Model Class Initialized
INFO - 2016-05-18 16:45:33 --> Helper loaded: date_helper
INFO - 2016-05-18 16:45:33 --> Controller Class Initialized
INFO - 2016-05-18 16:45:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:45:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:45:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:45:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:45:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:45:33 --> Model Class Initialized
INFO - 2016-05-18 16:45:45 --> Config Class Initialized
INFO - 2016-05-18 16:45:45 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:45:45 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:45:45 --> Utf8 Class Initialized
INFO - 2016-05-18 16:45:45 --> URI Class Initialized
INFO - 2016-05-18 16:45:45 --> Router Class Initialized
INFO - 2016-05-18 16:45:45 --> Output Class Initialized
INFO - 2016-05-18 16:45:45 --> Security Class Initialized
DEBUG - 2016-05-18 16:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:45:45 --> CSRF cookie sent
INFO - 2016-05-18 16:45:45 --> Input Class Initialized
INFO - 2016-05-18 16:45:45 --> Language Class Initialized
INFO - 2016-05-18 16:45:45 --> Loader Class Initialized
INFO - 2016-05-18 16:45:45 --> Helper loaded: form_helper
INFO - 2016-05-18 16:45:45 --> Database Driver Class Initialized
INFO - 2016-05-18 16:45:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:45:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:45:45 --> Email Class Initialized
INFO - 2016-05-18 16:45:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:45:45 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:45:45 --> Helper loaded: language_helper
INFO - 2016-05-18 16:45:45 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:45:45 --> Model Class Initialized
INFO - 2016-05-18 16:45:45 --> Helper loaded: date_helper
INFO - 2016-05-18 16:45:45 --> Controller Class Initialized
INFO - 2016-05-18 16:45:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:45:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:45:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:45:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:45:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:45:45 --> Model Class Initialized
INFO - 2016-05-18 16:45:45 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:45:45 --> test
INFO - 2016-05-18 16:45:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:45:45 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:45:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:45:46 --> Config Class Initialized
INFO - 2016-05-18 16:45:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:45:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:45:46 --> Utf8 Class Initialized
INFO - 2016-05-18 16:45:46 --> URI Class Initialized
INFO - 2016-05-18 16:45:46 --> Router Class Initialized
INFO - 2016-05-18 16:45:46 --> Output Class Initialized
INFO - 2016-05-18 16:45:46 --> Security Class Initialized
DEBUG - 2016-05-18 16:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:45:46 --> CSRF cookie sent
INFO - 2016-05-18 16:45:46 --> Input Class Initialized
INFO - 2016-05-18 16:45:46 --> Language Class Initialized
INFO - 2016-05-18 16:45:46 --> Loader Class Initialized
INFO - 2016-05-18 16:45:46 --> Helper loaded: form_helper
INFO - 2016-05-18 16:45:46 --> Database Driver Class Initialized
INFO - 2016-05-18 16:45:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:45:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:45:46 --> Email Class Initialized
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:45:46 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:45:46 --> Helper loaded: language_helper
INFO - 2016-05-18 16:45:46 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:45:46 --> Model Class Initialized
INFO - 2016-05-18 16:45:46 --> Helper loaded: date_helper
INFO - 2016-05-18 16:45:46 --> Controller Class Initialized
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:45:46 --> Model Class Initialized
INFO - 2016-05-18 16:45:46 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:45:46 --> test
INFO - 2016-05-18 16:45:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:45:46 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:45:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:45:46 --> Config Class Initialized
INFO - 2016-05-18 16:45:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:45:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:45:46 --> Utf8 Class Initialized
INFO - 2016-05-18 16:45:46 --> URI Class Initialized
INFO - 2016-05-18 16:45:46 --> Router Class Initialized
INFO - 2016-05-18 16:45:46 --> Output Class Initialized
INFO - 2016-05-18 16:45:46 --> Security Class Initialized
DEBUG - 2016-05-18 16:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:45:46 --> CSRF cookie sent
INFO - 2016-05-18 16:45:46 --> Input Class Initialized
INFO - 2016-05-18 16:45:46 --> Language Class Initialized
INFO - 2016-05-18 16:45:46 --> Loader Class Initialized
INFO - 2016-05-18 16:45:46 --> Helper loaded: form_helper
INFO - 2016-05-18 16:45:46 --> Database Driver Class Initialized
INFO - 2016-05-18 16:45:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:45:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:45:46 --> Email Class Initialized
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:45:46 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:45:46 --> Helper loaded: language_helper
INFO - 2016-05-18 16:45:46 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:45:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:45:46 --> Model Class Initialized
INFO - 2016-05-18 16:45:46 --> Helper loaded: date_helper
INFO - 2016-05-18 16:45:46 --> Controller Class Initialized
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:45:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:45:46 --> Model Class Initialized
INFO - 2016-05-18 16:45:46 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:45:46 --> test
INFO - 2016-05-18 16:45:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:45:46 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:45:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:45:47 --> Config Class Initialized
INFO - 2016-05-18 16:45:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:45:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:45:47 --> Utf8 Class Initialized
INFO - 2016-05-18 16:45:47 --> URI Class Initialized
INFO - 2016-05-18 16:45:47 --> Router Class Initialized
INFO - 2016-05-18 16:45:47 --> Output Class Initialized
INFO - 2016-05-18 16:45:47 --> Security Class Initialized
DEBUG - 2016-05-18 16:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:45:47 --> CSRF cookie sent
INFO - 2016-05-18 16:45:47 --> Input Class Initialized
INFO - 2016-05-18 16:45:47 --> Language Class Initialized
INFO - 2016-05-18 16:45:47 --> Loader Class Initialized
INFO - 2016-05-18 16:45:47 --> Helper loaded: form_helper
INFO - 2016-05-18 16:45:47 --> Database Driver Class Initialized
INFO - 2016-05-18 16:45:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:45:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:45:47 --> Email Class Initialized
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:45:47 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:45:47 --> Helper loaded: language_helper
INFO - 2016-05-18 16:45:47 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:45:47 --> Model Class Initialized
INFO - 2016-05-18 16:45:47 --> Helper loaded: date_helper
INFO - 2016-05-18 16:45:47 --> Controller Class Initialized
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:45:47 --> Model Class Initialized
INFO - 2016-05-18 16:45:47 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:45:47 --> test
INFO - 2016-05-18 16:45:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:45:47 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:45:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:45:47 --> Config Class Initialized
INFO - 2016-05-18 16:45:47 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:45:47 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:45:47 --> Utf8 Class Initialized
INFO - 2016-05-18 16:45:47 --> URI Class Initialized
INFO - 2016-05-18 16:45:47 --> Router Class Initialized
INFO - 2016-05-18 16:45:47 --> Output Class Initialized
INFO - 2016-05-18 16:45:47 --> Security Class Initialized
DEBUG - 2016-05-18 16:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:45:47 --> CSRF cookie sent
INFO - 2016-05-18 16:45:47 --> Input Class Initialized
INFO - 2016-05-18 16:45:47 --> Language Class Initialized
INFO - 2016-05-18 16:45:47 --> Loader Class Initialized
INFO - 2016-05-18 16:45:47 --> Helper loaded: form_helper
INFO - 2016-05-18 16:45:47 --> Database Driver Class Initialized
INFO - 2016-05-18 16:45:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:45:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:45:47 --> Email Class Initialized
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:45:47 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:45:47 --> Helper loaded: language_helper
INFO - 2016-05-18 16:45:47 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:45:47 --> Model Class Initialized
INFO - 2016-05-18 16:45:47 --> Helper loaded: date_helper
INFO - 2016-05-18 16:45:47 --> Controller Class Initialized
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:45:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:45:47 --> Model Class Initialized
INFO - 2016-05-18 16:45:47 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:45:47 --> test
INFO - 2016-05-18 16:45:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:45:47 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:45:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:45:51 --> Config Class Initialized
INFO - 2016-05-18 16:45:51 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:45:51 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:45:51 --> Utf8 Class Initialized
INFO - 2016-05-18 16:45:51 --> URI Class Initialized
INFO - 2016-05-18 16:45:51 --> Router Class Initialized
INFO - 2016-05-18 16:45:51 --> Output Class Initialized
INFO - 2016-05-18 16:45:51 --> Security Class Initialized
DEBUG - 2016-05-18 16:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:45:51 --> CSRF cookie sent
INFO - 2016-05-18 16:45:51 --> Input Class Initialized
INFO - 2016-05-18 16:45:51 --> Language Class Initialized
INFO - 2016-05-18 16:45:51 --> Loader Class Initialized
INFO - 2016-05-18 16:45:51 --> Helper loaded: form_helper
INFO - 2016-05-18 16:45:51 --> Database Driver Class Initialized
INFO - 2016-05-18 16:45:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:45:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:45:51 --> Email Class Initialized
INFO - 2016-05-18 16:45:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:45:51 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:45:51 --> Helper loaded: language_helper
INFO - 2016-05-18 16:45:51 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:45:51 --> Model Class Initialized
INFO - 2016-05-18 16:45:51 --> Helper loaded: date_helper
INFO - 2016-05-18 16:45:51 --> Controller Class Initialized
INFO - 2016-05-18 16:45:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:45:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:45:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:45:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:45:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:45:51 --> Model Class Initialized
INFO - 2016-05-18 16:45:51 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:45:51 --> test
INFO - 2016-05-18 16:45:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:45:51 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:45:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:46:43 --> Config Class Initialized
INFO - 2016-05-18 16:46:43 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:46:43 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:46:43 --> Utf8 Class Initialized
INFO - 2016-05-18 16:46:43 --> URI Class Initialized
INFO - 2016-05-18 16:46:43 --> Router Class Initialized
INFO - 2016-05-18 16:46:43 --> Output Class Initialized
INFO - 2016-05-18 16:46:43 --> Security Class Initialized
DEBUG - 2016-05-18 16:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:46:43 --> CSRF cookie sent
INFO - 2016-05-18 16:46:43 --> Input Class Initialized
INFO - 2016-05-18 16:46:43 --> Language Class Initialized
INFO - 2016-05-18 16:46:43 --> Loader Class Initialized
INFO - 2016-05-18 16:46:43 --> Helper loaded: form_helper
INFO - 2016-05-18 16:46:43 --> Database Driver Class Initialized
INFO - 2016-05-18 16:46:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:46:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:46:43 --> Email Class Initialized
INFO - 2016-05-18 16:46:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:46:43 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:46:43 --> Helper loaded: language_helper
INFO - 2016-05-18 16:46:43 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:46:43 --> Model Class Initialized
INFO - 2016-05-18 16:46:43 --> Helper loaded: date_helper
INFO - 2016-05-18 16:46:43 --> Controller Class Initialized
INFO - 2016-05-18 16:46:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:46:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:46:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:46:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:46:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:46:43 --> Model Class Initialized
ERROR - 2016-05-18 16:46:43 --> File 'user_area/acces2s' doesn't exist.
INFO - 2016-05-18 16:46:43 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:46:43 --> Mesaj Eroare.
INFO - 2016-05-18 16:46:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:46:43 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:46:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:46:43 --> Final output sent to browser
DEBUG - 2016-05-18 16:46:43 --> Total execution time: 0.0486
INFO - 2016-05-18 16:47:11 --> Config Class Initialized
INFO - 2016-05-18 16:47:11 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:47:11 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:47:11 --> Utf8 Class Initialized
INFO - 2016-05-18 16:47:11 --> URI Class Initialized
INFO - 2016-05-18 16:47:11 --> Router Class Initialized
INFO - 2016-05-18 16:47:11 --> Output Class Initialized
INFO - 2016-05-18 16:47:11 --> Security Class Initialized
DEBUG - 2016-05-18 16:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:47:11 --> CSRF cookie sent
INFO - 2016-05-18 16:47:11 --> Input Class Initialized
INFO - 2016-05-18 16:47:11 --> Language Class Initialized
INFO - 2016-05-18 16:47:11 --> Loader Class Initialized
INFO - 2016-05-18 16:47:11 --> Helper loaded: form_helper
INFO - 2016-05-18 16:47:11 --> Database Driver Class Initialized
INFO - 2016-05-18 16:47:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:47:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:47:11 --> Email Class Initialized
INFO - 2016-05-18 16:47:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:47:11 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:47:11 --> Helper loaded: language_helper
INFO - 2016-05-18 16:47:11 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:47:11 --> Model Class Initialized
INFO - 2016-05-18 16:47:11 --> Helper loaded: date_helper
INFO - 2016-05-18 16:47:11 --> Controller Class Initialized
INFO - 2016-05-18 16:47:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:47:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:47:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:47:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:47:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:47:11 --> Model Class Initialized
INFO - 2016-05-18 16:47:11 --> Helper loaded: languages_helper
INFO - 2016-05-18 16:47:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:47:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 16:47:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 16:47:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:47:11 --> Final output sent to browser
DEBUG - 2016-05-18 16:47:11 --> Total execution time: 0.0569
INFO - 2016-05-18 16:52:03 --> Config Class Initialized
INFO - 2016-05-18 16:52:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:52:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:52:03 --> Utf8 Class Initialized
INFO - 2016-05-18 16:52:03 --> URI Class Initialized
INFO - 2016-05-18 16:52:03 --> Router Class Initialized
INFO - 2016-05-18 16:52:03 --> Output Class Initialized
INFO - 2016-05-18 16:52:03 --> Security Class Initialized
DEBUG - 2016-05-18 16:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:52:03 --> CSRF cookie sent
INFO - 2016-05-18 16:52:03 --> Input Class Initialized
INFO - 2016-05-18 16:52:03 --> Language Class Initialized
INFO - 2016-05-18 16:52:03 --> Loader Class Initialized
INFO - 2016-05-18 16:52:03 --> Helper loaded: form_helper
INFO - 2016-05-18 16:52:03 --> Database Driver Class Initialized
INFO - 2016-05-18 16:52:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:52:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:52:03 --> Email Class Initialized
INFO - 2016-05-18 16:52:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:52:03 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:52:03 --> Helper loaded: language_helper
INFO - 2016-05-18 16:52:03 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:52:03 --> Model Class Initialized
INFO - 2016-05-18 16:52:03 --> Helper loaded: date_helper
INFO - 2016-05-18 16:52:03 --> Controller Class Initialized
INFO - 2016-05-18 16:52:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:52:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:52:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:52:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:52:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:52:03 --> Model Class Initialized
INFO - 2016-05-18 16:52:03 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:52:03 --> Mesaj nu are access
INFO - 2016-05-18 16:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:52:06 --> Config Class Initialized
INFO - 2016-05-18 16:52:06 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:52:06 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:52:06 --> Utf8 Class Initialized
INFO - 2016-05-18 16:52:06 --> URI Class Initialized
INFO - 2016-05-18 16:52:06 --> Router Class Initialized
INFO - 2016-05-18 16:52:06 --> Output Class Initialized
INFO - 2016-05-18 16:52:06 --> Security Class Initialized
DEBUG - 2016-05-18 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:52:06 --> CSRF cookie sent
INFO - 2016-05-18 16:52:06 --> Input Class Initialized
INFO - 2016-05-18 16:52:06 --> Language Class Initialized
INFO - 2016-05-18 16:52:06 --> Loader Class Initialized
INFO - 2016-05-18 16:52:06 --> Helper loaded: form_helper
INFO - 2016-05-18 16:52:06 --> Database Driver Class Initialized
INFO - 2016-05-18 16:52:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:52:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:52:06 --> Email Class Initialized
INFO - 2016-05-18 16:52:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:52:06 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:52:06 --> Helper loaded: language_helper
INFO - 2016-05-18 16:52:06 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:52:06 --> Model Class Initialized
INFO - 2016-05-18 16:52:06 --> Helper loaded: date_helper
INFO - 2016-05-18 16:52:06 --> Controller Class Initialized
INFO - 2016-05-18 16:52:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:52:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:52:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:52:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:52:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:52:06 --> Model Class Initialized
INFO - 2016-05-18 16:52:06 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:52:06 --> Mesaj token invalid
INFO - 2016-05-18 16:52:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:52:06 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:52:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 16:52:06 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 54
ERROR - 2016-05-18 16:52:06 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 73
INFO - 2016-05-18 16:52:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:52:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 16:52:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 16:52:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:52:06 --> Final output sent to browser
DEBUG - 2016-05-18 16:52:06 --> Total execution time: 0.0542
INFO - 2016-05-18 16:52:18 --> Config Class Initialized
INFO - 2016-05-18 16:52:18 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:52:18 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:52:18 --> Utf8 Class Initialized
INFO - 2016-05-18 16:52:18 --> URI Class Initialized
INFO - 2016-05-18 16:52:18 --> Router Class Initialized
INFO - 2016-05-18 16:52:18 --> Output Class Initialized
INFO - 2016-05-18 16:52:18 --> Security Class Initialized
DEBUG - 2016-05-18 16:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:52:18 --> CSRF cookie sent
INFO - 2016-05-18 16:52:18 --> Input Class Initialized
INFO - 2016-05-18 16:52:18 --> Language Class Initialized
INFO - 2016-05-18 16:52:18 --> Loader Class Initialized
INFO - 2016-05-18 16:52:18 --> Helper loaded: form_helper
INFO - 2016-05-18 16:52:18 --> Database Driver Class Initialized
INFO - 2016-05-18 16:52:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:52:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:52:18 --> Email Class Initialized
INFO - 2016-05-18 16:52:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:52:18 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:52:18 --> Helper loaded: language_helper
INFO - 2016-05-18 16:52:18 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:52:18 --> Model Class Initialized
INFO - 2016-05-18 16:52:18 --> Helper loaded: date_helper
INFO - 2016-05-18 16:52:18 --> Controller Class Initialized
INFO - 2016-05-18 16:52:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:52:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:52:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:52:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:52:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:52:18 --> Model Class Initialized
INFO - 2016-05-18 16:52:18 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:52:18 --> Mesaj token invalid
INFO - 2016-05-18 16:52:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:52:18 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:52:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:52:42 --> Config Class Initialized
INFO - 2016-05-18 16:52:42 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:52:42 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:52:42 --> Utf8 Class Initialized
INFO - 2016-05-18 16:52:42 --> URI Class Initialized
INFO - 2016-05-18 16:52:42 --> Router Class Initialized
INFO - 2016-05-18 16:52:42 --> Output Class Initialized
INFO - 2016-05-18 16:52:42 --> Security Class Initialized
DEBUG - 2016-05-18 16:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:52:42 --> CSRF cookie sent
INFO - 2016-05-18 16:52:42 --> Input Class Initialized
INFO - 2016-05-18 16:52:42 --> Language Class Initialized
INFO - 2016-05-18 16:52:42 --> Loader Class Initialized
INFO - 2016-05-18 16:52:42 --> Helper loaded: form_helper
INFO - 2016-05-18 16:52:42 --> Database Driver Class Initialized
INFO - 2016-05-18 16:52:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:52:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:52:42 --> Email Class Initialized
INFO - 2016-05-18 16:52:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:52:42 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:52:42 --> Helper loaded: language_helper
INFO - 2016-05-18 16:52:42 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:52:42 --> Model Class Initialized
INFO - 2016-05-18 16:52:42 --> Helper loaded: date_helper
INFO - 2016-05-18 16:52:42 --> Controller Class Initialized
INFO - 2016-05-18 16:52:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:52:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:52:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:52:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:52:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:52:42 --> Model Class Initialized
INFO - 2016-05-18 16:52:42 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:52:42 --> Mesaj token invalid
INFO - 2016-05-18 16:52:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:52:42 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:52:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:54:17 --> Config Class Initialized
INFO - 2016-05-18 16:54:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:54:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:54:17 --> Utf8 Class Initialized
INFO - 2016-05-18 16:54:17 --> URI Class Initialized
INFO - 2016-05-18 16:54:17 --> Router Class Initialized
INFO - 2016-05-18 16:54:17 --> Output Class Initialized
INFO - 2016-05-18 16:54:17 --> Security Class Initialized
DEBUG - 2016-05-18 16:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:54:17 --> CSRF cookie sent
INFO - 2016-05-18 16:54:17 --> Input Class Initialized
INFO - 2016-05-18 16:54:17 --> Language Class Initialized
INFO - 2016-05-18 16:54:17 --> Loader Class Initialized
INFO - 2016-05-18 16:54:17 --> Helper loaded: form_helper
INFO - 2016-05-18 16:54:17 --> Database Driver Class Initialized
INFO - 2016-05-18 16:54:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:54:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:54:17 --> Email Class Initialized
INFO - 2016-05-18 16:54:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:54:17 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:54:17 --> Helper loaded: language_helper
INFO - 2016-05-18 16:54:17 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:54:17 --> Model Class Initialized
INFO - 2016-05-18 16:54:17 --> Helper loaded: date_helper
INFO - 2016-05-18 16:54:17 --> Controller Class Initialized
INFO - 2016-05-18 16:54:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:54:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:54:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:54:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:54:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:54:17 --> Model Class Initialized
INFO - 2016-05-18 16:54:17 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:54:17 --> Mesaj token invalid
INFO - 2016-05-18 16:54:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:54:17 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:54:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:54:18 --> Config Class Initialized
INFO - 2016-05-18 16:54:18 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:54:18 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:54:18 --> Utf8 Class Initialized
INFO - 2016-05-18 16:54:18 --> URI Class Initialized
INFO - 2016-05-18 16:54:18 --> Router Class Initialized
INFO - 2016-05-18 16:54:18 --> Output Class Initialized
INFO - 2016-05-18 16:54:18 --> Security Class Initialized
DEBUG - 2016-05-18 16:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:54:18 --> CSRF cookie sent
INFO - 2016-05-18 16:54:18 --> Input Class Initialized
INFO - 2016-05-18 16:54:18 --> Language Class Initialized
INFO - 2016-05-18 16:54:18 --> Loader Class Initialized
INFO - 2016-05-18 16:54:18 --> Helper loaded: form_helper
INFO - 2016-05-18 16:54:18 --> Database Driver Class Initialized
INFO - 2016-05-18 16:54:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:54:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:54:18 --> Email Class Initialized
INFO - 2016-05-18 16:54:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:54:18 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:54:18 --> Helper loaded: language_helper
INFO - 2016-05-18 16:54:18 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:54:18 --> Model Class Initialized
INFO - 2016-05-18 16:54:18 --> Helper loaded: date_helper
INFO - 2016-05-18 16:54:18 --> Controller Class Initialized
INFO - 2016-05-18 16:54:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:54:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:54:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:54:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:54:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:54:18 --> Model Class Initialized
INFO - 2016-05-18 16:54:18 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:54:18 --> Mesaj token invalid
INFO - 2016-05-18 16:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:54:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:55:16 --> Config Class Initialized
INFO - 2016-05-18 16:55:16 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:55:16 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:55:16 --> Utf8 Class Initialized
INFO - 2016-05-18 16:55:16 --> URI Class Initialized
INFO - 2016-05-18 16:55:16 --> Router Class Initialized
INFO - 2016-05-18 16:55:16 --> Output Class Initialized
INFO - 2016-05-18 16:55:16 --> Security Class Initialized
DEBUG - 2016-05-18 16:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:55:16 --> CSRF cookie sent
INFO - 2016-05-18 16:55:16 --> Input Class Initialized
INFO - 2016-05-18 16:55:16 --> Language Class Initialized
INFO - 2016-05-18 16:55:16 --> Loader Class Initialized
INFO - 2016-05-18 16:55:16 --> Helper loaded: form_helper
INFO - 2016-05-18 16:55:16 --> Helper loaded: url_helper
INFO - 2016-05-18 16:55:16 --> Database Driver Class Initialized
INFO - 2016-05-18 16:55:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:55:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:55:16 --> Email Class Initialized
INFO - 2016-05-18 16:55:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:55:16 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:55:16 --> Helper loaded: language_helper
DEBUG - 2016-05-18 16:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:55:16 --> Model Class Initialized
INFO - 2016-05-18 16:55:16 --> Helper loaded: date_helper
INFO - 2016-05-18 16:55:16 --> Controller Class Initialized
INFO - 2016-05-18 16:55:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:55:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:55:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:55:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:55:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:55:16 --> Model Class Initialized
INFO - 2016-05-18 16:55:16 --> Helper loaded: languages_helper
ERROR - 2016-05-18 16:55:16 --> Mesaj token invalid
INFO - 2016-05-18 16:55:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:55:16 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:55:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:56:53 --> Config Class Initialized
INFO - 2016-05-18 16:56:53 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:56:53 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:56:53 --> Utf8 Class Initialized
INFO - 2016-05-18 16:56:53 --> URI Class Initialized
INFO - 2016-05-18 16:56:53 --> Router Class Initialized
INFO - 2016-05-18 16:56:53 --> Output Class Initialized
INFO - 2016-05-18 16:56:53 --> Security Class Initialized
DEBUG - 2016-05-18 16:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:56:53 --> CSRF cookie sent
INFO - 2016-05-18 16:56:53 --> Input Class Initialized
INFO - 2016-05-18 16:56:53 --> Language Class Initialized
INFO - 2016-05-18 16:56:53 --> Loader Class Initialized
INFO - 2016-05-18 16:56:53 --> Helper loaded: form_helper
INFO - 2016-05-18 16:56:53 --> Database Driver Class Initialized
INFO - 2016-05-18 16:56:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:56:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:56:54 --> Email Class Initialized
INFO - 2016-05-18 16:56:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:56:54 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:56:54 --> Helper loaded: language_helper
INFO - 2016-05-18 16:56:54 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:56:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:56:54 --> Model Class Initialized
INFO - 2016-05-18 16:56:54 --> Helper loaded: date_helper
INFO - 2016-05-18 16:56:54 --> Controller Class Initialized
INFO - 2016-05-18 16:56:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:56:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:56:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:56:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:56:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:56:54 --> Model Class Initialized
INFO - 2016-05-18 16:56:54 --> Helper loaded: languages_helper
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 16:56:54 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:56:54 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 16:56:54 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:56:54 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:56:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 16:56:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?
			AND
				`_is_active` = 1' at line 6 - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_is_active` = 1
			
INFO - 2016-05-18 16:58:22 --> Config Class Initialized
INFO - 2016-05-18 16:58:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:58:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:58:22 --> Utf8 Class Initialized
INFO - 2016-05-18 16:58:22 --> URI Class Initialized
INFO - 2016-05-18 16:58:22 --> Router Class Initialized
INFO - 2016-05-18 16:58:22 --> Output Class Initialized
INFO - 2016-05-18 16:58:22 --> Security Class Initialized
DEBUG - 2016-05-18 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:58:22 --> CSRF cookie sent
INFO - 2016-05-18 16:58:22 --> Input Class Initialized
INFO - 2016-05-18 16:58:22 --> Language Class Initialized
INFO - 2016-05-18 16:58:22 --> Loader Class Initialized
INFO - 2016-05-18 16:58:22 --> Helper loaded: form_helper
INFO - 2016-05-18 16:58:22 --> Database Driver Class Initialized
INFO - 2016-05-18 16:58:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:58:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:58:22 --> Email Class Initialized
INFO - 2016-05-18 16:58:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:58:22 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:58:22 --> Helper loaded: language_helper
INFO - 2016-05-18 16:58:22 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:58:22 --> Model Class Initialized
INFO - 2016-05-18 16:58:22 --> Helper loaded: date_helper
INFO - 2016-05-18 16:58:22 --> Controller Class Initialized
INFO - 2016-05-18 16:58:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:58:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:58:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:58:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:58:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:58:22 --> Model Class Initialized
INFO - 2016-05-18 16:58:22 --> Helper loaded: languages_helper
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 16:58:22 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:58:22 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 16:58:22 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:58:22 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:58:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:59:03 --> Config Class Initialized
INFO - 2016-05-18 16:59:03 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:59:03 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:59:03 --> Utf8 Class Initialized
INFO - 2016-05-18 16:59:03 --> URI Class Initialized
INFO - 2016-05-18 16:59:03 --> Router Class Initialized
INFO - 2016-05-18 16:59:03 --> Output Class Initialized
INFO - 2016-05-18 16:59:03 --> Security Class Initialized
DEBUG - 2016-05-18 16:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:59:03 --> CSRF cookie sent
INFO - 2016-05-18 16:59:03 --> Input Class Initialized
INFO - 2016-05-18 16:59:03 --> Language Class Initialized
INFO - 2016-05-18 16:59:03 --> Loader Class Initialized
INFO - 2016-05-18 16:59:03 --> Helper loaded: form_helper
INFO - 2016-05-18 16:59:03 --> Database Driver Class Initialized
INFO - 2016-05-18 16:59:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:59:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:59:03 --> Email Class Initialized
INFO - 2016-05-18 16:59:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:59:03 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:59:03 --> Helper loaded: language_helper
INFO - 2016-05-18 16:59:03 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:59:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:59:03 --> Model Class Initialized
INFO - 2016-05-18 16:59:03 --> Helper loaded: date_helper
INFO - 2016-05-18 16:59:03 --> Controller Class Initialized
INFO - 2016-05-18 16:59:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:59:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:59:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:59:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:59:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:59:03 --> Model Class Initialized
INFO - 2016-05-18 16:59:03 --> Helper loaded: languages_helper
INFO - 2016-05-18 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 16:59:03 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:59:03 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:59:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 16:59:11 --> Config Class Initialized
INFO - 2016-05-18 16:59:11 --> Hooks Class Initialized
DEBUG - 2016-05-18 16:59:11 --> UTF-8 Support Enabled
INFO - 2016-05-18 16:59:11 --> Utf8 Class Initialized
INFO - 2016-05-18 16:59:11 --> URI Class Initialized
INFO - 2016-05-18 16:59:11 --> Router Class Initialized
INFO - 2016-05-18 16:59:11 --> Output Class Initialized
INFO - 2016-05-18 16:59:11 --> Security Class Initialized
DEBUG - 2016-05-18 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 16:59:11 --> CSRF cookie sent
INFO - 2016-05-18 16:59:11 --> Input Class Initialized
INFO - 2016-05-18 16:59:11 --> Language Class Initialized
INFO - 2016-05-18 16:59:11 --> Loader Class Initialized
INFO - 2016-05-18 16:59:11 --> Helper loaded: form_helper
INFO - 2016-05-18 16:59:11 --> Database Driver Class Initialized
INFO - 2016-05-18 16:59:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 16:59:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 16:59:11 --> Email Class Initialized
INFO - 2016-05-18 16:59:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 16:59:11 --> Helper loaded: cookie_helper
INFO - 2016-05-18 16:59:11 --> Helper loaded: language_helper
INFO - 2016-05-18 16:59:11 --> Helper loaded: url_helper
DEBUG - 2016-05-18 16:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 16:59:11 --> Model Class Initialized
INFO - 2016-05-18 16:59:11 --> Helper loaded: date_helper
INFO - 2016-05-18 16:59:11 --> Controller Class Initialized
INFO - 2016-05-18 16:59:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 16:59:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 16:59:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 16:59:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 16:59:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 16:59:11 --> Model Class Initialized
INFO - 2016-05-18 16:59:11 --> Helper loaded: languages_helper
INFO - 2016-05-18 16:59:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 16:59:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 16:59:11 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 16:59:11 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 16:59:11 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 16:59:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:00:12 --> Config Class Initialized
INFO - 2016-05-18 17:00:12 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:00:12 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:00:12 --> Utf8 Class Initialized
INFO - 2016-05-18 17:00:12 --> URI Class Initialized
INFO - 2016-05-18 17:00:12 --> Router Class Initialized
INFO - 2016-05-18 17:00:12 --> Output Class Initialized
INFO - 2016-05-18 17:00:12 --> Security Class Initialized
DEBUG - 2016-05-18 17:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:00:12 --> CSRF cookie sent
INFO - 2016-05-18 17:00:12 --> Input Class Initialized
INFO - 2016-05-18 17:00:12 --> Language Class Initialized
INFO - 2016-05-18 17:00:12 --> Loader Class Initialized
INFO - 2016-05-18 17:00:12 --> Helper loaded: form_helper
INFO - 2016-05-18 17:00:12 --> Database Driver Class Initialized
INFO - 2016-05-18 17:00:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:00:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:00:12 --> Email Class Initialized
INFO - 2016-05-18 17:00:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:00:12 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:00:12 --> Helper loaded: language_helper
INFO - 2016-05-18 17:00:12 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:00:12 --> Model Class Initialized
INFO - 2016-05-18 17:00:12 --> Helper loaded: date_helper
INFO - 2016-05-18 17:00:12 --> Controller Class Initialized
INFO - 2016-05-18 17:00:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:00:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:00:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:00:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:00:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:00:12 --> Model Class Initialized
INFO - 2016-05-18 17:00:12 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:00:12 --> Mesaj token invalid
INFO - 2016-05-18 17:00:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:00:12 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:00:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:03:46 --> Config Class Initialized
INFO - 2016-05-18 17:03:46 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:03:46 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:03:46 --> Utf8 Class Initialized
INFO - 2016-05-18 17:03:46 --> URI Class Initialized
INFO - 2016-05-18 17:03:46 --> Router Class Initialized
INFO - 2016-05-18 17:03:46 --> Output Class Initialized
INFO - 2016-05-18 17:03:46 --> Security Class Initialized
DEBUG - 2016-05-18 17:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:03:46 --> CSRF cookie sent
INFO - 2016-05-18 17:03:46 --> Input Class Initialized
INFO - 2016-05-18 17:03:46 --> Language Class Initialized
INFO - 2016-05-18 17:03:46 --> Loader Class Initialized
INFO - 2016-05-18 17:03:46 --> Helper loaded: form_helper
INFO - 2016-05-18 17:03:46 --> Database Driver Class Initialized
INFO - 2016-05-18 17:03:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:03:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:03:46 --> Email Class Initialized
INFO - 2016-05-18 17:03:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:03:46 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:03:46 --> Helper loaded: language_helper
INFO - 2016-05-18 17:03:46 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:03:46 --> Model Class Initialized
INFO - 2016-05-18 17:03:46 --> Helper loaded: date_helper
INFO - 2016-05-18 17:03:46 --> Controller Class Initialized
INFO - 2016-05-18 17:03:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:03:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:03:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:03:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:03:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:03:46 --> Model Class Initialized
INFO - 2016-05-18 17:03:46 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:03:46 --> Mesaj token invalid
INFO - 2016-05-18 17:03:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:03:46 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:03:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:04:00 --> Config Class Initialized
INFO - 2016-05-18 17:04:00 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:04:00 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:04:00 --> Utf8 Class Initialized
INFO - 2016-05-18 17:04:00 --> URI Class Initialized
INFO - 2016-05-18 17:04:00 --> Router Class Initialized
INFO - 2016-05-18 17:04:00 --> Output Class Initialized
INFO - 2016-05-18 17:04:00 --> Security Class Initialized
DEBUG - 2016-05-18 17:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:04:00 --> CSRF cookie sent
INFO - 2016-05-18 17:04:00 --> Input Class Initialized
INFO - 2016-05-18 17:04:00 --> Language Class Initialized
INFO - 2016-05-18 17:04:00 --> Loader Class Initialized
INFO - 2016-05-18 17:04:00 --> Helper loaded: form_helper
INFO - 2016-05-18 17:04:00 --> Database Driver Class Initialized
INFO - 2016-05-18 17:04:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:04:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:04:00 --> Email Class Initialized
INFO - 2016-05-18 17:04:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:04:00 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:04:00 --> Helper loaded: language_helper
INFO - 2016-05-18 17:04:00 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:04:00 --> Model Class Initialized
INFO - 2016-05-18 17:04:00 --> Helper loaded: date_helper
INFO - 2016-05-18 17:04:00 --> Controller Class Initialized
INFO - 2016-05-18 17:04:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:04:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:04:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:04:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:04:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:04:00 --> Model Class Initialized
INFO - 2016-05-18 17:04:01 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:04:01 --> Mesaj token invalid
INFO - 2016-05-18 17:04:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:04:01 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:04:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:04:01 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 54
ERROR - 2016-05-18 17:04:01 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 73
INFO - 2016-05-18 17:04:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:04:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:04:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:04:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:04:01 --> Final output sent to browser
DEBUG - 2016-05-18 17:04:01 --> Total execution time: 0.0457
INFO - 2016-05-18 17:04:49 --> Config Class Initialized
INFO - 2016-05-18 17:04:49 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:04:49 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:04:49 --> Utf8 Class Initialized
INFO - 2016-05-18 17:04:49 --> URI Class Initialized
INFO - 2016-05-18 17:04:49 --> Router Class Initialized
INFO - 2016-05-18 17:04:49 --> Output Class Initialized
INFO - 2016-05-18 17:04:49 --> Security Class Initialized
DEBUG - 2016-05-18 17:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:04:49 --> CSRF cookie sent
INFO - 2016-05-18 17:04:49 --> Input Class Initialized
INFO - 2016-05-18 17:04:49 --> Language Class Initialized
INFO - 2016-05-18 17:04:49 --> Loader Class Initialized
INFO - 2016-05-18 17:04:49 --> Helper loaded: form_helper
INFO - 2016-05-18 17:04:49 --> Database Driver Class Initialized
INFO - 2016-05-18 17:04:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:04:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:04:49 --> Email Class Initialized
INFO - 2016-05-18 17:04:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:04:49 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:04:49 --> Helper loaded: language_helper
INFO - 2016-05-18 17:04:49 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:04:49 --> Model Class Initialized
INFO - 2016-05-18 17:04:49 --> Helper loaded: date_helper
INFO - 2016-05-18 17:04:49 --> Controller Class Initialized
INFO - 2016-05-18 17:04:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:04:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:04:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:04:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:04:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:04:49 --> Model Class Initialized
INFO - 2016-05-18 17:04:49 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:04:49 --> Mesaj token invalid
INFO - 2016-05-18 17:04:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:04:49 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:04:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:04:49 --> Mesaj nu are access
INFO - 2016-05-18 17:04:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:04:49 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:04:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:04:58 --> Config Class Initialized
INFO - 2016-05-18 17:04:58 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:04:58 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:04:58 --> Utf8 Class Initialized
INFO - 2016-05-18 17:04:58 --> URI Class Initialized
INFO - 2016-05-18 17:04:58 --> Router Class Initialized
INFO - 2016-05-18 17:04:58 --> Output Class Initialized
INFO - 2016-05-18 17:04:58 --> Security Class Initialized
DEBUG - 2016-05-18 17:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:04:58 --> CSRF cookie sent
INFO - 2016-05-18 17:04:58 --> Input Class Initialized
INFO - 2016-05-18 17:04:58 --> Language Class Initialized
INFO - 2016-05-18 17:04:58 --> Loader Class Initialized
INFO - 2016-05-18 17:04:58 --> Helper loaded: form_helper
INFO - 2016-05-18 17:04:58 --> Database Driver Class Initialized
INFO - 2016-05-18 17:04:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:04:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:04:58 --> Email Class Initialized
INFO - 2016-05-18 17:04:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:04:58 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:04:58 --> Helper loaded: language_helper
INFO - 2016-05-18 17:04:58 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:04:58 --> Model Class Initialized
INFO - 2016-05-18 17:04:58 --> Helper loaded: date_helper
INFO - 2016-05-18 17:04:58 --> Controller Class Initialized
INFO - 2016-05-18 17:04:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:04:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:04:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:04:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:04:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:04:58 --> Model Class Initialized
INFO - 2016-05-18 17:04:58 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:04:58 --> Mesaj token invalid
INFO - 2016-05-18 17:04:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:04:58 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:04:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:04:58 --> Mesaj nu are access
INFO - 2016-05-18 17:04:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:04:58 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:04:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:05:06 --> Config Class Initialized
INFO - 2016-05-18 17:05:06 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:05:06 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:05:06 --> Utf8 Class Initialized
INFO - 2016-05-18 17:05:06 --> URI Class Initialized
INFO - 2016-05-18 17:05:06 --> Router Class Initialized
INFO - 2016-05-18 17:05:06 --> Output Class Initialized
INFO - 2016-05-18 17:05:06 --> Security Class Initialized
DEBUG - 2016-05-18 17:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:05:06 --> CSRF cookie sent
INFO - 2016-05-18 17:05:06 --> Input Class Initialized
INFO - 2016-05-18 17:05:06 --> Language Class Initialized
INFO - 2016-05-18 17:05:06 --> Loader Class Initialized
INFO - 2016-05-18 17:05:06 --> Helper loaded: form_helper
INFO - 2016-05-18 17:05:06 --> Database Driver Class Initialized
INFO - 2016-05-18 17:05:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:05:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:05:06 --> Email Class Initialized
INFO - 2016-05-18 17:05:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:05:06 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:05:06 --> Helper loaded: language_helper
INFO - 2016-05-18 17:05:06 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:05:06 --> Model Class Initialized
INFO - 2016-05-18 17:05:06 --> Helper loaded: date_helper
INFO - 2016-05-18 17:05:06 --> Controller Class Initialized
INFO - 2016-05-18 17:05:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:05:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:05:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:05:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:05:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:05:06 --> Model Class Initialized
INFO - 2016-05-18 17:05:06 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:05:06 --> Mesaj token invalid
INFO - 2016-05-18 17:05:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:05:06 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:05:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:05:06 --> Mesaj nu are access
INFO - 2016-05-18 17:05:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:05:06 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:05:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:05:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?
			AND
				`_is_active` = 1' at line 6 - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_is_active` = 1
			
INFO - 2016-05-18 17:05:20 --> Config Class Initialized
INFO - 2016-05-18 17:05:20 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:05:20 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:05:20 --> Utf8 Class Initialized
INFO - 2016-05-18 17:05:20 --> URI Class Initialized
INFO - 2016-05-18 17:05:20 --> Router Class Initialized
INFO - 2016-05-18 17:05:20 --> Output Class Initialized
INFO - 2016-05-18 17:05:20 --> Security Class Initialized
DEBUG - 2016-05-18 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:05:20 --> CSRF cookie sent
INFO - 2016-05-18 17:05:20 --> Input Class Initialized
INFO - 2016-05-18 17:05:20 --> Language Class Initialized
INFO - 2016-05-18 17:05:20 --> Loader Class Initialized
INFO - 2016-05-18 17:05:20 --> Helper loaded: form_helper
INFO - 2016-05-18 17:05:20 --> Database Driver Class Initialized
INFO - 2016-05-18 17:05:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:05:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:05:20 --> Email Class Initialized
INFO - 2016-05-18 17:05:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:05:20 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:05:20 --> Helper loaded: language_helper
INFO - 2016-05-18 17:05:20 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:05:20 --> Model Class Initialized
INFO - 2016-05-18 17:05:20 --> Helper loaded: date_helper
INFO - 2016-05-18 17:05:20 --> Controller Class Initialized
INFO - 2016-05-18 17:05:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:05:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:05:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:05:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:05:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:05:20 --> Model Class Initialized
INFO - 2016-05-18 17:05:20 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:05:20 --> Mesaj token invalid
INFO - 2016-05-18 17:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:05:20 --> Mesaj nu are access
INFO - 2016-05-18 17:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:05:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?
			AND
				`_is_active` = 1' at line 6 - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_is_active` = 1
			
INFO - 2016-05-18 17:05:22 --> Config Class Initialized
INFO - 2016-05-18 17:05:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:05:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:05:22 --> Utf8 Class Initialized
INFO - 2016-05-18 17:05:22 --> URI Class Initialized
INFO - 2016-05-18 17:05:22 --> Router Class Initialized
INFO - 2016-05-18 17:05:22 --> Output Class Initialized
INFO - 2016-05-18 17:05:22 --> Security Class Initialized
DEBUG - 2016-05-18 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:05:22 --> CSRF cookie sent
INFO - 2016-05-18 17:05:22 --> Input Class Initialized
INFO - 2016-05-18 17:05:22 --> Language Class Initialized
INFO - 2016-05-18 17:05:22 --> Loader Class Initialized
INFO - 2016-05-18 17:05:22 --> Helper loaded: form_helper
INFO - 2016-05-18 17:05:22 --> Database Driver Class Initialized
INFO - 2016-05-18 17:05:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:05:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:05:22 --> Email Class Initialized
INFO - 2016-05-18 17:05:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:05:22 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:05:22 --> Helper loaded: language_helper
INFO - 2016-05-18 17:05:22 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:05:22 --> Model Class Initialized
INFO - 2016-05-18 17:05:22 --> Helper loaded: date_helper
INFO - 2016-05-18 17:05:22 --> Controller Class Initialized
INFO - 2016-05-18 17:05:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:05:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:05:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:05:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:05:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:05:22 --> Model Class Initialized
INFO - 2016-05-18 17:05:22 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:05:22 --> Mesaj token invalid
INFO - 2016-05-18 17:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:05:22 --> Mesaj nu are access
INFO - 2016-05-18 17:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
ERROR - 2016-05-18 17:05:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?
			AND
				`_is_active` = 1' at line 6 - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = ?
			AND
				`_is_active` = 1
			
INFO - 2016-05-18 17:07:07 --> Config Class Initialized
INFO - 2016-05-18 17:07:07 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:07:07 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:07:07 --> Utf8 Class Initialized
INFO - 2016-05-18 17:07:07 --> URI Class Initialized
INFO - 2016-05-18 17:07:07 --> Router Class Initialized
INFO - 2016-05-18 17:07:07 --> Output Class Initialized
INFO - 2016-05-18 17:07:07 --> Security Class Initialized
DEBUG - 2016-05-18 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:07:07 --> CSRF cookie sent
INFO - 2016-05-18 17:07:07 --> Input Class Initialized
INFO - 2016-05-18 17:07:07 --> Language Class Initialized
INFO - 2016-05-18 17:07:07 --> Loader Class Initialized
INFO - 2016-05-18 17:07:07 --> Helper loaded: form_helper
INFO - 2016-05-18 17:07:07 --> Database Driver Class Initialized
INFO - 2016-05-18 17:07:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:07:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:07:07 --> Email Class Initialized
INFO - 2016-05-18 17:07:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:07:07 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:07:07 --> Helper loaded: language_helper
INFO - 2016-05-18 17:07:07 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:07:07 --> Model Class Initialized
INFO - 2016-05-18 17:07:07 --> Helper loaded: date_helper
INFO - 2016-05-18 17:07:07 --> Controller Class Initialized
INFO - 2016-05-18 17:07:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:07:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:07:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:07:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:07:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:07:07 --> Model Class Initialized
ERROR - 2016-05-18 17:07:07 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/controllers/Diabet.php 60
ERROR - 2016-05-18 17:07:07 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 17:07:07 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 17:07:07 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:07:15 --> Config Class Initialized
INFO - 2016-05-18 17:07:15 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:07:15 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:07:15 --> Utf8 Class Initialized
INFO - 2016-05-18 17:07:15 --> URI Class Initialized
INFO - 2016-05-18 17:07:15 --> Router Class Initialized
INFO - 2016-05-18 17:07:15 --> Output Class Initialized
INFO - 2016-05-18 17:07:15 --> Security Class Initialized
DEBUG - 2016-05-18 17:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:07:15 --> CSRF cookie sent
INFO - 2016-05-18 17:07:15 --> Input Class Initialized
INFO - 2016-05-18 17:07:15 --> Language Class Initialized
INFO - 2016-05-18 17:07:15 --> Loader Class Initialized
INFO - 2016-05-18 17:07:15 --> Helper loaded: form_helper
INFO - 2016-05-18 17:07:15 --> Database Driver Class Initialized
INFO - 2016-05-18 17:07:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:07:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:07:15 --> Email Class Initialized
INFO - 2016-05-18 17:07:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:07:15 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:07:15 --> Helper loaded: language_helper
INFO - 2016-05-18 17:07:15 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:07:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:07:15 --> Model Class Initialized
INFO - 2016-05-18 17:07:15 --> Helper loaded: date_helper
INFO - 2016-05-18 17:07:15 --> Controller Class Initialized
INFO - 2016-05-18 17:07:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:07:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:07:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:07:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:07:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:07:15 --> Model Class Initialized
ERROR - 2016-05-18 17:07:15 --> Severity: Notice --> Undefined variable: array /home/demis/www/platformadiabet/application/controllers/Diabet.php 60
ERROR - 2016-05-18 17:07:15 --> Severity: Error --> Function name must be a string /home/demis/www/platformadiabet/application/controllers/Diabet.php 60
INFO - 2016-05-18 17:07:21 --> Config Class Initialized
INFO - 2016-05-18 17:07:21 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:07:21 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:07:21 --> Utf8 Class Initialized
INFO - 2016-05-18 17:07:21 --> URI Class Initialized
INFO - 2016-05-18 17:07:21 --> Router Class Initialized
INFO - 2016-05-18 17:07:21 --> Output Class Initialized
INFO - 2016-05-18 17:07:21 --> Security Class Initialized
DEBUG - 2016-05-18 17:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:07:21 --> CSRF cookie sent
INFO - 2016-05-18 17:07:21 --> Input Class Initialized
INFO - 2016-05-18 17:07:21 --> Language Class Initialized
INFO - 2016-05-18 17:07:21 --> Loader Class Initialized
INFO - 2016-05-18 17:07:21 --> Helper loaded: form_helper
INFO - 2016-05-18 17:07:21 --> Database Driver Class Initialized
INFO - 2016-05-18 17:07:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:07:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:07:21 --> Email Class Initialized
INFO - 2016-05-18 17:07:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:07:21 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:07:21 --> Helper loaded: language_helper
INFO - 2016-05-18 17:07:21 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:07:21 --> Model Class Initialized
INFO - 2016-05-18 17:07:21 --> Helper loaded: date_helper
INFO - 2016-05-18 17:07:21 --> Controller Class Initialized
INFO - 2016-05-18 17:07:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:07:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:07:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:07:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:07:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:07:21 --> Model Class Initialized
ERROR - 2016-05-18 17:07:21 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 17:07:21 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 17:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:08:52 --> Config Class Initialized
INFO - 2016-05-18 17:08:52 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:08:52 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:08:52 --> Utf8 Class Initialized
INFO - 2016-05-18 17:08:52 --> URI Class Initialized
INFO - 2016-05-18 17:08:52 --> Router Class Initialized
INFO - 2016-05-18 17:08:52 --> Output Class Initialized
INFO - 2016-05-18 17:08:52 --> Security Class Initialized
DEBUG - 2016-05-18 17:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:08:52 --> CSRF cookie sent
INFO - 2016-05-18 17:08:52 --> Input Class Initialized
INFO - 2016-05-18 17:08:52 --> Language Class Initialized
ERROR - 2016-05-18 17:08:52 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /home/demis/www/platformadiabet/application/controllers/Diabet.php 63
INFO - 2016-05-18 17:09:14 --> Config Class Initialized
INFO - 2016-05-18 17:09:14 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:09:14 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:09:14 --> Utf8 Class Initialized
INFO - 2016-05-18 17:09:14 --> URI Class Initialized
INFO - 2016-05-18 17:09:14 --> Router Class Initialized
INFO - 2016-05-18 17:09:14 --> Output Class Initialized
INFO - 2016-05-18 17:09:14 --> Security Class Initialized
DEBUG - 2016-05-18 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:09:14 --> CSRF cookie sent
INFO - 2016-05-18 17:09:14 --> Input Class Initialized
INFO - 2016-05-18 17:09:14 --> Language Class Initialized
ERROR - 2016-05-18 17:09:14 --> Severity: Notice --> Undefined property: Diabet::$load /home/demis/www/platformadiabet/application/controllers/Diabet.php 10
ERROR - 2016-05-18 17:09:14 --> Severity: Error --> Call to a member function helper() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 10
INFO - 2016-05-18 17:09:36 --> Config Class Initialized
INFO - 2016-05-18 17:09:36 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:09:36 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:09:36 --> Utf8 Class Initialized
INFO - 2016-05-18 17:09:36 --> URI Class Initialized
INFO - 2016-05-18 17:09:36 --> Router Class Initialized
INFO - 2016-05-18 17:09:36 --> Output Class Initialized
INFO - 2016-05-18 17:09:36 --> Security Class Initialized
DEBUG - 2016-05-18 17:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:09:36 --> CSRF cookie sent
INFO - 2016-05-18 17:09:36 --> Input Class Initialized
INFO - 2016-05-18 17:09:36 --> Language Class Initialized
INFO - 2016-05-18 17:09:36 --> Loader Class Initialized
INFO - 2016-05-18 17:09:36 --> Helper loaded: form_helper
INFO - 2016-05-18 17:09:36 --> Database Driver Class Initialized
INFO - 2016-05-18 17:09:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:09:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:09:36 --> Email Class Initialized
INFO - 2016-05-18 17:09:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:09:36 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:09:36 --> Helper loaded: language_helper
INFO - 2016-05-18 17:09:36 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:09:36 --> Model Class Initialized
INFO - 2016-05-18 17:09:36 --> Helper loaded: date_helper
INFO - 2016-05-18 17:09:36 --> Controller Class Initialized
INFO - 2016-05-18 17:09:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:09:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:09:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:09:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:09:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:09:36 --> Model Class Initialized
ERROR - 2016-05-18 17:09:36 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 17:09:36 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 17:09:36 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
ERROR - 2016-05-18 17:09:36 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 54
ERROR - 2016-05-18 17:09:36 --> Severity: Notice --> Use of undefined constant USER_ID - assumed 'USER_ID' /home/demis/www/platformadiabet/application/models/Diabet_model.php 73
INFO - 2016-05-18 17:09:36 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:09:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:09:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:09:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:09:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:09:36 --> Final output sent to browser
DEBUG - 2016-05-18 17:09:36 --> Total execution time: 0.0559
INFO - 2016-05-18 17:09:48 --> Config Class Initialized
INFO - 2016-05-18 17:09:48 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:09:48 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:09:48 --> Utf8 Class Initialized
INFO - 2016-05-18 17:09:48 --> URI Class Initialized
INFO - 2016-05-18 17:09:48 --> Router Class Initialized
INFO - 2016-05-18 17:09:48 --> Output Class Initialized
INFO - 2016-05-18 17:09:48 --> Security Class Initialized
DEBUG - 2016-05-18 17:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:09:48 --> CSRF cookie sent
INFO - 2016-05-18 17:09:48 --> Input Class Initialized
INFO - 2016-05-18 17:09:48 --> Language Class Initialized
INFO - 2016-05-18 17:09:48 --> Loader Class Initialized
INFO - 2016-05-18 17:09:48 --> Helper loaded: form_helper
INFO - 2016-05-18 17:09:48 --> Database Driver Class Initialized
INFO - 2016-05-18 17:09:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:09:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:09:48 --> Email Class Initialized
INFO - 2016-05-18 17:09:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:09:48 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:09:48 --> Helper loaded: language_helper
INFO - 2016-05-18 17:09:48 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:09:48 --> Model Class Initialized
INFO - 2016-05-18 17:09:48 --> Helper loaded: date_helper
INFO - 2016-05-18 17:09:48 --> Controller Class Initialized
INFO - 2016-05-18 17:09:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:09:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:09:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:09:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:09:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:09:48 --> Model Class Initialized
ERROR - 2016-05-18 17:09:48 --> Severity: Notice --> Undefined variable: error_title /home/demis/www/platformadiabet/application/views/errors/error_general.php 5
ERROR - 2016-05-18 17:09:48 --> Severity: Notice --> Undefined variable: error_message /home/demis/www/platformadiabet/application/views/errors/error_general.php 6
INFO - 2016-05-18 17:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:09:48 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:09:48 --> Mesaj token invalid
INFO - 2016-05-18 17:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:09:59 --> Config Class Initialized
INFO - 2016-05-18 17:09:59 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:09:59 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:09:59 --> Utf8 Class Initialized
INFO - 2016-05-18 17:09:59 --> URI Class Initialized
INFO - 2016-05-18 17:09:59 --> Router Class Initialized
INFO - 2016-05-18 17:09:59 --> Output Class Initialized
INFO - 2016-05-18 17:09:59 --> Security Class Initialized
DEBUG - 2016-05-18 17:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:09:59 --> CSRF cookie sent
INFO - 2016-05-18 17:09:59 --> Input Class Initialized
INFO - 2016-05-18 17:09:59 --> Language Class Initialized
INFO - 2016-05-18 17:09:59 --> Loader Class Initialized
INFO - 2016-05-18 17:09:59 --> Helper loaded: form_helper
INFO - 2016-05-18 17:09:59 --> Database Driver Class Initialized
INFO - 2016-05-18 17:09:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:09:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:09:59 --> Email Class Initialized
INFO - 2016-05-18 17:09:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:09:59 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:09:59 --> Helper loaded: language_helper
INFO - 2016-05-18 17:09:59 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:09:59 --> Model Class Initialized
INFO - 2016-05-18 17:09:59 --> Helper loaded: date_helper
INFO - 2016-05-18 17:09:59 --> Controller Class Initialized
INFO - 2016-05-18 17:09:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:09:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:09:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:09:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:09:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:09:59 --> Model Class Initialized
INFO - 2016-05-18 17:09:59 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:09:59 --> Mesaj token invalid
INFO - 2016-05-18 17:09:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:09:59 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:09:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:10:29 --> Config Class Initialized
INFO - 2016-05-18 17:10:29 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:10:29 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:10:29 --> Utf8 Class Initialized
INFO - 2016-05-18 17:10:29 --> URI Class Initialized
INFO - 2016-05-18 17:10:29 --> Router Class Initialized
INFO - 2016-05-18 17:10:29 --> Output Class Initialized
INFO - 2016-05-18 17:10:29 --> Security Class Initialized
DEBUG - 2016-05-18 17:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:10:29 --> CSRF cookie sent
INFO - 2016-05-18 17:10:29 --> Input Class Initialized
INFO - 2016-05-18 17:10:29 --> Language Class Initialized
INFO - 2016-05-18 17:10:29 --> Loader Class Initialized
INFO - 2016-05-18 17:10:29 --> Helper loaded: form_helper
INFO - 2016-05-18 17:10:29 --> Database Driver Class Initialized
INFO - 2016-05-18 17:10:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:10:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:10:29 --> Email Class Initialized
INFO - 2016-05-18 17:10:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:10:29 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:10:29 --> Helper loaded: language_helper
INFO - 2016-05-18 17:10:29 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:10:29 --> Model Class Initialized
INFO - 2016-05-18 17:10:29 --> Helper loaded: date_helper
INFO - 2016-05-18 17:10:29 --> Controller Class Initialized
INFO - 2016-05-18 17:10:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:10:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:10:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:10:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:10:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:10:29 --> Model Class Initialized
INFO - 2016-05-18 17:10:29 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:10:29 --> Mesaj token invalid
INFO - 2016-05-18 17:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:10:30 --> Config Class Initialized
INFO - 2016-05-18 17:10:30 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:10:30 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:10:30 --> Utf8 Class Initialized
INFO - 2016-05-18 17:10:30 --> URI Class Initialized
INFO - 2016-05-18 17:10:30 --> Router Class Initialized
INFO - 2016-05-18 17:10:30 --> Output Class Initialized
INFO - 2016-05-18 17:10:30 --> Security Class Initialized
DEBUG - 2016-05-18 17:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:10:30 --> CSRF cookie sent
INFO - 2016-05-18 17:10:30 --> Input Class Initialized
INFO - 2016-05-18 17:10:30 --> Language Class Initialized
INFO - 2016-05-18 17:10:30 --> Loader Class Initialized
INFO - 2016-05-18 17:10:30 --> Helper loaded: form_helper
INFO - 2016-05-18 17:10:30 --> Database Driver Class Initialized
INFO - 2016-05-18 17:10:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:10:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:10:30 --> Email Class Initialized
INFO - 2016-05-18 17:10:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:10:30 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:10:30 --> Helper loaded: language_helper
INFO - 2016-05-18 17:10:30 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:10:30 --> Model Class Initialized
INFO - 2016-05-18 17:10:30 --> Helper loaded: date_helper
INFO - 2016-05-18 17:10:30 --> Controller Class Initialized
INFO - 2016-05-18 17:10:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:10:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:10:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:10:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:10:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:10:30 --> Model Class Initialized
INFO - 2016-05-18 17:10:30 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:10:30 --> Mesaj token invalid
INFO - 2016-05-18 17:10:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:10:30 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:10:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:16:34 --> Config Class Initialized
INFO - 2016-05-18 17:16:34 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:16:34 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:16:34 --> Utf8 Class Initialized
INFO - 2016-05-18 17:16:34 --> URI Class Initialized
INFO - 2016-05-18 17:16:34 --> Router Class Initialized
INFO - 2016-05-18 17:16:34 --> Output Class Initialized
INFO - 2016-05-18 17:16:34 --> Security Class Initialized
DEBUG - 2016-05-18 17:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:16:34 --> CSRF cookie sent
INFO - 2016-05-18 17:16:34 --> Input Class Initialized
INFO - 2016-05-18 17:16:34 --> Language Class Initialized
INFO - 2016-05-18 17:16:34 --> Loader Class Initialized
INFO - 2016-05-18 17:16:34 --> Helper loaded: form_helper
INFO - 2016-05-18 17:16:34 --> Database Driver Class Initialized
INFO - 2016-05-18 17:16:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:16:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:16:34 --> Email Class Initialized
INFO - 2016-05-18 17:16:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:16:34 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:16:34 --> Helper loaded: language_helper
INFO - 2016-05-18 17:16:34 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:16:34 --> Model Class Initialized
INFO - 2016-05-18 17:16:34 --> Helper loaded: date_helper
INFO - 2016-05-18 17:16:34 --> Controller Class Initialized
INFO - 2016-05-18 17:16:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:16:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:16:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:16:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:16:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:16:34 --> Model Class Initialized
INFO - 2016-05-18 17:16:34 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:16:34 --> Mesaj token invalid
INFO - 2016-05-18 17:16:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:16:34 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:16:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:16:39 --> Config Class Initialized
INFO - 2016-05-18 17:16:39 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:16:39 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:16:39 --> Utf8 Class Initialized
INFO - 2016-05-18 17:16:39 --> URI Class Initialized
INFO - 2016-05-18 17:16:39 --> Router Class Initialized
INFO - 2016-05-18 17:16:39 --> Output Class Initialized
INFO - 2016-05-18 17:16:39 --> Security Class Initialized
DEBUG - 2016-05-18 17:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:16:39 --> CSRF cookie sent
INFO - 2016-05-18 17:16:39 --> Input Class Initialized
INFO - 2016-05-18 17:16:39 --> Language Class Initialized
INFO - 2016-05-18 17:16:39 --> Loader Class Initialized
INFO - 2016-05-18 17:16:39 --> Helper loaded: form_helper
INFO - 2016-05-18 17:16:39 --> Database Driver Class Initialized
INFO - 2016-05-18 17:16:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:16:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:16:39 --> Email Class Initialized
INFO - 2016-05-18 17:16:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:16:39 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:16:39 --> Helper loaded: language_helper
INFO - 2016-05-18 17:16:39 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:16:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:16:39 --> Model Class Initialized
INFO - 2016-05-18 17:16:39 --> Helper loaded: date_helper
INFO - 2016-05-18 17:16:39 --> Controller Class Initialized
INFO - 2016-05-18 17:16:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:16:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:16:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:16:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:16:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:16:39 --> Model Class Initialized
INFO - 2016-05-18 17:16:39 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:16:39 --> Mesaj nu are access
INFO - 2016-05-18 17:16:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:16:39 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:16:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:16:57 --> Config Class Initialized
INFO - 2016-05-18 17:16:57 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:16:57 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:16:57 --> Utf8 Class Initialized
INFO - 2016-05-18 17:16:57 --> URI Class Initialized
INFO - 2016-05-18 17:16:57 --> Router Class Initialized
INFO - 2016-05-18 17:16:57 --> Output Class Initialized
INFO - 2016-05-18 17:16:57 --> Security Class Initialized
DEBUG - 2016-05-18 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:16:57 --> CSRF cookie sent
INFO - 2016-05-18 17:16:57 --> Input Class Initialized
INFO - 2016-05-18 17:16:57 --> Language Class Initialized
INFO - 2016-05-18 17:16:57 --> Loader Class Initialized
INFO - 2016-05-18 17:16:57 --> Helper loaded: form_helper
INFO - 2016-05-18 17:16:57 --> Database Driver Class Initialized
INFO - 2016-05-18 17:16:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:16:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:16:57 --> Email Class Initialized
INFO - 2016-05-18 17:16:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:16:57 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:16:57 --> Helper loaded: language_helper
INFO - 2016-05-18 17:16:57 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:16:57 --> Model Class Initialized
INFO - 2016-05-18 17:16:57 --> Helper loaded: date_helper
INFO - 2016-05-18 17:16:57 --> Controller Class Initialized
INFO - 2016-05-18 17:16:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:16:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:16:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:16:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:16:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:16:57 --> Model Class Initialized
INFO - 2016-05-18 17:16:57 --> Helper loaded: languages_helper
ERROR - 2016-05-18 17:16:57 --> Mesaj nu are access
INFO - 2016-05-18 17:16:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:16:57 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-18 17:16:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:17:04 --> Config Class Initialized
INFO - 2016-05-18 17:17:04 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:17:04 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:17:04 --> Utf8 Class Initialized
INFO - 2016-05-18 17:17:04 --> URI Class Initialized
INFO - 2016-05-18 17:17:04 --> Router Class Initialized
INFO - 2016-05-18 17:17:04 --> Output Class Initialized
INFO - 2016-05-18 17:17:04 --> Security Class Initialized
DEBUG - 2016-05-18 17:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:17:04 --> CSRF cookie sent
INFO - 2016-05-18 17:17:04 --> Input Class Initialized
INFO - 2016-05-18 17:17:04 --> Language Class Initialized
INFO - 2016-05-18 17:17:04 --> Loader Class Initialized
INFO - 2016-05-18 17:17:04 --> Helper loaded: form_helper
INFO - 2016-05-18 17:17:04 --> Database Driver Class Initialized
INFO - 2016-05-18 17:17:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:17:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:17:04 --> Email Class Initialized
INFO - 2016-05-18 17:17:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:17:04 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:17:04 --> Helper loaded: language_helper
INFO - 2016-05-18 17:17:04 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:17:04 --> Model Class Initialized
INFO - 2016-05-18 17:17:04 --> Helper loaded: date_helper
INFO - 2016-05-18 17:17:04 --> Controller Class Initialized
INFO - 2016-05-18 17:17:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:17:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:17:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:17:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:17:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:17:04 --> Model Class Initialized
INFO - 2016-05-18 17:17:04 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:17:04 --> Final output sent to browser
DEBUG - 2016-05-18 17:17:04 --> Total execution time: 0.0440
INFO - 2016-05-18 17:17:17 --> Config Class Initialized
INFO - 2016-05-18 17:17:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:17:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:17:17 --> Utf8 Class Initialized
INFO - 2016-05-18 17:17:17 --> URI Class Initialized
INFO - 2016-05-18 17:17:17 --> Router Class Initialized
INFO - 2016-05-18 17:17:17 --> Output Class Initialized
INFO - 2016-05-18 17:17:17 --> Security Class Initialized
DEBUG - 2016-05-18 17:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:17:17 --> CSRF cookie sent
INFO - 2016-05-18 17:17:17 --> Input Class Initialized
INFO - 2016-05-18 17:17:17 --> Language Class Initialized
INFO - 2016-05-18 17:17:17 --> Loader Class Initialized
INFO - 2016-05-18 17:17:17 --> Helper loaded: form_helper
INFO - 2016-05-18 17:17:17 --> Database Driver Class Initialized
INFO - 2016-05-18 17:17:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:17:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:17:17 --> Email Class Initialized
INFO - 2016-05-18 17:17:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:17:17 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:17:17 --> Helper loaded: language_helper
INFO - 2016-05-18 17:17:17 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:17:17 --> Model Class Initialized
INFO - 2016-05-18 17:17:17 --> Helper loaded: date_helper
INFO - 2016-05-18 17:17:17 --> Controller Class Initialized
INFO - 2016-05-18 17:17:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:17:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:17:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:17:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:17:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:17:17 --> Model Class Initialized
INFO - 2016-05-18 17:17:17 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:17:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:17:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:17:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:17:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:17:17 --> Final output sent to browser
DEBUG - 2016-05-18 17:17:17 --> Total execution time: 0.0623
INFO - 2016-05-18 17:29:34 --> Config Class Initialized
INFO - 2016-05-18 17:29:34 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:29:34 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:29:34 --> Utf8 Class Initialized
INFO - 2016-05-18 17:29:34 --> URI Class Initialized
INFO - 2016-05-18 17:29:34 --> Router Class Initialized
INFO - 2016-05-18 17:29:34 --> Output Class Initialized
INFO - 2016-05-18 17:29:34 --> Security Class Initialized
DEBUG - 2016-05-18 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:29:34 --> CSRF cookie sent
INFO - 2016-05-18 17:29:34 --> Input Class Initialized
INFO - 2016-05-18 17:29:34 --> Language Class Initialized
INFO - 2016-05-18 17:29:34 --> Loader Class Initialized
INFO - 2016-05-18 17:29:34 --> Helper loaded: form_helper
INFO - 2016-05-18 17:29:34 --> Database Driver Class Initialized
INFO - 2016-05-18 17:29:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:29:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:29:34 --> Email Class Initialized
INFO - 2016-05-18 17:29:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:29:34 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:29:34 --> Helper loaded: language_helper
INFO - 2016-05-18 17:29:34 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:29:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:29:34 --> Model Class Initialized
INFO - 2016-05-18 17:29:34 --> Helper loaded: date_helper
INFO - 2016-05-18 17:29:34 --> Controller Class Initialized
INFO - 2016-05-18 17:29:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:29:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:29:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:29:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:29:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:29:34 --> Model Class Initialized
INFO - 2016-05-18 17:29:34 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:29:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:29:34 --> Final output sent to browser
DEBUG - 2016-05-18 17:29:34 --> Total execution time: 0.0572
INFO - 2016-05-18 17:29:54 --> Config Class Initialized
INFO - 2016-05-18 17:29:54 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:29:54 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:29:54 --> Utf8 Class Initialized
INFO - 2016-05-18 17:29:54 --> URI Class Initialized
INFO - 2016-05-18 17:29:54 --> Router Class Initialized
INFO - 2016-05-18 17:29:54 --> Output Class Initialized
INFO - 2016-05-18 17:29:54 --> Security Class Initialized
DEBUG - 2016-05-18 17:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:29:54 --> CSRF cookie sent
INFO - 2016-05-18 17:29:54 --> Input Class Initialized
INFO - 2016-05-18 17:29:54 --> Language Class Initialized
INFO - 2016-05-18 17:29:54 --> Loader Class Initialized
INFO - 2016-05-18 17:29:54 --> Helper loaded: form_helper
INFO - 2016-05-18 17:29:54 --> Database Driver Class Initialized
INFO - 2016-05-18 17:29:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:29:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:29:54 --> Email Class Initialized
INFO - 2016-05-18 17:29:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:29:54 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:29:54 --> Helper loaded: language_helper
INFO - 2016-05-18 17:29:54 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:29:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:29:54 --> Model Class Initialized
INFO - 2016-05-18 17:29:54 --> Helper loaded: date_helper
INFO - 2016-05-18 17:29:54 --> Controller Class Initialized
INFO - 2016-05-18 17:29:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:29:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:29:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:29:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:29:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:29:54 --> Model Class Initialized
INFO - 2016-05-18 17:29:54 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:29:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:29:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:29:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:29:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:29:54 --> Final output sent to browser
DEBUG - 2016-05-18 17:29:54 --> Total execution time: 0.0273
INFO - 2016-05-18 17:46:17 --> Config Class Initialized
INFO - 2016-05-18 17:46:17 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:46:17 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:46:17 --> Utf8 Class Initialized
INFO - 2016-05-18 17:46:17 --> URI Class Initialized
INFO - 2016-05-18 17:46:17 --> Router Class Initialized
INFO - 2016-05-18 17:46:17 --> Output Class Initialized
INFO - 2016-05-18 17:46:17 --> Security Class Initialized
DEBUG - 2016-05-18 17:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:46:17 --> CSRF cookie sent
INFO - 2016-05-18 17:46:17 --> Input Class Initialized
INFO - 2016-05-18 17:46:17 --> Language Class Initialized
INFO - 2016-05-18 17:46:17 --> Loader Class Initialized
INFO - 2016-05-18 17:46:17 --> Helper loaded: form_helper
INFO - 2016-05-18 17:46:17 --> Database Driver Class Initialized
INFO - 2016-05-18 17:46:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:46:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:46:17 --> Email Class Initialized
INFO - 2016-05-18 17:46:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:46:17 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:46:17 --> Helper loaded: language_helper
INFO - 2016-05-18 17:46:17 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:46:17 --> Model Class Initialized
INFO - 2016-05-18 17:46:17 --> Helper loaded: date_helper
INFO - 2016-05-18 17:46:17 --> Controller Class Initialized
INFO - 2016-05-18 17:46:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:46:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:46:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:46:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:46:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:46:17 --> Model Class Initialized
INFO - 2016-05-18 17:46:17 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:46:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:46:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 17:46:17 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/views/user_area/access.php 44
INFO - 2016-05-18 17:46:40 --> Config Class Initialized
INFO - 2016-05-18 17:46:40 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:46:40 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:46:40 --> Utf8 Class Initialized
INFO - 2016-05-18 17:46:40 --> URI Class Initialized
INFO - 2016-05-18 17:46:40 --> Router Class Initialized
INFO - 2016-05-18 17:46:40 --> Output Class Initialized
INFO - 2016-05-18 17:46:40 --> Security Class Initialized
DEBUG - 2016-05-18 17:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:46:40 --> CSRF cookie sent
INFO - 2016-05-18 17:46:40 --> Input Class Initialized
INFO - 2016-05-18 17:46:40 --> Language Class Initialized
INFO - 2016-05-18 17:46:40 --> Loader Class Initialized
INFO - 2016-05-18 17:46:40 --> Helper loaded: form_helper
INFO - 2016-05-18 17:46:40 --> Database Driver Class Initialized
INFO - 2016-05-18 17:46:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:46:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:46:40 --> Email Class Initialized
INFO - 2016-05-18 17:46:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:46:40 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:46:40 --> Helper loaded: language_helper
INFO - 2016-05-18 17:46:40 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:46:40 --> Model Class Initialized
INFO - 2016-05-18 17:46:40 --> Helper loaded: date_helper
INFO - 2016-05-18 17:46:40 --> Controller Class Initialized
INFO - 2016-05-18 17:46:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:46:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:46:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:46:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:46:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:46:40 --> Model Class Initialized
INFO - 2016-05-18 17:46:40 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:46:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:46:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:51:09 --> Config Class Initialized
INFO - 2016-05-18 17:51:09 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:51:09 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:51:09 --> Utf8 Class Initialized
INFO - 2016-05-18 17:51:09 --> URI Class Initialized
INFO - 2016-05-18 17:51:09 --> Router Class Initialized
INFO - 2016-05-18 17:51:09 --> Output Class Initialized
INFO - 2016-05-18 17:51:09 --> Security Class Initialized
DEBUG - 2016-05-18 17:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:51:09 --> CSRF cookie sent
INFO - 2016-05-18 17:51:09 --> Input Class Initialized
INFO - 2016-05-18 17:51:09 --> Language Class Initialized
INFO - 2016-05-18 17:51:09 --> Loader Class Initialized
INFO - 2016-05-18 17:51:09 --> Helper loaded: form_helper
INFO - 2016-05-18 17:51:09 --> Database Driver Class Initialized
INFO - 2016-05-18 17:51:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:51:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:51:09 --> Email Class Initialized
INFO - 2016-05-18 17:51:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:51:09 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:51:09 --> Helper loaded: language_helper
INFO - 2016-05-18 17:51:09 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:51:09 --> Model Class Initialized
INFO - 2016-05-18 17:51:09 --> Helper loaded: date_helper
INFO - 2016-05-18 17:51:09 --> Controller Class Initialized
INFO - 2016-05-18 17:51:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:51:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:51:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:51:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:51:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:51:09 --> Model Class Initialized
INFO - 2016-05-18 17:51:09 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:51:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:51:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:51:22 --> Config Class Initialized
INFO - 2016-05-18 17:51:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:51:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:51:22 --> Utf8 Class Initialized
INFO - 2016-05-18 17:51:22 --> URI Class Initialized
INFO - 2016-05-18 17:51:22 --> Router Class Initialized
INFO - 2016-05-18 17:51:22 --> Output Class Initialized
INFO - 2016-05-18 17:51:22 --> Security Class Initialized
DEBUG - 2016-05-18 17:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:51:22 --> CSRF cookie sent
INFO - 2016-05-18 17:51:22 --> Input Class Initialized
INFO - 2016-05-18 17:51:22 --> Language Class Initialized
INFO - 2016-05-18 17:51:22 --> Loader Class Initialized
INFO - 2016-05-18 17:51:22 --> Helper loaded: form_helper
INFO - 2016-05-18 17:51:22 --> Database Driver Class Initialized
INFO - 2016-05-18 17:51:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:51:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:51:22 --> Email Class Initialized
INFO - 2016-05-18 17:51:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:51:22 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:51:22 --> Helper loaded: language_helper
INFO - 2016-05-18 17:51:22 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:51:22 --> Model Class Initialized
INFO - 2016-05-18 17:51:22 --> Helper loaded: date_helper
INFO - 2016-05-18 17:51:22 --> Controller Class Initialized
INFO - 2016-05-18 17:51:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:51:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:51:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:51:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:51:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:51:22 --> Model Class Initialized
INFO - 2016-05-18 17:51:22 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:51:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:51:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 17:51:22 --> Severity: Notice --> Undefined index: family /home/demis/www/platformadiabet/application/views/user_area/access.php 50
INFO - 2016-05-18 17:51:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:51:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:51:22 --> Final output sent to browser
DEBUG - 2016-05-18 17:51:22 --> Total execution time: 0.0260
INFO - 2016-05-18 17:52:30 --> Config Class Initialized
INFO - 2016-05-18 17:52:30 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:52:30 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:52:30 --> Utf8 Class Initialized
INFO - 2016-05-18 17:52:30 --> URI Class Initialized
INFO - 2016-05-18 17:52:30 --> Router Class Initialized
INFO - 2016-05-18 17:52:30 --> Output Class Initialized
INFO - 2016-05-18 17:52:30 --> Security Class Initialized
DEBUG - 2016-05-18 17:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:52:30 --> CSRF cookie sent
INFO - 2016-05-18 17:52:30 --> Input Class Initialized
INFO - 2016-05-18 17:52:30 --> Language Class Initialized
INFO - 2016-05-18 17:52:30 --> Loader Class Initialized
INFO - 2016-05-18 17:52:30 --> Helper loaded: form_helper
INFO - 2016-05-18 17:52:30 --> Database Driver Class Initialized
INFO - 2016-05-18 17:52:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:52:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:52:30 --> Email Class Initialized
INFO - 2016-05-18 17:52:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:52:30 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:52:30 --> Helper loaded: language_helper
INFO - 2016-05-18 17:52:30 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:52:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:52:30 --> Model Class Initialized
INFO - 2016-05-18 17:52:30 --> Helper loaded: date_helper
INFO - 2016-05-18 17:52:30 --> Controller Class Initialized
INFO - 2016-05-18 17:52:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:52:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:52:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:52:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:52:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:52:30 --> Model Class Initialized
INFO - 2016-05-18 17:52:30 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:52:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:52:30 --> Final output sent to browser
DEBUG - 2016-05-18 17:52:30 --> Total execution time: 0.0174
INFO - 2016-05-18 17:55:09 --> Config Class Initialized
INFO - 2016-05-18 17:55:09 --> Hooks Class Initialized
DEBUG - 2016-05-18 17:55:09 --> UTF-8 Support Enabled
INFO - 2016-05-18 17:55:09 --> Utf8 Class Initialized
INFO - 2016-05-18 17:55:09 --> URI Class Initialized
INFO - 2016-05-18 17:55:09 --> Router Class Initialized
INFO - 2016-05-18 17:55:09 --> Output Class Initialized
INFO - 2016-05-18 17:55:09 --> Security Class Initialized
DEBUG - 2016-05-18 17:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 17:55:09 --> CSRF cookie sent
INFO - 2016-05-18 17:55:09 --> Input Class Initialized
INFO - 2016-05-18 17:55:09 --> Language Class Initialized
INFO - 2016-05-18 17:55:09 --> Loader Class Initialized
INFO - 2016-05-18 17:55:09 --> Helper loaded: form_helper
INFO - 2016-05-18 17:55:09 --> Database Driver Class Initialized
INFO - 2016-05-18 17:55:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 17:55:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 17:55:09 --> Email Class Initialized
INFO - 2016-05-18 17:55:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 17:55:09 --> Helper loaded: cookie_helper
INFO - 2016-05-18 17:55:09 --> Helper loaded: language_helper
INFO - 2016-05-18 17:55:09 --> Helper loaded: url_helper
DEBUG - 2016-05-18 17:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 17:55:09 --> Model Class Initialized
INFO - 2016-05-18 17:55:09 --> Helper loaded: date_helper
INFO - 2016-05-18 17:55:09 --> Controller Class Initialized
INFO - 2016-05-18 17:55:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 17:55:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 17:55:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 17:55:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 17:55:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 17:55:09 --> Model Class Initialized
INFO - 2016-05-18 17:55:09 --> Helper loaded: languages_helper
INFO - 2016-05-18 17:55:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 17:55:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-18 17:55:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-18 17:55:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-18 17:55:09 --> Final output sent to browser
DEBUG - 2016-05-18 17:55:09 --> Total execution time: 0.0583
INFO - 2016-05-18 18:04:22 --> Config Class Initialized
INFO - 2016-05-18 18:04:22 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:04:22 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:04:22 --> Utf8 Class Initialized
INFO - 2016-05-18 18:04:22 --> URI Class Initialized
INFO - 2016-05-18 18:04:22 --> Router Class Initialized
INFO - 2016-05-18 18:04:22 --> Output Class Initialized
INFO - 2016-05-18 18:04:22 --> Security Class Initialized
DEBUG - 2016-05-18 18:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:04:22 --> CSRF cookie sent
INFO - 2016-05-18 18:04:22 --> Input Class Initialized
INFO - 2016-05-18 18:04:22 --> Language Class Initialized
INFO - 2016-05-18 18:04:22 --> Loader Class Initialized
INFO - 2016-05-18 18:04:22 --> Helper loaded: form_helper
INFO - 2016-05-18 18:04:22 --> Database Driver Class Initialized
INFO - 2016-05-18 18:04:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 18:04:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 18:04:22 --> Email Class Initialized
INFO - 2016-05-18 18:04:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 18:04:22 --> Helper loaded: cookie_helper
INFO - 2016-05-18 18:04:22 --> Helper loaded: language_helper
INFO - 2016-05-18 18:04:22 --> Helper loaded: url_helper
DEBUG - 2016-05-18 18:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 18:04:22 --> Model Class Initialized
INFO - 2016-05-18 18:04:22 --> Helper loaded: date_helper
INFO - 2016-05-18 18:04:22 --> Controller Class Initialized
INFO - 2016-05-18 18:04:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 18:04:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 18:04:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 18:04:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 18:04:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 18:04:22 --> Model Class Initialized
INFO - 2016-05-18 18:04:22 --> Helper loaded: languages_helper
INFO - 2016-05-18 18:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 18:04:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 18:04:22 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/views/user_area/access.php 26
INFO - 2016-05-18 18:04:44 --> Config Class Initialized
INFO - 2016-05-18 18:04:44 --> Hooks Class Initialized
DEBUG - 2016-05-18 18:04:44 --> UTF-8 Support Enabled
INFO - 2016-05-18 18:04:44 --> Utf8 Class Initialized
INFO - 2016-05-18 18:04:44 --> URI Class Initialized
INFO - 2016-05-18 18:04:44 --> Router Class Initialized
INFO - 2016-05-18 18:04:44 --> Output Class Initialized
INFO - 2016-05-18 18:04:44 --> Security Class Initialized
DEBUG - 2016-05-18 18:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-18 18:04:44 --> CSRF cookie sent
INFO - 2016-05-18 18:04:44 --> Input Class Initialized
INFO - 2016-05-18 18:04:44 --> Language Class Initialized
INFO - 2016-05-18 18:04:44 --> Loader Class Initialized
INFO - 2016-05-18 18:04:44 --> Helper loaded: form_helper
INFO - 2016-05-18 18:04:44 --> Database Driver Class Initialized
INFO - 2016-05-18 18:04:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-18 18:04:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-18 18:04:44 --> Email Class Initialized
INFO - 2016-05-18 18:04:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-18 18:04:44 --> Helper loaded: cookie_helper
INFO - 2016-05-18 18:04:44 --> Helper loaded: language_helper
INFO - 2016-05-18 18:04:44 --> Helper loaded: url_helper
DEBUG - 2016-05-18 18:04:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-18 18:04:44 --> Model Class Initialized
INFO - 2016-05-18 18:04:44 --> Helper loaded: date_helper
INFO - 2016-05-18 18:04:44 --> Controller Class Initialized
INFO - 2016-05-18 18:04:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-18 18:04:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-18 18:04:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-18 18:04:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-18 18:04:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-18 18:04:44 --> Model Class Initialized
INFO - 2016-05-18 18:04:44 --> Helper loaded: languages_helper
INFO - 2016-05-18 18:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-18 18:04:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-18 18:04:44 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/views/user_area/access.php 26
