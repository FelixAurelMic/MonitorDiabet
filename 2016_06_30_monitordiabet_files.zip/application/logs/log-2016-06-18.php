<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-18 04:19:02 --> Config Class Initialized
INFO - 2016-06-18 04:19:02 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:02 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:02 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:02 --> URI Class Initialized
DEBUG - 2016-06-18 04:19:02 --> No URI present. Default controller set.
INFO - 2016-06-18 04:19:02 --> Router Class Initialized
INFO - 2016-06-18 04:19:02 --> Output Class Initialized
INFO - 2016-06-18 04:19:02 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:02 --> Input Class Initialized
INFO - 2016-06-18 04:19:02 --> Language Class Initialized
INFO - 2016-06-18 04:19:02 --> Loader Class Initialized
INFO - 2016-06-18 04:19:02 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:02 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:02 --> Email Class Initialized
INFO - 2016-06-18 04:19:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:02 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:02 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:02 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:02 --> Model Class Initialized
INFO - 2016-06-18 04:19:02 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:02 --> Controller Class Initialized
INFO - 2016-06-18 04:19:02 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 07:19:02 --> Model Class Initialized
INFO - 2016-06-18 07:19:02 --> Form Validation Class Initialized
INFO - 2016-06-18 07:19:02 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-18 07:19:02 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-18 07:19:02 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-18 07:19:02 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-18 07:19:02 --> Final output sent to browser
DEBUG - 2016-06-18 07:19:02 --> Total execution time: 0.5442
INFO - 2016-06-18 04:19:04 --> Config Class Initialized
INFO - 2016-06-18 04:19:04 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:04 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:04 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:04 --> URI Class Initialized
INFO - 2016-06-18 04:19:04 --> Router Class Initialized
INFO - 2016-06-18 04:19:04 --> Output Class Initialized
INFO - 2016-06-18 04:19:04 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:04 --> Input Class Initialized
INFO - 2016-06-18 04:19:04 --> Language Class Initialized
INFO - 2016-06-18 04:19:04 --> Loader Class Initialized
INFO - 2016-06-18 04:19:04 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:04 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:04 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:04 --> Email Class Initialized
INFO - 2016-06-18 04:19:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:04 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:04 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:04 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:04 --> Model Class Initialized
INFO - 2016-06-18 04:19:04 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:04 --> Controller Class Initialized
INFO - 2016-06-18 04:19:04 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 07:19:04 --> Model Class Initialized
INFO - 2016-06-18 07:19:04 --> Final output sent to browser
DEBUG - 2016-06-18 07:19:04 --> Total execution time: 0.1209
INFO - 2016-06-18 04:19:05 --> Config Class Initialized
INFO - 2016-06-18 04:19:05 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:05 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:05 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:05 --> URI Class Initialized
INFO - 2016-06-18 04:19:05 --> Router Class Initialized
INFO - 2016-06-18 04:19:05 --> Output Class Initialized
INFO - 2016-06-18 04:19:05 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:05 --> Input Class Initialized
INFO - 2016-06-18 04:19:05 --> Language Class Initialized
ERROR - 2016-06-18 04:19:05 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-18 04:19:05 --> Config Class Initialized
INFO - 2016-06-18 04:19:05 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:05 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:05 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:05 --> URI Class Initialized
INFO - 2016-06-18 04:19:05 --> Router Class Initialized
INFO - 2016-06-18 04:19:05 --> Output Class Initialized
INFO - 2016-06-18 04:19:05 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:05 --> Input Class Initialized
INFO - 2016-06-18 04:19:05 --> Language Class Initialized
ERROR - 2016-06-18 04:19:05 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-18 04:19:28 --> Config Class Initialized
INFO - 2016-06-18 04:19:28 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:28 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:28 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:28 --> URI Class Initialized
INFO - 2016-06-18 04:19:28 --> Router Class Initialized
INFO - 2016-06-18 04:19:28 --> Output Class Initialized
INFO - 2016-06-18 04:19:28 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:28 --> Input Class Initialized
INFO - 2016-06-18 04:19:28 --> Language Class Initialized
INFO - 2016-06-18 04:19:28 --> Loader Class Initialized
INFO - 2016-06-18 04:19:28 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:28 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:28 --> Email Class Initialized
INFO - 2016-06-18 04:19:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:28 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:28 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:28 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:28 --> Model Class Initialized
INFO - 2016-06-18 04:19:28 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:28 --> Controller Class Initialized
INFO - 2016-06-18 04:19:28 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-18 07:19:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-18 07:19:28 --> Form Validation Class Initialized
DEBUG - 2016-06-18 07:19:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-18 07:19:28 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-18 07:19:28 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-18 07:19:28 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-18 07:19:28 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-18 07:19:28 --> Final output sent to browser
DEBUG - 2016-06-18 07:19:28 --> Total execution time: 0.1292
INFO - 2016-06-18 04:19:29 --> Config Class Initialized
INFO - 2016-06-18 04:19:29 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:29 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:29 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:29 --> URI Class Initialized
INFO - 2016-06-18 04:19:29 --> Router Class Initialized
INFO - 2016-06-18 04:19:29 --> Output Class Initialized
INFO - 2016-06-18 04:19:29 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:29 --> Input Class Initialized
INFO - 2016-06-18 04:19:29 --> Language Class Initialized
INFO - 2016-06-18 04:19:29 --> Loader Class Initialized
INFO - 2016-06-18 04:19:29 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:29 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:29 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:29 --> Email Class Initialized
INFO - 2016-06-18 04:19:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:29 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:29 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:29 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:29 --> Model Class Initialized
INFO - 2016-06-18 04:19:29 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:29 --> Controller Class Initialized
INFO - 2016-06-18 04:19:29 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 07:19:29 --> Model Class Initialized
INFO - 2016-06-18 07:19:29 --> Final output sent to browser
DEBUG - 2016-06-18 07:19:29 --> Total execution time: 0.0838
INFO - 2016-06-18 04:19:50 --> Config Class Initialized
INFO - 2016-06-18 04:19:50 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:50 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:50 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:50 --> URI Class Initialized
INFO - 2016-06-18 04:19:50 --> Router Class Initialized
INFO - 2016-06-18 04:19:50 --> Output Class Initialized
INFO - 2016-06-18 04:19:50 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:50 --> Input Class Initialized
INFO - 2016-06-18 04:19:50 --> Language Class Initialized
INFO - 2016-06-18 04:19:50 --> Loader Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:50 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:50 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:50 --> Email Class Initialized
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:50 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:50 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:50 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:50 --> Model Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:50 --> Controller Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-18 07:19:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-18 07:19:50 --> Form Validation Class Initialized
DEBUG - 2016-06-18 07:19:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:50 --> Config Class Initialized
INFO - 2016-06-18 04:19:50 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:50 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:50 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:50 --> URI Class Initialized
DEBUG - 2016-06-18 04:19:50 --> No URI present. Default controller set.
INFO - 2016-06-18 04:19:50 --> Router Class Initialized
INFO - 2016-06-18 04:19:50 --> Output Class Initialized
INFO - 2016-06-18 04:19:50 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:50 --> Input Class Initialized
INFO - 2016-06-18 04:19:50 --> Language Class Initialized
INFO - 2016-06-18 04:19:50 --> Loader Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:50 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:50 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:50 --> Email Class Initialized
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:50 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:50 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:50 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:50 --> Model Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:50 --> Controller Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 04:19:50 --> Config Class Initialized
INFO - 2016-06-18 04:19:50 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:50 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:50 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:50 --> URI Class Initialized
INFO - 2016-06-18 04:19:50 --> Router Class Initialized
INFO - 2016-06-18 04:19:50 --> Output Class Initialized
INFO - 2016-06-18 04:19:50 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:50 --> Input Class Initialized
INFO - 2016-06-18 04:19:50 --> Language Class Initialized
INFO - 2016-06-18 04:19:50 --> Loader Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:50 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:50 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:50 --> Email Class Initialized
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:50 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:50 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:50 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:50 --> Model Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:50 --> Controller Class Initialized
INFO - 2016-06-18 04:19:50 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 07:19:50 --> Model Class Initialized
INFO - 2016-06-18 07:19:50 --> Form Validation Class Initialized
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-18 07:19:51 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-18 07:19:51 --> Final output sent to browser
DEBUG - 2016-06-18 07:19:51 --> Total execution time: 0.3213
INFO - 2016-06-18 04:19:52 --> Config Class Initialized
INFO - 2016-06-18 04:19:52 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:19:53 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:19:53 --> Utf8 Class Initialized
INFO - 2016-06-18 04:19:53 --> URI Class Initialized
INFO - 2016-06-18 04:19:53 --> Router Class Initialized
INFO - 2016-06-18 04:19:53 --> Output Class Initialized
INFO - 2016-06-18 04:19:53 --> Security Class Initialized
DEBUG - 2016-06-18 04:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:19:53 --> Input Class Initialized
INFO - 2016-06-18 04:19:53 --> Language Class Initialized
INFO - 2016-06-18 04:19:53 --> Loader Class Initialized
INFO - 2016-06-18 04:19:53 --> Helper loaded: form_helper
INFO - 2016-06-18 04:19:53 --> Database Driver Class Initialized
INFO - 2016-06-18 04:19:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:19:53 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:19:53 --> Email Class Initialized
INFO - 2016-06-18 04:19:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:19:53 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:19:53 --> Helper loaded: language_helper
INFO - 2016-06-18 04:19:53 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:19:53 --> Model Class Initialized
INFO - 2016-06-18 04:19:53 --> Helper loaded: date_helper
INFO - 2016-06-18 04:19:53 --> Controller Class Initialized
INFO - 2016-06-18 04:19:53 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:19:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:19:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:19:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:19:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:19:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 07:19:53 --> Model Class Initialized
INFO - 2016-06-18 07:19:53 --> Form Validation Class Initialized
INFO - 2016-06-18 07:19:53 --> Final output sent to browser
DEBUG - 2016-06-18 07:19:53 --> Total execution time: 0.0953
INFO - 2016-06-18 04:20:00 --> Config Class Initialized
INFO - 2016-06-18 04:20:00 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:20:00 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:20:00 --> Utf8 Class Initialized
INFO - 2016-06-18 04:20:00 --> URI Class Initialized
INFO - 2016-06-18 04:20:00 --> Router Class Initialized
INFO - 2016-06-18 04:20:00 --> Output Class Initialized
INFO - 2016-06-18 04:20:00 --> Security Class Initialized
DEBUG - 2016-06-18 04:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:20:00 --> Input Class Initialized
INFO - 2016-06-18 04:20:00 --> Language Class Initialized
INFO - 2016-06-18 04:20:00 --> Loader Class Initialized
INFO - 2016-06-18 04:20:00 --> Helper loaded: form_helper
INFO - 2016-06-18 04:20:00 --> Database Driver Class Initialized
INFO - 2016-06-18 04:20:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:20:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:20:00 --> Email Class Initialized
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:20:00 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:20:00 --> Helper loaded: language_helper
INFO - 2016-06-18 04:20:00 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:20:00 --> Model Class Initialized
INFO - 2016-06-18 04:20:00 --> Helper loaded: date_helper
INFO - 2016-06-18 04:20:00 --> Controller Class Initialized
INFO - 2016-06-18 04:20:00 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-18 07:20:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-18 07:20:00 --> Form Validation Class Initialized
INFO - 2016-06-18 04:20:00 --> Config Class Initialized
INFO - 2016-06-18 04:20:00 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:20:00 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:20:00 --> Utf8 Class Initialized
INFO - 2016-06-18 04:20:00 --> URI Class Initialized
DEBUG - 2016-06-18 04:20:00 --> No URI present. Default controller set.
INFO - 2016-06-18 04:20:00 --> Router Class Initialized
INFO - 2016-06-18 04:20:00 --> Output Class Initialized
INFO - 2016-06-18 04:20:00 --> Security Class Initialized
DEBUG - 2016-06-18 04:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:20:00 --> Input Class Initialized
INFO - 2016-06-18 04:20:00 --> Language Class Initialized
INFO - 2016-06-18 04:20:00 --> Loader Class Initialized
INFO - 2016-06-18 04:20:00 --> Helper loaded: form_helper
INFO - 2016-06-18 04:20:00 --> Database Driver Class Initialized
INFO - 2016-06-18 04:20:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:20:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:20:00 --> Email Class Initialized
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:20:00 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:20:00 --> Helper loaded: language_helper
INFO - 2016-06-18 04:20:00 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:20:00 --> Model Class Initialized
INFO - 2016-06-18 04:20:00 --> Helper loaded: date_helper
INFO - 2016-06-18 04:20:00 --> Controller Class Initialized
INFO - 2016-06-18 04:20:00 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:20:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 07:20:00 --> Model Class Initialized
INFO - 2016-06-18 07:20:00 --> Form Validation Class Initialized
INFO - 2016-06-18 07:20:00 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-18 07:20:00 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-18 07:20:00 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-18 07:20:00 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-18 07:20:00 --> Final output sent to browser
DEBUG - 2016-06-18 07:20:00 --> Total execution time: 0.0867
INFO - 2016-06-18 04:20:01 --> Config Class Initialized
INFO - 2016-06-18 04:20:01 --> Hooks Class Initialized
DEBUG - 2016-06-18 04:20:01 --> UTF-8 Support Enabled
INFO - 2016-06-18 04:20:01 --> Utf8 Class Initialized
INFO - 2016-06-18 04:20:01 --> URI Class Initialized
INFO - 2016-06-18 04:20:01 --> Router Class Initialized
INFO - 2016-06-18 04:20:01 --> Output Class Initialized
INFO - 2016-06-18 04:20:01 --> Security Class Initialized
DEBUG - 2016-06-18 04:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-18 04:20:01 --> Input Class Initialized
INFO - 2016-06-18 04:20:01 --> Language Class Initialized
INFO - 2016-06-18 04:20:01 --> Loader Class Initialized
INFO - 2016-06-18 04:20:01 --> Helper loaded: form_helper
INFO - 2016-06-18 04:20:01 --> Database Driver Class Initialized
INFO - 2016-06-18 04:20:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-18 04:20:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-18 04:20:01 --> Email Class Initialized
INFO - 2016-06-18 04:20:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-18 04:20:01 --> Helper loaded: cookie_helper
INFO - 2016-06-18 04:20:01 --> Helper loaded: language_helper
INFO - 2016-06-18 04:20:01 --> Helper loaded: url_helper
DEBUG - 2016-06-18 04:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-18 04:20:01 --> Model Class Initialized
INFO - 2016-06-18 04:20:01 --> Helper loaded: date_helper
INFO - 2016-06-18 04:20:01 --> Controller Class Initialized
INFO - 2016-06-18 04:20:01 --> Helper loaded: languages_helper
INFO - 2016-06-18 04:20:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-18 04:20:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-18 04:20:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-18 04:20:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-18 04:20:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-18 07:20:01 --> Model Class Initialized
INFO - 2016-06-18 07:20:01 --> Final output sent to browser
DEBUG - 2016-06-18 07:20:01 --> Total execution time: 0.2080
