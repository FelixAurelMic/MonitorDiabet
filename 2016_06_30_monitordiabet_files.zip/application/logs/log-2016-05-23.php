<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-23 10:15:40 --> Config Class Initialized
INFO - 2016-05-23 10:15:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:15:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:15:40 --> Utf8 Class Initialized
INFO - 2016-05-23 10:15:40 --> URI Class Initialized
INFO - 2016-05-23 10:15:40 --> Router Class Initialized
INFO - 2016-05-23 10:15:40 --> Output Class Initialized
INFO - 2016-05-23 10:15:40 --> Security Class Initialized
DEBUG - 2016-05-23 10:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:15:40 --> CSRF cookie sent
INFO - 2016-05-23 10:15:40 --> Input Class Initialized
INFO - 2016-05-23 10:15:40 --> Language Class Initialized
INFO - 2016-05-23 10:15:41 --> Loader Class Initialized
INFO - 2016-05-23 10:15:41 --> Helper loaded: form_helper
INFO - 2016-05-23 10:15:41 --> Database Driver Class Initialized
INFO - 2016-05-23 10:15:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 10:15:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 10:15:42 --> Email Class Initialized
INFO - 2016-05-23 10:15:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 10:15:42 --> Helper loaded: cookie_helper
INFO - 2016-05-23 10:15:42 --> Helper loaded: language_helper
INFO - 2016-05-23 10:15:42 --> Helper loaded: url_helper
DEBUG - 2016-05-23 10:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:15:42 --> Model Class Initialized
INFO - 2016-05-23 10:15:42 --> Helper loaded: date_helper
INFO - 2016-05-23 10:15:42 --> Controller Class Initialized
DEBUG - 2016-05-23 10:15:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:15:42 --> Form Validation Class Initialized
INFO - 2016-05-23 10:15:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 10:15:42 --> Config Class Initialized
INFO - 2016-05-23 10:15:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:15:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:15:42 --> Utf8 Class Initialized
INFO - 2016-05-23 10:15:42 --> URI Class Initialized
INFO - 2016-05-23 10:15:42 --> Router Class Initialized
INFO - 2016-05-23 10:15:42 --> Output Class Initialized
INFO - 2016-05-23 10:15:42 --> Security Class Initialized
DEBUG - 2016-05-23 10:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:15:42 --> CSRF cookie sent
INFO - 2016-05-23 10:15:42 --> Input Class Initialized
INFO - 2016-05-23 10:15:42 --> Language Class Initialized
INFO - 2016-05-23 10:15:42 --> Loader Class Initialized
INFO - 2016-05-23 10:15:42 --> Helper loaded: form_helper
INFO - 2016-05-23 10:15:42 --> Database Driver Class Initialized
INFO - 2016-05-23 10:15:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 10:15:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 10:15:42 --> Email Class Initialized
INFO - 2016-05-23 10:15:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 10:15:42 --> Helper loaded: cookie_helper
INFO - 2016-05-23 10:15:42 --> Helper loaded: language_helper
INFO - 2016-05-23 10:15:42 --> Helper loaded: url_helper
DEBUG - 2016-05-23 10:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:15:42 --> Model Class Initialized
INFO - 2016-05-23 10:15:42 --> Helper loaded: date_helper
INFO - 2016-05-23 10:15:42 --> Controller Class Initialized
DEBUG - 2016-05-23 10:15:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:15:42 --> Form Validation Class Initialized
INFO - 2016-05-23 10:15:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 10:38:11 --> Config Class Initialized
INFO - 2016-05-23 10:38:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:38:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:38:11 --> Utf8 Class Initialized
INFO - 2016-05-23 10:38:11 --> URI Class Initialized
INFO - 2016-05-23 10:38:11 --> Router Class Initialized
INFO - 2016-05-23 10:38:11 --> Output Class Initialized
INFO - 2016-05-23 10:38:11 --> Security Class Initialized
DEBUG - 2016-05-23 10:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:38:11 --> CSRF cookie sent
INFO - 2016-05-23 10:38:11 --> Input Class Initialized
INFO - 2016-05-23 10:38:11 --> Language Class Initialized
INFO - 2016-05-23 10:38:11 --> Loader Class Initialized
INFO - 2016-05-23 10:38:11 --> Helper loaded: form_helper
INFO - 2016-05-23 10:38:12 --> Database Driver Class Initialized
INFO - 2016-05-23 10:38:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 10:38:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 10:38:12 --> Email Class Initialized
INFO - 2016-05-23 10:38:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 10:38:12 --> Helper loaded: cookie_helper
INFO - 2016-05-23 10:38:12 --> Helper loaded: language_helper
INFO - 2016-05-23 10:38:12 --> Helper loaded: url_helper
DEBUG - 2016-05-23 10:38:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:38:12 --> Model Class Initialized
INFO - 2016-05-23 10:38:12 --> Helper loaded: date_helper
INFO - 2016-05-23 10:38:12 --> Controller Class Initialized
DEBUG - 2016-05-23 10:38:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:38:12 --> Form Validation Class Initialized
INFO - 2016-05-23 10:38:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 10:38:13 --> Config Class Initialized
INFO - 2016-05-23 10:38:13 --> Hooks Class Initialized
DEBUG - 2016-05-23 10:38:13 --> UTF-8 Support Enabled
INFO - 2016-05-23 10:38:13 --> Utf8 Class Initialized
INFO - 2016-05-23 10:38:13 --> URI Class Initialized
INFO - 2016-05-23 10:38:13 --> Router Class Initialized
INFO - 2016-05-23 10:38:13 --> Output Class Initialized
INFO - 2016-05-23 10:38:13 --> Security Class Initialized
DEBUG - 2016-05-23 10:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 10:38:13 --> CSRF cookie sent
INFO - 2016-05-23 10:38:13 --> Input Class Initialized
INFO - 2016-05-23 10:38:13 --> Language Class Initialized
INFO - 2016-05-23 10:38:13 --> Loader Class Initialized
INFO - 2016-05-23 10:38:13 --> Helper loaded: form_helper
INFO - 2016-05-23 10:38:13 --> Database Driver Class Initialized
INFO - 2016-05-23 10:38:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 10:38:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 10:38:13 --> Email Class Initialized
INFO - 2016-05-23 10:38:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 10:38:13 --> Helper loaded: cookie_helper
INFO - 2016-05-23 10:38:13 --> Helper loaded: language_helper
INFO - 2016-05-23 10:38:13 --> Helper loaded: url_helper
DEBUG - 2016-05-23 10:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:38:13 --> Model Class Initialized
INFO - 2016-05-23 10:38:13 --> Helper loaded: date_helper
INFO - 2016-05-23 10:38:13 --> Controller Class Initialized
DEBUG - 2016-05-23 10:38:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 10:38:13 --> Form Validation Class Initialized
INFO - 2016-05-23 10:38:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:16:09 --> Config Class Initialized
INFO - 2016-05-23 11:16:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:09 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:09 --> URI Class Initialized
DEBUG - 2016-05-23 11:16:09 --> No URI present. Default controller set.
INFO - 2016-05-23 11:16:09 --> Router Class Initialized
INFO - 2016-05-23 11:16:09 --> Output Class Initialized
INFO - 2016-05-23 11:16:09 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:09 --> CSRF cookie sent
INFO - 2016-05-23 11:16:09 --> Input Class Initialized
INFO - 2016-05-23 11:16:09 --> Language Class Initialized
INFO - 2016-05-23 11:16:09 --> Loader Class Initialized
INFO - 2016-05-23 11:16:09 --> Helper loaded: form_helper
INFO - 2016-05-23 11:16:09 --> Database Driver Class Initialized
INFO - 2016-05-23 11:16:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:16:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:16:09 --> Email Class Initialized
INFO - 2016-05-23 11:16:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:16:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:16:09 --> Helper loaded: language_helper
INFO - 2016-05-23 11:16:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:09 --> Model Class Initialized
INFO - 2016-05-23 11:16:09 --> Helper loaded: date_helper
INFO - 2016-05-23 11:16:09 --> Controller Class Initialized
INFO - 2016-05-23 11:16:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:16:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:16:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:16:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:16:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:16:09 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:16:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:16:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:16:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:16:09 --> Final output sent to browser
DEBUG - 2016-05-23 11:16:09 --> Total execution time: 1.1090
INFO - 2016-05-23 11:16:10 --> Config Class Initialized
INFO - 2016-05-23 11:16:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:10 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:10 --> URI Class Initialized
INFO - 2016-05-23 11:16:10 --> Router Class Initialized
INFO - 2016-05-23 11:16:10 --> Output Class Initialized
INFO - 2016-05-23 11:16:10 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:10 --> CSRF cookie sent
INFO - 2016-05-23 11:16:10 --> Input Class Initialized
INFO - 2016-05-23 11:16:10 --> Language Class Initialized
ERROR - 2016-05-23 11:16:10 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:16:13 --> Config Class Initialized
INFO - 2016-05-23 11:16:13 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:13 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:13 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:13 --> URI Class Initialized
INFO - 2016-05-23 11:16:13 --> Router Class Initialized
INFO - 2016-05-23 11:16:13 --> Output Class Initialized
INFO - 2016-05-23 11:16:13 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:13 --> CSRF cookie sent
INFO - 2016-05-23 11:16:13 --> Input Class Initialized
INFO - 2016-05-23 11:16:13 --> Language Class Initialized
ERROR - 2016-05-23 11:16:13 --> 404 Page Not Found: Faviconico/index
INFO - 2016-05-23 11:16:21 --> Config Class Initialized
INFO - 2016-05-23 11:16:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:21 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:21 --> URI Class Initialized
INFO - 2016-05-23 11:16:21 --> Router Class Initialized
INFO - 2016-05-23 11:16:21 --> Output Class Initialized
INFO - 2016-05-23 11:16:21 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:21 --> CSRF cookie sent
INFO - 2016-05-23 11:16:21 --> Input Class Initialized
INFO - 2016-05-23 11:16:21 --> Language Class Initialized
INFO - 2016-05-23 11:16:21 --> Loader Class Initialized
INFO - 2016-05-23 11:16:21 --> Helper loaded: form_helper
INFO - 2016-05-23 11:16:21 --> Database Driver Class Initialized
INFO - 2016-05-23 11:16:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:16:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:16:21 --> Email Class Initialized
INFO - 2016-05-23 11:16:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:16:21 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:16:21 --> Helper loaded: language_helper
INFO - 2016-05-23 11:16:21 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:21 --> Model Class Initialized
INFO - 2016-05-23 11:16:21 --> Helper loaded: date_helper
INFO - 2016-05-23 11:16:21 --> Controller Class Initialized
INFO - 2016-05-23 11:16:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:16:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:16:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:16:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:16:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 11:16:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:21 --> Form Validation Class Initialized
INFO - 2016-05-23 11:16:21 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:16:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:16:21 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 11:16:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:16:21 --> Final output sent to browser
DEBUG - 2016-05-23 11:16:21 --> Total execution time: 0.1110
INFO - 2016-05-23 11:16:22 --> Config Class Initialized
INFO - 2016-05-23 11:16:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:22 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:22 --> URI Class Initialized
INFO - 2016-05-23 11:16:22 --> Router Class Initialized
INFO - 2016-05-23 11:16:22 --> Output Class Initialized
INFO - 2016-05-23 11:16:22 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:22 --> CSRF cookie sent
INFO - 2016-05-23 11:16:22 --> Input Class Initialized
INFO - 2016-05-23 11:16:22 --> Language Class Initialized
ERROR - 2016-05-23 11:16:22 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:16:26 --> Config Class Initialized
INFO - 2016-05-23 11:16:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:26 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:26 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:26 --> URI Class Initialized
INFO - 2016-05-23 11:16:26 --> Router Class Initialized
INFO - 2016-05-23 11:16:26 --> Output Class Initialized
INFO - 2016-05-23 11:16:26 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:26 --> CSRF cookie sent
INFO - 2016-05-23 11:16:26 --> CSRF token verified
INFO - 2016-05-23 11:16:26 --> Input Class Initialized
INFO - 2016-05-23 11:16:26 --> Language Class Initialized
INFO - 2016-05-23 11:16:26 --> Loader Class Initialized
INFO - 2016-05-23 11:16:26 --> Helper loaded: form_helper
INFO - 2016-05-23 11:16:26 --> Database Driver Class Initialized
INFO - 2016-05-23 11:16:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:16:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:16:26 --> Email Class Initialized
INFO - 2016-05-23 11:16:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:16:26 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:16:26 --> Helper loaded: language_helper
INFO - 2016-05-23 11:16:26 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:26 --> Model Class Initialized
INFO - 2016-05-23 11:16:26 --> Helper loaded: date_helper
INFO - 2016-05-23 11:16:26 --> Controller Class Initialized
INFO - 2016-05-23 11:16:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:16:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:16:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:16:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:16:26 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 11:16:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:26 --> Form Validation Class Initialized
INFO - 2016-05-23 11:16:28 --> Config Class Initialized
INFO - 2016-05-23 11:16:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:28 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:28 --> URI Class Initialized
DEBUG - 2016-05-23 11:16:28 --> No URI present. Default controller set.
INFO - 2016-05-23 11:16:28 --> Router Class Initialized
INFO - 2016-05-23 11:16:28 --> Output Class Initialized
INFO - 2016-05-23 11:16:28 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:28 --> CSRF cookie sent
INFO - 2016-05-23 11:16:29 --> Input Class Initialized
INFO - 2016-05-23 11:16:29 --> Language Class Initialized
INFO - 2016-05-23 11:16:29 --> Loader Class Initialized
INFO - 2016-05-23 11:16:29 --> Helper loaded: form_helper
INFO - 2016-05-23 11:16:29 --> Database Driver Class Initialized
INFO - 2016-05-23 11:16:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:16:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:16:29 --> Email Class Initialized
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:16:29 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:16:29 --> Helper loaded: language_helper
INFO - 2016-05-23 11:16:29 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:29 --> Model Class Initialized
INFO - 2016-05-23 11:16:29 --> Helper loaded: date_helper
INFO - 2016-05-23 11:16:29 --> Controller Class Initialized
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:16:29 --> Config Class Initialized
INFO - 2016-05-23 11:16:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:29 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:29 --> URI Class Initialized
INFO - 2016-05-23 11:16:29 --> Router Class Initialized
INFO - 2016-05-23 11:16:29 --> Output Class Initialized
INFO - 2016-05-23 11:16:29 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:29 --> CSRF cookie sent
INFO - 2016-05-23 11:16:29 --> Input Class Initialized
INFO - 2016-05-23 11:16:29 --> Language Class Initialized
INFO - 2016-05-23 11:16:29 --> Loader Class Initialized
INFO - 2016-05-23 11:16:29 --> Helper loaded: form_helper
INFO - 2016-05-23 11:16:29 --> Database Driver Class Initialized
INFO - 2016-05-23 11:16:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:16:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:16:29 --> Email Class Initialized
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:16:29 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:16:29 --> Helper loaded: language_helper
INFO - 2016-05-23 11:16:29 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:29 --> Model Class Initialized
INFO - 2016-05-23 11:16:29 --> Helper loaded: date_helper
INFO - 2016-05-23 11:16:29 --> Controller Class Initialized
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:16:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:16:29 --> Model Class Initialized
INFO - 2016-05-23 11:16:29 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:16:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 11:16:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 11:16:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 11:16:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 11:16:34 --> Final output sent to browser
DEBUG - 2016-05-23 11:16:34 --> Total execution time: 4.9797
INFO - 2016-05-23 11:16:42 --> Config Class Initialized
INFO - 2016-05-23 11:16:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:16:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:16:42 --> Utf8 Class Initialized
INFO - 2016-05-23 11:16:42 --> URI Class Initialized
INFO - 2016-05-23 11:16:42 --> Router Class Initialized
INFO - 2016-05-23 11:16:42 --> Output Class Initialized
INFO - 2016-05-23 11:16:42 --> Security Class Initialized
DEBUG - 2016-05-23 11:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:16:42 --> CSRF cookie sent
INFO - 2016-05-23 11:16:42 --> Input Class Initialized
INFO - 2016-05-23 11:16:42 --> Language Class Initialized
INFO - 2016-05-23 11:16:42 --> Loader Class Initialized
INFO - 2016-05-23 11:16:42 --> Helper loaded: form_helper
INFO - 2016-05-23 11:16:42 --> Database Driver Class Initialized
INFO - 2016-05-23 11:16:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:16:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:16:42 --> Email Class Initialized
INFO - 2016-05-23 11:16:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:16:42 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:16:42 --> Helper loaded: language_helper
INFO - 2016-05-23 11:16:42 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:42 --> Model Class Initialized
INFO - 2016-05-23 11:16:42 --> Helper loaded: date_helper
INFO - 2016-05-23 11:16:42 --> Controller Class Initialized
INFO - 2016-05-23 11:16:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:16:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:16:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:16:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:16:42 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 11:16:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:16:42 --> Form Validation Class Initialized
INFO - 2016-05-23 11:16:42 --> Helper loaded: string_helper
INFO - 2016-05-23 11:16:42 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:16:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 11:16:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 11:16:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-23 11:16:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 11:16:42 --> Final output sent to browser
DEBUG - 2016-05-23 11:16:42 --> Total execution time: 0.1711
INFO - 2016-05-23 11:27:53 --> Config Class Initialized
INFO - 2016-05-23 11:27:53 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:27:53 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:27:53 --> Utf8 Class Initialized
INFO - 2016-05-23 11:27:53 --> URI Class Initialized
DEBUG - 2016-05-23 11:27:53 --> No URI present. Default controller set.
INFO - 2016-05-23 11:27:53 --> Router Class Initialized
INFO - 2016-05-23 11:27:53 --> Output Class Initialized
INFO - 2016-05-23 11:27:53 --> Security Class Initialized
DEBUG - 2016-05-23 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:27:53 --> CSRF cookie sent
INFO - 2016-05-23 11:27:53 --> Input Class Initialized
INFO - 2016-05-23 11:27:53 --> Language Class Initialized
INFO - 2016-05-23 11:27:53 --> Loader Class Initialized
INFO - 2016-05-23 11:27:53 --> Helper loaded: form_helper
INFO - 2016-05-23 11:27:53 --> Database Driver Class Initialized
INFO - 2016-05-23 11:27:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:27:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:27:53 --> Email Class Initialized
INFO - 2016-05-23 11:27:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:27:53 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:27:53 --> Helper loaded: language_helper
INFO - 2016-05-23 11:27:53 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:27:53 --> Model Class Initialized
INFO - 2016-05-23 11:27:53 --> Helper loaded: date_helper
INFO - 2016-05-23 11:27:53 --> Controller Class Initialized
INFO - 2016-05-23 11:27:53 --> Helper loaded: languages_helper
ERROR - 2016-05-23 11:27:53 --> Could not find the language line "login_heading"
ERROR - 2016-05-23 11:27:53 --> Could not find the language line "create_user_heading"
INFO - 2016-05-23 11:27:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:27:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:27:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:27:53 --> Final output sent to browser
DEBUG - 2016-05-23 11:27:53 --> Total execution time: 0.0402
INFO - 2016-05-23 11:27:53 --> Config Class Initialized
INFO - 2016-05-23 11:27:53 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:27:53 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:27:53 --> Utf8 Class Initialized
INFO - 2016-05-23 11:27:53 --> URI Class Initialized
INFO - 2016-05-23 11:27:53 --> Router Class Initialized
INFO - 2016-05-23 11:27:53 --> Output Class Initialized
INFO - 2016-05-23 11:27:53 --> Security Class Initialized
DEBUG - 2016-05-23 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:27:53 --> CSRF cookie sent
INFO - 2016-05-23 11:27:53 --> Input Class Initialized
INFO - 2016-05-23 11:27:53 --> Language Class Initialized
ERROR - 2016-05-23 11:27:53 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:40:02 --> Config Class Initialized
INFO - 2016-05-23 11:40:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:40:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:40:02 --> Utf8 Class Initialized
INFO - 2016-05-23 11:40:02 --> URI Class Initialized
INFO - 2016-05-23 11:40:02 --> Router Class Initialized
INFO - 2016-05-23 11:40:02 --> Output Class Initialized
INFO - 2016-05-23 11:40:02 --> Security Class Initialized
DEBUG - 2016-05-23 11:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:40:02 --> CSRF cookie sent
INFO - 2016-05-23 11:40:02 --> Input Class Initialized
INFO - 2016-05-23 11:40:02 --> Language Class Initialized
INFO - 2016-05-23 11:40:02 --> Loader Class Initialized
INFO - 2016-05-23 11:40:02 --> Helper loaded: form_helper
INFO - 2016-05-23 11:40:02 --> Database Driver Class Initialized
INFO - 2016-05-23 11:40:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:40:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:40:02 --> Email Class Initialized
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:40:02 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:40:02 --> Helper loaded: language_helper
INFO - 2016-05-23 11:40:02 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:40:02 --> Model Class Initialized
INFO - 2016-05-23 11:40:02 --> Helper loaded: date_helper
INFO - 2016-05-23 11:40:02 --> Controller Class Initialized
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 11:40:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:40:02 --> Form Validation Class Initialized
INFO - 2016-05-23 11:40:02 --> Config Class Initialized
INFO - 2016-05-23 11:40:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:40:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:40:02 --> Utf8 Class Initialized
INFO - 2016-05-23 11:40:02 --> URI Class Initialized
INFO - 2016-05-23 11:40:02 --> Router Class Initialized
INFO - 2016-05-23 11:40:02 --> Output Class Initialized
INFO - 2016-05-23 11:40:02 --> Security Class Initialized
DEBUG - 2016-05-23 11:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:40:02 --> CSRF cookie sent
INFO - 2016-05-23 11:40:02 --> Input Class Initialized
INFO - 2016-05-23 11:40:02 --> Language Class Initialized
INFO - 2016-05-23 11:40:02 --> Loader Class Initialized
INFO - 2016-05-23 11:40:02 --> Helper loaded: form_helper
INFO - 2016-05-23 11:40:02 --> Database Driver Class Initialized
INFO - 2016-05-23 11:40:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:40:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:40:02 --> Email Class Initialized
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:40:02 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:40:02 --> Helper loaded: language_helper
INFO - 2016-05-23 11:40:02 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:40:02 --> Model Class Initialized
INFO - 2016-05-23 11:40:02 --> Helper loaded: date_helper
INFO - 2016-05-23 11:40:02 --> Controller Class Initialized
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:40:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 11:40:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:40:02 --> Form Validation Class Initialized
INFO - 2016-05-23 11:40:02 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:40:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:40:02 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 11:40:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:40:02 --> Final output sent to browser
DEBUG - 2016-05-23 11:40:02 --> Total execution time: 0.0247
INFO - 2016-05-23 11:40:02 --> Config Class Initialized
INFO - 2016-05-23 11:40:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:40:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:40:02 --> Utf8 Class Initialized
INFO - 2016-05-23 11:40:02 --> URI Class Initialized
INFO - 2016-05-23 11:40:02 --> Router Class Initialized
INFO - 2016-05-23 11:40:02 --> Output Class Initialized
INFO - 2016-05-23 11:40:02 --> Security Class Initialized
DEBUG - 2016-05-23 11:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:40:02 --> CSRF cookie sent
INFO - 2016-05-23 11:40:02 --> Input Class Initialized
INFO - 2016-05-23 11:40:02 --> Language Class Initialized
ERROR - 2016-05-23 11:40:02 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:40:21 --> Config Class Initialized
INFO - 2016-05-23 11:40:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:40:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:40:21 --> Utf8 Class Initialized
INFO - 2016-05-23 11:40:21 --> URI Class Initialized
DEBUG - 2016-05-23 11:40:21 --> No URI present. Default controller set.
INFO - 2016-05-23 11:40:21 --> Router Class Initialized
INFO - 2016-05-23 11:40:21 --> Output Class Initialized
INFO - 2016-05-23 11:40:21 --> Security Class Initialized
DEBUG - 2016-05-23 11:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:40:21 --> CSRF cookie sent
INFO - 2016-05-23 11:40:21 --> Input Class Initialized
INFO - 2016-05-23 11:40:21 --> Language Class Initialized
INFO - 2016-05-23 11:40:21 --> Loader Class Initialized
INFO - 2016-05-23 11:40:21 --> Helper loaded: form_helper
INFO - 2016-05-23 11:40:21 --> Database Driver Class Initialized
INFO - 2016-05-23 11:40:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:40:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:40:21 --> Email Class Initialized
INFO - 2016-05-23 11:40:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:40:21 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:40:21 --> Helper loaded: language_helper
INFO - 2016-05-23 11:40:21 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:40:21 --> Model Class Initialized
INFO - 2016-05-23 11:40:21 --> Helper loaded: date_helper
INFO - 2016-05-23 11:40:21 --> Controller Class Initialized
INFO - 2016-05-23 11:40:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:40:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:40:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:40:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:40:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:40:21 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:40:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:40:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:40:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:40:21 --> Final output sent to browser
DEBUG - 2016-05-23 11:40:21 --> Total execution time: 0.0578
INFO - 2016-05-23 11:40:22 --> Config Class Initialized
INFO - 2016-05-23 11:40:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:40:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:40:22 --> Utf8 Class Initialized
INFO - 2016-05-23 11:40:22 --> URI Class Initialized
INFO - 2016-05-23 11:40:22 --> Router Class Initialized
INFO - 2016-05-23 11:40:22 --> Output Class Initialized
INFO - 2016-05-23 11:40:22 --> Security Class Initialized
DEBUG - 2016-05-23 11:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:40:22 --> CSRF cookie sent
INFO - 2016-05-23 11:40:22 --> Input Class Initialized
INFO - 2016-05-23 11:40:22 --> Language Class Initialized
ERROR - 2016-05-23 11:40:22 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:41:11 --> Config Class Initialized
INFO - 2016-05-23 11:41:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:41:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:41:11 --> Utf8 Class Initialized
INFO - 2016-05-23 11:41:11 --> URI Class Initialized
DEBUG - 2016-05-23 11:41:11 --> No URI present. Default controller set.
INFO - 2016-05-23 11:41:11 --> Router Class Initialized
INFO - 2016-05-23 11:41:11 --> Output Class Initialized
INFO - 2016-05-23 11:41:11 --> Security Class Initialized
DEBUG - 2016-05-23 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:41:11 --> CSRF cookie sent
INFO - 2016-05-23 11:41:11 --> Input Class Initialized
INFO - 2016-05-23 11:41:11 --> Language Class Initialized
INFO - 2016-05-23 11:41:11 --> Loader Class Initialized
INFO - 2016-05-23 11:41:11 --> Helper loaded: form_helper
INFO - 2016-05-23 11:41:11 --> Database Driver Class Initialized
INFO - 2016-05-23 11:41:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:41:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:41:11 --> Email Class Initialized
INFO - 2016-05-23 11:41:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:41:11 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:41:11 --> Helper loaded: language_helper
INFO - 2016-05-23 11:41:11 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:41:11 --> Model Class Initialized
INFO - 2016-05-23 11:41:11 --> Helper loaded: date_helper
INFO - 2016-05-23 11:41:11 --> Controller Class Initialized
INFO - 2016-05-23 11:41:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:41:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:41:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:41:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:41:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:41:11 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:41:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:41:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:41:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:41:11 --> Final output sent to browser
DEBUG - 2016-05-23 11:41:11 --> Total execution time: 0.0239
INFO - 2016-05-23 11:41:11 --> Config Class Initialized
INFO - 2016-05-23 11:41:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:41:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:41:11 --> Utf8 Class Initialized
INFO - 2016-05-23 11:41:11 --> URI Class Initialized
INFO - 2016-05-23 11:41:11 --> Router Class Initialized
INFO - 2016-05-23 11:41:11 --> Output Class Initialized
INFO - 2016-05-23 11:41:11 --> Security Class Initialized
DEBUG - 2016-05-23 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:41:11 --> CSRF cookie sent
INFO - 2016-05-23 11:41:11 --> Input Class Initialized
INFO - 2016-05-23 11:41:11 --> Language Class Initialized
ERROR - 2016-05-23 11:41:11 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:42:08 --> Config Class Initialized
INFO - 2016-05-23 11:42:08 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:42:08 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:42:08 --> Utf8 Class Initialized
INFO - 2016-05-23 11:42:08 --> URI Class Initialized
DEBUG - 2016-05-23 11:42:08 --> No URI present. Default controller set.
INFO - 2016-05-23 11:42:08 --> Router Class Initialized
INFO - 2016-05-23 11:42:08 --> Output Class Initialized
INFO - 2016-05-23 11:42:08 --> Security Class Initialized
DEBUG - 2016-05-23 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:42:08 --> CSRF cookie sent
INFO - 2016-05-23 11:42:08 --> Input Class Initialized
INFO - 2016-05-23 11:42:08 --> Language Class Initialized
INFO - 2016-05-23 11:42:08 --> Loader Class Initialized
INFO - 2016-05-23 11:42:08 --> Helper loaded: form_helper
INFO - 2016-05-23 11:42:08 --> Database Driver Class Initialized
INFO - 2016-05-23 11:42:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:42:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:42:08 --> Email Class Initialized
INFO - 2016-05-23 11:42:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:42:08 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:42:08 --> Helper loaded: language_helper
INFO - 2016-05-23 11:42:08 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:42:08 --> Model Class Initialized
INFO - 2016-05-23 11:42:08 --> Helper loaded: date_helper
INFO - 2016-05-23 11:42:08 --> Controller Class Initialized
INFO - 2016-05-23 11:42:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:42:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:42:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:42:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:42:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:42:08 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:42:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:42:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:42:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:42:08 --> Final output sent to browser
DEBUG - 2016-05-23 11:42:08 --> Total execution time: 0.0254
INFO - 2016-05-23 11:42:08 --> Config Class Initialized
INFO - 2016-05-23 11:42:08 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:42:08 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:42:08 --> Utf8 Class Initialized
INFO - 2016-05-23 11:42:08 --> URI Class Initialized
INFO - 2016-05-23 11:42:08 --> Router Class Initialized
INFO - 2016-05-23 11:42:08 --> Output Class Initialized
INFO - 2016-05-23 11:42:08 --> Security Class Initialized
DEBUG - 2016-05-23 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:42:08 --> CSRF cookie sent
INFO - 2016-05-23 11:42:08 --> Input Class Initialized
INFO - 2016-05-23 11:42:08 --> Language Class Initialized
ERROR - 2016-05-23 11:42:08 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:43:04 --> Config Class Initialized
INFO - 2016-05-23 11:43:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:43:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:43:04 --> Utf8 Class Initialized
INFO - 2016-05-23 11:43:04 --> URI Class Initialized
DEBUG - 2016-05-23 11:43:04 --> No URI present. Default controller set.
INFO - 2016-05-23 11:43:04 --> Router Class Initialized
INFO - 2016-05-23 11:43:04 --> Output Class Initialized
INFO - 2016-05-23 11:43:04 --> Security Class Initialized
DEBUG - 2016-05-23 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:43:04 --> CSRF cookie sent
INFO - 2016-05-23 11:43:04 --> Input Class Initialized
INFO - 2016-05-23 11:43:04 --> Language Class Initialized
INFO - 2016-05-23 11:43:04 --> Loader Class Initialized
INFO - 2016-05-23 11:43:04 --> Helper loaded: form_helper
INFO - 2016-05-23 11:43:04 --> Database Driver Class Initialized
INFO - 2016-05-23 11:43:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:43:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:43:04 --> Email Class Initialized
INFO - 2016-05-23 11:43:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:43:04 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:43:04 --> Helper loaded: language_helper
INFO - 2016-05-23 11:43:04 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:43:04 --> Model Class Initialized
INFO - 2016-05-23 11:43:04 --> Helper loaded: date_helper
INFO - 2016-05-23 11:43:04 --> Controller Class Initialized
INFO - 2016-05-23 11:43:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:43:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:43:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:43:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:43:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:43:04 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:43:04 --> Final output sent to browser
DEBUG - 2016-05-23 11:43:04 --> Total execution time: 0.0511
INFO - 2016-05-23 11:43:04 --> Config Class Initialized
INFO - 2016-05-23 11:43:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:43:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:43:04 --> Utf8 Class Initialized
INFO - 2016-05-23 11:43:04 --> URI Class Initialized
INFO - 2016-05-23 11:43:04 --> Router Class Initialized
INFO - 2016-05-23 11:43:04 --> Output Class Initialized
INFO - 2016-05-23 11:43:04 --> Security Class Initialized
DEBUG - 2016-05-23 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:43:04 --> CSRF cookie sent
INFO - 2016-05-23 11:43:04 --> Input Class Initialized
INFO - 2016-05-23 11:43:04 --> Language Class Initialized
ERROR - 2016-05-23 11:43:04 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:43:28 --> Config Class Initialized
INFO - 2016-05-23 11:43:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:43:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:43:28 --> Utf8 Class Initialized
INFO - 2016-05-23 11:43:28 --> URI Class Initialized
DEBUG - 2016-05-23 11:43:28 --> No URI present. Default controller set.
INFO - 2016-05-23 11:43:28 --> Router Class Initialized
INFO - 2016-05-23 11:43:28 --> Output Class Initialized
INFO - 2016-05-23 11:43:28 --> Security Class Initialized
DEBUG - 2016-05-23 11:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:43:28 --> CSRF cookie sent
INFO - 2016-05-23 11:43:28 --> Input Class Initialized
INFO - 2016-05-23 11:43:28 --> Language Class Initialized
INFO - 2016-05-23 11:43:28 --> Loader Class Initialized
INFO - 2016-05-23 11:43:28 --> Helper loaded: form_helper
INFO - 2016-05-23 11:43:28 --> Database Driver Class Initialized
INFO - 2016-05-23 11:43:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:43:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:43:28 --> Email Class Initialized
INFO - 2016-05-23 11:43:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:43:28 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:43:28 --> Helper loaded: language_helper
INFO - 2016-05-23 11:43:28 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:43:28 --> Model Class Initialized
INFO - 2016-05-23 11:43:28 --> Helper loaded: date_helper
INFO - 2016-05-23 11:43:28 --> Controller Class Initialized
INFO - 2016-05-23 11:43:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:43:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:43:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:43:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:43:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:43:28 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:43:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:43:28 --> Final output sent to browser
DEBUG - 2016-05-23 11:43:28 --> Total execution time: 0.0371
INFO - 2016-05-23 11:43:29 --> Config Class Initialized
INFO - 2016-05-23 11:43:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:43:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:43:29 --> Utf8 Class Initialized
INFO - 2016-05-23 11:43:29 --> URI Class Initialized
INFO - 2016-05-23 11:43:29 --> Router Class Initialized
INFO - 2016-05-23 11:43:29 --> Output Class Initialized
INFO - 2016-05-23 11:43:29 --> Security Class Initialized
DEBUG - 2016-05-23 11:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:43:29 --> CSRF cookie sent
INFO - 2016-05-23 11:43:29 --> Input Class Initialized
INFO - 2016-05-23 11:43:29 --> Language Class Initialized
ERROR - 2016-05-23 11:43:29 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:49:46 --> Config Class Initialized
INFO - 2016-05-23 11:49:46 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:49:46 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:49:46 --> Utf8 Class Initialized
INFO - 2016-05-23 11:49:46 --> URI Class Initialized
DEBUG - 2016-05-23 11:49:46 --> No URI present. Default controller set.
INFO - 2016-05-23 11:49:46 --> Router Class Initialized
INFO - 2016-05-23 11:49:46 --> Output Class Initialized
INFO - 2016-05-23 11:49:46 --> Security Class Initialized
DEBUG - 2016-05-23 11:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:49:46 --> CSRF cookie sent
INFO - 2016-05-23 11:49:46 --> Input Class Initialized
INFO - 2016-05-23 11:49:46 --> Language Class Initialized
INFO - 2016-05-23 11:49:46 --> Loader Class Initialized
INFO - 2016-05-23 11:49:46 --> Helper loaded: form_helper
INFO - 2016-05-23 11:49:46 --> Database Driver Class Initialized
INFO - 2016-05-23 11:49:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:49:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:49:46 --> Email Class Initialized
INFO - 2016-05-23 11:49:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:49:46 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:49:46 --> Helper loaded: language_helper
INFO - 2016-05-23 11:49:46 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:49:46 --> Model Class Initialized
INFO - 2016-05-23 11:49:46 --> Helper loaded: date_helper
INFO - 2016-05-23 11:49:46 --> Controller Class Initialized
INFO - 2016-05-23 11:49:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:49:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:49:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:49:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:49:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:49:46 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:49:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:49:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:49:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:49:46 --> Final output sent to browser
DEBUG - 2016-05-23 11:49:46 --> Total execution time: 0.0190
INFO - 2016-05-23 11:49:46 --> Config Class Initialized
INFO - 2016-05-23 11:49:46 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:49:46 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:49:46 --> Utf8 Class Initialized
INFO - 2016-05-23 11:49:46 --> URI Class Initialized
INFO - 2016-05-23 11:49:46 --> Router Class Initialized
INFO - 2016-05-23 11:49:46 --> Output Class Initialized
INFO - 2016-05-23 11:49:46 --> Security Class Initialized
DEBUG - 2016-05-23 11:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:49:46 --> CSRF cookie sent
INFO - 2016-05-23 11:49:46 --> Input Class Initialized
INFO - 2016-05-23 11:49:46 --> Language Class Initialized
ERROR - 2016-05-23 11:49:46 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:50:13 --> Config Class Initialized
INFO - 2016-05-23 11:50:13 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:50:13 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:50:13 --> Utf8 Class Initialized
INFO - 2016-05-23 11:50:13 --> URI Class Initialized
INFO - 2016-05-23 11:50:13 --> Router Class Initialized
INFO - 2016-05-23 11:50:13 --> Output Class Initialized
INFO - 2016-05-23 11:50:13 --> Security Class Initialized
DEBUG - 2016-05-23 11:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:50:13 --> CSRF cookie sent
INFO - 2016-05-23 11:50:13 --> Input Class Initialized
INFO - 2016-05-23 11:50:13 --> Language Class Initialized
ERROR - 2016-05-23 11:50:13 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 11:50:43 --> Config Class Initialized
INFO - 2016-05-23 11:50:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:50:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:50:43 --> Utf8 Class Initialized
INFO - 2016-05-23 11:50:43 --> URI Class Initialized
DEBUG - 2016-05-23 11:50:43 --> No URI present. Default controller set.
INFO - 2016-05-23 11:50:43 --> Router Class Initialized
INFO - 2016-05-23 11:50:43 --> Output Class Initialized
INFO - 2016-05-23 11:50:43 --> Security Class Initialized
DEBUG - 2016-05-23 11:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:50:43 --> CSRF cookie sent
INFO - 2016-05-23 11:50:43 --> Input Class Initialized
INFO - 2016-05-23 11:50:43 --> Language Class Initialized
INFO - 2016-05-23 11:50:43 --> Loader Class Initialized
INFO - 2016-05-23 11:50:43 --> Helper loaded: form_helper
INFO - 2016-05-23 11:50:43 --> Database Driver Class Initialized
INFO - 2016-05-23 11:50:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:50:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:50:43 --> Email Class Initialized
INFO - 2016-05-23 11:50:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:50:43 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:50:43 --> Helper loaded: language_helper
INFO - 2016-05-23 11:50:43 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:50:43 --> Model Class Initialized
INFO - 2016-05-23 11:50:43 --> Helper loaded: date_helper
INFO - 2016-05-23 11:50:43 --> Controller Class Initialized
INFO - 2016-05-23 11:50:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:50:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:50:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:50:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:50:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:50:43 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:50:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:50:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:50:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:50:43 --> Final output sent to browser
DEBUG - 2016-05-23 11:50:43 --> Total execution time: 0.0892
INFO - 2016-05-23 11:50:43 --> Config Class Initialized
INFO - 2016-05-23 11:50:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:50:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:50:43 --> Utf8 Class Initialized
INFO - 2016-05-23 11:50:43 --> URI Class Initialized
INFO - 2016-05-23 11:50:43 --> Router Class Initialized
INFO - 2016-05-23 11:50:43 --> Output Class Initialized
INFO - 2016-05-23 11:50:43 --> Security Class Initialized
DEBUG - 2016-05-23 11:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:50:43 --> CSRF cookie sent
INFO - 2016-05-23 11:50:43 --> Input Class Initialized
INFO - 2016-05-23 11:50:43 --> Language Class Initialized
ERROR - 2016-05-23 11:50:43 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:50:50 --> Config Class Initialized
INFO - 2016-05-23 11:50:50 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:50:50 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:50:50 --> Utf8 Class Initialized
INFO - 2016-05-23 11:50:50 --> URI Class Initialized
INFO - 2016-05-23 11:50:50 --> Router Class Initialized
INFO - 2016-05-23 11:50:50 --> Output Class Initialized
INFO - 2016-05-23 11:50:50 --> Security Class Initialized
DEBUG - 2016-05-23 11:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:50:50 --> CSRF cookie sent
INFO - 2016-05-23 11:50:50 --> Input Class Initialized
INFO - 2016-05-23 11:50:50 --> Language Class Initialized
ERROR - 2016-05-23 11:50:50 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 11:51:28 --> Config Class Initialized
INFO - 2016-05-23 11:51:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:51:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:51:28 --> Utf8 Class Initialized
INFO - 2016-05-23 11:51:28 --> URI Class Initialized
INFO - 2016-05-23 11:51:28 --> Router Class Initialized
INFO - 2016-05-23 11:51:28 --> Output Class Initialized
INFO - 2016-05-23 11:51:28 --> Security Class Initialized
DEBUG - 2016-05-23 11:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:51:28 --> CSRF cookie sent
INFO - 2016-05-23 11:51:28 --> Input Class Initialized
INFO - 2016-05-23 11:51:28 --> Language Class Initialized
ERROR - 2016-05-23 11:51:28 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 11:53:10 --> Config Class Initialized
INFO - 2016-05-23 11:53:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:53:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:53:10 --> Utf8 Class Initialized
INFO - 2016-05-23 11:53:10 --> URI Class Initialized
DEBUG - 2016-05-23 11:53:10 --> No URI present. Default controller set.
INFO - 2016-05-23 11:53:10 --> Router Class Initialized
INFO - 2016-05-23 11:53:10 --> Output Class Initialized
INFO - 2016-05-23 11:53:10 --> Security Class Initialized
DEBUG - 2016-05-23 11:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:53:10 --> CSRF cookie sent
INFO - 2016-05-23 11:53:10 --> Input Class Initialized
INFO - 2016-05-23 11:53:10 --> Language Class Initialized
INFO - 2016-05-23 11:53:10 --> Loader Class Initialized
INFO - 2016-05-23 11:53:10 --> Helper loaded: form_helper
INFO - 2016-05-23 11:53:10 --> Database Driver Class Initialized
INFO - 2016-05-23 11:53:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 11:53:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 11:53:10 --> Email Class Initialized
INFO - 2016-05-23 11:53:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 11:53:10 --> Helper loaded: cookie_helper
INFO - 2016-05-23 11:53:10 --> Helper loaded: language_helper
INFO - 2016-05-23 11:53:10 --> Helper loaded: url_helper
DEBUG - 2016-05-23 11:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 11:53:10 --> Model Class Initialized
INFO - 2016-05-23 11:53:10 --> Helper loaded: date_helper
INFO - 2016-05-23 11:53:10 --> Controller Class Initialized
INFO - 2016-05-23 11:53:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 11:53:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 11:53:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 11:53:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 11:53:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 11:53:10 --> Helper loaded: languages_helper
INFO - 2016-05-23 11:53:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 11:53:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 11:53:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 11:53:10 --> Final output sent to browser
DEBUG - 2016-05-23 11:53:10 --> Total execution time: 0.0553
INFO - 2016-05-23 11:53:10 --> Config Class Initialized
INFO - 2016-05-23 11:53:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:53:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:53:10 --> Utf8 Class Initialized
INFO - 2016-05-23 11:53:10 --> URI Class Initialized
INFO - 2016-05-23 11:53:10 --> Router Class Initialized
INFO - 2016-05-23 11:53:10 --> Output Class Initialized
INFO - 2016-05-23 11:53:10 --> Security Class Initialized
DEBUG - 2016-05-23 11:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:53:10 --> CSRF cookie sent
INFO - 2016-05-23 11:53:10 --> Input Class Initialized
INFO - 2016-05-23 11:53:10 --> Language Class Initialized
ERROR - 2016-05-23 11:53:10 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 11:53:15 --> Config Class Initialized
INFO - 2016-05-23 11:53:15 --> Hooks Class Initialized
DEBUG - 2016-05-23 11:53:15 --> UTF-8 Support Enabled
INFO - 2016-05-23 11:53:15 --> Utf8 Class Initialized
INFO - 2016-05-23 11:53:15 --> URI Class Initialized
INFO - 2016-05-23 11:53:15 --> Router Class Initialized
INFO - 2016-05-23 11:53:15 --> Output Class Initialized
INFO - 2016-05-23 11:53:15 --> Security Class Initialized
DEBUG - 2016-05-23 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 11:53:15 --> CSRF cookie sent
INFO - 2016-05-23 11:53:15 --> Input Class Initialized
INFO - 2016-05-23 11:53:15 --> Language Class Initialized
ERROR - 2016-05-23 11:53:15 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:01:10 --> Config Class Initialized
INFO - 2016-05-23 12:01:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:01:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:01:10 --> Utf8 Class Initialized
INFO - 2016-05-23 12:01:10 --> URI Class Initialized
DEBUG - 2016-05-23 12:01:10 --> No URI present. Default controller set.
INFO - 2016-05-23 12:01:10 --> Router Class Initialized
INFO - 2016-05-23 12:01:10 --> Output Class Initialized
INFO - 2016-05-23 12:01:10 --> Security Class Initialized
DEBUG - 2016-05-23 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:01:10 --> CSRF cookie sent
INFO - 2016-05-23 12:01:10 --> Input Class Initialized
INFO - 2016-05-23 12:01:10 --> Language Class Initialized
INFO - 2016-05-23 12:01:10 --> Loader Class Initialized
INFO - 2016-05-23 12:01:10 --> Helper loaded: form_helper
INFO - 2016-05-23 12:01:10 --> Database Driver Class Initialized
INFO - 2016-05-23 12:01:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:01:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:01:10 --> Email Class Initialized
INFO - 2016-05-23 12:01:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:01:10 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:01:10 --> Helper loaded: language_helper
INFO - 2016-05-23 12:01:10 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:01:10 --> Model Class Initialized
INFO - 2016-05-23 12:01:10 --> Helper loaded: date_helper
INFO - 2016-05-23 12:01:10 --> Controller Class Initialized
INFO - 2016-05-23 12:01:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:01:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:01:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:01:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:01:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:01:10 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:01:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:01:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:01:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:01:10 --> Final output sent to browser
DEBUG - 2016-05-23 12:01:10 --> Total execution time: 0.0366
INFO - 2016-05-23 12:01:11 --> Config Class Initialized
INFO - 2016-05-23 12:01:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:01:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:01:11 --> Utf8 Class Initialized
INFO - 2016-05-23 12:01:11 --> URI Class Initialized
INFO - 2016-05-23 12:01:11 --> Router Class Initialized
INFO - 2016-05-23 12:01:11 --> Output Class Initialized
INFO - 2016-05-23 12:01:11 --> Security Class Initialized
DEBUG - 2016-05-23 12:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:01:11 --> CSRF cookie sent
INFO - 2016-05-23 12:01:11 --> Input Class Initialized
INFO - 2016-05-23 12:01:11 --> Language Class Initialized
ERROR - 2016-05-23 12:01:11 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:01:17 --> Config Class Initialized
INFO - 2016-05-23 12:01:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:01:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:01:17 --> Utf8 Class Initialized
INFO - 2016-05-23 12:01:17 --> URI Class Initialized
INFO - 2016-05-23 12:01:17 --> Router Class Initialized
INFO - 2016-05-23 12:01:17 --> Output Class Initialized
INFO - 2016-05-23 12:01:17 --> Security Class Initialized
DEBUG - 2016-05-23 12:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:01:17 --> CSRF cookie sent
INFO - 2016-05-23 12:01:17 --> Input Class Initialized
INFO - 2016-05-23 12:01:17 --> Language Class Initialized
ERROR - 2016-05-23 12:01:17 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:02:16 --> Config Class Initialized
INFO - 2016-05-23 12:02:16 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:16 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:16 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:16 --> URI Class Initialized
DEBUG - 2016-05-23 12:02:16 --> No URI present. Default controller set.
INFO - 2016-05-23 12:02:16 --> Router Class Initialized
INFO - 2016-05-23 12:02:16 --> Output Class Initialized
INFO - 2016-05-23 12:02:16 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:16 --> CSRF cookie sent
INFO - 2016-05-23 12:02:16 --> Input Class Initialized
INFO - 2016-05-23 12:02:16 --> Language Class Initialized
INFO - 2016-05-23 12:02:16 --> Loader Class Initialized
INFO - 2016-05-23 12:02:16 --> Helper loaded: form_helper
INFO - 2016-05-23 12:02:16 --> Database Driver Class Initialized
INFO - 2016-05-23 12:02:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:02:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:02:16 --> Email Class Initialized
INFO - 2016-05-23 12:02:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:02:16 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:02:16 --> Helper loaded: language_helper
INFO - 2016-05-23 12:02:16 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:02:16 --> Model Class Initialized
INFO - 2016-05-23 12:02:16 --> Helper loaded: date_helper
INFO - 2016-05-23 12:02:16 --> Controller Class Initialized
INFO - 2016-05-23 12:02:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:02:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:02:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:02:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:02:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:02:16 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:02:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:02:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:02:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:02:16 --> Final output sent to browser
DEBUG - 2016-05-23 12:02:16 --> Total execution time: 0.0429
INFO - 2016-05-23 12:02:16 --> Config Class Initialized
INFO - 2016-05-23 12:02:16 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:16 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:16 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:16 --> URI Class Initialized
INFO - 2016-05-23 12:02:16 --> Router Class Initialized
INFO - 2016-05-23 12:02:16 --> Output Class Initialized
INFO - 2016-05-23 12:02:16 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:16 --> CSRF cookie sent
INFO - 2016-05-23 12:02:16 --> Input Class Initialized
INFO - 2016-05-23 12:02:16 --> Language Class Initialized
ERROR - 2016-05-23 12:02:16 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:02:25 --> Config Class Initialized
INFO - 2016-05-23 12:02:25 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:25 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:25 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:25 --> URI Class Initialized
INFO - 2016-05-23 12:02:25 --> Router Class Initialized
INFO - 2016-05-23 12:02:25 --> Output Class Initialized
INFO - 2016-05-23 12:02:25 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:25 --> CSRF cookie sent
INFO - 2016-05-23 12:02:25 --> Input Class Initialized
INFO - 2016-05-23 12:02:25 --> Language Class Initialized
ERROR - 2016-05-23 12:02:25 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:02:28 --> Config Class Initialized
INFO - 2016-05-23 12:02:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:28 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:28 --> URI Class Initialized
DEBUG - 2016-05-23 12:02:28 --> No URI present. Default controller set.
INFO - 2016-05-23 12:02:28 --> Router Class Initialized
INFO - 2016-05-23 12:02:28 --> Output Class Initialized
INFO - 2016-05-23 12:02:28 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:28 --> CSRF cookie sent
INFO - 2016-05-23 12:02:28 --> Input Class Initialized
INFO - 2016-05-23 12:02:28 --> Language Class Initialized
INFO - 2016-05-23 12:02:28 --> Loader Class Initialized
INFO - 2016-05-23 12:02:28 --> Helper loaded: form_helper
INFO - 2016-05-23 12:02:28 --> Database Driver Class Initialized
INFO - 2016-05-23 12:02:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:02:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:02:28 --> Email Class Initialized
INFO - 2016-05-23 12:02:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:02:28 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:02:28 --> Helper loaded: language_helper
INFO - 2016-05-23 12:02:28 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:02:28 --> Model Class Initialized
INFO - 2016-05-23 12:02:28 --> Helper loaded: date_helper
INFO - 2016-05-23 12:02:28 --> Controller Class Initialized
INFO - 2016-05-23 12:02:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:02:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:02:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:02:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:02:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:02:28 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:02:28 --> Final output sent to browser
DEBUG - 2016-05-23 12:02:28 --> Total execution time: 0.0295
INFO - 2016-05-23 12:02:29 --> Config Class Initialized
INFO - 2016-05-23 12:02:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:29 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:29 --> URI Class Initialized
INFO - 2016-05-23 12:02:29 --> Router Class Initialized
INFO - 2016-05-23 12:02:29 --> Output Class Initialized
INFO - 2016-05-23 12:02:29 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:29 --> CSRF cookie sent
INFO - 2016-05-23 12:02:29 --> Input Class Initialized
INFO - 2016-05-23 12:02:29 --> Language Class Initialized
ERROR - 2016-05-23 12:02:29 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:02:35 --> Config Class Initialized
INFO - 2016-05-23 12:02:35 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:35 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:35 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:35 --> URI Class Initialized
INFO - 2016-05-23 12:02:35 --> Router Class Initialized
INFO - 2016-05-23 12:02:35 --> Output Class Initialized
INFO - 2016-05-23 12:02:35 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:35 --> CSRF cookie sent
INFO - 2016-05-23 12:02:35 --> Input Class Initialized
INFO - 2016-05-23 12:02:35 --> Language Class Initialized
ERROR - 2016-05-23 12:02:35 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:02:56 --> Config Class Initialized
INFO - 2016-05-23 12:02:56 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:56 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:56 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:56 --> URI Class Initialized
DEBUG - 2016-05-23 12:02:56 --> No URI present. Default controller set.
INFO - 2016-05-23 12:02:56 --> Router Class Initialized
INFO - 2016-05-23 12:02:56 --> Output Class Initialized
INFO - 2016-05-23 12:02:56 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:56 --> CSRF cookie sent
INFO - 2016-05-23 12:02:56 --> Input Class Initialized
INFO - 2016-05-23 12:02:56 --> Language Class Initialized
INFO - 2016-05-23 12:02:56 --> Loader Class Initialized
INFO - 2016-05-23 12:02:56 --> Helper loaded: form_helper
INFO - 2016-05-23 12:02:56 --> Database Driver Class Initialized
INFO - 2016-05-23 12:02:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:02:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:02:56 --> Email Class Initialized
INFO - 2016-05-23 12:02:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:02:56 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:02:56 --> Helper loaded: language_helper
INFO - 2016-05-23 12:02:56 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:02:56 --> Model Class Initialized
INFO - 2016-05-23 12:02:56 --> Helper loaded: date_helper
INFO - 2016-05-23 12:02:56 --> Controller Class Initialized
INFO - 2016-05-23 12:02:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:02:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:02:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:02:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:02:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:02:56 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:02:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:02:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:02:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:02:56 --> Final output sent to browser
DEBUG - 2016-05-23 12:02:56 --> Total execution time: 0.0248
INFO - 2016-05-23 12:02:57 --> Config Class Initialized
INFO - 2016-05-23 12:02:57 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:02:57 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:02:57 --> Utf8 Class Initialized
INFO - 2016-05-23 12:02:57 --> URI Class Initialized
INFO - 2016-05-23 12:02:57 --> Router Class Initialized
INFO - 2016-05-23 12:02:57 --> Output Class Initialized
INFO - 2016-05-23 12:02:57 --> Security Class Initialized
DEBUG - 2016-05-23 12:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:02:57 --> CSRF cookie sent
INFO - 2016-05-23 12:02:57 --> Input Class Initialized
INFO - 2016-05-23 12:02:57 --> Language Class Initialized
ERROR - 2016-05-23 12:02:57 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:03:04 --> Config Class Initialized
INFO - 2016-05-23 12:03:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:03:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:03:04 --> Utf8 Class Initialized
INFO - 2016-05-23 12:03:04 --> URI Class Initialized
INFO - 2016-05-23 12:03:04 --> Router Class Initialized
INFO - 2016-05-23 12:03:04 --> Output Class Initialized
INFO - 2016-05-23 12:03:04 --> Security Class Initialized
DEBUG - 2016-05-23 12:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:03:04 --> CSRF cookie sent
INFO - 2016-05-23 12:03:04 --> Input Class Initialized
INFO - 2016-05-23 12:03:04 --> Language Class Initialized
ERROR - 2016-05-23 12:03:04 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:12:58 --> Config Class Initialized
INFO - 2016-05-23 12:12:58 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:12:58 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:12:58 --> Utf8 Class Initialized
INFO - 2016-05-23 12:12:58 --> URI Class Initialized
DEBUG - 2016-05-23 12:12:58 --> No URI present. Default controller set.
INFO - 2016-05-23 12:12:58 --> Router Class Initialized
INFO - 2016-05-23 12:12:58 --> Output Class Initialized
INFO - 2016-05-23 12:12:58 --> Security Class Initialized
DEBUG - 2016-05-23 12:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:12:58 --> CSRF cookie sent
INFO - 2016-05-23 12:12:58 --> Input Class Initialized
INFO - 2016-05-23 12:12:58 --> Language Class Initialized
INFO - 2016-05-23 12:12:58 --> Loader Class Initialized
INFO - 2016-05-23 12:12:58 --> Helper loaded: form_helper
INFO - 2016-05-23 12:12:58 --> Database Driver Class Initialized
INFO - 2016-05-23 12:12:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:12:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:12:58 --> Email Class Initialized
INFO - 2016-05-23 12:12:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:12:58 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:12:58 --> Helper loaded: language_helper
INFO - 2016-05-23 12:12:58 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:12:58 --> Model Class Initialized
INFO - 2016-05-23 12:12:58 --> Helper loaded: date_helper
INFO - 2016-05-23 12:12:58 --> Controller Class Initialized
INFO - 2016-05-23 12:12:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:12:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:12:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:12:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:12:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:12:58 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:12:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:12:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:12:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:12:58 --> Final output sent to browser
DEBUG - 2016-05-23 12:12:58 --> Total execution time: 0.0300
INFO - 2016-05-23 12:13:03 --> Config Class Initialized
INFO - 2016-05-23 12:13:03 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:13:03 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:13:03 --> Utf8 Class Initialized
INFO - 2016-05-23 12:13:03 --> URI Class Initialized
INFO - 2016-05-23 12:13:03 --> Router Class Initialized
INFO - 2016-05-23 12:13:03 --> Output Class Initialized
INFO - 2016-05-23 12:13:03 --> Security Class Initialized
DEBUG - 2016-05-23 12:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:13:03 --> CSRF cookie sent
INFO - 2016-05-23 12:13:03 --> Input Class Initialized
INFO - 2016-05-23 12:13:03 --> Language Class Initialized
ERROR - 2016-05-23 12:13:03 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:13:11 --> Config Class Initialized
INFO - 2016-05-23 12:13:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:13:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:13:11 --> Utf8 Class Initialized
INFO - 2016-05-23 12:13:11 --> URI Class Initialized
INFO - 2016-05-23 12:13:11 --> Router Class Initialized
INFO - 2016-05-23 12:13:11 --> Output Class Initialized
INFO - 2016-05-23 12:13:11 --> Security Class Initialized
DEBUG - 2016-05-23 12:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:13:11 --> CSRF cookie sent
INFO - 2016-05-23 12:13:11 --> Input Class Initialized
INFO - 2016-05-23 12:13:11 --> Language Class Initialized
ERROR - 2016-05-23 12:13:11 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:14:16 --> Config Class Initialized
INFO - 2016-05-23 12:14:16 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:14:16 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:14:16 --> Utf8 Class Initialized
INFO - 2016-05-23 12:14:16 --> URI Class Initialized
DEBUG - 2016-05-23 12:14:16 --> No URI present. Default controller set.
INFO - 2016-05-23 12:14:16 --> Router Class Initialized
INFO - 2016-05-23 12:14:16 --> Output Class Initialized
INFO - 2016-05-23 12:14:16 --> Security Class Initialized
DEBUG - 2016-05-23 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:14:16 --> CSRF cookie sent
INFO - 2016-05-23 12:14:16 --> Input Class Initialized
INFO - 2016-05-23 12:14:16 --> Language Class Initialized
INFO - 2016-05-23 12:14:16 --> Loader Class Initialized
INFO - 2016-05-23 12:14:16 --> Helper loaded: form_helper
INFO - 2016-05-23 12:14:16 --> Database Driver Class Initialized
INFO - 2016-05-23 12:14:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:14:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:14:16 --> Email Class Initialized
INFO - 2016-05-23 12:14:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:14:16 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:14:16 --> Helper loaded: language_helper
INFO - 2016-05-23 12:14:16 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:14:16 --> Model Class Initialized
INFO - 2016-05-23 12:14:16 --> Helper loaded: date_helper
INFO - 2016-05-23 12:14:16 --> Controller Class Initialized
INFO - 2016-05-23 12:14:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:14:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:14:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:14:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:14:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:14:16 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:14:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:14:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:14:16 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:14:16 --> Final output sent to browser
DEBUG - 2016-05-23 12:14:16 --> Total execution time: 0.0464
INFO - 2016-05-23 12:14:17 --> Config Class Initialized
INFO - 2016-05-23 12:14:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:14:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:14:17 --> Utf8 Class Initialized
INFO - 2016-05-23 12:14:17 --> URI Class Initialized
INFO - 2016-05-23 12:14:17 --> Router Class Initialized
INFO - 2016-05-23 12:14:17 --> Output Class Initialized
INFO - 2016-05-23 12:14:17 --> Security Class Initialized
DEBUG - 2016-05-23 12:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:14:17 --> CSRF cookie sent
INFO - 2016-05-23 12:14:17 --> Input Class Initialized
INFO - 2016-05-23 12:14:17 --> Language Class Initialized
ERROR - 2016-05-23 12:14:17 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:14:25 --> Config Class Initialized
INFO - 2016-05-23 12:14:25 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:14:25 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:14:25 --> Utf8 Class Initialized
INFO - 2016-05-23 12:14:25 --> URI Class Initialized
INFO - 2016-05-23 12:14:25 --> Router Class Initialized
INFO - 2016-05-23 12:14:25 --> Output Class Initialized
INFO - 2016-05-23 12:14:25 --> Security Class Initialized
DEBUG - 2016-05-23 12:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:14:25 --> CSRF cookie sent
INFO - 2016-05-23 12:14:25 --> Input Class Initialized
INFO - 2016-05-23 12:14:25 --> Language Class Initialized
ERROR - 2016-05-23 12:14:25 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:24:46 --> Config Class Initialized
INFO - 2016-05-23 12:24:46 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:24:46 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:24:46 --> Utf8 Class Initialized
INFO - 2016-05-23 12:24:46 --> URI Class Initialized
DEBUG - 2016-05-23 12:24:46 --> No URI present. Default controller set.
INFO - 2016-05-23 12:24:46 --> Router Class Initialized
INFO - 2016-05-23 12:24:46 --> Output Class Initialized
INFO - 2016-05-23 12:24:46 --> Security Class Initialized
DEBUG - 2016-05-23 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:24:46 --> CSRF cookie sent
INFO - 2016-05-23 12:24:46 --> Input Class Initialized
INFO - 2016-05-23 12:24:46 --> Language Class Initialized
INFO - 2016-05-23 12:24:46 --> Loader Class Initialized
INFO - 2016-05-23 12:24:46 --> Helper loaded: form_helper
INFO - 2016-05-23 12:24:46 --> Database Driver Class Initialized
INFO - 2016-05-23 12:24:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:24:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:24:46 --> Email Class Initialized
INFO - 2016-05-23 12:24:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:24:46 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:24:46 --> Helper loaded: language_helper
INFO - 2016-05-23 12:24:46 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:24:46 --> Model Class Initialized
INFO - 2016-05-23 12:24:46 --> Helper loaded: date_helper
INFO - 2016-05-23 12:24:46 --> Controller Class Initialized
INFO - 2016-05-23 12:24:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:24:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:24:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:24:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:24:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:24:46 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:24:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:24:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:24:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:24:46 --> Final output sent to browser
DEBUG - 2016-05-23 12:24:46 --> Total execution time: 0.0427
INFO - 2016-05-23 12:24:47 --> Config Class Initialized
INFO - 2016-05-23 12:24:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:24:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:24:47 --> Utf8 Class Initialized
INFO - 2016-05-23 12:24:47 --> URI Class Initialized
INFO - 2016-05-23 12:24:47 --> Router Class Initialized
INFO - 2016-05-23 12:24:47 --> Output Class Initialized
INFO - 2016-05-23 12:24:47 --> Security Class Initialized
DEBUG - 2016-05-23 12:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:24:47 --> CSRF cookie sent
INFO - 2016-05-23 12:24:47 --> Input Class Initialized
INFO - 2016-05-23 12:24:47 --> Language Class Initialized
ERROR - 2016-05-23 12:24:47 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:24:53 --> Config Class Initialized
INFO - 2016-05-23 12:24:53 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:24:53 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:24:53 --> Utf8 Class Initialized
INFO - 2016-05-23 12:24:53 --> URI Class Initialized
INFO - 2016-05-23 12:24:53 --> Router Class Initialized
INFO - 2016-05-23 12:24:53 --> Output Class Initialized
INFO - 2016-05-23 12:24:53 --> Security Class Initialized
DEBUG - 2016-05-23 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:24:53 --> CSRF cookie sent
INFO - 2016-05-23 12:24:53 --> Input Class Initialized
INFO - 2016-05-23 12:24:53 --> Language Class Initialized
ERROR - 2016-05-23 12:24:53 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:27:27 --> Config Class Initialized
INFO - 2016-05-23 12:27:27 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:27:27 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:27:27 --> Utf8 Class Initialized
INFO - 2016-05-23 12:27:27 --> URI Class Initialized
DEBUG - 2016-05-23 12:27:27 --> No URI present. Default controller set.
INFO - 2016-05-23 12:27:27 --> Router Class Initialized
INFO - 2016-05-23 12:27:27 --> Output Class Initialized
INFO - 2016-05-23 12:27:27 --> Security Class Initialized
DEBUG - 2016-05-23 12:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:27:27 --> CSRF cookie sent
INFO - 2016-05-23 12:27:27 --> Input Class Initialized
INFO - 2016-05-23 12:27:27 --> Language Class Initialized
INFO - 2016-05-23 12:27:27 --> Loader Class Initialized
INFO - 2016-05-23 12:27:27 --> Helper loaded: form_helper
INFO - 2016-05-23 12:27:27 --> Database Driver Class Initialized
INFO - 2016-05-23 12:27:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:27:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:27:27 --> Email Class Initialized
INFO - 2016-05-23 12:27:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:27:27 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:27:27 --> Helper loaded: language_helper
INFO - 2016-05-23 12:27:27 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:27:27 --> Model Class Initialized
INFO - 2016-05-23 12:27:27 --> Helper loaded: date_helper
INFO - 2016-05-23 12:27:27 --> Controller Class Initialized
INFO - 2016-05-23 12:27:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:27:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:27:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:27:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:27:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:27:27 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:27:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:27:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:27:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:27:27 --> Final output sent to browser
DEBUG - 2016-05-23 12:27:27 --> Total execution time: 0.0350
INFO - 2016-05-23 12:27:27 --> Config Class Initialized
INFO - 2016-05-23 12:27:27 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:27:27 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:27:27 --> Utf8 Class Initialized
INFO - 2016-05-23 12:27:27 --> URI Class Initialized
INFO - 2016-05-23 12:27:27 --> Router Class Initialized
INFO - 2016-05-23 12:27:27 --> Output Class Initialized
INFO - 2016-05-23 12:27:27 --> Security Class Initialized
DEBUG - 2016-05-23 12:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:27:27 --> CSRF cookie sent
INFO - 2016-05-23 12:27:27 --> Input Class Initialized
INFO - 2016-05-23 12:27:27 --> Language Class Initialized
ERROR - 2016-05-23 12:27:27 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:27:34 --> Config Class Initialized
INFO - 2016-05-23 12:27:34 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:27:34 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:27:34 --> Utf8 Class Initialized
INFO - 2016-05-23 12:27:34 --> URI Class Initialized
INFO - 2016-05-23 12:27:34 --> Router Class Initialized
INFO - 2016-05-23 12:27:34 --> Output Class Initialized
INFO - 2016-05-23 12:27:34 --> Security Class Initialized
DEBUG - 2016-05-23 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:27:34 --> CSRF cookie sent
INFO - 2016-05-23 12:27:34 --> Input Class Initialized
INFO - 2016-05-23 12:27:34 --> Language Class Initialized
ERROR - 2016-05-23 12:27:34 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:28:12 --> Config Class Initialized
INFO - 2016-05-23 12:28:12 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:28:12 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:28:12 --> Utf8 Class Initialized
INFO - 2016-05-23 12:28:12 --> URI Class Initialized
DEBUG - 2016-05-23 12:28:12 --> No URI present. Default controller set.
INFO - 2016-05-23 12:28:12 --> Router Class Initialized
INFO - 2016-05-23 12:28:12 --> Output Class Initialized
INFO - 2016-05-23 12:28:12 --> Security Class Initialized
DEBUG - 2016-05-23 12:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:28:12 --> CSRF cookie sent
INFO - 2016-05-23 12:28:12 --> Input Class Initialized
INFO - 2016-05-23 12:28:12 --> Language Class Initialized
INFO - 2016-05-23 12:28:12 --> Loader Class Initialized
INFO - 2016-05-23 12:28:12 --> Helper loaded: form_helper
INFO - 2016-05-23 12:28:12 --> Database Driver Class Initialized
INFO - 2016-05-23 12:28:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:28:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:28:12 --> Email Class Initialized
INFO - 2016-05-23 12:28:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:28:12 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:28:12 --> Helper loaded: language_helper
INFO - 2016-05-23 12:28:12 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:28:12 --> Model Class Initialized
INFO - 2016-05-23 12:28:12 --> Helper loaded: date_helper
INFO - 2016-05-23 12:28:12 --> Controller Class Initialized
INFO - 2016-05-23 12:28:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:28:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:28:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:28:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:28:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:28:12 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:28:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:28:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:28:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:28:12 --> Final output sent to browser
DEBUG - 2016-05-23 12:28:12 --> Total execution time: 0.0731
INFO - 2016-05-23 12:28:13 --> Config Class Initialized
INFO - 2016-05-23 12:28:13 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:28:13 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:28:13 --> Utf8 Class Initialized
INFO - 2016-05-23 12:28:13 --> URI Class Initialized
INFO - 2016-05-23 12:28:13 --> Router Class Initialized
INFO - 2016-05-23 12:28:13 --> Output Class Initialized
INFO - 2016-05-23 12:28:13 --> Security Class Initialized
DEBUG - 2016-05-23 12:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:28:13 --> CSRF cookie sent
INFO - 2016-05-23 12:28:13 --> Input Class Initialized
INFO - 2016-05-23 12:28:13 --> Language Class Initialized
ERROR - 2016-05-23 12:28:13 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:28:26 --> Config Class Initialized
INFO - 2016-05-23 12:28:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:28:26 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:28:26 --> Utf8 Class Initialized
INFO - 2016-05-23 12:28:26 --> URI Class Initialized
INFO - 2016-05-23 12:28:26 --> Router Class Initialized
INFO - 2016-05-23 12:28:26 --> Output Class Initialized
INFO - 2016-05-23 12:28:26 --> Security Class Initialized
DEBUG - 2016-05-23 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:28:26 --> CSRF cookie sent
INFO - 2016-05-23 12:28:26 --> Input Class Initialized
INFO - 2016-05-23 12:28:26 --> Language Class Initialized
ERROR - 2016-05-23 12:28:26 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:28:35 --> Config Class Initialized
INFO - 2016-05-23 12:28:35 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:28:35 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:28:35 --> Utf8 Class Initialized
INFO - 2016-05-23 12:28:35 --> URI Class Initialized
INFO - 2016-05-23 12:28:35 --> Router Class Initialized
INFO - 2016-05-23 12:28:35 --> Output Class Initialized
INFO - 2016-05-23 12:28:35 --> Security Class Initialized
DEBUG - 2016-05-23 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:28:35 --> CSRF cookie sent
INFO - 2016-05-23 12:28:35 --> CSRF token verified
INFO - 2016-05-23 12:28:35 --> Input Class Initialized
INFO - 2016-05-23 12:28:35 --> Language Class Initialized
INFO - 2016-05-23 12:28:35 --> Loader Class Initialized
INFO - 2016-05-23 12:28:35 --> Helper loaded: form_helper
INFO - 2016-05-23 12:28:35 --> Database Driver Class Initialized
INFO - 2016-05-23 12:28:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:28:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:28:35 --> Email Class Initialized
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:28:35 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:28:35 --> Helper loaded: language_helper
INFO - 2016-05-23 12:28:35 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:28:35 --> Model Class Initialized
INFO - 2016-05-23 12:28:35 --> Helper loaded: date_helper
INFO - 2016-05-23 12:28:35 --> Controller Class Initialized
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 12:28:35 --> Config Class Initialized
INFO - 2016-05-23 12:28:35 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:28:35 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:28:35 --> Utf8 Class Initialized
INFO - 2016-05-23 12:28:35 --> URI Class Initialized
DEBUG - 2016-05-23 12:28:35 --> No URI present. Default controller set.
INFO - 2016-05-23 12:28:35 --> Router Class Initialized
INFO - 2016-05-23 12:28:35 --> Output Class Initialized
INFO - 2016-05-23 12:28:35 --> Security Class Initialized
DEBUG - 2016-05-23 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:28:35 --> CSRF cookie sent
INFO - 2016-05-23 12:28:35 --> Input Class Initialized
INFO - 2016-05-23 12:28:35 --> Language Class Initialized
INFO - 2016-05-23 12:28:35 --> Loader Class Initialized
INFO - 2016-05-23 12:28:35 --> Helper loaded: form_helper
INFO - 2016-05-23 12:28:35 --> Database Driver Class Initialized
INFO - 2016-05-23 12:28:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:28:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:28:35 --> Email Class Initialized
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:28:35 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:28:35 --> Helper loaded: language_helper
INFO - 2016-05-23 12:28:35 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:28:35 --> Model Class Initialized
INFO - 2016-05-23 12:28:35 --> Helper loaded: date_helper
INFO - 2016-05-23 12:28:35 --> Controller Class Initialized
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:28:35 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:28:35 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:28:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:28:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:28:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:28:35 --> Final output sent to browser
DEBUG - 2016-05-23 12:28:35 --> Total execution time: 0.1338
INFO - 2016-05-23 12:28:39 --> Config Class Initialized
INFO - 2016-05-23 12:28:39 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:28:39 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:28:39 --> Utf8 Class Initialized
INFO - 2016-05-23 12:28:39 --> URI Class Initialized
INFO - 2016-05-23 12:28:39 --> Router Class Initialized
INFO - 2016-05-23 12:28:39 --> Output Class Initialized
INFO - 2016-05-23 12:28:39 --> Security Class Initialized
DEBUG - 2016-05-23 12:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:28:39 --> CSRF cookie sent
INFO - 2016-05-23 12:28:39 --> Input Class Initialized
INFO - 2016-05-23 12:28:39 --> Language Class Initialized
ERROR - 2016-05-23 12:28:39 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:35:21 --> Config Class Initialized
INFO - 2016-05-23 12:35:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:35:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:35:21 --> Utf8 Class Initialized
INFO - 2016-05-23 12:35:21 --> URI Class Initialized
DEBUG - 2016-05-23 12:35:21 --> No URI present. Default controller set.
INFO - 2016-05-23 12:35:21 --> Router Class Initialized
INFO - 2016-05-23 12:35:21 --> Output Class Initialized
INFO - 2016-05-23 12:35:21 --> Security Class Initialized
DEBUG - 2016-05-23 12:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:35:21 --> CSRF cookie sent
INFO - 2016-05-23 12:35:21 --> Input Class Initialized
INFO - 2016-05-23 12:35:21 --> Language Class Initialized
INFO - 2016-05-23 12:35:21 --> Loader Class Initialized
INFO - 2016-05-23 12:35:21 --> Helper loaded: form_helper
INFO - 2016-05-23 12:35:21 --> Database Driver Class Initialized
INFO - 2016-05-23 12:35:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:35:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:35:21 --> Email Class Initialized
INFO - 2016-05-23 12:35:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:35:21 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:35:21 --> Helper loaded: language_helper
INFO - 2016-05-23 12:35:21 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:35:21 --> Model Class Initialized
INFO - 2016-05-23 12:35:21 --> Helper loaded: date_helper
INFO - 2016-05-23 12:35:21 --> Controller Class Initialized
INFO - 2016-05-23 12:35:21 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:35:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:35:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:35:21 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:35:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:35:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:35:21 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:35:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:35:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:35:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:35:21 --> Final output sent to browser
DEBUG - 2016-05-23 12:35:21 --> Total execution time: 0.0341
INFO - 2016-05-23 12:35:21 --> Config Class Initialized
INFO - 2016-05-23 12:35:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:35:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:35:21 --> Utf8 Class Initialized
INFO - 2016-05-23 12:35:21 --> URI Class Initialized
INFO - 2016-05-23 12:35:21 --> Router Class Initialized
INFO - 2016-05-23 12:35:21 --> Output Class Initialized
INFO - 2016-05-23 12:35:21 --> Security Class Initialized
DEBUG - 2016-05-23 12:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:35:21 --> CSRF cookie sent
INFO - 2016-05-23 12:35:21 --> Input Class Initialized
INFO - 2016-05-23 12:35:21 --> Language Class Initialized
ERROR - 2016-05-23 12:35:21 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:35:55 --> Config Class Initialized
INFO - 2016-05-23 12:35:55 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:35:55 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:35:55 --> Utf8 Class Initialized
INFO - 2016-05-23 12:35:55 --> URI Class Initialized
INFO - 2016-05-23 12:35:55 --> Router Class Initialized
INFO - 2016-05-23 12:35:55 --> Output Class Initialized
INFO - 2016-05-23 12:35:55 --> Security Class Initialized
DEBUG - 2016-05-23 12:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:35:55 --> CSRF cookie sent
INFO - 2016-05-23 12:35:55 --> Input Class Initialized
INFO - 2016-05-23 12:35:55 --> Language Class Initialized
ERROR - 2016-05-23 12:35:55 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:36:02 --> Config Class Initialized
INFO - 2016-05-23 12:36:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:36:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:36:02 --> Utf8 Class Initialized
INFO - 2016-05-23 12:36:02 --> URI Class Initialized
DEBUG - 2016-05-23 12:36:02 --> No URI present. Default controller set.
INFO - 2016-05-23 12:36:02 --> Router Class Initialized
INFO - 2016-05-23 12:36:02 --> Output Class Initialized
INFO - 2016-05-23 12:36:02 --> Security Class Initialized
DEBUG - 2016-05-23 12:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:36:02 --> CSRF cookie sent
INFO - 2016-05-23 12:36:02 --> Input Class Initialized
INFO - 2016-05-23 12:36:02 --> Language Class Initialized
INFO - 2016-05-23 12:36:02 --> Loader Class Initialized
INFO - 2016-05-23 12:36:02 --> Helper loaded: form_helper
INFO - 2016-05-23 12:36:02 --> Database Driver Class Initialized
INFO - 2016-05-23 12:36:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:36:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:36:02 --> Email Class Initialized
INFO - 2016-05-23 12:36:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:36:02 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:36:02 --> Helper loaded: language_helper
INFO - 2016-05-23 12:36:02 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:36:02 --> Model Class Initialized
INFO - 2016-05-23 12:36:02 --> Helper loaded: date_helper
INFO - 2016-05-23 12:36:02 --> Controller Class Initialized
INFO - 2016-05-23 12:36:02 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:36:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:36:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:36:02 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:36:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:36:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:36:02 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:36:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:36:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:36:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:36:02 --> Final output sent to browser
DEBUG - 2016-05-23 12:36:02 --> Total execution time: 0.0508
INFO - 2016-05-23 12:36:03 --> Config Class Initialized
INFO - 2016-05-23 12:36:03 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:36:03 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:36:03 --> Utf8 Class Initialized
INFO - 2016-05-23 12:36:03 --> URI Class Initialized
INFO - 2016-05-23 12:36:03 --> Router Class Initialized
INFO - 2016-05-23 12:36:03 --> Output Class Initialized
INFO - 2016-05-23 12:36:03 --> Security Class Initialized
DEBUG - 2016-05-23 12:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:36:03 --> CSRF cookie sent
INFO - 2016-05-23 12:36:03 --> Input Class Initialized
INFO - 2016-05-23 12:36:03 --> Language Class Initialized
ERROR - 2016-05-23 12:36:03 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:36:10 --> Config Class Initialized
INFO - 2016-05-23 12:36:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:36:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:36:10 --> Utf8 Class Initialized
INFO - 2016-05-23 12:36:10 --> URI Class Initialized
INFO - 2016-05-23 12:36:10 --> Router Class Initialized
INFO - 2016-05-23 12:36:10 --> Output Class Initialized
INFO - 2016-05-23 12:36:10 --> Security Class Initialized
DEBUG - 2016-05-23 12:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:36:10 --> CSRF cookie sent
INFO - 2016-05-23 12:36:10 --> Input Class Initialized
INFO - 2016-05-23 12:36:10 --> Language Class Initialized
ERROR - 2016-05-23 12:36:10 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:36:36 --> Config Class Initialized
INFO - 2016-05-23 12:36:36 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:36:36 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:36:36 --> Utf8 Class Initialized
INFO - 2016-05-23 12:36:36 --> URI Class Initialized
DEBUG - 2016-05-23 12:36:36 --> No URI present. Default controller set.
INFO - 2016-05-23 12:36:36 --> Router Class Initialized
INFO - 2016-05-23 12:36:36 --> Output Class Initialized
INFO - 2016-05-23 12:36:36 --> Security Class Initialized
DEBUG - 2016-05-23 12:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:36:36 --> CSRF cookie sent
INFO - 2016-05-23 12:36:36 --> Input Class Initialized
INFO - 2016-05-23 12:36:36 --> Language Class Initialized
INFO - 2016-05-23 12:36:36 --> Loader Class Initialized
INFO - 2016-05-23 12:36:36 --> Helper loaded: form_helper
INFO - 2016-05-23 12:36:36 --> Database Driver Class Initialized
INFO - 2016-05-23 12:36:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:36:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:36:36 --> Email Class Initialized
INFO - 2016-05-23 12:36:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:36:36 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:36:36 --> Helper loaded: language_helper
INFO - 2016-05-23 12:36:36 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:36:36 --> Model Class Initialized
INFO - 2016-05-23 12:36:36 --> Helper loaded: date_helper
INFO - 2016-05-23 12:36:36 --> Controller Class Initialized
INFO - 2016-05-23 12:36:36 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:36:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:36:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:36:36 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:36:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:36:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:36:36 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:36:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:36:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:36:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:36:36 --> Final output sent to browser
DEBUG - 2016-05-23 12:36:36 --> Total execution time: 0.0716
INFO - 2016-05-23 12:36:38 --> Config Class Initialized
INFO - 2016-05-23 12:36:38 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:36:38 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:36:38 --> Utf8 Class Initialized
INFO - 2016-05-23 12:36:38 --> URI Class Initialized
INFO - 2016-05-23 12:36:38 --> Router Class Initialized
INFO - 2016-05-23 12:36:38 --> Output Class Initialized
INFO - 2016-05-23 12:36:38 --> Security Class Initialized
DEBUG - 2016-05-23 12:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:36:38 --> CSRF cookie sent
INFO - 2016-05-23 12:36:38 --> Input Class Initialized
INFO - 2016-05-23 12:36:38 --> Language Class Initialized
ERROR - 2016-05-23 12:36:38 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:36:43 --> Config Class Initialized
INFO - 2016-05-23 12:36:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:36:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:36:43 --> Utf8 Class Initialized
INFO - 2016-05-23 12:36:43 --> URI Class Initialized
INFO - 2016-05-23 12:36:43 --> Router Class Initialized
INFO - 2016-05-23 12:36:43 --> Output Class Initialized
INFO - 2016-05-23 12:36:43 --> Security Class Initialized
DEBUG - 2016-05-23 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:36:43 --> CSRF cookie sent
INFO - 2016-05-23 12:36:43 --> Input Class Initialized
INFO - 2016-05-23 12:36:43 --> Language Class Initialized
ERROR - 2016-05-23 12:36:43 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:40:10 --> Config Class Initialized
INFO - 2016-05-23 12:40:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:40:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:40:10 --> Utf8 Class Initialized
INFO - 2016-05-23 12:40:10 --> URI Class Initialized
DEBUG - 2016-05-23 12:40:10 --> No URI present. Default controller set.
INFO - 2016-05-23 12:40:10 --> Router Class Initialized
INFO - 2016-05-23 12:40:10 --> Output Class Initialized
INFO - 2016-05-23 12:40:10 --> Security Class Initialized
DEBUG - 2016-05-23 12:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:40:10 --> CSRF cookie sent
INFO - 2016-05-23 12:40:10 --> Input Class Initialized
INFO - 2016-05-23 12:40:10 --> Language Class Initialized
INFO - 2016-05-23 12:40:10 --> Loader Class Initialized
INFO - 2016-05-23 12:40:10 --> Helper loaded: form_helper
INFO - 2016-05-23 12:40:10 --> Database Driver Class Initialized
INFO - 2016-05-23 12:40:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:40:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:40:10 --> Email Class Initialized
INFO - 2016-05-23 12:40:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:40:10 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:40:10 --> Helper loaded: language_helper
INFO - 2016-05-23 12:40:10 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:40:10 --> Model Class Initialized
INFO - 2016-05-23 12:40:10 --> Helper loaded: date_helper
INFO - 2016-05-23 12:40:10 --> Controller Class Initialized
INFO - 2016-05-23 12:40:10 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:40:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:40:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:40:10 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:40:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:40:10 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:40:10 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:40:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:40:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:40:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:40:10 --> Final output sent to browser
DEBUG - 2016-05-23 12:40:10 --> Total execution time: 0.0620
INFO - 2016-05-23 12:40:10 --> Config Class Initialized
INFO - 2016-05-23 12:40:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:40:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:40:10 --> Utf8 Class Initialized
INFO - 2016-05-23 12:40:10 --> URI Class Initialized
INFO - 2016-05-23 12:40:10 --> Router Class Initialized
INFO - 2016-05-23 12:40:10 --> Output Class Initialized
INFO - 2016-05-23 12:40:10 --> Security Class Initialized
DEBUG - 2016-05-23 12:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:40:10 --> CSRF cookie sent
INFO - 2016-05-23 12:40:10 --> Input Class Initialized
INFO - 2016-05-23 12:40:10 --> Language Class Initialized
ERROR - 2016-05-23 12:40:10 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:40:17 --> Config Class Initialized
INFO - 2016-05-23 12:40:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:40:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:40:17 --> Utf8 Class Initialized
INFO - 2016-05-23 12:40:17 --> URI Class Initialized
INFO - 2016-05-23 12:40:17 --> Router Class Initialized
INFO - 2016-05-23 12:40:17 --> Output Class Initialized
INFO - 2016-05-23 12:40:17 --> Security Class Initialized
DEBUG - 2016-05-23 12:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:40:17 --> CSRF cookie sent
INFO - 2016-05-23 12:40:17 --> Input Class Initialized
INFO - 2016-05-23 12:40:17 --> Language Class Initialized
ERROR - 2016-05-23 12:40:17 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:40:28 --> Config Class Initialized
INFO - 2016-05-23 12:40:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:40:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:40:28 --> Utf8 Class Initialized
INFO - 2016-05-23 12:40:28 --> URI Class Initialized
DEBUG - 2016-05-23 12:40:28 --> No URI present. Default controller set.
INFO - 2016-05-23 12:40:28 --> Router Class Initialized
INFO - 2016-05-23 12:40:28 --> Output Class Initialized
INFO - 2016-05-23 12:40:28 --> Security Class Initialized
DEBUG - 2016-05-23 12:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:40:28 --> CSRF cookie sent
INFO - 2016-05-23 12:40:28 --> Input Class Initialized
INFO - 2016-05-23 12:40:28 --> Language Class Initialized
INFO - 2016-05-23 12:40:28 --> Loader Class Initialized
INFO - 2016-05-23 12:40:28 --> Helper loaded: form_helper
INFO - 2016-05-23 12:40:28 --> Database Driver Class Initialized
INFO - 2016-05-23 12:40:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:40:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:40:28 --> Email Class Initialized
INFO - 2016-05-23 12:40:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:40:28 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:40:28 --> Helper loaded: language_helper
INFO - 2016-05-23 12:40:28 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:40:28 --> Model Class Initialized
INFO - 2016-05-23 12:40:28 --> Helper loaded: date_helper
INFO - 2016-05-23 12:40:28 --> Controller Class Initialized
INFO - 2016-05-23 12:40:28 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:40:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:40:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:40:28 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:40:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:40:28 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:40:28 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:40:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:40:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:40:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:40:28 --> Final output sent to browser
DEBUG - 2016-05-23 12:40:28 --> Total execution time: 0.0536
INFO - 2016-05-23 12:40:29 --> Config Class Initialized
INFO - 2016-05-23 12:40:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:40:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:40:29 --> Utf8 Class Initialized
INFO - 2016-05-23 12:40:29 --> URI Class Initialized
INFO - 2016-05-23 12:40:29 --> Router Class Initialized
INFO - 2016-05-23 12:40:29 --> Output Class Initialized
INFO - 2016-05-23 12:40:29 --> Security Class Initialized
DEBUG - 2016-05-23 12:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:40:29 --> CSRF cookie sent
INFO - 2016-05-23 12:40:29 --> Input Class Initialized
INFO - 2016-05-23 12:40:29 --> Language Class Initialized
ERROR - 2016-05-23 12:40:29 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:40:36 --> Config Class Initialized
INFO - 2016-05-23 12:40:36 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:40:36 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:40:36 --> Utf8 Class Initialized
INFO - 2016-05-23 12:40:36 --> URI Class Initialized
INFO - 2016-05-23 12:40:36 --> Router Class Initialized
INFO - 2016-05-23 12:40:36 --> Output Class Initialized
INFO - 2016-05-23 12:40:36 --> Security Class Initialized
DEBUG - 2016-05-23 12:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:40:36 --> CSRF cookie sent
INFO - 2016-05-23 12:40:36 --> Input Class Initialized
INFO - 2016-05-23 12:40:36 --> Language Class Initialized
ERROR - 2016-05-23 12:40:36 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:43:04 --> Config Class Initialized
INFO - 2016-05-23 12:43:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:43:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:43:04 --> Utf8 Class Initialized
INFO - 2016-05-23 12:43:04 --> URI Class Initialized
DEBUG - 2016-05-23 12:43:04 --> No URI present. Default controller set.
INFO - 2016-05-23 12:43:04 --> Router Class Initialized
INFO - 2016-05-23 12:43:04 --> Output Class Initialized
INFO - 2016-05-23 12:43:04 --> Security Class Initialized
DEBUG - 2016-05-23 12:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:43:04 --> CSRF cookie sent
INFO - 2016-05-23 12:43:04 --> Input Class Initialized
INFO - 2016-05-23 12:43:04 --> Language Class Initialized
INFO - 2016-05-23 12:43:04 --> Loader Class Initialized
INFO - 2016-05-23 12:43:04 --> Helper loaded: form_helper
INFO - 2016-05-23 12:43:04 --> Database Driver Class Initialized
INFO - 2016-05-23 12:43:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:43:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:43:04 --> Email Class Initialized
INFO - 2016-05-23 12:43:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:43:04 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:43:04 --> Helper loaded: language_helper
INFO - 2016-05-23 12:43:04 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:43:04 --> Model Class Initialized
INFO - 2016-05-23 12:43:04 --> Helper loaded: date_helper
INFO - 2016-05-23 12:43:04 --> Controller Class Initialized
INFO - 2016-05-23 12:43:04 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:43:04 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:43:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:43:04 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:43:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:43:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:43:04 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:43:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:43:04 --> Final output sent to browser
DEBUG - 2016-05-23 12:43:04 --> Total execution time: 0.0618
INFO - 2016-05-23 12:43:05 --> Config Class Initialized
INFO - 2016-05-23 12:43:05 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:43:05 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:43:05 --> Utf8 Class Initialized
INFO - 2016-05-23 12:43:05 --> URI Class Initialized
INFO - 2016-05-23 12:43:05 --> Router Class Initialized
INFO - 2016-05-23 12:43:05 --> Output Class Initialized
INFO - 2016-05-23 12:43:05 --> Security Class Initialized
DEBUG - 2016-05-23 12:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:43:05 --> CSRF cookie sent
INFO - 2016-05-23 12:43:05 --> Input Class Initialized
INFO - 2016-05-23 12:43:05 --> Language Class Initialized
ERROR - 2016-05-23 12:43:05 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:43:11 --> Config Class Initialized
INFO - 2016-05-23 12:43:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:43:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:43:11 --> Utf8 Class Initialized
INFO - 2016-05-23 12:43:11 --> URI Class Initialized
INFO - 2016-05-23 12:43:11 --> Router Class Initialized
INFO - 2016-05-23 12:43:11 --> Output Class Initialized
INFO - 2016-05-23 12:43:11 --> Security Class Initialized
DEBUG - 2016-05-23 12:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:43:11 --> CSRF cookie sent
INFO - 2016-05-23 12:43:11 --> Input Class Initialized
INFO - 2016-05-23 12:43:11 --> Language Class Initialized
ERROR - 2016-05-23 12:43:11 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:44:08 --> Config Class Initialized
INFO - 2016-05-23 12:44:08 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:44:08 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:44:08 --> Utf8 Class Initialized
INFO - 2016-05-23 12:44:08 --> URI Class Initialized
DEBUG - 2016-05-23 12:44:08 --> No URI present. Default controller set.
INFO - 2016-05-23 12:44:08 --> Router Class Initialized
INFO - 2016-05-23 12:44:08 --> Output Class Initialized
INFO - 2016-05-23 12:44:08 --> Security Class Initialized
DEBUG - 2016-05-23 12:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:44:08 --> CSRF cookie sent
INFO - 2016-05-23 12:44:08 --> Input Class Initialized
INFO - 2016-05-23 12:44:08 --> Language Class Initialized
INFO - 2016-05-23 12:44:08 --> Loader Class Initialized
INFO - 2016-05-23 12:44:08 --> Helper loaded: form_helper
INFO - 2016-05-23 12:44:08 --> Database Driver Class Initialized
INFO - 2016-05-23 12:44:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:44:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:44:08 --> Email Class Initialized
INFO - 2016-05-23 12:44:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:44:08 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:44:08 --> Helper loaded: language_helper
INFO - 2016-05-23 12:44:08 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:44:08 --> Model Class Initialized
INFO - 2016-05-23 12:44:08 --> Helper loaded: date_helper
INFO - 2016-05-23 12:44:08 --> Controller Class Initialized
INFO - 2016-05-23 12:44:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:44:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:44:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:44:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:44:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:44:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:44:08 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:44:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:44:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:44:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:44:08 --> Final output sent to browser
DEBUG - 2016-05-23 12:44:08 --> Total execution time: 0.0985
INFO - 2016-05-23 12:44:11 --> Config Class Initialized
INFO - 2016-05-23 12:44:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:44:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:44:11 --> Utf8 Class Initialized
INFO - 2016-05-23 12:44:11 --> URI Class Initialized
INFO - 2016-05-23 12:44:11 --> Router Class Initialized
INFO - 2016-05-23 12:44:11 --> Output Class Initialized
INFO - 2016-05-23 12:44:11 --> Security Class Initialized
DEBUG - 2016-05-23 12:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:44:11 --> CSRF cookie sent
INFO - 2016-05-23 12:44:11 --> Input Class Initialized
INFO - 2016-05-23 12:44:11 --> Language Class Initialized
ERROR - 2016-05-23 12:44:11 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:44:17 --> Config Class Initialized
INFO - 2016-05-23 12:44:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:44:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:44:17 --> Utf8 Class Initialized
INFO - 2016-05-23 12:44:17 --> URI Class Initialized
INFO - 2016-05-23 12:44:17 --> Router Class Initialized
INFO - 2016-05-23 12:44:17 --> Output Class Initialized
INFO - 2016-05-23 12:44:17 --> Security Class Initialized
DEBUG - 2016-05-23 12:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:44:17 --> CSRF cookie sent
INFO - 2016-05-23 12:44:17 --> Input Class Initialized
INFO - 2016-05-23 12:44:17 --> Language Class Initialized
ERROR - 2016-05-23 12:44:17 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:47:07 --> Config Class Initialized
INFO - 2016-05-23 12:47:07 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:47:07 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:47:07 --> Utf8 Class Initialized
INFO - 2016-05-23 12:47:07 --> URI Class Initialized
DEBUG - 2016-05-23 12:47:07 --> No URI present. Default controller set.
INFO - 2016-05-23 12:47:07 --> Router Class Initialized
INFO - 2016-05-23 12:47:07 --> Output Class Initialized
INFO - 2016-05-23 12:47:07 --> Security Class Initialized
DEBUG - 2016-05-23 12:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:47:07 --> CSRF cookie sent
INFO - 2016-05-23 12:47:07 --> Input Class Initialized
INFO - 2016-05-23 12:47:07 --> Language Class Initialized
INFO - 2016-05-23 12:47:07 --> Loader Class Initialized
INFO - 2016-05-23 12:47:07 --> Helper loaded: form_helper
INFO - 2016-05-23 12:47:07 --> Database Driver Class Initialized
INFO - 2016-05-23 12:47:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:47:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:47:07 --> Email Class Initialized
INFO - 2016-05-23 12:47:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:47:07 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:47:07 --> Helper loaded: language_helper
INFO - 2016-05-23 12:47:07 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:47:07 --> Model Class Initialized
INFO - 2016-05-23 12:47:07 --> Helper loaded: date_helper
INFO - 2016-05-23 12:47:07 --> Controller Class Initialized
INFO - 2016-05-23 12:47:07 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:47:07 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:47:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:47:07 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:47:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:47:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 12:47:07 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:47:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:47:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 12:47:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:47:07 --> Final output sent to browser
DEBUG - 2016-05-23 12:47:07 --> Total execution time: 0.0719
INFO - 2016-05-23 12:47:08 --> Config Class Initialized
INFO - 2016-05-23 12:47:08 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:47:08 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:47:08 --> Utf8 Class Initialized
INFO - 2016-05-23 12:47:08 --> URI Class Initialized
INFO - 2016-05-23 12:47:08 --> Router Class Initialized
INFO - 2016-05-23 12:47:08 --> Output Class Initialized
INFO - 2016-05-23 12:47:08 --> Security Class Initialized
DEBUG - 2016-05-23 12:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:47:08 --> CSRF cookie sent
INFO - 2016-05-23 12:47:08 --> Input Class Initialized
INFO - 2016-05-23 12:47:08 --> Language Class Initialized
ERROR - 2016-05-23 12:47:08 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:47:17 --> Config Class Initialized
INFO - 2016-05-23 12:47:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:47:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:47:17 --> Utf8 Class Initialized
INFO - 2016-05-23 12:47:17 --> URI Class Initialized
INFO - 2016-05-23 12:47:17 --> Router Class Initialized
INFO - 2016-05-23 12:47:17 --> Output Class Initialized
INFO - 2016-05-23 12:47:17 --> Security Class Initialized
DEBUG - 2016-05-23 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:47:17 --> CSRF cookie sent
INFO - 2016-05-23 12:47:17 --> Input Class Initialized
INFO - 2016-05-23 12:47:17 --> Language Class Initialized
ERROR - 2016-05-23 12:47:17 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:47:19 --> Config Class Initialized
INFO - 2016-05-23 12:47:19 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:47:19 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:47:19 --> Utf8 Class Initialized
INFO - 2016-05-23 12:47:19 --> URI Class Initialized
INFO - 2016-05-23 12:47:19 --> Router Class Initialized
INFO - 2016-05-23 12:47:19 --> Output Class Initialized
INFO - 2016-05-23 12:47:19 --> Security Class Initialized
DEBUG - 2016-05-23 12:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:47:19 --> CSRF cookie sent
INFO - 2016-05-23 12:47:19 --> Input Class Initialized
INFO - 2016-05-23 12:47:19 --> Language Class Initialized
INFO - 2016-05-23 12:47:19 --> Loader Class Initialized
INFO - 2016-05-23 12:47:19 --> Helper loaded: form_helper
INFO - 2016-05-23 12:47:19 --> Database Driver Class Initialized
INFO - 2016-05-23 12:47:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:47:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:47:20 --> Email Class Initialized
INFO - 2016-05-23 12:47:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:47:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:47:20 --> Helper loaded: language_helper
INFO - 2016-05-23 12:47:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:47:20 --> Model Class Initialized
INFO - 2016-05-23 12:47:20 --> Helper loaded: date_helper
INFO - 2016-05-23 12:47:20 --> Controller Class Initialized
INFO - 2016-05-23 12:47:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:47:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:47:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:47:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:47:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:47:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 12:47:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:47:20 --> Form Validation Class Initialized
INFO - 2016-05-23 12:47:20 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 12:47:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:47:20 --> Final output sent to browser
DEBUG - 2016-05-23 12:47:20 --> Total execution time: 0.0351
INFO - 2016-05-23 12:47:23 --> Config Class Initialized
INFO - 2016-05-23 12:47:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:47:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:47:23 --> Utf8 Class Initialized
INFO - 2016-05-23 12:47:23 --> URI Class Initialized
INFO - 2016-05-23 12:47:23 --> Router Class Initialized
INFO - 2016-05-23 12:47:23 --> Output Class Initialized
INFO - 2016-05-23 12:47:23 --> Security Class Initialized
DEBUG - 2016-05-23 12:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:47:23 --> CSRF cookie sent
INFO - 2016-05-23 12:47:23 --> Input Class Initialized
INFO - 2016-05-23 12:47:23 --> Language Class Initialized
ERROR - 2016-05-23 12:47:23 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:47:29 --> Config Class Initialized
INFO - 2016-05-23 12:47:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:47:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:47:29 --> Utf8 Class Initialized
INFO - 2016-05-23 12:47:29 --> URI Class Initialized
INFO - 2016-05-23 12:47:29 --> Router Class Initialized
INFO - 2016-05-23 12:47:29 --> Output Class Initialized
INFO - 2016-05-23 12:47:29 --> Security Class Initialized
DEBUG - 2016-05-23 12:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:47:29 --> CSRF cookie sent
INFO - 2016-05-23 12:47:29 --> Input Class Initialized
INFO - 2016-05-23 12:47:29 --> Language Class Initialized
ERROR - 2016-05-23 12:47:29 --> 404 Page Not Found: Public/css
INFO - 2016-05-23 12:49:55 --> Config Class Initialized
INFO - 2016-05-23 12:49:55 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:49:55 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:49:55 --> Utf8 Class Initialized
INFO - 2016-05-23 12:49:55 --> URI Class Initialized
INFO - 2016-05-23 12:49:55 --> Router Class Initialized
INFO - 2016-05-23 12:49:55 --> Output Class Initialized
INFO - 2016-05-23 12:49:55 --> Security Class Initialized
DEBUG - 2016-05-23 12:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:49:55 --> CSRF cookie sent
INFO - 2016-05-23 12:49:55 --> Input Class Initialized
INFO - 2016-05-23 12:49:55 --> Language Class Initialized
INFO - 2016-05-23 12:49:55 --> Loader Class Initialized
INFO - 2016-05-23 12:49:55 --> Helper loaded: form_helper
INFO - 2016-05-23 12:49:55 --> Database Driver Class Initialized
INFO - 2016-05-23 12:49:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:49:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:49:55 --> Email Class Initialized
INFO - 2016-05-23 12:49:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:49:55 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:49:55 --> Helper loaded: language_helper
INFO - 2016-05-23 12:49:55 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:49:55 --> Model Class Initialized
INFO - 2016-05-23 12:49:55 --> Helper loaded: date_helper
INFO - 2016-05-23 12:49:55 --> Controller Class Initialized
INFO - 2016-05-23 12:49:55 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:49:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:49:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:49:55 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:49:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:49:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 12:49:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:49:55 --> Form Validation Class Initialized
INFO - 2016-05-23 12:49:55 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:49:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:49:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 12:49:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:49:55 --> Final output sent to browser
DEBUG - 2016-05-23 12:49:55 --> Total execution time: 0.0373
INFO - 2016-05-23 12:49:56 --> Config Class Initialized
INFO - 2016-05-23 12:49:56 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:49:56 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:49:56 --> Utf8 Class Initialized
INFO - 2016-05-23 12:49:56 --> URI Class Initialized
INFO - 2016-05-23 12:49:56 --> Router Class Initialized
INFO - 2016-05-23 12:49:56 --> Output Class Initialized
INFO - 2016-05-23 12:49:56 --> Security Class Initialized
DEBUG - 2016-05-23 12:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:49:56 --> CSRF cookie sent
INFO - 2016-05-23 12:49:56 --> Input Class Initialized
INFO - 2016-05-23 12:49:56 --> Language Class Initialized
ERROR - 2016-05-23 12:49:56 --> 404 Page Not Found: Public/js
INFO - 2016-05-23 12:50:46 --> Config Class Initialized
INFO - 2016-05-23 12:50:46 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:50:46 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:50:46 --> Utf8 Class Initialized
INFO - 2016-05-23 12:50:46 --> URI Class Initialized
INFO - 2016-05-23 12:50:46 --> Router Class Initialized
INFO - 2016-05-23 12:50:46 --> Output Class Initialized
INFO - 2016-05-23 12:50:46 --> Security Class Initialized
DEBUG - 2016-05-23 12:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:50:46 --> CSRF cookie sent
INFO - 2016-05-23 12:50:46 --> Input Class Initialized
INFO - 2016-05-23 12:50:46 --> Language Class Initialized
INFO - 2016-05-23 12:50:46 --> Loader Class Initialized
INFO - 2016-05-23 12:50:46 --> Helper loaded: form_helper
INFO - 2016-05-23 12:50:46 --> Database Driver Class Initialized
INFO - 2016-05-23 12:50:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:50:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:50:46 --> Email Class Initialized
INFO - 2016-05-23 12:50:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:50:46 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:50:46 --> Helper loaded: language_helper
INFO - 2016-05-23 12:50:46 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:50:46 --> Model Class Initialized
INFO - 2016-05-23 12:50:46 --> Helper loaded: date_helper
INFO - 2016-05-23 12:50:46 --> Controller Class Initialized
INFO - 2016-05-23 12:50:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:50:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:50:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:50:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:50:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:50:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 12:50:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:50:46 --> Form Validation Class Initialized
INFO - 2016-05-23 12:50:46 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 12:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:50:46 --> Final output sent to browser
DEBUG - 2016-05-23 12:50:46 --> Total execution time: 0.0505
INFO - 2016-05-23 12:55:09 --> Config Class Initialized
INFO - 2016-05-23 12:55:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 12:55:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 12:55:09 --> Utf8 Class Initialized
INFO - 2016-05-23 12:55:09 --> URI Class Initialized
INFO - 2016-05-23 12:55:09 --> Router Class Initialized
INFO - 2016-05-23 12:55:09 --> Output Class Initialized
INFO - 2016-05-23 12:55:09 --> Security Class Initialized
DEBUG - 2016-05-23 12:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 12:55:09 --> CSRF cookie sent
INFO - 2016-05-23 12:55:09 --> Input Class Initialized
INFO - 2016-05-23 12:55:09 --> Language Class Initialized
INFO - 2016-05-23 12:55:09 --> Loader Class Initialized
INFO - 2016-05-23 12:55:09 --> Helper loaded: form_helper
INFO - 2016-05-23 12:55:09 --> Database Driver Class Initialized
INFO - 2016-05-23 12:55:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 12:55:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 12:55:09 --> Email Class Initialized
INFO - 2016-05-23 12:55:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 12:55:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 12:55:09 --> Helper loaded: language_helper
INFO - 2016-05-23 12:55:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 12:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:55:09 --> Model Class Initialized
INFO - 2016-05-23 12:55:09 --> Helper loaded: date_helper
INFO - 2016-05-23 12:55:09 --> Controller Class Initialized
INFO - 2016-05-23 12:55:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 12:55:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 12:55:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 12:55:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 12:55:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 12:55:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 12:55:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 12:55:09 --> Form Validation Class Initialized
INFO - 2016-05-23 12:55:09 --> Helper loaded: languages_helper
INFO - 2016-05-23 12:55:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 12:55:09 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 12:55:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 12:55:09 --> Final output sent to browser
DEBUG - 2016-05-23 12:55:09 --> Total execution time: 0.0602
INFO - 2016-05-23 13:00:20 --> Config Class Initialized
INFO - 2016-05-23 13:00:20 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:00:20 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:00:20 --> Utf8 Class Initialized
INFO - 2016-05-23 13:00:20 --> URI Class Initialized
INFO - 2016-05-23 13:00:20 --> Router Class Initialized
INFO - 2016-05-23 13:00:20 --> Output Class Initialized
INFO - 2016-05-23 13:00:20 --> Security Class Initialized
DEBUG - 2016-05-23 13:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:00:20 --> CSRF cookie sent
INFO - 2016-05-23 13:00:20 --> CSRF token verified
INFO - 2016-05-23 13:00:20 --> Input Class Initialized
INFO - 2016-05-23 13:00:20 --> Language Class Initialized
INFO - 2016-05-23 13:00:20 --> Loader Class Initialized
INFO - 2016-05-23 13:00:20 --> Helper loaded: form_helper
INFO - 2016-05-23 13:00:20 --> Database Driver Class Initialized
INFO - 2016-05-23 13:00:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:00:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:00:20 --> Email Class Initialized
INFO - 2016-05-23 13:00:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:00:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:00:20 --> Helper loaded: language_helper
INFO - 2016-05-23 13:00:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:00:20 --> Model Class Initialized
INFO - 2016-05-23 13:00:20 --> Helper loaded: date_helper
INFO - 2016-05-23 13:00:20 --> Controller Class Initialized
INFO - 2016-05-23 13:00:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:00:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:00:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:00:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:00:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:00:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:00:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:00:20 --> Form Validation Class Initialized
INFO - 2016-05-23 13:00:22 --> Config Class Initialized
INFO - 2016-05-23 13:00:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:00:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:00:22 --> Utf8 Class Initialized
INFO - 2016-05-23 13:00:22 --> URI Class Initialized
DEBUG - 2016-05-23 13:00:22 --> No URI present. Default controller set.
INFO - 2016-05-23 13:00:22 --> Router Class Initialized
INFO - 2016-05-23 13:00:22 --> Output Class Initialized
INFO - 2016-05-23 13:00:22 --> Security Class Initialized
DEBUG - 2016-05-23 13:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:00:22 --> CSRF cookie sent
INFO - 2016-05-23 13:00:22 --> Input Class Initialized
INFO - 2016-05-23 13:00:22 --> Language Class Initialized
INFO - 2016-05-23 13:00:22 --> Loader Class Initialized
INFO - 2016-05-23 13:00:22 --> Helper loaded: form_helper
INFO - 2016-05-23 13:00:22 --> Database Driver Class Initialized
INFO - 2016-05-23 13:00:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:00:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:00:22 --> Email Class Initialized
INFO - 2016-05-23 13:00:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:00:22 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:00:22 --> Helper loaded: language_helper
INFO - 2016-05-23 13:00:22 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:00:22 --> Model Class Initialized
INFO - 2016-05-23 13:00:22 --> Helper loaded: date_helper
INFO - 2016-05-23 13:00:22 --> Controller Class Initialized
INFO - 2016-05-23 13:00:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:00:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:00:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:00:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:00:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:00:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:00:23 --> Config Class Initialized
INFO - 2016-05-23 13:00:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:00:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:00:23 --> Utf8 Class Initialized
INFO - 2016-05-23 13:00:23 --> URI Class Initialized
INFO - 2016-05-23 13:00:23 --> Router Class Initialized
INFO - 2016-05-23 13:00:23 --> Output Class Initialized
INFO - 2016-05-23 13:00:23 --> Security Class Initialized
DEBUG - 2016-05-23 13:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:00:23 --> CSRF cookie sent
INFO - 2016-05-23 13:00:23 --> Input Class Initialized
INFO - 2016-05-23 13:00:23 --> Language Class Initialized
INFO - 2016-05-23 13:00:23 --> Loader Class Initialized
INFO - 2016-05-23 13:00:23 --> Helper loaded: form_helper
INFO - 2016-05-23 13:00:23 --> Database Driver Class Initialized
INFO - 2016-05-23 13:00:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:00:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:00:23 --> Email Class Initialized
INFO - 2016-05-23 13:00:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:00:23 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:00:23 --> Helper loaded: language_helper
INFO - 2016-05-23 13:00:23 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:00:23 --> Model Class Initialized
INFO - 2016-05-23 13:00:23 --> Helper loaded: date_helper
INFO - 2016-05-23 13:00:23 --> Controller Class Initialized
INFO - 2016-05-23 13:00:23 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:00:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:00:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:00:23 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:00:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:00:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:00:23 --> Model Class Initialized
INFO - 2016-05-23 13:00:23 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:00:23 --> Final output sent to browser
DEBUG - 2016-05-23 13:00:23 --> Total execution time: 0.0466
INFO - 2016-05-23 13:01:07 --> Config Class Initialized
INFO - 2016-05-23 13:01:07 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:01:07 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:01:07 --> Utf8 Class Initialized
INFO - 2016-05-23 13:01:07 --> URI Class Initialized
INFO - 2016-05-23 13:01:07 --> Router Class Initialized
INFO - 2016-05-23 13:01:07 --> Output Class Initialized
INFO - 2016-05-23 13:01:07 --> Security Class Initialized
DEBUG - 2016-05-23 13:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:01:07 --> CSRF cookie sent
INFO - 2016-05-23 13:01:07 --> Input Class Initialized
INFO - 2016-05-23 13:01:07 --> Language Class Initialized
INFO - 2016-05-23 13:01:07 --> Loader Class Initialized
INFO - 2016-05-23 13:01:07 --> Helper loaded: form_helper
INFO - 2016-05-23 13:01:07 --> Database Driver Class Initialized
INFO - 2016-05-23 13:01:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:01:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:01:07 --> Email Class Initialized
INFO - 2016-05-23 13:01:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:01:07 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:01:07 --> Helper loaded: language_helper
INFO - 2016-05-23 13:01:07 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:01:07 --> Model Class Initialized
INFO - 2016-05-23 13:01:07 --> Helper loaded: date_helper
INFO - 2016-05-23 13:01:07 --> Controller Class Initialized
INFO - 2016-05-23 13:01:07 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:01:07 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:01:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:01:07 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:01:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:01:07 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:01:07 --> Model Class Initialized
INFO - 2016-05-23 13:01:07 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:01:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:01:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:01:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:01:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:01:07 --> Final output sent to browser
DEBUG - 2016-05-23 13:01:07 --> Total execution time: 0.0623
INFO - 2016-05-23 13:02:40 --> Config Class Initialized
INFO - 2016-05-23 13:02:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:02:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:02:40 --> Utf8 Class Initialized
INFO - 2016-05-23 13:02:40 --> URI Class Initialized
INFO - 2016-05-23 13:02:40 --> Router Class Initialized
INFO - 2016-05-23 13:02:40 --> Output Class Initialized
INFO - 2016-05-23 13:02:40 --> Security Class Initialized
DEBUG - 2016-05-23 13:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:02:40 --> CSRF cookie sent
INFO - 2016-05-23 13:02:40 --> Input Class Initialized
INFO - 2016-05-23 13:02:40 --> Language Class Initialized
INFO - 2016-05-23 13:02:40 --> Loader Class Initialized
INFO - 2016-05-23 13:02:40 --> Helper loaded: form_helper
INFO - 2016-05-23 13:02:40 --> Database Driver Class Initialized
INFO - 2016-05-23 13:02:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:02:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:02:40 --> Email Class Initialized
INFO - 2016-05-23 13:02:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:02:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:02:40 --> Helper loaded: language_helper
INFO - 2016-05-23 13:02:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:02:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:02:40 --> Model Class Initialized
INFO - 2016-05-23 13:02:40 --> Helper loaded: date_helper
INFO - 2016-05-23 13:02:40 --> Controller Class Initialized
INFO - 2016-05-23 13:02:40 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:02:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:02:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:02:40 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:02:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:02:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:02:40 --> Model Class Initialized
INFO - 2016-05-23 13:02:40 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:02:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:02:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:02:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:02:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:02:40 --> Final output sent to browser
DEBUG - 2016-05-23 13:02:40 --> Total execution time: 0.0471
INFO - 2016-05-23 13:06:05 --> Config Class Initialized
INFO - 2016-05-23 13:06:05 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:06:05 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:06:05 --> Utf8 Class Initialized
INFO - 2016-05-23 13:06:05 --> URI Class Initialized
INFO - 2016-05-23 13:06:05 --> Router Class Initialized
INFO - 2016-05-23 13:06:05 --> Output Class Initialized
INFO - 2016-05-23 13:06:05 --> Security Class Initialized
DEBUG - 2016-05-23 13:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:06:05 --> CSRF cookie sent
INFO - 2016-05-23 13:06:05 --> Input Class Initialized
INFO - 2016-05-23 13:06:05 --> Language Class Initialized
ERROR - 2016-05-23 13:06:05 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) /home/demis/www/platformadiabet/application/core/SVS_Controller.php 97
INFO - 2016-05-23 13:06:33 --> Config Class Initialized
INFO - 2016-05-23 13:06:33 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:06:33 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:06:33 --> Utf8 Class Initialized
INFO - 2016-05-23 13:06:33 --> URI Class Initialized
INFO - 2016-05-23 13:06:33 --> Router Class Initialized
INFO - 2016-05-23 13:06:33 --> Output Class Initialized
INFO - 2016-05-23 13:06:33 --> Security Class Initialized
DEBUG - 2016-05-23 13:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:06:33 --> CSRF cookie sent
INFO - 2016-05-23 13:06:33 --> Input Class Initialized
INFO - 2016-05-23 13:06:33 --> Language Class Initialized
INFO - 2016-05-23 13:06:33 --> Loader Class Initialized
INFO - 2016-05-23 13:06:33 --> Helper loaded: form_helper
INFO - 2016-05-23 13:06:33 --> Database Driver Class Initialized
INFO - 2016-05-23 13:06:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:06:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:06:33 --> Email Class Initialized
INFO - 2016-05-23 13:06:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:06:33 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:06:33 --> Helper loaded: language_helper
INFO - 2016-05-23 13:06:33 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:06:33 --> Model Class Initialized
INFO - 2016-05-23 13:06:33 --> Helper loaded: date_helper
INFO - 2016-05-23 13:06:33 --> Controller Class Initialized
INFO - 2016-05-23 13:06:52 --> Config Class Initialized
INFO - 2016-05-23 13:06:52 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:06:52 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:06:52 --> Utf8 Class Initialized
INFO - 2016-05-23 13:06:52 --> URI Class Initialized
INFO - 2016-05-23 13:06:52 --> Router Class Initialized
INFO - 2016-05-23 13:06:52 --> Output Class Initialized
INFO - 2016-05-23 13:06:52 --> Security Class Initialized
DEBUG - 2016-05-23 13:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:06:52 --> CSRF cookie sent
INFO - 2016-05-23 13:06:52 --> Input Class Initialized
INFO - 2016-05-23 13:06:52 --> Language Class Initialized
INFO - 2016-05-23 13:06:52 --> Loader Class Initialized
INFO - 2016-05-23 13:06:52 --> Helper loaded: form_helper
INFO - 2016-05-23 13:06:52 --> Database Driver Class Initialized
INFO - 2016-05-23 13:06:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:06:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:06:52 --> Email Class Initialized
INFO - 2016-05-23 13:06:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:06:52 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:06:52 --> Helper loaded: language_helper
INFO - 2016-05-23 13:06:52 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:06:52 --> Model Class Initialized
INFO - 2016-05-23 13:06:52 --> Helper loaded: date_helper
INFO - 2016-05-23 13:06:52 --> Controller Class Initialized
INFO - 2016-05-23 13:06:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:06:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:06:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:06:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:06:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:06:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:06:52 --> Model Class Initialized
INFO - 2016-05-23 13:06:52 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:06:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:06:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:06:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:06:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:06:52 --> Final output sent to browser
DEBUG - 2016-05-23 13:06:52 --> Total execution time: 0.0538
INFO - 2016-05-23 13:11:14 --> Config Class Initialized
INFO - 2016-05-23 13:11:14 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:11:14 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:11:14 --> Utf8 Class Initialized
INFO - 2016-05-23 13:11:14 --> URI Class Initialized
INFO - 2016-05-23 13:11:14 --> Router Class Initialized
INFO - 2016-05-23 13:11:14 --> Output Class Initialized
INFO - 2016-05-23 13:11:14 --> Security Class Initialized
DEBUG - 2016-05-23 13:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:11:14 --> CSRF cookie sent
INFO - 2016-05-23 13:11:14 --> Input Class Initialized
INFO - 2016-05-23 13:11:14 --> Language Class Initialized
INFO - 2016-05-23 13:11:14 --> Loader Class Initialized
INFO - 2016-05-23 13:11:14 --> Helper loaded: form_helper
INFO - 2016-05-23 13:11:14 --> Database Driver Class Initialized
INFO - 2016-05-23 13:11:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:11:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:11:14 --> Email Class Initialized
INFO - 2016-05-23 13:11:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:11:14 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:11:14 --> Helper loaded: language_helper
INFO - 2016-05-23 13:11:14 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:11:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:14 --> Model Class Initialized
INFO - 2016-05-23 13:11:14 --> Helper loaded: date_helper
INFO - 2016-05-23 13:11:14 --> Controller Class Initialized
INFO - 2016-05-23 13:11:14 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:11:14 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:11:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:11:14 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:11:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:11:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:11:14 --> Model Class Initialized
INFO - 2016-05-23 13:11:14 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:11:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:11:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:11:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:11:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:11:14 --> Final output sent to browser
DEBUG - 2016-05-23 13:11:14 --> Total execution time: 0.0561
INFO - 2016-05-23 13:11:24 --> Config Class Initialized
INFO - 2016-05-23 13:11:24 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:11:24 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:11:24 --> Utf8 Class Initialized
INFO - 2016-05-23 13:11:24 --> URI Class Initialized
INFO - 2016-05-23 13:11:24 --> Router Class Initialized
INFO - 2016-05-23 13:11:24 --> Output Class Initialized
INFO - 2016-05-23 13:11:24 --> Security Class Initialized
DEBUG - 2016-05-23 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:11:24 --> CSRF cookie sent
INFO - 2016-05-23 13:11:24 --> Input Class Initialized
INFO - 2016-05-23 13:11:24 --> Language Class Initialized
INFO - 2016-05-23 13:11:24 --> Loader Class Initialized
INFO - 2016-05-23 13:11:24 --> Helper loaded: form_helper
INFO - 2016-05-23 13:11:24 --> Database Driver Class Initialized
INFO - 2016-05-23 13:11:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:11:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:11:24 --> Email Class Initialized
INFO - 2016-05-23 13:11:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:11:24 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:11:24 --> Helper loaded: language_helper
INFO - 2016-05-23 13:11:24 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:24 --> Model Class Initialized
INFO - 2016-05-23 13:11:24 --> Helper loaded: date_helper
INFO - 2016-05-23 13:11:24 --> Controller Class Initialized
INFO - 2016-05-23 13:11:24 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:11:24 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:11:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:11:24 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:11:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:11:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:11:24 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:24 --> Form Validation Class Initialized
INFO - 2016-05-23 13:11:28 --> Config Class Initialized
INFO - 2016-05-23 13:11:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:11:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:11:28 --> Utf8 Class Initialized
INFO - 2016-05-23 13:11:28 --> URI Class Initialized
INFO - 2016-05-23 13:11:28 --> Router Class Initialized
INFO - 2016-05-23 13:11:28 --> Output Class Initialized
INFO - 2016-05-23 13:11:28 --> Security Class Initialized
DEBUG - 2016-05-23 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:11:28 --> CSRF cookie sent
INFO - 2016-05-23 13:11:28 --> Input Class Initialized
INFO - 2016-05-23 13:11:28 --> Language Class Initialized
INFO - 2016-05-23 13:11:28 --> Loader Class Initialized
INFO - 2016-05-23 13:11:28 --> Helper loaded: form_helper
INFO - 2016-05-23 13:11:28 --> Database Driver Class Initialized
INFO - 2016-05-23 13:11:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:11:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:11:28 --> Email Class Initialized
INFO - 2016-05-23 13:11:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:11:28 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:11:28 --> Helper loaded: language_helper
INFO - 2016-05-23 13:11:28 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:28 --> Model Class Initialized
INFO - 2016-05-23 13:11:28 --> Helper loaded: date_helper
INFO - 2016-05-23 13:11:28 --> Controller Class Initialized
INFO - 2016-05-23 13:11:28 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:11:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:11:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:11:28 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:11:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:11:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:11:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:28 --> Form Validation Class Initialized
INFO - 2016-05-23 13:11:28 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:11:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:11:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 13:11:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:11:28 --> Final output sent to browser
DEBUG - 2016-05-23 13:11:28 --> Total execution time: 0.0581
INFO - 2016-05-23 13:11:40 --> Config Class Initialized
INFO - 2016-05-23 13:11:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:11:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:11:40 --> Utf8 Class Initialized
INFO - 2016-05-23 13:11:40 --> URI Class Initialized
DEBUG - 2016-05-23 13:11:40 --> No URI present. Default controller set.
INFO - 2016-05-23 13:11:40 --> Router Class Initialized
INFO - 2016-05-23 13:11:40 --> Output Class Initialized
INFO - 2016-05-23 13:11:40 --> Security Class Initialized
DEBUG - 2016-05-23 13:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:11:40 --> CSRF cookie sent
INFO - 2016-05-23 13:11:40 --> Input Class Initialized
INFO - 2016-05-23 13:11:40 --> Language Class Initialized
INFO - 2016-05-23 13:11:40 --> Loader Class Initialized
INFO - 2016-05-23 13:11:40 --> Helper loaded: form_helper
INFO - 2016-05-23 13:11:40 --> Database Driver Class Initialized
INFO - 2016-05-23 13:11:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:11:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:11:40 --> Email Class Initialized
INFO - 2016-05-23 13:11:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:11:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:11:40 --> Helper loaded: language_helper
INFO - 2016-05-23 13:11:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:40 --> Model Class Initialized
INFO - 2016-05-23 13:11:40 --> Helper loaded: date_helper
INFO - 2016-05-23 13:11:40 --> Controller Class Initialized
INFO - 2016-05-23 13:11:40 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:11:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:11:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:11:40 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:11:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:11:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:11:40 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:11:40 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:11:40 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 13:11:40 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:11:40 --> Final output sent to browser
DEBUG - 2016-05-23 13:11:40 --> Total execution time: 0.0795
INFO - 2016-05-23 13:11:57 --> Config Class Initialized
INFO - 2016-05-23 13:11:57 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:11:57 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:11:57 --> Utf8 Class Initialized
INFO - 2016-05-23 13:11:57 --> URI Class Initialized
INFO - 2016-05-23 13:11:57 --> Router Class Initialized
INFO - 2016-05-23 13:11:57 --> Output Class Initialized
INFO - 2016-05-23 13:11:57 --> Security Class Initialized
DEBUG - 2016-05-23 13:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:11:57 --> CSRF cookie sent
INFO - 2016-05-23 13:11:57 --> Input Class Initialized
INFO - 2016-05-23 13:11:57 --> Language Class Initialized
INFO - 2016-05-23 13:11:57 --> Loader Class Initialized
INFO - 2016-05-23 13:11:57 --> Helper loaded: form_helper
INFO - 2016-05-23 13:11:57 --> Database Driver Class Initialized
INFO - 2016-05-23 13:11:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:11:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:11:57 --> Email Class Initialized
INFO - 2016-05-23 13:11:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:11:57 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:11:57 --> Helper loaded: language_helper
INFO - 2016-05-23 13:11:57 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:11:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:57 --> Model Class Initialized
INFO - 2016-05-23 13:11:57 --> Helper loaded: date_helper
INFO - 2016-05-23 13:11:57 --> Controller Class Initialized
INFO - 2016-05-23 13:11:57 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:11:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:11:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:11:57 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:11:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:11:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:11:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:11:57 --> Form Validation Class Initialized
INFO - 2016-05-23 13:11:57 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:11:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:11:57 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 13:11:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:11:57 --> Final output sent to browser
DEBUG - 2016-05-23 13:11:57 --> Total execution time: 0.0659
INFO - 2016-05-23 13:12:06 --> Config Class Initialized
INFO - 2016-05-23 13:12:06 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:12:06 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:12:06 --> Utf8 Class Initialized
INFO - 2016-05-23 13:12:06 --> URI Class Initialized
INFO - 2016-05-23 13:12:06 --> Router Class Initialized
INFO - 2016-05-23 13:12:06 --> Output Class Initialized
INFO - 2016-05-23 13:12:06 --> Security Class Initialized
DEBUG - 2016-05-23 13:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:12:06 --> CSRF cookie sent
INFO - 2016-05-23 13:12:06 --> CSRF token verified
INFO - 2016-05-23 13:12:06 --> Input Class Initialized
INFO - 2016-05-23 13:12:06 --> Language Class Initialized
INFO - 2016-05-23 13:12:06 --> Loader Class Initialized
INFO - 2016-05-23 13:12:06 --> Helper loaded: form_helper
INFO - 2016-05-23 13:12:06 --> Database Driver Class Initialized
INFO - 2016-05-23 13:12:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:12:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:12:06 --> Email Class Initialized
INFO - 2016-05-23 13:12:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:12:06 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:12:06 --> Helper loaded: language_helper
INFO - 2016-05-23 13:12:06 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:12:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:12:06 --> Model Class Initialized
INFO - 2016-05-23 13:12:06 --> Helper loaded: date_helper
INFO - 2016-05-23 13:12:06 --> Controller Class Initialized
INFO - 2016-05-23 13:12:06 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:12:06 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:12:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:12:06 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:12:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:12:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:12:06 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:12:06 --> Form Validation Class Initialized
INFO - 2016-05-23 13:12:08 --> Config Class Initialized
INFO - 2016-05-23 13:12:08 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:12:08 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:12:08 --> Utf8 Class Initialized
INFO - 2016-05-23 13:12:08 --> URI Class Initialized
DEBUG - 2016-05-23 13:12:08 --> No URI present. Default controller set.
INFO - 2016-05-23 13:12:08 --> Router Class Initialized
INFO - 2016-05-23 13:12:08 --> Output Class Initialized
INFO - 2016-05-23 13:12:08 --> Security Class Initialized
DEBUG - 2016-05-23 13:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:12:08 --> CSRF cookie sent
INFO - 2016-05-23 13:12:08 --> Input Class Initialized
INFO - 2016-05-23 13:12:08 --> Language Class Initialized
INFO - 2016-05-23 13:12:08 --> Loader Class Initialized
INFO - 2016-05-23 13:12:08 --> Helper loaded: form_helper
INFO - 2016-05-23 13:12:08 --> Database Driver Class Initialized
INFO - 2016-05-23 13:12:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:12:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:12:08 --> Email Class Initialized
INFO - 2016-05-23 13:12:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:12:08 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:12:08 --> Helper loaded: language_helper
INFO - 2016-05-23 13:12:08 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:12:08 --> Model Class Initialized
INFO - 2016-05-23 13:12:08 --> Helper loaded: date_helper
INFO - 2016-05-23 13:12:08 --> Controller Class Initialized
INFO - 2016-05-23 13:12:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:12:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:12:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:12:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:12:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:12:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:12:09 --> Config Class Initialized
INFO - 2016-05-23 13:12:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:12:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:12:09 --> Utf8 Class Initialized
INFO - 2016-05-23 13:12:09 --> URI Class Initialized
INFO - 2016-05-23 13:12:09 --> Router Class Initialized
INFO - 2016-05-23 13:12:09 --> Output Class Initialized
INFO - 2016-05-23 13:12:09 --> Security Class Initialized
DEBUG - 2016-05-23 13:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:12:09 --> CSRF cookie sent
INFO - 2016-05-23 13:12:09 --> Input Class Initialized
INFO - 2016-05-23 13:12:09 --> Language Class Initialized
INFO - 2016-05-23 13:12:09 --> Loader Class Initialized
INFO - 2016-05-23 13:12:09 --> Helper loaded: form_helper
INFO - 2016-05-23 13:12:09 --> Database Driver Class Initialized
INFO - 2016-05-23 13:12:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:12:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:12:09 --> Email Class Initialized
INFO - 2016-05-23 13:12:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:12:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:12:09 --> Helper loaded: language_helper
INFO - 2016-05-23 13:12:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:12:09 --> Model Class Initialized
INFO - 2016-05-23 13:12:09 --> Helper loaded: date_helper
INFO - 2016-05-23 13:12:09 --> Controller Class Initialized
INFO - 2016-05-23 13:12:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:12:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:12:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:12:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:12:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:12:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:12:09 --> Model Class Initialized
INFO - 2016-05-23 13:12:09 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:12:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:12:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:12:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:12:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:12:09 --> Final output sent to browser
DEBUG - 2016-05-23 13:12:09 --> Total execution time: 0.0733
INFO - 2016-05-23 13:15:17 --> Config Class Initialized
INFO - 2016-05-23 13:15:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:15:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:15:17 --> Utf8 Class Initialized
INFO - 2016-05-23 13:15:17 --> URI Class Initialized
INFO - 2016-05-23 13:15:17 --> Router Class Initialized
INFO - 2016-05-23 13:15:17 --> Output Class Initialized
INFO - 2016-05-23 13:15:17 --> Security Class Initialized
DEBUG - 2016-05-23 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:15:17 --> CSRF cookie sent
INFO - 2016-05-23 13:15:17 --> Input Class Initialized
INFO - 2016-05-23 13:15:17 --> Language Class Initialized
INFO - 2016-05-23 13:15:17 --> Loader Class Initialized
INFO - 2016-05-23 13:15:17 --> Helper loaded: form_helper
INFO - 2016-05-23 13:15:17 --> Database Driver Class Initialized
INFO - 2016-05-23 13:15:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:15:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:15:17 --> Email Class Initialized
INFO - 2016-05-23 13:15:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:15:17 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:15:17 --> Helper loaded: language_helper
INFO - 2016-05-23 13:15:17 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:15:17 --> Model Class Initialized
INFO - 2016-05-23 13:15:17 --> Helper loaded: date_helper
INFO - 2016-05-23 13:15:17 --> Controller Class Initialized
DEBUG - 2016-05-23 13:15:17 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:15:17 --> Form Validation Class Initialized
INFO - 2016-05-23 13:15:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 13:15:17 --> Config Class Initialized
INFO - 2016-05-23 13:15:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:15:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:15:17 --> Utf8 Class Initialized
INFO - 2016-05-23 13:15:17 --> URI Class Initialized
INFO - 2016-05-23 13:15:17 --> Router Class Initialized
INFO - 2016-05-23 13:15:17 --> Output Class Initialized
INFO - 2016-05-23 13:15:17 --> Security Class Initialized
DEBUG - 2016-05-23 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:15:17 --> CSRF cookie sent
INFO - 2016-05-23 13:15:17 --> Input Class Initialized
INFO - 2016-05-23 13:15:17 --> Language Class Initialized
INFO - 2016-05-23 13:15:17 --> Loader Class Initialized
INFO - 2016-05-23 13:15:17 --> Helper loaded: form_helper
INFO - 2016-05-23 13:15:17 --> Database Driver Class Initialized
INFO - 2016-05-23 13:15:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:15:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:15:17 --> Email Class Initialized
INFO - 2016-05-23 13:15:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:15:17 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:15:17 --> Helper loaded: language_helper
INFO - 2016-05-23 13:15:17 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:15:17 --> Model Class Initialized
INFO - 2016-05-23 13:15:17 --> Helper loaded: date_helper
INFO - 2016-05-23 13:15:17 --> Controller Class Initialized
DEBUG - 2016-05-23 13:15:17 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:15:17 --> Form Validation Class Initialized
INFO - 2016-05-23 13:15:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 13:21:36 --> Config Class Initialized
INFO - 2016-05-23 13:21:36 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:21:36 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:21:36 --> Utf8 Class Initialized
INFO - 2016-05-23 13:21:36 --> URI Class Initialized
INFO - 2016-05-23 13:21:36 --> Router Class Initialized
INFO - 2016-05-23 13:21:36 --> Output Class Initialized
INFO - 2016-05-23 13:21:36 --> Security Class Initialized
DEBUG - 2016-05-23 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:21:36 --> CSRF cookie sent
INFO - 2016-05-23 13:21:36 --> Input Class Initialized
INFO - 2016-05-23 13:21:36 --> Language Class Initialized
INFO - 2016-05-23 13:21:36 --> Loader Class Initialized
INFO - 2016-05-23 13:21:36 --> Helper loaded: form_helper
INFO - 2016-05-23 13:21:36 --> Database Driver Class Initialized
INFO - 2016-05-23 13:21:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:21:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:21:36 --> Email Class Initialized
INFO - 2016-05-23 13:21:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:21:36 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:21:36 --> Helper loaded: language_helper
INFO - 2016-05-23 13:21:36 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:21:36 --> Model Class Initialized
INFO - 2016-05-23 13:21:36 --> Helper loaded: date_helper
INFO - 2016-05-23 13:21:36 --> Controller Class Initialized
INFO - 2016-05-23 13:21:36 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:21:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:21:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:21:36 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:21:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:21:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:21:36 --> Model Class Initialized
INFO - 2016-05-23 13:21:36 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:21:36 --> Final output sent to browser
DEBUG - 2016-05-23 13:21:36 --> Total execution time: 0.0482
INFO - 2016-05-23 13:21:45 --> Config Class Initialized
INFO - 2016-05-23 13:21:45 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:21:45 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:21:45 --> Utf8 Class Initialized
INFO - 2016-05-23 13:21:45 --> URI Class Initialized
INFO - 2016-05-23 13:21:45 --> Router Class Initialized
INFO - 2016-05-23 13:21:45 --> Output Class Initialized
INFO - 2016-05-23 13:21:45 --> Security Class Initialized
DEBUG - 2016-05-23 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:21:45 --> CSRF cookie sent
INFO - 2016-05-23 13:21:45 --> Input Class Initialized
INFO - 2016-05-23 13:21:45 --> Language Class Initialized
INFO - 2016-05-23 13:21:45 --> Loader Class Initialized
INFO - 2016-05-23 13:21:45 --> Helper loaded: form_helper
INFO - 2016-05-23 13:21:45 --> Database Driver Class Initialized
INFO - 2016-05-23 13:21:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:21:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:21:45 --> Email Class Initialized
INFO - 2016-05-23 13:21:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:21:45 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:21:45 --> Helper loaded: language_helper
INFO - 2016-05-23 13:21:45 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:21:45 --> Model Class Initialized
INFO - 2016-05-23 13:21:45 --> Helper loaded: date_helper
INFO - 2016-05-23 13:21:45 --> Controller Class Initialized
INFO - 2016-05-23 13:21:45 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:21:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:21:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:21:45 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:21:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:21:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:21:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:21:45 --> Form Validation Class Initialized
INFO - 2016-05-23 13:21:47 --> Config Class Initialized
INFO - 2016-05-23 13:21:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:21:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:21:47 --> Utf8 Class Initialized
INFO - 2016-05-23 13:21:47 --> URI Class Initialized
INFO - 2016-05-23 13:21:47 --> Router Class Initialized
INFO - 2016-05-23 13:21:47 --> Output Class Initialized
INFO - 2016-05-23 13:21:47 --> Security Class Initialized
DEBUG - 2016-05-23 13:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:21:47 --> CSRF cookie sent
INFO - 2016-05-23 13:21:47 --> Input Class Initialized
INFO - 2016-05-23 13:21:47 --> Language Class Initialized
INFO - 2016-05-23 13:21:47 --> Loader Class Initialized
INFO - 2016-05-23 13:21:47 --> Helper loaded: form_helper
INFO - 2016-05-23 13:21:47 --> Database Driver Class Initialized
INFO - 2016-05-23 13:21:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:21:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:21:47 --> Email Class Initialized
INFO - 2016-05-23 13:21:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:21:47 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:21:47 --> Helper loaded: language_helper
INFO - 2016-05-23 13:21:47 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:21:47 --> Model Class Initialized
INFO - 2016-05-23 13:21:47 --> Helper loaded: date_helper
INFO - 2016-05-23 13:21:47 --> Controller Class Initialized
INFO - 2016-05-23 13:21:47 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:21:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:21:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:21:47 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:21:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:21:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:21:47 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:21:47 --> Form Validation Class Initialized
INFO - 2016-05-23 13:21:47 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:21:47 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:21:47 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 13:21:47 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:21:47 --> Final output sent to browser
DEBUG - 2016-05-23 13:21:47 --> Total execution time: 0.0507
INFO - 2016-05-23 13:22:17 --> Config Class Initialized
INFO - 2016-05-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:22:17 --> Utf8 Class Initialized
INFO - 2016-05-23 13:22:17 --> URI Class Initialized
INFO - 2016-05-23 13:22:17 --> Router Class Initialized
INFO - 2016-05-23 13:22:17 --> Output Class Initialized
INFO - 2016-05-23 13:22:17 --> Security Class Initialized
DEBUG - 2016-05-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:22:17 --> CSRF cookie sent
INFO - 2016-05-23 13:22:17 --> CSRF token verified
INFO - 2016-05-23 13:22:17 --> Input Class Initialized
INFO - 2016-05-23 13:22:17 --> Language Class Initialized
INFO - 2016-05-23 13:22:17 --> Loader Class Initialized
INFO - 2016-05-23 13:22:17 --> Helper loaded: form_helper
INFO - 2016-05-23 13:22:17 --> Database Driver Class Initialized
INFO - 2016-05-23 13:22:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:22:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:22:17 --> Email Class Initialized
INFO - 2016-05-23 13:22:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:22:17 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:22:17 --> Helper loaded: language_helper
INFO - 2016-05-23 13:22:17 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:17 --> Model Class Initialized
INFO - 2016-05-23 13:22:17 --> Helper loaded: date_helper
INFO - 2016-05-23 13:22:17 --> Controller Class Initialized
INFO - 2016-05-23 13:22:17 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:22:17 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:22:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:22:17 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:22:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:22:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:22:17 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:17 --> Form Validation Class Initialized
INFO - 2016-05-23 13:22:21 --> Config Class Initialized
INFO - 2016-05-23 13:22:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:22:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:22:21 --> Utf8 Class Initialized
INFO - 2016-05-23 13:22:21 --> URI Class Initialized
DEBUG - 2016-05-23 13:22:21 --> No URI present. Default controller set.
INFO - 2016-05-23 13:22:21 --> Router Class Initialized
INFO - 2016-05-23 13:22:21 --> Output Class Initialized
INFO - 2016-05-23 13:22:21 --> Security Class Initialized
DEBUG - 2016-05-23 13:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:22:21 --> CSRF cookie sent
INFO - 2016-05-23 13:22:21 --> Input Class Initialized
INFO - 2016-05-23 13:22:21 --> Language Class Initialized
INFO - 2016-05-23 13:22:21 --> Loader Class Initialized
INFO - 2016-05-23 13:22:21 --> Helper loaded: form_helper
INFO - 2016-05-23 13:22:21 --> Database Driver Class Initialized
INFO - 2016-05-23 13:22:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:22:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:22:21 --> Email Class Initialized
INFO - 2016-05-23 13:22:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:22:21 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:22:21 --> Helper loaded: language_helper
INFO - 2016-05-23 13:22:21 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:21 --> Model Class Initialized
INFO - 2016-05-23 13:22:21 --> Helper loaded: date_helper
INFO - 2016-05-23 13:22:21 --> Controller Class Initialized
INFO - 2016-05-23 13:22:21 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:22:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:22:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:22:21 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:22:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:22:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:22:22 --> Config Class Initialized
INFO - 2016-05-23 13:22:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:22:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:22:22 --> Utf8 Class Initialized
INFO - 2016-05-23 13:22:22 --> URI Class Initialized
INFO - 2016-05-23 13:22:22 --> Router Class Initialized
INFO - 2016-05-23 13:22:22 --> Output Class Initialized
INFO - 2016-05-23 13:22:22 --> Security Class Initialized
DEBUG - 2016-05-23 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:22:22 --> CSRF cookie sent
INFO - 2016-05-23 13:22:22 --> Input Class Initialized
INFO - 2016-05-23 13:22:22 --> Language Class Initialized
INFO - 2016-05-23 13:22:22 --> Loader Class Initialized
INFO - 2016-05-23 13:22:22 --> Helper loaded: form_helper
INFO - 2016-05-23 13:22:22 --> Database Driver Class Initialized
INFO - 2016-05-23 13:22:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:22:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:22:22 --> Email Class Initialized
INFO - 2016-05-23 13:22:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:22:22 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:22:22 --> Helper loaded: language_helper
INFO - 2016-05-23 13:22:22 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:22 --> Model Class Initialized
INFO - 2016-05-23 13:22:22 --> Helper loaded: date_helper
INFO - 2016-05-23 13:22:22 --> Controller Class Initialized
INFO - 2016-05-23 13:22:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:22:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:22:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:22:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:22:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:22:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:22:22 --> Model Class Initialized
INFO - 2016-05-23 13:22:22 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:22:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:22:22 --> Final output sent to browser
DEBUG - 2016-05-23 13:22:22 --> Total execution time: 0.0436
INFO - 2016-05-23 13:22:28 --> Config Class Initialized
INFO - 2016-05-23 13:22:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:22:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:22:28 --> Utf8 Class Initialized
INFO - 2016-05-23 13:22:28 --> URI Class Initialized
INFO - 2016-05-23 13:22:28 --> Router Class Initialized
INFO - 2016-05-23 13:22:28 --> Output Class Initialized
INFO - 2016-05-23 13:22:28 --> Security Class Initialized
DEBUG - 2016-05-23 13:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:22:28 --> CSRF cookie sent
INFO - 2016-05-23 13:22:28 --> Input Class Initialized
INFO - 2016-05-23 13:22:28 --> Language Class Initialized
INFO - 2016-05-23 13:22:28 --> Loader Class Initialized
INFO - 2016-05-23 13:22:28 --> Helper loaded: form_helper
INFO - 2016-05-23 13:22:28 --> Database Driver Class Initialized
INFO - 2016-05-23 13:22:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:22:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:22:28 --> Email Class Initialized
INFO - 2016-05-23 13:22:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:22:28 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:22:28 --> Helper loaded: language_helper
INFO - 2016-05-23 13:22:28 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:28 --> Model Class Initialized
INFO - 2016-05-23 13:22:28 --> Helper loaded: date_helper
INFO - 2016-05-23 13:22:28 --> Controller Class Initialized
INFO - 2016-05-23 13:22:28 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:22:28 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:22:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:22:28 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:22:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:22:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:22:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:28 --> Form Validation Class Initialized
INFO - 2016-05-23 13:22:32 --> Config Class Initialized
INFO - 2016-05-23 13:22:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:22:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:22:32 --> Utf8 Class Initialized
INFO - 2016-05-23 13:22:32 --> URI Class Initialized
INFO - 2016-05-23 13:22:32 --> Router Class Initialized
INFO - 2016-05-23 13:22:32 --> Output Class Initialized
INFO - 2016-05-23 13:22:32 --> Security Class Initialized
DEBUG - 2016-05-23 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:22:32 --> CSRF cookie sent
INFO - 2016-05-23 13:22:32 --> Input Class Initialized
INFO - 2016-05-23 13:22:32 --> Language Class Initialized
INFO - 2016-05-23 13:22:32 --> Loader Class Initialized
INFO - 2016-05-23 13:22:32 --> Helper loaded: form_helper
INFO - 2016-05-23 13:22:32 --> Database Driver Class Initialized
INFO - 2016-05-23 13:22:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:22:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:22:32 --> Email Class Initialized
INFO - 2016-05-23 13:22:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:22:32 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:22:32 --> Helper loaded: language_helper
INFO - 2016-05-23 13:22:32 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:32 --> Model Class Initialized
INFO - 2016-05-23 13:22:32 --> Helper loaded: date_helper
INFO - 2016-05-23 13:22:32 --> Controller Class Initialized
INFO - 2016-05-23 13:22:32 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:22:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:22:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:22:32 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:22:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:22:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:22:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:22:33 --> Form Validation Class Initialized
INFO - 2016-05-23 13:22:33 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 13:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:22:33 --> Final output sent to browser
DEBUG - 2016-05-23 13:22:33 --> Total execution time: 0.0451
INFO - 2016-05-23 13:24:42 --> Config Class Initialized
INFO - 2016-05-23 13:24:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:24:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:24:42 --> Utf8 Class Initialized
INFO - 2016-05-23 13:24:42 --> URI Class Initialized
INFO - 2016-05-23 13:24:42 --> Router Class Initialized
INFO - 2016-05-23 13:24:42 --> Output Class Initialized
INFO - 2016-05-23 13:24:42 --> Security Class Initialized
DEBUG - 2016-05-23 13:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:24:42 --> CSRF cookie sent
INFO - 2016-05-23 13:24:42 --> Input Class Initialized
INFO - 2016-05-23 13:24:42 --> Language Class Initialized
INFO - 2016-05-23 13:24:42 --> Loader Class Initialized
INFO - 2016-05-23 13:24:42 --> Helper loaded: form_helper
INFO - 2016-05-23 13:24:42 --> Database Driver Class Initialized
INFO - 2016-05-23 13:24:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:24:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:24:42 --> Email Class Initialized
INFO - 2016-05-23 13:24:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:24:42 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:24:42 --> Helper loaded: language_helper
INFO - 2016-05-23 13:24:42 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:24:42 --> Model Class Initialized
INFO - 2016-05-23 13:24:42 --> Helper loaded: date_helper
INFO - 2016-05-23 13:24:42 --> Controller Class Initialized
INFO - 2016-05-23 13:24:42 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:24:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:24:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:24:42 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:24:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:24:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:24:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:24:42 --> Form Validation Class Initialized
INFO - 2016-05-23 13:24:42 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:24:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:24:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 13:24:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:24:42 --> Final output sent to browser
DEBUG - 2016-05-23 13:24:42 --> Total execution time: 0.0428
INFO - 2016-05-23 13:25:07 --> Config Class Initialized
INFO - 2016-05-23 13:25:07 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:25:07 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:25:07 --> Utf8 Class Initialized
INFO - 2016-05-23 13:25:07 --> URI Class Initialized
INFO - 2016-05-23 13:25:07 --> Router Class Initialized
INFO - 2016-05-23 13:25:07 --> Output Class Initialized
INFO - 2016-05-23 13:25:07 --> Security Class Initialized
DEBUG - 2016-05-23 13:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:25:07 --> CSRF cookie sent
INFO - 2016-05-23 13:25:07 --> Input Class Initialized
INFO - 2016-05-23 13:25:07 --> Language Class Initialized
INFO - 2016-05-23 13:25:07 --> Loader Class Initialized
INFO - 2016-05-23 13:25:07 --> Helper loaded: form_helper
INFO - 2016-05-23 13:25:07 --> Database Driver Class Initialized
INFO - 2016-05-23 13:25:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:25:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:25:07 --> Email Class Initialized
INFO - 2016-05-23 13:25:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:25:07 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:25:07 --> Helper loaded: language_helper
INFO - 2016-05-23 13:25:07 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:07 --> Model Class Initialized
INFO - 2016-05-23 13:25:07 --> Helper loaded: date_helper
INFO - 2016-05-23 13:25:07 --> Controller Class Initialized
INFO - 2016-05-23 13:25:07 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:25:07 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:25:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:25:07 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:25:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:25:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:25:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:07 --> Form Validation Class Initialized
INFO - 2016-05-23 13:25:07 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 13:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:25:07 --> Final output sent to browser
DEBUG - 2016-05-23 13:25:07 --> Total execution time: 0.0414
INFO - 2016-05-23 13:25:37 --> Config Class Initialized
INFO - 2016-05-23 13:25:37 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:25:37 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:25:37 --> Utf8 Class Initialized
INFO - 2016-05-23 13:25:37 --> URI Class Initialized
INFO - 2016-05-23 13:25:37 --> Router Class Initialized
INFO - 2016-05-23 13:25:37 --> Output Class Initialized
INFO - 2016-05-23 13:25:37 --> Security Class Initialized
DEBUG - 2016-05-23 13:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:25:37 --> CSRF cookie sent
INFO - 2016-05-23 13:25:37 --> CSRF token verified
INFO - 2016-05-23 13:25:37 --> Input Class Initialized
INFO - 2016-05-23 13:25:37 --> Language Class Initialized
INFO - 2016-05-23 13:25:37 --> Loader Class Initialized
INFO - 2016-05-23 13:25:37 --> Helper loaded: form_helper
INFO - 2016-05-23 13:25:37 --> Database Driver Class Initialized
INFO - 2016-05-23 13:25:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:25:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:25:37 --> Email Class Initialized
INFO - 2016-05-23 13:25:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:25:37 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:25:37 --> Helper loaded: language_helper
INFO - 2016-05-23 13:25:37 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:37 --> Model Class Initialized
INFO - 2016-05-23 13:25:37 --> Helper loaded: date_helper
INFO - 2016-05-23 13:25:37 --> Controller Class Initialized
INFO - 2016-05-23 13:25:37 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:25:37 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:25:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:25:37 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:25:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:25:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:25:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:37 --> Form Validation Class Initialized
INFO - 2016-05-23 13:25:40 --> Config Class Initialized
INFO - 2016-05-23 13:25:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:25:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:25:40 --> Utf8 Class Initialized
INFO - 2016-05-23 13:25:40 --> URI Class Initialized
DEBUG - 2016-05-23 13:25:40 --> No URI present. Default controller set.
INFO - 2016-05-23 13:25:40 --> Router Class Initialized
INFO - 2016-05-23 13:25:40 --> Output Class Initialized
INFO - 2016-05-23 13:25:40 --> Security Class Initialized
DEBUG - 2016-05-23 13:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:25:40 --> CSRF cookie sent
INFO - 2016-05-23 13:25:40 --> Input Class Initialized
INFO - 2016-05-23 13:25:40 --> Language Class Initialized
INFO - 2016-05-23 13:25:40 --> Loader Class Initialized
INFO - 2016-05-23 13:25:40 --> Helper loaded: form_helper
INFO - 2016-05-23 13:25:40 --> Database Driver Class Initialized
INFO - 2016-05-23 13:25:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:25:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:25:40 --> Email Class Initialized
INFO - 2016-05-23 13:25:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:25:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:25:40 --> Helper loaded: language_helper
INFO - 2016-05-23 13:25:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:40 --> Model Class Initialized
INFO - 2016-05-23 13:25:40 --> Helper loaded: date_helper
INFO - 2016-05-23 13:25:40 --> Controller Class Initialized
INFO - 2016-05-23 13:25:40 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:25:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:25:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:25:40 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:25:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:25:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:25:41 --> Config Class Initialized
INFO - 2016-05-23 13:25:41 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:25:41 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:25:41 --> Utf8 Class Initialized
INFO - 2016-05-23 13:25:41 --> URI Class Initialized
INFO - 2016-05-23 13:25:41 --> Router Class Initialized
INFO - 2016-05-23 13:25:41 --> Output Class Initialized
INFO - 2016-05-23 13:25:41 --> Security Class Initialized
DEBUG - 2016-05-23 13:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:25:41 --> CSRF cookie sent
INFO - 2016-05-23 13:25:41 --> Input Class Initialized
INFO - 2016-05-23 13:25:41 --> Language Class Initialized
INFO - 2016-05-23 13:25:41 --> Loader Class Initialized
INFO - 2016-05-23 13:25:41 --> Helper loaded: form_helper
INFO - 2016-05-23 13:25:41 --> Database Driver Class Initialized
INFO - 2016-05-23 13:25:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:25:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:25:41 --> Email Class Initialized
INFO - 2016-05-23 13:25:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:25:41 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:25:41 --> Helper loaded: language_helper
INFO - 2016-05-23 13:25:41 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:41 --> Model Class Initialized
INFO - 2016-05-23 13:25:41 --> Helper loaded: date_helper
INFO - 2016-05-23 13:25:41 --> Controller Class Initialized
INFO - 2016-05-23 13:25:41 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:25:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:25:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:25:41 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:25:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:25:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 13:25:41 --> Model Class Initialized
INFO - 2016-05-23 13:25:41 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:25:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 13:25:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 13:25:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 13:25:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 13:25:41 --> Final output sent to browser
DEBUG - 2016-05-23 13:25:41 --> Total execution time: 0.0627
INFO - 2016-05-23 13:25:45 --> Config Class Initialized
INFO - 2016-05-23 13:25:45 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:25:45 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:25:45 --> Utf8 Class Initialized
INFO - 2016-05-23 13:25:45 --> URI Class Initialized
INFO - 2016-05-23 13:25:45 --> Router Class Initialized
INFO - 2016-05-23 13:25:45 --> Output Class Initialized
INFO - 2016-05-23 13:25:45 --> Security Class Initialized
DEBUG - 2016-05-23 13:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:25:45 --> CSRF cookie sent
INFO - 2016-05-23 13:25:45 --> Input Class Initialized
INFO - 2016-05-23 13:25:45 --> Language Class Initialized
INFO - 2016-05-23 13:25:45 --> Loader Class Initialized
INFO - 2016-05-23 13:25:45 --> Helper loaded: form_helper
INFO - 2016-05-23 13:25:45 --> Database Driver Class Initialized
INFO - 2016-05-23 13:25:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:25:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:25:45 --> Email Class Initialized
INFO - 2016-05-23 13:25:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:25:45 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:25:45 --> Helper loaded: language_helper
INFO - 2016-05-23 13:25:45 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:45 --> Model Class Initialized
INFO - 2016-05-23 13:25:45 --> Helper loaded: date_helper
INFO - 2016-05-23 13:25:45 --> Controller Class Initialized
INFO - 2016-05-23 13:25:45 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:25:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:25:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:25:45 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:25:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:25:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:25:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:45 --> Form Validation Class Initialized
INFO - 2016-05-23 13:25:46 --> Config Class Initialized
INFO - 2016-05-23 13:25:46 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:25:46 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:25:46 --> Utf8 Class Initialized
INFO - 2016-05-23 13:25:46 --> URI Class Initialized
INFO - 2016-05-23 13:25:46 --> Router Class Initialized
INFO - 2016-05-23 13:25:46 --> Output Class Initialized
INFO - 2016-05-23 13:25:46 --> Security Class Initialized
DEBUG - 2016-05-23 13:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:25:46 --> CSRF cookie sent
INFO - 2016-05-23 13:25:46 --> Input Class Initialized
INFO - 2016-05-23 13:25:46 --> Language Class Initialized
INFO - 2016-05-23 13:25:46 --> Loader Class Initialized
INFO - 2016-05-23 13:25:46 --> Helper loaded: form_helper
INFO - 2016-05-23 13:25:46 --> Database Driver Class Initialized
INFO - 2016-05-23 13:25:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:25:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:25:46 --> Email Class Initialized
INFO - 2016-05-23 13:25:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:25:46 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:25:46 --> Helper loaded: language_helper
INFO - 2016-05-23 13:25:46 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:46 --> Model Class Initialized
INFO - 2016-05-23 13:25:46 --> Helper loaded: date_helper
INFO - 2016-05-23 13:25:46 --> Controller Class Initialized
INFO - 2016-05-23 13:25:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 13:25:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 13:25:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 13:25:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 13:25:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 13:25:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 13:25:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:25:46 --> Form Validation Class Initialized
INFO - 2016-05-23 13:25:46 --> Helper loaded: languages_helper
INFO - 2016-05-23 13:25:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 13:25:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 13:25:47 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 13:25:47 --> Final output sent to browser
DEBUG - 2016-05-23 13:25:47 --> Total execution time: 0.0654
INFO - 2016-05-23 13:44:11 --> Config Class Initialized
INFO - 2016-05-23 13:44:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:44:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:44:11 --> Utf8 Class Initialized
INFO - 2016-05-23 13:44:11 --> URI Class Initialized
INFO - 2016-05-23 13:44:11 --> Router Class Initialized
INFO - 2016-05-23 13:44:11 --> Output Class Initialized
INFO - 2016-05-23 13:44:11 --> Security Class Initialized
DEBUG - 2016-05-23 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:44:11 --> CSRF cookie sent
INFO - 2016-05-23 13:44:11 --> Input Class Initialized
INFO - 2016-05-23 13:44:11 --> Language Class Initialized
INFO - 2016-05-23 13:44:11 --> Loader Class Initialized
INFO - 2016-05-23 13:44:11 --> Helper loaded: form_helper
INFO - 2016-05-23 13:44:11 --> Database Driver Class Initialized
INFO - 2016-05-23 13:44:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:44:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:44:11 --> Email Class Initialized
INFO - 2016-05-23 13:44:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:44:11 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:44:11 --> Helper loaded: language_helper
INFO - 2016-05-23 13:44:11 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:44:11 --> Model Class Initialized
INFO - 2016-05-23 13:44:11 --> Helper loaded: date_helper
INFO - 2016-05-23 13:44:11 --> Controller Class Initialized
DEBUG - 2016-05-23 13:44:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:44:11 --> Form Validation Class Initialized
INFO - 2016-05-23 13:44:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 13:44:11 --> Config Class Initialized
INFO - 2016-05-23 13:44:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 13:44:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 13:44:11 --> Utf8 Class Initialized
INFO - 2016-05-23 13:44:11 --> URI Class Initialized
INFO - 2016-05-23 13:44:11 --> Router Class Initialized
INFO - 2016-05-23 13:44:11 --> Output Class Initialized
INFO - 2016-05-23 13:44:11 --> Security Class Initialized
DEBUG - 2016-05-23 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 13:44:11 --> CSRF cookie sent
INFO - 2016-05-23 13:44:11 --> Input Class Initialized
INFO - 2016-05-23 13:44:11 --> Language Class Initialized
INFO - 2016-05-23 13:44:11 --> Loader Class Initialized
INFO - 2016-05-23 13:44:11 --> Helper loaded: form_helper
INFO - 2016-05-23 13:44:11 --> Database Driver Class Initialized
INFO - 2016-05-23 13:44:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 13:44:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 13:44:11 --> Email Class Initialized
INFO - 2016-05-23 13:44:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 13:44:11 --> Helper loaded: cookie_helper
INFO - 2016-05-23 13:44:11 --> Helper loaded: language_helper
INFO - 2016-05-23 13:44:11 --> Helper loaded: url_helper
DEBUG - 2016-05-23 13:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:44:11 --> Model Class Initialized
INFO - 2016-05-23 13:44:11 --> Helper loaded: date_helper
INFO - 2016-05-23 13:44:11 --> Controller Class Initialized
DEBUG - 2016-05-23 13:44:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 13:44:11 --> Form Validation Class Initialized
INFO - 2016-05-23 13:44:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 14:00:44 --> Config Class Initialized
INFO - 2016-05-23 14:00:44 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:00:44 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:00:44 --> Utf8 Class Initialized
INFO - 2016-05-23 14:00:44 --> URI Class Initialized
INFO - 2016-05-23 14:00:44 --> Router Class Initialized
INFO - 2016-05-23 14:00:44 --> Output Class Initialized
INFO - 2016-05-23 14:00:44 --> Security Class Initialized
DEBUG - 2016-05-23 14:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:00:44 --> CSRF cookie sent
INFO - 2016-05-23 14:00:44 --> Input Class Initialized
INFO - 2016-05-23 14:00:44 --> Language Class Initialized
INFO - 2016-05-23 14:00:44 --> Loader Class Initialized
INFO - 2016-05-23 14:00:44 --> Helper loaded: form_helper
INFO - 2016-05-23 14:00:44 --> Database Driver Class Initialized
INFO - 2016-05-23 14:00:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:00:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:00:44 --> Email Class Initialized
INFO - 2016-05-23 14:00:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:00:44 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:00:44 --> Helper loaded: language_helper
INFO - 2016-05-23 14:00:44 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:00:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:00:44 --> Model Class Initialized
INFO - 2016-05-23 14:00:44 --> Helper loaded: date_helper
INFO - 2016-05-23 14:00:44 --> Controller Class Initialized
INFO - 2016-05-23 14:00:44 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:00:44 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:00:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:00:44 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:00:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:00:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:00:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:00:44 --> Form Validation Class Initialized
INFO - 2016-05-23 14:00:44 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:00:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:00:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:00:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:00:44 --> Final output sent to browser
DEBUG - 2016-05-23 14:00:44 --> Total execution time: 0.0926
INFO - 2016-05-23 14:01:01 --> Config Class Initialized
INFO - 2016-05-23 14:01:01 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:01:01 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:01:01 --> Utf8 Class Initialized
INFO - 2016-05-23 14:01:01 --> URI Class Initialized
INFO - 2016-05-23 14:01:01 --> Router Class Initialized
INFO - 2016-05-23 14:01:01 --> Output Class Initialized
INFO - 2016-05-23 14:01:01 --> Security Class Initialized
DEBUG - 2016-05-23 14:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:01:01 --> CSRF cookie sent
INFO - 2016-05-23 14:01:01 --> CSRF token verified
INFO - 2016-05-23 14:01:01 --> Input Class Initialized
INFO - 2016-05-23 14:01:01 --> Language Class Initialized
INFO - 2016-05-23 14:01:01 --> Loader Class Initialized
INFO - 2016-05-23 14:01:01 --> Helper loaded: form_helper
INFO - 2016-05-23 14:01:01 --> Database Driver Class Initialized
INFO - 2016-05-23 14:01:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:01:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:01:02 --> Email Class Initialized
INFO - 2016-05-23 14:01:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:01:02 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:01:02 --> Helper loaded: language_helper
INFO - 2016-05-23 14:01:02 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:01:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:01:02 --> Model Class Initialized
INFO - 2016-05-23 14:01:02 --> Helper loaded: date_helper
INFO - 2016-05-23 14:01:02 --> Controller Class Initialized
INFO - 2016-05-23 14:01:02 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:01:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:01:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:01:02 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:01:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:01:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:01:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:01:02 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:01:02 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:01:02 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:01:02 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:01:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:01:02 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:01:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:01:02 --> Final output sent to browser
DEBUG - 2016-05-23 14:01:02 --> Total execution time: 0.0484
INFO - 2016-05-23 14:02:56 --> Config Class Initialized
INFO - 2016-05-23 14:02:56 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:02:56 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:02:56 --> Utf8 Class Initialized
INFO - 2016-05-23 14:02:56 --> URI Class Initialized
INFO - 2016-05-23 14:02:56 --> Router Class Initialized
INFO - 2016-05-23 14:02:56 --> Output Class Initialized
INFO - 2016-05-23 14:02:56 --> Security Class Initialized
DEBUG - 2016-05-23 14:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:02:56 --> CSRF cookie sent
INFO - 2016-05-23 14:02:56 --> CSRF token verified
INFO - 2016-05-23 14:02:56 --> Input Class Initialized
INFO - 2016-05-23 14:02:56 --> Language Class Initialized
INFO - 2016-05-23 14:02:56 --> Loader Class Initialized
INFO - 2016-05-23 14:02:56 --> Helper loaded: form_helper
INFO - 2016-05-23 14:02:56 --> Database Driver Class Initialized
INFO - 2016-05-23 14:02:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:02:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:02:56 --> Email Class Initialized
INFO - 2016-05-23 14:02:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:02:56 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:02:56 --> Helper loaded: language_helper
INFO - 2016-05-23 14:02:56 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:02:56 --> Model Class Initialized
INFO - 2016-05-23 14:02:56 --> Helper loaded: date_helper
INFO - 2016-05-23 14:02:56 --> Controller Class Initialized
INFO - 2016-05-23 14:02:56 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:02:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:02:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:02:56 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:02:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:02:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:02:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:02:56 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:02:56 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:02:56 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:02:56 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:02:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:02:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:02:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:02:56 --> Final output sent to browser
DEBUG - 2016-05-23 14:02:56 --> Total execution time: 0.0575
INFO - 2016-05-23 14:04:03 --> Config Class Initialized
INFO - 2016-05-23 14:04:03 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:04:03 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:04:03 --> Utf8 Class Initialized
INFO - 2016-05-23 14:04:03 --> URI Class Initialized
INFO - 2016-05-23 14:04:03 --> Router Class Initialized
INFO - 2016-05-23 14:04:03 --> Output Class Initialized
INFO - 2016-05-23 14:04:03 --> Security Class Initialized
DEBUG - 2016-05-23 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:04:03 --> CSRF cookie sent
INFO - 2016-05-23 14:04:03 --> CSRF token verified
INFO - 2016-05-23 14:04:03 --> Input Class Initialized
INFO - 2016-05-23 14:04:03 --> Language Class Initialized
INFO - 2016-05-23 14:04:03 --> Loader Class Initialized
INFO - 2016-05-23 14:04:03 --> Helper loaded: form_helper
INFO - 2016-05-23 14:04:03 --> Database Driver Class Initialized
INFO - 2016-05-23 14:04:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:04:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:04:03 --> Email Class Initialized
INFO - 2016-05-23 14:04:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:04:03 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:04:03 --> Helper loaded: language_helper
INFO - 2016-05-23 14:04:03 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:04:03 --> Model Class Initialized
INFO - 2016-05-23 14:04:03 --> Helper loaded: date_helper
INFO - 2016-05-23 14:04:03 --> Controller Class Initialized
INFO - 2016-05-23 14:04:03 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:04:03 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:04:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:04:03 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:04:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:04:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:04:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:04:03 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:04:03 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:04:03 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:04:03 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:04:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:04:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:04:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:04:03 --> Final output sent to browser
DEBUG - 2016-05-23 14:04:03 --> Total execution time: 0.0626
INFO - 2016-05-23 14:04:12 --> Config Class Initialized
INFO - 2016-05-23 14:04:12 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:04:12 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:04:12 --> Utf8 Class Initialized
INFO - 2016-05-23 14:04:12 --> URI Class Initialized
INFO - 2016-05-23 14:04:12 --> Router Class Initialized
INFO - 2016-05-23 14:04:12 --> Output Class Initialized
INFO - 2016-05-23 14:04:12 --> Security Class Initialized
DEBUG - 2016-05-23 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:04:12 --> CSRF cookie sent
INFO - 2016-05-23 14:04:12 --> CSRF token verified
INFO - 2016-05-23 14:04:12 --> Input Class Initialized
INFO - 2016-05-23 14:04:12 --> Language Class Initialized
INFO - 2016-05-23 14:04:12 --> Loader Class Initialized
INFO - 2016-05-23 14:04:12 --> Helper loaded: form_helper
INFO - 2016-05-23 14:04:12 --> Database Driver Class Initialized
INFO - 2016-05-23 14:04:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:04:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:04:12 --> Email Class Initialized
INFO - 2016-05-23 14:04:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:04:12 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:04:12 --> Helper loaded: language_helper
INFO - 2016-05-23 14:04:12 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:04:12 --> Model Class Initialized
INFO - 2016-05-23 14:04:12 --> Helper loaded: date_helper
INFO - 2016-05-23 14:04:12 --> Controller Class Initialized
INFO - 2016-05-23 14:04:12 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:04:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:04:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:04:12 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:04:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:04:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:04:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:04:12 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:04:12 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:04:12 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:04:12 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:04:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:04:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:04:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:04:12 --> Final output sent to browser
DEBUG - 2016-05-23 14:04:12 --> Total execution time: 0.3096
INFO - 2016-05-23 14:05:54 --> Config Class Initialized
INFO - 2016-05-23 14:05:54 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:05:54 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:05:54 --> Utf8 Class Initialized
INFO - 2016-05-23 14:05:54 --> URI Class Initialized
DEBUG - 2016-05-23 14:05:54 --> No URI present. Default controller set.
INFO - 2016-05-23 14:05:54 --> Router Class Initialized
INFO - 2016-05-23 14:05:54 --> Output Class Initialized
INFO - 2016-05-23 14:05:54 --> Security Class Initialized
DEBUG - 2016-05-23 14:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:05:54 --> CSRF cookie sent
INFO - 2016-05-23 14:05:54 --> Input Class Initialized
INFO - 2016-05-23 14:05:54 --> Language Class Initialized
INFO - 2016-05-23 14:05:54 --> Loader Class Initialized
INFO - 2016-05-23 14:05:54 --> Helper loaded: form_helper
INFO - 2016-05-23 14:05:54 --> Database Driver Class Initialized
INFO - 2016-05-23 14:05:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:05:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:05:54 --> Email Class Initialized
INFO - 2016-05-23 14:05:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:05:54 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:05:54 --> Helper loaded: language_helper
INFO - 2016-05-23 14:05:54 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:05:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:05:54 --> Model Class Initialized
INFO - 2016-05-23 14:05:54 --> Helper loaded: date_helper
INFO - 2016-05-23 14:05:54 --> Controller Class Initialized
INFO - 2016-05-23 14:05:54 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:05:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:05:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:05:54 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:05:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:05:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:05:54 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:05:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:05:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 14:05:54 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:05:54 --> Final output sent to browser
DEBUG - 2016-05-23 14:05:54 --> Total execution time: 0.0303
INFO - 2016-05-23 14:06:02 --> Config Class Initialized
INFO - 2016-05-23 14:06:02 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:06:02 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:06:02 --> Utf8 Class Initialized
INFO - 2016-05-23 14:06:02 --> URI Class Initialized
INFO - 2016-05-23 14:06:02 --> Router Class Initialized
INFO - 2016-05-23 14:06:02 --> Output Class Initialized
INFO - 2016-05-23 14:06:02 --> Security Class Initialized
DEBUG - 2016-05-23 14:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:06:02 --> CSRF cookie sent
INFO - 2016-05-23 14:06:02 --> Input Class Initialized
INFO - 2016-05-23 14:06:02 --> Language Class Initialized
INFO - 2016-05-23 14:06:02 --> Loader Class Initialized
INFO - 2016-05-23 14:06:02 --> Helper loaded: form_helper
INFO - 2016-05-23 14:06:02 --> Database Driver Class Initialized
INFO - 2016-05-23 14:06:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:06:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:06:02 --> Email Class Initialized
INFO - 2016-05-23 14:06:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:06:02 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:06:02 --> Helper loaded: language_helper
INFO - 2016-05-23 14:06:02 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:06:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:06:02 --> Model Class Initialized
INFO - 2016-05-23 14:06:02 --> Helper loaded: date_helper
INFO - 2016-05-23 14:06:02 --> Controller Class Initialized
INFO - 2016-05-23 14:06:02 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:06:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:06:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:06:02 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:06:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:06:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:06:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:06:02 --> Form Validation Class Initialized
INFO - 2016-05-23 14:06:02 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:06:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:06:02 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:06:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:06:02 --> Final output sent to browser
DEBUG - 2016-05-23 14:06:02 --> Total execution time: 0.0811
INFO - 2016-05-23 14:06:10 --> Config Class Initialized
INFO - 2016-05-23 14:06:10 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:06:10 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:06:10 --> Utf8 Class Initialized
INFO - 2016-05-23 14:06:10 --> URI Class Initialized
INFO - 2016-05-23 14:06:10 --> Router Class Initialized
INFO - 2016-05-23 14:06:10 --> Output Class Initialized
INFO - 2016-05-23 14:06:10 --> Security Class Initialized
DEBUG - 2016-05-23 14:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:06:10 --> CSRF cookie sent
INFO - 2016-05-23 14:06:10 --> CSRF token verified
INFO - 2016-05-23 14:06:10 --> Input Class Initialized
INFO - 2016-05-23 14:06:10 --> Language Class Initialized
INFO - 2016-05-23 14:06:10 --> Loader Class Initialized
INFO - 2016-05-23 14:06:10 --> Helper loaded: form_helper
INFO - 2016-05-23 14:06:10 --> Database Driver Class Initialized
INFO - 2016-05-23 14:06:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:06:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:06:10 --> Email Class Initialized
INFO - 2016-05-23 14:06:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:06:10 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:06:10 --> Helper loaded: language_helper
INFO - 2016-05-23 14:06:10 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:06:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:06:10 --> Model Class Initialized
INFO - 2016-05-23 14:06:10 --> Helper loaded: date_helper
INFO - 2016-05-23 14:06:10 --> Controller Class Initialized
INFO - 2016-05-23 14:06:10 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:06:10 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:06:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:06:10 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:06:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:06:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:06:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:06:10 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:06:10 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:06:10 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:06:10 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:06:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:06:10 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:06:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:06:10 --> Final output sent to browser
DEBUG - 2016-05-23 14:06:10 --> Total execution time: 0.0448
INFO - 2016-05-23 14:07:12 --> Config Class Initialized
INFO - 2016-05-23 14:07:12 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:07:12 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:07:12 --> Utf8 Class Initialized
INFO - 2016-05-23 14:07:12 --> URI Class Initialized
INFO - 2016-05-23 14:07:12 --> Router Class Initialized
INFO - 2016-05-23 14:07:12 --> Output Class Initialized
INFO - 2016-05-23 14:07:12 --> Security Class Initialized
DEBUG - 2016-05-23 14:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:07:12 --> CSRF cookie sent
INFO - 2016-05-23 14:07:12 --> CSRF token verified
INFO - 2016-05-23 14:07:12 --> Input Class Initialized
INFO - 2016-05-23 14:07:12 --> Language Class Initialized
INFO - 2016-05-23 14:07:12 --> Loader Class Initialized
INFO - 2016-05-23 14:07:12 --> Helper loaded: form_helper
INFO - 2016-05-23 14:07:12 --> Database Driver Class Initialized
INFO - 2016-05-23 14:07:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:07:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:07:12 --> Email Class Initialized
INFO - 2016-05-23 14:07:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:07:12 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:07:12 --> Helper loaded: language_helper
INFO - 2016-05-23 14:07:12 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:07:12 --> Model Class Initialized
INFO - 2016-05-23 14:07:12 --> Helper loaded: date_helper
INFO - 2016-05-23 14:07:12 --> Controller Class Initialized
INFO - 2016-05-23 14:07:12 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:07:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:07:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:07:12 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:07:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:07:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:07:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:07:12 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-05-23 14:07:12 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:07:12 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:07:12 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:07:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:07:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:07:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:07:12 --> Final output sent to browser
DEBUG - 2016-05-23 14:07:12 --> Total execution time: 0.0245
INFO - 2016-05-23 14:07:23 --> Config Class Initialized
INFO - 2016-05-23 14:07:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:07:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:07:23 --> Utf8 Class Initialized
INFO - 2016-05-23 14:07:23 --> URI Class Initialized
INFO - 2016-05-23 14:07:23 --> Router Class Initialized
INFO - 2016-05-23 14:07:23 --> Output Class Initialized
INFO - 2016-05-23 14:07:23 --> Security Class Initialized
DEBUG - 2016-05-23 14:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:07:23 --> CSRF cookie sent
INFO - 2016-05-23 14:07:23 --> Input Class Initialized
INFO - 2016-05-23 14:07:23 --> Language Class Initialized
INFO - 2016-05-23 14:07:23 --> Loader Class Initialized
INFO - 2016-05-23 14:07:23 --> Helper loaded: form_helper
INFO - 2016-05-23 14:07:23 --> Database Driver Class Initialized
INFO - 2016-05-23 14:07:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:07:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:07:23 --> Email Class Initialized
INFO - 2016-05-23 14:07:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:07:23 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:07:23 --> Helper loaded: language_helper
INFO - 2016-05-23 14:07:23 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:07:23 --> Model Class Initialized
INFO - 2016-05-23 14:07:23 --> Helper loaded: date_helper
INFO - 2016-05-23 14:07:23 --> Controller Class Initialized
INFO - 2016-05-23 14:07:23 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:07:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:07:23 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:07:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:07:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:07:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:07:23 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:07:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:07:23 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:07:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:07:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:07:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:07:23 --> Final output sent to browser
DEBUG - 2016-05-23 14:07:23 --> Total execution time: 0.0892
INFO - 2016-05-23 14:07:53 --> Config Class Initialized
INFO - 2016-05-23 14:07:53 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:07:53 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:07:53 --> Utf8 Class Initialized
INFO - 2016-05-23 14:07:53 --> URI Class Initialized
INFO - 2016-05-23 14:07:53 --> Router Class Initialized
INFO - 2016-05-23 14:07:53 --> Output Class Initialized
INFO - 2016-05-23 14:07:53 --> Security Class Initialized
DEBUG - 2016-05-23 14:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:07:53 --> CSRF cookie sent
INFO - 2016-05-23 14:07:53 --> CSRF token verified
INFO - 2016-05-23 14:07:53 --> Input Class Initialized
INFO - 2016-05-23 14:07:53 --> Language Class Initialized
INFO - 2016-05-23 14:07:53 --> Loader Class Initialized
INFO - 2016-05-23 14:07:53 --> Helper loaded: form_helper
INFO - 2016-05-23 14:07:53 --> Database Driver Class Initialized
INFO - 2016-05-23 14:07:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:07:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:07:53 --> Email Class Initialized
INFO - 2016-05-23 14:07:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:07:53 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:07:53 --> Helper loaded: language_helper
INFO - 2016-05-23 14:07:53 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:07:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:07:53 --> Model Class Initialized
INFO - 2016-05-23 14:07:53 --> Helper loaded: date_helper
INFO - 2016-05-23 14:07:53 --> Controller Class Initialized
INFO - 2016-05-23 14:07:53 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:07:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:07:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:07:53 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:07:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:07:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:07:53 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:07:53 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:07:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-05-23 14:07:53 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:07:53 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:07:53 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:07:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:07:53 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:07:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:07:53 --> Final output sent to browser
DEBUG - 2016-05-23 14:07:53 --> Total execution time: 0.0515
INFO - 2016-05-23 14:08:31 --> Config Class Initialized
INFO - 2016-05-23 14:08:31 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:08:31 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:08:31 --> Utf8 Class Initialized
INFO - 2016-05-23 14:08:31 --> URI Class Initialized
INFO - 2016-05-23 14:08:31 --> Router Class Initialized
INFO - 2016-05-23 14:08:31 --> Output Class Initialized
INFO - 2016-05-23 14:08:31 --> Security Class Initialized
DEBUG - 2016-05-23 14:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:08:31 --> CSRF cookie sent
INFO - 2016-05-23 14:08:31 --> CSRF token verified
INFO - 2016-05-23 14:08:31 --> Input Class Initialized
INFO - 2016-05-23 14:08:31 --> Language Class Initialized
INFO - 2016-05-23 14:08:31 --> Loader Class Initialized
INFO - 2016-05-23 14:08:31 --> Helper loaded: form_helper
INFO - 2016-05-23 14:08:31 --> Database Driver Class Initialized
INFO - 2016-05-23 14:08:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:08:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:08:31 --> Email Class Initialized
INFO - 2016-05-23 14:08:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:08:31 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:08:31 --> Helper loaded: language_helper
INFO - 2016-05-23 14:08:31 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:08:31 --> Model Class Initialized
INFO - 2016-05-23 14:08:31 --> Helper loaded: date_helper
INFO - 2016-05-23 14:08:31 --> Controller Class Initialized
INFO - 2016-05-23 14:08:31 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:08:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:08:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:08:31 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:08:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:08:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:08:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:08:31 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:08:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-05-23 14:08:31 --> Unable to find callback validation rule: recaptcha
ERROR - 2016-05-23 14:08:31 --> Could not find the language line "form_validation_recaptcha"
INFO - 2016-05-23 14:08:31 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:08:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:08:31 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:08:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:08:31 --> Final output sent to browser
DEBUG - 2016-05-23 14:08:31 --> Total execution time: 0.1014
INFO - 2016-05-23 14:11:23 --> Config Class Initialized
INFO - 2016-05-23 14:11:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:11:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:11:23 --> Utf8 Class Initialized
INFO - 2016-05-23 14:11:23 --> URI Class Initialized
INFO - 2016-05-23 14:11:23 --> Router Class Initialized
INFO - 2016-05-23 14:11:23 --> Output Class Initialized
INFO - 2016-05-23 14:11:23 --> Security Class Initialized
DEBUG - 2016-05-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:11:23 --> CSRF cookie sent
INFO - 2016-05-23 14:11:23 --> Input Class Initialized
INFO - 2016-05-23 14:11:23 --> Language Class Initialized
INFO - 2016-05-23 14:11:23 --> Loader Class Initialized
INFO - 2016-05-23 14:11:23 --> Helper loaded: form_helper
INFO - 2016-05-23 14:11:23 --> Database Driver Class Initialized
INFO - 2016-05-23 14:11:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:11:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:11:23 --> Email Class Initialized
INFO - 2016-05-23 14:11:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:11:23 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:11:23 --> Helper loaded: language_helper
INFO - 2016-05-23 14:11:23 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:23 --> Model Class Initialized
INFO - 2016-05-23 14:11:23 --> Helper loaded: date_helper
INFO - 2016-05-23 14:11:23 --> Controller Class Initialized
INFO - 2016-05-23 14:11:23 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:11:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:11:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:11:23 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:11:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:11:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:11:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:23 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:11:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:23 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:11:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:11:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:11:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:11:23 --> Final output sent to browser
DEBUG - 2016-05-23 14:11:23 --> Total execution time: 0.0573
INFO - 2016-05-23 14:11:30 --> Config Class Initialized
INFO - 2016-05-23 14:11:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:11:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:11:30 --> Utf8 Class Initialized
INFO - 2016-05-23 14:11:30 --> URI Class Initialized
INFO - 2016-05-23 14:11:30 --> Router Class Initialized
INFO - 2016-05-23 14:11:30 --> Output Class Initialized
INFO - 2016-05-23 14:11:30 --> Security Class Initialized
DEBUG - 2016-05-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:11:30 --> CSRF cookie sent
INFO - 2016-05-23 14:11:30 --> CSRF token verified
INFO - 2016-05-23 14:11:30 --> Input Class Initialized
INFO - 2016-05-23 14:11:30 --> Language Class Initialized
INFO - 2016-05-23 14:11:30 --> Loader Class Initialized
INFO - 2016-05-23 14:11:30 --> Helper loaded: form_helper
INFO - 2016-05-23 14:11:30 --> Database Driver Class Initialized
INFO - 2016-05-23 14:11:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:11:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:11:30 --> Email Class Initialized
INFO - 2016-05-23 14:11:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:11:30 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:11:30 --> Helper loaded: language_helper
INFO - 2016-05-23 14:11:30 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:30 --> Model Class Initialized
INFO - 2016-05-23 14:11:30 --> Helper loaded: date_helper
INFO - 2016-05-23 14:11:30 --> Controller Class Initialized
INFO - 2016-05-23 14:11:30 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:11:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:11:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:11:30 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:11:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:11:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:11:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:30 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:11:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:32 --> Config Class Initialized
INFO - 2016-05-23 14:11:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:11:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:11:32 --> Utf8 Class Initialized
INFO - 2016-05-23 14:11:32 --> URI Class Initialized
DEBUG - 2016-05-23 14:11:32 --> No URI present. Default controller set.
INFO - 2016-05-23 14:11:32 --> Router Class Initialized
INFO - 2016-05-23 14:11:32 --> Output Class Initialized
INFO - 2016-05-23 14:11:32 --> Security Class Initialized
DEBUG - 2016-05-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:11:32 --> CSRF cookie sent
INFO - 2016-05-23 14:11:32 --> Input Class Initialized
INFO - 2016-05-23 14:11:32 --> Language Class Initialized
INFO - 2016-05-23 14:11:32 --> Loader Class Initialized
INFO - 2016-05-23 14:11:32 --> Helper loaded: form_helper
INFO - 2016-05-23 14:11:32 --> Database Driver Class Initialized
INFO - 2016-05-23 14:11:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:11:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:11:32 --> Email Class Initialized
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:11:32 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:11:32 --> Helper loaded: language_helper
INFO - 2016-05-23 14:11:32 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:32 --> Model Class Initialized
INFO - 2016-05-23 14:11:32 --> Helper loaded: date_helper
INFO - 2016-05-23 14:11:32 --> Controller Class Initialized
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:11:32 --> Config Class Initialized
INFO - 2016-05-23 14:11:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:11:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:11:32 --> Utf8 Class Initialized
INFO - 2016-05-23 14:11:32 --> URI Class Initialized
INFO - 2016-05-23 14:11:32 --> Router Class Initialized
INFO - 2016-05-23 14:11:32 --> Output Class Initialized
INFO - 2016-05-23 14:11:32 --> Security Class Initialized
DEBUG - 2016-05-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:11:32 --> CSRF cookie sent
INFO - 2016-05-23 14:11:32 --> Input Class Initialized
INFO - 2016-05-23 14:11:32 --> Language Class Initialized
INFO - 2016-05-23 14:11:32 --> Loader Class Initialized
INFO - 2016-05-23 14:11:32 --> Helper loaded: form_helper
INFO - 2016-05-23 14:11:32 --> Database Driver Class Initialized
INFO - 2016-05-23 14:11:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:11:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:11:32 --> Email Class Initialized
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:11:32 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:11:32 --> Helper loaded: language_helper
INFO - 2016-05-23 14:11:32 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:11:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:11:32 --> Model Class Initialized
INFO - 2016-05-23 14:11:32 --> Helper loaded: date_helper
INFO - 2016-05-23 14:11:32 --> Controller Class Initialized
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:11:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:11:32 --> Model Class Initialized
INFO - 2016-05-23 14:11:32 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:11:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 14:11:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 14:11:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 14:11:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 14:11:32 --> Final output sent to browser
DEBUG - 2016-05-23 14:11:32 --> Total execution time: 0.0583
INFO - 2016-05-23 14:12:07 --> Config Class Initialized
INFO - 2016-05-23 14:12:07 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:12:07 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:12:07 --> Utf8 Class Initialized
INFO - 2016-05-23 14:12:07 --> URI Class Initialized
INFO - 2016-05-23 14:12:07 --> Router Class Initialized
INFO - 2016-05-23 14:12:07 --> Output Class Initialized
INFO - 2016-05-23 14:12:07 --> Security Class Initialized
DEBUG - 2016-05-23 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:12:07 --> CSRF cookie sent
INFO - 2016-05-23 14:12:07 --> Input Class Initialized
INFO - 2016-05-23 14:12:07 --> Language Class Initialized
INFO - 2016-05-23 14:12:07 --> Loader Class Initialized
INFO - 2016-05-23 14:12:07 --> Helper loaded: form_helper
INFO - 2016-05-23 14:12:07 --> Database Driver Class Initialized
INFO - 2016-05-23 14:12:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:12:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:12:07 --> Email Class Initialized
INFO - 2016-05-23 14:12:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:12:07 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:12:07 --> Helper loaded: language_helper
INFO - 2016-05-23 14:12:07 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:07 --> Model Class Initialized
INFO - 2016-05-23 14:12:07 --> Helper loaded: date_helper
INFO - 2016-05-23 14:12:07 --> Controller Class Initialized
INFO - 2016-05-23 14:12:07 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:12:07 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:12:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:12:07 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:12:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:12:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:12:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:07 --> Form Validation Class Initialized
INFO - 2016-05-23 14:12:09 --> Config Class Initialized
INFO - 2016-05-23 14:12:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:12:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:12:09 --> Utf8 Class Initialized
INFO - 2016-05-23 14:12:09 --> URI Class Initialized
INFO - 2016-05-23 14:12:09 --> Router Class Initialized
INFO - 2016-05-23 14:12:09 --> Output Class Initialized
INFO - 2016-05-23 14:12:09 --> Security Class Initialized
DEBUG - 2016-05-23 14:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:12:09 --> CSRF cookie sent
INFO - 2016-05-23 14:12:09 --> Input Class Initialized
INFO - 2016-05-23 14:12:09 --> Language Class Initialized
INFO - 2016-05-23 14:12:09 --> Loader Class Initialized
INFO - 2016-05-23 14:12:09 --> Helper loaded: form_helper
INFO - 2016-05-23 14:12:09 --> Database Driver Class Initialized
INFO - 2016-05-23 14:12:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:12:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:12:09 --> Email Class Initialized
INFO - 2016-05-23 14:12:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:12:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:12:09 --> Helper loaded: language_helper
INFO - 2016-05-23 14:12:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:09 --> Model Class Initialized
INFO - 2016-05-23 14:12:09 --> Helper loaded: date_helper
INFO - 2016-05-23 14:12:09 --> Controller Class Initialized
INFO - 2016-05-23 14:12:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:12:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:12:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:12:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:12:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:12:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:12:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:09 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:12:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:09 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:12:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:12:09 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:12:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:12:09 --> Final output sent to browser
DEBUG - 2016-05-23 14:12:09 --> Total execution time: 0.0240
INFO - 2016-05-23 14:12:17 --> Config Class Initialized
INFO - 2016-05-23 14:12:17 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:12:17 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:12:17 --> Utf8 Class Initialized
INFO - 2016-05-23 14:12:17 --> URI Class Initialized
INFO - 2016-05-23 14:12:17 --> Router Class Initialized
INFO - 2016-05-23 14:12:17 --> Output Class Initialized
INFO - 2016-05-23 14:12:17 --> Security Class Initialized
DEBUG - 2016-05-23 14:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:12:17 --> CSRF cookie sent
INFO - 2016-05-23 14:12:17 --> CSRF token verified
INFO - 2016-05-23 14:12:17 --> Input Class Initialized
INFO - 2016-05-23 14:12:17 --> Language Class Initialized
INFO - 2016-05-23 14:12:17 --> Loader Class Initialized
INFO - 2016-05-23 14:12:17 --> Helper loaded: form_helper
INFO - 2016-05-23 14:12:17 --> Database Driver Class Initialized
INFO - 2016-05-23 14:12:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:12:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:12:17 --> Email Class Initialized
INFO - 2016-05-23 14:12:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:12:17 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:12:17 --> Helper loaded: language_helper
INFO - 2016-05-23 14:12:17 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:17 --> Model Class Initialized
INFO - 2016-05-23 14:12:17 --> Helper loaded: date_helper
INFO - 2016-05-23 14:12:17 --> Controller Class Initialized
INFO - 2016-05-23 14:12:17 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:12:17 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:12:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:12:17 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:12:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:12:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:12:18 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:18 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:12:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:21 --> Config Class Initialized
INFO - 2016-05-23 14:12:21 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:12:21 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:12:21 --> Utf8 Class Initialized
INFO - 2016-05-23 14:12:21 --> URI Class Initialized
DEBUG - 2016-05-23 14:12:21 --> No URI present. Default controller set.
INFO - 2016-05-23 14:12:21 --> Router Class Initialized
INFO - 2016-05-23 14:12:21 --> Output Class Initialized
INFO - 2016-05-23 14:12:21 --> Security Class Initialized
DEBUG - 2016-05-23 14:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:12:21 --> CSRF cookie sent
INFO - 2016-05-23 14:12:21 --> Input Class Initialized
INFO - 2016-05-23 14:12:21 --> Language Class Initialized
INFO - 2016-05-23 14:12:21 --> Loader Class Initialized
INFO - 2016-05-23 14:12:21 --> Helper loaded: form_helper
INFO - 2016-05-23 14:12:21 --> Database Driver Class Initialized
INFO - 2016-05-23 14:12:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:12:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:12:21 --> Email Class Initialized
INFO - 2016-05-23 14:12:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:12:21 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:12:21 --> Helper loaded: language_helper
INFO - 2016-05-23 14:12:21 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:21 --> Model Class Initialized
INFO - 2016-05-23 14:12:21 --> Helper loaded: date_helper
INFO - 2016-05-23 14:12:21 --> Controller Class Initialized
INFO - 2016-05-23 14:12:21 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:12:21 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:12:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:12:21 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:12:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:12:21 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:12:22 --> Config Class Initialized
INFO - 2016-05-23 14:12:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:12:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:12:22 --> Utf8 Class Initialized
INFO - 2016-05-23 14:12:22 --> URI Class Initialized
INFO - 2016-05-23 14:12:22 --> Router Class Initialized
INFO - 2016-05-23 14:12:22 --> Output Class Initialized
INFO - 2016-05-23 14:12:22 --> Security Class Initialized
DEBUG - 2016-05-23 14:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:12:22 --> CSRF cookie sent
INFO - 2016-05-23 14:12:22 --> Input Class Initialized
INFO - 2016-05-23 14:12:22 --> Language Class Initialized
INFO - 2016-05-23 14:12:22 --> Loader Class Initialized
INFO - 2016-05-23 14:12:22 --> Helper loaded: form_helper
INFO - 2016-05-23 14:12:22 --> Database Driver Class Initialized
INFO - 2016-05-23 14:12:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:12:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:12:22 --> Email Class Initialized
INFO - 2016-05-23 14:12:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:12:22 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:12:22 --> Helper loaded: language_helper
INFO - 2016-05-23 14:12:22 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:12:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:22 --> Model Class Initialized
INFO - 2016-05-23 14:12:22 --> Helper loaded: date_helper
INFO - 2016-05-23 14:12:22 --> Controller Class Initialized
INFO - 2016-05-23 14:12:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:12:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:12:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:12:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:12:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:12:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:12:22 --> Model Class Initialized
INFO - 2016-05-23 14:12:22 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:12:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 14:12:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 14:12:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 14:12:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 14:12:22 --> Final output sent to browser
DEBUG - 2016-05-23 14:12:22 --> Total execution time: 0.0180
INFO - 2016-05-23 14:12:31 --> Config Class Initialized
INFO - 2016-05-23 14:12:31 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:12:31 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:12:31 --> Utf8 Class Initialized
INFO - 2016-05-23 14:12:31 --> URI Class Initialized
INFO - 2016-05-23 14:12:31 --> Router Class Initialized
INFO - 2016-05-23 14:12:31 --> Output Class Initialized
INFO - 2016-05-23 14:12:31 --> Security Class Initialized
DEBUG - 2016-05-23 14:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:12:31 --> CSRF cookie sent
INFO - 2016-05-23 14:12:31 --> Input Class Initialized
INFO - 2016-05-23 14:12:31 --> Language Class Initialized
INFO - 2016-05-23 14:12:31 --> Loader Class Initialized
INFO - 2016-05-23 14:12:31 --> Helper loaded: form_helper
INFO - 2016-05-23 14:12:31 --> Database Driver Class Initialized
INFO - 2016-05-23 14:12:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:12:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:12:31 --> Email Class Initialized
INFO - 2016-05-23 14:12:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:12:31 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:12:31 --> Helper loaded: language_helper
INFO - 2016-05-23 14:12:31 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:12:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:31 --> Model Class Initialized
INFO - 2016-05-23 14:12:31 --> Helper loaded: date_helper
INFO - 2016-05-23 14:12:31 --> Controller Class Initialized
INFO - 2016-05-23 14:12:31 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:12:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:12:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:12:31 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:12:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:12:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:12:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:31 --> Form Validation Class Initialized
INFO - 2016-05-23 14:12:35 --> Config Class Initialized
INFO - 2016-05-23 14:12:35 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:12:35 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:12:35 --> Utf8 Class Initialized
INFO - 2016-05-23 14:12:35 --> URI Class Initialized
INFO - 2016-05-23 14:12:35 --> Router Class Initialized
INFO - 2016-05-23 14:12:35 --> Output Class Initialized
INFO - 2016-05-23 14:12:35 --> Security Class Initialized
DEBUG - 2016-05-23 14:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:12:35 --> CSRF cookie sent
INFO - 2016-05-23 14:12:35 --> Input Class Initialized
INFO - 2016-05-23 14:12:35 --> Language Class Initialized
INFO - 2016-05-23 14:12:35 --> Loader Class Initialized
INFO - 2016-05-23 14:12:35 --> Helper loaded: form_helper
INFO - 2016-05-23 14:12:35 --> Database Driver Class Initialized
INFO - 2016-05-23 14:12:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:12:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:12:35 --> Email Class Initialized
INFO - 2016-05-23 14:12:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:12:35 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:12:35 --> Helper loaded: language_helper
INFO - 2016-05-23 14:12:35 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:35 --> Model Class Initialized
INFO - 2016-05-23 14:12:35 --> Helper loaded: date_helper
INFO - 2016-05-23 14:12:35 --> Controller Class Initialized
INFO - 2016-05-23 14:12:35 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:12:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:12:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:12:35 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:12:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:12:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:12:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:35 --> Form Validation Class Initialized
DEBUG - 2016-05-23 14:12:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:12:35 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:12:35 --> Final output sent to browser
DEBUG - 2016-05-23 14:12:35 --> Total execution time: 0.0356
INFO - 2016-05-23 14:14:15 --> Config Class Initialized
INFO - 2016-05-23 14:14:15 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:14:15 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:14:15 --> Utf8 Class Initialized
INFO - 2016-05-23 14:14:15 --> URI Class Initialized
INFO - 2016-05-23 14:14:15 --> Router Class Initialized
INFO - 2016-05-23 14:14:15 --> Output Class Initialized
INFO - 2016-05-23 14:14:15 --> Security Class Initialized
DEBUG - 2016-05-23 14:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:14:15 --> CSRF cookie sent
INFO - 2016-05-23 14:14:15 --> Input Class Initialized
INFO - 2016-05-23 14:14:15 --> Language Class Initialized
INFO - 2016-05-23 14:14:15 --> Loader Class Initialized
INFO - 2016-05-23 14:14:15 --> Helper loaded: form_helper
INFO - 2016-05-23 14:14:15 --> Database Driver Class Initialized
INFO - 2016-05-23 14:14:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:14:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:14:15 --> Email Class Initialized
INFO - 2016-05-23 14:14:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:14:15 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:14:15 --> Helper loaded: language_helper
INFO - 2016-05-23 14:14:15 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:14:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:14:15 --> Model Class Initialized
INFO - 2016-05-23 14:14:15 --> Helper loaded: date_helper
INFO - 2016-05-23 14:14:15 --> Controller Class Initialized
INFO - 2016-05-23 14:14:15 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:14:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:14:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:14:15 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:14:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:14:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:14:15 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:14:15 --> Form Validation Class Initialized
INFO - 2016-05-23 14:14:15 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:14:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:14:15 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:14:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:14:15 --> Final output sent to browser
DEBUG - 2016-05-23 14:14:15 --> Total execution time: 0.0670
INFO - 2016-05-23 14:14:23 --> Config Class Initialized
INFO - 2016-05-23 14:14:23 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:14:23 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:14:23 --> Utf8 Class Initialized
INFO - 2016-05-23 14:14:23 --> URI Class Initialized
INFO - 2016-05-23 14:14:23 --> Router Class Initialized
INFO - 2016-05-23 14:14:23 --> Output Class Initialized
INFO - 2016-05-23 14:14:23 --> Security Class Initialized
DEBUG - 2016-05-23 14:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:14:23 --> CSRF cookie sent
INFO - 2016-05-23 14:14:23 --> CSRF token verified
INFO - 2016-05-23 14:14:23 --> Input Class Initialized
INFO - 2016-05-23 14:14:23 --> Language Class Initialized
INFO - 2016-05-23 14:14:23 --> Loader Class Initialized
INFO - 2016-05-23 14:14:23 --> Helper loaded: form_helper
INFO - 2016-05-23 14:14:23 --> Database Driver Class Initialized
INFO - 2016-05-23 14:14:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:14:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:14:23 --> Email Class Initialized
INFO - 2016-05-23 14:14:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:14:23 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:14:23 --> Helper loaded: language_helper
INFO - 2016-05-23 14:14:23 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:14:23 --> Model Class Initialized
INFO - 2016-05-23 14:14:23 --> Helper loaded: date_helper
INFO - 2016-05-23 14:14:23 --> Controller Class Initialized
INFO - 2016-05-23 14:14:23 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:14:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:14:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:14:23 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:14:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:14:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:14:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:14:23 --> Form Validation Class Initialized
INFO - 2016-05-23 14:14:48 --> Config Class Initialized
INFO - 2016-05-23 14:14:48 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:14:48 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:14:48 --> Utf8 Class Initialized
INFO - 2016-05-23 14:14:48 --> URI Class Initialized
INFO - 2016-05-23 14:14:48 --> Router Class Initialized
INFO - 2016-05-23 14:14:48 --> Output Class Initialized
INFO - 2016-05-23 14:14:48 --> Security Class Initialized
DEBUG - 2016-05-23 14:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:14:53 --> Config Class Initialized
INFO - 2016-05-23 14:14:53 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:14:53 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:14:53 --> Utf8 Class Initialized
INFO - 2016-05-23 14:14:53 --> URI Class Initialized
INFO - 2016-05-23 14:14:53 --> Router Class Initialized
INFO - 2016-05-23 14:14:53 --> Output Class Initialized
INFO - 2016-05-23 14:14:53 --> Security Class Initialized
DEBUG - 2016-05-23 14:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:14:53 --> CSRF cookie sent
INFO - 2016-05-23 14:14:53 --> Input Class Initialized
INFO - 2016-05-23 14:14:53 --> Language Class Initialized
INFO - 2016-05-23 14:14:53 --> Loader Class Initialized
INFO - 2016-05-23 14:14:53 --> Helper loaded: form_helper
INFO - 2016-05-23 14:14:53 --> Database Driver Class Initialized
INFO - 2016-05-23 14:14:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:14:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:14:53 --> Email Class Initialized
INFO - 2016-05-23 14:14:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:14:53 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:14:53 --> Helper loaded: language_helper
INFO - 2016-05-23 14:14:53 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:14:53 --> Model Class Initialized
INFO - 2016-05-23 14:14:53 --> Helper loaded: date_helper
INFO - 2016-05-23 14:14:53 --> Controller Class Initialized
INFO - 2016-05-23 14:14:53 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:14:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:14:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:14:53 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:14:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:14:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:14:53 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:14:53 --> Form Validation Class Initialized
INFO - 2016-05-23 14:14:53 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:14:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:14:53 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:14:53 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:14:53 --> Final output sent to browser
DEBUG - 2016-05-23 14:14:53 --> Total execution time: 0.0875
INFO - 2016-05-23 14:15:04 --> Config Class Initialized
INFO - 2016-05-23 14:15:04 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:15:04 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:15:04 --> Utf8 Class Initialized
INFO - 2016-05-23 14:15:04 --> URI Class Initialized
INFO - 2016-05-23 14:15:04 --> Router Class Initialized
INFO - 2016-05-23 14:15:04 --> Output Class Initialized
INFO - 2016-05-23 14:15:04 --> Security Class Initialized
DEBUG - 2016-05-23 14:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:15:04 --> CSRF cookie sent
INFO - 2016-05-23 14:15:04 --> CSRF token verified
INFO - 2016-05-23 14:15:04 --> Input Class Initialized
INFO - 2016-05-23 14:15:04 --> Language Class Initialized
INFO - 2016-05-23 14:15:04 --> Loader Class Initialized
INFO - 2016-05-23 14:15:04 --> Helper loaded: form_helper
INFO - 2016-05-23 14:15:04 --> Database Driver Class Initialized
INFO - 2016-05-23 14:15:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:15:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:15:04 --> Email Class Initialized
INFO - 2016-05-23 14:15:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:15:04 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:15:04 --> Helper loaded: language_helper
INFO - 2016-05-23 14:15:04 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:04 --> Model Class Initialized
INFO - 2016-05-23 14:15:04 --> Helper loaded: date_helper
INFO - 2016-05-23 14:15:04 --> Controller Class Initialized
INFO - 2016-05-23 14:15:04 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:15:04 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:15:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:15:04 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:15:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:15:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:15:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:04 --> Form Validation Class Initialized
INFO - 2016-05-23 14:15:20 --> Config Class Initialized
INFO - 2016-05-23 14:15:20 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:15:20 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:15:20 --> Utf8 Class Initialized
INFO - 2016-05-23 14:15:20 --> URI Class Initialized
INFO - 2016-05-23 14:15:20 --> Router Class Initialized
INFO - 2016-05-23 14:15:20 --> Output Class Initialized
INFO - 2016-05-23 14:15:20 --> Security Class Initialized
DEBUG - 2016-05-23 14:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:15:20 --> CSRF cookie sent
INFO - 2016-05-23 14:15:20 --> Input Class Initialized
INFO - 2016-05-23 14:15:20 --> Language Class Initialized
INFO - 2016-05-23 14:15:20 --> Loader Class Initialized
INFO - 2016-05-23 14:15:20 --> Helper loaded: form_helper
INFO - 2016-05-23 14:15:20 --> Database Driver Class Initialized
INFO - 2016-05-23 14:15:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:15:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:15:20 --> Email Class Initialized
INFO - 2016-05-23 14:15:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:15:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:15:20 --> Helper loaded: language_helper
INFO - 2016-05-23 14:15:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:20 --> Model Class Initialized
INFO - 2016-05-23 14:15:20 --> Helper loaded: date_helper
INFO - 2016-05-23 14:15:20 --> Controller Class Initialized
INFO - 2016-05-23 14:15:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:15:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:15:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:15:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:15:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:15:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:15:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:20 --> Form Validation Class Initialized
INFO - 2016-05-23 14:15:20 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:15:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:15:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:15:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:15:20 --> Final output sent to browser
DEBUG - 2016-05-23 14:15:20 --> Total execution time: 0.0568
INFO - 2016-05-23 14:15:30 --> Config Class Initialized
INFO - 2016-05-23 14:15:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:15:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:15:30 --> Utf8 Class Initialized
INFO - 2016-05-23 14:15:30 --> URI Class Initialized
INFO - 2016-05-23 14:15:30 --> Router Class Initialized
INFO - 2016-05-23 14:15:30 --> Output Class Initialized
INFO - 2016-05-23 14:15:30 --> Security Class Initialized
DEBUG - 2016-05-23 14:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:15:30 --> CSRF cookie sent
INFO - 2016-05-23 14:15:30 --> CSRF token verified
INFO - 2016-05-23 14:15:30 --> Input Class Initialized
INFO - 2016-05-23 14:15:30 --> Language Class Initialized
INFO - 2016-05-23 14:15:30 --> Loader Class Initialized
INFO - 2016-05-23 14:15:30 --> Helper loaded: form_helper
INFO - 2016-05-23 14:15:30 --> Database Driver Class Initialized
INFO - 2016-05-23 14:15:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:15:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:15:30 --> Email Class Initialized
INFO - 2016-05-23 14:15:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:15:30 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:15:30 --> Helper loaded: language_helper
INFO - 2016-05-23 14:15:30 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:30 --> Model Class Initialized
INFO - 2016-05-23 14:15:30 --> Helper loaded: date_helper
INFO - 2016-05-23 14:15:30 --> Controller Class Initialized
INFO - 2016-05-23 14:15:30 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:15:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:15:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:15:30 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:15:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:15:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:15:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:30 --> Form Validation Class Initialized
INFO - 2016-05-23 14:15:32 --> Config Class Initialized
INFO - 2016-05-23 14:15:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:15:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:15:32 --> Utf8 Class Initialized
INFO - 2016-05-23 14:15:32 --> URI Class Initialized
DEBUG - 2016-05-23 14:15:32 --> No URI present. Default controller set.
INFO - 2016-05-23 14:15:32 --> Router Class Initialized
INFO - 2016-05-23 14:15:32 --> Output Class Initialized
INFO - 2016-05-23 14:15:32 --> Security Class Initialized
DEBUG - 2016-05-23 14:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:15:32 --> CSRF cookie sent
INFO - 2016-05-23 14:15:32 --> Input Class Initialized
INFO - 2016-05-23 14:15:32 --> Language Class Initialized
INFO - 2016-05-23 14:15:32 --> Loader Class Initialized
INFO - 2016-05-23 14:15:32 --> Helper loaded: form_helper
INFO - 2016-05-23 14:15:32 --> Database Driver Class Initialized
INFO - 2016-05-23 14:15:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:15:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:15:32 --> Email Class Initialized
INFO - 2016-05-23 14:15:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:15:32 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:15:32 --> Helper loaded: language_helper
INFO - 2016-05-23 14:15:32 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:32 --> Model Class Initialized
INFO - 2016-05-23 14:15:32 --> Helper loaded: date_helper
INFO - 2016-05-23 14:15:32 --> Controller Class Initialized
INFO - 2016-05-23 14:15:32 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:15:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:15:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:15:32 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:15:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:15:32 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:15:32 --> Config Class Initialized
INFO - 2016-05-23 14:15:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:15:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:15:32 --> Utf8 Class Initialized
INFO - 2016-05-23 14:15:32 --> URI Class Initialized
INFO - 2016-05-23 14:15:32 --> Router Class Initialized
INFO - 2016-05-23 14:15:32 --> Output Class Initialized
INFO - 2016-05-23 14:15:32 --> Security Class Initialized
DEBUG - 2016-05-23 14:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:15:32 --> CSRF cookie sent
INFO - 2016-05-23 14:15:32 --> Input Class Initialized
INFO - 2016-05-23 14:15:33 --> Language Class Initialized
INFO - 2016-05-23 14:15:33 --> Loader Class Initialized
INFO - 2016-05-23 14:15:33 --> Helper loaded: form_helper
INFO - 2016-05-23 14:15:33 --> Database Driver Class Initialized
INFO - 2016-05-23 14:15:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:15:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:15:33 --> Email Class Initialized
INFO - 2016-05-23 14:15:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:15:33 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:15:33 --> Helper loaded: language_helper
INFO - 2016-05-23 14:15:33 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:33 --> Model Class Initialized
INFO - 2016-05-23 14:15:33 --> Helper loaded: date_helper
INFO - 2016-05-23 14:15:33 --> Controller Class Initialized
INFO - 2016-05-23 14:15:33 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:15:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:15:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:15:33 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:15:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:15:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:15:33 --> Model Class Initialized
INFO - 2016-05-23 14:15:33 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:15:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 14:15:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 14:15:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 14:15:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 14:15:33 --> Final output sent to browser
DEBUG - 2016-05-23 14:15:33 --> Total execution time: 0.0698
INFO - 2016-05-23 14:15:38 --> Config Class Initialized
INFO - 2016-05-23 14:15:38 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:15:38 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:15:38 --> Utf8 Class Initialized
INFO - 2016-05-23 14:15:38 --> URI Class Initialized
INFO - 2016-05-23 14:15:38 --> Router Class Initialized
INFO - 2016-05-23 14:15:38 --> Output Class Initialized
INFO - 2016-05-23 14:15:38 --> Security Class Initialized
DEBUG - 2016-05-23 14:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:15:38 --> CSRF cookie sent
INFO - 2016-05-23 14:15:38 --> Input Class Initialized
INFO - 2016-05-23 14:15:38 --> Language Class Initialized
INFO - 2016-05-23 14:15:38 --> Loader Class Initialized
INFO - 2016-05-23 14:15:38 --> Helper loaded: form_helper
INFO - 2016-05-23 14:15:38 --> Database Driver Class Initialized
INFO - 2016-05-23 14:15:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:15:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:15:38 --> Email Class Initialized
INFO - 2016-05-23 14:15:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:15:38 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:15:38 --> Helper loaded: language_helper
INFO - 2016-05-23 14:15:38 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:15:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:38 --> Model Class Initialized
INFO - 2016-05-23 14:15:38 --> Helper loaded: date_helper
INFO - 2016-05-23 14:15:38 --> Controller Class Initialized
INFO - 2016-05-23 14:15:38 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:15:38 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:15:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:15:38 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:15:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:15:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:15:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:15:38 --> Form Validation Class Initialized
INFO - 2016-05-23 14:15:38 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:15:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 14:15:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 14:15:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:15:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 14:15:38 --> Final output sent to browser
DEBUG - 2016-05-23 14:15:38 --> Total execution time: 0.0314
INFO - 2016-05-23 14:16:30 --> Config Class Initialized
INFO - 2016-05-23 14:16:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:16:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:16:30 --> Utf8 Class Initialized
INFO - 2016-05-23 14:16:30 --> URI Class Initialized
INFO - 2016-05-23 14:16:30 --> Router Class Initialized
INFO - 2016-05-23 14:16:30 --> Output Class Initialized
INFO - 2016-05-23 14:16:30 --> Security Class Initialized
DEBUG - 2016-05-23 14:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:16:30 --> CSRF cookie sent
INFO - 2016-05-23 14:16:30 --> Input Class Initialized
INFO - 2016-05-23 14:16:30 --> Language Class Initialized
INFO - 2016-05-23 14:16:30 --> Loader Class Initialized
INFO - 2016-05-23 14:16:30 --> Helper loaded: form_helper
INFO - 2016-05-23 14:16:30 --> Database Driver Class Initialized
INFO - 2016-05-23 14:16:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:16:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:16:30 --> Email Class Initialized
INFO - 2016-05-23 14:16:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:16:30 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:16:30 --> Helper loaded: language_helper
INFO - 2016-05-23 14:16:30 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:16:30 --> Model Class Initialized
INFO - 2016-05-23 14:16:30 --> Helper loaded: date_helper
INFO - 2016-05-23 14:16:30 --> Controller Class Initialized
INFO - 2016-05-23 14:16:30 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:16:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:16:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:16:30 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:16:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:16:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:16:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:16:30 --> Form Validation Class Initialized
INFO - 2016-05-23 14:16:32 --> Config Class Initialized
INFO - 2016-05-23 14:16:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:16:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:16:32 --> Utf8 Class Initialized
INFO - 2016-05-23 14:16:32 --> URI Class Initialized
INFO - 2016-05-23 14:16:32 --> Router Class Initialized
INFO - 2016-05-23 14:16:32 --> Output Class Initialized
INFO - 2016-05-23 14:16:32 --> Security Class Initialized
DEBUG - 2016-05-23 14:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:16:32 --> CSRF cookie sent
INFO - 2016-05-23 14:16:32 --> Input Class Initialized
INFO - 2016-05-23 14:16:32 --> Language Class Initialized
INFO - 2016-05-23 14:16:32 --> Loader Class Initialized
INFO - 2016-05-23 14:16:32 --> Helper loaded: form_helper
INFO - 2016-05-23 14:16:32 --> Database Driver Class Initialized
INFO - 2016-05-23 14:16:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:16:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:16:32 --> Email Class Initialized
INFO - 2016-05-23 14:16:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:16:32 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:16:32 --> Helper loaded: language_helper
INFO - 2016-05-23 14:16:32 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:16:32 --> Model Class Initialized
INFO - 2016-05-23 14:16:32 --> Helper loaded: date_helper
INFO - 2016-05-23 14:16:32 --> Controller Class Initialized
INFO - 2016-05-23 14:16:32 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:16:32 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:16:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:16:32 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:16:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:16:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:16:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:16:32 --> Form Validation Class Initialized
INFO - 2016-05-23 14:16:32 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:16:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:16:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:16:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:16:32 --> Final output sent to browser
DEBUG - 2016-05-23 14:16:32 --> Total execution time: 0.0253
INFO - 2016-05-23 14:16:46 --> Config Class Initialized
INFO - 2016-05-23 14:16:46 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:16:46 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:16:46 --> Utf8 Class Initialized
INFO - 2016-05-23 14:16:46 --> URI Class Initialized
INFO - 2016-05-23 14:16:46 --> Router Class Initialized
INFO - 2016-05-23 14:16:46 --> Output Class Initialized
INFO - 2016-05-23 14:16:46 --> Security Class Initialized
DEBUG - 2016-05-23 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:16:46 --> CSRF cookie sent
INFO - 2016-05-23 14:16:46 --> CSRF token verified
INFO - 2016-05-23 14:16:46 --> Input Class Initialized
INFO - 2016-05-23 14:16:46 --> Language Class Initialized
INFO - 2016-05-23 14:16:46 --> Loader Class Initialized
INFO - 2016-05-23 14:16:46 --> Helper loaded: form_helper
INFO - 2016-05-23 14:16:46 --> Database Driver Class Initialized
INFO - 2016-05-23 14:16:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:16:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:16:46 --> Email Class Initialized
INFO - 2016-05-23 14:16:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:16:46 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:16:46 --> Helper loaded: language_helper
INFO - 2016-05-23 14:16:46 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:16:46 --> Model Class Initialized
INFO - 2016-05-23 14:16:46 --> Helper loaded: date_helper
INFO - 2016-05-23 14:16:46 --> Controller Class Initialized
INFO - 2016-05-23 14:16:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:16:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:16:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:16:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:16:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:16:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:16:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:16:46 --> Form Validation Class Initialized
INFO - 2016-05-23 14:17:42 --> Config Class Initialized
INFO - 2016-05-23 14:17:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:17:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:17:42 --> Utf8 Class Initialized
INFO - 2016-05-23 14:17:42 --> URI Class Initialized
INFO - 2016-05-23 14:17:42 --> Router Class Initialized
INFO - 2016-05-23 14:17:42 --> Output Class Initialized
INFO - 2016-05-23 14:17:42 --> Security Class Initialized
DEBUG - 2016-05-23 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:17:42 --> CSRF cookie sent
INFO - 2016-05-23 14:17:42 --> Input Class Initialized
INFO - 2016-05-23 14:17:42 --> Language Class Initialized
INFO - 2016-05-23 14:17:42 --> Loader Class Initialized
INFO - 2016-05-23 14:17:42 --> Helper loaded: form_helper
INFO - 2016-05-23 14:17:42 --> Database Driver Class Initialized
INFO - 2016-05-23 14:17:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:17:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:17:42 --> Email Class Initialized
INFO - 2016-05-23 14:17:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:17:42 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:17:42 --> Helper loaded: language_helper
INFO - 2016-05-23 14:17:42 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:17:42 --> Model Class Initialized
INFO - 2016-05-23 14:17:42 --> Helper loaded: date_helper
INFO - 2016-05-23 14:17:42 --> Controller Class Initialized
INFO - 2016-05-23 14:17:42 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:17:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:17:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:17:42 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:17:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:17:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:17:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:17:42 --> Form Validation Class Initialized
INFO - 2016-05-23 14:17:42 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:17:42 --> Final output sent to browser
DEBUG - 2016-05-23 14:17:42 --> Total execution time: 0.0210
INFO - 2016-05-23 14:17:48 --> Config Class Initialized
INFO - 2016-05-23 14:17:48 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:17:48 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:17:48 --> Utf8 Class Initialized
INFO - 2016-05-23 14:17:48 --> URI Class Initialized
INFO - 2016-05-23 14:17:48 --> Router Class Initialized
INFO - 2016-05-23 14:17:48 --> Output Class Initialized
INFO - 2016-05-23 14:17:48 --> Security Class Initialized
DEBUG - 2016-05-23 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:17:48 --> CSRF cookie sent
INFO - 2016-05-23 14:17:48 --> CSRF token verified
INFO - 2016-05-23 14:17:48 --> Input Class Initialized
INFO - 2016-05-23 14:17:48 --> Language Class Initialized
INFO - 2016-05-23 14:17:48 --> Loader Class Initialized
INFO - 2016-05-23 14:17:48 --> Helper loaded: form_helper
INFO - 2016-05-23 14:17:48 --> Database Driver Class Initialized
INFO - 2016-05-23 14:17:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:17:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:17:48 --> Email Class Initialized
INFO - 2016-05-23 14:17:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:17:48 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:17:48 --> Helper loaded: language_helper
INFO - 2016-05-23 14:17:48 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:17:48 --> Model Class Initialized
INFO - 2016-05-23 14:17:48 --> Helper loaded: date_helper
INFO - 2016-05-23 14:17:48 --> Controller Class Initialized
INFO - 2016-05-23 14:17:48 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:17:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:17:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:17:48 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:17:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:17:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:17:48 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:17:48 --> Form Validation Class Initialized
INFO - 2016-05-23 14:19:11 --> Config Class Initialized
INFO - 2016-05-23 14:19:11 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:19:11 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:19:11 --> Utf8 Class Initialized
INFO - 2016-05-23 14:19:11 --> URI Class Initialized
INFO - 2016-05-23 14:19:11 --> Router Class Initialized
INFO - 2016-05-23 14:19:11 --> Output Class Initialized
INFO - 2016-05-23 14:19:11 --> Security Class Initialized
DEBUG - 2016-05-23 14:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:19:11 --> CSRF cookie sent
INFO - 2016-05-23 14:19:11 --> Input Class Initialized
INFO - 2016-05-23 14:19:11 --> Language Class Initialized
INFO - 2016-05-23 14:19:11 --> Loader Class Initialized
INFO - 2016-05-23 14:19:11 --> Helper loaded: form_helper
INFO - 2016-05-23 14:19:11 --> Database Driver Class Initialized
INFO - 2016-05-23 14:19:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:19:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:19:11 --> Email Class Initialized
INFO - 2016-05-23 14:19:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:19:11 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:19:11 --> Helper loaded: language_helper
INFO - 2016-05-23 14:19:11 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:19:11 --> Model Class Initialized
INFO - 2016-05-23 14:19:11 --> Helper loaded: date_helper
INFO - 2016-05-23 14:19:11 --> Controller Class Initialized
INFO - 2016-05-23 14:19:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:19:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:19:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:19:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:19:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:19:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:19:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:19:11 --> Form Validation Class Initialized
INFO - 2016-05-23 14:19:11 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:19:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:19:11 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:19:11 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:19:11 --> Final output sent to browser
DEBUG - 2016-05-23 14:19:11 --> Total execution time: 0.0314
INFO - 2016-05-23 14:19:43 --> Config Class Initialized
INFO - 2016-05-23 14:19:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:19:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:19:43 --> Utf8 Class Initialized
INFO - 2016-05-23 14:19:43 --> URI Class Initialized
INFO - 2016-05-23 14:19:43 --> Router Class Initialized
INFO - 2016-05-23 14:19:43 --> Output Class Initialized
INFO - 2016-05-23 14:19:43 --> Security Class Initialized
DEBUG - 2016-05-23 14:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:19:43 --> CSRF cookie sent
INFO - 2016-05-23 14:19:43 --> CSRF token verified
INFO - 2016-05-23 14:19:43 --> Input Class Initialized
INFO - 2016-05-23 14:19:43 --> Language Class Initialized
INFO - 2016-05-23 14:19:43 --> Loader Class Initialized
INFO - 2016-05-23 14:19:43 --> Helper loaded: form_helper
INFO - 2016-05-23 14:19:43 --> Database Driver Class Initialized
INFO - 2016-05-23 14:19:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:19:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:19:43 --> Email Class Initialized
INFO - 2016-05-23 14:19:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:19:43 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:19:43 --> Helper loaded: language_helper
INFO - 2016-05-23 14:19:43 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:19:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:19:43 --> Model Class Initialized
INFO - 2016-05-23 14:19:43 --> Helper loaded: date_helper
INFO - 2016-05-23 14:19:43 --> Controller Class Initialized
INFO - 2016-05-23 14:19:43 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:19:43 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:19:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:19:43 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:19:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:19:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:19:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:19:43 --> Form Validation Class Initialized
INFO - 2016-05-23 14:21:20 --> Config Class Initialized
INFO - 2016-05-23 14:21:20 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:21:20 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:21:20 --> Utf8 Class Initialized
INFO - 2016-05-23 14:21:20 --> URI Class Initialized
INFO - 2016-05-23 14:21:20 --> Router Class Initialized
INFO - 2016-05-23 14:21:20 --> Output Class Initialized
INFO - 2016-05-23 14:21:20 --> Security Class Initialized
DEBUG - 2016-05-23 14:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:21:20 --> CSRF cookie sent
INFO - 2016-05-23 14:21:20 --> Input Class Initialized
INFO - 2016-05-23 14:21:20 --> Language Class Initialized
INFO - 2016-05-23 14:21:20 --> Loader Class Initialized
INFO - 2016-05-23 14:21:20 --> Helper loaded: form_helper
INFO - 2016-05-23 14:21:20 --> Database Driver Class Initialized
INFO - 2016-05-23 14:21:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:21:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:21:20 --> Email Class Initialized
INFO - 2016-05-23 14:21:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:21:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:21:20 --> Helper loaded: language_helper
INFO - 2016-05-23 14:21:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:21:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:21:20 --> Model Class Initialized
INFO - 2016-05-23 14:21:20 --> Helper loaded: date_helper
INFO - 2016-05-23 14:21:20 --> Controller Class Initialized
INFO - 2016-05-23 14:21:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:21:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:21:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:21:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:21:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:21:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:21:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:21:20 --> Form Validation Class Initialized
INFO - 2016-05-23 14:21:20 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:21:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:21:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:21:20 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:21:20 --> Final output sent to browser
DEBUG - 2016-05-23 14:21:20 --> Total execution time: 0.0455
INFO - 2016-05-23 14:21:57 --> Config Class Initialized
INFO - 2016-05-23 14:21:57 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:21:57 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:21:57 --> Utf8 Class Initialized
INFO - 2016-05-23 14:21:57 --> URI Class Initialized
INFO - 2016-05-23 14:21:57 --> Router Class Initialized
INFO - 2016-05-23 14:21:57 --> Output Class Initialized
INFO - 2016-05-23 14:21:57 --> Security Class Initialized
DEBUG - 2016-05-23 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:21:57 --> CSRF cookie sent
INFO - 2016-05-23 14:21:57 --> Input Class Initialized
INFO - 2016-05-23 14:21:57 --> Language Class Initialized
INFO - 2016-05-23 14:21:57 --> Loader Class Initialized
INFO - 2016-05-23 14:21:57 --> Helper loaded: form_helper
INFO - 2016-05-23 14:21:57 --> Database Driver Class Initialized
INFO - 2016-05-23 14:21:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:21:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:21:57 --> Email Class Initialized
INFO - 2016-05-23 14:21:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:21:57 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:21:57 --> Helper loaded: language_helper
INFO - 2016-05-23 14:21:57 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:21:57 --> Model Class Initialized
INFO - 2016-05-23 14:21:57 --> Helper loaded: date_helper
INFO - 2016-05-23 14:21:57 --> Controller Class Initialized
INFO - 2016-05-23 14:21:57 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:21:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:21:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:21:57 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:21:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:21:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:21:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:21:57 --> Form Validation Class Initialized
INFO - 2016-05-23 14:21:57 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:21:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:21:57 --> Final output sent to browser
DEBUG - 2016-05-23 14:21:57 --> Total execution time: 0.0188
INFO - 2016-05-23 14:23:20 --> Config Class Initialized
INFO - 2016-05-23 14:23:20 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:23:20 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:23:20 --> Utf8 Class Initialized
INFO - 2016-05-23 14:23:20 --> URI Class Initialized
INFO - 2016-05-23 14:23:20 --> Router Class Initialized
INFO - 2016-05-23 14:23:20 --> Output Class Initialized
INFO - 2016-05-23 14:23:20 --> Security Class Initialized
DEBUG - 2016-05-23 14:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:23:20 --> CSRF cookie sent
INFO - 2016-05-23 14:23:20 --> CSRF token verified
INFO - 2016-05-23 14:23:20 --> Input Class Initialized
INFO - 2016-05-23 14:23:20 --> Language Class Initialized
INFO - 2016-05-23 14:23:20 --> Loader Class Initialized
INFO - 2016-05-23 14:23:20 --> Helper loaded: form_helper
INFO - 2016-05-23 14:23:20 --> Database Driver Class Initialized
INFO - 2016-05-23 14:23:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:23:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:23:20 --> Email Class Initialized
INFO - 2016-05-23 14:23:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:23:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:23:20 --> Helper loaded: language_helper
INFO - 2016-05-23 14:23:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:23:20 --> Model Class Initialized
INFO - 2016-05-23 14:23:20 --> Helper loaded: date_helper
INFO - 2016-05-23 14:23:20 --> Controller Class Initialized
INFO - 2016-05-23 14:23:20 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:23:20 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:23:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:23:20 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:23:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:23:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:23:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:23:20 --> Form Validation Class Initialized
INFO - 2016-05-23 14:29:55 --> Config Class Initialized
INFO - 2016-05-23 14:29:55 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:29:55 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:29:55 --> Utf8 Class Initialized
INFO - 2016-05-23 14:29:55 --> URI Class Initialized
INFO - 2016-05-23 14:29:55 --> Router Class Initialized
INFO - 2016-05-23 14:29:55 --> Output Class Initialized
INFO - 2016-05-23 14:29:55 --> Security Class Initialized
DEBUG - 2016-05-23 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:29:55 --> CSRF cookie sent
INFO - 2016-05-23 14:29:55 --> Input Class Initialized
INFO - 2016-05-23 14:29:55 --> Language Class Initialized
INFO - 2016-05-23 14:29:55 --> Loader Class Initialized
INFO - 2016-05-23 14:29:55 --> Helper loaded: form_helper
INFO - 2016-05-23 14:29:55 --> Database Driver Class Initialized
INFO - 2016-05-23 14:29:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:29:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:29:55 --> Email Class Initialized
INFO - 2016-05-23 14:29:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:29:55 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:29:55 --> Helper loaded: language_helper
INFO - 2016-05-23 14:29:55 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:29:55 --> Model Class Initialized
INFO - 2016-05-23 14:29:55 --> Helper loaded: date_helper
INFO - 2016-05-23 14:29:55 --> Controller Class Initialized
DEBUG - 2016-05-23 14:29:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:29:55 --> Form Validation Class Initialized
INFO - 2016-05-23 14:29:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 14:29:56 --> Config Class Initialized
INFO - 2016-05-23 14:29:56 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:29:56 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:29:56 --> Utf8 Class Initialized
INFO - 2016-05-23 14:29:56 --> URI Class Initialized
INFO - 2016-05-23 14:29:56 --> Router Class Initialized
INFO - 2016-05-23 14:29:56 --> Output Class Initialized
INFO - 2016-05-23 14:29:56 --> Security Class Initialized
DEBUG - 2016-05-23 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:29:56 --> CSRF cookie sent
INFO - 2016-05-23 14:29:56 --> Input Class Initialized
INFO - 2016-05-23 14:29:56 --> Language Class Initialized
INFO - 2016-05-23 14:29:56 --> Loader Class Initialized
INFO - 2016-05-23 14:29:56 --> Helper loaded: form_helper
INFO - 2016-05-23 14:29:56 --> Database Driver Class Initialized
INFO - 2016-05-23 14:29:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:29:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:29:56 --> Email Class Initialized
INFO - 2016-05-23 14:29:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:29:56 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:29:56 --> Helper loaded: language_helper
INFO - 2016-05-23 14:29:56 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:29:56 --> Model Class Initialized
INFO - 2016-05-23 14:29:56 --> Helper loaded: date_helper
INFO - 2016-05-23 14:29:56 --> Controller Class Initialized
DEBUG - 2016-05-23 14:29:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:29:56 --> Form Validation Class Initialized
INFO - 2016-05-23 14:29:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 14:32:47 --> Config Class Initialized
INFO - 2016-05-23 14:32:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:32:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:32:47 --> Utf8 Class Initialized
INFO - 2016-05-23 14:32:47 --> URI Class Initialized
INFO - 2016-05-23 14:32:47 --> Router Class Initialized
INFO - 2016-05-23 14:32:47 --> Output Class Initialized
INFO - 2016-05-23 14:32:47 --> Security Class Initialized
DEBUG - 2016-05-23 14:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:32:47 --> CSRF cookie sent
INFO - 2016-05-23 14:32:47 --> Input Class Initialized
INFO - 2016-05-23 14:32:47 --> Language Class Initialized
INFO - 2016-05-23 14:32:47 --> Loader Class Initialized
INFO - 2016-05-23 14:32:47 --> Helper loaded: form_helper
INFO - 2016-05-23 14:32:47 --> Database Driver Class Initialized
INFO - 2016-05-23 14:32:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:32:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:32:47 --> Email Class Initialized
INFO - 2016-05-23 14:32:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:32:47 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:32:47 --> Helper loaded: language_helper
INFO - 2016-05-23 14:32:47 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:32:47 --> Model Class Initialized
INFO - 2016-05-23 14:32:47 --> Helper loaded: date_helper
INFO - 2016-05-23 14:32:47 --> Controller Class Initialized
INFO - 2016-05-23 14:32:47 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:32:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:32:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:32:47 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:32:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:32:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:32:47 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:32:47 --> Form Validation Class Initialized
INFO - 2016-05-23 14:32:47 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:32:47 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:32:47 --> Final output sent to browser
DEBUG - 2016-05-23 14:32:47 --> Total execution time: 0.0447
INFO - 2016-05-23 14:33:00 --> Config Class Initialized
INFO - 2016-05-23 14:33:00 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:33:00 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:33:00 --> Utf8 Class Initialized
INFO - 2016-05-23 14:33:00 --> URI Class Initialized
INFO - 2016-05-23 14:33:00 --> Router Class Initialized
INFO - 2016-05-23 14:33:00 --> Output Class Initialized
INFO - 2016-05-23 14:33:00 --> Security Class Initialized
DEBUG - 2016-05-23 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:33:00 --> CSRF cookie sent
INFO - 2016-05-23 14:33:00 --> CSRF token verified
INFO - 2016-05-23 14:33:00 --> Input Class Initialized
INFO - 2016-05-23 14:33:00 --> Language Class Initialized
INFO - 2016-05-23 14:33:00 --> Loader Class Initialized
INFO - 2016-05-23 14:33:00 --> Helper loaded: form_helper
INFO - 2016-05-23 14:33:00 --> Database Driver Class Initialized
INFO - 2016-05-23 14:33:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:33:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:33:00 --> Email Class Initialized
INFO - 2016-05-23 14:33:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:33:00 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:33:00 --> Helper loaded: language_helper
INFO - 2016-05-23 14:33:00 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:33:00 --> Model Class Initialized
INFO - 2016-05-23 14:33:00 --> Helper loaded: date_helper
INFO - 2016-05-23 14:33:00 --> Controller Class Initialized
INFO - 2016-05-23 14:33:00 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:33:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:33:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:33:00 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:33:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:33:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:33:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:33:00 --> Form Validation Class Initialized
INFO - 2016-05-23 14:33:01 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:33:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:33:01 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:33:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:33:01 --> Final output sent to browser
DEBUG - 2016-05-23 14:33:01 --> Total execution time: 0.7710
INFO - 2016-05-23 14:34:26 --> Config Class Initialized
INFO - 2016-05-23 14:34:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:34:26 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:34:26 --> Utf8 Class Initialized
INFO - 2016-05-23 14:34:26 --> URI Class Initialized
INFO - 2016-05-23 14:34:26 --> Router Class Initialized
INFO - 2016-05-23 14:34:26 --> Output Class Initialized
INFO - 2016-05-23 14:34:26 --> Security Class Initialized
DEBUG - 2016-05-23 14:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:34:26 --> CSRF cookie sent
INFO - 2016-05-23 14:34:26 --> Input Class Initialized
INFO - 2016-05-23 14:34:26 --> Language Class Initialized
INFO - 2016-05-23 14:34:26 --> Loader Class Initialized
INFO - 2016-05-23 14:34:26 --> Helper loaded: form_helper
INFO - 2016-05-23 14:34:26 --> Database Driver Class Initialized
INFO - 2016-05-23 14:34:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:34:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:34:26 --> Email Class Initialized
INFO - 2016-05-23 14:34:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:34:26 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:34:26 --> Helper loaded: language_helper
INFO - 2016-05-23 14:34:26 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:34:26 --> Model Class Initialized
INFO - 2016-05-23 14:34:26 --> Helper loaded: date_helper
INFO - 2016-05-23 14:34:26 --> Controller Class Initialized
INFO - 2016-05-23 14:34:26 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:34:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:34:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:34:26 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:34:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:34:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:34:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:34:26 --> Form Validation Class Initialized
INFO - 2016-05-23 14:34:26 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:34:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:34:26 --> Final output sent to browser
DEBUG - 2016-05-23 14:34:26 --> Total execution time: 0.0222
INFO - 2016-05-23 14:34:40 --> Config Class Initialized
INFO - 2016-05-23 14:34:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:34:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:34:40 --> Utf8 Class Initialized
INFO - 2016-05-23 14:34:40 --> URI Class Initialized
INFO - 2016-05-23 14:34:40 --> Router Class Initialized
INFO - 2016-05-23 14:34:40 --> Output Class Initialized
INFO - 2016-05-23 14:34:40 --> Security Class Initialized
DEBUG - 2016-05-23 14:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:34:40 --> CSRF cookie sent
INFO - 2016-05-23 14:34:40 --> CSRF token verified
INFO - 2016-05-23 14:34:40 --> Input Class Initialized
INFO - 2016-05-23 14:34:40 --> Language Class Initialized
INFO - 2016-05-23 14:34:40 --> Loader Class Initialized
INFO - 2016-05-23 14:34:40 --> Helper loaded: form_helper
INFO - 2016-05-23 14:34:40 --> Database Driver Class Initialized
INFO - 2016-05-23 14:34:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:34:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:34:40 --> Email Class Initialized
INFO - 2016-05-23 14:34:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:34:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:34:40 --> Helper loaded: language_helper
INFO - 2016-05-23 14:34:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:34:40 --> Model Class Initialized
INFO - 2016-05-23 14:34:40 --> Helper loaded: date_helper
INFO - 2016-05-23 14:34:40 --> Controller Class Initialized
INFO - 2016-05-23 14:34:40 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:34:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:34:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:34:40 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:34:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:34:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:34:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:34:40 --> Form Validation Class Initialized
ERROR - 2016-05-23 14:34:41 --> Severity: Notice --> Undefined property: Auth::$CI /home/demis/www/platformadiabet/application/controllers/Auth.php 871
ERROR - 2016-05-23 14:34:41 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/controllers/Auth.php 871
ERROR - 2016-05-23 14:34:41 --> Severity: Error --> Call to a member function line() on null /home/demis/www/platformadiabet/application/controllers/Auth.php 871
INFO - 2016-05-23 14:36:03 --> Config Class Initialized
INFO - 2016-05-23 14:36:03 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:36:03 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:36:03 --> Utf8 Class Initialized
INFO - 2016-05-23 14:36:03 --> URI Class Initialized
INFO - 2016-05-23 14:36:03 --> Router Class Initialized
INFO - 2016-05-23 14:36:03 --> Output Class Initialized
INFO - 2016-05-23 14:36:03 --> Security Class Initialized
DEBUG - 2016-05-23 14:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:36:03 --> CSRF cookie sent
INFO - 2016-05-23 14:36:03 --> Input Class Initialized
INFO - 2016-05-23 14:36:03 --> Language Class Initialized
INFO - 2016-05-23 14:36:03 --> Loader Class Initialized
INFO - 2016-05-23 14:36:03 --> Helper loaded: form_helper
INFO - 2016-05-23 14:36:03 --> Database Driver Class Initialized
INFO - 2016-05-23 14:36:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:36:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:36:03 --> Email Class Initialized
INFO - 2016-05-23 14:36:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:36:03 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:36:03 --> Helper loaded: language_helper
INFO - 2016-05-23 14:36:03 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:36:03 --> Model Class Initialized
INFO - 2016-05-23 14:36:03 --> Helper loaded: date_helper
INFO - 2016-05-23 14:36:03 --> Controller Class Initialized
INFO - 2016-05-23 14:36:03 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:36:03 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:36:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:36:03 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:36:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:36:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:36:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:36:03 --> Form Validation Class Initialized
INFO - 2016-05-23 14:36:03 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:36:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:36:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:36:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:36:03 --> Final output sent to browser
DEBUG - 2016-05-23 14:36:03 --> Total execution time: 0.0371
INFO - 2016-05-23 14:36:35 --> Config Class Initialized
INFO - 2016-05-23 14:36:35 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:36:35 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:36:35 --> Utf8 Class Initialized
INFO - 2016-05-23 14:36:35 --> URI Class Initialized
INFO - 2016-05-23 14:36:35 --> Router Class Initialized
INFO - 2016-05-23 14:36:35 --> Output Class Initialized
INFO - 2016-05-23 14:36:35 --> Security Class Initialized
DEBUG - 2016-05-23 14:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:36:35 --> CSRF cookie sent
INFO - 2016-05-23 14:36:35 --> CSRF token verified
INFO - 2016-05-23 14:36:35 --> Input Class Initialized
INFO - 2016-05-23 14:36:35 --> Language Class Initialized
INFO - 2016-05-23 14:36:35 --> Loader Class Initialized
INFO - 2016-05-23 14:36:35 --> Helper loaded: form_helper
INFO - 2016-05-23 14:36:35 --> Database Driver Class Initialized
INFO - 2016-05-23 14:36:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:36:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:36:35 --> Email Class Initialized
INFO - 2016-05-23 14:36:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:36:35 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:36:35 --> Helper loaded: language_helper
INFO - 2016-05-23 14:36:35 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:36:35 --> Model Class Initialized
INFO - 2016-05-23 14:36:35 --> Helper loaded: date_helper
INFO - 2016-05-23 14:36:35 --> Controller Class Initialized
INFO - 2016-05-23 14:36:35 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:36:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:36:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:36:35 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:36:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:36:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:36:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:36:35 --> Form Validation Class Initialized
INFO - 2016-05-23 14:36:35 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:36:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:36:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:36:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:36:35 --> Final output sent to browser
DEBUG - 2016-05-23 14:36:35 --> Total execution time: 0.2126
INFO - 2016-05-23 14:37:46 --> Config Class Initialized
INFO - 2016-05-23 14:37:46 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:37:46 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:37:46 --> Utf8 Class Initialized
INFO - 2016-05-23 14:37:46 --> URI Class Initialized
INFO - 2016-05-23 14:37:46 --> Router Class Initialized
INFO - 2016-05-23 14:37:46 --> Output Class Initialized
INFO - 2016-05-23 14:37:46 --> Security Class Initialized
DEBUG - 2016-05-23 14:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:37:46 --> CSRF cookie sent
INFO - 2016-05-23 14:37:46 --> Input Class Initialized
INFO - 2016-05-23 14:37:46 --> Language Class Initialized
INFO - 2016-05-23 14:37:46 --> Loader Class Initialized
INFO - 2016-05-23 14:37:46 --> Helper loaded: form_helper
INFO - 2016-05-23 14:37:46 --> Database Driver Class Initialized
INFO - 2016-05-23 14:37:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:37:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:37:46 --> Email Class Initialized
INFO - 2016-05-23 14:37:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:37:46 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:37:46 --> Helper loaded: language_helper
INFO - 2016-05-23 14:37:46 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:37:46 --> Model Class Initialized
INFO - 2016-05-23 14:37:46 --> Helper loaded: date_helper
INFO - 2016-05-23 14:37:46 --> Controller Class Initialized
INFO - 2016-05-23 14:37:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:37:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:37:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:37:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:37:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:37:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:37:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:37:46 --> Form Validation Class Initialized
INFO - 2016-05-23 14:37:46 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:37:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:37:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:37:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:37:46 --> Final output sent to browser
DEBUG - 2016-05-23 14:37:46 --> Total execution time: 0.0285
INFO - 2016-05-23 14:38:57 --> Config Class Initialized
INFO - 2016-05-23 14:38:57 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:38:57 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:38:57 --> Utf8 Class Initialized
INFO - 2016-05-23 14:38:57 --> URI Class Initialized
INFO - 2016-05-23 14:38:57 --> Router Class Initialized
INFO - 2016-05-23 14:38:57 --> Output Class Initialized
INFO - 2016-05-23 14:38:57 --> Security Class Initialized
DEBUG - 2016-05-23 14:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:38:57 --> CSRF cookie sent
INFO - 2016-05-23 14:38:57 --> Input Class Initialized
INFO - 2016-05-23 14:38:57 --> Language Class Initialized
INFO - 2016-05-23 14:38:57 --> Loader Class Initialized
INFO - 2016-05-23 14:38:57 --> Helper loaded: form_helper
INFO - 2016-05-23 14:38:57 --> Database Driver Class Initialized
INFO - 2016-05-23 14:38:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:38:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:38:57 --> Email Class Initialized
INFO - 2016-05-23 14:38:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:38:57 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:38:57 --> Helper loaded: language_helper
INFO - 2016-05-23 14:38:57 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:38:57 --> Model Class Initialized
INFO - 2016-05-23 14:38:57 --> Helper loaded: date_helper
INFO - 2016-05-23 14:38:57 --> Controller Class Initialized
INFO - 2016-05-23 14:38:57 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:38:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:38:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:38:57 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:38:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:38:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:38:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:38:57 --> Form Validation Class Initialized
INFO - 2016-05-23 14:38:57 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:38:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:38:57 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:38:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:38:57 --> Final output sent to browser
DEBUG - 2016-05-23 14:38:57 --> Total execution time: 0.0170
INFO - 2016-05-23 14:39:33 --> Config Class Initialized
INFO - 2016-05-23 14:39:33 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:39:33 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:39:33 --> Utf8 Class Initialized
INFO - 2016-05-23 14:39:33 --> URI Class Initialized
INFO - 2016-05-23 14:39:33 --> Router Class Initialized
INFO - 2016-05-23 14:39:33 --> Output Class Initialized
INFO - 2016-05-23 14:39:33 --> Security Class Initialized
DEBUG - 2016-05-23 14:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:39:33 --> CSRF cookie sent
INFO - 2016-05-23 14:39:33 --> CSRF token verified
INFO - 2016-05-23 14:39:33 --> Input Class Initialized
INFO - 2016-05-23 14:39:33 --> Language Class Initialized
INFO - 2016-05-23 14:39:33 --> Loader Class Initialized
INFO - 2016-05-23 14:39:33 --> Helper loaded: form_helper
INFO - 2016-05-23 14:39:33 --> Database Driver Class Initialized
INFO - 2016-05-23 14:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:39:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:39:33 --> Email Class Initialized
INFO - 2016-05-23 14:39:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:39:33 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:39:33 --> Helper loaded: language_helper
INFO - 2016-05-23 14:39:33 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:39:33 --> Model Class Initialized
INFO - 2016-05-23 14:39:33 --> Helper loaded: date_helper
INFO - 2016-05-23 14:39:33 --> Controller Class Initialized
INFO - 2016-05-23 14:39:33 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:39:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:39:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:39:33 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:39:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:39:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:39:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:39:33 --> Form Validation Class Initialized
INFO - 2016-05-23 14:40:09 --> Config Class Initialized
INFO - 2016-05-23 14:40:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:40:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:40:09 --> Utf8 Class Initialized
INFO - 2016-05-23 14:40:09 --> URI Class Initialized
INFO - 2016-05-23 14:40:09 --> Router Class Initialized
INFO - 2016-05-23 14:40:09 --> Output Class Initialized
INFO - 2016-05-23 14:40:09 --> Security Class Initialized
DEBUG - 2016-05-23 14:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:40:12 --> Config Class Initialized
INFO - 2016-05-23 14:40:12 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:40:12 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:40:12 --> Utf8 Class Initialized
INFO - 2016-05-23 14:40:12 --> URI Class Initialized
INFO - 2016-05-23 14:40:12 --> Router Class Initialized
INFO - 2016-05-23 14:40:12 --> Output Class Initialized
INFO - 2016-05-23 14:40:12 --> Security Class Initialized
DEBUG - 2016-05-23 14:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:40:12 --> CSRF cookie sent
INFO - 2016-05-23 14:40:12 --> Input Class Initialized
INFO - 2016-05-23 14:40:12 --> Language Class Initialized
INFO - 2016-05-23 14:40:12 --> Loader Class Initialized
INFO - 2016-05-23 14:40:12 --> Helper loaded: form_helper
INFO - 2016-05-23 14:40:12 --> Database Driver Class Initialized
INFO - 2016-05-23 14:40:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:40:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:40:12 --> Email Class Initialized
INFO - 2016-05-23 14:40:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:40:12 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:40:12 --> Helper loaded: language_helper
INFO - 2016-05-23 14:40:12 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:40:12 --> Model Class Initialized
INFO - 2016-05-23 14:40:12 --> Helper loaded: date_helper
INFO - 2016-05-23 14:40:12 --> Controller Class Initialized
INFO - 2016-05-23 14:40:12 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:40:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:40:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:40:12 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:40:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:40:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:40:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:40:12 --> Form Validation Class Initialized
INFO - 2016-05-23 14:40:12 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:40:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 14:40:12 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 14:40:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 14:40:12 --> Final output sent to browser
DEBUG - 2016-05-23 14:40:12 --> Total execution time: 0.0807
INFO - 2016-05-23 14:41:09 --> Config Class Initialized
INFO - 2016-05-23 14:41:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:41:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:41:09 --> Utf8 Class Initialized
INFO - 2016-05-23 14:41:09 --> URI Class Initialized
INFO - 2016-05-23 14:41:09 --> Router Class Initialized
INFO - 2016-05-23 14:41:09 --> Output Class Initialized
INFO - 2016-05-23 14:41:09 --> Security Class Initialized
DEBUG - 2016-05-23 14:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:41:09 --> CSRF cookie sent
INFO - 2016-05-23 14:41:09 --> CSRF token verified
INFO - 2016-05-23 14:41:09 --> Input Class Initialized
INFO - 2016-05-23 14:41:09 --> Language Class Initialized
INFO - 2016-05-23 14:41:09 --> Loader Class Initialized
INFO - 2016-05-23 14:41:09 --> Helper loaded: form_helper
INFO - 2016-05-23 14:41:09 --> Database Driver Class Initialized
INFO - 2016-05-23 14:41:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:41:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:41:09 --> Email Class Initialized
INFO - 2016-05-23 14:41:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:41:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:41:09 --> Helper loaded: language_helper
INFO - 2016-05-23 14:41:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:41:09 --> Model Class Initialized
INFO - 2016-05-23 14:41:09 --> Helper loaded: date_helper
INFO - 2016-05-23 14:41:09 --> Controller Class Initialized
INFO - 2016-05-23 14:41:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:41:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:41:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:41:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:41:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:41:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-23 14:41:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:41:09 --> Form Validation Class Initialized
INFO - 2016-05-23 14:41:14 --> Config Class Initialized
INFO - 2016-05-23 14:41:14 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:41:14 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:41:14 --> Utf8 Class Initialized
INFO - 2016-05-23 14:41:14 --> URI Class Initialized
DEBUG - 2016-05-23 14:41:14 --> No URI present. Default controller set.
INFO - 2016-05-23 14:41:14 --> Router Class Initialized
INFO - 2016-05-23 14:41:14 --> Output Class Initialized
INFO - 2016-05-23 14:41:14 --> Security Class Initialized
DEBUG - 2016-05-23 14:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:41:14 --> CSRF cookie sent
INFO - 2016-05-23 14:41:14 --> Input Class Initialized
INFO - 2016-05-23 14:41:14 --> Language Class Initialized
INFO - 2016-05-23 14:41:14 --> Loader Class Initialized
INFO - 2016-05-23 14:41:14 --> Helper loaded: form_helper
INFO - 2016-05-23 14:41:14 --> Database Driver Class Initialized
INFO - 2016-05-23 14:41:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:41:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:41:14 --> Email Class Initialized
INFO - 2016-05-23 14:41:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:41:14 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:41:14 --> Helper loaded: language_helper
INFO - 2016-05-23 14:41:14 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:41:14 --> Model Class Initialized
INFO - 2016-05-23 14:41:14 --> Helper loaded: date_helper
INFO - 2016-05-23 14:41:14 --> Controller Class Initialized
INFO - 2016-05-23 14:41:14 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:41:14 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:41:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:41:14 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:41:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:41:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:41:16 --> Config Class Initialized
INFO - 2016-05-23 14:41:16 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:41:16 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:41:16 --> Utf8 Class Initialized
INFO - 2016-05-23 14:41:16 --> URI Class Initialized
INFO - 2016-05-23 14:41:16 --> Router Class Initialized
INFO - 2016-05-23 14:41:16 --> Output Class Initialized
INFO - 2016-05-23 14:41:16 --> Security Class Initialized
DEBUG - 2016-05-23 14:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:41:16 --> CSRF cookie sent
INFO - 2016-05-23 14:41:16 --> Input Class Initialized
INFO - 2016-05-23 14:41:16 --> Language Class Initialized
INFO - 2016-05-23 14:41:16 --> Loader Class Initialized
INFO - 2016-05-23 14:41:16 --> Helper loaded: form_helper
INFO - 2016-05-23 14:41:16 --> Database Driver Class Initialized
INFO - 2016-05-23 14:41:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:41:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:41:16 --> Email Class Initialized
INFO - 2016-05-23 14:41:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:41:16 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:41:16 --> Helper loaded: language_helper
INFO - 2016-05-23 14:41:16 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:41:16 --> Model Class Initialized
INFO - 2016-05-23 14:41:16 --> Helper loaded: date_helper
INFO - 2016-05-23 14:41:16 --> Controller Class Initialized
INFO - 2016-05-23 14:41:16 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 14:41:16 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 14:41:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 14:41:16 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 14:41:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 14:41:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 14:41:16 --> Model Class Initialized
INFO - 2016-05-23 14:41:16 --> Helper loaded: languages_helper
INFO - 2016-05-23 14:41:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 14:41:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 14:41:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 14:41:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 14:41:16 --> Final output sent to browser
DEBUG - 2016-05-23 14:41:16 --> Total execution time: 0.0484
INFO - 2016-05-23 14:47:29 --> Config Class Initialized
INFO - 2016-05-23 14:47:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:47:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:47:29 --> Utf8 Class Initialized
INFO - 2016-05-23 14:47:29 --> URI Class Initialized
INFO - 2016-05-23 14:47:29 --> Router Class Initialized
INFO - 2016-05-23 14:47:29 --> Output Class Initialized
INFO - 2016-05-23 14:47:29 --> Security Class Initialized
DEBUG - 2016-05-23 14:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:47:29 --> CSRF cookie sent
INFO - 2016-05-23 14:47:29 --> Input Class Initialized
INFO - 2016-05-23 14:47:29 --> Language Class Initialized
INFO - 2016-05-23 14:47:29 --> Loader Class Initialized
INFO - 2016-05-23 14:47:29 --> Helper loaded: form_helper
INFO - 2016-05-23 14:47:29 --> Database Driver Class Initialized
INFO - 2016-05-23 14:47:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:47:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:47:29 --> Email Class Initialized
INFO - 2016-05-23 14:47:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:47:29 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:47:29 --> Helper loaded: language_helper
INFO - 2016-05-23 14:47:29 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:47:29 --> Model Class Initialized
INFO - 2016-05-23 14:47:29 --> Helper loaded: date_helper
INFO - 2016-05-23 14:47:29 --> Controller Class Initialized
DEBUG - 2016-05-23 14:47:29 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:47:29 --> Form Validation Class Initialized
INFO - 2016-05-23 14:47:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 14:47:30 --> Config Class Initialized
INFO - 2016-05-23 14:47:30 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:47:30 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:47:30 --> Utf8 Class Initialized
INFO - 2016-05-23 14:47:30 --> URI Class Initialized
INFO - 2016-05-23 14:47:30 --> Router Class Initialized
INFO - 2016-05-23 14:47:30 --> Output Class Initialized
INFO - 2016-05-23 14:47:30 --> Security Class Initialized
DEBUG - 2016-05-23 14:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:47:30 --> CSRF cookie sent
INFO - 2016-05-23 14:47:30 --> Input Class Initialized
INFO - 2016-05-23 14:47:30 --> Language Class Initialized
INFO - 2016-05-23 14:47:30 --> Loader Class Initialized
INFO - 2016-05-23 14:47:30 --> Helper loaded: form_helper
INFO - 2016-05-23 14:47:30 --> Database Driver Class Initialized
INFO - 2016-05-23 14:47:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:47:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:47:30 --> Email Class Initialized
INFO - 2016-05-23 14:47:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:47:30 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:47:30 --> Helper loaded: language_helper
INFO - 2016-05-23 14:47:30 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:47:30 --> Model Class Initialized
INFO - 2016-05-23 14:47:30 --> Helper loaded: date_helper
INFO - 2016-05-23 14:47:30 --> Controller Class Initialized
DEBUG - 2016-05-23 14:47:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:47:30 --> Form Validation Class Initialized
INFO - 2016-05-23 14:47:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 14:57:19 --> Config Class Initialized
INFO - 2016-05-23 14:57:19 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:57:19 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:57:19 --> Utf8 Class Initialized
INFO - 2016-05-23 14:57:19 --> URI Class Initialized
INFO - 2016-05-23 14:57:19 --> Router Class Initialized
INFO - 2016-05-23 14:57:19 --> Output Class Initialized
INFO - 2016-05-23 14:57:19 --> Security Class Initialized
DEBUG - 2016-05-23 14:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:57:19 --> CSRF cookie sent
INFO - 2016-05-23 14:57:19 --> Input Class Initialized
INFO - 2016-05-23 14:57:19 --> Language Class Initialized
INFO - 2016-05-23 14:57:19 --> Loader Class Initialized
INFO - 2016-05-23 14:57:19 --> Helper loaded: form_helper
INFO - 2016-05-23 14:57:19 --> Database Driver Class Initialized
INFO - 2016-05-23 14:57:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:57:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:57:19 --> Email Class Initialized
INFO - 2016-05-23 14:57:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:57:19 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:57:19 --> Helper loaded: language_helper
INFO - 2016-05-23 14:57:19 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:57:19 --> Model Class Initialized
INFO - 2016-05-23 14:57:19 --> Helper loaded: date_helper
INFO - 2016-05-23 14:57:19 --> Controller Class Initialized
DEBUG - 2016-05-23 14:57:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:57:19 --> Form Validation Class Initialized
INFO - 2016-05-23 14:57:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 14:57:19 --> Config Class Initialized
INFO - 2016-05-23 14:57:19 --> Hooks Class Initialized
DEBUG - 2016-05-23 14:57:19 --> UTF-8 Support Enabled
INFO - 2016-05-23 14:57:19 --> Utf8 Class Initialized
INFO - 2016-05-23 14:57:19 --> URI Class Initialized
INFO - 2016-05-23 14:57:19 --> Router Class Initialized
INFO - 2016-05-23 14:57:19 --> Output Class Initialized
INFO - 2016-05-23 14:57:19 --> Security Class Initialized
DEBUG - 2016-05-23 14:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 14:57:19 --> CSRF cookie sent
INFO - 2016-05-23 14:57:19 --> Input Class Initialized
INFO - 2016-05-23 14:57:19 --> Language Class Initialized
INFO - 2016-05-23 14:57:19 --> Loader Class Initialized
INFO - 2016-05-23 14:57:19 --> Helper loaded: form_helper
INFO - 2016-05-23 14:57:19 --> Database Driver Class Initialized
INFO - 2016-05-23 14:57:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 14:57:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 14:57:19 --> Email Class Initialized
INFO - 2016-05-23 14:57:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 14:57:19 --> Helper loaded: cookie_helper
INFO - 2016-05-23 14:57:19 --> Helper loaded: language_helper
INFO - 2016-05-23 14:57:19 --> Helper loaded: url_helper
DEBUG - 2016-05-23 14:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:57:19 --> Model Class Initialized
INFO - 2016-05-23 14:57:19 --> Helper loaded: date_helper
INFO - 2016-05-23 14:57:19 --> Controller Class Initialized
DEBUG - 2016-05-23 14:57:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 14:57:19 --> Form Validation Class Initialized
INFO - 2016-05-23 14:57:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:22:36 --> Config Class Initialized
INFO - 2016-05-23 15:22:36 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:22:36 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:22:36 --> Utf8 Class Initialized
INFO - 2016-05-23 15:22:36 --> URI Class Initialized
INFO - 2016-05-23 15:22:36 --> Router Class Initialized
INFO - 2016-05-23 15:22:36 --> Output Class Initialized
INFO - 2016-05-23 15:22:36 --> Security Class Initialized
DEBUG - 2016-05-23 15:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:22:36 --> CSRF cookie sent
INFO - 2016-05-23 15:22:36 --> Input Class Initialized
INFO - 2016-05-23 15:22:36 --> Language Class Initialized
INFO - 2016-05-23 15:22:36 --> Loader Class Initialized
INFO - 2016-05-23 15:22:36 --> Helper loaded: form_helper
INFO - 2016-05-23 15:22:36 --> Database Driver Class Initialized
INFO - 2016-05-23 15:22:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:22:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:22:36 --> Email Class Initialized
INFO - 2016-05-23 15:22:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:22:36 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:22:36 --> Helper loaded: language_helper
INFO - 2016-05-23 15:22:36 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:22:36 --> Model Class Initialized
INFO - 2016-05-23 15:22:36 --> Helper loaded: date_helper
INFO - 2016-05-23 15:22:36 --> Controller Class Initialized
INFO - 2016-05-23 15:22:36 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 15:22:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 15:22:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 15:22:36 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 15:22:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 15:22:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 15:22:36 --> Model Class Initialized
INFO - 2016-05-23 15:22:36 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 15:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:22:36 --> Final output sent to browser
DEBUG - 2016-05-23 15:22:36 --> Total execution time: 0.0201
INFO - 2016-05-23 15:23:09 --> Config Class Initialized
INFO - 2016-05-23 15:23:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:23:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:23:09 --> Utf8 Class Initialized
INFO - 2016-05-23 15:23:09 --> URI Class Initialized
INFO - 2016-05-23 15:23:09 --> Router Class Initialized
INFO - 2016-05-23 15:23:09 --> Output Class Initialized
INFO - 2016-05-23 15:23:09 --> Security Class Initialized
DEBUG - 2016-05-23 15:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:23:09 --> CSRF cookie sent
INFO - 2016-05-23 15:23:09 --> Input Class Initialized
INFO - 2016-05-23 15:23:09 --> Language Class Initialized
INFO - 2016-05-23 15:23:09 --> Loader Class Initialized
INFO - 2016-05-23 15:23:09 --> Helper loaded: form_helper
INFO - 2016-05-23 15:23:09 --> Database Driver Class Initialized
INFO - 2016-05-23 15:23:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:23:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:23:09 --> Email Class Initialized
INFO - 2016-05-23 15:23:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:23:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:23:09 --> Helper loaded: language_helper
INFO - 2016-05-23 15:23:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:23:09 --> Model Class Initialized
INFO - 2016-05-23 15:23:09 --> Helper loaded: date_helper
INFO - 2016-05-23 15:23:09 --> Controller Class Initialized
INFO - 2016-05-23 15:23:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 15:23:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 15:23:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 15:23:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 15:23:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 15:23:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 15:23:09 --> Model Class Initialized
INFO - 2016-05-23 15:23:09 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:23:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:23:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:23:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 15:23:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:23:09 --> Final output sent to browser
DEBUG - 2016-05-23 15:23:09 --> Total execution time: 0.0371
INFO - 2016-05-23 15:23:36 --> Config Class Initialized
INFO - 2016-05-23 15:23:36 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:23:36 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:23:36 --> Utf8 Class Initialized
INFO - 2016-05-23 15:23:36 --> URI Class Initialized
INFO - 2016-05-23 15:23:36 --> Router Class Initialized
INFO - 2016-05-23 15:23:36 --> Output Class Initialized
INFO - 2016-05-23 15:23:36 --> Security Class Initialized
DEBUG - 2016-05-23 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:23:36 --> CSRF cookie sent
INFO - 2016-05-23 15:23:36 --> CSRF token verified
INFO - 2016-05-23 15:23:36 --> Input Class Initialized
INFO - 2016-05-23 15:23:36 --> Language Class Initialized
INFO - 2016-05-23 15:23:36 --> Loader Class Initialized
INFO - 2016-05-23 15:23:36 --> Helper loaded: form_helper
INFO - 2016-05-23 15:23:36 --> Database Driver Class Initialized
INFO - 2016-05-23 15:23:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:23:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:23:36 --> Email Class Initialized
INFO - 2016-05-23 15:23:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:23:36 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:23:36 --> Helper loaded: language_helper
INFO - 2016-05-23 15:23:36 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:23:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:23:36 --> Model Class Initialized
INFO - 2016-05-23 15:23:36 --> Helper loaded: date_helper
INFO - 2016-05-23 15:23:36 --> Controller Class Initialized
INFO - 2016-05-23 15:23:36 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 15:23:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 15:23:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 15:23:36 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 15:23:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 15:23:36 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 15:23:37 --> Config Class Initialized
INFO - 2016-05-23 15:23:37 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:23:37 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:23:37 --> Utf8 Class Initialized
INFO - 2016-05-23 15:23:37 --> URI Class Initialized
INFO - 2016-05-23 15:23:37 --> Router Class Initialized
INFO - 2016-05-23 15:23:37 --> Output Class Initialized
INFO - 2016-05-23 15:23:37 --> Security Class Initialized
DEBUG - 2016-05-23 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:23:37 --> CSRF cookie sent
INFO - 2016-05-23 15:23:37 --> Input Class Initialized
INFO - 2016-05-23 15:23:37 --> Language Class Initialized
INFO - 2016-05-23 15:23:37 --> Loader Class Initialized
INFO - 2016-05-23 15:23:37 --> Helper loaded: form_helper
INFO - 2016-05-23 15:23:37 --> Database Driver Class Initialized
INFO - 2016-05-23 15:23:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:23:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:23:37 --> Email Class Initialized
INFO - 2016-05-23 15:23:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:23:37 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:23:37 --> Helper loaded: language_helper
INFO - 2016-05-23 15:23:37 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:23:37 --> Model Class Initialized
INFO - 2016-05-23 15:23:37 --> Helper loaded: date_helper
INFO - 2016-05-23 15:23:37 --> Controller Class Initialized
INFO - 2016-05-23 15:23:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:23:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:23:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:23:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:23:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:23:37 --> Model Class Initialized
INFO - 2016-05-23 15:23:37 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:23:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:23:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:23:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 15:23:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:23:37 --> Final output sent to browser
DEBUG - 2016-05-23 15:23:37 --> Total execution time: 0.0740
INFO - 2016-05-23 15:23:50 --> Config Class Initialized
INFO - 2016-05-23 15:23:50 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:23:50 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:23:50 --> Utf8 Class Initialized
INFO - 2016-05-23 15:23:50 --> URI Class Initialized
INFO - 2016-05-23 15:23:50 --> Router Class Initialized
INFO - 2016-05-23 15:23:50 --> Output Class Initialized
INFO - 2016-05-23 15:23:50 --> Security Class Initialized
DEBUG - 2016-05-23 15:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:23:50 --> CSRF cookie sent
INFO - 2016-05-23 15:23:50 --> Input Class Initialized
INFO - 2016-05-23 15:23:50 --> Language Class Initialized
INFO - 2016-05-23 15:23:50 --> Loader Class Initialized
INFO - 2016-05-23 15:23:50 --> Helper loaded: form_helper
INFO - 2016-05-23 15:23:50 --> Database Driver Class Initialized
INFO - 2016-05-23 15:23:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:23:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:23:50 --> Email Class Initialized
INFO - 2016-05-23 15:23:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:23:50 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:23:50 --> Helper loaded: language_helper
INFO - 2016-05-23 15:23:50 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:23:50 --> Model Class Initialized
INFO - 2016-05-23 15:23:50 --> Helper loaded: date_helper
INFO - 2016-05-23 15:23:50 --> Controller Class Initialized
DEBUG - 2016-05-23 15:23:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:23:50 --> Form Validation Class Initialized
INFO - 2016-05-23 15:23:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:23:58 --> Config Class Initialized
INFO - 2016-05-23 15:23:58 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:23:58 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:23:58 --> Utf8 Class Initialized
INFO - 2016-05-23 15:23:58 --> URI Class Initialized
INFO - 2016-05-23 15:23:58 --> Router Class Initialized
INFO - 2016-05-23 15:23:58 --> Output Class Initialized
INFO - 2016-05-23 15:23:58 --> Security Class Initialized
DEBUG - 2016-05-23 15:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:23:58 --> CSRF cookie sent
INFO - 2016-05-23 15:23:58 --> Input Class Initialized
INFO - 2016-05-23 15:23:58 --> Language Class Initialized
INFO - 2016-05-23 15:23:58 --> Loader Class Initialized
INFO - 2016-05-23 15:23:58 --> Helper loaded: form_helper
INFO - 2016-05-23 15:23:58 --> Database Driver Class Initialized
INFO - 2016-05-23 15:23:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:23:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:23:58 --> Email Class Initialized
INFO - 2016-05-23 15:23:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:23:58 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:23:58 --> Helper loaded: language_helper
INFO - 2016-05-23 15:23:58 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:23:58 --> Model Class Initialized
INFO - 2016-05-23 15:23:58 --> Helper loaded: date_helper
INFO - 2016-05-23 15:23:58 --> Controller Class Initialized
DEBUG - 2016-05-23 15:23:58 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:23:58 --> Form Validation Class Initialized
INFO - 2016-05-23 15:23:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:24:01 --> Config Class Initialized
INFO - 2016-05-23 15:24:01 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:24:01 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:24:01 --> Utf8 Class Initialized
INFO - 2016-05-23 15:24:02 --> URI Class Initialized
INFO - 2016-05-23 15:24:02 --> Router Class Initialized
INFO - 2016-05-23 15:24:02 --> Output Class Initialized
INFO - 2016-05-23 15:24:02 --> Security Class Initialized
DEBUG - 2016-05-23 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:24:02 --> CSRF cookie sent
INFO - 2016-05-23 15:24:02 --> Input Class Initialized
INFO - 2016-05-23 15:24:02 --> Language Class Initialized
INFO - 2016-05-23 15:24:02 --> Loader Class Initialized
INFO - 2016-05-23 15:24:02 --> Helper loaded: form_helper
INFO - 2016-05-23 15:24:02 --> Database Driver Class Initialized
INFO - 2016-05-23 15:24:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:24:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:24:02 --> Email Class Initialized
INFO - 2016-05-23 15:24:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:24:02 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:24:02 --> Helper loaded: language_helper
INFO - 2016-05-23 15:24:02 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:24:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:24:02 --> Model Class Initialized
INFO - 2016-05-23 15:24:02 --> Helper loaded: date_helper
INFO - 2016-05-23 15:24:02 --> Controller Class Initialized
INFO - 2016-05-23 15:24:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:24:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:24:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:24:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:24:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:24:02 --> Model Class Initialized
INFO - 2016-05-23 15:24:02 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 15:24:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:24:02 --> Final output sent to browser
DEBUG - 2016-05-23 15:24:02 --> Total execution time: 0.2013
INFO - 2016-05-23 15:34:38 --> Config Class Initialized
INFO - 2016-05-23 15:34:38 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:34:38 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:34:38 --> Utf8 Class Initialized
INFO - 2016-05-23 15:34:39 --> URI Class Initialized
INFO - 2016-05-23 15:34:39 --> Router Class Initialized
INFO - 2016-05-23 15:34:39 --> Output Class Initialized
INFO - 2016-05-23 15:34:39 --> Security Class Initialized
DEBUG - 2016-05-23 15:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:34:39 --> CSRF cookie sent
INFO - 2016-05-23 15:34:39 --> Input Class Initialized
INFO - 2016-05-23 15:34:39 --> Language Class Initialized
INFO - 2016-05-23 15:34:39 --> Loader Class Initialized
INFO - 2016-05-23 15:34:39 --> Helper loaded: form_helper
INFO - 2016-05-23 15:34:39 --> Database Driver Class Initialized
INFO - 2016-05-23 15:34:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:34:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:34:39 --> Email Class Initialized
INFO - 2016-05-23 15:34:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:34:39 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:34:39 --> Helper loaded: language_helper
INFO - 2016-05-23 15:34:39 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:34:39 --> Model Class Initialized
INFO - 2016-05-23 15:34:39 --> Helper loaded: date_helper
INFO - 2016-05-23 15:34:39 --> Controller Class Initialized
DEBUG - 2016-05-23 15:34:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:34:39 --> Form Validation Class Initialized
INFO - 2016-05-23 15:34:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:34:39 --> Config Class Initialized
INFO - 2016-05-23 15:34:39 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:34:39 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:34:39 --> Utf8 Class Initialized
INFO - 2016-05-23 15:34:39 --> URI Class Initialized
INFO - 2016-05-23 15:34:39 --> Router Class Initialized
INFO - 2016-05-23 15:34:39 --> Output Class Initialized
INFO - 2016-05-23 15:34:39 --> Security Class Initialized
DEBUG - 2016-05-23 15:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:34:39 --> CSRF cookie sent
INFO - 2016-05-23 15:34:39 --> Input Class Initialized
INFO - 2016-05-23 15:34:39 --> Language Class Initialized
INFO - 2016-05-23 15:34:39 --> Loader Class Initialized
INFO - 2016-05-23 15:34:39 --> Helper loaded: form_helper
INFO - 2016-05-23 15:34:39 --> Database Driver Class Initialized
INFO - 2016-05-23 15:34:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:34:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:34:39 --> Email Class Initialized
INFO - 2016-05-23 15:34:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:34:39 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:34:39 --> Helper loaded: language_helper
INFO - 2016-05-23 15:34:39 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:34:39 --> Model Class Initialized
INFO - 2016-05-23 15:34:39 --> Helper loaded: date_helper
INFO - 2016-05-23 15:34:39 --> Controller Class Initialized
DEBUG - 2016-05-23 15:34:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:34:39 --> Form Validation Class Initialized
INFO - 2016-05-23 15:34:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:53:29 --> Config Class Initialized
INFO - 2016-05-23 15:53:29 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:53:29 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:53:29 --> Utf8 Class Initialized
INFO - 2016-05-23 15:53:29 --> URI Class Initialized
INFO - 2016-05-23 15:53:29 --> Router Class Initialized
INFO - 2016-05-23 15:53:29 --> Output Class Initialized
INFO - 2016-05-23 15:53:29 --> Security Class Initialized
DEBUG - 2016-05-23 15:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:53:29 --> CSRF cookie sent
INFO - 2016-05-23 15:53:29 --> Input Class Initialized
INFO - 2016-05-23 15:53:29 --> Language Class Initialized
INFO - 2016-05-23 15:53:29 --> Loader Class Initialized
INFO - 2016-05-23 15:53:29 --> Helper loaded: form_helper
INFO - 2016-05-23 15:53:29 --> Database Driver Class Initialized
INFO - 2016-05-23 15:53:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:53:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:53:29 --> Email Class Initialized
INFO - 2016-05-23 15:53:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:53:29 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:53:29 --> Helper loaded: language_helper
INFO - 2016-05-23 15:53:29 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:53:29 --> Model Class Initialized
INFO - 2016-05-23 15:53:29 --> Helper loaded: date_helper
INFO - 2016-05-23 15:53:29 --> Controller Class Initialized
INFO - 2016-05-23 15:53:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:53:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:53:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:53:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:53:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:53:29 --> Model Class Initialized
INFO - 2016-05-23 15:53:29 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:53:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:53:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:53:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 15:53:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:53:29 --> Final output sent to browser
DEBUG - 2016-05-23 15:53:29 --> Total execution time: 0.0272
INFO - 2016-05-23 15:54:28 --> Config Class Initialized
INFO - 2016-05-23 15:54:28 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:54:28 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:54:28 --> Utf8 Class Initialized
INFO - 2016-05-23 15:54:28 --> URI Class Initialized
INFO - 2016-05-23 15:54:28 --> Router Class Initialized
INFO - 2016-05-23 15:54:28 --> Output Class Initialized
INFO - 2016-05-23 15:54:28 --> Security Class Initialized
DEBUG - 2016-05-23 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:54:28 --> CSRF cookie sent
INFO - 2016-05-23 15:54:28 --> Input Class Initialized
INFO - 2016-05-23 15:54:28 --> Language Class Initialized
INFO - 2016-05-23 15:54:28 --> Loader Class Initialized
INFO - 2016-05-23 15:54:28 --> Helper loaded: form_helper
INFO - 2016-05-23 15:54:28 --> Database Driver Class Initialized
INFO - 2016-05-23 15:54:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:54:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:54:28 --> Email Class Initialized
INFO - 2016-05-23 15:54:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:54:28 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:54:28 --> Helper loaded: language_helper
INFO - 2016-05-23 15:54:28 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:54:28 --> Model Class Initialized
INFO - 2016-05-23 15:54:28 --> Helper loaded: date_helper
INFO - 2016-05-23 15:54:28 --> Controller Class Initialized
INFO - 2016-05-23 15:54:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:54:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:54:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:54:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:54:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:54:28 --> Model Class Initialized
INFO - 2016-05-23 15:54:28 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:54:28 --> Final output sent to browser
DEBUG - 2016-05-23 15:54:28 --> Total execution time: 0.0198
INFO - 2016-05-23 15:56:19 --> Config Class Initialized
INFO - 2016-05-23 15:56:19 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:56:19 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:56:19 --> Utf8 Class Initialized
INFO - 2016-05-23 15:56:19 --> URI Class Initialized
INFO - 2016-05-23 15:56:19 --> Router Class Initialized
INFO - 2016-05-23 15:56:19 --> Output Class Initialized
INFO - 2016-05-23 15:56:19 --> Security Class Initialized
DEBUG - 2016-05-23 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:56:19 --> CSRF cookie sent
INFO - 2016-05-23 15:56:19 --> Input Class Initialized
INFO - 2016-05-23 15:56:19 --> Language Class Initialized
INFO - 2016-05-23 15:56:19 --> Loader Class Initialized
INFO - 2016-05-23 15:56:19 --> Helper loaded: form_helper
INFO - 2016-05-23 15:56:19 --> Database Driver Class Initialized
INFO - 2016-05-23 15:56:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:56:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:56:19 --> Email Class Initialized
INFO - 2016-05-23 15:56:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:56:19 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:56:19 --> Helper loaded: language_helper
INFO - 2016-05-23 15:56:19 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:56:19 --> Model Class Initialized
INFO - 2016-05-23 15:56:19 --> Helper loaded: date_helper
INFO - 2016-05-23 15:56:19 --> Controller Class Initialized
DEBUG - 2016-05-23 15:56:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:56:19 --> Form Validation Class Initialized
INFO - 2016-05-23 15:56:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:56:20 --> Config Class Initialized
INFO - 2016-05-23 15:56:20 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:56:20 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:56:20 --> Utf8 Class Initialized
INFO - 2016-05-23 15:56:20 --> URI Class Initialized
INFO - 2016-05-23 15:56:20 --> Router Class Initialized
INFO - 2016-05-23 15:56:20 --> Output Class Initialized
INFO - 2016-05-23 15:56:20 --> Security Class Initialized
DEBUG - 2016-05-23 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:56:20 --> CSRF cookie sent
INFO - 2016-05-23 15:56:20 --> Input Class Initialized
INFO - 2016-05-23 15:56:20 --> Language Class Initialized
INFO - 2016-05-23 15:56:20 --> Loader Class Initialized
INFO - 2016-05-23 15:56:20 --> Helper loaded: form_helper
INFO - 2016-05-23 15:56:20 --> Database Driver Class Initialized
INFO - 2016-05-23 15:56:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:56:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:56:20 --> Email Class Initialized
INFO - 2016-05-23 15:56:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:56:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:56:20 --> Helper loaded: language_helper
INFO - 2016-05-23 15:56:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:56:20 --> Model Class Initialized
INFO - 2016-05-23 15:56:20 --> Helper loaded: date_helper
INFO - 2016-05-23 15:56:20 --> Controller Class Initialized
DEBUG - 2016-05-23 15:56:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:56:20 --> Form Validation Class Initialized
INFO - 2016-05-23 15:56:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:57:55 --> Config Class Initialized
INFO - 2016-05-23 15:57:55 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:57:55 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:57:55 --> Utf8 Class Initialized
INFO - 2016-05-23 15:57:55 --> URI Class Initialized
INFO - 2016-05-23 15:57:55 --> Router Class Initialized
INFO - 2016-05-23 15:57:55 --> Output Class Initialized
INFO - 2016-05-23 15:57:55 --> Security Class Initialized
DEBUG - 2016-05-23 15:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:57:55 --> CSRF cookie sent
INFO - 2016-05-23 15:57:55 --> Input Class Initialized
INFO - 2016-05-23 15:57:55 --> Language Class Initialized
INFO - 2016-05-23 15:57:55 --> Loader Class Initialized
INFO - 2016-05-23 15:57:55 --> Helper loaded: form_helper
INFO - 2016-05-23 15:57:55 --> Database Driver Class Initialized
INFO - 2016-05-23 15:57:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:57:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:57:55 --> Email Class Initialized
INFO - 2016-05-23 15:57:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:57:55 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:57:55 --> Helper loaded: language_helper
INFO - 2016-05-23 15:57:55 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:57:55 --> Model Class Initialized
INFO - 2016-05-23 15:57:55 --> Helper loaded: date_helper
INFO - 2016-05-23 15:57:55 --> Controller Class Initialized
INFO - 2016-05-23 15:57:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:57:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:57:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:57:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:57:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:57:55 --> Model Class Initialized
INFO - 2016-05-23 15:57:55 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:57:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:57:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:57:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 15:57:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:57:55 --> Final output sent to browser
DEBUG - 2016-05-23 15:57:55 --> Total execution time: 0.0235
INFO - 2016-05-23 15:58:54 --> Config Class Initialized
INFO - 2016-05-23 15:58:54 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:58:54 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:58:54 --> Utf8 Class Initialized
INFO - 2016-05-23 15:58:54 --> URI Class Initialized
DEBUG - 2016-05-23 15:58:54 --> No URI present. Default controller set.
INFO - 2016-05-23 15:58:54 --> Router Class Initialized
INFO - 2016-05-23 15:58:54 --> Output Class Initialized
INFO - 2016-05-23 15:58:54 --> Security Class Initialized
DEBUG - 2016-05-23 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:58:54 --> CSRF cookie sent
INFO - 2016-05-23 15:58:54 --> Input Class Initialized
INFO - 2016-05-23 15:58:54 --> Language Class Initialized
INFO - 2016-05-23 15:58:54 --> Loader Class Initialized
INFO - 2016-05-23 15:58:54 --> Helper loaded: form_helper
INFO - 2016-05-23 15:58:54 --> Database Driver Class Initialized
INFO - 2016-05-23 15:58:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:58:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:58:54 --> Email Class Initialized
INFO - 2016-05-23 15:58:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:58:54 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:58:54 --> Helper loaded: language_helper
INFO - 2016-05-23 15:58:54 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:58:54 --> Model Class Initialized
INFO - 2016-05-23 15:58:54 --> Helper loaded: date_helper
INFO - 2016-05-23 15:58:54 --> Controller Class Initialized
INFO - 2016-05-23 15:58:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:58:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:58:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:58:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:58:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:58:58 --> Config Class Initialized
INFO - 2016-05-23 15:58:58 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:58:58 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:58:58 --> Utf8 Class Initialized
INFO - 2016-05-23 15:58:58 --> URI Class Initialized
INFO - 2016-05-23 15:58:58 --> Router Class Initialized
INFO - 2016-05-23 15:58:58 --> Output Class Initialized
INFO - 2016-05-23 15:58:58 --> Security Class Initialized
DEBUG - 2016-05-23 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:58:58 --> CSRF cookie sent
INFO - 2016-05-23 15:58:58 --> Input Class Initialized
INFO - 2016-05-23 15:58:58 --> Language Class Initialized
INFO - 2016-05-23 15:58:58 --> Loader Class Initialized
INFO - 2016-05-23 15:58:58 --> Helper loaded: form_helper
INFO - 2016-05-23 15:58:58 --> Database Driver Class Initialized
INFO - 2016-05-23 15:58:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:58:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:58:58 --> Email Class Initialized
INFO - 2016-05-23 15:58:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:58:58 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:58:58 --> Helper loaded: language_helper
INFO - 2016-05-23 15:58:58 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:58:58 --> Model Class Initialized
INFO - 2016-05-23 15:58:58 --> Helper loaded: date_helper
INFO - 2016-05-23 15:58:58 --> Controller Class Initialized
INFO - 2016-05-23 15:58:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:58:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:58:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:58:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:58:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:58:58 --> Model Class Initialized
INFO - 2016-05-23 15:58:58 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:58:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:58:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:58:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 15:58:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:58:58 --> Final output sent to browser
DEBUG - 2016-05-23 15:58:58 --> Total execution time: 0.0278
INFO - 2016-05-23 15:59:07 --> Config Class Initialized
INFO - 2016-05-23 15:59:07 --> Hooks Class Initialized
DEBUG - 2016-05-23 15:59:07 --> UTF-8 Support Enabled
INFO - 2016-05-23 15:59:07 --> Utf8 Class Initialized
INFO - 2016-05-23 15:59:07 --> URI Class Initialized
INFO - 2016-05-23 15:59:07 --> Router Class Initialized
INFO - 2016-05-23 15:59:07 --> Output Class Initialized
INFO - 2016-05-23 15:59:07 --> Security Class Initialized
DEBUG - 2016-05-23 15:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 15:59:07 --> CSRF cookie sent
INFO - 2016-05-23 15:59:07 --> Input Class Initialized
INFO - 2016-05-23 15:59:07 --> Language Class Initialized
INFO - 2016-05-23 15:59:07 --> Loader Class Initialized
INFO - 2016-05-23 15:59:07 --> Helper loaded: form_helper
INFO - 2016-05-23 15:59:07 --> Database Driver Class Initialized
INFO - 2016-05-23 15:59:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 15:59:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 15:59:07 --> Email Class Initialized
INFO - 2016-05-23 15:59:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 15:59:07 --> Helper loaded: cookie_helper
INFO - 2016-05-23 15:59:07 --> Helper loaded: language_helper
INFO - 2016-05-23 15:59:07 --> Helper loaded: url_helper
DEBUG - 2016-05-23 15:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 15:59:07 --> Model Class Initialized
INFO - 2016-05-23 15:59:07 --> Helper loaded: date_helper
INFO - 2016-05-23 15:59:07 --> Controller Class Initialized
INFO - 2016-05-23 15:59:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 15:59:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 15:59:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 15:59:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 15:59:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 15:59:07 --> Model Class Initialized
INFO - 2016-05-23 15:59:07 --> Helper loaded: languages_helper
INFO - 2016-05-23 15:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 15:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 15:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 15:59:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 15:59:07 --> Final output sent to browser
DEBUG - 2016-05-23 15:59:07 --> Total execution time: 0.0414
INFO - 2016-05-23 16:02:57 --> Config Class Initialized
INFO - 2016-05-23 16:02:57 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:02:57 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:02:57 --> Utf8 Class Initialized
INFO - 2016-05-23 16:02:57 --> URI Class Initialized
DEBUG - 2016-05-23 16:02:57 --> No URI present. Default controller set.
INFO - 2016-05-23 16:02:57 --> Router Class Initialized
INFO - 2016-05-23 16:02:57 --> Output Class Initialized
INFO - 2016-05-23 16:02:57 --> Security Class Initialized
DEBUG - 2016-05-23 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:02:57 --> CSRF cookie sent
INFO - 2016-05-23 16:02:57 --> Input Class Initialized
INFO - 2016-05-23 16:02:57 --> Language Class Initialized
INFO - 2016-05-23 16:02:57 --> Loader Class Initialized
INFO - 2016-05-23 16:02:57 --> Helper loaded: form_helper
INFO - 2016-05-23 16:02:57 --> Database Driver Class Initialized
INFO - 2016-05-23 16:02:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:02:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:02:57 --> Email Class Initialized
INFO - 2016-05-23 16:02:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:02:57 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:02:57 --> Helper loaded: language_helper
INFO - 2016-05-23 16:02:57 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:02:57 --> Model Class Initialized
INFO - 2016-05-23 16:02:57 --> Helper loaded: date_helper
INFO - 2016-05-23 16:02:57 --> Controller Class Initialized
INFO - 2016-05-23 16:02:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:02:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:02:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:02:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:02:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:02:59 --> Config Class Initialized
INFO - 2016-05-23 16:02:59 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:02:59 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:02:59 --> Utf8 Class Initialized
INFO - 2016-05-23 16:02:59 --> URI Class Initialized
INFO - 2016-05-23 16:02:59 --> Router Class Initialized
INFO - 2016-05-23 16:02:59 --> Output Class Initialized
INFO - 2016-05-23 16:02:59 --> Security Class Initialized
DEBUG - 2016-05-23 16:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:02:59 --> CSRF cookie sent
INFO - 2016-05-23 16:02:59 --> Input Class Initialized
INFO - 2016-05-23 16:02:59 --> Language Class Initialized
INFO - 2016-05-23 16:02:59 --> Loader Class Initialized
INFO - 2016-05-23 16:02:59 --> Helper loaded: form_helper
INFO - 2016-05-23 16:02:59 --> Database Driver Class Initialized
INFO - 2016-05-23 16:02:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:02:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:02:59 --> Email Class Initialized
INFO - 2016-05-23 16:02:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:02:59 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:02:59 --> Helper loaded: language_helper
INFO - 2016-05-23 16:02:59 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:02:59 --> Model Class Initialized
INFO - 2016-05-23 16:02:59 --> Helper loaded: date_helper
INFO - 2016-05-23 16:02:59 --> Controller Class Initialized
INFO - 2016-05-23 16:02:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:02:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:02:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:02:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:02:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:02:59 --> Model Class Initialized
INFO - 2016-05-23 16:02:59 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:02:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:02:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:02:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 16:02:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:02:59 --> Final output sent to browser
DEBUG - 2016-05-23 16:02:59 --> Total execution time: 0.0234
INFO - 2016-05-23 16:03:09 --> Config Class Initialized
INFO - 2016-05-23 16:03:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:03:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:03:09 --> Utf8 Class Initialized
INFO - 2016-05-23 16:03:09 --> URI Class Initialized
INFO - 2016-05-23 16:03:09 --> Router Class Initialized
INFO - 2016-05-23 16:03:09 --> Output Class Initialized
INFO - 2016-05-23 16:03:09 --> Security Class Initialized
DEBUG - 2016-05-23 16:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:03:09 --> CSRF cookie sent
INFO - 2016-05-23 16:03:09 --> Input Class Initialized
INFO - 2016-05-23 16:03:09 --> Language Class Initialized
INFO - 2016-05-23 16:03:09 --> Loader Class Initialized
INFO - 2016-05-23 16:03:09 --> Helper loaded: form_helper
INFO - 2016-05-23 16:03:09 --> Database Driver Class Initialized
INFO - 2016-05-23 16:03:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:03:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:03:09 --> Email Class Initialized
INFO - 2016-05-23 16:03:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:03:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:03:09 --> Helper loaded: language_helper
INFO - 2016-05-23 16:03:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:03:09 --> Model Class Initialized
INFO - 2016-05-23 16:03:09 --> Helper loaded: date_helper
INFO - 2016-05-23 16:03:09 --> Controller Class Initialized
INFO - 2016-05-23 16:03:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:03:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:03:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:03:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:03:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:03:09 --> Model Class Initialized
INFO - 2016-05-23 16:03:40 --> Config Class Initialized
INFO - 2016-05-23 16:03:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:03:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:03:40 --> Utf8 Class Initialized
INFO - 2016-05-23 16:03:40 --> URI Class Initialized
INFO - 2016-05-23 16:03:40 --> Router Class Initialized
INFO - 2016-05-23 16:03:40 --> Output Class Initialized
INFO - 2016-05-23 16:03:40 --> Security Class Initialized
DEBUG - 2016-05-23 16:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:03:40 --> CSRF cookie sent
INFO - 2016-05-23 16:03:40 --> Input Class Initialized
INFO - 2016-05-23 16:03:40 --> Language Class Initialized
INFO - 2016-05-23 16:03:40 --> Loader Class Initialized
INFO - 2016-05-23 16:03:40 --> Helper loaded: form_helper
INFO - 2016-05-23 16:03:40 --> Database Driver Class Initialized
INFO - 2016-05-23 16:03:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:03:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:03:40 --> Email Class Initialized
INFO - 2016-05-23 16:03:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:03:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:03:40 --> Helper loaded: language_helper
INFO - 2016-05-23 16:03:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:03:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:03:40 --> Model Class Initialized
INFO - 2016-05-23 16:03:40 --> Helper loaded: date_helper
INFO - 2016-05-23 16:03:40 --> Controller Class Initialized
INFO - 2016-05-23 16:03:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:03:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:03:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:03:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:03:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:03:40 --> Model Class Initialized
INFO - 2016-05-23 16:04:07 --> Config Class Initialized
INFO - 2016-05-23 16:04:07 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:04:07 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:04:07 --> Utf8 Class Initialized
INFO - 2016-05-23 16:04:07 --> URI Class Initialized
INFO - 2016-05-23 16:04:07 --> Router Class Initialized
INFO - 2016-05-23 16:04:07 --> Output Class Initialized
INFO - 2016-05-23 16:04:07 --> Security Class Initialized
DEBUG - 2016-05-23 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:04:07 --> CSRF cookie sent
INFO - 2016-05-23 16:04:07 --> Input Class Initialized
INFO - 2016-05-23 16:04:07 --> Language Class Initialized
INFO - 2016-05-23 16:04:07 --> Loader Class Initialized
INFO - 2016-05-23 16:04:07 --> Helper loaded: form_helper
INFO - 2016-05-23 16:04:07 --> Database Driver Class Initialized
INFO - 2016-05-23 16:04:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:04:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:04:07 --> Email Class Initialized
INFO - 2016-05-23 16:04:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:04:07 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:04:07 --> Helper loaded: language_helper
INFO - 2016-05-23 16:04:07 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:04:07 --> Model Class Initialized
INFO - 2016-05-23 16:04:07 --> Helper loaded: date_helper
INFO - 2016-05-23 16:04:07 --> Controller Class Initialized
INFO - 2016-05-23 16:04:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:04:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:04:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:04:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:04:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:04:07 --> Model Class Initialized
INFO - 2016-05-23 16:05:15 --> Config Class Initialized
INFO - 2016-05-23 16:05:15 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:05:15 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:05:15 --> Utf8 Class Initialized
INFO - 2016-05-23 16:05:15 --> URI Class Initialized
INFO - 2016-05-23 16:05:15 --> Router Class Initialized
INFO - 2016-05-23 16:05:15 --> Output Class Initialized
INFO - 2016-05-23 16:05:15 --> Security Class Initialized
DEBUG - 2016-05-23 16:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:05:15 --> CSRF cookie sent
INFO - 2016-05-23 16:05:15 --> Input Class Initialized
INFO - 2016-05-23 16:05:15 --> Language Class Initialized
INFO - 2016-05-23 16:05:15 --> Loader Class Initialized
INFO - 2016-05-23 16:05:15 --> Helper loaded: form_helper
INFO - 2016-05-23 16:05:15 --> Database Driver Class Initialized
INFO - 2016-05-23 16:05:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:05:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:05:15 --> Email Class Initialized
INFO - 2016-05-23 16:05:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:05:15 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:05:15 --> Helper loaded: language_helper
INFO - 2016-05-23 16:05:15 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:05:15 --> Model Class Initialized
INFO - 2016-05-23 16:05:15 --> Helper loaded: date_helper
INFO - 2016-05-23 16:05:15 --> Controller Class Initialized
INFO - 2016-05-23 16:05:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:05:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:05:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:05:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:05:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:05:15 --> Model Class Initialized
INFO - 2016-05-23 16:05:44 --> Config Class Initialized
INFO - 2016-05-23 16:05:44 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:05:44 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:05:44 --> Utf8 Class Initialized
INFO - 2016-05-23 16:05:44 --> URI Class Initialized
INFO - 2016-05-23 16:05:44 --> Router Class Initialized
INFO - 2016-05-23 16:05:44 --> Output Class Initialized
INFO - 2016-05-23 16:05:44 --> Security Class Initialized
DEBUG - 2016-05-23 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:05:44 --> CSRF cookie sent
INFO - 2016-05-23 16:05:44 --> Input Class Initialized
INFO - 2016-05-23 16:05:44 --> Language Class Initialized
INFO - 2016-05-23 16:05:44 --> Loader Class Initialized
INFO - 2016-05-23 16:05:44 --> Helper loaded: form_helper
INFO - 2016-05-23 16:05:44 --> Database Driver Class Initialized
INFO - 2016-05-23 16:05:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:05:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:05:44 --> Email Class Initialized
INFO - 2016-05-23 16:05:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:05:44 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:05:44 --> Helper loaded: language_helper
INFO - 2016-05-23 16:05:44 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:05:44 --> Model Class Initialized
INFO - 2016-05-23 16:05:44 --> Helper loaded: date_helper
INFO - 2016-05-23 16:05:44 --> Controller Class Initialized
INFO - 2016-05-23 16:05:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:05:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:05:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:05:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:05:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:05:44 --> Model Class Initialized
INFO - 2016-05-23 16:05:59 --> Config Class Initialized
INFO - 2016-05-23 16:05:59 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:05:59 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:05:59 --> Utf8 Class Initialized
INFO - 2016-05-23 16:05:59 --> URI Class Initialized
INFO - 2016-05-23 16:05:59 --> Router Class Initialized
INFO - 2016-05-23 16:05:59 --> Output Class Initialized
INFO - 2016-05-23 16:05:59 --> Security Class Initialized
DEBUG - 2016-05-23 16:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:05:59 --> CSRF cookie sent
INFO - 2016-05-23 16:05:59 --> Input Class Initialized
INFO - 2016-05-23 16:05:59 --> Language Class Initialized
INFO - 2016-05-23 16:05:59 --> Loader Class Initialized
INFO - 2016-05-23 16:05:59 --> Helper loaded: form_helper
INFO - 2016-05-23 16:05:59 --> Database Driver Class Initialized
INFO - 2016-05-23 16:05:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:05:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:05:59 --> Email Class Initialized
INFO - 2016-05-23 16:05:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:05:59 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:05:59 --> Helper loaded: language_helper
INFO - 2016-05-23 16:05:59 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:05:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:05:59 --> Model Class Initialized
INFO - 2016-05-23 16:05:59 --> Helper loaded: date_helper
INFO - 2016-05-23 16:05:59 --> Controller Class Initialized
INFO - 2016-05-23 16:05:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:05:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:05:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:05:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:05:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:05:59 --> Model Class Initialized
INFO - 2016-05-23 16:05:59 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 16:05:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:05:59 --> Final output sent to browser
DEBUG - 2016-05-23 16:05:59 --> Total execution time: 0.1095
INFO - 2016-05-23 16:17:47 --> Config Class Initialized
INFO - 2016-05-23 16:17:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:17:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:17:47 --> Utf8 Class Initialized
INFO - 2016-05-23 16:17:47 --> URI Class Initialized
INFO - 2016-05-23 16:17:47 --> Router Class Initialized
INFO - 2016-05-23 16:17:47 --> Output Class Initialized
INFO - 2016-05-23 16:17:47 --> Security Class Initialized
DEBUG - 2016-05-23 16:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:17:47 --> CSRF cookie sent
INFO - 2016-05-23 16:17:47 --> Input Class Initialized
INFO - 2016-05-23 16:17:47 --> Language Class Initialized
INFO - 2016-05-23 16:17:47 --> Loader Class Initialized
INFO - 2016-05-23 16:17:47 --> Helper loaded: form_helper
INFO - 2016-05-23 16:17:47 --> Database Driver Class Initialized
INFO - 2016-05-23 16:17:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:17:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:17:47 --> Email Class Initialized
INFO - 2016-05-23 16:17:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:17:47 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:17:47 --> Helper loaded: language_helper
INFO - 2016-05-23 16:17:47 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:17:47 --> Model Class Initialized
INFO - 2016-05-23 16:17:47 --> Helper loaded: date_helper
INFO - 2016-05-23 16:17:47 --> Controller Class Initialized
DEBUG - 2016-05-23 16:17:47 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:17:47 --> Form Validation Class Initialized
INFO - 2016-05-23 16:17:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:17:48 --> Config Class Initialized
INFO - 2016-05-23 16:17:48 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:17:48 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:17:48 --> Utf8 Class Initialized
INFO - 2016-05-23 16:17:48 --> URI Class Initialized
INFO - 2016-05-23 16:17:48 --> Router Class Initialized
INFO - 2016-05-23 16:17:48 --> Output Class Initialized
INFO - 2016-05-23 16:17:48 --> Security Class Initialized
DEBUG - 2016-05-23 16:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:17:48 --> CSRF cookie sent
INFO - 2016-05-23 16:17:48 --> Input Class Initialized
INFO - 2016-05-23 16:17:48 --> Language Class Initialized
INFO - 2016-05-23 16:17:48 --> Loader Class Initialized
INFO - 2016-05-23 16:17:48 --> Helper loaded: form_helper
INFO - 2016-05-23 16:17:48 --> Database Driver Class Initialized
INFO - 2016-05-23 16:17:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:17:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:17:48 --> Email Class Initialized
INFO - 2016-05-23 16:17:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:17:48 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:17:48 --> Helper loaded: language_helper
INFO - 2016-05-23 16:17:48 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:17:48 --> Model Class Initialized
INFO - 2016-05-23 16:17:48 --> Helper loaded: date_helper
INFO - 2016-05-23 16:17:48 --> Controller Class Initialized
DEBUG - 2016-05-23 16:17:48 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:17:48 --> Form Validation Class Initialized
INFO - 2016-05-23 16:17:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:18:38 --> Config Class Initialized
INFO - 2016-05-23 16:18:38 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:18:38 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:18:38 --> Utf8 Class Initialized
INFO - 2016-05-23 16:18:38 --> URI Class Initialized
INFO - 2016-05-23 16:18:38 --> Router Class Initialized
INFO - 2016-05-23 16:18:38 --> Output Class Initialized
INFO - 2016-05-23 16:18:38 --> Security Class Initialized
DEBUG - 2016-05-23 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:18:38 --> CSRF cookie sent
INFO - 2016-05-23 16:18:38 --> Input Class Initialized
INFO - 2016-05-23 16:18:38 --> Language Class Initialized
INFO - 2016-05-23 16:18:38 --> Loader Class Initialized
INFO - 2016-05-23 16:18:38 --> Helper loaded: form_helper
INFO - 2016-05-23 16:18:38 --> Database Driver Class Initialized
INFO - 2016-05-23 16:18:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:18:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:18:38 --> Email Class Initialized
INFO - 2016-05-23 16:18:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:18:38 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:18:38 --> Helper loaded: language_helper
INFO - 2016-05-23 16:18:38 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:18:38 --> Model Class Initialized
INFO - 2016-05-23 16:18:38 --> Helper loaded: date_helper
INFO - 2016-05-23 16:18:38 --> Controller Class Initialized
INFO - 2016-05-23 16:18:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:18:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:18:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:18:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:18:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 16:18:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:18:38 --> Form Validation Class Initialized
INFO - 2016-05-23 16:18:43 --> Config Class Initialized
INFO - 2016-05-23 16:18:43 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:18:43 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:18:43 --> Utf8 Class Initialized
INFO - 2016-05-23 16:18:43 --> URI Class Initialized
INFO - 2016-05-23 16:18:43 --> Router Class Initialized
INFO - 2016-05-23 16:18:43 --> Output Class Initialized
INFO - 2016-05-23 16:18:43 --> Security Class Initialized
DEBUG - 2016-05-23 16:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:18:43 --> CSRF cookie sent
INFO - 2016-05-23 16:18:43 --> Input Class Initialized
INFO - 2016-05-23 16:18:43 --> Language Class Initialized
INFO - 2016-05-23 16:18:43 --> Loader Class Initialized
INFO - 2016-05-23 16:18:43 --> Helper loaded: form_helper
INFO - 2016-05-23 16:18:43 --> Database Driver Class Initialized
INFO - 2016-05-23 16:18:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:18:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:18:43 --> Email Class Initialized
INFO - 2016-05-23 16:18:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:18:43 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:18:43 --> Helper loaded: language_helper
INFO - 2016-05-23 16:18:43 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:18:43 --> Model Class Initialized
INFO - 2016-05-23 16:18:43 --> Helper loaded: date_helper
INFO - 2016-05-23 16:18:43 --> Controller Class Initialized
INFO - 2016-05-23 16:18:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:18:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:18:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:18:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:18:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 16:18:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:18:43 --> Form Validation Class Initialized
INFO - 2016-05-23 16:18:43 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 16:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 16:18:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 16:18:43 --> Final output sent to browser
DEBUG - 2016-05-23 16:18:43 --> Total execution time: 0.0188
INFO - 2016-05-23 16:18:51 --> Config Class Initialized
INFO - 2016-05-23 16:18:51 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:18:51 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:18:51 --> Utf8 Class Initialized
INFO - 2016-05-23 16:18:51 --> URI Class Initialized
DEBUG - 2016-05-23 16:18:51 --> No URI present. Default controller set.
INFO - 2016-05-23 16:18:51 --> Router Class Initialized
INFO - 2016-05-23 16:18:51 --> Output Class Initialized
INFO - 2016-05-23 16:18:51 --> Security Class Initialized
DEBUG - 2016-05-23 16:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:18:51 --> CSRF cookie sent
INFO - 2016-05-23 16:18:51 --> Input Class Initialized
INFO - 2016-05-23 16:18:51 --> Language Class Initialized
INFO - 2016-05-23 16:18:51 --> Loader Class Initialized
INFO - 2016-05-23 16:18:51 --> Helper loaded: form_helper
INFO - 2016-05-23 16:18:51 --> Database Driver Class Initialized
INFO - 2016-05-23 16:18:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:18:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:18:51 --> Email Class Initialized
INFO - 2016-05-23 16:18:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:18:51 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:18:51 --> Helper loaded: language_helper
INFO - 2016-05-23 16:18:51 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:18:51 --> Model Class Initialized
INFO - 2016-05-23 16:18:51 --> Helper loaded: date_helper
INFO - 2016-05-23 16:18:51 --> Controller Class Initialized
INFO - 2016-05-23 16:18:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:18:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:18:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:18:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:18:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:18:51 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:18:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 16:18:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-23 16:18:51 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 16:18:51 --> Final output sent to browser
DEBUG - 2016-05-23 16:18:51 --> Total execution time: 0.0166
INFO - 2016-05-23 16:21:33 --> Config Class Initialized
INFO - 2016-05-23 16:21:33 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:21:33 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:21:33 --> Utf8 Class Initialized
INFO - 2016-05-23 16:21:33 --> URI Class Initialized
INFO - 2016-05-23 16:21:33 --> Router Class Initialized
INFO - 2016-05-23 16:21:33 --> Output Class Initialized
INFO - 2016-05-23 16:21:33 --> Security Class Initialized
DEBUG - 2016-05-23 16:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:21:33 --> CSRF cookie sent
INFO - 2016-05-23 16:21:33 --> Input Class Initialized
INFO - 2016-05-23 16:21:33 --> Language Class Initialized
INFO - 2016-05-23 16:21:33 --> Loader Class Initialized
INFO - 2016-05-23 16:21:33 --> Helper loaded: form_helper
INFO - 2016-05-23 16:21:33 --> Database Driver Class Initialized
INFO - 2016-05-23 16:21:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:21:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:21:33 --> Email Class Initialized
INFO - 2016-05-23 16:21:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:21:33 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:21:33 --> Helper loaded: language_helper
INFO - 2016-05-23 16:21:33 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:21:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:21:33 --> Model Class Initialized
INFO - 2016-05-23 16:21:33 --> Helper loaded: date_helper
INFO - 2016-05-23 16:21:33 --> Controller Class Initialized
INFO - 2016-05-23 16:21:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:21:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:21:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:21:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:21:33 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 16:21:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:21:33 --> Form Validation Class Initialized
INFO - 2016-05-23 16:21:33 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:21:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-23 16:21:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-23 16:21:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-23 16:21:33 --> Final output sent to browser
DEBUG - 2016-05-23 16:21:33 --> Total execution time: 0.0683
INFO - 2016-05-23 16:22:26 --> Config Class Initialized
INFO - 2016-05-23 16:22:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:22:26 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:22:26 --> Utf8 Class Initialized
INFO - 2016-05-23 16:22:26 --> URI Class Initialized
INFO - 2016-05-23 16:22:26 --> Router Class Initialized
INFO - 2016-05-23 16:22:26 --> Output Class Initialized
INFO - 2016-05-23 16:22:26 --> Security Class Initialized
DEBUG - 2016-05-23 16:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:22:26 --> CSRF cookie sent
INFO - 2016-05-23 16:22:26 --> CSRF token verified
INFO - 2016-05-23 16:22:26 --> Input Class Initialized
INFO - 2016-05-23 16:22:26 --> Language Class Initialized
INFO - 2016-05-23 16:22:26 --> Loader Class Initialized
INFO - 2016-05-23 16:22:26 --> Helper loaded: form_helper
INFO - 2016-05-23 16:22:26 --> Database Driver Class Initialized
INFO - 2016-05-23 16:22:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:22:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:22:26 --> Email Class Initialized
INFO - 2016-05-23 16:22:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:22:26 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:22:26 --> Helper loaded: language_helper
INFO - 2016-05-23 16:22:26 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:22:26 --> Model Class Initialized
INFO - 2016-05-23 16:22:26 --> Helper loaded: date_helper
INFO - 2016-05-23 16:22:26 --> Controller Class Initialized
INFO - 2016-05-23 16:22:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:22:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:22:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:22:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:22:26 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-23 16:22:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:22:26 --> Form Validation Class Initialized
INFO - 2016-05-23 16:22:32 --> Config Class Initialized
INFO - 2016-05-23 16:22:32 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:22:32 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:22:32 --> Utf8 Class Initialized
INFO - 2016-05-23 16:22:32 --> URI Class Initialized
DEBUG - 2016-05-23 16:22:32 --> No URI present. Default controller set.
INFO - 2016-05-23 16:22:32 --> Router Class Initialized
INFO - 2016-05-23 16:22:32 --> Output Class Initialized
INFO - 2016-05-23 16:22:32 --> Security Class Initialized
DEBUG - 2016-05-23 16:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:22:32 --> CSRF cookie sent
INFO - 2016-05-23 16:22:32 --> Input Class Initialized
INFO - 2016-05-23 16:22:32 --> Language Class Initialized
INFO - 2016-05-23 16:22:32 --> Loader Class Initialized
INFO - 2016-05-23 16:22:32 --> Helper loaded: form_helper
INFO - 2016-05-23 16:22:32 --> Database Driver Class Initialized
INFO - 2016-05-23 16:22:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:22:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:22:32 --> Email Class Initialized
INFO - 2016-05-23 16:22:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:22:32 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:22:32 --> Helper loaded: language_helper
INFO - 2016-05-23 16:22:32 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:22:32 --> Model Class Initialized
INFO - 2016-05-23 16:22:32 --> Helper loaded: date_helper
INFO - 2016-05-23 16:22:32 --> Controller Class Initialized
INFO - 2016-05-23 16:22:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:22:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:22:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:22:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:22:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:22:33 --> Config Class Initialized
INFO - 2016-05-23 16:22:33 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:22:33 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:22:33 --> Utf8 Class Initialized
INFO - 2016-05-23 16:22:33 --> URI Class Initialized
INFO - 2016-05-23 16:22:33 --> Router Class Initialized
INFO - 2016-05-23 16:22:33 --> Output Class Initialized
INFO - 2016-05-23 16:22:33 --> Security Class Initialized
DEBUG - 2016-05-23 16:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:22:33 --> CSRF cookie sent
INFO - 2016-05-23 16:22:33 --> Input Class Initialized
INFO - 2016-05-23 16:22:33 --> Language Class Initialized
INFO - 2016-05-23 16:22:33 --> Loader Class Initialized
INFO - 2016-05-23 16:22:33 --> Helper loaded: form_helper
INFO - 2016-05-23 16:22:33 --> Database Driver Class Initialized
INFO - 2016-05-23 16:22:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:22:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:22:33 --> Email Class Initialized
INFO - 2016-05-23 16:22:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:22:33 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:22:33 --> Helper loaded: language_helper
INFO - 2016-05-23 16:22:33 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:22:33 --> Model Class Initialized
INFO - 2016-05-23 16:22:33 --> Helper loaded: date_helper
INFO - 2016-05-23 16:22:33 --> Controller Class Initialized
INFO - 2016-05-23 16:22:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:22:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:22:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:22:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:22:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:22:33 --> Model Class Initialized
INFO - 2016-05-23 16:22:33 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 16:22:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:22:33 --> Final output sent to browser
DEBUG - 2016-05-23 16:22:33 --> Total execution time: 0.0530
INFO - 2016-05-23 16:33:38 --> Config Class Initialized
INFO - 2016-05-23 16:33:38 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:33:38 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:33:38 --> Utf8 Class Initialized
INFO - 2016-05-23 16:33:38 --> URI Class Initialized
INFO - 2016-05-23 16:33:38 --> Router Class Initialized
INFO - 2016-05-23 16:33:38 --> Output Class Initialized
INFO - 2016-05-23 16:33:38 --> Security Class Initialized
DEBUG - 2016-05-23 16:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:33:38 --> CSRF cookie sent
INFO - 2016-05-23 16:33:38 --> Input Class Initialized
INFO - 2016-05-23 16:33:38 --> Language Class Initialized
INFO - 2016-05-23 16:33:38 --> Loader Class Initialized
INFO - 2016-05-23 16:33:38 --> Helper loaded: form_helper
INFO - 2016-05-23 16:33:38 --> Database Driver Class Initialized
INFO - 2016-05-23 16:33:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:33:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:33:38 --> Email Class Initialized
INFO - 2016-05-23 16:33:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:33:38 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:33:38 --> Helper loaded: language_helper
INFO - 2016-05-23 16:33:38 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:33:38 --> Model Class Initialized
INFO - 2016-05-23 16:33:38 --> Helper loaded: date_helper
INFO - 2016-05-23 16:33:38 --> Controller Class Initialized
INFO - 2016-05-23 16:33:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:33:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:33:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:33:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:33:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:33:38 --> Model Class Initialized
INFO - 2016-05-23 16:33:38 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:33:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:33:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:33:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 16:33:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:33:38 --> Final output sent to browser
DEBUG - 2016-05-23 16:33:38 --> Total execution time: 0.0558
INFO - 2016-05-23 16:36:45 --> Config Class Initialized
INFO - 2016-05-23 16:36:45 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:36:45 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:36:45 --> Utf8 Class Initialized
INFO - 2016-05-23 16:36:45 --> URI Class Initialized
INFO - 2016-05-23 16:36:45 --> Router Class Initialized
INFO - 2016-05-23 16:36:45 --> Output Class Initialized
INFO - 2016-05-23 16:36:45 --> Security Class Initialized
DEBUG - 2016-05-23 16:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:36:45 --> CSRF cookie sent
INFO - 2016-05-23 16:36:45 --> Input Class Initialized
INFO - 2016-05-23 16:36:45 --> Language Class Initialized
INFO - 2016-05-23 16:36:45 --> Loader Class Initialized
INFO - 2016-05-23 16:36:45 --> Helper loaded: form_helper
INFO - 2016-05-23 16:36:45 --> Database Driver Class Initialized
INFO - 2016-05-23 16:36:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:36:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:36:45 --> Email Class Initialized
INFO - 2016-05-23 16:36:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:36:45 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:36:45 --> Helper loaded: language_helper
INFO - 2016-05-23 16:36:45 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:36:45 --> Model Class Initialized
INFO - 2016-05-23 16:36:45 --> Helper loaded: date_helper
INFO - 2016-05-23 16:36:45 --> Controller Class Initialized
INFO - 2016-05-23 16:36:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:36:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:36:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:36:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:36:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:36:45 --> Model Class Initialized
INFO - 2016-05-23 16:36:45 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 16:36:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:36:45 --> Final output sent to browser
DEBUG - 2016-05-23 16:36:45 --> Total execution time: 0.0980
INFO - 2016-05-23 16:37:19 --> Config Class Initialized
INFO - 2016-05-23 16:37:19 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:37:19 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:37:19 --> Utf8 Class Initialized
INFO - 2016-05-23 16:37:19 --> URI Class Initialized
INFO - 2016-05-23 16:37:19 --> Router Class Initialized
INFO - 2016-05-23 16:37:19 --> Output Class Initialized
INFO - 2016-05-23 16:37:19 --> Security Class Initialized
DEBUG - 2016-05-23 16:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:37:19 --> CSRF cookie sent
INFO - 2016-05-23 16:37:19 --> Input Class Initialized
INFO - 2016-05-23 16:37:19 --> Language Class Initialized
INFO - 2016-05-23 16:37:19 --> Loader Class Initialized
INFO - 2016-05-23 16:37:19 --> Helper loaded: form_helper
INFO - 2016-05-23 16:37:19 --> Database Driver Class Initialized
INFO - 2016-05-23 16:37:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:37:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:37:19 --> Email Class Initialized
INFO - 2016-05-23 16:37:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:37:19 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:37:19 --> Helper loaded: language_helper
INFO - 2016-05-23 16:37:19 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:37:19 --> Model Class Initialized
INFO - 2016-05-23 16:37:19 --> Helper loaded: date_helper
INFO - 2016-05-23 16:37:19 --> Controller Class Initialized
INFO - 2016-05-23 16:37:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:37:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:37:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:37:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:37:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:37:19 --> Model Class Initialized
INFO - 2016-05-23 16:37:19 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:37:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:37:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:37:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 16:37:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:37:19 --> Final output sent to browser
DEBUG - 2016-05-23 16:37:19 --> Total execution time: 0.0356
INFO - 2016-05-23 16:38:40 --> Config Class Initialized
INFO - 2016-05-23 16:38:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:38:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:38:40 --> Utf8 Class Initialized
INFO - 2016-05-23 16:38:40 --> URI Class Initialized
INFO - 2016-05-23 16:38:40 --> Router Class Initialized
INFO - 2016-05-23 16:38:40 --> Output Class Initialized
INFO - 2016-05-23 16:38:40 --> Security Class Initialized
DEBUG - 2016-05-23 16:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:38:40 --> CSRF cookie sent
INFO - 2016-05-23 16:38:40 --> Input Class Initialized
INFO - 2016-05-23 16:38:40 --> Language Class Initialized
INFO - 2016-05-23 16:38:40 --> Loader Class Initialized
INFO - 2016-05-23 16:38:40 --> Helper loaded: form_helper
INFO - 2016-05-23 16:38:40 --> Database Driver Class Initialized
INFO - 2016-05-23 16:38:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:38:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:38:40 --> Email Class Initialized
INFO - 2016-05-23 16:38:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:38:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:38:40 --> Helper loaded: language_helper
INFO - 2016-05-23 16:38:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:38:40 --> Model Class Initialized
INFO - 2016-05-23 16:38:40 --> Helper loaded: date_helper
INFO - 2016-05-23 16:38:40 --> Controller Class Initialized
INFO - 2016-05-23 16:38:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:38:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:38:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:38:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:38:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:38:40 --> Model Class Initialized
INFO - 2016-05-23 16:38:40 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 16:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:38:40 --> Final output sent to browser
DEBUG - 2016-05-23 16:38:40 --> Total execution time: 0.0464
INFO - 2016-05-23 16:38:44 --> Config Class Initialized
INFO - 2016-05-23 16:38:44 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:38:44 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:38:44 --> Utf8 Class Initialized
INFO - 2016-05-23 16:38:44 --> URI Class Initialized
INFO - 2016-05-23 16:38:44 --> Router Class Initialized
INFO - 2016-05-23 16:38:44 --> Output Class Initialized
INFO - 2016-05-23 16:38:44 --> Security Class Initialized
DEBUG - 2016-05-23 16:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:38:44 --> CSRF cookie sent
INFO - 2016-05-23 16:38:44 --> Input Class Initialized
INFO - 2016-05-23 16:38:44 --> Language Class Initialized
INFO - 2016-05-23 16:38:44 --> Loader Class Initialized
INFO - 2016-05-23 16:38:44 --> Helper loaded: form_helper
INFO - 2016-05-23 16:38:44 --> Database Driver Class Initialized
INFO - 2016-05-23 16:38:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:38:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:38:44 --> Email Class Initialized
INFO - 2016-05-23 16:38:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:38:44 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:38:44 --> Helper loaded: language_helper
INFO - 2016-05-23 16:38:44 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:38:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:38:44 --> Model Class Initialized
INFO - 2016-05-23 16:38:44 --> Helper loaded: date_helper
INFO - 2016-05-23 16:38:44 --> Controller Class Initialized
INFO - 2016-05-23 16:38:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:38:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:38:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:38:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:38:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:38:44 --> Model Class Initialized
INFO - 2016-05-23 16:38:44 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 16:38:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:38:44 --> Final output sent to browser
DEBUG - 2016-05-23 16:38:44 --> Total execution time: 0.0773
INFO - 2016-05-23 16:38:48 --> Config Class Initialized
INFO - 2016-05-23 16:38:48 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:38:48 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:38:48 --> Utf8 Class Initialized
INFO - 2016-05-23 16:38:48 --> URI Class Initialized
INFO - 2016-05-23 16:38:48 --> Router Class Initialized
INFO - 2016-05-23 16:38:48 --> Output Class Initialized
INFO - 2016-05-23 16:38:48 --> Security Class Initialized
DEBUG - 2016-05-23 16:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:38:48 --> CSRF cookie sent
INFO - 2016-05-23 16:38:48 --> Input Class Initialized
INFO - 2016-05-23 16:38:48 --> Language Class Initialized
INFO - 2016-05-23 16:38:48 --> Loader Class Initialized
INFO - 2016-05-23 16:38:48 --> Helper loaded: form_helper
INFO - 2016-05-23 16:38:48 --> Database Driver Class Initialized
INFO - 2016-05-23 16:38:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:38:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:38:48 --> Email Class Initialized
INFO - 2016-05-23 16:38:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:38:48 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:38:48 --> Helper loaded: language_helper
INFO - 2016-05-23 16:38:48 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:38:48 --> Model Class Initialized
INFO - 2016-05-23 16:38:48 --> Helper loaded: date_helper
INFO - 2016-05-23 16:38:48 --> Controller Class Initialized
INFO - 2016-05-23 16:38:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:38:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:38:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:38:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:38:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:38:48 --> Model Class Initialized
INFO - 2016-05-23 16:38:48 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:38:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:38:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:38:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-23 16:38:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:38:48 --> Final output sent to browser
DEBUG - 2016-05-23 16:38:48 --> Total execution time: 0.0676
INFO - 2016-05-23 16:38:57 --> Config Class Initialized
INFO - 2016-05-23 16:38:57 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:38:57 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:38:57 --> Utf8 Class Initialized
INFO - 2016-05-23 16:38:57 --> URI Class Initialized
INFO - 2016-05-23 16:38:57 --> Router Class Initialized
INFO - 2016-05-23 16:38:57 --> Output Class Initialized
INFO - 2016-05-23 16:38:57 --> Security Class Initialized
DEBUG - 2016-05-23 16:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:38:57 --> CSRF cookie sent
INFO - 2016-05-23 16:38:57 --> Input Class Initialized
INFO - 2016-05-23 16:38:57 --> Language Class Initialized
INFO - 2016-05-23 16:38:57 --> Loader Class Initialized
INFO - 2016-05-23 16:38:57 --> Helper loaded: form_helper
INFO - 2016-05-23 16:38:57 --> Database Driver Class Initialized
INFO - 2016-05-23 16:38:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:38:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:38:57 --> Email Class Initialized
INFO - 2016-05-23 16:38:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:38:57 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:38:57 --> Helper loaded: language_helper
INFO - 2016-05-23 16:38:57 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:38:57 --> Model Class Initialized
INFO - 2016-05-23 16:38:57 --> Helper loaded: date_helper
INFO - 2016-05-23 16:38:57 --> Controller Class Initialized
INFO - 2016-05-23 16:38:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 16:38:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:38:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 16:38:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 16:38:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 16:38:57 --> Model Class Initialized
INFO - 2016-05-23 16:38:57 --> Helper loaded: languages_helper
INFO - 2016-05-23 16:38:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 16:38:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 16:38:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 16:38:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 16:38:57 --> Final output sent to browser
DEBUG - 2016-05-23 16:38:57 --> Total execution time: 0.0652
INFO - 2016-05-23 16:59:20 --> Config Class Initialized
INFO - 2016-05-23 16:59:20 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:59:20 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:59:20 --> Utf8 Class Initialized
INFO - 2016-05-23 16:59:20 --> URI Class Initialized
INFO - 2016-05-23 16:59:20 --> Router Class Initialized
INFO - 2016-05-23 16:59:20 --> Output Class Initialized
INFO - 2016-05-23 16:59:20 --> Security Class Initialized
DEBUG - 2016-05-23 16:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:59:20 --> CSRF cookie sent
INFO - 2016-05-23 16:59:20 --> Input Class Initialized
INFO - 2016-05-23 16:59:20 --> Language Class Initialized
INFO - 2016-05-23 16:59:20 --> Loader Class Initialized
INFO - 2016-05-23 16:59:20 --> Helper loaded: form_helper
INFO - 2016-05-23 16:59:20 --> Database Driver Class Initialized
INFO - 2016-05-23 16:59:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:59:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:59:20 --> Email Class Initialized
INFO - 2016-05-23 16:59:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:59:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:59:20 --> Helper loaded: language_helper
INFO - 2016-05-23 16:59:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:59:20 --> Model Class Initialized
INFO - 2016-05-23 16:59:20 --> Helper loaded: date_helper
INFO - 2016-05-23 16:59:20 --> Controller Class Initialized
DEBUG - 2016-05-23 16:59:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:59:20 --> Form Validation Class Initialized
INFO - 2016-05-23 16:59:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 16:59:20 --> Config Class Initialized
INFO - 2016-05-23 16:59:20 --> Hooks Class Initialized
DEBUG - 2016-05-23 16:59:20 --> UTF-8 Support Enabled
INFO - 2016-05-23 16:59:20 --> Utf8 Class Initialized
INFO - 2016-05-23 16:59:20 --> URI Class Initialized
INFO - 2016-05-23 16:59:20 --> Router Class Initialized
INFO - 2016-05-23 16:59:20 --> Output Class Initialized
INFO - 2016-05-23 16:59:20 --> Security Class Initialized
DEBUG - 2016-05-23 16:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 16:59:20 --> CSRF cookie sent
INFO - 2016-05-23 16:59:20 --> Input Class Initialized
INFO - 2016-05-23 16:59:20 --> Language Class Initialized
INFO - 2016-05-23 16:59:20 --> Loader Class Initialized
INFO - 2016-05-23 16:59:20 --> Helper loaded: form_helper
INFO - 2016-05-23 16:59:20 --> Database Driver Class Initialized
INFO - 2016-05-23 16:59:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 16:59:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 16:59:20 --> Email Class Initialized
INFO - 2016-05-23 16:59:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 16:59:20 --> Helper loaded: cookie_helper
INFO - 2016-05-23 16:59:20 --> Helper loaded: language_helper
INFO - 2016-05-23 16:59:20 --> Helper loaded: url_helper
DEBUG - 2016-05-23 16:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:59:20 --> Model Class Initialized
INFO - 2016-05-23 16:59:20 --> Helper loaded: date_helper
INFO - 2016-05-23 16:59:20 --> Controller Class Initialized
DEBUG - 2016-05-23 16:59:20 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 16:59:20 --> Form Validation Class Initialized
INFO - 2016-05-23 16:59:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:28:42 --> Config Class Initialized
INFO - 2016-05-23 17:28:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:28:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:28:42 --> Utf8 Class Initialized
INFO - 2016-05-23 17:28:42 --> URI Class Initialized
INFO - 2016-05-23 17:28:42 --> Router Class Initialized
INFO - 2016-05-23 17:28:42 --> Output Class Initialized
INFO - 2016-05-23 17:28:42 --> Security Class Initialized
DEBUG - 2016-05-23 17:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:28:42 --> CSRF cookie sent
INFO - 2016-05-23 17:28:42 --> Input Class Initialized
INFO - 2016-05-23 17:28:42 --> Language Class Initialized
INFO - 2016-05-23 17:28:42 --> Loader Class Initialized
INFO - 2016-05-23 17:28:42 --> Helper loaded: form_helper
INFO - 2016-05-23 17:28:42 --> Database Driver Class Initialized
INFO - 2016-05-23 17:28:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:28:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:28:42 --> Email Class Initialized
INFO - 2016-05-23 17:28:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:28:42 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:28:42 --> Helper loaded: language_helper
INFO - 2016-05-23 17:28:42 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:28:42 --> Model Class Initialized
INFO - 2016-05-23 17:28:42 --> Helper loaded: date_helper
INFO - 2016-05-23 17:28:42 --> Controller Class Initialized
DEBUG - 2016-05-23 17:28:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:28:42 --> Form Validation Class Initialized
INFO - 2016-05-23 17:28:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:28:42 --> Config Class Initialized
INFO - 2016-05-23 17:28:42 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:28:42 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:28:42 --> Utf8 Class Initialized
INFO - 2016-05-23 17:28:42 --> URI Class Initialized
INFO - 2016-05-23 17:28:42 --> Router Class Initialized
INFO - 2016-05-23 17:28:42 --> Output Class Initialized
INFO - 2016-05-23 17:28:42 --> Security Class Initialized
DEBUG - 2016-05-23 17:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:28:42 --> CSRF cookie sent
INFO - 2016-05-23 17:28:42 --> Input Class Initialized
INFO - 2016-05-23 17:28:42 --> Language Class Initialized
INFO - 2016-05-23 17:28:42 --> Loader Class Initialized
INFO - 2016-05-23 17:28:42 --> Helper loaded: form_helper
INFO - 2016-05-23 17:28:42 --> Database Driver Class Initialized
INFO - 2016-05-23 17:28:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:28:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:28:42 --> Email Class Initialized
INFO - 2016-05-23 17:28:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:28:42 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:28:42 --> Helper loaded: language_helper
INFO - 2016-05-23 17:28:42 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:28:42 --> Model Class Initialized
INFO - 2016-05-23 17:28:42 --> Helper loaded: date_helper
INFO - 2016-05-23 17:28:42 --> Controller Class Initialized
DEBUG - 2016-05-23 17:28:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:28:42 --> Form Validation Class Initialized
INFO - 2016-05-23 17:28:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:38:16 --> Config Class Initialized
INFO - 2016-05-23 17:38:16 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:38:16 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:38:16 --> Utf8 Class Initialized
INFO - 2016-05-23 17:38:16 --> URI Class Initialized
INFO - 2016-05-23 17:38:16 --> Router Class Initialized
INFO - 2016-05-23 17:38:16 --> Output Class Initialized
INFO - 2016-05-23 17:38:16 --> Security Class Initialized
DEBUG - 2016-05-23 17:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:38:16 --> CSRF cookie sent
INFO - 2016-05-23 17:38:16 --> Input Class Initialized
INFO - 2016-05-23 17:38:16 --> Language Class Initialized
INFO - 2016-05-23 17:38:16 --> Loader Class Initialized
INFO - 2016-05-23 17:38:16 --> Helper loaded: form_helper
INFO - 2016-05-23 17:38:16 --> Database Driver Class Initialized
INFO - 2016-05-23 17:38:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:38:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:38:16 --> Email Class Initialized
INFO - 2016-05-23 17:38:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:38:16 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:38:16 --> Helper loaded: language_helper
INFO - 2016-05-23 17:38:16 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:38:16 --> Model Class Initialized
INFO - 2016-05-23 17:38:16 --> Helper loaded: date_helper
INFO - 2016-05-23 17:38:16 --> Controller Class Initialized
DEBUG - 2016-05-23 17:38:16 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:38:16 --> Form Validation Class Initialized
INFO - 2016-05-23 17:38:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:38:16 --> Config Class Initialized
INFO - 2016-05-23 17:38:16 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:38:16 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:38:16 --> Utf8 Class Initialized
INFO - 2016-05-23 17:38:16 --> URI Class Initialized
INFO - 2016-05-23 17:38:16 --> Router Class Initialized
INFO - 2016-05-23 17:38:16 --> Output Class Initialized
INFO - 2016-05-23 17:38:16 --> Security Class Initialized
DEBUG - 2016-05-23 17:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:38:16 --> CSRF cookie sent
INFO - 2016-05-23 17:38:16 --> Input Class Initialized
INFO - 2016-05-23 17:38:16 --> Language Class Initialized
INFO - 2016-05-23 17:38:16 --> Loader Class Initialized
INFO - 2016-05-23 17:38:16 --> Helper loaded: form_helper
INFO - 2016-05-23 17:38:16 --> Database Driver Class Initialized
INFO - 2016-05-23 17:38:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:38:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:38:16 --> Email Class Initialized
INFO - 2016-05-23 17:38:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:38:16 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:38:16 --> Helper loaded: language_helper
INFO - 2016-05-23 17:38:16 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:38:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:38:16 --> Model Class Initialized
INFO - 2016-05-23 17:38:16 --> Helper loaded: date_helper
INFO - 2016-05-23 17:38:16 --> Controller Class Initialized
DEBUG - 2016-05-23 17:38:16 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:38:16 --> Form Validation Class Initialized
INFO - 2016-05-23 17:38:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:52:39 --> Config Class Initialized
INFO - 2016-05-23 17:52:39 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:52:39 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:52:39 --> Utf8 Class Initialized
INFO - 2016-05-23 17:52:39 --> URI Class Initialized
INFO - 2016-05-23 17:52:39 --> Router Class Initialized
INFO - 2016-05-23 17:52:39 --> Output Class Initialized
INFO - 2016-05-23 17:52:39 --> Security Class Initialized
DEBUG - 2016-05-23 17:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:52:39 --> CSRF cookie sent
INFO - 2016-05-23 17:52:39 --> Input Class Initialized
INFO - 2016-05-23 17:52:39 --> Language Class Initialized
INFO - 2016-05-23 17:52:39 --> Loader Class Initialized
INFO - 2016-05-23 17:52:39 --> Helper loaded: form_helper
INFO - 2016-05-23 17:52:39 --> Database Driver Class Initialized
INFO - 2016-05-23 17:52:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:52:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:52:39 --> Email Class Initialized
INFO - 2016-05-23 17:52:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:52:39 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:52:39 --> Helper loaded: language_helper
INFO - 2016-05-23 17:52:39 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:52:39 --> Model Class Initialized
INFO - 2016-05-23 17:52:39 --> Helper loaded: date_helper
INFO - 2016-05-23 17:52:39 --> Controller Class Initialized
DEBUG - 2016-05-23 17:52:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:52:39 --> Form Validation Class Initialized
INFO - 2016-05-23 17:52:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:52:40 --> Config Class Initialized
INFO - 2016-05-23 17:52:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:52:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:52:40 --> Utf8 Class Initialized
INFO - 2016-05-23 17:52:40 --> URI Class Initialized
INFO - 2016-05-23 17:52:40 --> Router Class Initialized
INFO - 2016-05-23 17:52:40 --> Output Class Initialized
INFO - 2016-05-23 17:52:40 --> Security Class Initialized
DEBUG - 2016-05-23 17:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:52:40 --> CSRF cookie sent
INFO - 2016-05-23 17:52:40 --> Input Class Initialized
INFO - 2016-05-23 17:52:40 --> Language Class Initialized
INFO - 2016-05-23 17:52:40 --> Loader Class Initialized
INFO - 2016-05-23 17:52:40 --> Helper loaded: form_helper
INFO - 2016-05-23 17:52:40 --> Database Driver Class Initialized
INFO - 2016-05-23 17:52:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:52:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:52:40 --> Email Class Initialized
INFO - 2016-05-23 17:52:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:52:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:52:40 --> Helper loaded: language_helper
INFO - 2016-05-23 17:52:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:52:40 --> Model Class Initialized
INFO - 2016-05-23 17:52:40 --> Helper loaded: date_helper
INFO - 2016-05-23 17:52:40 --> Controller Class Initialized
DEBUG - 2016-05-23 17:52:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:52:40 --> Form Validation Class Initialized
INFO - 2016-05-23 17:52:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:53:25 --> Config Class Initialized
INFO - 2016-05-23 17:53:25 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:53:25 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:53:25 --> Utf8 Class Initialized
INFO - 2016-05-23 17:53:25 --> URI Class Initialized
INFO - 2016-05-23 17:53:25 --> Router Class Initialized
INFO - 2016-05-23 17:53:25 --> Output Class Initialized
INFO - 2016-05-23 17:53:25 --> Security Class Initialized
DEBUG - 2016-05-23 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:53:25 --> CSRF cookie sent
INFO - 2016-05-23 17:53:25 --> Input Class Initialized
INFO - 2016-05-23 17:53:25 --> Language Class Initialized
INFO - 2016-05-23 17:53:25 --> Loader Class Initialized
INFO - 2016-05-23 17:53:25 --> Helper loaded: form_helper
INFO - 2016-05-23 17:53:25 --> Database Driver Class Initialized
INFO - 2016-05-23 17:53:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:53:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:53:25 --> Email Class Initialized
INFO - 2016-05-23 17:53:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:53:25 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:53:25 --> Helper loaded: language_helper
INFO - 2016-05-23 17:53:25 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:53:25 --> Model Class Initialized
INFO - 2016-05-23 17:53:25 --> Helper loaded: date_helper
INFO - 2016-05-23 17:53:25 --> Controller Class Initialized
DEBUG - 2016-05-23 17:53:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:53:25 --> Form Validation Class Initialized
INFO - 2016-05-23 17:53:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:53:27 --> Config Class Initialized
INFO - 2016-05-23 17:53:27 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:53:27 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:53:27 --> Utf8 Class Initialized
INFO - 2016-05-23 17:53:27 --> URI Class Initialized
INFO - 2016-05-23 17:53:27 --> Router Class Initialized
INFO - 2016-05-23 17:53:27 --> Output Class Initialized
INFO - 2016-05-23 17:53:27 --> Security Class Initialized
DEBUG - 2016-05-23 17:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:53:27 --> CSRF cookie sent
INFO - 2016-05-23 17:53:27 --> Input Class Initialized
INFO - 2016-05-23 17:53:27 --> Language Class Initialized
INFO - 2016-05-23 17:53:27 --> Loader Class Initialized
INFO - 2016-05-23 17:53:27 --> Helper loaded: form_helper
INFO - 2016-05-23 17:53:27 --> Database Driver Class Initialized
INFO - 2016-05-23 17:53:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:53:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:53:27 --> Email Class Initialized
INFO - 2016-05-23 17:53:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:53:27 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:53:27 --> Helper loaded: language_helper
INFO - 2016-05-23 17:53:27 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:53:27 --> Model Class Initialized
INFO - 2016-05-23 17:53:27 --> Helper loaded: date_helper
INFO - 2016-05-23 17:53:27 --> Controller Class Initialized
DEBUG - 2016-05-23 17:53:27 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:53:27 --> Form Validation Class Initialized
INFO - 2016-05-23 17:53:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:54:22 --> Config Class Initialized
INFO - 2016-05-23 17:54:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:54:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:54:22 --> Utf8 Class Initialized
INFO - 2016-05-23 17:54:22 --> URI Class Initialized
INFO - 2016-05-23 17:54:22 --> Router Class Initialized
INFO - 2016-05-23 17:54:22 --> Output Class Initialized
INFO - 2016-05-23 17:54:22 --> Security Class Initialized
DEBUG - 2016-05-23 17:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:54:22 --> CSRF cookie sent
INFO - 2016-05-23 17:54:22 --> Input Class Initialized
INFO - 2016-05-23 17:54:22 --> Language Class Initialized
INFO - 2016-05-23 17:54:22 --> Loader Class Initialized
INFO - 2016-05-23 17:54:22 --> Helper loaded: form_helper
INFO - 2016-05-23 17:54:22 --> Database Driver Class Initialized
INFO - 2016-05-23 17:54:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:54:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:54:22 --> Email Class Initialized
INFO - 2016-05-23 17:54:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:54:22 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:54:22 --> Helper loaded: language_helper
INFO - 2016-05-23 17:54:22 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:54:22 --> Model Class Initialized
INFO - 2016-05-23 17:54:22 --> Helper loaded: date_helper
INFO - 2016-05-23 17:54:22 --> Controller Class Initialized
DEBUG - 2016-05-23 17:54:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:54:22 --> Form Validation Class Initialized
INFO - 2016-05-23 17:54:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:54:26 --> Config Class Initialized
INFO - 2016-05-23 17:54:26 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:54:26 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:54:26 --> Utf8 Class Initialized
INFO - 2016-05-23 17:54:26 --> URI Class Initialized
INFO - 2016-05-23 17:54:26 --> Router Class Initialized
INFO - 2016-05-23 17:54:26 --> Output Class Initialized
INFO - 2016-05-23 17:54:26 --> Security Class Initialized
DEBUG - 2016-05-23 17:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:54:26 --> CSRF cookie sent
INFO - 2016-05-23 17:54:26 --> Input Class Initialized
INFO - 2016-05-23 17:54:26 --> Language Class Initialized
INFO - 2016-05-23 17:54:26 --> Loader Class Initialized
INFO - 2016-05-23 17:54:26 --> Helper loaded: form_helper
INFO - 2016-05-23 17:54:26 --> Database Driver Class Initialized
INFO - 2016-05-23 17:54:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:54:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:54:26 --> Email Class Initialized
INFO - 2016-05-23 17:54:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:54:26 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:54:26 --> Helper loaded: language_helper
INFO - 2016-05-23 17:54:26 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:54:26 --> Model Class Initialized
INFO - 2016-05-23 17:54:26 --> Helper loaded: date_helper
INFO - 2016-05-23 17:54:26 --> Controller Class Initialized
DEBUG - 2016-05-23 17:54:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:54:26 --> Form Validation Class Initialized
INFO - 2016-05-23 17:54:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 17:56:00 --> Config Class Initialized
INFO - 2016-05-23 17:56:00 --> Hooks Class Initialized
DEBUG - 2016-05-23 17:56:00 --> UTF-8 Support Enabled
INFO - 2016-05-23 17:56:00 --> Utf8 Class Initialized
INFO - 2016-05-23 17:56:00 --> URI Class Initialized
INFO - 2016-05-23 17:56:00 --> Router Class Initialized
INFO - 2016-05-23 17:56:00 --> Output Class Initialized
INFO - 2016-05-23 17:56:00 --> Security Class Initialized
DEBUG - 2016-05-23 17:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 17:56:00 --> CSRF cookie sent
INFO - 2016-05-23 17:56:00 --> Input Class Initialized
INFO - 2016-05-23 17:56:00 --> Language Class Initialized
INFO - 2016-05-23 17:56:00 --> Loader Class Initialized
INFO - 2016-05-23 17:56:00 --> Helper loaded: form_helper
INFO - 2016-05-23 17:56:00 --> Database Driver Class Initialized
INFO - 2016-05-23 17:56:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 17:56:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 17:56:00 --> Email Class Initialized
INFO - 2016-05-23 17:56:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 17:56:00 --> Helper loaded: cookie_helper
INFO - 2016-05-23 17:56:00 --> Helper loaded: language_helper
INFO - 2016-05-23 17:56:00 --> Helper loaded: url_helper
DEBUG - 2016-05-23 17:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:56:00 --> Model Class Initialized
INFO - 2016-05-23 17:56:00 --> Helper loaded: date_helper
INFO - 2016-05-23 17:56:00 --> Controller Class Initialized
DEBUG - 2016-05-23 17:56:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 17:56:00 --> Form Validation Class Initialized
INFO - 2016-05-23 17:56:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:04:08 --> Config Class Initialized
INFO - 2016-05-23 18:04:08 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:04:08 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:04:08 --> Utf8 Class Initialized
INFO - 2016-05-23 18:04:08 --> URI Class Initialized
INFO - 2016-05-23 18:04:08 --> Router Class Initialized
INFO - 2016-05-23 18:04:08 --> Output Class Initialized
INFO - 2016-05-23 18:04:08 --> Security Class Initialized
DEBUG - 2016-05-23 18:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:04:08 --> CSRF cookie sent
INFO - 2016-05-23 18:04:08 --> Input Class Initialized
INFO - 2016-05-23 18:04:08 --> Language Class Initialized
INFO - 2016-05-23 18:04:08 --> Loader Class Initialized
INFO - 2016-05-23 18:04:08 --> Helper loaded: form_helper
INFO - 2016-05-23 18:04:08 --> Database Driver Class Initialized
INFO - 2016-05-23 18:04:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:04:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:04:08 --> Email Class Initialized
INFO - 2016-05-23 18:04:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:04:08 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:04:08 --> Helper loaded: language_helper
INFO - 2016-05-23 18:04:08 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:04:08 --> Model Class Initialized
INFO - 2016-05-23 18:04:08 --> Helper loaded: date_helper
INFO - 2016-05-23 18:04:08 --> Controller Class Initialized
DEBUG - 2016-05-23 18:04:08 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:04:08 --> Form Validation Class Initialized
INFO - 2016-05-23 18:04:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:04:09 --> Config Class Initialized
INFO - 2016-05-23 18:04:09 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:04:09 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:04:09 --> Utf8 Class Initialized
INFO - 2016-05-23 18:04:09 --> URI Class Initialized
INFO - 2016-05-23 18:04:09 --> Router Class Initialized
INFO - 2016-05-23 18:04:09 --> Output Class Initialized
INFO - 2016-05-23 18:04:09 --> Security Class Initialized
DEBUG - 2016-05-23 18:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:04:09 --> CSRF cookie sent
INFO - 2016-05-23 18:04:09 --> Input Class Initialized
INFO - 2016-05-23 18:04:09 --> Language Class Initialized
INFO - 2016-05-23 18:04:09 --> Loader Class Initialized
INFO - 2016-05-23 18:04:09 --> Helper loaded: form_helper
INFO - 2016-05-23 18:04:09 --> Database Driver Class Initialized
INFO - 2016-05-23 18:04:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:04:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:04:09 --> Email Class Initialized
INFO - 2016-05-23 18:04:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:04:09 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:04:09 --> Helper loaded: language_helper
INFO - 2016-05-23 18:04:09 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:04:09 --> Model Class Initialized
INFO - 2016-05-23 18:04:09 --> Helper loaded: date_helper
INFO - 2016-05-23 18:04:09 --> Controller Class Initialized
DEBUG - 2016-05-23 18:04:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:04:09 --> Form Validation Class Initialized
INFO - 2016-05-23 18:04:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:07:40 --> Config Class Initialized
INFO - 2016-05-23 18:07:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:07:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:07:40 --> Utf8 Class Initialized
INFO - 2016-05-23 18:07:40 --> URI Class Initialized
INFO - 2016-05-23 18:07:40 --> Router Class Initialized
INFO - 2016-05-23 18:07:40 --> Output Class Initialized
INFO - 2016-05-23 18:07:40 --> Security Class Initialized
DEBUG - 2016-05-23 18:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:07:40 --> CSRF cookie sent
INFO - 2016-05-23 18:07:40 --> Input Class Initialized
INFO - 2016-05-23 18:07:40 --> Language Class Initialized
INFO - 2016-05-23 18:07:40 --> Loader Class Initialized
INFO - 2016-05-23 18:07:40 --> Helper loaded: form_helper
INFO - 2016-05-23 18:07:40 --> Database Driver Class Initialized
INFO - 2016-05-23 18:07:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:07:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:07:40 --> Email Class Initialized
INFO - 2016-05-23 18:07:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:07:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:07:40 --> Helper loaded: language_helper
INFO - 2016-05-23 18:07:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:07:40 --> Model Class Initialized
INFO - 2016-05-23 18:07:40 --> Helper loaded: date_helper
INFO - 2016-05-23 18:07:40 --> Controller Class Initialized
DEBUG - 2016-05-23 18:07:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:07:40 --> Form Validation Class Initialized
INFO - 2016-05-23 18:07:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:07:47 --> Config Class Initialized
INFO - 2016-05-23 18:07:47 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:07:47 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:07:47 --> Utf8 Class Initialized
INFO - 2016-05-23 18:07:47 --> URI Class Initialized
INFO - 2016-05-23 18:07:47 --> Router Class Initialized
INFO - 2016-05-23 18:07:47 --> Output Class Initialized
INFO - 2016-05-23 18:07:47 --> Security Class Initialized
DEBUG - 2016-05-23 18:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:07:47 --> CSRF cookie sent
INFO - 2016-05-23 18:07:47 --> Input Class Initialized
INFO - 2016-05-23 18:07:47 --> Language Class Initialized
INFO - 2016-05-23 18:07:47 --> Loader Class Initialized
INFO - 2016-05-23 18:07:47 --> Helper loaded: form_helper
INFO - 2016-05-23 18:07:47 --> Database Driver Class Initialized
INFO - 2016-05-23 18:07:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:07:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:07:47 --> Email Class Initialized
INFO - 2016-05-23 18:07:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:07:47 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:07:47 --> Helper loaded: language_helper
INFO - 2016-05-23 18:07:47 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:07:47 --> Model Class Initialized
INFO - 2016-05-23 18:07:47 --> Helper loaded: date_helper
INFO - 2016-05-23 18:07:47 --> Controller Class Initialized
DEBUG - 2016-05-23 18:07:47 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:07:47 --> Form Validation Class Initialized
INFO - 2016-05-23 18:07:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:09:15 --> Config Class Initialized
INFO - 2016-05-23 18:09:15 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:09:15 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:09:15 --> Utf8 Class Initialized
INFO - 2016-05-23 18:09:15 --> URI Class Initialized
INFO - 2016-05-23 18:09:15 --> Router Class Initialized
INFO - 2016-05-23 18:09:15 --> Output Class Initialized
INFO - 2016-05-23 18:09:15 --> Security Class Initialized
DEBUG - 2016-05-23 18:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:09:15 --> CSRF cookie sent
INFO - 2016-05-23 18:09:15 --> Input Class Initialized
INFO - 2016-05-23 18:09:15 --> Language Class Initialized
INFO - 2016-05-23 18:09:15 --> Loader Class Initialized
INFO - 2016-05-23 18:09:15 --> Helper loaded: form_helper
INFO - 2016-05-23 18:09:15 --> Database Driver Class Initialized
INFO - 2016-05-23 18:09:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:09:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:09:15 --> Email Class Initialized
INFO - 2016-05-23 18:09:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:09:15 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:09:15 --> Helper loaded: language_helper
INFO - 2016-05-23 18:09:15 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:09:15 --> Model Class Initialized
INFO - 2016-05-23 18:09:15 --> Helper loaded: date_helper
INFO - 2016-05-23 18:09:15 --> Controller Class Initialized
DEBUG - 2016-05-23 18:09:15 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:09:15 --> Form Validation Class Initialized
INFO - 2016-05-23 18:09:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:09:16 --> Config Class Initialized
INFO - 2016-05-23 18:09:16 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:09:16 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:09:16 --> Utf8 Class Initialized
INFO - 2016-05-23 18:09:16 --> URI Class Initialized
INFO - 2016-05-23 18:09:16 --> Router Class Initialized
INFO - 2016-05-23 18:09:16 --> Output Class Initialized
INFO - 2016-05-23 18:09:16 --> Security Class Initialized
DEBUG - 2016-05-23 18:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:09:16 --> CSRF cookie sent
INFO - 2016-05-23 18:09:16 --> Input Class Initialized
INFO - 2016-05-23 18:09:16 --> Language Class Initialized
INFO - 2016-05-23 18:09:16 --> Loader Class Initialized
INFO - 2016-05-23 18:09:16 --> Helper loaded: form_helper
INFO - 2016-05-23 18:09:16 --> Database Driver Class Initialized
INFO - 2016-05-23 18:09:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:09:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:09:16 --> Email Class Initialized
INFO - 2016-05-23 18:09:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:09:16 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:09:16 --> Helper loaded: language_helper
INFO - 2016-05-23 18:09:16 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:09:16 --> Model Class Initialized
INFO - 2016-05-23 18:09:16 --> Helper loaded: date_helper
INFO - 2016-05-23 18:09:16 --> Controller Class Initialized
DEBUG - 2016-05-23 18:09:16 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:09:16 --> Form Validation Class Initialized
INFO - 2016-05-23 18:09:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:28:40 --> Config Class Initialized
INFO - 2016-05-23 18:28:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:28:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:28:40 --> Utf8 Class Initialized
INFO - 2016-05-23 18:28:40 --> URI Class Initialized
INFO - 2016-05-23 18:28:40 --> Router Class Initialized
INFO - 2016-05-23 18:28:40 --> Output Class Initialized
INFO - 2016-05-23 18:28:40 --> Security Class Initialized
DEBUG - 2016-05-23 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:28:40 --> CSRF cookie sent
INFO - 2016-05-23 18:28:40 --> Input Class Initialized
INFO - 2016-05-23 18:28:40 --> Language Class Initialized
INFO - 2016-05-23 18:28:40 --> Loader Class Initialized
INFO - 2016-05-23 18:28:40 --> Helper loaded: form_helper
INFO - 2016-05-23 18:28:40 --> Database Driver Class Initialized
INFO - 2016-05-23 18:28:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:28:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:28:40 --> Email Class Initialized
INFO - 2016-05-23 18:28:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:28:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:28:40 --> Helper loaded: language_helper
INFO - 2016-05-23 18:28:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:28:40 --> Model Class Initialized
INFO - 2016-05-23 18:28:40 --> Helper loaded: date_helper
INFO - 2016-05-23 18:28:40 --> Controller Class Initialized
DEBUG - 2016-05-23 18:28:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:28:40 --> Form Validation Class Initialized
INFO - 2016-05-23 18:28:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:28:40 --> Config Class Initialized
INFO - 2016-05-23 18:28:40 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:28:40 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:28:40 --> Utf8 Class Initialized
INFO - 2016-05-23 18:28:40 --> URI Class Initialized
INFO - 2016-05-23 18:28:40 --> Router Class Initialized
INFO - 2016-05-23 18:28:40 --> Output Class Initialized
INFO - 2016-05-23 18:28:40 --> Security Class Initialized
DEBUG - 2016-05-23 18:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:28:40 --> CSRF cookie sent
INFO - 2016-05-23 18:28:40 --> Input Class Initialized
INFO - 2016-05-23 18:28:40 --> Language Class Initialized
INFO - 2016-05-23 18:28:40 --> Loader Class Initialized
INFO - 2016-05-23 18:28:40 --> Helper loaded: form_helper
INFO - 2016-05-23 18:28:40 --> Database Driver Class Initialized
INFO - 2016-05-23 18:28:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:28:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:28:40 --> Email Class Initialized
INFO - 2016-05-23 18:28:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:28:40 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:28:40 --> Helper loaded: language_helper
INFO - 2016-05-23 18:28:40 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:28:40 --> Model Class Initialized
INFO - 2016-05-23 18:28:40 --> Helper loaded: date_helper
INFO - 2016-05-23 18:28:40 --> Controller Class Initialized
DEBUG - 2016-05-23 18:28:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:28:40 --> Form Validation Class Initialized
INFO - 2016-05-23 18:28:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:32:22 --> Config Class Initialized
INFO - 2016-05-23 18:32:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:32:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:32:22 --> Utf8 Class Initialized
INFO - 2016-05-23 18:32:22 --> URI Class Initialized
INFO - 2016-05-23 18:32:22 --> Router Class Initialized
INFO - 2016-05-23 18:32:22 --> Output Class Initialized
INFO - 2016-05-23 18:32:22 --> Security Class Initialized
DEBUG - 2016-05-23 18:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:32:22 --> CSRF cookie sent
INFO - 2016-05-23 18:32:22 --> CSRF token verified
INFO - 2016-05-23 18:32:22 --> Input Class Initialized
INFO - 2016-05-23 18:32:22 --> Language Class Initialized
INFO - 2016-05-23 18:32:22 --> Loader Class Initialized
INFO - 2016-05-23 18:32:22 --> Helper loaded: form_helper
INFO - 2016-05-23 18:32:22 --> Database Driver Class Initialized
INFO - 2016-05-23 18:32:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:32:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:32:22 --> Email Class Initialized
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:32:22 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:32:22 --> Helper loaded: language_helper
INFO - 2016-05-23 18:32:22 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:32:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:32:22 --> Model Class Initialized
INFO - 2016-05-23 18:32:22 --> Helper loaded: date_helper
INFO - 2016-05-23 18:32:22 --> Controller Class Initialized
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-23 18:32:22 --> Config Class Initialized
INFO - 2016-05-23 18:32:22 --> Hooks Class Initialized
DEBUG - 2016-05-23 18:32:22 --> UTF-8 Support Enabled
INFO - 2016-05-23 18:32:22 --> Utf8 Class Initialized
INFO - 2016-05-23 18:32:22 --> URI Class Initialized
INFO - 2016-05-23 18:32:22 --> Router Class Initialized
INFO - 2016-05-23 18:32:22 --> Output Class Initialized
INFO - 2016-05-23 18:32:22 --> Security Class Initialized
DEBUG - 2016-05-23 18:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-23 18:32:22 --> CSRF cookie sent
INFO - 2016-05-23 18:32:22 --> Input Class Initialized
INFO - 2016-05-23 18:32:22 --> Language Class Initialized
INFO - 2016-05-23 18:32:22 --> Loader Class Initialized
INFO - 2016-05-23 18:32:22 --> Helper loaded: form_helper
INFO - 2016-05-23 18:32:22 --> Database Driver Class Initialized
INFO - 2016-05-23 18:32:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-23 18:32:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-23 18:32:22 --> Email Class Initialized
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-23 18:32:22 --> Helper loaded: cookie_helper
INFO - 2016-05-23 18:32:22 --> Helper loaded: language_helper
INFO - 2016-05-23 18:32:22 --> Helper loaded: url_helper
DEBUG - 2016-05-23 18:32:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-23 18:32:22 --> Model Class Initialized
INFO - 2016-05-23 18:32:22 --> Helper loaded: date_helper
INFO - 2016-05-23 18:32:22 --> Controller Class Initialized
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-23 18:32:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-23 18:32:22 --> Model Class Initialized
INFO - 2016-05-23 18:32:22 --> Helper loaded: languages_helper
INFO - 2016-05-23 18:32:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-23 18:32:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-23 18:32:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-23 18:32:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-23 18:32:22 --> Final output sent to browser
DEBUG - 2016-05-23 18:32:22 --> Total execution time: 0.0675
