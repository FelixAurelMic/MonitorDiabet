<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-28 06:10:32 --> Config Class Initialized
INFO - 2016-06-28 06:10:32 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:10:33 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:10:33 --> Utf8 Class Initialized
INFO - 2016-06-28 06:10:33 --> URI Class Initialized
DEBUG - 2016-06-28 06:10:33 --> No URI present. Default controller set.
INFO - 2016-06-28 06:10:33 --> Router Class Initialized
INFO - 2016-06-28 06:10:33 --> Output Class Initialized
INFO - 2016-06-28 06:10:33 --> Security Class Initialized
DEBUG - 2016-06-28 06:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:10:33 --> Input Class Initialized
INFO - 2016-06-28 06:10:33 --> Language Class Initialized
INFO - 2016-06-28 06:10:33 --> Loader Class Initialized
INFO - 2016-06-28 06:10:33 --> Helper loaded: form_helper
INFO - 2016-06-28 06:10:33 --> Database Driver Class Initialized
INFO - 2016-06-28 06:10:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:10:33 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:10:33 --> Email Class Initialized
INFO - 2016-06-28 06:10:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:10:33 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:10:33 --> Helper loaded: language_helper
INFO - 2016-06-28 06:10:33 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:10:33 --> Model Class Initialized
INFO - 2016-06-28 06:10:33 --> Helper loaded: date_helper
INFO - 2016-06-28 06:10:33 --> Controller Class Initialized
INFO - 2016-06-28 06:10:33 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:10:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:10:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:10:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:10:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:10:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:10:33 --> Model Class Initialized
INFO - 2016-06-28 09:10:33 --> Form Validation Class Initialized
INFO - 2016-06-28 09:10:33 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-28 09:10:33 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-28 09:10:33 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-28 09:10:33 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-28 09:10:33 --> Final output sent to browser
DEBUG - 2016-06-28 09:10:33 --> Total execution time: 1.0020
INFO - 2016-06-28 06:10:36 --> Config Class Initialized
INFO - 2016-06-28 06:10:36 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:10:36 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:10:36 --> Utf8 Class Initialized
INFO - 2016-06-28 06:10:36 --> URI Class Initialized
INFO - 2016-06-28 06:10:36 --> Router Class Initialized
INFO - 2016-06-28 06:10:36 --> Output Class Initialized
INFO - 2016-06-28 06:10:36 --> Security Class Initialized
DEBUG - 2016-06-28 06:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:10:36 --> Input Class Initialized
INFO - 2016-06-28 06:10:36 --> Language Class Initialized
INFO - 2016-06-28 06:10:36 --> Loader Class Initialized
INFO - 2016-06-28 06:10:36 --> Helper loaded: form_helper
INFO - 2016-06-28 06:10:36 --> Database Driver Class Initialized
INFO - 2016-06-28 06:10:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:10:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:10:36 --> Email Class Initialized
INFO - 2016-06-28 06:10:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:10:36 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:10:36 --> Helper loaded: language_helper
INFO - 2016-06-28 06:10:36 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:10:36 --> Model Class Initialized
INFO - 2016-06-28 06:10:36 --> Helper loaded: date_helper
INFO - 2016-06-28 06:10:36 --> Controller Class Initialized
INFO - 2016-06-28 06:10:36 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:10:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:10:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:10:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:10:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:10:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:10:36 --> Model Class Initialized
INFO - 2016-06-28 09:10:37 --> Final output sent to browser
DEBUG - 2016-06-28 09:10:37 --> Total execution time: 0.1222
INFO - 2016-06-28 06:10:37 --> Config Class Initialized
INFO - 2016-06-28 06:10:37 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:10:37 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:10:37 --> Utf8 Class Initialized
INFO - 2016-06-28 06:10:37 --> URI Class Initialized
INFO - 2016-06-28 06:10:37 --> Router Class Initialized
INFO - 2016-06-28 06:10:37 --> Output Class Initialized
INFO - 2016-06-28 06:10:37 --> Security Class Initialized
DEBUG - 2016-06-28 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:10:37 --> Input Class Initialized
INFO - 2016-06-28 06:10:37 --> Language Class Initialized
ERROR - 2016-06-28 06:10:37 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-28 06:10:37 --> Config Class Initialized
INFO - 2016-06-28 06:10:37 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:10:37 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:10:37 --> Utf8 Class Initialized
INFO - 2016-06-28 06:10:37 --> URI Class Initialized
INFO - 2016-06-28 06:10:37 --> Router Class Initialized
INFO - 2016-06-28 06:10:37 --> Output Class Initialized
INFO - 2016-06-28 06:10:37 --> Security Class Initialized
DEBUG - 2016-06-28 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:10:37 --> Input Class Initialized
INFO - 2016-06-28 06:10:37 --> Language Class Initialized
ERROR - 2016-06-28 06:10:37 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-28 06:11:00 --> Config Class Initialized
INFO - 2016-06-28 06:11:00 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:00 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:00 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:00 --> URI Class Initialized
INFO - 2016-06-28 06:11:00 --> Router Class Initialized
INFO - 2016-06-28 06:11:00 --> Output Class Initialized
INFO - 2016-06-28 06:11:00 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:00 --> Input Class Initialized
INFO - 2016-06-28 06:11:00 --> Language Class Initialized
INFO - 2016-06-28 06:11:00 --> Loader Class Initialized
INFO - 2016-06-28 06:11:00 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:00 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:00 --> Email Class Initialized
INFO - 2016-06-28 06:11:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:00 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:00 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:00 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:00 --> Model Class Initialized
INFO - 2016-06-28 06:11:00 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:00 --> Controller Class Initialized
INFO - 2016-06-28 06:11:00 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:00 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-28 09:11:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-28 09:11:00 --> Form Validation Class Initialized
DEBUG - 2016-06-28 09:11:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:01 --> Config Class Initialized
INFO - 2016-06-28 06:11:01 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:01 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:01 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:01 --> URI Class Initialized
DEBUG - 2016-06-28 06:11:01 --> No URI present. Default controller set.
INFO - 2016-06-28 06:11:01 --> Router Class Initialized
INFO - 2016-06-28 06:11:01 --> Output Class Initialized
INFO - 2016-06-28 06:11:01 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:01 --> Input Class Initialized
INFO - 2016-06-28 06:11:01 --> Language Class Initialized
INFO - 2016-06-28 06:11:01 --> Loader Class Initialized
INFO - 2016-06-28 06:11:01 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:01 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:01 --> Email Class Initialized
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:01 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:01 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:01 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:01 --> Model Class Initialized
INFO - 2016-06-28 06:11:01 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:01 --> Controller Class Initialized
INFO - 2016-06-28 06:11:01 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 06:11:01 --> Config Class Initialized
INFO - 2016-06-28 06:11:01 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:01 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:01 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:01 --> URI Class Initialized
INFO - 2016-06-28 06:11:01 --> Router Class Initialized
INFO - 2016-06-28 06:11:01 --> Output Class Initialized
INFO - 2016-06-28 06:11:01 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:01 --> Input Class Initialized
INFO - 2016-06-28 06:11:01 --> Language Class Initialized
INFO - 2016-06-28 06:11:01 --> Loader Class Initialized
INFO - 2016-06-28 06:11:01 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:01 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:01 --> Email Class Initialized
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:01 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:01 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:01 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:01 --> Model Class Initialized
INFO - 2016-06-28 06:11:01 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:01 --> Controller Class Initialized
INFO - 2016-06-28 06:11:01 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:01 --> Model Class Initialized
INFO - 2016-06-28 09:11:01 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-28 09:11:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-28 09:11:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-28 09:11:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-28 09:11:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-28 09:11:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-28 09:11:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-28 09:11:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-28 09:11:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-28 09:11:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-28 09:11:02 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-28 09:11:02 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-28 09:11:02 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:02 --> Total execution time: 0.2590
INFO - 2016-06-28 06:11:08 --> Config Class Initialized
INFO - 2016-06-28 06:11:08 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:08 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:08 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:08 --> URI Class Initialized
INFO - 2016-06-28 06:11:08 --> Router Class Initialized
INFO - 2016-06-28 06:11:08 --> Output Class Initialized
INFO - 2016-06-28 06:11:08 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:08 --> Input Class Initialized
INFO - 2016-06-28 06:11:08 --> Language Class Initialized
INFO - 2016-06-28 06:11:08 --> Loader Class Initialized
INFO - 2016-06-28 06:11:08 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:08 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:08 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:08 --> Email Class Initialized
INFO - 2016-06-28 06:11:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:08 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:08 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:08 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:08 --> Model Class Initialized
INFO - 2016-06-28 06:11:08 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:08 --> Controller Class Initialized
INFO - 2016-06-28 06:11:08 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:08 --> Model Class Initialized
INFO - 2016-06-28 09:11:08 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:08 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:08 --> Total execution time: 0.0953
INFO - 2016-06-28 06:11:17 --> Config Class Initialized
INFO - 2016-06-28 06:11:17 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:17 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:17 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:17 --> URI Class Initialized
INFO - 2016-06-28 06:11:17 --> Router Class Initialized
INFO - 2016-06-28 06:11:17 --> Output Class Initialized
INFO - 2016-06-28 06:11:17 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:17 --> Input Class Initialized
INFO - 2016-06-28 06:11:17 --> Language Class Initialized
INFO - 2016-06-28 06:11:17 --> Loader Class Initialized
INFO - 2016-06-28 06:11:17 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:17 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:17 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:17 --> Email Class Initialized
INFO - 2016-06-28 06:11:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:17 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:17 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:17 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:17 --> Model Class Initialized
INFO - 2016-06-28 06:11:17 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:17 --> Controller Class Initialized
INFO - 2016-06-28 06:11:17 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:17 --> Model Class Initialized
INFO - 2016-06-28 09:11:17 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:17 --> Helper loaded: sort_array_helper
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-28 09:11:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-28 09:11:17 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:17 --> Total execution time: 0.1117
INFO - 2016-06-28 06:11:26 --> Config Class Initialized
INFO - 2016-06-28 06:11:26 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:26 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:26 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:26 --> URI Class Initialized
INFO - 2016-06-28 06:11:26 --> Router Class Initialized
INFO - 2016-06-28 06:11:26 --> Output Class Initialized
INFO - 2016-06-28 06:11:26 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:26 --> Input Class Initialized
INFO - 2016-06-28 06:11:26 --> Language Class Initialized
INFO - 2016-06-28 06:11:26 --> Loader Class Initialized
INFO - 2016-06-28 06:11:26 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:26 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:26 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:26 --> Email Class Initialized
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:26 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:26 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:26 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:26 --> Model Class Initialized
INFO - 2016-06-28 06:11:26 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:26 --> Controller Class Initialized
INFO - 2016-06-28 06:11:26 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:26 --> Model Class Initialized
INFO - 2016-06-28 09:11:26 --> Form Validation Class Initialized
DEBUG - 2016-06-28 09:11:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:26 --> Config Class Initialized
INFO - 2016-06-28 06:11:26 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:26 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:26 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:26 --> URI Class Initialized
INFO - 2016-06-28 06:11:26 --> Router Class Initialized
INFO - 2016-06-28 06:11:26 --> Output Class Initialized
INFO - 2016-06-28 06:11:26 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:26 --> Input Class Initialized
INFO - 2016-06-28 06:11:26 --> Language Class Initialized
INFO - 2016-06-28 06:11:26 --> Loader Class Initialized
INFO - 2016-06-28 06:11:26 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:26 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:26 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:26 --> Email Class Initialized
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:26 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:26 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:26 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:26 --> Model Class Initialized
INFO - 2016-06-28 06:11:26 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:26 --> Controller Class Initialized
INFO - 2016-06-28 06:11:26 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:26 --> Model Class Initialized
INFO - 2016-06-28 09:11:26 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-28 09:11:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-28 09:11:26 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:26 --> Total execution time: 0.0869
INFO - 2016-06-28 06:11:28 --> Config Class Initialized
INFO - 2016-06-28 06:11:28 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:28 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:28 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:28 --> URI Class Initialized
INFO - 2016-06-28 06:11:28 --> Router Class Initialized
INFO - 2016-06-28 06:11:28 --> Output Class Initialized
INFO - 2016-06-28 06:11:28 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:28 --> Input Class Initialized
INFO - 2016-06-28 06:11:28 --> Language Class Initialized
INFO - 2016-06-28 06:11:28 --> Loader Class Initialized
INFO - 2016-06-28 06:11:28 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:28 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:28 --> Email Class Initialized
INFO - 2016-06-28 06:11:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:28 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:28 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:28 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:28 --> Model Class Initialized
INFO - 2016-06-28 06:11:28 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:28 --> Controller Class Initialized
INFO - 2016-06-28 06:11:28 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:28 --> Model Class Initialized
INFO - 2016-06-28 09:11:28 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:28 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:28 --> Total execution time: 0.0835
INFO - 2016-06-28 06:11:36 --> Config Class Initialized
INFO - 2016-06-28 06:11:36 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:36 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:36 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:36 --> URI Class Initialized
INFO - 2016-06-28 06:11:36 --> Router Class Initialized
INFO - 2016-06-28 06:11:36 --> Output Class Initialized
INFO - 2016-06-28 06:11:36 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:36 --> Input Class Initialized
INFO - 2016-06-28 06:11:36 --> Language Class Initialized
INFO - 2016-06-28 06:11:36 --> Loader Class Initialized
INFO - 2016-06-28 06:11:36 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:36 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:36 --> Email Class Initialized
INFO - 2016-06-28 06:11:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:36 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:36 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:36 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:36 --> Model Class Initialized
INFO - 2016-06-28 06:11:36 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:36 --> Controller Class Initialized
INFO - 2016-06-28 06:11:36 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:36 --> Model Class Initialized
INFO - 2016-06-28 09:11:36 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-28 09:11:36 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-28 09:11:36 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:36 --> Total execution time: 0.0944
INFO - 2016-06-28 06:11:40 --> Config Class Initialized
INFO - 2016-06-28 06:11:40 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:40 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:40 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:40 --> URI Class Initialized
INFO - 2016-06-28 06:11:40 --> Router Class Initialized
INFO - 2016-06-28 06:11:40 --> Output Class Initialized
INFO - 2016-06-28 06:11:40 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:40 --> Input Class Initialized
INFO - 2016-06-28 06:11:40 --> Language Class Initialized
INFO - 2016-06-28 06:11:40 --> Loader Class Initialized
INFO - 2016-06-28 06:11:40 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:40 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:40 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:40 --> Email Class Initialized
INFO - 2016-06-28 06:11:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:40 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:40 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:40 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:40 --> Model Class Initialized
INFO - 2016-06-28 06:11:40 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:40 --> Controller Class Initialized
INFO - 2016-06-28 06:11:40 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:40 --> Model Class Initialized
INFO - 2016-06-28 09:11:40 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:40 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:40 --> Total execution time: 0.0913
INFO - 2016-06-28 06:11:45 --> Config Class Initialized
INFO - 2016-06-28 06:11:45 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:45 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:45 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:45 --> URI Class Initialized
INFO - 2016-06-28 06:11:45 --> Router Class Initialized
INFO - 2016-06-28 06:11:45 --> Output Class Initialized
INFO - 2016-06-28 06:11:45 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:45 --> Input Class Initialized
INFO - 2016-06-28 06:11:45 --> Language Class Initialized
INFO - 2016-06-28 06:11:45 --> Loader Class Initialized
INFO - 2016-06-28 06:11:45 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:45 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:45 --> Email Class Initialized
INFO - 2016-06-28 06:11:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:45 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:45 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:45 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:45 --> Model Class Initialized
INFO - 2016-06-28 06:11:45 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:45 --> Controller Class Initialized
INFO - 2016-06-28 06:11:45 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:45 --> Model Class Initialized
INFO - 2016-06-28 09:11:45 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-28 09:11:45 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-28 09:11:45 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:45 --> Total execution time: 0.1283
INFO - 2016-06-28 06:11:49 --> Config Class Initialized
INFO - 2016-06-28 06:11:49 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:49 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:49 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:49 --> URI Class Initialized
INFO - 2016-06-28 06:11:49 --> Router Class Initialized
INFO - 2016-06-28 06:11:49 --> Output Class Initialized
INFO - 2016-06-28 06:11:49 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:49 --> Input Class Initialized
INFO - 2016-06-28 06:11:49 --> Language Class Initialized
INFO - 2016-06-28 06:11:49 --> Loader Class Initialized
INFO - 2016-06-28 06:11:49 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:49 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:49 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:49 --> Email Class Initialized
INFO - 2016-06-28 06:11:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:49 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:49 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:49 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:49 --> Model Class Initialized
INFO - 2016-06-28 06:11:49 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:49 --> Controller Class Initialized
INFO - 2016-06-28 06:11:49 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:49 --> Model Class Initialized
INFO - 2016-06-28 09:11:49 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:49 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:49 --> Total execution time: 0.0879
INFO - 2016-06-28 06:11:55 --> Config Class Initialized
INFO - 2016-06-28 06:11:55 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:55 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:55 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:55 --> URI Class Initialized
INFO - 2016-06-28 06:11:55 --> Router Class Initialized
INFO - 2016-06-28 06:11:55 --> Output Class Initialized
INFO - 2016-06-28 06:11:55 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:55 --> Input Class Initialized
INFO - 2016-06-28 06:11:55 --> Language Class Initialized
INFO - 2016-06-28 06:11:55 --> Loader Class Initialized
INFO - 2016-06-28 06:11:55 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:55 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:55 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:55 --> Email Class Initialized
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:55 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:55 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:55 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:55 --> Model Class Initialized
INFO - 2016-06-28 06:11:55 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:55 --> Controller Class Initialized
INFO - 2016-06-28 06:11:55 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-28 09:11:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-28 09:11:55 --> Form Validation Class Initialized
INFO - 2016-06-28 06:11:55 --> Config Class Initialized
INFO - 2016-06-28 06:11:55 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:55 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:55 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:55 --> URI Class Initialized
DEBUG - 2016-06-28 06:11:55 --> No URI present. Default controller set.
INFO - 2016-06-28 06:11:55 --> Router Class Initialized
INFO - 2016-06-28 06:11:55 --> Output Class Initialized
INFO - 2016-06-28 06:11:55 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:55 --> Input Class Initialized
INFO - 2016-06-28 06:11:55 --> Language Class Initialized
INFO - 2016-06-28 06:11:55 --> Loader Class Initialized
INFO - 2016-06-28 06:11:55 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:55 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:55 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:55 --> Email Class Initialized
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:55 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:55 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:55 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:55 --> Model Class Initialized
INFO - 2016-06-28 06:11:55 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:55 --> Controller Class Initialized
INFO - 2016-06-28 06:11:55 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:55 --> Model Class Initialized
INFO - 2016-06-28 09:11:55 --> Form Validation Class Initialized
INFO - 2016-06-28 09:11:55 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-28 09:11:55 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-28 09:11:55 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-28 09:11:55 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-28 09:11:55 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:55 --> Total execution time: 0.0829
INFO - 2016-06-28 06:11:57 --> Config Class Initialized
INFO - 2016-06-28 06:11:57 --> Hooks Class Initialized
DEBUG - 2016-06-28 06:11:57 --> UTF-8 Support Enabled
INFO - 2016-06-28 06:11:57 --> Utf8 Class Initialized
INFO - 2016-06-28 06:11:57 --> URI Class Initialized
INFO - 2016-06-28 06:11:57 --> Router Class Initialized
INFO - 2016-06-28 06:11:57 --> Output Class Initialized
INFO - 2016-06-28 06:11:57 --> Security Class Initialized
DEBUG - 2016-06-28 06:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-28 06:11:57 --> Input Class Initialized
INFO - 2016-06-28 06:11:57 --> Language Class Initialized
INFO - 2016-06-28 06:11:57 --> Loader Class Initialized
INFO - 2016-06-28 06:11:57 --> Helper loaded: form_helper
INFO - 2016-06-28 06:11:57 --> Database Driver Class Initialized
INFO - 2016-06-28 06:11:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-28 06:11:57 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-28 06:11:57 --> Email Class Initialized
INFO - 2016-06-28 06:11:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-28 06:11:57 --> Helper loaded: cookie_helper
INFO - 2016-06-28 06:11:57 --> Helper loaded: language_helper
INFO - 2016-06-28 06:11:57 --> Helper loaded: url_helper
DEBUG - 2016-06-28 06:11:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-28 06:11:57 --> Model Class Initialized
INFO - 2016-06-28 06:11:57 --> Helper loaded: date_helper
INFO - 2016-06-28 06:11:57 --> Controller Class Initialized
INFO - 2016-06-28 06:11:57 --> Helper loaded: languages_helper
INFO - 2016-06-28 06:11:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-28 06:11:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-28 06:11:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-28 06:11:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-28 06:11:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-28 09:11:57 --> Model Class Initialized
INFO - 2016-06-28 09:11:57 --> Final output sent to browser
DEBUG - 2016-06-28 09:11:57 --> Total execution time: 0.0875
