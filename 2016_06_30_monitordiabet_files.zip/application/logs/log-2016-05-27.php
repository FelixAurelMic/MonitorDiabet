<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-27 10:31:01 --> Config Class Initialized
INFO - 2016-05-27 10:31:01 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:31:01 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:01 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:01 --> URI Class Initialized
INFO - 2016-05-27 10:31:01 --> Router Class Initialized
INFO - 2016-05-27 10:31:01 --> Output Class Initialized
INFO - 2016-05-27 10:31:01 --> Security Class Initialized
DEBUG - 2016-05-27 10:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:01 --> CSRF cookie sent
INFO - 2016-05-27 10:31:01 --> Input Class Initialized
INFO - 2016-05-27 10:31:01 --> Language Class Initialized
INFO - 2016-05-27 10:31:01 --> Loader Class Initialized
INFO - 2016-05-27 10:31:01 --> Helper loaded: form_helper
INFO - 2016-05-27 10:31:01 --> Database Driver Class Initialized
INFO - 2016-05-27 10:31:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:31:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:31:02 --> Email Class Initialized
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:31:02 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:31:02 --> Helper loaded: language_helper
INFO - 2016-05-27 10:31:02 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:02 --> Model Class Initialized
INFO - 2016-05-27 10:31:02 --> Helper loaded: date_helper
INFO - 2016-05-27 10:31:02 --> Controller Class Initialized
INFO - 2016-05-27 10:31:02 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:31:02 --> Model Class Initialized
INFO - 2016-05-27 10:31:02 --> Form Validation Class Initialized
INFO - 2016-05-27 10:31:02 --> Config Class Initialized
INFO - 2016-05-27 10:31:02 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:31:02 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:02 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:02 --> URI Class Initialized
INFO - 2016-05-27 10:31:02 --> Router Class Initialized
INFO - 2016-05-27 10:31:02 --> Output Class Initialized
INFO - 2016-05-27 10:31:02 --> Security Class Initialized
DEBUG - 2016-05-27 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:02 --> CSRF cookie sent
INFO - 2016-05-27 10:31:02 --> Input Class Initialized
INFO - 2016-05-27 10:31:02 --> Language Class Initialized
INFO - 2016-05-27 10:31:02 --> Loader Class Initialized
INFO - 2016-05-27 10:31:02 --> Helper loaded: form_helper
INFO - 2016-05-27 10:31:02 --> Database Driver Class Initialized
INFO - 2016-05-27 10:31:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:31:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:31:02 --> Email Class Initialized
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:31:02 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:31:02 --> Helper loaded: language_helper
INFO - 2016-05-27 10:31:02 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:31:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:02 --> Config Class Initialized
INFO - 2016-05-27 10:31:02 --> Model Class Initialized
INFO - 2016-05-27 10:31:02 --> Hooks Class Initialized
INFO - 2016-05-27 10:31:02 --> Helper loaded: date_helper
DEBUG - 2016-05-27 10:31:02 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:02 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:02 --> Controller Class Initialized
INFO - 2016-05-27 10:31:02 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:31:02 --> URI Class Initialized
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:31:02 --> Router Class Initialized
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:31:02 --> Output Class Initialized
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:31:02 --> Security Class Initialized
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/errors_generals_lang.php
DEBUG - 2016-05-27 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:31:02 --> CSRF cookie sent
DEBUG - 2016-05-27 10:31:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:02 --> Input Class Initialized
INFO - 2016-05-27 10:31:02 --> Language Class Initialized
INFO - 2016-05-27 10:31:02 --> Form Validation Class Initialized
INFO - 2016-05-27 10:31:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
ERROR - 2016-05-27 10:31:02 --> 404 Page Not Found: Faviconico/index
INFO - 2016-05-27 10:31:02 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-27 10:31:02 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-27 10:31:02 --> Final output sent to browser
DEBUG - 2016-05-27 10:31:02 --> Total execution time: 0.1797
INFO - 2016-05-27 10:31:15 --> Config Class Initialized
INFO - 2016-05-27 10:31:15 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:31:15 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:15 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:15 --> URI Class Initialized
INFO - 2016-05-27 10:31:15 --> Router Class Initialized
INFO - 2016-05-27 10:31:15 --> Output Class Initialized
INFO - 2016-05-27 10:31:15 --> Security Class Initialized
DEBUG - 2016-05-27 10:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:15 --> CSRF cookie sent
INFO - 2016-05-27 10:31:15 --> CSRF token verified
INFO - 2016-05-27 10:31:15 --> Input Class Initialized
INFO - 2016-05-27 10:31:15 --> Language Class Initialized
INFO - 2016-05-27 10:31:15 --> Loader Class Initialized
INFO - 2016-05-27 10:31:15 --> Helper loaded: form_helper
INFO - 2016-05-27 10:31:15 --> Database Driver Class Initialized
INFO - 2016-05-27 10:31:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:31:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:31:15 --> Email Class Initialized
INFO - 2016-05-27 10:31:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:31:15 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:31:15 --> Helper loaded: language_helper
INFO - 2016-05-27 10:31:15 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:31:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:15 --> Model Class Initialized
INFO - 2016-05-27 10:31:15 --> Helper loaded: date_helper
INFO - 2016-05-27 10:31:15 --> Controller Class Initialized
INFO - 2016-05-27 10:31:15 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:31:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:31:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:31:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:31:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:31:15 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-27 10:31:15 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:15 --> Form Validation Class Initialized
INFO - 2016-05-27 10:31:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-27 10:31:15 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-27 10:31:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-27 10:31:15 --> Final output sent to browser
DEBUG - 2016-05-27 10:31:15 --> Total execution time: 0.4734
INFO - 2016-05-27 10:31:31 --> Config Class Initialized
INFO - 2016-05-27 10:31:31 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:31:31 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:31 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:31 --> URI Class Initialized
INFO - 2016-05-27 10:31:31 --> Router Class Initialized
INFO - 2016-05-27 10:31:31 --> Output Class Initialized
INFO - 2016-05-27 10:31:31 --> Security Class Initialized
DEBUG - 2016-05-27 10:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:31 --> CSRF cookie sent
INFO - 2016-05-27 10:31:31 --> CSRF token verified
INFO - 2016-05-27 10:31:31 --> Input Class Initialized
INFO - 2016-05-27 10:31:31 --> Language Class Initialized
INFO - 2016-05-27 10:31:31 --> Loader Class Initialized
INFO - 2016-05-27 10:31:31 --> Helper loaded: form_helper
INFO - 2016-05-27 10:31:31 --> Database Driver Class Initialized
INFO - 2016-05-27 10:31:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:31:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:31:31 --> Email Class Initialized
INFO - 2016-05-27 10:31:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:31:31 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:31:31 --> Helper loaded: language_helper
INFO - 2016-05-27 10:31:31 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:31 --> Model Class Initialized
INFO - 2016-05-27 10:31:31 --> Helper loaded: date_helper
INFO - 2016-05-27 10:31:31 --> Controller Class Initialized
INFO - 2016-05-27 10:31:31 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:31:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:31:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:31:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:31:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:31:31 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-27 10:31:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:31 --> Form Validation Class Initialized
INFO - 2016-05-27 10:31:32 --> Config Class Initialized
INFO - 2016-05-27 10:31:32 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:31:32 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:32 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:32 --> URI Class Initialized
DEBUG - 2016-05-27 10:31:32 --> No URI present. Default controller set.
INFO - 2016-05-27 10:31:32 --> Router Class Initialized
INFO - 2016-05-27 10:31:32 --> Output Class Initialized
INFO - 2016-05-27 10:31:32 --> Security Class Initialized
DEBUG - 2016-05-27 10:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:32 --> CSRF cookie sent
INFO - 2016-05-27 10:31:32 --> Input Class Initialized
INFO - 2016-05-27 10:31:32 --> Language Class Initialized
INFO - 2016-05-27 10:31:32 --> Loader Class Initialized
INFO - 2016-05-27 10:31:32 --> Helper loaded: form_helper
INFO - 2016-05-27 10:31:32 --> Database Driver Class Initialized
INFO - 2016-05-27 10:31:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:31:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:31:32 --> Email Class Initialized
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:31:32 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:31:32 --> Helper loaded: language_helper
INFO - 2016-05-27 10:31:32 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:32 --> Model Class Initialized
INFO - 2016-05-27 10:31:32 --> Helper loaded: date_helper
INFO - 2016-05-27 10:31:32 --> Controller Class Initialized
INFO - 2016-05-27 10:31:32 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:31:32 --> Config Class Initialized
INFO - 2016-05-27 10:31:32 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:31:32 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:32 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:32 --> URI Class Initialized
INFO - 2016-05-27 10:31:32 --> Router Class Initialized
INFO - 2016-05-27 10:31:32 --> Output Class Initialized
INFO - 2016-05-27 10:31:32 --> Security Class Initialized
DEBUG - 2016-05-27 10:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:32 --> CSRF cookie sent
INFO - 2016-05-27 10:31:32 --> Input Class Initialized
INFO - 2016-05-27 10:31:32 --> Language Class Initialized
INFO - 2016-05-27 10:31:32 --> Loader Class Initialized
INFO - 2016-05-27 10:31:32 --> Helper loaded: form_helper
INFO - 2016-05-27 10:31:32 --> Database Driver Class Initialized
INFO - 2016-05-27 10:31:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:31:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:31:32 --> Email Class Initialized
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:31:32 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:31:32 --> Helper loaded: language_helper
INFO - 2016-05-27 10:31:32 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:32 --> Model Class Initialized
INFO - 2016-05-27 10:31:32 --> Helper loaded: date_helper
INFO - 2016-05-27 10:31:32 --> Controller Class Initialized
INFO - 2016-05-27 10:31:32 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:31:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:31:32 --> Model Class Initialized
INFO - 2016-05-27 10:31:32 --> Form Validation Class Initialized
INFO - 2016-05-27 10:31:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 10:31:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:31:33 --> Final output sent to browser
DEBUG - 2016-05-27 10:31:33 --> Total execution time: 0.3869
INFO - 2016-05-27 10:31:37 --> Config Class Initialized
INFO - 2016-05-27 10:31:37 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:31:37 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:31:37 --> Utf8 Class Initialized
INFO - 2016-05-27 10:31:37 --> URI Class Initialized
INFO - 2016-05-27 10:31:37 --> Router Class Initialized
INFO - 2016-05-27 10:31:37 --> Output Class Initialized
INFO - 2016-05-27 10:31:37 --> Security Class Initialized
DEBUG - 2016-05-27 10:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:31:37 --> CSRF cookie sent
INFO - 2016-05-27 10:31:37 --> Input Class Initialized
INFO - 2016-05-27 10:31:37 --> Language Class Initialized
INFO - 2016-05-27 10:31:37 --> Loader Class Initialized
INFO - 2016-05-27 10:31:37 --> Helper loaded: form_helper
INFO - 2016-05-27 10:31:37 --> Database Driver Class Initialized
INFO - 2016-05-27 10:31:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:31:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:31:37 --> Email Class Initialized
INFO - 2016-05-27 10:31:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:31:37 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:31:37 --> Helper loaded: language_helper
INFO - 2016-05-27 10:31:37 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:31:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:31:37 --> Model Class Initialized
INFO - 2016-05-27 10:31:37 --> Helper loaded: date_helper
INFO - 2016-05-27 10:31:37 --> Controller Class Initialized
INFO - 2016-05-27 10:31:37 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:31:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:31:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:31:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:31:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:31:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:31:37 --> Model Class Initialized
INFO - 2016-05-27 10:31:37 --> Form Validation Class Initialized
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_1 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_1 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_2 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_2 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_3 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_3 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_4 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_4 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_5 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_5 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_6 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_6 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_7 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_7 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_8 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_8 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_9 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_9 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_10 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:31:37 --> Severity: Notice --> Undefined variable: interval_10 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 34
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:31:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:31:37 --> Final output sent to browser
DEBUG - 2016-05-27 10:31:37 --> Total execution time: 0.1317
INFO - 2016-05-27 10:33:43 --> Config Class Initialized
INFO - 2016-05-27 10:33:43 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:33:43 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:33:43 --> Utf8 Class Initialized
INFO - 2016-05-27 10:33:43 --> URI Class Initialized
INFO - 2016-05-27 10:33:43 --> Router Class Initialized
INFO - 2016-05-27 10:33:43 --> Output Class Initialized
INFO - 2016-05-27 10:33:43 --> Security Class Initialized
DEBUG - 2016-05-27 10:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:33:43 --> CSRF cookie sent
INFO - 2016-05-27 10:33:43 --> Input Class Initialized
INFO - 2016-05-27 10:33:43 --> Language Class Initialized
INFO - 2016-05-27 10:33:43 --> Loader Class Initialized
INFO - 2016-05-27 10:33:43 --> Helper loaded: form_helper
INFO - 2016-05-27 10:33:43 --> Database Driver Class Initialized
INFO - 2016-05-27 10:33:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:33:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:33:43 --> Email Class Initialized
INFO - 2016-05-27 10:33:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:33:43 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:33:43 --> Helper loaded: language_helper
INFO - 2016-05-27 10:33:43 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:33:43 --> Model Class Initialized
INFO - 2016-05-27 10:33:43 --> Helper loaded: date_helper
INFO - 2016-05-27 10:33:43 --> Controller Class Initialized
INFO - 2016-05-27 10:33:43 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:33:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:33:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:33:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:33:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:33:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:33:43 --> Model Class Initialized
INFO - 2016-05-27 10:33:43 --> Form Validation Class Initialized
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_1 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_2 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_3 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_4 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_5 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_6 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_7 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_8 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_9 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:33:43 --> Severity: Notice --> Undefined variable: interval_10 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:33:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:33:43 --> Final output sent to browser
DEBUG - 2016-05-27 10:33:43 --> Total execution time: 0.0411
INFO - 2016-05-27 10:34:04 --> Config Class Initialized
INFO - 2016-05-27 10:34:04 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:34:04 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:34:04 --> Utf8 Class Initialized
INFO - 2016-05-27 10:34:04 --> URI Class Initialized
INFO - 2016-05-27 10:34:04 --> Router Class Initialized
INFO - 2016-05-27 10:34:04 --> Output Class Initialized
INFO - 2016-05-27 10:34:04 --> Security Class Initialized
DEBUG - 2016-05-27 10:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:34:04 --> CSRF cookie sent
INFO - 2016-05-27 10:34:04 --> Input Class Initialized
INFO - 2016-05-27 10:34:04 --> Language Class Initialized
INFO - 2016-05-27 10:34:04 --> Loader Class Initialized
INFO - 2016-05-27 10:34:04 --> Helper loaded: form_helper
INFO - 2016-05-27 10:34:04 --> Database Driver Class Initialized
INFO - 2016-05-27 10:34:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:34:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:34:04 --> Email Class Initialized
INFO - 2016-05-27 10:34:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:34:04 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:34:04 --> Helper loaded: language_helper
INFO - 2016-05-27 10:34:04 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:34:04 --> Model Class Initialized
INFO - 2016-05-27 10:34:04 --> Helper loaded: date_helper
INFO - 2016-05-27 10:34:04 --> Controller Class Initialized
INFO - 2016-05-27 10:34:04 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:34:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:34:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:34:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:34:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:34:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:34:04 --> Model Class Initialized
INFO - 2016-05-27 10:34:04 --> Form Validation Class Initialized
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_1 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_2 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_3 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_4 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_5 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_6 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_7 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_8 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_9 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:34:04 --> Severity: Notice --> Undefined variable: interval_10 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:34:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:34:04 --> Final output sent to browser
DEBUG - 2016-05-27 10:34:04 --> Total execution time: 0.0377
INFO - 2016-05-27 10:38:35 --> Config Class Initialized
INFO - 2016-05-27 10:38:35 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:38:35 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:38:35 --> Utf8 Class Initialized
INFO - 2016-05-27 10:38:35 --> URI Class Initialized
INFO - 2016-05-27 10:38:35 --> Router Class Initialized
INFO - 2016-05-27 10:38:35 --> Output Class Initialized
INFO - 2016-05-27 10:38:35 --> Security Class Initialized
DEBUG - 2016-05-27 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:38:35 --> CSRF cookie sent
INFO - 2016-05-27 10:38:35 --> Input Class Initialized
INFO - 2016-05-27 10:38:35 --> Language Class Initialized
INFO - 2016-05-27 10:38:35 --> Loader Class Initialized
INFO - 2016-05-27 10:38:35 --> Helper loaded: form_helper
INFO - 2016-05-27 10:38:35 --> Database Driver Class Initialized
INFO - 2016-05-27 10:38:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:38:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:38:35 --> Email Class Initialized
INFO - 2016-05-27 10:38:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:38:35 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:38:35 --> Helper loaded: language_helper
INFO - 2016-05-27 10:38:35 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:38:35 --> Model Class Initialized
INFO - 2016-05-27 10:38:35 --> Helper loaded: date_helper
INFO - 2016-05-27 10:38:35 --> Controller Class Initialized
INFO - 2016-05-27 10:38:35 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:38:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:38:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:38:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:38:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:38:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:38:35 --> Model Class Initialized
INFO - 2016-05-27 10:38:35 --> Form Validation Class Initialized
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:38:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:38:35 --> Final output sent to browser
DEBUG - 2016-05-27 10:38:35 --> Total execution time: 0.0472
INFO - 2016-05-27 10:40:16 --> Config Class Initialized
INFO - 2016-05-27 10:40:16 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:40:16 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:40:16 --> Utf8 Class Initialized
INFO - 2016-05-27 10:40:16 --> URI Class Initialized
INFO - 2016-05-27 10:40:16 --> Router Class Initialized
INFO - 2016-05-27 10:40:16 --> Output Class Initialized
INFO - 2016-05-27 10:40:16 --> Security Class Initialized
DEBUG - 2016-05-27 10:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:40:16 --> CSRF cookie sent
INFO - 2016-05-27 10:40:16 --> CSRF token verified
INFO - 2016-05-27 10:40:16 --> Input Class Initialized
INFO - 2016-05-27 10:40:16 --> Language Class Initialized
INFO - 2016-05-27 10:40:16 --> Loader Class Initialized
INFO - 2016-05-27 10:40:16 --> Helper loaded: form_helper
INFO - 2016-05-27 10:40:16 --> Database Driver Class Initialized
INFO - 2016-05-27 10:40:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:40:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:40:16 --> Email Class Initialized
INFO - 2016-05-27 10:40:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:40:16 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:40:16 --> Helper loaded: language_helper
INFO - 2016-05-27 10:40:16 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:40:16 --> Model Class Initialized
INFO - 2016-05-27 10:40:16 --> Helper loaded: date_helper
INFO - 2016-05-27 10:40:16 --> Controller Class Initialized
INFO - 2016-05-27 10:40:16 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:40:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:40:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:40:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:40:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:40:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:40:16 --> Model Class Initialized
INFO - 2016-05-27 10:40:16 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:40:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:40:17 --> Config Class Initialized
INFO - 2016-05-27 10:40:17 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:40:17 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:40:17 --> Utf8 Class Initialized
INFO - 2016-05-27 10:40:17 --> URI Class Initialized
INFO - 2016-05-27 10:40:17 --> Router Class Initialized
INFO - 2016-05-27 10:40:17 --> Output Class Initialized
INFO - 2016-05-27 10:40:17 --> Security Class Initialized
DEBUG - 2016-05-27 10:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:40:17 --> CSRF cookie sent
INFO - 2016-05-27 10:40:17 --> Input Class Initialized
INFO - 2016-05-27 10:40:17 --> Language Class Initialized
INFO - 2016-05-27 10:40:17 --> Loader Class Initialized
INFO - 2016-05-27 10:40:17 --> Helper loaded: form_helper
INFO - 2016-05-27 10:40:17 --> Database Driver Class Initialized
INFO - 2016-05-27 10:40:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:40:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:40:17 --> Email Class Initialized
INFO - 2016-05-27 10:40:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:40:17 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:40:17 --> Helper loaded: language_helper
INFO - 2016-05-27 10:40:17 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:40:17 --> Model Class Initialized
INFO - 2016-05-27 10:40:17 --> Helper loaded: date_helper
INFO - 2016-05-27 10:40:17 --> Controller Class Initialized
INFO - 2016-05-27 10:40:17 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:40:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:40:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:40:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:40:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:40:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:40:17 --> Model Class Initialized
INFO - 2016-05-27 10:40:17 --> Form Validation Class Initialized
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 10:40:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:40:17 --> Final output sent to browser
DEBUG - 2016-05-27 10:40:17 --> Total execution time: 0.0578
INFO - 2016-05-27 10:40:22 --> Config Class Initialized
INFO - 2016-05-27 10:40:22 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:40:22 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:40:22 --> Utf8 Class Initialized
INFO - 2016-05-27 10:40:22 --> URI Class Initialized
INFO - 2016-05-27 10:40:22 --> Router Class Initialized
INFO - 2016-05-27 10:40:22 --> Output Class Initialized
INFO - 2016-05-27 10:40:22 --> Security Class Initialized
DEBUG - 2016-05-27 10:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:40:22 --> CSRF cookie sent
INFO - 2016-05-27 10:40:22 --> Input Class Initialized
INFO - 2016-05-27 10:40:22 --> Language Class Initialized
INFO - 2016-05-27 10:40:22 --> Loader Class Initialized
INFO - 2016-05-27 10:40:22 --> Helper loaded: form_helper
INFO - 2016-05-27 10:40:22 --> Database Driver Class Initialized
INFO - 2016-05-27 10:40:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:40:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:40:22 --> Email Class Initialized
INFO - 2016-05-27 10:40:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:40:22 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:40:22 --> Helper loaded: language_helper
INFO - 2016-05-27 10:40:22 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:40:22 --> Model Class Initialized
INFO - 2016-05-27 10:40:22 --> Helper loaded: date_helper
INFO - 2016-05-27 10:40:22 --> Controller Class Initialized
INFO - 2016-05-27 10:40:22 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:40:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:40:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:40:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:40:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:40:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:40:22 --> Model Class Initialized
INFO - 2016-05-27 10:40:22 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:40:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
ERROR - 2016-05-27 10:40:22 --> Severity: Notice --> Undefined variable: glucose_values /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 33
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:40:22 --> Final output sent to browser
DEBUG - 2016-05-27 10:40:22 --> Total execution time: 0.1374
INFO - 2016-05-27 10:40:46 --> Config Class Initialized
INFO - 2016-05-27 10:40:46 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:40:46 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:40:46 --> Utf8 Class Initialized
INFO - 2016-05-27 10:40:46 --> URI Class Initialized
INFO - 2016-05-27 10:40:46 --> Router Class Initialized
INFO - 2016-05-27 10:40:46 --> Output Class Initialized
INFO - 2016-05-27 10:40:46 --> Security Class Initialized
DEBUG - 2016-05-27 10:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:40:46 --> CSRF cookie sent
INFO - 2016-05-27 10:40:46 --> Input Class Initialized
INFO - 2016-05-27 10:40:46 --> Language Class Initialized
INFO - 2016-05-27 10:40:46 --> Loader Class Initialized
INFO - 2016-05-27 10:40:46 --> Helper loaded: form_helper
INFO - 2016-05-27 10:40:46 --> Database Driver Class Initialized
INFO - 2016-05-27 10:40:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:40:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:40:46 --> Email Class Initialized
INFO - 2016-05-27 10:40:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:40:46 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:40:46 --> Helper loaded: language_helper
INFO - 2016-05-27 10:40:46 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:40:46 --> Model Class Initialized
INFO - 2016-05-27 10:40:46 --> Helper loaded: date_helper
INFO - 2016-05-27 10:40:46 --> Controller Class Initialized
INFO - 2016-05-27 10:40:46 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:40:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:40:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:40:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:40:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:40:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:40:46 --> Model Class Initialized
INFO - 2016-05-27 10:40:46 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:40:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:40:46 --> Final output sent to browser
DEBUG - 2016-05-27 10:40:46 --> Total execution time: 0.0501
INFO - 2016-05-27 10:49:44 --> Config Class Initialized
INFO - 2016-05-27 10:49:44 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:49:44 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:49:44 --> Utf8 Class Initialized
INFO - 2016-05-27 10:49:44 --> URI Class Initialized
INFO - 2016-05-27 10:49:44 --> Router Class Initialized
INFO - 2016-05-27 10:49:44 --> Output Class Initialized
INFO - 2016-05-27 10:49:44 --> Security Class Initialized
DEBUG - 2016-05-27 10:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:49:44 --> CSRF cookie sent
INFO - 2016-05-27 10:49:44 --> Input Class Initialized
INFO - 2016-05-27 10:49:44 --> Language Class Initialized
INFO - 2016-05-27 10:49:44 --> Loader Class Initialized
INFO - 2016-05-27 10:49:44 --> Helper loaded: form_helper
INFO - 2016-05-27 10:49:44 --> Database Driver Class Initialized
INFO - 2016-05-27 10:49:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:49:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:49:44 --> Email Class Initialized
INFO - 2016-05-27 10:49:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:49:44 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:49:44 --> Helper loaded: language_helper
INFO - 2016-05-27 10:49:44 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:49:44 --> Model Class Initialized
INFO - 2016-05-27 10:49:44 --> Helper loaded: date_helper
INFO - 2016-05-27 10:49:44 --> Controller Class Initialized
INFO - 2016-05-27 10:49:44 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:49:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:49:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:49:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:49:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:49:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:49:44 --> Model Class Initialized
INFO - 2016-05-27 10:49:44 --> Form Validation Class Initialized
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:49:44 --> Final output sent to browser
DEBUG - 2016-05-27 10:49:44 --> Total execution time: 0.0682
INFO - 2016-05-27 10:50:47 --> Config Class Initialized
INFO - 2016-05-27 10:50:47 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:50:47 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:50:47 --> Utf8 Class Initialized
INFO - 2016-05-27 10:50:47 --> URI Class Initialized
INFO - 2016-05-27 10:50:47 --> Router Class Initialized
INFO - 2016-05-27 10:50:47 --> Output Class Initialized
INFO - 2016-05-27 10:50:47 --> Security Class Initialized
DEBUG - 2016-05-27 10:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:50:47 --> CSRF cookie sent
INFO - 2016-05-27 10:50:47 --> CSRF token verified
INFO - 2016-05-27 10:50:47 --> Input Class Initialized
INFO - 2016-05-27 10:50:47 --> Language Class Initialized
INFO - 2016-05-27 10:50:47 --> Loader Class Initialized
INFO - 2016-05-27 10:50:47 --> Helper loaded: form_helper
INFO - 2016-05-27 10:50:47 --> Database Driver Class Initialized
INFO - 2016-05-27 10:50:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:50:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:50:47 --> Email Class Initialized
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:50:47 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:50:47 --> Helper loaded: language_helper
INFO - 2016-05-27 10:50:47 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:50:47 --> Model Class Initialized
INFO - 2016-05-27 10:50:47 --> Helper loaded: date_helper
INFO - 2016-05-27 10:50:47 --> Controller Class Initialized
INFO - 2016-05-27 10:50:47 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:50:47 --> Model Class Initialized
INFO - 2016-05-27 10:50:47 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:50:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:50:47 --> Config Class Initialized
INFO - 2016-05-27 10:50:47 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:50:47 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:50:47 --> Utf8 Class Initialized
INFO - 2016-05-27 10:50:47 --> URI Class Initialized
INFO - 2016-05-27 10:50:47 --> Router Class Initialized
INFO - 2016-05-27 10:50:47 --> Output Class Initialized
INFO - 2016-05-27 10:50:47 --> Security Class Initialized
DEBUG - 2016-05-27 10:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:50:47 --> CSRF cookie sent
INFO - 2016-05-27 10:50:47 --> Input Class Initialized
INFO - 2016-05-27 10:50:47 --> Language Class Initialized
INFO - 2016-05-27 10:50:47 --> Loader Class Initialized
INFO - 2016-05-27 10:50:47 --> Helper loaded: form_helper
INFO - 2016-05-27 10:50:47 --> Database Driver Class Initialized
INFO - 2016-05-27 10:50:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:50:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:50:47 --> Email Class Initialized
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:50:47 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:50:47 --> Helper loaded: language_helper
INFO - 2016-05-27 10:50:47 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:50:47 --> Model Class Initialized
INFO - 2016-05-27 10:50:47 --> Helper loaded: date_helper
INFO - 2016-05-27 10:50:47 --> Controller Class Initialized
INFO - 2016-05-27 10:50:47 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:50:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:50:47 --> Model Class Initialized
INFO - 2016-05-27 10:50:47 --> Form Validation Class Initialized
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 10:50:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:50:47 --> Final output sent to browser
DEBUG - 2016-05-27 10:50:47 --> Total execution time: 0.0191
INFO - 2016-05-27 10:50:50 --> Config Class Initialized
INFO - 2016-05-27 10:50:50 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:50:50 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:50:50 --> Utf8 Class Initialized
INFO - 2016-05-27 10:50:50 --> URI Class Initialized
INFO - 2016-05-27 10:50:50 --> Router Class Initialized
INFO - 2016-05-27 10:50:50 --> Output Class Initialized
INFO - 2016-05-27 10:50:50 --> Security Class Initialized
DEBUG - 2016-05-27 10:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:50:50 --> CSRF cookie sent
INFO - 2016-05-27 10:50:50 --> Input Class Initialized
INFO - 2016-05-27 10:50:50 --> Language Class Initialized
INFO - 2016-05-27 10:50:50 --> Loader Class Initialized
INFO - 2016-05-27 10:50:50 --> Helper loaded: form_helper
INFO - 2016-05-27 10:50:50 --> Database Driver Class Initialized
INFO - 2016-05-27 10:50:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:50:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:50:50 --> Email Class Initialized
INFO - 2016-05-27 10:50:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:50:50 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:50:50 --> Helper loaded: language_helper
INFO - 2016-05-27 10:50:50 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:50:50 --> Model Class Initialized
INFO - 2016-05-27 10:50:50 --> Helper loaded: date_helper
INFO - 2016-05-27 10:50:50 --> Controller Class Initialized
INFO - 2016-05-27 10:50:50 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:50:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:50:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:50:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:50:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:50:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:50:50 --> Model Class Initialized
INFO - 2016-05-27 10:50:51 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:50:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:50:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:50:51 --> Final output sent to browser
DEBUG - 2016-05-27 10:50:51 --> Total execution time: 0.0823
INFO - 2016-05-27 10:52:05 --> Config Class Initialized
INFO - 2016-05-27 10:52:05 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:52:05 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:52:05 --> Utf8 Class Initialized
INFO - 2016-05-27 10:52:05 --> URI Class Initialized
INFO - 2016-05-27 10:52:05 --> Router Class Initialized
INFO - 2016-05-27 10:52:05 --> Output Class Initialized
INFO - 2016-05-27 10:52:05 --> Security Class Initialized
DEBUG - 2016-05-27 10:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:52:05 --> CSRF cookie sent
INFO - 2016-05-27 10:52:05 --> Input Class Initialized
INFO - 2016-05-27 10:52:05 --> Language Class Initialized
INFO - 2016-05-27 10:52:05 --> Loader Class Initialized
INFO - 2016-05-27 10:52:05 --> Helper loaded: form_helper
INFO - 2016-05-27 10:52:05 --> Database Driver Class Initialized
INFO - 2016-05-27 10:52:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:52:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:52:05 --> Email Class Initialized
INFO - 2016-05-27 10:52:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:52:05 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:52:05 --> Helper loaded: language_helper
INFO - 2016-05-27 10:52:05 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:52:05 --> Model Class Initialized
INFO - 2016-05-27 10:52:05 --> Helper loaded: date_helper
INFO - 2016-05-27 10:52:05 --> Controller Class Initialized
INFO - 2016-05-27 10:52:05 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:52:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:52:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:52:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:52:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:52:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:52:05 --> Model Class Initialized
INFO - 2016-05-27 10:52:05 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:52:05 --> Severity: Notice --> Undefined variable: notes /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 6
INFO - 2016-05-27 10:52:14 --> Config Class Initialized
INFO - 2016-05-27 10:52:14 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:52:14 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:52:14 --> Utf8 Class Initialized
INFO - 2016-05-27 10:52:14 --> URI Class Initialized
INFO - 2016-05-27 10:52:14 --> Router Class Initialized
INFO - 2016-05-27 10:52:14 --> Output Class Initialized
INFO - 2016-05-27 10:52:14 --> Security Class Initialized
DEBUG - 2016-05-27 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:52:14 --> CSRF cookie sent
INFO - 2016-05-27 10:52:14 --> Input Class Initialized
INFO - 2016-05-27 10:52:14 --> Language Class Initialized
INFO - 2016-05-27 10:52:14 --> Loader Class Initialized
INFO - 2016-05-27 10:52:14 --> Helper loaded: form_helper
INFO - 2016-05-27 10:52:14 --> Database Driver Class Initialized
INFO - 2016-05-27 10:52:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:52:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:52:14 --> Email Class Initialized
INFO - 2016-05-27 10:52:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:52:14 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:52:14 --> Helper loaded: language_helper
INFO - 2016-05-27 10:52:14 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:52:14 --> Model Class Initialized
INFO - 2016-05-27 10:52:14 --> Helper loaded: date_helper
INFO - 2016-05-27 10:52:14 --> Controller Class Initialized
INFO - 2016-05-27 10:52:14 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:52:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:52:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:52:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:52:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:52:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:52:14 --> Model Class Initialized
INFO - 2016-05-27 10:52:14 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:52:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:52:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:52:14 --> Severity: Notice --> Undefined variable: notes /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 6
INFO - 2016-05-27 10:52:49 --> Config Class Initialized
INFO - 2016-05-27 10:52:49 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:52:49 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:52:49 --> Utf8 Class Initialized
INFO - 2016-05-27 10:52:49 --> URI Class Initialized
INFO - 2016-05-27 10:52:49 --> Router Class Initialized
INFO - 2016-05-27 10:52:49 --> Output Class Initialized
INFO - 2016-05-27 10:52:49 --> Security Class Initialized
DEBUG - 2016-05-27 10:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:52:49 --> CSRF cookie sent
INFO - 2016-05-27 10:52:49 --> Input Class Initialized
INFO - 2016-05-27 10:52:49 --> Language Class Initialized
INFO - 2016-05-27 10:52:49 --> Loader Class Initialized
INFO - 2016-05-27 10:52:49 --> Helper loaded: form_helper
INFO - 2016-05-27 10:52:49 --> Database Driver Class Initialized
INFO - 2016-05-27 10:52:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:52:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:52:49 --> Email Class Initialized
INFO - 2016-05-27 10:52:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:52:49 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:52:49 --> Helper loaded: language_helper
INFO - 2016-05-27 10:52:49 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:52:49 --> Model Class Initialized
INFO - 2016-05-27 10:52:49 --> Helper loaded: date_helper
INFO - 2016-05-27 10:52:49 --> Controller Class Initialized
INFO - 2016-05-27 10:52:49 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:52:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:52:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:52:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:52:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:52:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:52:49 --> Model Class Initialized
INFO - 2016-05-27 10:52:49 --> Form Validation Class Initialized
INFO - 2016-05-27 10:53:36 --> Config Class Initialized
INFO - 2016-05-27 10:53:36 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:53:36 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:53:36 --> Utf8 Class Initialized
INFO - 2016-05-27 10:53:36 --> URI Class Initialized
INFO - 2016-05-27 10:53:36 --> Router Class Initialized
INFO - 2016-05-27 10:53:36 --> Output Class Initialized
INFO - 2016-05-27 10:53:36 --> Security Class Initialized
DEBUG - 2016-05-27 10:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:53:36 --> CSRF cookie sent
INFO - 2016-05-27 10:53:36 --> Input Class Initialized
INFO - 2016-05-27 10:53:36 --> Language Class Initialized
INFO - 2016-05-27 10:53:36 --> Loader Class Initialized
INFO - 2016-05-27 10:53:36 --> Helper loaded: form_helper
INFO - 2016-05-27 10:53:36 --> Database Driver Class Initialized
INFO - 2016-05-27 10:53:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:53:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:53:36 --> Email Class Initialized
INFO - 2016-05-27 10:53:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:53:36 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:53:36 --> Helper loaded: language_helper
INFO - 2016-05-27 10:53:36 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:53:36 --> Model Class Initialized
INFO - 2016-05-27 10:53:36 --> Helper loaded: date_helper
INFO - 2016-05-27 10:53:36 --> Controller Class Initialized
INFO - 2016-05-27 10:53:36 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:53:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:53:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:53:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:53:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:53:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:53:36 --> Model Class Initialized
INFO - 2016-05-27 10:53:36 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:53:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:53:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:53:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:53:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:53:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:53:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:53:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:53:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:53:36 --> Severity: Notice --> Undefined variable: notes /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 6
INFO - 2016-05-27 10:53:53 --> Config Class Initialized
INFO - 2016-05-27 10:53:53 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:53:53 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:53:53 --> Utf8 Class Initialized
INFO - 2016-05-27 10:53:53 --> URI Class Initialized
INFO - 2016-05-27 10:53:53 --> Router Class Initialized
INFO - 2016-05-27 10:53:53 --> Output Class Initialized
INFO - 2016-05-27 10:53:53 --> Security Class Initialized
DEBUG - 2016-05-27 10:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:53:53 --> CSRF cookie sent
INFO - 2016-05-27 10:53:53 --> Input Class Initialized
INFO - 2016-05-27 10:53:53 --> Language Class Initialized
INFO - 2016-05-27 10:53:53 --> Loader Class Initialized
INFO - 2016-05-27 10:53:53 --> Helper loaded: form_helper
INFO - 2016-05-27 10:53:53 --> Database Driver Class Initialized
INFO - 2016-05-27 10:53:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:53:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:53:53 --> Email Class Initialized
INFO - 2016-05-27 10:53:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:53:53 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:53:53 --> Helper loaded: language_helper
INFO - 2016-05-27 10:53:53 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:53:53 --> Model Class Initialized
INFO - 2016-05-27 10:53:53 --> Helper loaded: date_helper
INFO - 2016-05-27 10:53:53 --> Controller Class Initialized
INFO - 2016-05-27 10:53:53 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:53:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:53:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:53:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:53:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:53:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:53:53 --> Model Class Initialized
INFO - 2016-05-27 10:53:53 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:53:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:53:53 --> Severity: Notice --> Undefined variable: notes /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 6
INFO - 2016-05-27 10:54:21 --> Config Class Initialized
INFO - 2016-05-27 10:54:21 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:54:21 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:54:21 --> Utf8 Class Initialized
INFO - 2016-05-27 10:54:21 --> URI Class Initialized
INFO - 2016-05-27 10:54:21 --> Router Class Initialized
INFO - 2016-05-27 10:54:21 --> Output Class Initialized
INFO - 2016-05-27 10:54:21 --> Security Class Initialized
DEBUG - 2016-05-27 10:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:54:21 --> CSRF cookie sent
INFO - 2016-05-27 10:54:21 --> Input Class Initialized
INFO - 2016-05-27 10:54:21 --> Language Class Initialized
INFO - 2016-05-27 10:54:21 --> Loader Class Initialized
INFO - 2016-05-27 10:54:21 --> Helper loaded: form_helper
INFO - 2016-05-27 10:54:21 --> Database Driver Class Initialized
INFO - 2016-05-27 10:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:54:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:54:21 --> Email Class Initialized
INFO - 2016-05-27 10:54:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:54:21 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:54:21 --> Helper loaded: language_helper
INFO - 2016-05-27 10:54:21 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:54:21 --> Model Class Initialized
INFO - 2016-05-27 10:54:21 --> Helper loaded: date_helper
INFO - 2016-05-27 10:54:21 --> Controller Class Initialized
INFO - 2016-05-27 10:54:21 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:54:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:54:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:54:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:54:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:54:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:54:21 --> Model Class Initialized
INFO - 2016-05-27 10:54:21 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:54:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:54:39 --> Config Class Initialized
INFO - 2016-05-27 10:54:39 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:54:39 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:54:39 --> Utf8 Class Initialized
INFO - 2016-05-27 10:54:39 --> URI Class Initialized
INFO - 2016-05-27 10:54:39 --> Router Class Initialized
INFO - 2016-05-27 10:54:39 --> Output Class Initialized
INFO - 2016-05-27 10:54:39 --> Security Class Initialized
DEBUG - 2016-05-27 10:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:54:39 --> CSRF cookie sent
INFO - 2016-05-27 10:54:39 --> Input Class Initialized
INFO - 2016-05-27 10:54:39 --> Language Class Initialized
INFO - 2016-05-27 10:54:39 --> Loader Class Initialized
INFO - 2016-05-27 10:54:39 --> Helper loaded: form_helper
INFO - 2016-05-27 10:54:39 --> Database Driver Class Initialized
INFO - 2016-05-27 10:54:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:54:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:54:39 --> Email Class Initialized
INFO - 2016-05-27 10:54:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:54:39 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:54:39 --> Helper loaded: language_helper
INFO - 2016-05-27 10:54:39 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:54:39 --> Model Class Initialized
INFO - 2016-05-27 10:54:39 --> Helper loaded: date_helper
INFO - 2016-05-27 10:54:39 --> Controller Class Initialized
INFO - 2016-05-27 10:54:39 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:54:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:54:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:54:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:54:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:54:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:54:39 --> Model Class Initialized
INFO - 2016-05-27 10:54:39 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:54:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:54:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 10:56:47 --> Config Class Initialized
INFO - 2016-05-27 10:56:47 --> Hooks Class Initialized
DEBUG - 2016-05-27 10:56:47 --> UTF-8 Support Enabled
INFO - 2016-05-27 10:56:47 --> Utf8 Class Initialized
INFO - 2016-05-27 10:56:47 --> URI Class Initialized
INFO - 2016-05-27 10:56:47 --> Router Class Initialized
INFO - 2016-05-27 10:56:47 --> Output Class Initialized
INFO - 2016-05-27 10:56:47 --> Security Class Initialized
DEBUG - 2016-05-27 10:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 10:56:47 --> CSRF cookie sent
INFO - 2016-05-27 10:56:47 --> Input Class Initialized
INFO - 2016-05-27 10:56:47 --> Language Class Initialized
INFO - 2016-05-27 10:56:47 --> Loader Class Initialized
INFO - 2016-05-27 10:56:47 --> Helper loaded: form_helper
INFO - 2016-05-27 10:56:47 --> Database Driver Class Initialized
INFO - 2016-05-27 10:56:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 10:56:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 10:56:47 --> Email Class Initialized
INFO - 2016-05-27 10:56:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 10:56:47 --> Helper loaded: cookie_helper
INFO - 2016-05-27 10:56:47 --> Helper loaded: language_helper
INFO - 2016-05-27 10:56:47 --> Helper loaded: url_helper
DEBUG - 2016-05-27 10:56:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:56:47 --> Model Class Initialized
INFO - 2016-05-27 10:56:47 --> Helper loaded: date_helper
INFO - 2016-05-27 10:56:47 --> Controller Class Initialized
INFO - 2016-05-27 10:56:47 --> Helper loaded: languages_helper
INFO - 2016-05-27 10:56:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 10:56:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 10:56:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 10:56:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 10:56:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 10:56:47 --> Model Class Initialized
INFO - 2016-05-27 10:56:47 --> Form Validation Class Initialized
DEBUG - 2016-05-27 10:56:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_1 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_2 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_3 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_4 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_5 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_6 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_7 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_8 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_9 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 10:56:47 --> Severity: Notice --> Undefined property: stdClass::$interval_10 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 10:56:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 10:56:47 --> Final output sent to browser
DEBUG - 2016-05-27 10:56:47 --> Total execution time: 0.0385
INFO - 2016-05-27 11:00:18 --> Config Class Initialized
INFO - 2016-05-27 11:00:18 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:00:18 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:00:18 --> Utf8 Class Initialized
INFO - 2016-05-27 11:00:18 --> URI Class Initialized
INFO - 2016-05-27 11:00:18 --> Router Class Initialized
INFO - 2016-05-27 11:00:18 --> Output Class Initialized
INFO - 2016-05-27 11:00:18 --> Security Class Initialized
DEBUG - 2016-05-27 11:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:00:18 --> CSRF cookie sent
INFO - 2016-05-27 11:00:18 --> Input Class Initialized
INFO - 2016-05-27 11:00:18 --> Language Class Initialized
INFO - 2016-05-27 11:00:18 --> Loader Class Initialized
INFO - 2016-05-27 11:00:18 --> Helper loaded: form_helper
INFO - 2016-05-27 11:00:18 --> Database Driver Class Initialized
INFO - 2016-05-27 11:00:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:00:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:00:18 --> Email Class Initialized
INFO - 2016-05-27 11:00:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:00:18 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:00:18 --> Helper loaded: language_helper
INFO - 2016-05-27 11:00:18 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:00:18 --> Model Class Initialized
INFO - 2016-05-27 11:00:18 --> Helper loaded: date_helper
INFO - 2016-05-27 11:00:18 --> Controller Class Initialized
INFO - 2016-05-27 11:00:18 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:00:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:00:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:00:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:00:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:00:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:00:18 --> Model Class Initialized
INFO - 2016-05-27 11:00:18 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:00:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_1 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_2 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_3 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_4 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_5 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_6 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_7 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_8 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_9 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:00:18 --> Severity: Notice --> Undefined property: stdClass::$interval_10 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:00:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:00:18 --> Final output sent to browser
DEBUG - 2016-05-27 11:00:18 --> Total execution time: 0.2315
INFO - 2016-05-27 11:00:35 --> Config Class Initialized
INFO - 2016-05-27 11:00:35 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:00:35 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:00:35 --> Utf8 Class Initialized
INFO - 2016-05-27 11:00:35 --> URI Class Initialized
INFO - 2016-05-27 11:00:35 --> Router Class Initialized
INFO - 2016-05-27 11:00:35 --> Output Class Initialized
INFO - 2016-05-27 11:00:35 --> Security Class Initialized
DEBUG - 2016-05-27 11:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:00:35 --> CSRF cookie sent
INFO - 2016-05-27 11:00:35 --> Input Class Initialized
INFO - 2016-05-27 11:00:35 --> Language Class Initialized
INFO - 2016-05-27 11:00:35 --> Loader Class Initialized
INFO - 2016-05-27 11:00:35 --> Helper loaded: form_helper
INFO - 2016-05-27 11:00:35 --> Database Driver Class Initialized
INFO - 2016-05-27 11:00:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:00:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:00:35 --> Email Class Initialized
INFO - 2016-05-27 11:00:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:00:35 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:00:35 --> Helper loaded: language_helper
INFO - 2016-05-27 11:00:35 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:00:35 --> Model Class Initialized
INFO - 2016-05-27 11:00:35 --> Helper loaded: date_helper
INFO - 2016-05-27 11:00:35 --> Controller Class Initialized
INFO - 2016-05-27 11:00:35 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:00:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:00:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:00:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:00:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:00:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:00:35 --> Model Class Initialized
INFO - 2016-05-27 11:00:35 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:00:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 11:00:35 --> Severity: Parsing Error --> syntax error, unexpected '"interval_1_nota"' (T_CONSTANT_ENCAPSED_STRING), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
INFO - 2016-05-27 11:01:01 --> Config Class Initialized
INFO - 2016-05-27 11:01:01 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:01:01 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:01:01 --> Utf8 Class Initialized
INFO - 2016-05-27 11:01:01 --> URI Class Initialized
INFO - 2016-05-27 11:01:01 --> Router Class Initialized
INFO - 2016-05-27 11:01:01 --> Output Class Initialized
INFO - 2016-05-27 11:01:01 --> Security Class Initialized
DEBUG - 2016-05-27 11:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:01:01 --> CSRF cookie sent
INFO - 2016-05-27 11:01:01 --> Input Class Initialized
INFO - 2016-05-27 11:01:01 --> Language Class Initialized
INFO - 2016-05-27 11:01:01 --> Loader Class Initialized
INFO - 2016-05-27 11:01:01 --> Helper loaded: form_helper
INFO - 2016-05-27 11:01:01 --> Database Driver Class Initialized
INFO - 2016-05-27 11:01:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:01:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:01:01 --> Email Class Initialized
INFO - 2016-05-27 11:01:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:01:01 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:01:01 --> Helper loaded: language_helper
INFO - 2016-05-27 11:01:01 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:01:01 --> Model Class Initialized
INFO - 2016-05-27 11:01:01 --> Helper loaded: date_helper
INFO - 2016-05-27 11:01:01 --> Controller Class Initialized
INFO - 2016-05-27 11:01:01 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:01:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:01:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:01:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:01:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:01:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:01:01 --> Model Class Initialized
INFO - 2016-05-27 11:01:01 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:01:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:01:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:01:01 --> Final output sent to browser
DEBUG - 2016-05-27 11:01:01 --> Total execution time: 0.0471
INFO - 2016-05-27 11:01:37 --> Config Class Initialized
INFO - 2016-05-27 11:01:37 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:01:37 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:01:37 --> Utf8 Class Initialized
INFO - 2016-05-27 11:01:37 --> URI Class Initialized
INFO - 2016-05-27 11:01:37 --> Router Class Initialized
INFO - 2016-05-27 11:01:37 --> Output Class Initialized
INFO - 2016-05-27 11:01:37 --> Security Class Initialized
DEBUG - 2016-05-27 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:01:37 --> CSRF cookie sent
INFO - 2016-05-27 11:01:37 --> Input Class Initialized
INFO - 2016-05-27 11:01:37 --> Language Class Initialized
INFO - 2016-05-27 11:01:37 --> Loader Class Initialized
INFO - 2016-05-27 11:01:37 --> Helper loaded: form_helper
INFO - 2016-05-27 11:01:37 --> Database Driver Class Initialized
INFO - 2016-05-27 11:01:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:01:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:01:37 --> Email Class Initialized
INFO - 2016-05-27 11:01:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:01:37 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:01:37 --> Helper loaded: language_helper
INFO - 2016-05-27 11:01:37 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:01:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:01:37 --> Model Class Initialized
INFO - 2016-05-27 11:01:37 --> Helper loaded: date_helper
INFO - 2016-05-27 11:01:37 --> Controller Class Initialized
INFO - 2016-05-27 11:01:37 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:01:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:01:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:01:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:01:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:01:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:01:37 --> Model Class Initialized
INFO - 2016-05-27 11:01:37 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:01:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_1 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_2 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_3 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_4 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_5 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_6 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_7 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_8 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_9 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
ERROR - 2016-05-27 11:01:37 --> Severity: Notice --> Undefined property: stdClass::$interval_10 /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:01:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:01:37 --> Final output sent to browser
DEBUG - 2016-05-27 11:01:37 --> Total execution time: 0.0502
INFO - 2016-05-27 11:01:50 --> Config Class Initialized
INFO - 2016-05-27 11:01:50 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:01:50 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:01:50 --> Utf8 Class Initialized
INFO - 2016-05-27 11:01:50 --> URI Class Initialized
INFO - 2016-05-27 11:01:50 --> Router Class Initialized
INFO - 2016-05-27 11:01:50 --> Output Class Initialized
INFO - 2016-05-27 11:01:50 --> Security Class Initialized
DEBUG - 2016-05-27 11:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:01:50 --> CSRF cookie sent
INFO - 2016-05-27 11:01:50 --> Input Class Initialized
INFO - 2016-05-27 11:01:50 --> Language Class Initialized
INFO - 2016-05-27 11:01:50 --> Loader Class Initialized
INFO - 2016-05-27 11:01:50 --> Helper loaded: form_helper
INFO - 2016-05-27 11:01:50 --> Database Driver Class Initialized
INFO - 2016-05-27 11:01:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:01:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:01:50 --> Email Class Initialized
INFO - 2016-05-27 11:01:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:01:50 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:01:50 --> Helper loaded: language_helper
INFO - 2016-05-27 11:01:50 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:01:50 --> Model Class Initialized
INFO - 2016-05-27 11:01:50 --> Helper loaded: date_helper
INFO - 2016-05-27 11:01:50 --> Controller Class Initialized
INFO - 2016-05-27 11:01:50 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:01:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:01:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:01:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:01:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:01:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:01:50 --> Model Class Initialized
INFO - 2016-05-27 11:01:50 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:01:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:01:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 11:01:50 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 48
INFO - 2016-05-27 11:06:46 --> Config Class Initialized
INFO - 2016-05-27 11:06:46 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:06:46 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:06:46 --> Utf8 Class Initialized
INFO - 2016-05-27 11:06:46 --> URI Class Initialized
INFO - 2016-05-27 11:06:46 --> Router Class Initialized
INFO - 2016-05-27 11:06:46 --> Output Class Initialized
INFO - 2016-05-27 11:06:46 --> Security Class Initialized
DEBUG - 2016-05-27 11:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:06:46 --> CSRF cookie sent
INFO - 2016-05-27 11:06:46 --> Input Class Initialized
INFO - 2016-05-27 11:06:46 --> Language Class Initialized
INFO - 2016-05-27 11:06:46 --> Loader Class Initialized
INFO - 2016-05-27 11:06:46 --> Helper loaded: form_helper
INFO - 2016-05-27 11:06:46 --> Database Driver Class Initialized
INFO - 2016-05-27 11:06:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:06:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:06:46 --> Email Class Initialized
INFO - 2016-05-27 11:06:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:06:46 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:06:46 --> Helper loaded: language_helper
INFO - 2016-05-27 11:06:46 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:06:46 --> Model Class Initialized
INFO - 2016-05-27 11:06:46 --> Helper loaded: date_helper
INFO - 2016-05-27 11:06:46 --> Controller Class Initialized
INFO - 2016-05-27 11:06:46 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:06:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:06:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:06:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:06:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:06:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:06:46 --> Model Class Initialized
INFO - 2016-05-27 11:06:46 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:06:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:06:46 --> Final output sent to browser
DEBUG - 2016-05-27 11:06:46 --> Total execution time: 0.1342
INFO - 2016-05-27 11:07:21 --> Config Class Initialized
INFO - 2016-05-27 11:07:21 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:07:21 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:07:21 --> Utf8 Class Initialized
INFO - 2016-05-27 11:07:21 --> URI Class Initialized
INFO - 2016-05-27 11:07:21 --> Router Class Initialized
INFO - 2016-05-27 11:07:21 --> Output Class Initialized
INFO - 2016-05-27 11:07:21 --> Security Class Initialized
DEBUG - 2016-05-27 11:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:07:21 --> CSRF cookie sent
INFO - 2016-05-27 11:07:21 --> Input Class Initialized
INFO - 2016-05-27 11:07:21 --> Language Class Initialized
INFO - 2016-05-27 11:07:21 --> Loader Class Initialized
INFO - 2016-05-27 11:07:21 --> Helper loaded: form_helper
INFO - 2016-05-27 11:07:21 --> Database Driver Class Initialized
INFO - 2016-05-27 11:07:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:07:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:07:21 --> Email Class Initialized
INFO - 2016-05-27 11:07:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:07:21 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:07:21 --> Helper loaded: language_helper
INFO - 2016-05-27 11:07:21 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:07:21 --> Model Class Initialized
INFO - 2016-05-27 11:07:21 --> Helper loaded: date_helper
INFO - 2016-05-27 11:07:21 --> Controller Class Initialized
INFO - 2016-05-27 11:07:21 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:07:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:07:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:07:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:07:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:07:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:07:21 --> Model Class Initialized
INFO - 2016-05-27 11:07:21 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:07:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:07:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:07:21 --> Final output sent to browser
DEBUG - 2016-05-27 11:07:21 --> Total execution time: 0.0330
INFO - 2016-05-27 11:07:42 --> Config Class Initialized
INFO - 2016-05-27 11:07:42 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:07:42 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:07:42 --> Utf8 Class Initialized
INFO - 2016-05-27 11:07:42 --> URI Class Initialized
INFO - 2016-05-27 11:07:42 --> Router Class Initialized
INFO - 2016-05-27 11:07:42 --> Output Class Initialized
INFO - 2016-05-27 11:07:42 --> Security Class Initialized
DEBUG - 2016-05-27 11:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:07:42 --> CSRF cookie sent
INFO - 2016-05-27 11:07:42 --> CSRF token verified
INFO - 2016-05-27 11:07:42 --> Input Class Initialized
INFO - 2016-05-27 11:07:42 --> Language Class Initialized
INFO - 2016-05-27 11:07:42 --> Loader Class Initialized
INFO - 2016-05-27 11:07:42 --> Helper loaded: form_helper
INFO - 2016-05-27 11:07:42 --> Database Driver Class Initialized
INFO - 2016-05-27 11:07:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:07:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:07:42 --> Email Class Initialized
INFO - 2016-05-27 11:07:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:07:42 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:07:42 --> Helper loaded: language_helper
INFO - 2016-05-27 11:07:42 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:07:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:07:42 --> Model Class Initialized
INFO - 2016-05-27 11:07:42 --> Helper loaded: date_helper
INFO - 2016-05-27 11:07:42 --> Controller Class Initialized
INFO - 2016-05-27 11:07:42 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:07:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:07:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:07:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:07:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:07:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:07:42 --> Model Class Initialized
INFO - 2016-05-27 11:07:42 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:07:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:07:43 --> Config Class Initialized
INFO - 2016-05-27 11:07:43 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:07:43 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:07:43 --> Utf8 Class Initialized
INFO - 2016-05-27 11:07:43 --> URI Class Initialized
INFO - 2016-05-27 11:07:43 --> Router Class Initialized
INFO - 2016-05-27 11:07:43 --> Output Class Initialized
INFO - 2016-05-27 11:07:43 --> Security Class Initialized
DEBUG - 2016-05-27 11:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:07:43 --> CSRF cookie sent
INFO - 2016-05-27 11:07:43 --> Input Class Initialized
INFO - 2016-05-27 11:07:43 --> Language Class Initialized
INFO - 2016-05-27 11:07:43 --> Loader Class Initialized
INFO - 2016-05-27 11:07:43 --> Helper loaded: form_helper
INFO - 2016-05-27 11:07:43 --> Database Driver Class Initialized
INFO - 2016-05-27 11:07:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:07:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:07:43 --> Email Class Initialized
INFO - 2016-05-27 11:07:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:07:43 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:07:43 --> Helper loaded: language_helper
INFO - 2016-05-27 11:07:43 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:07:43 --> Model Class Initialized
INFO - 2016-05-27 11:07:43 --> Helper loaded: date_helper
INFO - 2016-05-27 11:07:43 --> Controller Class Initialized
INFO - 2016-05-27 11:07:43 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:07:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:07:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:07:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:07:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:07:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:07:43 --> Model Class Initialized
INFO - 2016-05-27 11:07:43 --> Form Validation Class Initialized
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 11:07:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:07:43 --> Final output sent to browser
DEBUG - 2016-05-27 11:07:43 --> Total execution time: 0.1770
INFO - 2016-05-27 11:25:07 --> Config Class Initialized
INFO - 2016-05-27 11:25:07 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:25:07 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:25:07 --> Utf8 Class Initialized
INFO - 2016-05-27 11:25:07 --> URI Class Initialized
INFO - 2016-05-27 11:25:07 --> Router Class Initialized
INFO - 2016-05-27 11:25:07 --> Output Class Initialized
INFO - 2016-05-27 11:25:07 --> Security Class Initialized
DEBUG - 2016-05-27 11:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:25:07 --> CSRF cookie sent
INFO - 2016-05-27 11:25:07 --> Input Class Initialized
INFO - 2016-05-27 11:25:07 --> Language Class Initialized
INFO - 2016-05-27 11:25:07 --> Loader Class Initialized
INFO - 2016-05-27 11:25:07 --> Helper loaded: form_helper
INFO - 2016-05-27 11:25:07 --> Database Driver Class Initialized
INFO - 2016-05-27 11:25:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:25:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:25:07 --> Email Class Initialized
INFO - 2016-05-27 11:25:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:25:07 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:25:07 --> Helper loaded: language_helper
INFO - 2016-05-27 11:25:07 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:25:07 --> Model Class Initialized
INFO - 2016-05-27 11:25:07 --> Helper loaded: date_helper
INFO - 2016-05-27 11:25:07 --> Controller Class Initialized
INFO - 2016-05-27 11:25:07 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:25:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:25:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:25:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:25:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:25:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:25:07 --> Model Class Initialized
INFO - 2016-05-27 11:25:07 --> Form Validation Class Initialized
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 11:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:25:07 --> Final output sent to browser
DEBUG - 2016-05-27 11:25:07 --> Total execution time: 0.1952
INFO - 2016-05-27 11:25:10 --> Config Class Initialized
INFO - 2016-05-27 11:25:10 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:25:10 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:25:10 --> Utf8 Class Initialized
INFO - 2016-05-27 11:25:10 --> URI Class Initialized
INFO - 2016-05-27 11:25:10 --> Router Class Initialized
INFO - 2016-05-27 11:25:10 --> Output Class Initialized
INFO - 2016-05-27 11:25:10 --> Security Class Initialized
DEBUG - 2016-05-27 11:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:25:10 --> CSRF cookie sent
INFO - 2016-05-27 11:25:10 --> Input Class Initialized
INFO - 2016-05-27 11:25:10 --> Language Class Initialized
INFO - 2016-05-27 11:25:10 --> Loader Class Initialized
INFO - 2016-05-27 11:25:10 --> Helper loaded: form_helper
INFO - 2016-05-27 11:25:10 --> Database Driver Class Initialized
INFO - 2016-05-27 11:25:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:25:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:25:10 --> Email Class Initialized
INFO - 2016-05-27 11:25:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:25:10 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:25:10 --> Helper loaded: language_helper
INFO - 2016-05-27 11:25:10 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:25:10 --> Model Class Initialized
INFO - 2016-05-27 11:25:10 --> Helper loaded: date_helper
INFO - 2016-05-27 11:25:10 --> Controller Class Initialized
INFO - 2016-05-27 11:25:10 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:25:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:25:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:25:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:25:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:25:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:25:10 --> Model Class Initialized
INFO - 2016-05-27 11:25:10 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:25:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:25:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:25:10 --> Final output sent to browser
DEBUG - 2016-05-27 11:25:10 --> Total execution time: 0.0609
INFO - 2016-05-27 11:26:02 --> Config Class Initialized
INFO - 2016-05-27 11:26:02 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:26:02 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:26:02 --> Utf8 Class Initialized
INFO - 2016-05-27 11:26:02 --> URI Class Initialized
INFO - 2016-05-27 11:26:02 --> Router Class Initialized
INFO - 2016-05-27 11:26:02 --> Output Class Initialized
INFO - 2016-05-27 11:26:02 --> Security Class Initialized
DEBUG - 2016-05-27 11:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:26:02 --> CSRF cookie sent
INFO - 2016-05-27 11:26:02 --> Input Class Initialized
INFO - 2016-05-27 11:26:02 --> Language Class Initialized
INFO - 2016-05-27 11:26:02 --> Loader Class Initialized
INFO - 2016-05-27 11:26:02 --> Helper loaded: form_helper
INFO - 2016-05-27 11:26:02 --> Database Driver Class Initialized
INFO - 2016-05-27 11:26:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:26:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:26:02 --> Email Class Initialized
INFO - 2016-05-27 11:26:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:26:02 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:26:02 --> Helper loaded: language_helper
INFO - 2016-05-27 11:26:02 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:26:02 --> Model Class Initialized
INFO - 2016-05-27 11:26:02 --> Helper loaded: date_helper
INFO - 2016-05-27 11:26:02 --> Controller Class Initialized
INFO - 2016-05-27 11:26:02 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:26:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:26:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:26:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:26:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:26:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:26:02 --> Model Class Initialized
INFO - 2016-05-27 11:26:02 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:26:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:26:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:26:02 --> Final output sent to browser
DEBUG - 2016-05-27 11:26:02 --> Total execution time: 0.1541
INFO - 2016-05-27 11:27:39 --> Config Class Initialized
INFO - 2016-05-27 11:27:39 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:27:39 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:27:39 --> Utf8 Class Initialized
INFO - 2016-05-27 11:27:39 --> URI Class Initialized
INFO - 2016-05-27 11:27:39 --> Router Class Initialized
INFO - 2016-05-27 11:27:39 --> Output Class Initialized
INFO - 2016-05-27 11:27:39 --> Security Class Initialized
DEBUG - 2016-05-27 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:27:39 --> CSRF cookie sent
INFO - 2016-05-27 11:27:39 --> CSRF token verified
INFO - 2016-05-27 11:27:39 --> Input Class Initialized
INFO - 2016-05-27 11:27:39 --> Language Class Initialized
INFO - 2016-05-27 11:27:39 --> Loader Class Initialized
INFO - 2016-05-27 11:27:39 --> Helper loaded: form_helper
INFO - 2016-05-27 11:27:39 --> Database Driver Class Initialized
INFO - 2016-05-27 11:27:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:27:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:27:39 --> Email Class Initialized
INFO - 2016-05-27 11:27:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:27:39 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:27:39 --> Helper loaded: language_helper
INFO - 2016-05-27 11:27:39 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:27:39 --> Model Class Initialized
INFO - 2016-05-27 11:27:39 --> Helper loaded: date_helper
INFO - 2016-05-27 11:27:39 --> Controller Class Initialized
INFO - 2016-05-27 11:27:39 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:27:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:27:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:27:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:27:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:27:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:27:39 --> Model Class Initialized
INFO - 2016-05-27 11:27:39 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:27:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:28:36 --> Config Class Initialized
INFO - 2016-05-27 11:28:36 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:28:36 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:28:36 --> Utf8 Class Initialized
INFO - 2016-05-27 11:28:36 --> URI Class Initialized
INFO - 2016-05-27 11:28:36 --> Router Class Initialized
INFO - 2016-05-27 11:28:36 --> Output Class Initialized
INFO - 2016-05-27 11:28:36 --> Security Class Initialized
DEBUG - 2016-05-27 11:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:28:36 --> CSRF cookie sent
INFO - 2016-05-27 11:28:36 --> Input Class Initialized
INFO - 2016-05-27 11:28:36 --> Language Class Initialized
INFO - 2016-05-27 11:28:36 --> Loader Class Initialized
INFO - 2016-05-27 11:28:36 --> Helper loaded: form_helper
INFO - 2016-05-27 11:28:36 --> Database Driver Class Initialized
INFO - 2016-05-27 11:28:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:28:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:28:36 --> Email Class Initialized
INFO - 2016-05-27 11:28:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:28:36 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:28:36 --> Helper loaded: language_helper
INFO - 2016-05-27 11:28:36 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:28:36 --> Model Class Initialized
INFO - 2016-05-27 11:28:36 --> Helper loaded: date_helper
INFO - 2016-05-27 11:28:36 --> Controller Class Initialized
INFO - 2016-05-27 11:28:36 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:28:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:28:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:28:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:28:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:28:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:28:36 --> Model Class Initialized
INFO - 2016-05-27 11:28:36 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:28:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:28:39 --> Config Class Initialized
INFO - 2016-05-27 11:28:39 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:28:39 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:28:39 --> Utf8 Class Initialized
INFO - 2016-05-27 11:28:39 --> URI Class Initialized
INFO - 2016-05-27 11:28:39 --> Router Class Initialized
INFO - 2016-05-27 11:28:39 --> Output Class Initialized
INFO - 2016-05-27 11:28:39 --> Security Class Initialized
DEBUG - 2016-05-27 11:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:28:39 --> CSRF cookie sent
INFO - 2016-05-27 11:28:39 --> Input Class Initialized
INFO - 2016-05-27 11:28:39 --> Language Class Initialized
INFO - 2016-05-27 11:28:39 --> Loader Class Initialized
INFO - 2016-05-27 11:28:39 --> Helper loaded: form_helper
INFO - 2016-05-27 11:28:39 --> Database Driver Class Initialized
INFO - 2016-05-27 11:28:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:28:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:28:39 --> Email Class Initialized
INFO - 2016-05-27 11:28:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:28:39 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:28:39 --> Helper loaded: language_helper
INFO - 2016-05-27 11:28:39 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:28:39 --> Model Class Initialized
INFO - 2016-05-27 11:28:39 --> Helper loaded: date_helper
INFO - 2016-05-27 11:28:39 --> Controller Class Initialized
INFO - 2016-05-27 11:28:39 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:28:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:28:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:28:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:28:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:28:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:28:39 --> Model Class Initialized
INFO - 2016-05-27 11:28:39 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:28:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
ERROR - 2016-05-27 11:28:39 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php 49
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:28:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:28:39 --> Final output sent to browser
DEBUG - 2016-05-27 11:28:39 --> Total execution time: 0.0692
INFO - 2016-05-27 11:29:37 --> Config Class Initialized
INFO - 2016-05-27 11:29:37 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:29:37 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:29:37 --> Utf8 Class Initialized
INFO - 2016-05-27 11:29:37 --> URI Class Initialized
INFO - 2016-05-27 11:29:37 --> Router Class Initialized
INFO - 2016-05-27 11:29:37 --> Output Class Initialized
INFO - 2016-05-27 11:29:37 --> Security Class Initialized
DEBUG - 2016-05-27 11:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:29:37 --> CSRF cookie sent
INFO - 2016-05-27 11:29:37 --> Input Class Initialized
INFO - 2016-05-27 11:29:37 --> Language Class Initialized
INFO - 2016-05-27 11:29:37 --> Loader Class Initialized
INFO - 2016-05-27 11:29:37 --> Helper loaded: form_helper
INFO - 2016-05-27 11:29:37 --> Database Driver Class Initialized
INFO - 2016-05-27 11:29:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:29:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:29:37 --> Email Class Initialized
INFO - 2016-05-27 11:29:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:29:37 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:29:37 --> Helper loaded: language_helper
INFO - 2016-05-27 11:29:37 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:29:37 --> Model Class Initialized
INFO - 2016-05-27 11:29:37 --> Helper loaded: date_helper
INFO - 2016-05-27 11:29:37 --> Controller Class Initialized
INFO - 2016-05-27 11:29:37 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:29:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:29:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:29:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:29:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:29:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:29:37 --> Model Class Initialized
INFO - 2016-05-27 11:29:37 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:29:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:29:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:29:37 --> Final output sent to browser
DEBUG - 2016-05-27 11:29:37 --> Total execution time: 0.0292
INFO - 2016-05-27 11:30:01 --> Config Class Initialized
INFO - 2016-05-27 11:30:01 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:30:01 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:30:01 --> Utf8 Class Initialized
INFO - 2016-05-27 11:30:01 --> URI Class Initialized
INFO - 2016-05-27 11:30:01 --> Router Class Initialized
INFO - 2016-05-27 11:30:01 --> Output Class Initialized
INFO - 2016-05-27 11:30:01 --> Security Class Initialized
DEBUG - 2016-05-27 11:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:30:01 --> CSRF cookie sent
INFO - 2016-05-27 11:30:01 --> CSRF token verified
INFO - 2016-05-27 11:30:01 --> Input Class Initialized
INFO - 2016-05-27 11:30:01 --> Language Class Initialized
INFO - 2016-05-27 11:30:01 --> Loader Class Initialized
INFO - 2016-05-27 11:30:01 --> Helper loaded: form_helper
INFO - 2016-05-27 11:30:01 --> Database Driver Class Initialized
INFO - 2016-05-27 11:30:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:30:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:30:01 --> Email Class Initialized
INFO - 2016-05-27 11:30:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:30:01 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:30:01 --> Helper loaded: language_helper
INFO - 2016-05-27 11:30:01 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:30:01 --> Model Class Initialized
INFO - 2016-05-27 11:30:01 --> Helper loaded: date_helper
INFO - 2016-05-27 11:30:01 --> Controller Class Initialized
INFO - 2016-05-27 11:30:01 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:30:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:30:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:30:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:30:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:30:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:30:01 --> Model Class Initialized
INFO - 2016-05-27 11:30:01 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:30:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:01 --> Config Class Initialized
INFO - 2016-05-27 11:32:01 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:32:01 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:32:01 --> Utf8 Class Initialized
INFO - 2016-05-27 11:32:01 --> URI Class Initialized
INFO - 2016-05-27 11:32:01 --> Router Class Initialized
INFO - 2016-05-27 11:32:01 --> Output Class Initialized
INFO - 2016-05-27 11:32:01 --> Security Class Initialized
DEBUG - 2016-05-27 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:32:04 --> Config Class Initialized
INFO - 2016-05-27 11:32:04 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:32:04 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:32:04 --> Utf8 Class Initialized
INFO - 2016-05-27 11:32:04 --> URI Class Initialized
INFO - 2016-05-27 11:32:04 --> Router Class Initialized
INFO - 2016-05-27 11:32:04 --> Output Class Initialized
INFO - 2016-05-27 11:32:04 --> Security Class Initialized
DEBUG - 2016-05-27 11:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:32:04 --> CSRF cookie sent
INFO - 2016-05-27 11:32:04 --> Input Class Initialized
INFO - 2016-05-27 11:32:04 --> Language Class Initialized
INFO - 2016-05-27 11:32:04 --> Loader Class Initialized
INFO - 2016-05-27 11:32:04 --> Helper loaded: form_helper
INFO - 2016-05-27 11:32:04 --> Database Driver Class Initialized
INFO - 2016-05-27 11:32:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:32:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:32:04 --> Email Class Initialized
INFO - 2016-05-27 11:32:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:32:04 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:32:04 --> Helper loaded: language_helper
INFO - 2016-05-27 11:32:04 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:04 --> Model Class Initialized
INFO - 2016-05-27 11:32:04 --> Helper loaded: date_helper
INFO - 2016-05-27 11:32:04 --> Controller Class Initialized
INFO - 2016-05-27 11:32:04 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:32:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:32:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:32:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:32:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:32:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:32:04 --> Model Class Initialized
INFO - 2016-05-27 11:32:04 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:32:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:32:04 --> Final output sent to browser
DEBUG - 2016-05-27 11:32:04 --> Total execution time: 0.1041
INFO - 2016-05-27 11:32:26 --> Config Class Initialized
INFO - 2016-05-27 11:32:26 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:32:26 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:32:26 --> Utf8 Class Initialized
INFO - 2016-05-27 11:32:26 --> URI Class Initialized
INFO - 2016-05-27 11:32:26 --> Router Class Initialized
INFO - 2016-05-27 11:32:26 --> Output Class Initialized
INFO - 2016-05-27 11:32:26 --> Security Class Initialized
DEBUG - 2016-05-27 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:32:26 --> CSRF cookie sent
INFO - 2016-05-27 11:32:26 --> CSRF token verified
INFO - 2016-05-27 11:32:26 --> Input Class Initialized
INFO - 2016-05-27 11:32:26 --> Language Class Initialized
INFO - 2016-05-27 11:32:26 --> Loader Class Initialized
INFO - 2016-05-27 11:32:26 --> Helper loaded: form_helper
INFO - 2016-05-27 11:32:26 --> Database Driver Class Initialized
INFO - 2016-05-27 11:32:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:32:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:32:26 --> Email Class Initialized
INFO - 2016-05-27 11:32:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:32:26 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:32:26 --> Helper loaded: language_helper
INFO - 2016-05-27 11:32:26 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:32:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:26 --> Model Class Initialized
INFO - 2016-05-27 11:32:26 --> Helper loaded: date_helper
INFO - 2016-05-27 11:32:26 --> Controller Class Initialized
INFO - 2016-05-27 11:32:26 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:32:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:32:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:32:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:32:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:32:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:32:26 --> Model Class Initialized
INFO - 2016-05-27 11:32:26 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:32:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:39 --> Config Class Initialized
INFO - 2016-05-27 11:32:39 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:32:39 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:32:39 --> Utf8 Class Initialized
INFO - 2016-05-27 11:32:39 --> URI Class Initialized
INFO - 2016-05-27 11:32:39 --> Router Class Initialized
INFO - 2016-05-27 11:32:39 --> Output Class Initialized
INFO - 2016-05-27 11:32:39 --> Security Class Initialized
DEBUG - 2016-05-27 11:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:32:39 --> CSRF cookie sent
INFO - 2016-05-27 11:32:39 --> Input Class Initialized
INFO - 2016-05-27 11:32:39 --> Language Class Initialized
INFO - 2016-05-27 11:32:39 --> Loader Class Initialized
INFO - 2016-05-27 11:32:39 --> Helper loaded: form_helper
INFO - 2016-05-27 11:32:39 --> Database Driver Class Initialized
INFO - 2016-05-27 11:32:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:32:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:32:39 --> Email Class Initialized
INFO - 2016-05-27 11:32:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:32:39 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:32:39 --> Helper loaded: language_helper
INFO - 2016-05-27 11:32:39 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:39 --> Model Class Initialized
INFO - 2016-05-27 11:32:39 --> Helper loaded: date_helper
INFO - 2016-05-27 11:32:39 --> Controller Class Initialized
INFO - 2016-05-27 11:32:39 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:32:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:32:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:32:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:32:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:32:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:32:39 --> Model Class Initialized
INFO - 2016-05-27 11:32:39 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:32:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:53 --> Config Class Initialized
INFO - 2016-05-27 11:32:53 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:32:53 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:32:53 --> Utf8 Class Initialized
INFO - 2016-05-27 11:32:53 --> URI Class Initialized
INFO - 2016-05-27 11:32:53 --> Router Class Initialized
INFO - 2016-05-27 11:32:53 --> Output Class Initialized
INFO - 2016-05-27 11:32:53 --> Security Class Initialized
DEBUG - 2016-05-27 11:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:32:53 --> CSRF cookie sent
INFO - 2016-05-27 11:32:53 --> Input Class Initialized
INFO - 2016-05-27 11:32:53 --> Language Class Initialized
INFO - 2016-05-27 11:32:53 --> Loader Class Initialized
INFO - 2016-05-27 11:32:53 --> Helper loaded: form_helper
INFO - 2016-05-27 11:32:53 --> Database Driver Class Initialized
INFO - 2016-05-27 11:32:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:32:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:32:53 --> Email Class Initialized
INFO - 2016-05-27 11:32:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:32:53 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:32:53 --> Helper loaded: language_helper
INFO - 2016-05-27 11:32:53 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:53 --> Model Class Initialized
INFO - 2016-05-27 11:32:53 --> Helper loaded: date_helper
INFO - 2016-05-27 11:32:53 --> Controller Class Initialized
INFO - 2016-05-27 11:32:53 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:32:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:32:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:32:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:32:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:32:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:32:53 --> Model Class Initialized
INFO - 2016-05-27 11:32:53 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:32:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:32:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:32:53 --> Final output sent to browser
DEBUG - 2016-05-27 11:32:53 --> Total execution time: 0.0286
INFO - 2016-05-27 11:33:24 --> Config Class Initialized
INFO - 2016-05-27 11:33:24 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:33:24 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:33:24 --> Utf8 Class Initialized
INFO - 2016-05-27 11:33:24 --> URI Class Initialized
INFO - 2016-05-27 11:33:24 --> Router Class Initialized
INFO - 2016-05-27 11:33:24 --> Output Class Initialized
INFO - 2016-05-27 11:33:24 --> Security Class Initialized
DEBUG - 2016-05-27 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:33:24 --> CSRF cookie sent
INFO - 2016-05-27 11:33:24 --> CSRF token verified
INFO - 2016-05-27 11:33:24 --> Input Class Initialized
INFO - 2016-05-27 11:33:24 --> Language Class Initialized
INFO - 2016-05-27 11:33:24 --> Loader Class Initialized
INFO - 2016-05-27 11:33:24 --> Helper loaded: form_helper
INFO - 2016-05-27 11:33:24 --> Database Driver Class Initialized
INFO - 2016-05-27 11:33:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:33:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:33:24 --> Email Class Initialized
INFO - 2016-05-27 11:33:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:33:24 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:33:24 --> Helper loaded: language_helper
INFO - 2016-05-27 11:33:24 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:33:24 --> Model Class Initialized
INFO - 2016-05-27 11:33:24 --> Helper loaded: date_helper
INFO - 2016-05-27 11:33:24 --> Controller Class Initialized
INFO - 2016-05-27 11:33:24 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:33:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:33:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:33:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:33:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:33:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:33:24 --> Model Class Initialized
INFO - 2016-05-27 11:33:24 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:33:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-05-27 11:33:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:33:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:33:24 --> Final output sent to browser
DEBUG - 2016-05-27 11:33:24 --> Total execution time: 0.0514
INFO - 2016-05-27 11:33:57 --> Config Class Initialized
INFO - 2016-05-27 11:33:57 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:33:57 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:33:57 --> Utf8 Class Initialized
INFO - 2016-05-27 11:33:57 --> URI Class Initialized
INFO - 2016-05-27 11:33:57 --> Router Class Initialized
INFO - 2016-05-27 11:33:57 --> Output Class Initialized
INFO - 2016-05-27 11:33:57 --> Security Class Initialized
DEBUG - 2016-05-27 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:33:57 --> CSRF cookie sent
INFO - 2016-05-27 11:33:57 --> CSRF token verified
INFO - 2016-05-27 11:33:57 --> Input Class Initialized
INFO - 2016-05-27 11:33:57 --> Language Class Initialized
INFO - 2016-05-27 11:33:57 --> Loader Class Initialized
INFO - 2016-05-27 11:33:57 --> Helper loaded: form_helper
INFO - 2016-05-27 11:33:57 --> Database Driver Class Initialized
INFO - 2016-05-27 11:33:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:33:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:33:57 --> Email Class Initialized
INFO - 2016-05-27 11:33:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:33:57 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:33:57 --> Helper loaded: language_helper
INFO - 2016-05-27 11:33:57 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:33:57 --> Model Class Initialized
INFO - 2016-05-27 11:33:57 --> Helper loaded: date_helper
INFO - 2016-05-27 11:33:57 --> Controller Class Initialized
INFO - 2016-05-27 11:33:57 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:33:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:33:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:33:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:33:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:33:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:33:57 --> Model Class Initialized
INFO - 2016-05-27 11:33:57 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:33:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-05-27 11:33:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:33:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:33:57 --> Final output sent to browser
DEBUG - 2016-05-27 11:33:57 --> Total execution time: 0.0797
INFO - 2016-05-27 11:34:11 --> Config Class Initialized
INFO - 2016-05-27 11:34:11 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:34:11 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:34:11 --> Utf8 Class Initialized
INFO - 2016-05-27 11:34:11 --> URI Class Initialized
INFO - 2016-05-27 11:34:11 --> Router Class Initialized
INFO - 2016-05-27 11:34:11 --> Output Class Initialized
INFO - 2016-05-27 11:34:11 --> Security Class Initialized
DEBUG - 2016-05-27 11:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:34:11 --> CSRF cookie sent
INFO - 2016-05-27 11:34:11 --> CSRF token verified
INFO - 2016-05-27 11:34:11 --> Input Class Initialized
INFO - 2016-05-27 11:34:11 --> Language Class Initialized
INFO - 2016-05-27 11:34:11 --> Loader Class Initialized
INFO - 2016-05-27 11:34:11 --> Helper loaded: form_helper
INFO - 2016-05-27 11:34:11 --> Database Driver Class Initialized
INFO - 2016-05-27 11:34:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:34:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:34:11 --> Email Class Initialized
INFO - 2016-05-27 11:34:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:34:11 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:34:11 --> Helper loaded: language_helper
INFO - 2016-05-27 11:34:11 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:34:11 --> Model Class Initialized
INFO - 2016-05-27 11:34:11 --> Helper loaded: date_helper
INFO - 2016-05-27 11:34:11 --> Controller Class Initialized
INFO - 2016-05-27 11:34:11 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:34:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:34:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:34:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:34:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:34:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:34:11 --> Model Class Initialized
INFO - 2016-05-27 11:34:11 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:34:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-05-27 11:34:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:34:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:34:11 --> Final output sent to browser
DEBUG - 2016-05-27 11:34:11 --> Total execution time: 0.0343
INFO - 2016-05-27 11:34:24 --> Config Class Initialized
INFO - 2016-05-27 11:34:24 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:34:24 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:34:24 --> Utf8 Class Initialized
INFO - 2016-05-27 11:34:24 --> URI Class Initialized
INFO - 2016-05-27 11:34:24 --> Router Class Initialized
INFO - 2016-05-27 11:34:24 --> Output Class Initialized
INFO - 2016-05-27 11:34:24 --> Security Class Initialized
DEBUG - 2016-05-27 11:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:34:29 --> Config Class Initialized
INFO - 2016-05-27 11:34:29 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:34:29 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:34:29 --> Utf8 Class Initialized
INFO - 2016-05-27 11:34:29 --> URI Class Initialized
INFO - 2016-05-27 11:34:29 --> Router Class Initialized
INFO - 2016-05-27 11:34:29 --> Output Class Initialized
INFO - 2016-05-27 11:34:29 --> Security Class Initialized
DEBUG - 2016-05-27 11:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:34:29 --> CSRF cookie sent
INFO - 2016-05-27 11:34:29 --> Input Class Initialized
INFO - 2016-05-27 11:34:29 --> Language Class Initialized
INFO - 2016-05-27 11:34:29 --> Loader Class Initialized
INFO - 2016-05-27 11:34:29 --> Helper loaded: form_helper
INFO - 2016-05-27 11:34:29 --> Database Driver Class Initialized
INFO - 2016-05-27 11:34:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:34:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:34:29 --> Email Class Initialized
INFO - 2016-05-27 11:34:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:34:29 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:34:29 --> Helper loaded: language_helper
INFO - 2016-05-27 11:34:29 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:34:29 --> Model Class Initialized
INFO - 2016-05-27 11:34:29 --> Helper loaded: date_helper
INFO - 2016-05-27 11:34:29 --> Controller Class Initialized
INFO - 2016-05-27 11:34:29 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:34:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:34:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:34:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:34:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:34:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:34:29 --> Model Class Initialized
INFO - 2016-05-27 11:34:29 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:34:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:34:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:34:29 --> Final output sent to browser
DEBUG - 2016-05-27 11:34:29 --> Total execution time: 0.0683
INFO - 2016-05-27 11:36:14 --> Config Class Initialized
INFO - 2016-05-27 11:36:14 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:36:14 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:36:14 --> Utf8 Class Initialized
INFO - 2016-05-27 11:36:14 --> URI Class Initialized
INFO - 2016-05-27 11:36:14 --> Router Class Initialized
INFO - 2016-05-27 11:36:14 --> Output Class Initialized
INFO - 2016-05-27 11:36:14 --> Security Class Initialized
DEBUG - 2016-05-27 11:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:36:14 --> CSRF cookie sent
INFO - 2016-05-27 11:36:14 --> Input Class Initialized
INFO - 2016-05-27 11:36:14 --> Language Class Initialized
INFO - 2016-05-27 11:36:14 --> Loader Class Initialized
INFO - 2016-05-27 11:36:14 --> Helper loaded: form_helper
INFO - 2016-05-27 11:36:14 --> Database Driver Class Initialized
INFO - 2016-05-27 11:36:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:36:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:36:14 --> Email Class Initialized
INFO - 2016-05-27 11:36:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:36:14 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:36:14 --> Helper loaded: language_helper
INFO - 2016-05-27 11:36:14 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:36:14 --> Model Class Initialized
INFO - 2016-05-27 11:36:14 --> Helper loaded: date_helper
INFO - 2016-05-27 11:36:14 --> Controller Class Initialized
INFO - 2016-05-27 11:36:14 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:36:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:36:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:36:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:36:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:36:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:36:14 --> Model Class Initialized
INFO - 2016-05-27 11:36:14 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:36:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:36:30 --> Config Class Initialized
INFO - 2016-05-27 11:36:30 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:36:30 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:36:30 --> Utf8 Class Initialized
INFO - 2016-05-27 11:36:30 --> URI Class Initialized
INFO - 2016-05-27 11:36:30 --> Router Class Initialized
INFO - 2016-05-27 11:36:30 --> Output Class Initialized
INFO - 2016-05-27 11:36:30 --> Security Class Initialized
DEBUG - 2016-05-27 11:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:36:30 --> CSRF cookie sent
INFO - 2016-05-27 11:36:30 --> Input Class Initialized
INFO - 2016-05-27 11:36:30 --> Language Class Initialized
INFO - 2016-05-27 11:36:30 --> Loader Class Initialized
INFO - 2016-05-27 11:36:30 --> Helper loaded: form_helper
INFO - 2016-05-27 11:36:30 --> Database Driver Class Initialized
INFO - 2016-05-27 11:36:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:36:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:36:30 --> Email Class Initialized
INFO - 2016-05-27 11:36:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:36:30 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:36:30 --> Helper loaded: language_helper
INFO - 2016-05-27 11:36:30 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:36:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:36:30 --> Model Class Initialized
INFO - 2016-05-27 11:36:30 --> Helper loaded: date_helper
INFO - 2016-05-27 11:36:30 --> Controller Class Initialized
INFO - 2016-05-27 11:36:30 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:36:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:36:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:36:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:36:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:36:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:36:30 --> Model Class Initialized
INFO - 2016-05-27 11:36:30 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:36:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:37:41 --> Config Class Initialized
INFO - 2016-05-27 11:37:41 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:37:41 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:37:41 --> Utf8 Class Initialized
INFO - 2016-05-27 11:37:41 --> URI Class Initialized
INFO - 2016-05-27 11:37:41 --> Router Class Initialized
INFO - 2016-05-27 11:37:41 --> Output Class Initialized
INFO - 2016-05-27 11:37:41 --> Security Class Initialized
DEBUG - 2016-05-27 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:37:41 --> CSRF cookie sent
INFO - 2016-05-27 11:37:41 --> Input Class Initialized
INFO - 2016-05-27 11:37:41 --> Language Class Initialized
INFO - 2016-05-27 11:37:41 --> Loader Class Initialized
INFO - 2016-05-27 11:37:41 --> Helper loaded: form_helper
INFO - 2016-05-27 11:37:41 --> Database Driver Class Initialized
INFO - 2016-05-27 11:37:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:37:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:37:41 --> Email Class Initialized
INFO - 2016-05-27 11:37:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:37:41 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:37:41 --> Helper loaded: language_helper
INFO - 2016-05-27 11:37:41 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:37:41 --> Model Class Initialized
INFO - 2016-05-27 11:37:41 --> Helper loaded: date_helper
INFO - 2016-05-27 11:37:41 --> Controller Class Initialized
INFO - 2016-05-27 11:37:41 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:37:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:37:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:37:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:37:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:37:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:37:41 --> Model Class Initialized
INFO - 2016-05-27 11:37:41 --> Form Validation Class Initialized
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 11:37:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:37:41 --> Final output sent to browser
DEBUG - 2016-05-27 11:37:41 --> Total execution time: 0.0337
INFO - 2016-05-27 11:37:43 --> Config Class Initialized
INFO - 2016-05-27 11:37:43 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:37:43 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:37:43 --> Utf8 Class Initialized
INFO - 2016-05-27 11:37:43 --> URI Class Initialized
INFO - 2016-05-27 11:37:43 --> Router Class Initialized
INFO - 2016-05-27 11:37:43 --> Output Class Initialized
INFO - 2016-05-27 11:37:44 --> Security Class Initialized
DEBUG - 2016-05-27 11:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:37:44 --> CSRF cookie sent
INFO - 2016-05-27 11:37:44 --> Input Class Initialized
INFO - 2016-05-27 11:37:44 --> Language Class Initialized
INFO - 2016-05-27 11:37:44 --> Loader Class Initialized
INFO - 2016-05-27 11:37:44 --> Helper loaded: form_helper
INFO - 2016-05-27 11:37:44 --> Database Driver Class Initialized
INFO - 2016-05-27 11:37:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:37:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:37:44 --> Email Class Initialized
INFO - 2016-05-27 11:37:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:37:44 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:37:44 --> Helper loaded: language_helper
INFO - 2016-05-27 11:37:44 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:37:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:37:44 --> Model Class Initialized
INFO - 2016-05-27 11:37:44 --> Helper loaded: date_helper
INFO - 2016-05-27 11:37:44 --> Controller Class Initialized
INFO - 2016-05-27 11:37:44 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:37:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:37:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:37:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:37:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:37:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:37:44 --> Model Class Initialized
INFO - 2016-05-27 11:37:44 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:37:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:37:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:37:44 --> Final output sent to browser
DEBUG - 2016-05-27 11:37:44 --> Total execution time: 0.0423
INFO - 2016-05-27 11:37:51 --> Config Class Initialized
INFO - 2016-05-27 11:37:51 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:37:51 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:37:51 --> Utf8 Class Initialized
INFO - 2016-05-27 11:37:51 --> URI Class Initialized
INFO - 2016-05-27 11:37:51 --> Router Class Initialized
INFO - 2016-05-27 11:37:51 --> Output Class Initialized
INFO - 2016-05-27 11:37:51 --> Security Class Initialized
DEBUG - 2016-05-27 11:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:37:51 --> CSRF cookie sent
INFO - 2016-05-27 11:37:51 --> CSRF token verified
INFO - 2016-05-27 11:37:51 --> Input Class Initialized
INFO - 2016-05-27 11:37:51 --> Language Class Initialized
INFO - 2016-05-27 11:37:51 --> Loader Class Initialized
INFO - 2016-05-27 11:37:51 --> Helper loaded: form_helper
INFO - 2016-05-27 11:37:51 --> Database Driver Class Initialized
INFO - 2016-05-27 11:37:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:37:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:37:51 --> Email Class Initialized
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:37:51 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:37:51 --> Helper loaded: language_helper
INFO - 2016-05-27 11:37:51 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:37:51 --> Model Class Initialized
INFO - 2016-05-27 11:37:51 --> Helper loaded: date_helper
INFO - 2016-05-27 11:37:51 --> Controller Class Initialized
INFO - 2016-05-27 11:37:51 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:37:51 --> Model Class Initialized
INFO - 2016-05-27 11:37:51 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:37:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:37:51 --> Config Class Initialized
INFO - 2016-05-27 11:37:51 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:37:51 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:37:51 --> Utf8 Class Initialized
INFO - 2016-05-27 11:37:51 --> URI Class Initialized
INFO - 2016-05-27 11:37:51 --> Router Class Initialized
INFO - 2016-05-27 11:37:51 --> Output Class Initialized
INFO - 2016-05-27 11:37:51 --> Security Class Initialized
DEBUG - 2016-05-27 11:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:37:51 --> CSRF cookie sent
INFO - 2016-05-27 11:37:51 --> Input Class Initialized
INFO - 2016-05-27 11:37:51 --> Language Class Initialized
INFO - 2016-05-27 11:37:51 --> Loader Class Initialized
INFO - 2016-05-27 11:37:51 --> Helper loaded: form_helper
INFO - 2016-05-27 11:37:51 --> Database Driver Class Initialized
INFO - 2016-05-27 11:37:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:37:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:37:51 --> Email Class Initialized
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:37:51 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:37:51 --> Helper loaded: language_helper
INFO - 2016-05-27 11:37:51 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:37:51 --> Model Class Initialized
INFO - 2016-05-27 11:37:51 --> Helper loaded: date_helper
INFO - 2016-05-27 11:37:51 --> Controller Class Initialized
INFO - 2016-05-27 11:37:51 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:37:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:37:51 --> Model Class Initialized
INFO - 2016-05-27 11:37:51 --> Form Validation Class Initialized
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 11:37:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:37:51 --> Final output sent to browser
DEBUG - 2016-05-27 11:37:51 --> Total execution time: 0.0218
INFO - 2016-05-27 11:38:40 --> Config Class Initialized
INFO - 2016-05-27 11:38:40 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:38:40 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:38:40 --> Utf8 Class Initialized
INFO - 2016-05-27 11:38:40 --> URI Class Initialized
INFO - 2016-05-27 11:38:40 --> Router Class Initialized
INFO - 2016-05-27 11:38:40 --> Output Class Initialized
INFO - 2016-05-27 11:38:40 --> Security Class Initialized
DEBUG - 2016-05-27 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:38:40 --> CSRF cookie sent
INFO - 2016-05-27 11:38:40 --> Input Class Initialized
INFO - 2016-05-27 11:38:40 --> Language Class Initialized
INFO - 2016-05-27 11:38:40 --> Loader Class Initialized
INFO - 2016-05-27 11:38:40 --> Helper loaded: form_helper
INFO - 2016-05-27 11:38:40 --> Database Driver Class Initialized
INFO - 2016-05-27 11:38:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:38:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:38:40 --> Email Class Initialized
INFO - 2016-05-27 11:38:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:38:40 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:38:40 --> Helper loaded: language_helper
INFO - 2016-05-27 11:38:40 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:38:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:38:40 --> Model Class Initialized
INFO - 2016-05-27 11:38:40 --> Helper loaded: date_helper
INFO - 2016-05-27 11:38:40 --> Controller Class Initialized
INFO - 2016-05-27 11:38:40 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:38:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:38:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:38:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:38:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:38:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:38:40 --> Model Class Initialized
INFO - 2016-05-27 11:38:40 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:38:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:38:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:38:40 --> Final output sent to browser
DEBUG - 2016-05-27 11:38:40 --> Total execution time: 0.0890
INFO - 2016-05-27 11:38:50 --> Config Class Initialized
INFO - 2016-05-27 11:38:50 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:38:50 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:38:50 --> Utf8 Class Initialized
INFO - 2016-05-27 11:38:50 --> URI Class Initialized
INFO - 2016-05-27 11:38:50 --> Router Class Initialized
INFO - 2016-05-27 11:38:50 --> Output Class Initialized
INFO - 2016-05-27 11:38:50 --> Security Class Initialized
DEBUG - 2016-05-27 11:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:38:50 --> CSRF cookie sent
INFO - 2016-05-27 11:38:50 --> CSRF token verified
INFO - 2016-05-27 11:38:50 --> Input Class Initialized
INFO - 2016-05-27 11:38:50 --> Language Class Initialized
INFO - 2016-05-27 11:38:50 --> Loader Class Initialized
INFO - 2016-05-27 11:38:50 --> Helper loaded: form_helper
INFO - 2016-05-27 11:38:50 --> Database Driver Class Initialized
INFO - 2016-05-27 11:38:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:38:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:38:50 --> Email Class Initialized
INFO - 2016-05-27 11:38:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:38:50 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:38:50 --> Helper loaded: language_helper
INFO - 2016-05-27 11:38:50 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:38:50 --> Model Class Initialized
INFO - 2016-05-27 11:38:51 --> Helper loaded: date_helper
INFO - 2016-05-27 11:38:51 --> Controller Class Initialized
INFO - 2016-05-27 11:38:51 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:38:51 --> Model Class Initialized
INFO - 2016-05-27 11:38:51 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:38:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:38:51 --> Config Class Initialized
INFO - 2016-05-27 11:38:51 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:38:51 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:38:51 --> Utf8 Class Initialized
INFO - 2016-05-27 11:38:51 --> URI Class Initialized
INFO - 2016-05-27 11:38:51 --> Router Class Initialized
INFO - 2016-05-27 11:38:51 --> Output Class Initialized
INFO - 2016-05-27 11:38:51 --> Security Class Initialized
DEBUG - 2016-05-27 11:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:38:51 --> CSRF cookie sent
INFO - 2016-05-27 11:38:51 --> Input Class Initialized
INFO - 2016-05-27 11:38:51 --> Language Class Initialized
INFO - 2016-05-27 11:38:51 --> Loader Class Initialized
INFO - 2016-05-27 11:38:51 --> Helper loaded: form_helper
INFO - 2016-05-27 11:38:51 --> Database Driver Class Initialized
INFO - 2016-05-27 11:38:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:38:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:38:51 --> Email Class Initialized
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:38:51 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:38:51 --> Helper loaded: language_helper
INFO - 2016-05-27 11:38:51 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:38:51 --> Model Class Initialized
INFO - 2016-05-27 11:38:51 --> Helper loaded: date_helper
INFO - 2016-05-27 11:38:51 --> Controller Class Initialized
INFO - 2016-05-27 11:38:51 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:38:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:38:51 --> Model Class Initialized
INFO - 2016-05-27 11:38:51 --> Form Validation Class Initialized
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 11:38:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:38:51 --> Final output sent to browser
DEBUG - 2016-05-27 11:38:51 --> Total execution time: 0.0927
INFO - 2016-05-27 11:38:54 --> Config Class Initialized
INFO - 2016-05-27 11:38:54 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:38:54 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:38:54 --> Utf8 Class Initialized
INFO - 2016-05-27 11:38:54 --> URI Class Initialized
INFO - 2016-05-27 11:38:54 --> Router Class Initialized
INFO - 2016-05-27 11:38:54 --> Output Class Initialized
INFO - 2016-05-27 11:38:54 --> Security Class Initialized
DEBUG - 2016-05-27 11:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:38:54 --> CSRF cookie sent
INFO - 2016-05-27 11:38:54 --> Input Class Initialized
INFO - 2016-05-27 11:38:54 --> Language Class Initialized
INFO - 2016-05-27 11:38:54 --> Loader Class Initialized
INFO - 2016-05-27 11:38:54 --> Helper loaded: form_helper
INFO - 2016-05-27 11:38:54 --> Database Driver Class Initialized
INFO - 2016-05-27 11:38:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:38:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:38:54 --> Email Class Initialized
INFO - 2016-05-27 11:38:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:38:54 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:38:54 --> Helper loaded: language_helper
INFO - 2016-05-27 11:38:54 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:38:54 --> Model Class Initialized
INFO - 2016-05-27 11:38:54 --> Helper loaded: date_helper
INFO - 2016-05-27 11:38:54 --> Controller Class Initialized
INFO - 2016-05-27 11:38:54 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:38:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:38:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:38:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:38:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:38:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:38:54 --> Model Class Initialized
INFO - 2016-05-27 11:38:54 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:38:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:38:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:38:54 --> Final output sent to browser
DEBUG - 2016-05-27 11:38:54 --> Total execution time: 0.0864
INFO - 2016-05-27 11:39:27 --> Config Class Initialized
INFO - 2016-05-27 11:39:27 --> Hooks Class Initialized
DEBUG - 2016-05-27 11:39:27 --> UTF-8 Support Enabled
INFO - 2016-05-27 11:39:27 --> Utf8 Class Initialized
INFO - 2016-05-27 11:39:27 --> URI Class Initialized
INFO - 2016-05-27 11:39:27 --> Router Class Initialized
INFO - 2016-05-27 11:39:27 --> Output Class Initialized
INFO - 2016-05-27 11:39:27 --> Security Class Initialized
DEBUG - 2016-05-27 11:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 11:39:27 --> CSRF cookie sent
INFO - 2016-05-27 11:39:27 --> Input Class Initialized
INFO - 2016-05-27 11:39:27 --> Language Class Initialized
INFO - 2016-05-27 11:39:27 --> Loader Class Initialized
INFO - 2016-05-27 11:39:27 --> Helper loaded: form_helper
INFO - 2016-05-27 11:39:27 --> Database Driver Class Initialized
INFO - 2016-05-27 11:39:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 11:39:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 11:39:27 --> Email Class Initialized
INFO - 2016-05-27 11:39:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 11:39:27 --> Helper loaded: cookie_helper
INFO - 2016-05-27 11:39:27 --> Helper loaded: language_helper
INFO - 2016-05-27 11:39:27 --> Helper loaded: url_helper
DEBUG - 2016-05-27 11:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:39:27 --> Model Class Initialized
INFO - 2016-05-27 11:39:27 --> Helper loaded: date_helper
INFO - 2016-05-27 11:39:27 --> Controller Class Initialized
INFO - 2016-05-27 11:39:27 --> Helper loaded: languages_helper
INFO - 2016-05-27 11:39:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 11:39:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 11:39:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 11:39:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 11:39:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 11:39:27 --> Model Class Initialized
INFO - 2016-05-27 11:39:27 --> Form Validation Class Initialized
DEBUG - 2016-05-27 11:39:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-05-27 11:39:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 11:39:27 --> Final output sent to browser
DEBUG - 2016-05-27 11:39:27 --> Total execution time: 0.1272
INFO - 2016-05-27 12:19:05 --> Config Class Initialized
INFO - 2016-05-27 12:19:05 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:19:05 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:19:05 --> Utf8 Class Initialized
INFO - 2016-05-27 12:19:05 --> URI Class Initialized
INFO - 2016-05-27 12:19:05 --> Router Class Initialized
INFO - 2016-05-27 12:19:05 --> Output Class Initialized
INFO - 2016-05-27 12:19:05 --> Security Class Initialized
DEBUG - 2016-05-27 12:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:19:05 --> CSRF cookie sent
INFO - 2016-05-27 12:19:05 --> Input Class Initialized
INFO - 2016-05-27 12:19:05 --> Language Class Initialized
INFO - 2016-05-27 12:19:05 --> Loader Class Initialized
INFO - 2016-05-27 12:19:05 --> Helper loaded: form_helper
INFO - 2016-05-27 12:19:05 --> Database Driver Class Initialized
INFO - 2016-05-27 12:19:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 12:19:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 12:19:05 --> Email Class Initialized
INFO - 2016-05-27 12:19:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 12:19:05 --> Helper loaded: cookie_helper
INFO - 2016-05-27 12:19:05 --> Helper loaded: language_helper
INFO - 2016-05-27 12:19:05 --> Helper loaded: url_helper
DEBUG - 2016-05-27 12:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 12:19:05 --> Model Class Initialized
INFO - 2016-05-27 12:19:05 --> Helper loaded: date_helper
INFO - 2016-05-27 12:19:05 --> Controller Class Initialized
INFO - 2016-05-27 12:19:05 --> Helper loaded: languages_helper
INFO - 2016-05-27 12:19:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 12:19:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 12:19:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 12:19:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 12:19:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 12:19:05 --> Model Class Initialized
INFO - 2016-05-27 12:19:05 --> Form Validation Class Initialized
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 12:19:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 12:19:05 --> Final output sent to browser
DEBUG - 2016-05-27 12:19:05 --> Total execution time: 0.0434
INFO - 2016-05-27 12:19:41 --> Config Class Initialized
INFO - 2016-05-27 12:19:41 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:19:41 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:19:41 --> Utf8 Class Initialized
INFO - 2016-05-27 12:19:41 --> URI Class Initialized
INFO - 2016-05-27 12:19:41 --> Router Class Initialized
INFO - 2016-05-27 12:19:41 --> Output Class Initialized
INFO - 2016-05-27 12:19:41 --> Security Class Initialized
DEBUG - 2016-05-27 12:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:19:41 --> CSRF cookie sent
INFO - 2016-05-27 12:19:41 --> Input Class Initialized
INFO - 2016-05-27 12:19:41 --> Language Class Initialized
INFO - 2016-05-27 12:19:41 --> Loader Class Initialized
INFO - 2016-05-27 12:19:41 --> Helper loaded: form_helper
INFO - 2016-05-27 12:19:41 --> Database Driver Class Initialized
INFO - 2016-05-27 12:19:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 12:19:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 12:19:41 --> Email Class Initialized
INFO - 2016-05-27 12:19:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 12:19:41 --> Helper loaded: cookie_helper
INFO - 2016-05-27 12:19:41 --> Helper loaded: language_helper
INFO - 2016-05-27 12:19:41 --> Helper loaded: url_helper
DEBUG - 2016-05-27 12:19:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 12:19:41 --> Model Class Initialized
INFO - 2016-05-27 12:19:41 --> Helper loaded: date_helper
INFO - 2016-05-27 12:19:41 --> Controller Class Initialized
INFO - 2016-05-27 12:19:41 --> Helper loaded: languages_helper
INFO - 2016-05-27 12:19:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 12:19:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 12:19:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 12:19:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 12:19:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 12:19:41 --> Model Class Initialized
INFO - 2016-05-27 12:19:41 --> Form Validation Class Initialized
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 12:19:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 12:19:41 --> Final output sent to browser
DEBUG - 2016-05-27 12:19:41 --> Total execution time: 0.0513
INFO - 2016-05-27 12:57:15 --> Config Class Initialized
INFO - 2016-05-27 12:57:15 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:57:15 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:57:15 --> Utf8 Class Initialized
INFO - 2016-05-27 12:57:15 --> URI Class Initialized
INFO - 2016-05-27 12:57:15 --> Router Class Initialized
INFO - 2016-05-27 12:57:15 --> Output Class Initialized
INFO - 2016-05-27 12:57:15 --> Security Class Initialized
DEBUG - 2016-05-27 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:57:15 --> CSRF cookie sent
INFO - 2016-05-27 12:57:15 --> Input Class Initialized
INFO - 2016-05-27 12:57:15 --> Language Class Initialized
INFO - 2016-05-27 12:57:15 --> Loader Class Initialized
INFO - 2016-05-27 12:57:15 --> Helper loaded: form_helper
INFO - 2016-05-27 12:57:15 --> Database Driver Class Initialized
INFO - 2016-05-27 12:57:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 12:57:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 12:57:15 --> Email Class Initialized
INFO - 2016-05-27 12:57:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 12:57:15 --> Helper loaded: cookie_helper
INFO - 2016-05-27 12:57:15 --> Helper loaded: language_helper
INFO - 2016-05-27 12:57:15 --> Helper loaded: url_helper
DEBUG - 2016-05-27 12:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 12:57:15 --> Model Class Initialized
INFO - 2016-05-27 12:57:15 --> Helper loaded: date_helper
INFO - 2016-05-27 12:57:15 --> Controller Class Initialized
INFO - 2016-05-27 12:57:15 --> Helper loaded: languages_helper
INFO - 2016-05-27 12:57:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 12:57:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 12:57:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 12:57:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 12:57:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 12:57:15 --> Model Class Initialized
INFO - 2016-05-27 12:57:15 --> Form Validation Class Initialized
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 12:57:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 12:57:15 --> Final output sent to browser
DEBUG - 2016-05-27 12:57:15 --> Total execution time: 0.1162
INFO - 2016-05-27 12:57:56 --> Config Class Initialized
INFO - 2016-05-27 12:57:56 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:57:56 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:57:56 --> Utf8 Class Initialized
INFO - 2016-05-27 12:57:56 --> URI Class Initialized
INFO - 2016-05-27 12:57:56 --> Router Class Initialized
INFO - 2016-05-27 12:57:56 --> Output Class Initialized
INFO - 2016-05-27 12:57:56 --> Security Class Initialized
DEBUG - 2016-05-27 12:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:57:56 --> CSRF cookie sent
INFO - 2016-05-27 12:57:56 --> Input Class Initialized
INFO - 2016-05-27 12:57:56 --> Language Class Initialized
INFO - 2016-05-27 12:57:56 --> Loader Class Initialized
INFO - 2016-05-27 12:57:56 --> Helper loaded: form_helper
INFO - 2016-05-27 12:57:56 --> Database Driver Class Initialized
INFO - 2016-05-27 12:57:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 12:57:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 12:57:56 --> Email Class Initialized
INFO - 2016-05-27 12:57:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 12:57:56 --> Helper loaded: cookie_helper
INFO - 2016-05-27 12:57:56 --> Helper loaded: language_helper
INFO - 2016-05-27 12:57:56 --> Helper loaded: url_helper
DEBUG - 2016-05-27 12:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 12:57:56 --> Model Class Initialized
INFO - 2016-05-27 12:57:56 --> Helper loaded: date_helper
INFO - 2016-05-27 12:57:56 --> Controller Class Initialized
INFO - 2016-05-27 12:57:56 --> Helper loaded: languages_helper
INFO - 2016-05-27 12:57:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 12:57:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 12:57:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 12:57:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 12:57:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 12:57:56 --> Model Class Initialized
INFO - 2016-05-27 12:57:56 --> Form Validation Class Initialized
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 12:57:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 12:57:56 --> Final output sent to browser
DEBUG - 2016-05-27 12:57:56 --> Total execution time: 0.0708
INFO - 2016-05-27 12:57:58 --> Config Class Initialized
INFO - 2016-05-27 12:57:58 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:57:58 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:57:58 --> Utf8 Class Initialized
INFO - 2016-05-27 12:57:58 --> URI Class Initialized
INFO - 2016-05-27 12:57:58 --> Router Class Initialized
INFO - 2016-05-27 12:57:58 --> Output Class Initialized
INFO - 2016-05-27 12:57:58 --> Security Class Initialized
DEBUG - 2016-05-27 12:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:58:25 --> Config Class Initialized
INFO - 2016-05-27 12:58:25 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:58:25 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:58:25 --> Utf8 Class Initialized
INFO - 2016-05-27 12:58:25 --> URI Class Initialized
INFO - 2016-05-27 12:58:25 --> Router Class Initialized
INFO - 2016-05-27 12:58:25 --> Output Class Initialized
INFO - 2016-05-27 12:58:25 --> Security Class Initialized
DEBUG - 2016-05-27 12:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:58:25 --> CSRF cookie sent
INFO - 2016-05-27 12:58:25 --> Input Class Initialized
INFO - 2016-05-27 12:58:25 --> Language Class Initialized
INFO - 2016-05-27 12:58:25 --> Loader Class Initialized
INFO - 2016-05-27 12:58:25 --> Helper loaded: form_helper
INFO - 2016-05-27 12:58:25 --> Database Driver Class Initialized
INFO - 2016-05-27 12:58:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 12:58:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 12:58:25 --> Email Class Initialized
INFO - 2016-05-27 12:58:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 12:58:25 --> Helper loaded: cookie_helper
INFO - 2016-05-27 12:58:25 --> Helper loaded: language_helper
INFO - 2016-05-27 12:58:25 --> Helper loaded: url_helper
DEBUG - 2016-05-27 12:58:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 12:58:25 --> Model Class Initialized
INFO - 2016-05-27 12:58:25 --> Helper loaded: date_helper
INFO - 2016-05-27 12:58:25 --> Controller Class Initialized
INFO - 2016-05-27 12:58:25 --> Helper loaded: languages_helper
INFO - 2016-05-27 12:58:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 12:58:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 12:58:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 12:58:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 12:58:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 12:58:25 --> Model Class Initialized
INFO - 2016-05-27 12:58:25 --> Form Validation Class Initialized
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 12:58:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 12:58:25 --> Final output sent to browser
DEBUG - 2016-05-27 12:58:25 --> Total execution time: 0.0902
INFO - 2016-05-27 12:58:28 --> Config Class Initialized
INFO - 2016-05-27 12:58:28 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:58:28 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:58:28 --> Utf8 Class Initialized
INFO - 2016-05-27 12:58:28 --> URI Class Initialized
INFO - 2016-05-27 12:58:28 --> Router Class Initialized
INFO - 2016-05-27 12:58:28 --> Output Class Initialized
INFO - 2016-05-27 12:58:28 --> Security Class Initialized
DEBUG - 2016-05-27 12:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:58:55 --> Config Class Initialized
INFO - 2016-05-27 12:58:55 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:58:55 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:58:55 --> Utf8 Class Initialized
INFO - 2016-05-27 12:58:55 --> URI Class Initialized
INFO - 2016-05-27 12:58:55 --> Router Class Initialized
INFO - 2016-05-27 12:58:55 --> Output Class Initialized
INFO - 2016-05-27 12:58:55 --> Security Class Initialized
DEBUG - 2016-05-27 12:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 12:58:55 --> CSRF cookie sent
INFO - 2016-05-27 12:58:55 --> Input Class Initialized
INFO - 2016-05-27 12:58:55 --> Language Class Initialized
INFO - 2016-05-27 12:58:55 --> Loader Class Initialized
INFO - 2016-05-27 12:58:55 --> Helper loaded: form_helper
INFO - 2016-05-27 12:58:55 --> Database Driver Class Initialized
INFO - 2016-05-27 12:58:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 12:58:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 12:58:55 --> Email Class Initialized
INFO - 2016-05-27 12:58:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 12:58:55 --> Helper loaded: cookie_helper
INFO - 2016-05-27 12:58:55 --> Helper loaded: language_helper
INFO - 2016-05-27 12:58:55 --> Helper loaded: url_helper
DEBUG - 2016-05-27 12:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 12:58:55 --> Model Class Initialized
INFO - 2016-05-27 12:58:55 --> Helper loaded: date_helper
INFO - 2016-05-27 12:58:55 --> Controller Class Initialized
INFO - 2016-05-27 12:58:55 --> Helper loaded: languages_helper
INFO - 2016-05-27 12:58:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 12:58:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 12:58:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 12:58:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 12:58:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 12:58:55 --> Model Class Initialized
INFO - 2016-05-27 12:58:55 --> Form Validation Class Initialized
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 12:58:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 12:58:55 --> Final output sent to browser
DEBUG - 2016-05-27 12:58:55 --> Total execution time: 0.0781
INFO - 2016-05-27 12:58:58 --> Config Class Initialized
INFO - 2016-05-27 12:58:58 --> Hooks Class Initialized
DEBUG - 2016-05-27 12:58:58 --> UTF-8 Support Enabled
INFO - 2016-05-27 12:58:58 --> Utf8 Class Initialized
INFO - 2016-05-27 12:58:58 --> URI Class Initialized
INFO - 2016-05-27 12:58:58 --> Router Class Initialized
INFO - 2016-05-27 12:58:58 --> Output Class Initialized
INFO - 2016-05-27 12:58:58 --> Security Class Initialized
DEBUG - 2016-05-27 12:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:05:56 --> Config Class Initialized
INFO - 2016-05-27 13:05:56 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:05:56 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:05:56 --> Utf8 Class Initialized
INFO - 2016-05-27 13:05:56 --> URI Class Initialized
INFO - 2016-05-27 13:05:56 --> Router Class Initialized
INFO - 2016-05-27 13:05:56 --> Output Class Initialized
INFO - 2016-05-27 13:05:56 --> Security Class Initialized
DEBUG - 2016-05-27 13:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:05:56 --> CSRF cookie sent
INFO - 2016-05-27 13:05:56 --> Input Class Initialized
INFO - 2016-05-27 13:05:56 --> Language Class Initialized
INFO - 2016-05-27 13:05:56 --> Loader Class Initialized
INFO - 2016-05-27 13:05:56 --> Helper loaded: form_helper
INFO - 2016-05-27 13:05:56 --> Database Driver Class Initialized
INFO - 2016-05-27 13:05:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:05:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:05:56 --> Email Class Initialized
INFO - 2016-05-27 13:05:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:05:56 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:05:56 --> Helper loaded: language_helper
INFO - 2016-05-27 13:05:56 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:05:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:05:56 --> Model Class Initialized
INFO - 2016-05-27 13:05:56 --> Helper loaded: date_helper
INFO - 2016-05-27 13:05:56 --> Controller Class Initialized
INFO - 2016-05-27 13:05:56 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:05:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:05:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:05:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:05:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:05:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:05:56 --> Model Class Initialized
INFO - 2016-05-27 13:05:56 --> Form Validation Class Initialized
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:05:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:05:56 --> Final output sent to browser
DEBUG - 2016-05-27 13:05:56 --> Total execution time: 0.0443
INFO - 2016-05-27 13:05:58 --> Config Class Initialized
INFO - 2016-05-27 13:05:58 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:05:58 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:05:58 --> Utf8 Class Initialized
INFO - 2016-05-27 13:05:58 --> URI Class Initialized
INFO - 2016-05-27 13:05:58 --> Router Class Initialized
INFO - 2016-05-27 13:05:58 --> Output Class Initialized
INFO - 2016-05-27 13:05:58 --> Security Class Initialized
DEBUG - 2016-05-27 13:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:07:32 --> Config Class Initialized
INFO - 2016-05-27 13:07:32 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:07:32 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:07:32 --> Utf8 Class Initialized
INFO - 2016-05-27 13:07:32 --> URI Class Initialized
INFO - 2016-05-27 13:07:32 --> Router Class Initialized
INFO - 2016-05-27 13:07:32 --> Output Class Initialized
INFO - 2016-05-27 13:07:32 --> Security Class Initialized
DEBUG - 2016-05-27 13:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:07:32 --> CSRF cookie sent
INFO - 2016-05-27 13:07:32 --> Input Class Initialized
INFO - 2016-05-27 13:07:32 --> Language Class Initialized
INFO - 2016-05-27 13:07:32 --> Loader Class Initialized
INFO - 2016-05-27 13:07:32 --> Helper loaded: form_helper
INFO - 2016-05-27 13:07:32 --> Database Driver Class Initialized
INFO - 2016-05-27 13:07:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:07:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:07:32 --> Email Class Initialized
INFO - 2016-05-27 13:07:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:07:32 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:07:32 --> Helper loaded: language_helper
INFO - 2016-05-27 13:07:32 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:07:32 --> Model Class Initialized
INFO - 2016-05-27 13:07:32 --> Helper loaded: date_helper
INFO - 2016-05-27 13:07:32 --> Controller Class Initialized
INFO - 2016-05-27 13:07:32 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:07:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:07:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:07:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:07:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:07:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:07:32 --> Model Class Initialized
INFO - 2016-05-27 13:07:32 --> Form Validation Class Initialized
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:07:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:07:32 --> Final output sent to browser
DEBUG - 2016-05-27 13:07:32 --> Total execution time: 0.0626
INFO - 2016-05-27 13:07:34 --> Config Class Initialized
INFO - 2016-05-27 13:07:34 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:07:34 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:07:34 --> Utf8 Class Initialized
INFO - 2016-05-27 13:07:34 --> URI Class Initialized
INFO - 2016-05-27 13:07:34 --> Router Class Initialized
INFO - 2016-05-27 13:07:34 --> Output Class Initialized
INFO - 2016-05-27 13:07:34 --> Security Class Initialized
DEBUG - 2016-05-27 13:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:39:28 --> Config Class Initialized
INFO - 2016-05-27 13:39:28 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:39:28 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:39:28 --> Utf8 Class Initialized
INFO - 2016-05-27 13:39:28 --> URI Class Initialized
INFO - 2016-05-27 13:39:28 --> Router Class Initialized
INFO - 2016-05-27 13:39:28 --> Output Class Initialized
INFO - 2016-05-27 13:39:28 --> Security Class Initialized
DEBUG - 2016-05-27 13:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:39:28 --> CSRF cookie sent
INFO - 2016-05-27 13:39:28 --> Input Class Initialized
INFO - 2016-05-27 13:39:28 --> Language Class Initialized
INFO - 2016-05-27 13:39:28 --> Loader Class Initialized
INFO - 2016-05-27 13:39:28 --> Helper loaded: form_helper
INFO - 2016-05-27 13:39:28 --> Database Driver Class Initialized
INFO - 2016-05-27 13:39:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:39:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:39:28 --> Email Class Initialized
INFO - 2016-05-27 13:39:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:39:28 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:39:28 --> Helper loaded: language_helper
INFO - 2016-05-27 13:39:28 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:39:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:39:28 --> Model Class Initialized
INFO - 2016-05-27 13:39:28 --> Helper loaded: date_helper
INFO - 2016-05-27 13:39:28 --> Controller Class Initialized
INFO - 2016-05-27 13:39:28 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:39:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:39:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:39:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:39:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:39:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:39:28 --> Model Class Initialized
INFO - 2016-05-27 13:39:28 --> Form Validation Class Initialized
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:39:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:39:28 --> Final output sent to browser
DEBUG - 2016-05-27 13:39:28 --> Total execution time: 0.0755
INFO - 2016-05-27 13:39:30 --> Config Class Initialized
INFO - 2016-05-27 13:39:30 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:39:30 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:39:30 --> Utf8 Class Initialized
INFO - 2016-05-27 13:39:30 --> URI Class Initialized
INFO - 2016-05-27 13:39:30 --> Router Class Initialized
INFO - 2016-05-27 13:39:30 --> Output Class Initialized
INFO - 2016-05-27 13:39:30 --> Security Class Initialized
DEBUG - 2016-05-27 13:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:39:37 --> Config Class Initialized
INFO - 2016-05-27 13:39:37 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:39:37 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:39:37 --> Utf8 Class Initialized
INFO - 2016-05-27 13:39:37 --> URI Class Initialized
INFO - 2016-05-27 13:39:37 --> Router Class Initialized
INFO - 2016-05-27 13:39:37 --> Output Class Initialized
INFO - 2016-05-27 13:39:37 --> Security Class Initialized
DEBUG - 2016-05-27 13:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:39:37 --> CSRF cookie sent
INFO - 2016-05-27 13:39:37 --> Input Class Initialized
INFO - 2016-05-27 13:39:37 --> Language Class Initialized
INFO - 2016-05-27 13:39:37 --> Loader Class Initialized
INFO - 2016-05-27 13:39:37 --> Helper loaded: form_helper
INFO - 2016-05-27 13:39:37 --> Database Driver Class Initialized
INFO - 2016-05-27 13:39:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:39:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:39:37 --> Email Class Initialized
INFO - 2016-05-27 13:39:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:39:37 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:39:37 --> Helper loaded: language_helper
INFO - 2016-05-27 13:39:37 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:39:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:39:37 --> Model Class Initialized
INFO - 2016-05-27 13:39:37 --> Helper loaded: date_helper
INFO - 2016-05-27 13:39:37 --> Controller Class Initialized
INFO - 2016-05-27 13:39:37 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:39:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:39:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:39:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:39:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:39:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:39:37 --> Model Class Initialized
INFO - 2016-05-27 13:39:37 --> Form Validation Class Initialized
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:39:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:39:37 --> Final output sent to browser
DEBUG - 2016-05-27 13:39:37 --> Total execution time: 0.0956
INFO - 2016-05-27 13:39:42 --> Config Class Initialized
INFO - 2016-05-27 13:39:42 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:39:42 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:39:42 --> Utf8 Class Initialized
INFO - 2016-05-27 13:39:42 --> URI Class Initialized
INFO - 2016-05-27 13:39:42 --> Router Class Initialized
INFO - 2016-05-27 13:39:42 --> Output Class Initialized
INFO - 2016-05-27 13:39:42 --> Security Class Initialized
DEBUG - 2016-05-27 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:40:37 --> Config Class Initialized
INFO - 2016-05-27 13:40:37 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:40:37 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:40:37 --> Utf8 Class Initialized
INFO - 2016-05-27 13:40:37 --> URI Class Initialized
INFO - 2016-05-27 13:40:37 --> Router Class Initialized
INFO - 2016-05-27 13:40:37 --> Output Class Initialized
INFO - 2016-05-27 13:40:37 --> Security Class Initialized
DEBUG - 2016-05-27 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:40:37 --> CSRF cookie sent
INFO - 2016-05-27 13:40:37 --> Input Class Initialized
INFO - 2016-05-27 13:40:37 --> Language Class Initialized
INFO - 2016-05-27 13:40:37 --> Loader Class Initialized
INFO - 2016-05-27 13:40:37 --> Helper loaded: form_helper
INFO - 2016-05-27 13:40:37 --> Database Driver Class Initialized
INFO - 2016-05-27 13:40:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:40:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:40:37 --> Email Class Initialized
INFO - 2016-05-27 13:40:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:40:37 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:40:37 --> Helper loaded: language_helper
INFO - 2016-05-27 13:40:37 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:40:37 --> Model Class Initialized
INFO - 2016-05-27 13:40:37 --> Helper loaded: date_helper
INFO - 2016-05-27 13:40:37 --> Controller Class Initialized
INFO - 2016-05-27 13:40:37 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:40:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:40:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:40:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:40:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:40:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:40:37 --> Model Class Initialized
INFO - 2016-05-27 13:40:37 --> Form Validation Class Initialized
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:40:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:40:37 --> Final output sent to browser
DEBUG - 2016-05-27 13:40:37 --> Total execution time: 0.0984
INFO - 2016-05-27 13:40:58 --> Config Class Initialized
INFO - 2016-05-27 13:40:58 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:40:58 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:40:58 --> Utf8 Class Initialized
INFO - 2016-05-27 13:40:58 --> URI Class Initialized
INFO - 2016-05-27 13:40:58 --> Router Class Initialized
INFO - 2016-05-27 13:40:58 --> Output Class Initialized
INFO - 2016-05-27 13:40:58 --> Security Class Initialized
DEBUG - 2016-05-27 13:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:40:58 --> CSRF cookie sent
INFO - 2016-05-27 13:40:58 --> Input Class Initialized
INFO - 2016-05-27 13:40:58 --> Language Class Initialized
INFO - 2016-05-27 13:40:58 --> Loader Class Initialized
INFO - 2016-05-27 13:40:58 --> Helper loaded: form_helper
INFO - 2016-05-27 13:40:58 --> Database Driver Class Initialized
INFO - 2016-05-27 13:40:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:40:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:40:58 --> Email Class Initialized
INFO - 2016-05-27 13:40:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:40:58 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:40:58 --> Helper loaded: language_helper
INFO - 2016-05-27 13:40:58 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:40:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:40:58 --> Model Class Initialized
INFO - 2016-05-27 13:40:58 --> Helper loaded: date_helper
INFO - 2016-05-27 13:40:58 --> Controller Class Initialized
INFO - 2016-05-27 13:40:58 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:40:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:40:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:40:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:40:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:40:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:40:58 --> Model Class Initialized
INFO - 2016-05-27 13:40:58 --> Form Validation Class Initialized
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:40:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:40:58 --> Final output sent to browser
DEBUG - 2016-05-27 13:40:58 --> Total execution time: 0.0931
INFO - 2016-05-27 13:41:00 --> Config Class Initialized
INFO - 2016-05-27 13:41:00 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:41:00 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:41:00 --> Utf8 Class Initialized
INFO - 2016-05-27 13:41:00 --> URI Class Initialized
INFO - 2016-05-27 13:41:00 --> Router Class Initialized
INFO - 2016-05-27 13:41:00 --> Output Class Initialized
INFO - 2016-05-27 13:41:00 --> Security Class Initialized
DEBUG - 2016-05-27 13:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:41:26 --> Config Class Initialized
INFO - 2016-05-27 13:41:26 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:41:26 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:41:26 --> Utf8 Class Initialized
INFO - 2016-05-27 13:41:26 --> URI Class Initialized
INFO - 2016-05-27 13:41:26 --> Router Class Initialized
INFO - 2016-05-27 13:41:26 --> Output Class Initialized
INFO - 2016-05-27 13:41:26 --> Security Class Initialized
DEBUG - 2016-05-27 13:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:41:26 --> CSRF cookie sent
INFO - 2016-05-27 13:41:26 --> Input Class Initialized
INFO - 2016-05-27 13:41:26 --> Language Class Initialized
INFO - 2016-05-27 13:41:26 --> Loader Class Initialized
INFO - 2016-05-27 13:41:26 --> Helper loaded: form_helper
INFO - 2016-05-27 13:41:26 --> Database Driver Class Initialized
INFO - 2016-05-27 13:41:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:41:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:41:26 --> Email Class Initialized
INFO - 2016-05-27 13:41:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:41:26 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:41:26 --> Helper loaded: language_helper
INFO - 2016-05-27 13:41:26 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:41:26 --> Model Class Initialized
INFO - 2016-05-27 13:41:26 --> Helper loaded: date_helper
INFO - 2016-05-27 13:41:26 --> Controller Class Initialized
INFO - 2016-05-27 13:41:26 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:41:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:41:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:41:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:41:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:41:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:41:26 --> Model Class Initialized
INFO - 2016-05-27 13:41:26 --> Form Validation Class Initialized
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:41:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:41:26 --> Final output sent to browser
DEBUG - 2016-05-27 13:41:26 --> Total execution time: 0.0603
INFO - 2016-05-27 13:41:29 --> Config Class Initialized
INFO - 2016-05-27 13:41:29 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:41:29 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:41:29 --> Utf8 Class Initialized
INFO - 2016-05-27 13:41:29 --> URI Class Initialized
INFO - 2016-05-27 13:41:29 --> Router Class Initialized
INFO - 2016-05-27 13:41:29 --> Output Class Initialized
INFO - 2016-05-27 13:41:29 --> Security Class Initialized
DEBUG - 2016-05-27 13:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:41:40 --> Config Class Initialized
INFO - 2016-05-27 13:41:40 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:41:40 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:41:40 --> Utf8 Class Initialized
INFO - 2016-05-27 13:41:40 --> URI Class Initialized
INFO - 2016-05-27 13:41:40 --> Router Class Initialized
INFO - 2016-05-27 13:41:40 --> Output Class Initialized
INFO - 2016-05-27 13:41:40 --> Security Class Initialized
DEBUG - 2016-05-27 13:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:41:40 --> CSRF cookie sent
INFO - 2016-05-27 13:41:40 --> Input Class Initialized
INFO - 2016-05-27 13:41:40 --> Language Class Initialized
INFO - 2016-05-27 13:41:40 --> Loader Class Initialized
INFO - 2016-05-27 13:41:40 --> Helper loaded: form_helper
INFO - 2016-05-27 13:41:40 --> Database Driver Class Initialized
INFO - 2016-05-27 13:41:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:41:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:41:40 --> Email Class Initialized
INFO - 2016-05-27 13:41:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:41:40 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:41:40 --> Helper loaded: language_helper
INFO - 2016-05-27 13:41:40 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:41:40 --> Model Class Initialized
INFO - 2016-05-27 13:41:40 --> Helper loaded: date_helper
INFO - 2016-05-27 13:41:40 --> Controller Class Initialized
INFO - 2016-05-27 13:41:40 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:41:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:41:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:41:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:41:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:41:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:41:40 --> Model Class Initialized
INFO - 2016-05-27 13:41:40 --> Form Validation Class Initialized
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:41:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:41:40 --> Final output sent to browser
DEBUG - 2016-05-27 13:41:40 --> Total execution time: 0.0751
INFO - 2016-05-27 13:41:45 --> Config Class Initialized
INFO - 2016-05-27 13:41:45 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:41:45 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:41:45 --> Utf8 Class Initialized
INFO - 2016-05-27 13:41:45 --> URI Class Initialized
INFO - 2016-05-27 13:41:45 --> Router Class Initialized
INFO - 2016-05-27 13:41:45 --> Output Class Initialized
INFO - 2016-05-27 13:41:45 --> Security Class Initialized
DEBUG - 2016-05-27 13:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:41:54 --> Config Class Initialized
INFO - 2016-05-27 13:41:54 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:41:54 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:41:54 --> Utf8 Class Initialized
INFO - 2016-05-27 13:41:54 --> URI Class Initialized
INFO - 2016-05-27 13:41:54 --> Router Class Initialized
INFO - 2016-05-27 13:41:54 --> Output Class Initialized
INFO - 2016-05-27 13:41:54 --> Security Class Initialized
DEBUG - 2016-05-27 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:41:54 --> CSRF cookie sent
INFO - 2016-05-27 13:41:54 --> Input Class Initialized
INFO - 2016-05-27 13:41:54 --> Language Class Initialized
INFO - 2016-05-27 13:41:54 --> Loader Class Initialized
INFO - 2016-05-27 13:41:54 --> Helper loaded: form_helper
INFO - 2016-05-27 13:41:54 --> Database Driver Class Initialized
INFO - 2016-05-27 13:41:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:41:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:41:54 --> Email Class Initialized
INFO - 2016-05-27 13:41:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:41:54 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:41:54 --> Helper loaded: language_helper
INFO - 2016-05-27 13:41:54 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:41:54 --> Model Class Initialized
INFO - 2016-05-27 13:41:54 --> Helper loaded: date_helper
INFO - 2016-05-27 13:41:54 --> Controller Class Initialized
INFO - 2016-05-27 13:41:54 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:41:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:41:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:41:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:41:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:41:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:41:54 --> Model Class Initialized
INFO - 2016-05-27 13:41:54 --> Form Validation Class Initialized
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:41:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:41:54 --> Final output sent to browser
DEBUG - 2016-05-27 13:41:54 --> Total execution time: 0.0525
INFO - 2016-05-27 13:41:59 --> Config Class Initialized
INFO - 2016-05-27 13:41:59 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:41:59 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:41:59 --> Utf8 Class Initialized
INFO - 2016-05-27 13:41:59 --> URI Class Initialized
INFO - 2016-05-27 13:41:59 --> Router Class Initialized
INFO - 2016-05-27 13:41:59 --> Output Class Initialized
INFO - 2016-05-27 13:41:59 --> Security Class Initialized
DEBUG - 2016-05-27 13:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:42:14 --> Config Class Initialized
INFO - 2016-05-27 13:42:14 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:42:14 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:42:14 --> Utf8 Class Initialized
INFO - 2016-05-27 13:42:14 --> URI Class Initialized
INFO - 2016-05-27 13:42:14 --> Router Class Initialized
INFO - 2016-05-27 13:42:14 --> Output Class Initialized
INFO - 2016-05-27 13:42:14 --> Security Class Initialized
DEBUG - 2016-05-27 13:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:42:14 --> CSRF cookie sent
INFO - 2016-05-27 13:42:14 --> Input Class Initialized
INFO - 2016-05-27 13:42:14 --> Language Class Initialized
INFO - 2016-05-27 13:42:14 --> Loader Class Initialized
INFO - 2016-05-27 13:42:14 --> Helper loaded: form_helper
INFO - 2016-05-27 13:42:14 --> Database Driver Class Initialized
INFO - 2016-05-27 13:42:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:42:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:42:14 --> Email Class Initialized
INFO - 2016-05-27 13:42:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:42:14 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:42:14 --> Helper loaded: language_helper
INFO - 2016-05-27 13:42:14 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:42:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:42:14 --> Model Class Initialized
INFO - 2016-05-27 13:42:14 --> Helper loaded: date_helper
INFO - 2016-05-27 13:42:14 --> Controller Class Initialized
INFO - 2016-05-27 13:42:14 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:42:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:42:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:42:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:42:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:42:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:42:14 --> Model Class Initialized
INFO - 2016-05-27 13:42:14 --> Form Validation Class Initialized
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:42:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:42:14 --> Final output sent to browser
DEBUG - 2016-05-27 13:42:14 --> Total execution time: 0.1039
INFO - 2016-05-27 13:46:06 --> Config Class Initialized
INFO - 2016-05-27 13:46:06 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:46:06 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:46:06 --> Utf8 Class Initialized
INFO - 2016-05-27 13:46:06 --> URI Class Initialized
INFO - 2016-05-27 13:46:06 --> Router Class Initialized
INFO - 2016-05-27 13:46:06 --> Output Class Initialized
INFO - 2016-05-27 13:46:06 --> Security Class Initialized
DEBUG - 2016-05-27 13:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:46:06 --> CSRF cookie sent
INFO - 2016-05-27 13:46:06 --> Input Class Initialized
INFO - 2016-05-27 13:46:06 --> Language Class Initialized
INFO - 2016-05-27 13:46:06 --> Loader Class Initialized
INFO - 2016-05-27 13:46:06 --> Helper loaded: form_helper
INFO - 2016-05-27 13:46:06 --> Database Driver Class Initialized
INFO - 2016-05-27 13:46:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:46:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:46:06 --> Email Class Initialized
INFO - 2016-05-27 13:46:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:46:06 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:46:06 --> Helper loaded: language_helper
INFO - 2016-05-27 13:46:06 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:46:06 --> Model Class Initialized
INFO - 2016-05-27 13:46:06 --> Helper loaded: date_helper
INFO - 2016-05-27 13:46:06 --> Controller Class Initialized
INFO - 2016-05-27 13:46:06 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:46:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:46:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:46:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:46:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:46:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:46:06 --> Model Class Initialized
INFO - 2016-05-27 13:46:06 --> Form Validation Class Initialized
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:46:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:46:06 --> Final output sent to browser
DEBUG - 2016-05-27 13:46:06 --> Total execution time: 0.1040
INFO - 2016-05-27 13:46:31 --> Config Class Initialized
INFO - 2016-05-27 13:46:31 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:46:31 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:46:31 --> Utf8 Class Initialized
INFO - 2016-05-27 13:46:31 --> URI Class Initialized
INFO - 2016-05-27 13:46:31 --> Router Class Initialized
INFO - 2016-05-27 13:46:31 --> Output Class Initialized
INFO - 2016-05-27 13:46:31 --> Security Class Initialized
DEBUG - 2016-05-27 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:46:31 --> CSRF cookie sent
INFO - 2016-05-27 13:46:31 --> Input Class Initialized
INFO - 2016-05-27 13:46:31 --> Language Class Initialized
INFO - 2016-05-27 13:46:31 --> Loader Class Initialized
INFO - 2016-05-27 13:46:31 --> Helper loaded: form_helper
INFO - 2016-05-27 13:46:31 --> Database Driver Class Initialized
INFO - 2016-05-27 13:46:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:46:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:46:31 --> Email Class Initialized
INFO - 2016-05-27 13:46:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:46:31 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:46:31 --> Helper loaded: language_helper
INFO - 2016-05-27 13:46:31 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:46:31 --> Model Class Initialized
INFO - 2016-05-27 13:46:31 --> Helper loaded: date_helper
INFO - 2016-05-27 13:46:31 --> Controller Class Initialized
INFO - 2016-05-27 13:46:31 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:46:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:46:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:46:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:46:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:46:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:46:31 --> Model Class Initialized
INFO - 2016-05-27 13:46:31 --> Form Validation Class Initialized
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:46:31 --> Final output sent to browser
DEBUG - 2016-05-27 13:46:31 --> Total execution time: 0.0385
INFO - 2016-05-27 13:49:12 --> Config Class Initialized
INFO - 2016-05-27 13:49:12 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:49:12 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:49:12 --> Utf8 Class Initialized
INFO - 2016-05-27 13:49:12 --> URI Class Initialized
INFO - 2016-05-27 13:49:12 --> Router Class Initialized
INFO - 2016-05-27 13:49:12 --> Output Class Initialized
INFO - 2016-05-27 13:49:12 --> Security Class Initialized
DEBUG - 2016-05-27 13:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:49:12 --> CSRF cookie sent
INFO - 2016-05-27 13:49:12 --> Input Class Initialized
INFO - 2016-05-27 13:49:12 --> Language Class Initialized
INFO - 2016-05-27 13:49:12 --> Loader Class Initialized
INFO - 2016-05-27 13:49:12 --> Helper loaded: form_helper
INFO - 2016-05-27 13:49:12 --> Database Driver Class Initialized
INFO - 2016-05-27 13:49:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:49:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:49:12 --> Email Class Initialized
INFO - 2016-05-27 13:49:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:49:12 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:49:12 --> Helper loaded: language_helper
INFO - 2016-05-27 13:49:12 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:49:12 --> Model Class Initialized
INFO - 2016-05-27 13:49:12 --> Helper loaded: date_helper
INFO - 2016-05-27 13:49:12 --> Controller Class Initialized
INFO - 2016-05-27 13:49:12 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:49:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:49:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:49:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:49:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:49:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:49:12 --> Model Class Initialized
INFO - 2016-05-27 13:49:12 --> Form Validation Class Initialized
INFO - 2016-05-27 13:49:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:49:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:49:13 --> Final output sent to browser
DEBUG - 2016-05-27 13:49:13 --> Total execution time: 0.0488
INFO - 2016-05-27 13:51:37 --> Config Class Initialized
INFO - 2016-05-27 13:51:37 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:51:37 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:51:37 --> Utf8 Class Initialized
INFO - 2016-05-27 13:51:37 --> URI Class Initialized
INFO - 2016-05-27 13:51:37 --> Router Class Initialized
INFO - 2016-05-27 13:51:37 --> Output Class Initialized
INFO - 2016-05-27 13:51:37 --> Security Class Initialized
DEBUG - 2016-05-27 13:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:51:37 --> CSRF cookie sent
INFO - 2016-05-27 13:51:37 --> Input Class Initialized
INFO - 2016-05-27 13:51:37 --> Language Class Initialized
INFO - 2016-05-27 13:51:37 --> Loader Class Initialized
INFO - 2016-05-27 13:51:37 --> Helper loaded: form_helper
INFO - 2016-05-27 13:51:37 --> Database Driver Class Initialized
INFO - 2016-05-27 13:51:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:51:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:51:37 --> Email Class Initialized
INFO - 2016-05-27 13:51:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:51:37 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:51:37 --> Helper loaded: language_helper
INFO - 2016-05-27 13:51:37 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:51:37 --> Model Class Initialized
INFO - 2016-05-27 13:51:37 --> Helper loaded: date_helper
INFO - 2016-05-27 13:51:37 --> Controller Class Initialized
INFO - 2016-05-27 13:51:37 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:51:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:51:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:51:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:51:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:51:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:51:37 --> Model Class Initialized
INFO - 2016-05-27 13:51:37 --> Form Validation Class Initialized
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:51:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:51:37 --> Final output sent to browser
DEBUG - 2016-05-27 13:51:37 --> Total execution time: 0.0681
INFO - 2016-05-27 13:51:43 --> Config Class Initialized
INFO - 2016-05-27 13:51:43 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:51:43 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:51:43 --> Utf8 Class Initialized
INFO - 2016-05-27 13:51:43 --> URI Class Initialized
INFO - 2016-05-27 13:51:43 --> Router Class Initialized
INFO - 2016-05-27 13:51:43 --> Output Class Initialized
INFO - 2016-05-27 13:51:43 --> Security Class Initialized
DEBUG - 2016-05-27 13:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:52:20 --> Config Class Initialized
INFO - 2016-05-27 13:52:20 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:52:20 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:52:20 --> Utf8 Class Initialized
INFO - 2016-05-27 13:52:20 --> URI Class Initialized
INFO - 2016-05-27 13:52:20 --> Router Class Initialized
INFO - 2016-05-27 13:52:20 --> Output Class Initialized
INFO - 2016-05-27 13:52:20 --> Security Class Initialized
DEBUG - 2016-05-27 13:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:52:20 --> CSRF cookie sent
INFO - 2016-05-27 13:52:20 --> Input Class Initialized
INFO - 2016-05-27 13:52:20 --> Language Class Initialized
INFO - 2016-05-27 13:52:20 --> Loader Class Initialized
INFO - 2016-05-27 13:52:20 --> Helper loaded: form_helper
INFO - 2016-05-27 13:52:20 --> Database Driver Class Initialized
INFO - 2016-05-27 13:52:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:52:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:52:20 --> Email Class Initialized
INFO - 2016-05-27 13:52:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:52:20 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:52:20 --> Helper loaded: language_helper
INFO - 2016-05-27 13:52:20 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:52:20 --> Model Class Initialized
INFO - 2016-05-27 13:52:20 --> Helper loaded: date_helper
INFO - 2016-05-27 13:52:20 --> Controller Class Initialized
INFO - 2016-05-27 13:52:20 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:52:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:52:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:52:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:52:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:52:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:52:20 --> Model Class Initialized
INFO - 2016-05-27 13:52:20 --> Form Validation Class Initialized
INFO - 2016-05-27 13:52:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:52:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:52:21 --> Final output sent to browser
DEBUG - 2016-05-27 13:52:21 --> Total execution time: 0.0910
INFO - 2016-05-27 13:52:23 --> Config Class Initialized
INFO - 2016-05-27 13:52:23 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:52:23 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:52:23 --> Utf8 Class Initialized
INFO - 2016-05-27 13:52:23 --> URI Class Initialized
INFO - 2016-05-27 13:52:23 --> Router Class Initialized
INFO - 2016-05-27 13:52:23 --> Output Class Initialized
INFO - 2016-05-27 13:52:23 --> Security Class Initialized
DEBUG - 2016-05-27 13:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:52:45 --> Config Class Initialized
INFO - 2016-05-27 13:52:45 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:52:45 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:52:45 --> Utf8 Class Initialized
INFO - 2016-05-27 13:52:45 --> URI Class Initialized
INFO - 2016-05-27 13:52:45 --> Router Class Initialized
INFO - 2016-05-27 13:52:45 --> Output Class Initialized
INFO - 2016-05-27 13:52:45 --> Security Class Initialized
DEBUG - 2016-05-27 13:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:52:45 --> CSRF cookie sent
INFO - 2016-05-27 13:52:45 --> Input Class Initialized
INFO - 2016-05-27 13:52:45 --> Language Class Initialized
INFO - 2016-05-27 13:52:45 --> Loader Class Initialized
INFO - 2016-05-27 13:52:45 --> Helper loaded: form_helper
INFO - 2016-05-27 13:52:45 --> Database Driver Class Initialized
INFO - 2016-05-27 13:52:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:52:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:52:45 --> Email Class Initialized
INFO - 2016-05-27 13:52:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:52:45 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:52:45 --> Helper loaded: language_helper
INFO - 2016-05-27 13:52:45 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:52:45 --> Model Class Initialized
INFO - 2016-05-27 13:52:45 --> Helper loaded: date_helper
INFO - 2016-05-27 13:52:45 --> Controller Class Initialized
INFO - 2016-05-27 13:52:45 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:52:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:52:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:52:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:52:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:52:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:52:45 --> Model Class Initialized
INFO - 2016-05-27 13:52:45 --> Form Validation Class Initialized
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:52:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:52:45 --> Final output sent to browser
DEBUG - 2016-05-27 13:52:45 --> Total execution time: 0.0654
INFO - 2016-05-27 13:52:49 --> Config Class Initialized
INFO - 2016-05-27 13:52:49 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:52:49 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:52:49 --> Utf8 Class Initialized
INFO - 2016-05-27 13:52:49 --> URI Class Initialized
INFO - 2016-05-27 13:52:49 --> Router Class Initialized
INFO - 2016-05-27 13:52:49 --> Output Class Initialized
INFO - 2016-05-27 13:52:49 --> Security Class Initialized
DEBUG - 2016-05-27 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:52:49 --> CSRF cookie sent
INFO - 2016-05-27 13:52:49 --> CSRF token verified
INFO - 2016-05-27 13:52:49 --> Input Class Initialized
INFO - 2016-05-27 13:52:49 --> Language Class Initialized
INFO - 2016-05-27 13:52:49 --> Loader Class Initialized
INFO - 2016-05-27 13:52:49 --> Helper loaded: form_helper
INFO - 2016-05-27 13:52:49 --> Database Driver Class Initialized
INFO - 2016-05-27 13:52:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:52:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:52:49 --> Email Class Initialized
INFO - 2016-05-27 13:52:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:52:49 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:52:49 --> Helper loaded: language_helper
INFO - 2016-05-27 13:52:49 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:52:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:52:49 --> Model Class Initialized
INFO - 2016-05-27 13:52:49 --> Helper loaded: date_helper
INFO - 2016-05-27 13:52:49 --> Controller Class Initialized
INFO - 2016-05-27 13:52:49 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:52:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:52:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:52:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:52:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:52:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:52:49 --> Model Class Initialized
INFO - 2016-05-27 13:52:49 --> Form Validation Class Initialized
INFO - 2016-05-27 13:52:49 --> Final output sent to browser
DEBUG - 2016-05-27 13:52:49 --> Total execution time: 0.0476
INFO - 2016-05-27 13:54:12 --> Config Class Initialized
INFO - 2016-05-27 13:54:12 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:54:12 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:54:12 --> Utf8 Class Initialized
INFO - 2016-05-27 13:54:12 --> URI Class Initialized
INFO - 2016-05-27 13:54:12 --> Router Class Initialized
INFO - 2016-05-27 13:54:12 --> Output Class Initialized
INFO - 2016-05-27 13:54:12 --> Security Class Initialized
DEBUG - 2016-05-27 13:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:54:12 --> CSRF cookie sent
INFO - 2016-05-27 13:54:12 --> Input Class Initialized
INFO - 2016-05-27 13:54:12 --> Language Class Initialized
INFO - 2016-05-27 13:54:12 --> Loader Class Initialized
INFO - 2016-05-27 13:54:12 --> Helper loaded: form_helper
INFO - 2016-05-27 13:54:12 --> Database Driver Class Initialized
INFO - 2016-05-27 13:54:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:54:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:54:12 --> Email Class Initialized
INFO - 2016-05-27 13:54:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:54:12 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:54:12 --> Helper loaded: language_helper
INFO - 2016-05-27 13:54:12 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:54:12 --> Model Class Initialized
INFO - 2016-05-27 13:54:12 --> Helper loaded: date_helper
INFO - 2016-05-27 13:54:12 --> Controller Class Initialized
INFO - 2016-05-27 13:54:12 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:54:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:54:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:54:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:54:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:54:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:54:12 --> Model Class Initialized
INFO - 2016-05-27 13:54:12 --> Form Validation Class Initialized
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 13:54:12 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 13:54:12 --> Final output sent to browser
DEBUG - 2016-05-27 13:54:12 --> Total execution time: 0.0924
INFO - 2016-05-27 13:54:15 --> Config Class Initialized
INFO - 2016-05-27 13:54:15 --> Hooks Class Initialized
DEBUG - 2016-05-27 13:54:15 --> UTF-8 Support Enabled
INFO - 2016-05-27 13:54:15 --> Utf8 Class Initialized
INFO - 2016-05-27 13:54:15 --> URI Class Initialized
INFO - 2016-05-27 13:54:15 --> Router Class Initialized
INFO - 2016-05-27 13:54:15 --> Output Class Initialized
INFO - 2016-05-27 13:54:15 --> Security Class Initialized
DEBUG - 2016-05-27 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 13:54:15 --> CSRF cookie sent
INFO - 2016-05-27 13:54:15 --> CSRF token verified
INFO - 2016-05-27 13:54:15 --> Input Class Initialized
INFO - 2016-05-27 13:54:15 --> Language Class Initialized
INFO - 2016-05-27 13:54:15 --> Loader Class Initialized
INFO - 2016-05-27 13:54:15 --> Helper loaded: form_helper
INFO - 2016-05-27 13:54:15 --> Database Driver Class Initialized
INFO - 2016-05-27 13:54:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 13:54:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 13:54:15 --> Email Class Initialized
INFO - 2016-05-27 13:54:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 13:54:15 --> Helper loaded: cookie_helper
INFO - 2016-05-27 13:54:15 --> Helper loaded: language_helper
INFO - 2016-05-27 13:54:15 --> Helper loaded: url_helper
DEBUG - 2016-05-27 13:54:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 13:54:15 --> Model Class Initialized
INFO - 2016-05-27 13:54:15 --> Helper loaded: date_helper
INFO - 2016-05-27 13:54:15 --> Controller Class Initialized
INFO - 2016-05-27 13:54:15 --> Helper loaded: languages_helper
INFO - 2016-05-27 13:54:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 13:54:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 13:54:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 13:54:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 13:54:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 13:54:15 --> Model Class Initialized
INFO - 2016-05-27 13:54:15 --> Form Validation Class Initialized
INFO - 2016-05-27 13:54:15 --> Final output sent to browser
DEBUG - 2016-05-27 13:54:15 --> Total execution time: 0.0472
INFO - 2016-05-27 14:02:28 --> Config Class Initialized
INFO - 2016-05-27 14:02:28 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:02:28 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:02:28 --> Utf8 Class Initialized
INFO - 2016-05-27 14:02:28 --> URI Class Initialized
INFO - 2016-05-27 14:02:28 --> Router Class Initialized
INFO - 2016-05-27 14:02:28 --> Output Class Initialized
INFO - 2016-05-27 14:02:28 --> Security Class Initialized
DEBUG - 2016-05-27 14:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:02:28 --> CSRF cookie sent
INFO - 2016-05-27 14:02:28 --> Input Class Initialized
INFO - 2016-05-27 14:02:28 --> Language Class Initialized
INFO - 2016-05-27 14:02:28 --> Loader Class Initialized
INFO - 2016-05-27 14:02:28 --> Helper loaded: form_helper
INFO - 2016-05-27 14:02:28 --> Database Driver Class Initialized
INFO - 2016-05-27 14:02:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:02:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:02:28 --> Email Class Initialized
INFO - 2016-05-27 14:02:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:02:28 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:02:28 --> Helper loaded: language_helper
INFO - 2016-05-27 14:02:28 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:02:28 --> Model Class Initialized
INFO - 2016-05-27 14:02:28 --> Helper loaded: date_helper
INFO - 2016-05-27 14:02:28 --> Controller Class Initialized
INFO - 2016-05-27 14:02:28 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:02:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:02:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:02:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:02:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:02:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:02:28 --> Model Class Initialized
INFO - 2016-05-27 14:02:28 --> Form Validation Class Initialized
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:02:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:02:28 --> Final output sent to browser
DEBUG - 2016-05-27 14:02:28 --> Total execution time: 0.0882
INFO - 2016-05-27 14:02:35 --> Config Class Initialized
INFO - 2016-05-27 14:02:35 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:02:35 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:02:35 --> Utf8 Class Initialized
INFO - 2016-05-27 14:02:35 --> URI Class Initialized
INFO - 2016-05-27 14:02:35 --> Router Class Initialized
INFO - 2016-05-27 14:02:35 --> Output Class Initialized
INFO - 2016-05-27 14:02:35 --> Security Class Initialized
DEBUG - 2016-05-27 14:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:02:35 --> CSRF cookie sent
INFO - 2016-05-27 14:02:35 --> CSRF token verified
INFO - 2016-05-27 14:02:35 --> Input Class Initialized
INFO - 2016-05-27 14:02:35 --> Language Class Initialized
INFO - 2016-05-27 14:02:35 --> Loader Class Initialized
INFO - 2016-05-27 14:02:35 --> Helper loaded: form_helper
INFO - 2016-05-27 14:02:35 --> Database Driver Class Initialized
INFO - 2016-05-27 14:02:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:02:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:02:35 --> Email Class Initialized
INFO - 2016-05-27 14:02:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:02:35 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:02:35 --> Helper loaded: language_helper
INFO - 2016-05-27 14:02:35 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:02:35 --> Model Class Initialized
INFO - 2016-05-27 14:02:35 --> Helper loaded: date_helper
INFO - 2016-05-27 14:02:35 --> Controller Class Initialized
INFO - 2016-05-27 14:02:35 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:02:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:02:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:02:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:02:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:02:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:02:35 --> Model Class Initialized
INFO - 2016-05-27 14:02:35 --> Form Validation Class Initialized
ERROR - 2016-05-27 14:02:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM 
                    1_glicemie 
                WHERE 
                   ' at line 12 - Invalid query: 
                SELECT 
                    `interval_1`,
                    `interval_2`,
                    `interval_3`,
                    `interval_4`,
                    `interval_5`,
                    `interval_6`,
                    `interval_7`,
                    `interval_8`,
                    `interval_9`,
                    `interval_10`,          
                FROM 
                    1_glicemie 
                WHERE 
                    `fk_user` = 2
                AND 
                    DATE(`date`) > (NOW() - INTERVAL 7 DAY)
                LIMIT
                    7
            
INFO - 2016-05-27 14:03:56 --> Config Class Initialized
INFO - 2016-05-27 14:03:56 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:03:56 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:03:56 --> Utf8 Class Initialized
INFO - 2016-05-27 14:03:56 --> URI Class Initialized
INFO - 2016-05-27 14:03:56 --> Router Class Initialized
INFO - 2016-05-27 14:03:56 --> Output Class Initialized
INFO - 2016-05-27 14:03:56 --> Security Class Initialized
DEBUG - 2016-05-27 14:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:03:56 --> CSRF cookie sent
INFO - 2016-05-27 14:03:56 --> Input Class Initialized
INFO - 2016-05-27 14:03:56 --> Language Class Initialized
INFO - 2016-05-27 14:03:56 --> Loader Class Initialized
INFO - 2016-05-27 14:03:56 --> Helper loaded: form_helper
INFO - 2016-05-27 14:03:56 --> Database Driver Class Initialized
INFO - 2016-05-27 14:03:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:03:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:03:56 --> Email Class Initialized
INFO - 2016-05-27 14:03:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:03:56 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:03:56 --> Helper loaded: language_helper
INFO - 2016-05-27 14:03:56 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:03:56 --> Model Class Initialized
INFO - 2016-05-27 14:03:56 --> Helper loaded: date_helper
INFO - 2016-05-27 14:03:56 --> Controller Class Initialized
INFO - 2016-05-27 14:03:56 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:03:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:03:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:03:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:03:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:03:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:03:56 --> Model Class Initialized
INFO - 2016-05-27 14:03:56 --> Form Validation Class Initialized
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:03:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:03:56 --> Final output sent to browser
DEBUG - 2016-05-27 14:03:56 --> Total execution time: 0.0635
INFO - 2016-05-27 14:03:59 --> Config Class Initialized
INFO - 2016-05-27 14:03:59 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:03:59 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:03:59 --> Utf8 Class Initialized
INFO - 2016-05-27 14:03:59 --> URI Class Initialized
INFO - 2016-05-27 14:03:59 --> Router Class Initialized
INFO - 2016-05-27 14:03:59 --> Output Class Initialized
INFO - 2016-05-27 14:03:59 --> Security Class Initialized
DEBUG - 2016-05-27 14:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:03:59 --> CSRF cookie sent
INFO - 2016-05-27 14:03:59 --> CSRF token verified
INFO - 2016-05-27 14:03:59 --> Input Class Initialized
INFO - 2016-05-27 14:03:59 --> Language Class Initialized
INFO - 2016-05-27 14:03:59 --> Loader Class Initialized
INFO - 2016-05-27 14:03:59 --> Helper loaded: form_helper
INFO - 2016-05-27 14:03:59 --> Database Driver Class Initialized
INFO - 2016-05-27 14:03:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:03:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:03:59 --> Email Class Initialized
INFO - 2016-05-27 14:03:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:03:59 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:03:59 --> Helper loaded: language_helper
INFO - 2016-05-27 14:03:59 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:03:59 --> Model Class Initialized
INFO - 2016-05-27 14:03:59 --> Helper loaded: date_helper
INFO - 2016-05-27 14:03:59 --> Controller Class Initialized
INFO - 2016-05-27 14:03:59 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:03:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:03:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:03:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:03:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:03:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:03:59 --> Model Class Initialized
INFO - 2016-05-27 14:03:59 --> Form Validation Class Initialized
INFO - 2016-05-27 14:03:59 --> Final output sent to browser
DEBUG - 2016-05-27 14:03:59 --> Total execution time: 0.0814
INFO - 2016-05-27 14:05:22 --> Config Class Initialized
INFO - 2016-05-27 14:05:22 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:05:22 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:05:22 --> Utf8 Class Initialized
INFO - 2016-05-27 14:05:22 --> URI Class Initialized
INFO - 2016-05-27 14:05:22 --> Router Class Initialized
INFO - 2016-05-27 14:05:22 --> Output Class Initialized
INFO - 2016-05-27 14:05:22 --> Security Class Initialized
DEBUG - 2016-05-27 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:05:22 --> CSRF cookie sent
INFO - 2016-05-27 14:05:22 --> Input Class Initialized
INFO - 2016-05-27 14:05:22 --> Language Class Initialized
INFO - 2016-05-27 14:05:22 --> Loader Class Initialized
INFO - 2016-05-27 14:05:22 --> Helper loaded: form_helper
INFO - 2016-05-27 14:05:22 --> Database Driver Class Initialized
INFO - 2016-05-27 14:05:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:05:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:05:22 --> Email Class Initialized
INFO - 2016-05-27 14:05:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:05:22 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:05:22 --> Helper loaded: language_helper
INFO - 2016-05-27 14:05:22 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:05:22 --> Model Class Initialized
INFO - 2016-05-27 14:05:22 --> Helper loaded: date_helper
INFO - 2016-05-27 14:05:22 --> Controller Class Initialized
INFO - 2016-05-27 14:05:22 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:05:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:05:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:05:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:05:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:05:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:05:22 --> Model Class Initialized
INFO - 2016-05-27 14:05:22 --> Form Validation Class Initialized
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:05:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:05:22 --> Final output sent to browser
DEBUG - 2016-05-27 14:05:22 --> Total execution time: 0.0433
INFO - 2016-05-27 14:05:24 --> Config Class Initialized
INFO - 2016-05-27 14:05:24 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:05:24 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:05:24 --> Utf8 Class Initialized
INFO - 2016-05-27 14:05:24 --> URI Class Initialized
INFO - 2016-05-27 14:05:24 --> Router Class Initialized
INFO - 2016-05-27 14:05:24 --> Output Class Initialized
INFO - 2016-05-27 14:05:24 --> Security Class Initialized
DEBUG - 2016-05-27 14:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:05:24 --> CSRF cookie sent
INFO - 2016-05-27 14:05:24 --> CSRF token verified
INFO - 2016-05-27 14:05:24 --> Input Class Initialized
INFO - 2016-05-27 14:05:24 --> Language Class Initialized
INFO - 2016-05-27 14:05:24 --> Loader Class Initialized
INFO - 2016-05-27 14:05:24 --> Helper loaded: form_helper
INFO - 2016-05-27 14:05:24 --> Database Driver Class Initialized
INFO - 2016-05-27 14:05:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:05:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:05:25 --> Email Class Initialized
INFO - 2016-05-27 14:05:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:05:25 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:05:25 --> Helper loaded: language_helper
INFO - 2016-05-27 14:05:25 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:05:25 --> Model Class Initialized
INFO - 2016-05-27 14:05:25 --> Helper loaded: date_helper
INFO - 2016-05-27 14:05:25 --> Controller Class Initialized
INFO - 2016-05-27 14:05:25 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:05:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:05:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:05:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:05:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:05:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:05:25 --> Model Class Initialized
INFO - 2016-05-27 14:05:25 --> Form Validation Class Initialized
ERROR - 2016-05-27 14:05:25 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 349
INFO - 2016-05-27 14:05:25 --> Final output sent to browser
DEBUG - 2016-05-27 14:05:25 --> Total execution time: 0.0814
INFO - 2016-05-27 14:09:08 --> Config Class Initialized
INFO - 2016-05-27 14:09:08 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:09:08 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:09:08 --> Utf8 Class Initialized
INFO - 2016-05-27 14:09:08 --> URI Class Initialized
INFO - 2016-05-27 14:09:08 --> Router Class Initialized
INFO - 2016-05-27 14:09:08 --> Output Class Initialized
INFO - 2016-05-27 14:09:08 --> Security Class Initialized
DEBUG - 2016-05-27 14:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:09:08 --> CSRF cookie sent
INFO - 2016-05-27 14:09:08 --> Input Class Initialized
INFO - 2016-05-27 14:09:08 --> Language Class Initialized
INFO - 2016-05-27 14:09:08 --> Loader Class Initialized
INFO - 2016-05-27 14:09:08 --> Helper loaded: form_helper
INFO - 2016-05-27 14:09:08 --> Database Driver Class Initialized
INFO - 2016-05-27 14:09:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:09:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:09:08 --> Email Class Initialized
INFO - 2016-05-27 14:09:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:09:08 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:09:08 --> Helper loaded: language_helper
INFO - 2016-05-27 14:09:08 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:09:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:09:08 --> Model Class Initialized
INFO - 2016-05-27 14:09:08 --> Helper loaded: date_helper
INFO - 2016-05-27 14:09:08 --> Controller Class Initialized
INFO - 2016-05-27 14:09:08 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:09:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:09:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:09:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:09:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:09:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:09:08 --> Model Class Initialized
INFO - 2016-05-27 14:09:08 --> Form Validation Class Initialized
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:09:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:09:08 --> Final output sent to browser
DEBUG - 2016-05-27 14:09:08 --> Total execution time: 0.0818
INFO - 2016-05-27 14:09:13 --> Config Class Initialized
INFO - 2016-05-27 14:09:13 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:09:13 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:09:13 --> Utf8 Class Initialized
INFO - 2016-05-27 14:09:13 --> URI Class Initialized
INFO - 2016-05-27 14:09:13 --> Router Class Initialized
INFO - 2016-05-27 14:09:13 --> Output Class Initialized
INFO - 2016-05-27 14:09:13 --> Security Class Initialized
DEBUG - 2016-05-27 14:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:09:13 --> CSRF cookie sent
INFO - 2016-05-27 14:09:13 --> CSRF token verified
INFO - 2016-05-27 14:09:13 --> Input Class Initialized
INFO - 2016-05-27 14:09:13 --> Language Class Initialized
INFO - 2016-05-27 14:09:13 --> Loader Class Initialized
INFO - 2016-05-27 14:09:13 --> Helper loaded: form_helper
INFO - 2016-05-27 14:09:13 --> Database Driver Class Initialized
INFO - 2016-05-27 14:09:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:09:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:09:13 --> Email Class Initialized
INFO - 2016-05-27 14:09:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:09:13 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:09:13 --> Helper loaded: language_helper
INFO - 2016-05-27 14:09:13 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:09:13 --> Model Class Initialized
INFO - 2016-05-27 14:09:13 --> Helper loaded: date_helper
INFO - 2016-05-27 14:09:13 --> Controller Class Initialized
INFO - 2016-05-27 14:09:13 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:09:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:09:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:09:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:09:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:09:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:09:13 --> Model Class Initialized
INFO - 2016-05-27 14:09:13 --> Form Validation Class Initialized
INFO - 2016-05-27 14:09:13 --> Final output sent to browser
DEBUG - 2016-05-27 14:09:13 --> Total execution time: 0.0230
INFO - 2016-05-27 14:09:44 --> Config Class Initialized
INFO - 2016-05-27 14:09:44 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:09:44 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:09:44 --> Utf8 Class Initialized
INFO - 2016-05-27 14:09:44 --> URI Class Initialized
INFO - 2016-05-27 14:09:44 --> Router Class Initialized
INFO - 2016-05-27 14:09:44 --> Output Class Initialized
INFO - 2016-05-27 14:09:44 --> Security Class Initialized
DEBUG - 2016-05-27 14:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:09:44 --> CSRF cookie sent
INFO - 2016-05-27 14:09:44 --> Input Class Initialized
INFO - 2016-05-27 14:09:44 --> Language Class Initialized
INFO - 2016-05-27 14:09:44 --> Loader Class Initialized
INFO - 2016-05-27 14:09:44 --> Helper loaded: form_helper
INFO - 2016-05-27 14:09:44 --> Database Driver Class Initialized
INFO - 2016-05-27 14:09:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:09:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:09:44 --> Email Class Initialized
INFO - 2016-05-27 14:09:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:09:44 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:09:44 --> Helper loaded: language_helper
INFO - 2016-05-27 14:09:44 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:09:44 --> Model Class Initialized
INFO - 2016-05-27 14:09:44 --> Helper loaded: date_helper
INFO - 2016-05-27 14:09:44 --> Controller Class Initialized
INFO - 2016-05-27 14:09:44 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:09:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:09:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:09:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:09:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:09:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:09:44 --> Model Class Initialized
INFO - 2016-05-27 14:09:44 --> Form Validation Class Initialized
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:09:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:09:44 --> Final output sent to browser
DEBUG - 2016-05-27 14:09:44 --> Total execution time: 0.0806
INFO - 2016-05-27 14:09:48 --> Config Class Initialized
INFO - 2016-05-27 14:09:48 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:09:48 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:09:48 --> Utf8 Class Initialized
INFO - 2016-05-27 14:09:48 --> URI Class Initialized
INFO - 2016-05-27 14:09:48 --> Router Class Initialized
INFO - 2016-05-27 14:09:48 --> Output Class Initialized
INFO - 2016-05-27 14:09:48 --> Security Class Initialized
DEBUG - 2016-05-27 14:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:09:48 --> CSRF cookie sent
INFO - 2016-05-27 14:09:48 --> CSRF token verified
INFO - 2016-05-27 14:09:48 --> Input Class Initialized
INFO - 2016-05-27 14:09:48 --> Language Class Initialized
INFO - 2016-05-27 14:09:48 --> Loader Class Initialized
INFO - 2016-05-27 14:09:48 --> Helper loaded: form_helper
INFO - 2016-05-27 14:09:48 --> Database Driver Class Initialized
INFO - 2016-05-27 14:09:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:09:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:09:48 --> Email Class Initialized
INFO - 2016-05-27 14:09:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:09:48 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:09:48 --> Helper loaded: language_helper
INFO - 2016-05-27 14:09:48 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:09:48 --> Model Class Initialized
INFO - 2016-05-27 14:09:48 --> Helper loaded: date_helper
INFO - 2016-05-27 14:09:48 --> Controller Class Initialized
INFO - 2016-05-27 14:09:48 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:09:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:09:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:09:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:09:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:09:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:09:48 --> Model Class Initialized
INFO - 2016-05-27 14:09:48 --> Form Validation Class Initialized
INFO - 2016-05-27 14:09:48 --> Final output sent to browser
DEBUG - 2016-05-27 14:09:48 --> Total execution time: 0.0646
INFO - 2016-05-27 14:10:26 --> Config Class Initialized
INFO - 2016-05-27 14:10:26 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:10:26 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:10:26 --> Utf8 Class Initialized
INFO - 2016-05-27 14:10:26 --> URI Class Initialized
INFO - 2016-05-27 14:10:26 --> Router Class Initialized
INFO - 2016-05-27 14:10:26 --> Output Class Initialized
INFO - 2016-05-27 14:10:26 --> Security Class Initialized
DEBUG - 2016-05-27 14:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:10:26 --> CSRF cookie sent
INFO - 2016-05-27 14:10:26 --> Input Class Initialized
INFO - 2016-05-27 14:10:26 --> Language Class Initialized
INFO - 2016-05-27 14:10:26 --> Loader Class Initialized
INFO - 2016-05-27 14:10:26 --> Helper loaded: form_helper
INFO - 2016-05-27 14:10:26 --> Database Driver Class Initialized
INFO - 2016-05-27 14:10:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:10:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:10:26 --> Email Class Initialized
INFO - 2016-05-27 14:10:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:10:26 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:10:26 --> Helper loaded: language_helper
INFO - 2016-05-27 14:10:26 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:10:26 --> Model Class Initialized
INFO - 2016-05-27 14:10:26 --> Helper loaded: date_helper
INFO - 2016-05-27 14:10:26 --> Controller Class Initialized
INFO - 2016-05-27 14:10:26 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:10:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:10:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:10:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:10:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:10:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:10:26 --> Model Class Initialized
INFO - 2016-05-27 14:10:26 --> Form Validation Class Initialized
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:10:26 --> Final output sent to browser
DEBUG - 2016-05-27 14:10:26 --> Total execution time: 0.1039
INFO - 2016-05-27 14:10:28 --> Config Class Initialized
INFO - 2016-05-27 14:10:28 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:10:28 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:10:28 --> Utf8 Class Initialized
INFO - 2016-05-27 14:10:28 --> URI Class Initialized
INFO - 2016-05-27 14:10:28 --> Router Class Initialized
INFO - 2016-05-27 14:10:28 --> Output Class Initialized
INFO - 2016-05-27 14:10:28 --> Security Class Initialized
DEBUG - 2016-05-27 14:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:10:28 --> CSRF cookie sent
INFO - 2016-05-27 14:10:28 --> CSRF token verified
INFO - 2016-05-27 14:10:28 --> Input Class Initialized
INFO - 2016-05-27 14:10:28 --> Language Class Initialized
INFO - 2016-05-27 14:10:28 --> Loader Class Initialized
INFO - 2016-05-27 14:10:28 --> Helper loaded: form_helper
INFO - 2016-05-27 14:10:28 --> Database Driver Class Initialized
INFO - 2016-05-27 14:10:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:10:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:10:28 --> Email Class Initialized
INFO - 2016-05-27 14:10:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:10:28 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:10:28 --> Helper loaded: language_helper
INFO - 2016-05-27 14:10:28 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:10:28 --> Model Class Initialized
INFO - 2016-05-27 14:10:28 --> Helper loaded: date_helper
INFO - 2016-05-27 14:10:28 --> Controller Class Initialized
INFO - 2016-05-27 14:10:28 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:10:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:10:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:10:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:10:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:10:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:10:28 --> Model Class Initialized
INFO - 2016-05-27 14:10:28 --> Form Validation Class Initialized
INFO - 2016-05-27 14:10:28 --> Final output sent to browser
DEBUG - 2016-05-27 14:10:28 --> Total execution time: 0.0379
INFO - 2016-05-27 14:14:22 --> Config Class Initialized
INFO - 2016-05-27 14:14:22 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:14:22 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:14:22 --> Utf8 Class Initialized
INFO - 2016-05-27 14:14:22 --> URI Class Initialized
INFO - 2016-05-27 14:14:22 --> Router Class Initialized
INFO - 2016-05-27 14:14:22 --> Output Class Initialized
INFO - 2016-05-27 14:14:22 --> Security Class Initialized
DEBUG - 2016-05-27 14:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:14:22 --> CSRF cookie sent
INFO - 2016-05-27 14:14:22 --> Input Class Initialized
INFO - 2016-05-27 14:14:22 --> Language Class Initialized
INFO - 2016-05-27 14:14:22 --> Loader Class Initialized
INFO - 2016-05-27 14:14:22 --> Helper loaded: form_helper
INFO - 2016-05-27 14:14:22 --> Database Driver Class Initialized
INFO - 2016-05-27 14:14:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:14:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:14:22 --> Email Class Initialized
INFO - 2016-05-27 14:14:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:14:22 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:14:22 --> Helper loaded: language_helper
INFO - 2016-05-27 14:14:22 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:14:22 --> Model Class Initialized
INFO - 2016-05-27 14:14:22 --> Helper loaded: date_helper
INFO - 2016-05-27 14:14:22 --> Controller Class Initialized
INFO - 2016-05-27 14:14:22 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:14:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:14:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:14:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:14:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:14:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:14:22 --> Model Class Initialized
INFO - 2016-05-27 14:14:22 --> Form Validation Class Initialized
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:14:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:14:22 --> Final output sent to browser
DEBUG - 2016-05-27 14:14:22 --> Total execution time: 0.1203
INFO - 2016-05-27 14:14:25 --> Config Class Initialized
INFO - 2016-05-27 14:14:25 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:14:25 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:14:25 --> Utf8 Class Initialized
INFO - 2016-05-27 14:14:25 --> URI Class Initialized
INFO - 2016-05-27 14:14:25 --> Router Class Initialized
INFO - 2016-05-27 14:14:25 --> Output Class Initialized
INFO - 2016-05-27 14:14:25 --> Security Class Initialized
DEBUG - 2016-05-27 14:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:14:25 --> CSRF cookie sent
INFO - 2016-05-27 14:14:25 --> CSRF token verified
INFO - 2016-05-27 14:14:25 --> Input Class Initialized
INFO - 2016-05-27 14:14:25 --> Language Class Initialized
INFO - 2016-05-27 14:14:25 --> Loader Class Initialized
INFO - 2016-05-27 14:14:25 --> Helper loaded: form_helper
INFO - 2016-05-27 14:14:25 --> Database Driver Class Initialized
INFO - 2016-05-27 14:14:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:14:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:14:25 --> Email Class Initialized
INFO - 2016-05-27 14:14:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:14:25 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:14:25 --> Helper loaded: language_helper
INFO - 2016-05-27 14:14:25 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:14:25 --> Model Class Initialized
INFO - 2016-05-27 14:14:25 --> Helper loaded: date_helper
INFO - 2016-05-27 14:14:25 --> Controller Class Initialized
INFO - 2016-05-27 14:14:25 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:14:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:14:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:14:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:14:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:14:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:14:25 --> Model Class Initialized
INFO - 2016-05-27 14:14:25 --> Form Validation Class Initialized
INFO - 2016-05-27 14:14:25 --> Final output sent to browser
DEBUG - 2016-05-27 14:14:25 --> Total execution time: 0.0397
INFO - 2016-05-27 14:15:05 --> Config Class Initialized
INFO - 2016-05-27 14:15:05 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:15:05 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:15:05 --> Utf8 Class Initialized
INFO - 2016-05-27 14:15:05 --> URI Class Initialized
INFO - 2016-05-27 14:15:05 --> Router Class Initialized
INFO - 2016-05-27 14:15:05 --> Output Class Initialized
INFO - 2016-05-27 14:15:05 --> Security Class Initialized
DEBUG - 2016-05-27 14:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:15:05 --> CSRF cookie sent
INFO - 2016-05-27 14:15:05 --> Input Class Initialized
INFO - 2016-05-27 14:15:05 --> Language Class Initialized
INFO - 2016-05-27 14:15:05 --> Loader Class Initialized
INFO - 2016-05-27 14:15:05 --> Helper loaded: form_helper
INFO - 2016-05-27 14:15:05 --> Database Driver Class Initialized
INFO - 2016-05-27 14:15:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:15:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:15:05 --> Email Class Initialized
INFO - 2016-05-27 14:15:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:15:05 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:15:05 --> Helper loaded: language_helper
INFO - 2016-05-27 14:15:05 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:15:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:15:05 --> Model Class Initialized
INFO - 2016-05-27 14:15:05 --> Helper loaded: date_helper
INFO - 2016-05-27 14:15:05 --> Controller Class Initialized
INFO - 2016-05-27 14:15:05 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:15:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:15:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:15:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:15:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:15:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:15:05 --> Model Class Initialized
INFO - 2016-05-27 14:15:05 --> Form Validation Class Initialized
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:15:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:15:05 --> Final output sent to browser
DEBUG - 2016-05-27 14:15:05 --> Total execution time: 0.1018
INFO - 2016-05-27 14:15:07 --> Config Class Initialized
INFO - 2016-05-27 14:15:07 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:15:07 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:15:07 --> Utf8 Class Initialized
INFO - 2016-05-27 14:15:07 --> URI Class Initialized
INFO - 2016-05-27 14:15:07 --> Router Class Initialized
INFO - 2016-05-27 14:15:07 --> Output Class Initialized
INFO - 2016-05-27 14:15:07 --> Security Class Initialized
DEBUG - 2016-05-27 14:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:15:07 --> CSRF cookie sent
INFO - 2016-05-27 14:15:07 --> CSRF token verified
INFO - 2016-05-27 14:15:07 --> Input Class Initialized
INFO - 2016-05-27 14:15:07 --> Language Class Initialized
INFO - 2016-05-27 14:15:07 --> Loader Class Initialized
INFO - 2016-05-27 14:15:07 --> Helper loaded: form_helper
INFO - 2016-05-27 14:15:07 --> Database Driver Class Initialized
INFO - 2016-05-27 14:15:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:15:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:15:07 --> Email Class Initialized
INFO - 2016-05-27 14:15:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:15:07 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:15:07 --> Helper loaded: language_helper
INFO - 2016-05-27 14:15:07 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:15:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:15:07 --> Model Class Initialized
INFO - 2016-05-27 14:15:07 --> Helper loaded: date_helper
INFO - 2016-05-27 14:15:07 --> Controller Class Initialized
INFO - 2016-05-27 14:15:07 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:15:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:15:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:15:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:15:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:15:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:15:07 --> Model Class Initialized
INFO - 2016-05-27 14:15:07 --> Form Validation Class Initialized
INFO - 2016-05-27 14:15:07 --> Final output sent to browser
DEBUG - 2016-05-27 14:15:07 --> Total execution time: 0.0157
INFO - 2016-05-27 14:16:07 --> Config Class Initialized
INFO - 2016-05-27 14:16:07 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:16:07 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:16:07 --> Utf8 Class Initialized
INFO - 2016-05-27 14:16:07 --> URI Class Initialized
INFO - 2016-05-27 14:16:07 --> Router Class Initialized
INFO - 2016-05-27 14:16:07 --> Output Class Initialized
INFO - 2016-05-27 14:16:07 --> Security Class Initialized
DEBUG - 2016-05-27 14:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:16:07 --> CSRF cookie sent
INFO - 2016-05-27 14:16:07 --> Input Class Initialized
INFO - 2016-05-27 14:16:07 --> Language Class Initialized
INFO - 2016-05-27 14:16:07 --> Loader Class Initialized
INFO - 2016-05-27 14:16:07 --> Helper loaded: form_helper
INFO - 2016-05-27 14:16:07 --> Database Driver Class Initialized
INFO - 2016-05-27 14:16:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:16:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:16:07 --> Email Class Initialized
INFO - 2016-05-27 14:16:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:16:07 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:16:07 --> Helper loaded: language_helper
INFO - 2016-05-27 14:16:07 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:16:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:16:07 --> Model Class Initialized
INFO - 2016-05-27 14:16:07 --> Helper loaded: date_helper
INFO - 2016-05-27 14:16:07 --> Controller Class Initialized
INFO - 2016-05-27 14:16:07 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:16:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:16:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:16:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:16:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:16:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:16:07 --> Model Class Initialized
INFO - 2016-05-27 14:16:07 --> Form Validation Class Initialized
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:16:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:16:07 --> Final output sent to browser
DEBUG - 2016-05-27 14:16:07 --> Total execution time: 0.0766
INFO - 2016-05-27 14:16:09 --> Config Class Initialized
INFO - 2016-05-27 14:16:09 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:16:09 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:16:09 --> Utf8 Class Initialized
INFO - 2016-05-27 14:16:09 --> URI Class Initialized
INFO - 2016-05-27 14:16:09 --> Router Class Initialized
INFO - 2016-05-27 14:16:09 --> Output Class Initialized
INFO - 2016-05-27 14:16:09 --> Security Class Initialized
DEBUG - 2016-05-27 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:16:09 --> CSRF cookie sent
INFO - 2016-05-27 14:16:09 --> CSRF token verified
INFO - 2016-05-27 14:16:09 --> Input Class Initialized
INFO - 2016-05-27 14:16:09 --> Language Class Initialized
INFO - 2016-05-27 14:16:09 --> Loader Class Initialized
INFO - 2016-05-27 14:16:09 --> Helper loaded: form_helper
INFO - 2016-05-27 14:16:09 --> Database Driver Class Initialized
INFO - 2016-05-27 14:16:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:16:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:16:09 --> Email Class Initialized
INFO - 2016-05-27 14:16:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:16:09 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:16:09 --> Helper loaded: language_helper
INFO - 2016-05-27 14:16:09 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:16:09 --> Model Class Initialized
INFO - 2016-05-27 14:16:09 --> Helper loaded: date_helper
INFO - 2016-05-27 14:16:09 --> Controller Class Initialized
INFO - 2016-05-27 14:16:09 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:16:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:16:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:16:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:16:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:16:09 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:16:09 --> Model Class Initialized
INFO - 2016-05-27 14:16:09 --> Form Validation Class Initialized
INFO - 2016-05-27 14:16:09 --> Final output sent to browser
DEBUG - 2016-05-27 14:16:09 --> Total execution time: 0.0532
INFO - 2016-05-27 14:17:42 --> Config Class Initialized
INFO - 2016-05-27 14:17:42 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:17:42 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:17:42 --> Utf8 Class Initialized
INFO - 2016-05-27 14:17:42 --> URI Class Initialized
INFO - 2016-05-27 14:17:42 --> Router Class Initialized
INFO - 2016-05-27 14:17:42 --> Output Class Initialized
INFO - 2016-05-27 14:17:42 --> Security Class Initialized
DEBUG - 2016-05-27 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:17:42 --> CSRF cookie sent
INFO - 2016-05-27 14:17:42 --> Input Class Initialized
INFO - 2016-05-27 14:17:42 --> Language Class Initialized
INFO - 2016-05-27 14:17:42 --> Loader Class Initialized
INFO - 2016-05-27 14:17:42 --> Helper loaded: form_helper
INFO - 2016-05-27 14:17:42 --> Database Driver Class Initialized
INFO - 2016-05-27 14:17:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:17:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:17:42 --> Email Class Initialized
INFO - 2016-05-27 14:17:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:17:42 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:17:42 --> Helper loaded: language_helper
INFO - 2016-05-27 14:17:42 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:17:42 --> Model Class Initialized
INFO - 2016-05-27 14:17:42 --> Helper loaded: date_helper
INFO - 2016-05-27 14:17:42 --> Controller Class Initialized
INFO - 2016-05-27 14:17:42 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:17:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:17:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:17:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:17:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:17:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:17:42 --> Model Class Initialized
INFO - 2016-05-27 14:17:42 --> Form Validation Class Initialized
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:17:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:17:42 --> Final output sent to browser
DEBUG - 2016-05-27 14:17:42 --> Total execution time: 0.0958
INFO - 2016-05-27 14:17:45 --> Config Class Initialized
INFO - 2016-05-27 14:17:45 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:17:45 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:17:45 --> Utf8 Class Initialized
INFO - 2016-05-27 14:17:45 --> URI Class Initialized
INFO - 2016-05-27 14:17:45 --> Router Class Initialized
INFO - 2016-05-27 14:17:45 --> Output Class Initialized
INFO - 2016-05-27 14:17:45 --> Security Class Initialized
DEBUG - 2016-05-27 14:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:17:45 --> CSRF cookie sent
INFO - 2016-05-27 14:17:45 --> CSRF token verified
INFO - 2016-05-27 14:17:45 --> Input Class Initialized
INFO - 2016-05-27 14:17:45 --> Language Class Initialized
INFO - 2016-05-27 14:17:45 --> Loader Class Initialized
INFO - 2016-05-27 14:17:45 --> Helper loaded: form_helper
INFO - 2016-05-27 14:17:45 --> Database Driver Class Initialized
INFO - 2016-05-27 14:17:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:17:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:17:45 --> Email Class Initialized
INFO - 2016-05-27 14:17:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:17:45 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:17:45 --> Helper loaded: language_helper
INFO - 2016-05-27 14:17:45 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:17:45 --> Model Class Initialized
INFO - 2016-05-27 14:17:45 --> Helper loaded: date_helper
INFO - 2016-05-27 14:17:45 --> Controller Class Initialized
INFO - 2016-05-27 14:17:45 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:17:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:17:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:17:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:17:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:17:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:17:45 --> Model Class Initialized
INFO - 2016-05-27 14:17:45 --> Form Validation Class Initialized
INFO - 2016-05-27 14:17:45 --> Final output sent to browser
DEBUG - 2016-05-27 14:17:45 --> Total execution time: 0.0191
INFO - 2016-05-27 14:18:00 --> Config Class Initialized
INFO - 2016-05-27 14:18:00 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:18:00 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:18:00 --> Utf8 Class Initialized
INFO - 2016-05-27 14:18:00 --> URI Class Initialized
INFO - 2016-05-27 14:18:00 --> Router Class Initialized
INFO - 2016-05-27 14:18:00 --> Output Class Initialized
INFO - 2016-05-27 14:18:00 --> Security Class Initialized
DEBUG - 2016-05-27 14:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:18:00 --> CSRF cookie sent
INFO - 2016-05-27 14:18:00 --> Input Class Initialized
INFO - 2016-05-27 14:18:00 --> Language Class Initialized
INFO - 2016-05-27 14:18:00 --> Loader Class Initialized
INFO - 2016-05-27 14:18:00 --> Helper loaded: form_helper
INFO - 2016-05-27 14:18:00 --> Database Driver Class Initialized
INFO - 2016-05-27 14:18:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:18:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:18:00 --> Email Class Initialized
INFO - 2016-05-27 14:18:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:18:00 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:18:00 --> Helper loaded: language_helper
INFO - 2016-05-27 14:18:00 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:18:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:18:00 --> Model Class Initialized
INFO - 2016-05-27 14:18:00 --> Helper loaded: date_helper
INFO - 2016-05-27 14:18:00 --> Controller Class Initialized
INFO - 2016-05-27 14:18:00 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:18:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:18:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:18:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:18:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:18:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:18:00 --> Model Class Initialized
INFO - 2016-05-27 14:18:00 --> Form Validation Class Initialized
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:18:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:18:00 --> Final output sent to browser
DEBUG - 2016-05-27 14:18:00 --> Total execution time: 0.0730
INFO - 2016-05-27 14:18:03 --> Config Class Initialized
INFO - 2016-05-27 14:18:03 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:18:03 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:18:03 --> Utf8 Class Initialized
INFO - 2016-05-27 14:18:03 --> URI Class Initialized
INFO - 2016-05-27 14:18:03 --> Router Class Initialized
INFO - 2016-05-27 14:18:03 --> Output Class Initialized
INFO - 2016-05-27 14:18:03 --> Security Class Initialized
DEBUG - 2016-05-27 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:18:03 --> CSRF cookie sent
INFO - 2016-05-27 14:18:03 --> CSRF token verified
INFO - 2016-05-27 14:18:03 --> Input Class Initialized
INFO - 2016-05-27 14:18:03 --> Language Class Initialized
INFO - 2016-05-27 14:18:03 --> Loader Class Initialized
INFO - 2016-05-27 14:18:03 --> Helper loaded: form_helper
INFO - 2016-05-27 14:18:03 --> Database Driver Class Initialized
INFO - 2016-05-27 14:18:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:18:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:18:03 --> Email Class Initialized
INFO - 2016-05-27 14:18:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:18:03 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:18:03 --> Helper loaded: language_helper
INFO - 2016-05-27 14:18:04 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:18:04 --> Model Class Initialized
INFO - 2016-05-27 14:18:04 --> Helper loaded: date_helper
INFO - 2016-05-27 14:18:04 --> Controller Class Initialized
INFO - 2016-05-27 14:18:04 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:18:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:18:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:18:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:18:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:18:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:18:04 --> Model Class Initialized
INFO - 2016-05-27 14:18:04 --> Form Validation Class Initialized
INFO - 2016-05-27 14:18:04 --> Final output sent to browser
DEBUG - 2016-05-27 14:18:04 --> Total execution time: 0.0651
INFO - 2016-05-27 14:18:28 --> Config Class Initialized
INFO - 2016-05-27 14:18:28 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:18:28 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:18:28 --> Utf8 Class Initialized
INFO - 2016-05-27 14:18:28 --> URI Class Initialized
INFO - 2016-05-27 14:18:28 --> Router Class Initialized
INFO - 2016-05-27 14:18:28 --> Output Class Initialized
INFO - 2016-05-27 14:18:28 --> Security Class Initialized
DEBUG - 2016-05-27 14:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:18:28 --> CSRF cookie sent
INFO - 2016-05-27 14:18:28 --> Input Class Initialized
INFO - 2016-05-27 14:18:28 --> Language Class Initialized
INFO - 2016-05-27 14:18:28 --> Loader Class Initialized
INFO - 2016-05-27 14:18:28 --> Helper loaded: form_helper
INFO - 2016-05-27 14:18:28 --> Database Driver Class Initialized
INFO - 2016-05-27 14:18:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:18:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:18:28 --> Email Class Initialized
INFO - 2016-05-27 14:18:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:18:28 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:18:28 --> Helper loaded: language_helper
INFO - 2016-05-27 14:18:28 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:18:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:18:28 --> Model Class Initialized
INFO - 2016-05-27 14:18:28 --> Helper loaded: date_helper
INFO - 2016-05-27 14:18:28 --> Controller Class Initialized
INFO - 2016-05-27 14:18:28 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:18:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:18:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:18:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:18:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:18:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:18:28 --> Model Class Initialized
INFO - 2016-05-27 14:18:28 --> Form Validation Class Initialized
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:18:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:18:28 --> Final output sent to browser
DEBUG - 2016-05-27 14:18:28 --> Total execution time: 0.1148
INFO - 2016-05-27 14:18:30 --> Config Class Initialized
INFO - 2016-05-27 14:18:30 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:18:30 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:18:30 --> Utf8 Class Initialized
INFO - 2016-05-27 14:18:30 --> URI Class Initialized
INFO - 2016-05-27 14:18:30 --> Router Class Initialized
INFO - 2016-05-27 14:18:30 --> Output Class Initialized
INFO - 2016-05-27 14:18:30 --> Security Class Initialized
DEBUG - 2016-05-27 14:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:18:30 --> CSRF cookie sent
INFO - 2016-05-27 14:18:30 --> CSRF token verified
INFO - 2016-05-27 14:18:30 --> Input Class Initialized
INFO - 2016-05-27 14:18:30 --> Language Class Initialized
INFO - 2016-05-27 14:18:30 --> Loader Class Initialized
INFO - 2016-05-27 14:18:30 --> Helper loaded: form_helper
INFO - 2016-05-27 14:18:30 --> Database Driver Class Initialized
INFO - 2016-05-27 14:18:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:18:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:18:31 --> Email Class Initialized
INFO - 2016-05-27 14:18:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:18:31 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:18:31 --> Helper loaded: language_helper
INFO - 2016-05-27 14:18:31 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:18:31 --> Model Class Initialized
INFO - 2016-05-27 14:18:31 --> Helper loaded: date_helper
INFO - 2016-05-27 14:18:31 --> Controller Class Initialized
INFO - 2016-05-27 14:18:31 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:18:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:18:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:18:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:18:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:18:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:18:31 --> Model Class Initialized
INFO - 2016-05-27 14:18:31 --> Form Validation Class Initialized
ERROR - 2016-05-27 14:18:31 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 349
INFO - 2016-05-27 14:18:31 --> Final output sent to browser
DEBUG - 2016-05-27 14:18:31 --> Total execution time: 0.0519
INFO - 2016-05-27 14:19:02 --> Config Class Initialized
INFO - 2016-05-27 14:19:02 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:19:02 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:19:02 --> Utf8 Class Initialized
INFO - 2016-05-27 14:19:02 --> URI Class Initialized
INFO - 2016-05-27 14:19:02 --> Router Class Initialized
INFO - 2016-05-27 14:19:02 --> Output Class Initialized
INFO - 2016-05-27 14:19:02 --> Security Class Initialized
DEBUG - 2016-05-27 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:19:02 --> CSRF cookie sent
INFO - 2016-05-27 14:19:02 --> Input Class Initialized
INFO - 2016-05-27 14:19:02 --> Language Class Initialized
INFO - 2016-05-27 14:19:02 --> Loader Class Initialized
INFO - 2016-05-27 14:19:02 --> Helper loaded: form_helper
INFO - 2016-05-27 14:19:02 --> Database Driver Class Initialized
INFO - 2016-05-27 14:19:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:19:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:19:02 --> Email Class Initialized
INFO - 2016-05-27 14:19:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:19:02 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:19:02 --> Helper loaded: language_helper
INFO - 2016-05-27 14:19:02 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:19:02 --> Model Class Initialized
INFO - 2016-05-27 14:19:02 --> Helper loaded: date_helper
INFO - 2016-05-27 14:19:02 --> Controller Class Initialized
INFO - 2016-05-27 14:19:02 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:19:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:19:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:19:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:19:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:19:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:19:02 --> Model Class Initialized
INFO - 2016-05-27 14:19:02 --> Form Validation Class Initialized
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:19:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:19:02 --> Final output sent to browser
DEBUG - 2016-05-27 14:19:02 --> Total execution time: 0.0840
INFO - 2016-05-27 14:19:05 --> Config Class Initialized
INFO - 2016-05-27 14:19:05 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:19:05 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:19:05 --> Utf8 Class Initialized
INFO - 2016-05-27 14:19:05 --> URI Class Initialized
INFO - 2016-05-27 14:19:05 --> Router Class Initialized
INFO - 2016-05-27 14:19:05 --> Output Class Initialized
INFO - 2016-05-27 14:19:05 --> Security Class Initialized
DEBUG - 2016-05-27 14:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:19:05 --> CSRF cookie sent
INFO - 2016-05-27 14:19:05 --> CSRF token verified
INFO - 2016-05-27 14:19:05 --> Input Class Initialized
INFO - 2016-05-27 14:19:05 --> Language Class Initialized
INFO - 2016-05-27 14:19:05 --> Loader Class Initialized
INFO - 2016-05-27 14:19:05 --> Helper loaded: form_helper
INFO - 2016-05-27 14:19:05 --> Database Driver Class Initialized
INFO - 2016-05-27 14:19:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:19:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:19:05 --> Email Class Initialized
INFO - 2016-05-27 14:19:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:19:05 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:19:05 --> Helper loaded: language_helper
INFO - 2016-05-27 14:19:05 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:19:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:19:05 --> Model Class Initialized
INFO - 2016-05-27 14:19:05 --> Helper loaded: date_helper
INFO - 2016-05-27 14:19:05 --> Controller Class Initialized
INFO - 2016-05-27 14:19:05 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:19:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:19:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:19:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:19:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:19:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:19:05 --> Model Class Initialized
INFO - 2016-05-27 14:19:05 --> Form Validation Class Initialized
INFO - 2016-05-27 14:19:05 --> Final output sent to browser
DEBUG - 2016-05-27 14:19:05 --> Total execution time: 0.1016
INFO - 2016-05-27 14:21:18 --> Config Class Initialized
INFO - 2016-05-27 14:21:18 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:21:18 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:21:18 --> Utf8 Class Initialized
INFO - 2016-05-27 14:21:18 --> URI Class Initialized
INFO - 2016-05-27 14:21:18 --> Router Class Initialized
INFO - 2016-05-27 14:21:18 --> Output Class Initialized
INFO - 2016-05-27 14:21:18 --> Security Class Initialized
DEBUG - 2016-05-27 14:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:21:18 --> CSRF cookie sent
INFO - 2016-05-27 14:21:18 --> Input Class Initialized
INFO - 2016-05-27 14:21:18 --> Language Class Initialized
ERROR - 2016-05-27 14:21:18 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/demis/www/platformadiabet/application/controllers/Diabet.php 349
INFO - 2016-05-27 14:21:32 --> Config Class Initialized
INFO - 2016-05-27 14:21:32 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:21:32 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:21:32 --> Utf8 Class Initialized
INFO - 2016-05-27 14:21:32 --> URI Class Initialized
INFO - 2016-05-27 14:21:32 --> Router Class Initialized
INFO - 2016-05-27 14:21:32 --> Output Class Initialized
INFO - 2016-05-27 14:21:32 --> Security Class Initialized
DEBUG - 2016-05-27 14:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:21:32 --> CSRF cookie sent
INFO - 2016-05-27 14:21:32 --> Input Class Initialized
INFO - 2016-05-27 14:21:32 --> Language Class Initialized
INFO - 2016-05-27 14:21:32 --> Loader Class Initialized
INFO - 2016-05-27 14:21:32 --> Helper loaded: form_helper
INFO - 2016-05-27 14:21:32 --> Database Driver Class Initialized
INFO - 2016-05-27 14:21:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:21:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:21:32 --> Email Class Initialized
INFO - 2016-05-27 14:21:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:21:32 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:21:32 --> Helper loaded: language_helper
INFO - 2016-05-27 14:21:32 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:21:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:21:32 --> Model Class Initialized
INFO - 2016-05-27 14:21:32 --> Helper loaded: date_helper
INFO - 2016-05-27 14:21:32 --> Controller Class Initialized
INFO - 2016-05-27 14:21:32 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:21:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:21:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:21:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:21:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:21:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:21:32 --> Model Class Initialized
INFO - 2016-05-27 14:21:32 --> Form Validation Class Initialized
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:21:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:21:32 --> Final output sent to browser
DEBUG - 2016-05-27 14:21:32 --> Total execution time: 0.0579
INFO - 2016-05-27 14:21:36 --> Config Class Initialized
INFO - 2016-05-27 14:21:36 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:21:36 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:21:36 --> Utf8 Class Initialized
INFO - 2016-05-27 14:21:36 --> URI Class Initialized
INFO - 2016-05-27 14:21:36 --> Router Class Initialized
INFO - 2016-05-27 14:21:36 --> Output Class Initialized
INFO - 2016-05-27 14:21:36 --> Security Class Initialized
DEBUG - 2016-05-27 14:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:21:36 --> CSRF cookie sent
INFO - 2016-05-27 14:21:36 --> CSRF token verified
INFO - 2016-05-27 14:21:36 --> Input Class Initialized
INFO - 2016-05-27 14:21:36 --> Language Class Initialized
INFO - 2016-05-27 14:21:36 --> Loader Class Initialized
INFO - 2016-05-27 14:21:36 --> Helper loaded: form_helper
INFO - 2016-05-27 14:21:36 --> Database Driver Class Initialized
INFO - 2016-05-27 14:21:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:21:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:21:36 --> Email Class Initialized
INFO - 2016-05-27 14:21:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:21:36 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:21:36 --> Helper loaded: language_helper
INFO - 2016-05-27 14:21:36 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:21:36 --> Model Class Initialized
INFO - 2016-05-27 14:21:36 --> Helper loaded: date_helper
INFO - 2016-05-27 14:21:36 --> Controller Class Initialized
INFO - 2016-05-27 14:21:36 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:21:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:21:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:21:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:21:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:21:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:21:36 --> Model Class Initialized
INFO - 2016-05-27 14:21:36 --> Form Validation Class Initialized
INFO - 2016-05-27 14:21:36 --> Final output sent to browser
DEBUG - 2016-05-27 14:21:36 --> Total execution time: 0.0606
INFO - 2016-05-27 14:22:26 --> Config Class Initialized
INFO - 2016-05-27 14:22:26 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:22:26 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:22:26 --> Utf8 Class Initialized
INFO - 2016-05-27 14:22:26 --> URI Class Initialized
INFO - 2016-05-27 14:22:26 --> Router Class Initialized
INFO - 2016-05-27 14:22:26 --> Output Class Initialized
INFO - 2016-05-27 14:22:26 --> Security Class Initialized
DEBUG - 2016-05-27 14:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:22:26 --> CSRF cookie sent
INFO - 2016-05-27 14:22:26 --> Input Class Initialized
INFO - 2016-05-27 14:22:26 --> Language Class Initialized
INFO - 2016-05-27 14:22:26 --> Loader Class Initialized
INFO - 2016-05-27 14:22:26 --> Helper loaded: form_helper
INFO - 2016-05-27 14:22:26 --> Database Driver Class Initialized
INFO - 2016-05-27 14:22:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:22:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:22:26 --> Email Class Initialized
INFO - 2016-05-27 14:22:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:22:26 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:22:26 --> Helper loaded: language_helper
INFO - 2016-05-27 14:22:26 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:22:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:22:26 --> Model Class Initialized
INFO - 2016-05-27 14:22:26 --> Helper loaded: date_helper
INFO - 2016-05-27 14:22:26 --> Controller Class Initialized
INFO - 2016-05-27 14:22:26 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:22:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:22:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:22:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:22:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:22:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:22:26 --> Model Class Initialized
INFO - 2016-05-27 14:22:26 --> Form Validation Class Initialized
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:22:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:22:26 --> Final output sent to browser
DEBUG - 2016-05-27 14:22:26 --> Total execution time: 0.1259
INFO - 2016-05-27 14:22:28 --> Config Class Initialized
INFO - 2016-05-27 14:22:28 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:22:28 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:22:28 --> Utf8 Class Initialized
INFO - 2016-05-27 14:22:28 --> URI Class Initialized
INFO - 2016-05-27 14:22:28 --> Router Class Initialized
INFO - 2016-05-27 14:22:28 --> Output Class Initialized
INFO - 2016-05-27 14:22:28 --> Security Class Initialized
DEBUG - 2016-05-27 14:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:22:28 --> CSRF cookie sent
INFO - 2016-05-27 14:22:28 --> CSRF token verified
INFO - 2016-05-27 14:22:28 --> Input Class Initialized
INFO - 2016-05-27 14:22:28 --> Language Class Initialized
INFO - 2016-05-27 14:22:28 --> Loader Class Initialized
INFO - 2016-05-27 14:22:28 --> Helper loaded: form_helper
INFO - 2016-05-27 14:22:28 --> Database Driver Class Initialized
INFO - 2016-05-27 14:22:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:22:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:22:28 --> Email Class Initialized
INFO - 2016-05-27 14:22:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:22:28 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:22:28 --> Helper loaded: language_helper
INFO - 2016-05-27 14:22:28 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:22:28 --> Model Class Initialized
INFO - 2016-05-27 14:22:28 --> Helper loaded: date_helper
INFO - 2016-05-27 14:22:28 --> Controller Class Initialized
INFO - 2016-05-27 14:22:28 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:22:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:22:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:22:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:22:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:22:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:22:28 --> Model Class Initialized
INFO - 2016-05-27 14:22:28 --> Form Validation Class Initialized
INFO - 2016-05-27 14:22:28 --> Final output sent to browser
DEBUG - 2016-05-27 14:22:28 --> Total execution time: 0.0380
INFO - 2016-05-27 14:23:26 --> Config Class Initialized
INFO - 2016-05-27 14:23:26 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:23:26 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:23:26 --> Utf8 Class Initialized
INFO - 2016-05-27 14:23:26 --> URI Class Initialized
INFO - 2016-05-27 14:23:26 --> Router Class Initialized
INFO - 2016-05-27 14:23:26 --> Output Class Initialized
INFO - 2016-05-27 14:23:26 --> Security Class Initialized
DEBUG - 2016-05-27 14:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:23:26 --> CSRF cookie sent
INFO - 2016-05-27 14:23:26 --> Input Class Initialized
INFO - 2016-05-27 14:23:26 --> Language Class Initialized
INFO - 2016-05-27 14:23:26 --> Loader Class Initialized
INFO - 2016-05-27 14:23:26 --> Helper loaded: form_helper
INFO - 2016-05-27 14:23:26 --> Database Driver Class Initialized
INFO - 2016-05-27 14:23:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:23:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:23:26 --> Email Class Initialized
INFO - 2016-05-27 14:23:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:23:26 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:23:26 --> Helper loaded: language_helper
INFO - 2016-05-27 14:23:26 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:23:26 --> Model Class Initialized
INFO - 2016-05-27 14:23:26 --> Helper loaded: date_helper
INFO - 2016-05-27 14:23:26 --> Controller Class Initialized
INFO - 2016-05-27 14:23:26 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:23:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:23:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:23:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:23:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:23:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:23:26 --> Model Class Initialized
INFO - 2016-05-27 14:23:26 --> Form Validation Class Initialized
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:23:26 --> Final output sent to browser
DEBUG - 2016-05-27 14:23:26 --> Total execution time: 0.1031
INFO - 2016-05-27 14:23:29 --> Config Class Initialized
INFO - 2016-05-27 14:23:29 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:23:29 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:23:29 --> Utf8 Class Initialized
INFO - 2016-05-27 14:23:29 --> URI Class Initialized
INFO - 2016-05-27 14:23:29 --> Router Class Initialized
INFO - 2016-05-27 14:23:29 --> Output Class Initialized
INFO - 2016-05-27 14:23:29 --> Security Class Initialized
DEBUG - 2016-05-27 14:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:23:29 --> CSRF cookie sent
INFO - 2016-05-27 14:23:29 --> CSRF token verified
INFO - 2016-05-27 14:23:29 --> Input Class Initialized
INFO - 2016-05-27 14:23:29 --> Language Class Initialized
INFO - 2016-05-27 14:23:29 --> Loader Class Initialized
INFO - 2016-05-27 14:23:29 --> Helper loaded: form_helper
INFO - 2016-05-27 14:23:29 --> Database Driver Class Initialized
INFO - 2016-05-27 14:23:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:23:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:23:29 --> Email Class Initialized
INFO - 2016-05-27 14:23:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:23:29 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:23:29 --> Helper loaded: language_helper
INFO - 2016-05-27 14:23:29 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:23:29 --> Model Class Initialized
INFO - 2016-05-27 14:23:29 --> Helper loaded: date_helper
INFO - 2016-05-27 14:23:29 --> Controller Class Initialized
INFO - 2016-05-27 14:23:29 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:23:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:23:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:23:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:23:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:23:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:23:29 --> Model Class Initialized
INFO - 2016-05-27 14:23:29 --> Form Validation Class Initialized
INFO - 2016-05-27 14:23:29 --> Final output sent to browser
DEBUG - 2016-05-27 14:23:29 --> Total execution time: 0.0156
INFO - 2016-05-27 14:26:16 --> Config Class Initialized
INFO - 2016-05-27 14:26:16 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:26:16 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:26:16 --> Utf8 Class Initialized
INFO - 2016-05-27 14:26:16 --> URI Class Initialized
INFO - 2016-05-27 14:26:16 --> Router Class Initialized
INFO - 2016-05-27 14:26:16 --> Output Class Initialized
INFO - 2016-05-27 14:26:16 --> Security Class Initialized
DEBUG - 2016-05-27 14:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:26:16 --> CSRF cookie sent
INFO - 2016-05-27 14:26:16 --> Input Class Initialized
INFO - 2016-05-27 14:26:16 --> Language Class Initialized
INFO - 2016-05-27 14:26:16 --> Loader Class Initialized
INFO - 2016-05-27 14:26:16 --> Helper loaded: form_helper
INFO - 2016-05-27 14:26:16 --> Database Driver Class Initialized
INFO - 2016-05-27 14:26:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:26:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:26:16 --> Email Class Initialized
INFO - 2016-05-27 14:26:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:26:16 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:26:16 --> Helper loaded: language_helper
INFO - 2016-05-27 14:26:16 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:26:16 --> Model Class Initialized
INFO - 2016-05-27 14:26:16 --> Helper loaded: date_helper
INFO - 2016-05-27 14:26:16 --> Controller Class Initialized
INFO - 2016-05-27 14:26:16 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:26:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:26:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:26:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:26:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:26:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:26:16 --> Model Class Initialized
INFO - 2016-05-27 14:26:16 --> Form Validation Class Initialized
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:26:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:26:16 --> Final output sent to browser
DEBUG - 2016-05-27 14:26:16 --> Total execution time: 0.0800
INFO - 2016-05-27 14:26:19 --> Config Class Initialized
INFO - 2016-05-27 14:26:19 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:26:19 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:26:19 --> Utf8 Class Initialized
INFO - 2016-05-27 14:26:19 --> URI Class Initialized
INFO - 2016-05-27 14:26:19 --> Router Class Initialized
INFO - 2016-05-27 14:26:19 --> Output Class Initialized
INFO - 2016-05-27 14:26:19 --> Security Class Initialized
DEBUG - 2016-05-27 14:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:26:19 --> CSRF cookie sent
INFO - 2016-05-27 14:26:19 --> CSRF token verified
INFO - 2016-05-27 14:26:19 --> Input Class Initialized
INFO - 2016-05-27 14:26:19 --> Language Class Initialized
INFO - 2016-05-27 14:26:19 --> Loader Class Initialized
INFO - 2016-05-27 14:26:19 --> Helper loaded: form_helper
INFO - 2016-05-27 14:26:19 --> Database Driver Class Initialized
INFO - 2016-05-27 14:26:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:26:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:26:19 --> Email Class Initialized
INFO - 2016-05-27 14:26:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:26:19 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:26:19 --> Helper loaded: language_helper
INFO - 2016-05-27 14:26:19 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:26:19 --> Model Class Initialized
INFO - 2016-05-27 14:26:19 --> Helper loaded: date_helper
INFO - 2016-05-27 14:26:19 --> Controller Class Initialized
INFO - 2016-05-27 14:26:19 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:26:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:26:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:26:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:26:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:26:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:26:19 --> Model Class Initialized
INFO - 2016-05-27 14:26:19 --> Form Validation Class Initialized
INFO - 2016-05-27 14:26:19 --> Final output sent to browser
DEBUG - 2016-05-27 14:26:19 --> Total execution time: 0.1219
INFO - 2016-05-27 14:27:55 --> Config Class Initialized
INFO - 2016-05-27 14:27:55 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:27:55 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:27:55 --> Utf8 Class Initialized
INFO - 2016-05-27 14:27:55 --> URI Class Initialized
INFO - 2016-05-27 14:27:55 --> Router Class Initialized
INFO - 2016-05-27 14:27:55 --> Output Class Initialized
INFO - 2016-05-27 14:27:55 --> Security Class Initialized
DEBUG - 2016-05-27 14:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:27:55 --> CSRF cookie sent
INFO - 2016-05-27 14:27:55 --> Input Class Initialized
INFO - 2016-05-27 14:27:55 --> Language Class Initialized
INFO - 2016-05-27 14:27:55 --> Loader Class Initialized
INFO - 2016-05-27 14:27:55 --> Helper loaded: form_helper
INFO - 2016-05-27 14:27:55 --> Database Driver Class Initialized
INFO - 2016-05-27 14:27:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:27:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:27:55 --> Email Class Initialized
INFO - 2016-05-27 14:27:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:27:55 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:27:55 --> Helper loaded: language_helper
INFO - 2016-05-27 14:27:55 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:27:55 --> Model Class Initialized
INFO - 2016-05-27 14:27:55 --> Helper loaded: date_helper
INFO - 2016-05-27 14:27:55 --> Controller Class Initialized
INFO - 2016-05-27 14:27:55 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:27:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:27:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:27:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:27:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:27:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:27:55 --> Model Class Initialized
INFO - 2016-05-27 14:27:55 --> Form Validation Class Initialized
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:27:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:27:55 --> Final output sent to browser
DEBUG - 2016-05-27 14:27:55 --> Total execution time: 0.0696
INFO - 2016-05-27 14:27:57 --> Config Class Initialized
INFO - 2016-05-27 14:27:57 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:27:57 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:27:57 --> Utf8 Class Initialized
INFO - 2016-05-27 14:27:57 --> URI Class Initialized
INFO - 2016-05-27 14:27:57 --> Router Class Initialized
INFO - 2016-05-27 14:27:57 --> Output Class Initialized
INFO - 2016-05-27 14:27:57 --> Security Class Initialized
DEBUG - 2016-05-27 14:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:27:57 --> CSRF cookie sent
INFO - 2016-05-27 14:27:57 --> CSRF token verified
INFO - 2016-05-27 14:27:57 --> Input Class Initialized
INFO - 2016-05-27 14:27:57 --> Language Class Initialized
INFO - 2016-05-27 14:27:57 --> Loader Class Initialized
INFO - 2016-05-27 14:27:57 --> Helper loaded: form_helper
INFO - 2016-05-27 14:27:57 --> Database Driver Class Initialized
INFO - 2016-05-27 14:27:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:27:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:27:57 --> Email Class Initialized
INFO - 2016-05-27 14:27:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:27:57 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:27:57 --> Helper loaded: language_helper
INFO - 2016-05-27 14:27:57 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:27:57 --> Model Class Initialized
INFO - 2016-05-27 14:27:57 --> Helper loaded: date_helper
INFO - 2016-05-27 14:27:57 --> Controller Class Initialized
INFO - 2016-05-27 14:27:57 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:27:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:27:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:27:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:27:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:27:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:27:57 --> Model Class Initialized
INFO - 2016-05-27 14:27:57 --> Form Validation Class Initialized
INFO - 2016-05-27 14:27:57 --> Final output sent to browser
DEBUG - 2016-05-27 14:27:57 --> Total execution time: 0.0215
INFO - 2016-05-27 14:30:39 --> Config Class Initialized
INFO - 2016-05-27 14:30:39 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:30:39 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:30:39 --> Utf8 Class Initialized
INFO - 2016-05-27 14:30:39 --> URI Class Initialized
INFO - 2016-05-27 14:30:39 --> Router Class Initialized
INFO - 2016-05-27 14:30:39 --> Output Class Initialized
INFO - 2016-05-27 14:30:39 --> Security Class Initialized
DEBUG - 2016-05-27 14:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:30:39 --> CSRF cookie sent
INFO - 2016-05-27 14:30:39 --> Input Class Initialized
INFO - 2016-05-27 14:30:39 --> Language Class Initialized
INFO - 2016-05-27 14:30:39 --> Loader Class Initialized
INFO - 2016-05-27 14:30:39 --> Helper loaded: form_helper
INFO - 2016-05-27 14:30:39 --> Database Driver Class Initialized
INFO - 2016-05-27 14:30:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:30:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:30:39 --> Email Class Initialized
INFO - 2016-05-27 14:30:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:30:39 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:30:39 --> Helper loaded: language_helper
INFO - 2016-05-27 14:30:39 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:30:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:30:39 --> Model Class Initialized
INFO - 2016-05-27 14:30:39 --> Helper loaded: date_helper
INFO - 2016-05-27 14:30:39 --> Controller Class Initialized
INFO - 2016-05-27 14:30:39 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:30:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:30:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:30:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:30:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:30:39 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-27 14:30:39 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/demis/www/platformadiabet/application/models/Diabet_model.php 328
INFO - 2016-05-27 14:30:58 --> Config Class Initialized
INFO - 2016-05-27 14:30:58 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:30:58 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:30:58 --> Utf8 Class Initialized
INFO - 2016-05-27 14:30:58 --> URI Class Initialized
INFO - 2016-05-27 14:30:58 --> Router Class Initialized
INFO - 2016-05-27 14:30:58 --> Output Class Initialized
INFO - 2016-05-27 14:30:58 --> Security Class Initialized
DEBUG - 2016-05-27 14:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:30:58 --> CSRF cookie sent
INFO - 2016-05-27 14:30:58 --> Input Class Initialized
INFO - 2016-05-27 14:30:58 --> Language Class Initialized
INFO - 2016-05-27 14:30:58 --> Loader Class Initialized
INFO - 2016-05-27 14:30:58 --> Helper loaded: form_helper
INFO - 2016-05-27 14:30:58 --> Database Driver Class Initialized
INFO - 2016-05-27 14:30:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:30:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:30:58 --> Email Class Initialized
INFO - 2016-05-27 14:30:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:30:58 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:30:58 --> Helper loaded: language_helper
INFO - 2016-05-27 14:30:58 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:30:58 --> Model Class Initialized
INFO - 2016-05-27 14:30:58 --> Helper loaded: date_helper
INFO - 2016-05-27 14:30:58 --> Controller Class Initialized
INFO - 2016-05-27 14:30:58 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:30:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:30:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:30:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:30:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:30:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:30:58 --> Model Class Initialized
INFO - 2016-05-27 14:30:58 --> Form Validation Class Initialized
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:30:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:30:58 --> Final output sent to browser
DEBUG - 2016-05-27 14:30:58 --> Total execution time: 0.0861
INFO - 2016-05-27 14:31:01 --> Config Class Initialized
INFO - 2016-05-27 14:31:01 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:31:01 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:31:01 --> Utf8 Class Initialized
INFO - 2016-05-27 14:31:01 --> URI Class Initialized
INFO - 2016-05-27 14:31:01 --> Router Class Initialized
INFO - 2016-05-27 14:31:01 --> Output Class Initialized
INFO - 2016-05-27 14:31:01 --> Security Class Initialized
DEBUG - 2016-05-27 14:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:31:01 --> CSRF cookie sent
INFO - 2016-05-27 14:31:01 --> CSRF token verified
INFO - 2016-05-27 14:31:01 --> Input Class Initialized
INFO - 2016-05-27 14:31:01 --> Language Class Initialized
INFO - 2016-05-27 14:31:01 --> Loader Class Initialized
INFO - 2016-05-27 14:31:01 --> Helper loaded: form_helper
INFO - 2016-05-27 14:31:01 --> Database Driver Class Initialized
INFO - 2016-05-27 14:31:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:31:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:31:01 --> Email Class Initialized
INFO - 2016-05-27 14:31:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:31:01 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:31:01 --> Helper loaded: language_helper
INFO - 2016-05-27 14:31:01 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:31:01 --> Model Class Initialized
INFO - 2016-05-27 14:31:01 --> Helper loaded: date_helper
INFO - 2016-05-27 14:31:01 --> Controller Class Initialized
INFO - 2016-05-27 14:31:01 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:31:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:31:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:31:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:31:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:31:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:31:01 --> Model Class Initialized
INFO - 2016-05-27 14:31:01 --> Form Validation Class Initialized
INFO - 2016-05-27 14:31:01 --> Final output sent to browser
DEBUG - 2016-05-27 14:31:01 --> Total execution time: 0.0573
INFO - 2016-05-27 14:38:13 --> Config Class Initialized
INFO - 2016-05-27 14:38:13 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:38:13 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:38:13 --> Utf8 Class Initialized
INFO - 2016-05-27 14:38:13 --> URI Class Initialized
INFO - 2016-05-27 14:38:13 --> Router Class Initialized
INFO - 2016-05-27 14:38:13 --> Output Class Initialized
INFO - 2016-05-27 14:38:13 --> Security Class Initialized
DEBUG - 2016-05-27 14:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:38:13 --> CSRF cookie sent
INFO - 2016-05-27 14:38:13 --> Input Class Initialized
INFO - 2016-05-27 14:38:13 --> Language Class Initialized
INFO - 2016-05-27 14:38:13 --> Loader Class Initialized
INFO - 2016-05-27 14:38:13 --> Helper loaded: form_helper
INFO - 2016-05-27 14:38:13 --> Database Driver Class Initialized
INFO - 2016-05-27 14:38:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:38:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:38:13 --> Email Class Initialized
INFO - 2016-05-27 14:38:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:38:13 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:38:13 --> Helper loaded: language_helper
INFO - 2016-05-27 14:38:13 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:38:13 --> Model Class Initialized
INFO - 2016-05-27 14:38:13 --> Helper loaded: date_helper
INFO - 2016-05-27 14:38:13 --> Controller Class Initialized
INFO - 2016-05-27 14:38:13 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:38:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:38:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:38:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:38:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:38:13 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-27 14:38:13 --> Severity: Parsing Error --> syntax error, unexpected '{' /home/demis/www/platformadiabet/application/models/Diabet_model.php 333
INFO - 2016-05-27 14:38:49 --> Config Class Initialized
INFO - 2016-05-27 14:38:49 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:38:49 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:38:49 --> Utf8 Class Initialized
INFO - 2016-05-27 14:38:49 --> URI Class Initialized
INFO - 2016-05-27 14:38:49 --> Router Class Initialized
INFO - 2016-05-27 14:38:49 --> Output Class Initialized
INFO - 2016-05-27 14:38:49 --> Security Class Initialized
DEBUG - 2016-05-27 14:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:38:49 --> CSRF cookie sent
INFO - 2016-05-27 14:38:49 --> Input Class Initialized
INFO - 2016-05-27 14:38:49 --> Language Class Initialized
INFO - 2016-05-27 14:38:49 --> Loader Class Initialized
INFO - 2016-05-27 14:38:49 --> Helper loaded: form_helper
INFO - 2016-05-27 14:38:49 --> Database Driver Class Initialized
INFO - 2016-05-27 14:38:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:38:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:38:49 --> Email Class Initialized
INFO - 2016-05-27 14:38:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:38:49 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:38:49 --> Helper loaded: language_helper
INFO - 2016-05-27 14:38:49 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:38:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:38:49 --> Model Class Initialized
INFO - 2016-05-27 14:38:49 --> Helper loaded: date_helper
INFO - 2016-05-27 14:38:49 --> Controller Class Initialized
INFO - 2016-05-27 14:38:49 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:38:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:38:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:38:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:38:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:38:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:38:49 --> Model Class Initialized
INFO - 2016-05-27 14:38:49 --> Form Validation Class Initialized
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:38:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:38:49 --> Final output sent to browser
DEBUG - 2016-05-27 14:38:49 --> Total execution time: 0.0914
INFO - 2016-05-27 14:38:51 --> Config Class Initialized
INFO - 2016-05-27 14:38:51 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:38:51 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:38:51 --> Utf8 Class Initialized
INFO - 2016-05-27 14:38:51 --> URI Class Initialized
INFO - 2016-05-27 14:38:51 --> Router Class Initialized
INFO - 2016-05-27 14:38:51 --> Output Class Initialized
INFO - 2016-05-27 14:38:51 --> Security Class Initialized
DEBUG - 2016-05-27 14:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:38:51 --> CSRF cookie sent
INFO - 2016-05-27 14:38:51 --> CSRF token verified
INFO - 2016-05-27 14:38:51 --> Input Class Initialized
INFO - 2016-05-27 14:38:51 --> Language Class Initialized
INFO - 2016-05-27 14:38:51 --> Loader Class Initialized
INFO - 2016-05-27 14:38:51 --> Helper loaded: form_helper
INFO - 2016-05-27 14:38:51 --> Database Driver Class Initialized
INFO - 2016-05-27 14:38:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:38:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:38:51 --> Email Class Initialized
INFO - 2016-05-27 14:38:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:38:51 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:38:51 --> Helper loaded: language_helper
INFO - 2016-05-27 14:38:51 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:38:51 --> Model Class Initialized
INFO - 2016-05-27 14:38:51 --> Helper loaded: date_helper
INFO - 2016-05-27 14:38:51 --> Controller Class Initialized
INFO - 2016-05-27 14:38:51 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:38:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:38:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:38:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:38:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:38:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:38:52 --> Model Class Initialized
INFO - 2016-05-27 14:38:52 --> Form Validation Class Initialized
ERROR - 2016-05-27 14:38:52 --> Severity: Warning --> trim() expects parameter 1 to be string, array given /home/demis/www/platformadiabet/application/controllers/Diabet.php 349
INFO - 2016-05-27 14:38:52 --> Final output sent to browser
DEBUG - 2016-05-27 14:38:52 --> Total execution time: 0.0563
INFO - 2016-05-27 14:39:31 --> Config Class Initialized
INFO - 2016-05-27 14:39:31 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:39:31 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:39:31 --> Utf8 Class Initialized
INFO - 2016-05-27 14:39:31 --> URI Class Initialized
INFO - 2016-05-27 14:39:31 --> Router Class Initialized
INFO - 2016-05-27 14:39:31 --> Output Class Initialized
INFO - 2016-05-27 14:39:31 --> Security Class Initialized
DEBUG - 2016-05-27 14:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:39:31 --> CSRF cookie sent
INFO - 2016-05-27 14:39:31 --> Input Class Initialized
INFO - 2016-05-27 14:39:31 --> Language Class Initialized
INFO - 2016-05-27 14:39:31 --> Loader Class Initialized
INFO - 2016-05-27 14:39:31 --> Helper loaded: form_helper
INFO - 2016-05-27 14:39:31 --> Database Driver Class Initialized
INFO - 2016-05-27 14:39:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:39:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:39:31 --> Email Class Initialized
INFO - 2016-05-27 14:39:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:39:31 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:39:31 --> Helper loaded: language_helper
INFO - 2016-05-27 14:39:31 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:39:31 --> Model Class Initialized
INFO - 2016-05-27 14:39:31 --> Helper loaded: date_helper
INFO - 2016-05-27 14:39:31 --> Controller Class Initialized
INFO - 2016-05-27 14:39:31 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:39:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:39:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:39:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:39:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:39:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:39:31 --> Model Class Initialized
INFO - 2016-05-27 14:39:31 --> Form Validation Class Initialized
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:39:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:39:31 --> Final output sent to browser
DEBUG - 2016-05-27 14:39:31 --> Total execution time: 0.0443
INFO - 2016-05-27 14:39:33 --> Config Class Initialized
INFO - 2016-05-27 14:39:33 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:39:33 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:39:33 --> Utf8 Class Initialized
INFO - 2016-05-27 14:39:33 --> URI Class Initialized
INFO - 2016-05-27 14:39:33 --> Router Class Initialized
INFO - 2016-05-27 14:39:33 --> Output Class Initialized
INFO - 2016-05-27 14:39:33 --> Security Class Initialized
DEBUG - 2016-05-27 14:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:39:33 --> CSRF cookie sent
INFO - 2016-05-27 14:39:33 --> CSRF token verified
INFO - 2016-05-27 14:39:33 --> Input Class Initialized
INFO - 2016-05-27 14:39:33 --> Language Class Initialized
INFO - 2016-05-27 14:39:33 --> Loader Class Initialized
INFO - 2016-05-27 14:39:33 --> Helper loaded: form_helper
INFO - 2016-05-27 14:39:33 --> Database Driver Class Initialized
INFO - 2016-05-27 14:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:39:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:39:33 --> Email Class Initialized
INFO - 2016-05-27 14:39:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:39:33 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:39:33 --> Helper loaded: language_helper
INFO - 2016-05-27 14:39:33 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:39:33 --> Model Class Initialized
INFO - 2016-05-27 14:39:33 --> Helper loaded: date_helper
INFO - 2016-05-27 14:39:33 --> Controller Class Initialized
INFO - 2016-05-27 14:39:33 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:39:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:39:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:39:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:39:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:39:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:39:33 --> Model Class Initialized
INFO - 2016-05-27 14:39:33 --> Form Validation Class Initialized
INFO - 2016-05-27 14:39:33 --> Final output sent to browser
DEBUG - 2016-05-27 14:39:33 --> Total execution time: 0.0469
INFO - 2016-05-27 14:45:02 --> Config Class Initialized
INFO - 2016-05-27 14:45:02 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:45:02 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:45:02 --> Utf8 Class Initialized
INFO - 2016-05-27 14:45:02 --> URI Class Initialized
INFO - 2016-05-27 14:45:02 --> Router Class Initialized
INFO - 2016-05-27 14:45:02 --> Output Class Initialized
INFO - 2016-05-27 14:45:02 --> Security Class Initialized
DEBUG - 2016-05-27 14:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:45:02 --> CSRF cookie sent
INFO - 2016-05-27 14:45:02 --> Input Class Initialized
INFO - 2016-05-27 14:45:02 --> Language Class Initialized
INFO - 2016-05-27 14:45:02 --> Loader Class Initialized
INFO - 2016-05-27 14:45:02 --> Helper loaded: form_helper
INFO - 2016-05-27 14:45:02 --> Database Driver Class Initialized
INFO - 2016-05-27 14:45:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:45:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:45:02 --> Email Class Initialized
INFO - 2016-05-27 14:45:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:45:02 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:45:02 --> Helper loaded: language_helper
INFO - 2016-05-27 14:45:02 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:45:02 --> Model Class Initialized
INFO - 2016-05-27 14:45:02 --> Helper loaded: date_helper
INFO - 2016-05-27 14:45:02 --> Controller Class Initialized
INFO - 2016-05-27 14:45:02 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:45:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:45:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:45:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:45:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:45:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:45:02 --> Model Class Initialized
INFO - 2016-05-27 14:45:02 --> Form Validation Class Initialized
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:45:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:45:02 --> Final output sent to browser
DEBUG - 2016-05-27 14:45:02 --> Total execution time: 0.0620
INFO - 2016-05-27 14:45:04 --> Config Class Initialized
INFO - 2016-05-27 14:45:04 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:45:04 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:45:04 --> Utf8 Class Initialized
INFO - 2016-05-27 14:45:04 --> URI Class Initialized
INFO - 2016-05-27 14:45:04 --> Router Class Initialized
INFO - 2016-05-27 14:45:04 --> Output Class Initialized
INFO - 2016-05-27 14:45:04 --> Security Class Initialized
DEBUG - 2016-05-27 14:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:45:04 --> CSRF cookie sent
INFO - 2016-05-27 14:45:04 --> CSRF token verified
INFO - 2016-05-27 14:45:04 --> Input Class Initialized
INFO - 2016-05-27 14:45:04 --> Language Class Initialized
INFO - 2016-05-27 14:45:04 --> Loader Class Initialized
INFO - 2016-05-27 14:45:04 --> Helper loaded: form_helper
INFO - 2016-05-27 14:45:04 --> Database Driver Class Initialized
INFO - 2016-05-27 14:45:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:45:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:45:04 --> Email Class Initialized
INFO - 2016-05-27 14:45:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:45:04 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:45:04 --> Helper loaded: language_helper
INFO - 2016-05-27 14:45:04 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:45:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:45:04 --> Model Class Initialized
INFO - 2016-05-27 14:45:04 --> Helper loaded: date_helper
INFO - 2016-05-27 14:45:04 --> Controller Class Initialized
INFO - 2016-05-27 14:45:04 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:45:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:45:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:45:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:45:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:45:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:45:04 --> Model Class Initialized
INFO - 2016-05-27 14:45:04 --> Form Validation Class Initialized
INFO - 2016-05-27 14:45:04 --> Final output sent to browser
DEBUG - 2016-05-27 14:45:04 --> Total execution time: 0.0165
INFO - 2016-05-27 14:45:29 --> Config Class Initialized
INFO - 2016-05-27 14:45:29 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:45:29 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:45:29 --> Utf8 Class Initialized
INFO - 2016-05-27 14:45:29 --> URI Class Initialized
INFO - 2016-05-27 14:45:29 --> Router Class Initialized
INFO - 2016-05-27 14:45:29 --> Output Class Initialized
INFO - 2016-05-27 14:45:29 --> Security Class Initialized
DEBUG - 2016-05-27 14:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:45:29 --> CSRF cookie sent
INFO - 2016-05-27 14:45:29 --> Input Class Initialized
INFO - 2016-05-27 14:45:29 --> Language Class Initialized
INFO - 2016-05-27 14:45:29 --> Loader Class Initialized
INFO - 2016-05-27 14:45:29 --> Helper loaded: form_helper
INFO - 2016-05-27 14:45:29 --> Database Driver Class Initialized
INFO - 2016-05-27 14:45:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:45:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:45:29 --> Email Class Initialized
INFO - 2016-05-27 14:45:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:45:29 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:45:29 --> Helper loaded: language_helper
INFO - 2016-05-27 14:45:29 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:45:29 --> Model Class Initialized
INFO - 2016-05-27 14:45:29 --> Helper loaded: date_helper
INFO - 2016-05-27 14:45:29 --> Controller Class Initialized
INFO - 2016-05-27 14:45:29 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:45:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:45:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:45:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:45:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:45:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:45:29 --> Model Class Initialized
INFO - 2016-05-27 14:45:29 --> Form Validation Class Initialized
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:45:29 --> Final output sent to browser
DEBUG - 2016-05-27 14:45:29 --> Total execution time: 0.0676
INFO - 2016-05-27 14:45:31 --> Config Class Initialized
INFO - 2016-05-27 14:45:31 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:45:31 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:45:31 --> Utf8 Class Initialized
INFO - 2016-05-27 14:45:31 --> URI Class Initialized
INFO - 2016-05-27 14:45:31 --> Router Class Initialized
INFO - 2016-05-27 14:45:31 --> Output Class Initialized
INFO - 2016-05-27 14:45:31 --> Security Class Initialized
DEBUG - 2016-05-27 14:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:45:31 --> CSRF cookie sent
INFO - 2016-05-27 14:45:31 --> CSRF token verified
INFO - 2016-05-27 14:45:31 --> Input Class Initialized
INFO - 2016-05-27 14:45:31 --> Language Class Initialized
INFO - 2016-05-27 14:45:31 --> Loader Class Initialized
INFO - 2016-05-27 14:45:31 --> Helper loaded: form_helper
INFO - 2016-05-27 14:45:31 --> Database Driver Class Initialized
INFO - 2016-05-27 14:45:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:45:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:45:31 --> Email Class Initialized
INFO - 2016-05-27 14:45:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:45:31 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:45:31 --> Helper loaded: language_helper
INFO - 2016-05-27 14:45:31 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:45:31 --> Model Class Initialized
INFO - 2016-05-27 14:45:31 --> Helper loaded: date_helper
INFO - 2016-05-27 14:45:31 --> Controller Class Initialized
INFO - 2016-05-27 14:45:31 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:45:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:45:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:45:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:45:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:45:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:45:31 --> Model Class Initialized
INFO - 2016-05-27 14:45:31 --> Form Validation Class Initialized
INFO - 2016-05-27 14:45:31 --> Final output sent to browser
DEBUG - 2016-05-27 14:45:31 --> Total execution time: 0.0150
INFO - 2016-05-27 14:53:57 --> Config Class Initialized
INFO - 2016-05-27 14:53:57 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:53:57 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:53:57 --> Utf8 Class Initialized
INFO - 2016-05-27 14:53:57 --> URI Class Initialized
INFO - 2016-05-27 14:53:57 --> Router Class Initialized
INFO - 2016-05-27 14:53:57 --> Output Class Initialized
INFO - 2016-05-27 14:53:57 --> Security Class Initialized
DEBUG - 2016-05-27 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:53:57 --> CSRF cookie sent
INFO - 2016-05-27 14:53:57 --> Input Class Initialized
INFO - 2016-05-27 14:53:57 --> Language Class Initialized
INFO - 2016-05-27 14:53:57 --> Loader Class Initialized
INFO - 2016-05-27 14:53:57 --> Helper loaded: form_helper
INFO - 2016-05-27 14:53:57 --> Database Driver Class Initialized
INFO - 2016-05-27 14:53:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:53:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:53:57 --> Email Class Initialized
INFO - 2016-05-27 14:53:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:53:57 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:53:57 --> Helper loaded: language_helper
INFO - 2016-05-27 14:53:57 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:53:57 --> Model Class Initialized
INFO - 2016-05-27 14:53:57 --> Helper loaded: date_helper
INFO - 2016-05-27 14:53:57 --> Controller Class Initialized
INFO - 2016-05-27 14:53:57 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:53:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:53:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:53:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:53:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:53:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:53:57 --> Model Class Initialized
INFO - 2016-05-27 14:53:57 --> Form Validation Class Initialized
INFO - 2016-05-27 14:53:57 --> Config Class Initialized
INFO - 2016-05-27 14:53:57 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:53:57 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:53:57 --> Utf8 Class Initialized
INFO - 2016-05-27 14:53:57 --> URI Class Initialized
INFO - 2016-05-27 14:53:57 --> Router Class Initialized
INFO - 2016-05-27 14:53:57 --> Output Class Initialized
INFO - 2016-05-27 14:53:57 --> Security Class Initialized
DEBUG - 2016-05-27 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:53:57 --> CSRF cookie sent
INFO - 2016-05-27 14:53:57 --> Input Class Initialized
INFO - 2016-05-27 14:53:57 --> Language Class Initialized
INFO - 2016-05-27 14:53:57 --> Loader Class Initialized
INFO - 2016-05-27 14:53:57 --> Helper loaded: form_helper
INFO - 2016-05-27 14:53:57 --> Database Driver Class Initialized
INFO - 2016-05-27 14:53:57 --> Config Class Initialized
INFO - 2016-05-27 14:53:57 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:53:57 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:53:57 --> Utf8 Class Initialized
INFO - 2016-05-27 14:53:57 --> URI Class Initialized
INFO - 2016-05-27 14:53:57 --> Router Class Initialized
INFO - 2016-05-27 14:53:57 --> Output Class Initialized
INFO - 2016-05-27 14:53:57 --> Security Class Initialized
DEBUG - 2016-05-27 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:53:58 --> CSRF cookie sent
INFO - 2016-05-27 14:53:58 --> Input Class Initialized
INFO - 2016-05-27 14:53:58 --> Language Class Initialized
ERROR - 2016-05-27 14:53:58 --> 404 Page Not Found: Faviconico/index
INFO - 2016-05-27 14:53:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:53:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:53:58 --> Email Class Initialized
INFO - 2016-05-27 14:53:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:53:58 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:53:58 --> Helper loaded: language_helper
INFO - 2016-05-27 14:53:58 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:53:58 --> Model Class Initialized
INFO - 2016-05-27 14:53:58 --> Helper loaded: date_helper
INFO - 2016-05-27 14:53:58 --> Controller Class Initialized
INFO - 2016-05-27 14:53:58 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:53:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:53:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:53:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:53:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:53:58 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-27 14:53:58 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:53:58 --> Form Validation Class Initialized
INFO - 2016-05-27 14:53:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-27 14:53:58 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-27 14:53:58 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-27 14:53:58 --> Final output sent to browser
DEBUG - 2016-05-27 14:53:58 --> Total execution time: 0.6576
INFO - 2016-05-27 14:56:20 --> Config Class Initialized
INFO - 2016-05-27 14:56:20 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:56:20 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:56:20 --> Utf8 Class Initialized
INFO - 2016-05-27 14:56:20 --> URI Class Initialized
INFO - 2016-05-27 14:56:20 --> Router Class Initialized
INFO - 2016-05-27 14:56:20 --> Output Class Initialized
INFO - 2016-05-27 14:56:20 --> Security Class Initialized
DEBUG - 2016-05-27 14:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:56:20 --> CSRF cookie sent
INFO - 2016-05-27 14:56:20 --> Input Class Initialized
INFO - 2016-05-27 14:56:20 --> Language Class Initialized
INFO - 2016-05-27 14:56:20 --> Loader Class Initialized
INFO - 2016-05-27 14:56:20 --> Helper loaded: form_helper
INFO - 2016-05-27 14:56:20 --> Database Driver Class Initialized
INFO - 2016-05-27 14:56:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:56:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:56:20 --> Email Class Initialized
INFO - 2016-05-27 14:56:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:56:20 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:56:20 --> Helper loaded: language_helper
INFO - 2016-05-27 14:56:20 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:56:20 --> Model Class Initialized
INFO - 2016-05-27 14:56:20 --> Helper loaded: date_helper
INFO - 2016-05-27 14:56:20 --> Controller Class Initialized
INFO - 2016-05-27 14:56:20 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:56:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:56:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:56:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:56:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:56:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:56:20 --> Model Class Initialized
INFO - 2016-05-27 14:56:20 --> Form Validation Class Initialized
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-27 14:56:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-27 14:56:20 --> Final output sent to browser
DEBUG - 2016-05-27 14:56:20 --> Total execution time: 0.2646
INFO - 2016-05-27 14:56:23 --> Config Class Initialized
INFO - 2016-05-27 14:56:23 --> Hooks Class Initialized
DEBUG - 2016-05-27 14:56:23 --> UTF-8 Support Enabled
INFO - 2016-05-27 14:56:23 --> Utf8 Class Initialized
INFO - 2016-05-27 14:56:23 --> URI Class Initialized
INFO - 2016-05-27 14:56:23 --> Router Class Initialized
INFO - 2016-05-27 14:56:23 --> Output Class Initialized
INFO - 2016-05-27 14:56:23 --> Security Class Initialized
DEBUG - 2016-05-27 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-27 14:56:23 --> CSRF cookie sent
INFO - 2016-05-27 14:56:23 --> CSRF token verified
INFO - 2016-05-27 14:56:23 --> Input Class Initialized
INFO - 2016-05-27 14:56:23 --> Language Class Initialized
INFO - 2016-05-27 14:56:23 --> Loader Class Initialized
INFO - 2016-05-27 14:56:23 --> Helper loaded: form_helper
INFO - 2016-05-27 14:56:23 --> Database Driver Class Initialized
INFO - 2016-05-27 14:56:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-27 14:56:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-27 14:56:23 --> Email Class Initialized
INFO - 2016-05-27 14:56:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-27 14:56:23 --> Helper loaded: cookie_helper
INFO - 2016-05-27 14:56:23 --> Helper loaded: language_helper
INFO - 2016-05-27 14:56:23 --> Helper loaded: url_helper
DEBUG - 2016-05-27 14:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-27 14:56:23 --> Model Class Initialized
INFO - 2016-05-27 14:56:23 --> Helper loaded: date_helper
INFO - 2016-05-27 14:56:23 --> Controller Class Initialized
INFO - 2016-05-27 14:56:23 --> Helper loaded: languages_helper
INFO - 2016-05-27 14:56:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-27 14:56:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-27 14:56:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-27 14:56:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-27 14:56:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-27 14:56:23 --> Model Class Initialized
INFO - 2016-05-27 14:56:23 --> Form Validation Class Initialized
INFO - 2016-05-27 14:56:23 --> Final output sent to browser
DEBUG - 2016-05-27 14:56:23 --> Total execution time: 0.0754
