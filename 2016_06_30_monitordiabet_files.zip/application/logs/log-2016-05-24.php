<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-24 10:06:39 --> Config Class Initialized
INFO - 2016-05-24 10:06:39 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:06:39 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:06:39 --> Utf8 Class Initialized
INFO - 2016-05-24 10:06:39 --> URI Class Initialized
INFO - 2016-05-24 10:06:39 --> Router Class Initialized
INFO - 2016-05-24 10:06:39 --> Output Class Initialized
INFO - 2016-05-24 10:06:39 --> Security Class Initialized
DEBUG - 2016-05-24 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:06:39 --> CSRF cookie sent
INFO - 2016-05-24 10:06:39 --> Input Class Initialized
INFO - 2016-05-24 10:06:39 --> Language Class Initialized
INFO - 2016-05-24 10:06:40 --> Loader Class Initialized
INFO - 2016-05-24 10:06:40 --> Helper loaded: form_helper
INFO - 2016-05-24 10:06:40 --> Database Driver Class Initialized
INFO - 2016-05-24 10:06:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:06:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:06:40 --> Email Class Initialized
INFO - 2016-05-24 10:06:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:06:41 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:06:41 --> Helper loaded: language_helper
INFO - 2016-05-24 10:06:41 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:06:41 --> Model Class Initialized
INFO - 2016-05-24 10:06:41 --> Helper loaded: date_helper
INFO - 2016-05-24 10:06:41 --> Controller Class Initialized
INFO - 2016-05-24 10:06:41 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:06:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:06:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:06:41 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:06:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:06:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:06:41 --> Model Class Initialized
INFO - 2016-05-24 10:06:42 --> Config Class Initialized
INFO - 2016-05-24 10:06:42 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:06:42 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:06:42 --> Utf8 Class Initialized
INFO - 2016-05-24 10:06:42 --> URI Class Initialized
INFO - 2016-05-24 10:06:42 --> Router Class Initialized
INFO - 2016-05-24 10:06:42 --> Output Class Initialized
INFO - 2016-05-24 10:06:42 --> Security Class Initialized
DEBUG - 2016-05-24 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:06:42 --> CSRF cookie sent
INFO - 2016-05-24 10:06:42 --> Input Class Initialized
INFO - 2016-05-24 10:06:42 --> Language Class Initialized
INFO - 2016-05-24 10:06:42 --> Loader Class Initialized
INFO - 2016-05-24 10:06:42 --> Helper loaded: form_helper
INFO - 2016-05-24 10:06:42 --> Database Driver Class Initialized
INFO - 2016-05-24 10:06:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:06:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:06:42 --> Email Class Initialized
INFO - 2016-05-24 10:06:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:06:42 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:06:42 --> Helper loaded: language_helper
INFO - 2016-05-24 10:06:42 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:06:42 --> Model Class Initialized
INFO - 2016-05-24 10:06:42 --> Helper loaded: date_helper
INFO - 2016-05-24 10:06:42 --> Controller Class Initialized
INFO - 2016-05-24 10:06:42 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:06:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:06:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:06:42 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:06:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:06:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 10:06:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:06:42 --> Form Validation Class Initialized
INFO - 2016-05-24 10:06:42 --> Helper loaded: languages_helper
INFO - 2016-05-24 10:06:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 10:06:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 10:06:42 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 10:06:42 --> Final output sent to browser
DEBUG - 2016-05-24 10:06:42 --> Total execution time: 0.3369
INFO - 2016-05-24 10:06:46 --> Config Class Initialized
INFO - 2016-05-24 10:06:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:06:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:06:46 --> Utf8 Class Initialized
INFO - 2016-05-24 10:06:46 --> URI Class Initialized
INFO - 2016-05-24 10:06:46 --> Router Class Initialized
INFO - 2016-05-24 10:06:46 --> Output Class Initialized
INFO - 2016-05-24 10:06:46 --> Security Class Initialized
DEBUG - 2016-05-24 10:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:06:46 --> CSRF cookie sent
INFO - 2016-05-24 10:06:46 --> Input Class Initialized
INFO - 2016-05-24 10:06:46 --> Language Class Initialized
ERROR - 2016-05-24 10:06:46 --> 404 Page Not Found: Faviconico/index
INFO - 2016-05-24 10:12:34 --> Config Class Initialized
INFO - 2016-05-24 10:12:34 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:12:34 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:12:34 --> Utf8 Class Initialized
INFO - 2016-05-24 10:12:34 --> URI Class Initialized
INFO - 2016-05-24 10:12:34 --> Router Class Initialized
INFO - 2016-05-24 10:12:34 --> Output Class Initialized
INFO - 2016-05-24 10:12:34 --> Security Class Initialized
DEBUG - 2016-05-24 10:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:12:34 --> CSRF cookie sent
INFO - 2016-05-24 10:12:34 --> Input Class Initialized
INFO - 2016-05-24 10:12:34 --> Language Class Initialized
INFO - 2016-05-24 10:12:34 --> Loader Class Initialized
INFO - 2016-05-24 10:12:34 --> Helper loaded: form_helper
INFO - 2016-05-24 10:12:34 --> Database Driver Class Initialized
INFO - 2016-05-24 10:12:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:12:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:12:34 --> Email Class Initialized
INFO - 2016-05-24 10:12:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:12:34 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:12:34 --> Helper loaded: language_helper
INFO - 2016-05-24 10:12:34 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:12:34 --> Model Class Initialized
INFO - 2016-05-24 10:12:34 --> Helper loaded: date_helper
INFO - 2016-05-24 10:12:34 --> Controller Class Initialized
DEBUG - 2016-05-24 10:12:34 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:12:34 --> Form Validation Class Initialized
INFO - 2016-05-24 10:12:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 10:12:34 --> Config Class Initialized
INFO - 2016-05-24 10:12:34 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:12:34 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:12:34 --> Utf8 Class Initialized
INFO - 2016-05-24 10:12:34 --> URI Class Initialized
INFO - 2016-05-24 10:12:34 --> Router Class Initialized
INFO - 2016-05-24 10:12:34 --> Output Class Initialized
INFO - 2016-05-24 10:12:34 --> Security Class Initialized
DEBUG - 2016-05-24 10:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:12:34 --> CSRF cookie sent
INFO - 2016-05-24 10:12:34 --> Input Class Initialized
INFO - 2016-05-24 10:12:34 --> Language Class Initialized
INFO - 2016-05-24 10:12:34 --> Loader Class Initialized
INFO - 2016-05-24 10:12:34 --> Helper loaded: form_helper
INFO - 2016-05-24 10:12:34 --> Database Driver Class Initialized
INFO - 2016-05-24 10:12:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:12:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:12:34 --> Email Class Initialized
INFO - 2016-05-24 10:12:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:12:34 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:12:34 --> Helper loaded: language_helper
INFO - 2016-05-24 10:12:34 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:12:34 --> Model Class Initialized
INFO - 2016-05-24 10:12:34 --> Helper loaded: date_helper
INFO - 2016-05-24 10:12:34 --> Controller Class Initialized
DEBUG - 2016-05-24 10:12:34 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:12:34 --> Form Validation Class Initialized
INFO - 2016-05-24 10:12:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 10:18:58 --> Config Class Initialized
INFO - 2016-05-24 10:18:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:18:58 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:18:58 --> Utf8 Class Initialized
INFO - 2016-05-24 10:18:58 --> URI Class Initialized
INFO - 2016-05-24 10:18:58 --> Router Class Initialized
INFO - 2016-05-24 10:18:58 --> Output Class Initialized
INFO - 2016-05-24 10:18:58 --> Security Class Initialized
DEBUG - 2016-05-24 10:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:18:58 --> CSRF cookie sent
INFO - 2016-05-24 10:18:58 --> Input Class Initialized
INFO - 2016-05-24 10:18:58 --> Language Class Initialized
INFO - 2016-05-24 10:18:59 --> Loader Class Initialized
INFO - 2016-05-24 10:18:59 --> Helper loaded: form_helper
INFO - 2016-05-24 10:18:59 --> Database Driver Class Initialized
INFO - 2016-05-24 10:18:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:18:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:18:59 --> Email Class Initialized
INFO - 2016-05-24 10:18:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:18:59 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:18:59 --> Helper loaded: language_helper
INFO - 2016-05-24 10:18:59 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:18:59 --> Model Class Initialized
INFO - 2016-05-24 10:18:59 --> Helper loaded: date_helper
INFO - 2016-05-24 10:18:59 --> Controller Class Initialized
DEBUG - 2016-05-24 10:18:59 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:18:59 --> Form Validation Class Initialized
INFO - 2016-05-24 10:18:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 10:18:59 --> Config Class Initialized
INFO - 2016-05-24 10:18:59 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:18:59 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:18:59 --> Utf8 Class Initialized
INFO - 2016-05-24 10:18:59 --> URI Class Initialized
INFO - 2016-05-24 10:18:59 --> Router Class Initialized
INFO - 2016-05-24 10:18:59 --> Output Class Initialized
INFO - 2016-05-24 10:18:59 --> Security Class Initialized
DEBUG - 2016-05-24 10:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:18:59 --> CSRF cookie sent
INFO - 2016-05-24 10:18:59 --> Input Class Initialized
INFO - 2016-05-24 10:18:59 --> Language Class Initialized
INFO - 2016-05-24 10:18:59 --> Loader Class Initialized
INFO - 2016-05-24 10:18:59 --> Helper loaded: form_helper
INFO - 2016-05-24 10:18:59 --> Database Driver Class Initialized
INFO - 2016-05-24 10:18:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:18:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:18:59 --> Email Class Initialized
INFO - 2016-05-24 10:18:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:18:59 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:18:59 --> Helper loaded: language_helper
INFO - 2016-05-24 10:18:59 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:18:59 --> Model Class Initialized
INFO - 2016-05-24 10:18:59 --> Helper loaded: date_helper
INFO - 2016-05-24 10:18:59 --> Controller Class Initialized
DEBUG - 2016-05-24 10:18:59 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:18:59 --> Form Validation Class Initialized
INFO - 2016-05-24 10:18:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 10:22:58 --> Config Class Initialized
INFO - 2016-05-24 10:22:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:22:58 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:22:58 --> Utf8 Class Initialized
INFO - 2016-05-24 10:22:58 --> URI Class Initialized
INFO - 2016-05-24 10:22:58 --> Router Class Initialized
INFO - 2016-05-24 10:22:58 --> Output Class Initialized
INFO - 2016-05-24 10:22:58 --> Security Class Initialized
DEBUG - 2016-05-24 10:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:22:58 --> CSRF cookie sent
INFO - 2016-05-24 10:22:58 --> Input Class Initialized
INFO - 2016-05-24 10:22:58 --> Language Class Initialized
INFO - 2016-05-24 10:22:58 --> Loader Class Initialized
INFO - 2016-05-24 10:22:58 --> Helper loaded: form_helper
INFO - 2016-05-24 10:22:58 --> Database Driver Class Initialized
INFO - 2016-05-24 10:22:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:22:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:22:59 --> Email Class Initialized
INFO - 2016-05-24 10:22:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:22:59 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:22:59 --> Helper loaded: language_helper
INFO - 2016-05-24 10:22:59 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:22:59 --> Model Class Initialized
INFO - 2016-05-24 10:22:59 --> Helper loaded: date_helper
INFO - 2016-05-24 10:22:59 --> Controller Class Initialized
DEBUG - 2016-05-24 10:22:59 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:22:59 --> Form Validation Class Initialized
INFO - 2016-05-24 10:22:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 10:22:59 --> Config Class Initialized
INFO - 2016-05-24 10:22:59 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:22:59 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:22:59 --> Utf8 Class Initialized
INFO - 2016-05-24 10:22:59 --> URI Class Initialized
INFO - 2016-05-24 10:22:59 --> Router Class Initialized
INFO - 2016-05-24 10:22:59 --> Output Class Initialized
INFO - 2016-05-24 10:22:59 --> Security Class Initialized
DEBUG - 2016-05-24 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:22:59 --> CSRF cookie sent
INFO - 2016-05-24 10:22:59 --> Input Class Initialized
INFO - 2016-05-24 10:22:59 --> Language Class Initialized
INFO - 2016-05-24 10:22:59 --> Loader Class Initialized
INFO - 2016-05-24 10:22:59 --> Helper loaded: form_helper
INFO - 2016-05-24 10:22:59 --> Database Driver Class Initialized
INFO - 2016-05-24 10:22:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:22:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:22:59 --> Email Class Initialized
INFO - 2016-05-24 10:22:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:22:59 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:22:59 --> Helper loaded: language_helper
INFO - 2016-05-24 10:22:59 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:22:59 --> Model Class Initialized
INFO - 2016-05-24 10:22:59 --> Helper loaded: date_helper
INFO - 2016-05-24 10:22:59 --> Controller Class Initialized
DEBUG - 2016-05-24 10:22:59 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:22:59 --> Form Validation Class Initialized
INFO - 2016-05-24 10:22:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 10:28:42 --> Config Class Initialized
INFO - 2016-05-24 10:28:42 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:28:42 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:28:42 --> Utf8 Class Initialized
INFO - 2016-05-24 10:28:42 --> URI Class Initialized
DEBUG - 2016-05-24 10:28:42 --> No URI present. Default controller set.
INFO - 2016-05-24 10:28:42 --> Router Class Initialized
INFO - 2016-05-24 10:28:42 --> Output Class Initialized
INFO - 2016-05-24 10:28:42 --> Security Class Initialized
DEBUG - 2016-05-24 10:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:28:42 --> CSRF cookie sent
INFO - 2016-05-24 10:28:42 --> Input Class Initialized
INFO - 2016-05-24 10:28:42 --> Language Class Initialized
INFO - 2016-05-24 10:28:42 --> Loader Class Initialized
INFO - 2016-05-24 10:28:42 --> Helper loaded: form_helper
INFO - 2016-05-24 10:28:42 --> Database Driver Class Initialized
INFO - 2016-05-24 10:28:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:28:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:28:43 --> Email Class Initialized
INFO - 2016-05-24 10:28:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:28:43 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:28:43 --> Helper loaded: language_helper
INFO - 2016-05-24 10:28:43 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:28:43 --> Model Class Initialized
INFO - 2016-05-24 10:28:43 --> Helper loaded: date_helper
INFO - 2016-05-24 10:28:43 --> Controller Class Initialized
INFO - 2016-05-24 10:28:43 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:28:43 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:28:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:28:43 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:28:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:28:43 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:28:43 --> Migrations Class Initialized
INFO - 2016-05-24 10:29:11 --> Config Class Initialized
INFO - 2016-05-24 10:29:11 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:29:11 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:29:11 --> Utf8 Class Initialized
INFO - 2016-05-24 10:29:11 --> URI Class Initialized
INFO - 2016-05-24 10:29:11 --> Router Class Initialized
INFO - 2016-05-24 10:29:11 --> Output Class Initialized
INFO - 2016-05-24 10:29:11 --> Security Class Initialized
DEBUG - 2016-05-24 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:29:11 --> CSRF cookie sent
INFO - 2016-05-24 10:29:11 --> Input Class Initialized
INFO - 2016-05-24 10:29:11 --> Language Class Initialized
INFO - 2016-05-24 10:29:11 --> Loader Class Initialized
INFO - 2016-05-24 10:29:11 --> Helper loaded: form_helper
INFO - 2016-05-24 10:29:11 --> Database Driver Class Initialized
INFO - 2016-05-24 10:29:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:29:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:29:11 --> Email Class Initialized
INFO - 2016-05-24 10:29:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:29:11 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:29:11 --> Helper loaded: language_helper
INFO - 2016-05-24 10:29:11 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:29:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:29:11 --> Model Class Initialized
INFO - 2016-05-24 10:29:11 --> Helper loaded: date_helper
INFO - 2016-05-24 10:29:11 --> Controller Class Initialized
INFO - 2016-05-24 10:29:11 --> Migrations Class Initialized
INFO - 2016-05-24 10:33:52 --> Config Class Initialized
INFO - 2016-05-24 10:33:52 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:33:52 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:33:52 --> Utf8 Class Initialized
INFO - 2016-05-24 10:33:52 --> URI Class Initialized
INFO - 2016-05-24 10:33:52 --> Router Class Initialized
INFO - 2016-05-24 10:33:52 --> Output Class Initialized
INFO - 2016-05-24 10:33:52 --> Security Class Initialized
DEBUG - 2016-05-24 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:33:52 --> CSRF cookie sent
INFO - 2016-05-24 10:33:52 --> Input Class Initialized
INFO - 2016-05-24 10:33:52 --> Language Class Initialized
INFO - 2016-05-24 10:33:52 --> Loader Class Initialized
INFO - 2016-05-24 10:33:52 --> Helper loaded: form_helper
INFO - 2016-05-24 10:33:52 --> Database Driver Class Initialized
INFO - 2016-05-24 10:33:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:33:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:33:52 --> Email Class Initialized
INFO - 2016-05-24 10:33:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:33:52 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:33:52 --> Helper loaded: language_helper
INFO - 2016-05-24 10:33:52 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:33:52 --> Model Class Initialized
INFO - 2016-05-24 10:33:52 --> Helper loaded: date_helper
INFO - 2016-05-24 10:33:52 --> Controller Class Initialized
INFO - 2016-05-24 10:33:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:33:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:33:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:33:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:33:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:33:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:33:52 --> Migrations Class Initialized
INFO - 2016-05-24 10:33:55 --> Config Class Initialized
INFO - 2016-05-24 10:33:55 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:33:55 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:33:55 --> Utf8 Class Initialized
INFO - 2016-05-24 10:33:55 --> URI Class Initialized
INFO - 2016-05-24 10:33:55 --> Router Class Initialized
INFO - 2016-05-24 10:33:55 --> Output Class Initialized
INFO - 2016-05-24 10:33:55 --> Security Class Initialized
DEBUG - 2016-05-24 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:33:55 --> CSRF cookie sent
INFO - 2016-05-24 10:33:55 --> Input Class Initialized
INFO - 2016-05-24 10:33:55 --> Language Class Initialized
INFO - 2016-05-24 10:33:55 --> Loader Class Initialized
INFO - 2016-05-24 10:33:55 --> Helper loaded: form_helper
INFO - 2016-05-24 10:33:55 --> Database Driver Class Initialized
INFO - 2016-05-24 10:33:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:33:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:33:55 --> Email Class Initialized
INFO - 2016-05-24 10:33:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:33:55 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:33:55 --> Helper loaded: language_helper
INFO - 2016-05-24 10:33:55 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:33:55 --> Model Class Initialized
INFO - 2016-05-24 10:33:55 --> Helper loaded: date_helper
INFO - 2016-05-24 10:33:55 --> Controller Class Initialized
INFO - 2016-05-24 10:33:55 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:33:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:33:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:33:55 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:33:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:33:55 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:33:55 --> Migrations Class Initialized
INFO - 2016-05-24 10:36:00 --> Config Class Initialized
INFO - 2016-05-24 10:36:00 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:36:00 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:36:00 --> Utf8 Class Initialized
INFO - 2016-05-24 10:36:00 --> URI Class Initialized
INFO - 2016-05-24 10:36:00 --> Router Class Initialized
INFO - 2016-05-24 10:36:00 --> Output Class Initialized
INFO - 2016-05-24 10:36:00 --> Security Class Initialized
DEBUG - 2016-05-24 10:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:36:00 --> CSRF cookie sent
INFO - 2016-05-24 10:36:00 --> Input Class Initialized
INFO - 2016-05-24 10:36:00 --> Language Class Initialized
INFO - 2016-05-24 10:36:00 --> Loader Class Initialized
INFO - 2016-05-24 10:36:00 --> Helper loaded: form_helper
INFO - 2016-05-24 10:36:00 --> Database Driver Class Initialized
INFO - 2016-05-24 10:36:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:36:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:36:00 --> Email Class Initialized
INFO - 2016-05-24 10:36:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:36:00 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:36:00 --> Helper loaded: language_helper
INFO - 2016-05-24 10:36:00 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:36:00 --> Model Class Initialized
INFO - 2016-05-24 10:36:00 --> Helper loaded: date_helper
INFO - 2016-05-24 10:36:00 --> Controller Class Initialized
INFO - 2016-05-24 10:36:00 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:36:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:36:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:36:00 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:36:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:36:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:36:00 --> Migrations Class Initialized
INFO - 2016-05-24 10:36:02 --> Config Class Initialized
INFO - 2016-05-24 10:36:02 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:36:02 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:36:02 --> Utf8 Class Initialized
INFO - 2016-05-24 10:36:02 --> URI Class Initialized
INFO - 2016-05-24 10:36:02 --> Router Class Initialized
INFO - 2016-05-24 10:36:02 --> Output Class Initialized
INFO - 2016-05-24 10:36:02 --> Security Class Initialized
DEBUG - 2016-05-24 10:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:36:02 --> CSRF cookie sent
INFO - 2016-05-24 10:36:02 --> Input Class Initialized
INFO - 2016-05-24 10:36:02 --> Language Class Initialized
INFO - 2016-05-24 10:36:02 --> Loader Class Initialized
INFO - 2016-05-24 10:36:02 --> Helper loaded: form_helper
INFO - 2016-05-24 10:36:02 --> Database Driver Class Initialized
INFO - 2016-05-24 10:36:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:36:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:36:02 --> Email Class Initialized
INFO - 2016-05-24 10:36:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:36:02 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:36:02 --> Helper loaded: language_helper
INFO - 2016-05-24 10:36:02 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:36:02 --> Model Class Initialized
INFO - 2016-05-24 10:36:02 --> Helper loaded: date_helper
INFO - 2016-05-24 10:36:02 --> Controller Class Initialized
INFO - 2016-05-24 10:36:02 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:36:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:36:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:36:02 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:36:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:36:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:36:02 --> Migrations Class Initialized
INFO - 2016-05-24 10:36:57 --> Config Class Initialized
INFO - 2016-05-24 10:36:57 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:36:57 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:36:57 --> Utf8 Class Initialized
INFO - 2016-05-24 10:36:57 --> URI Class Initialized
INFO - 2016-05-24 10:36:57 --> Router Class Initialized
INFO - 2016-05-24 10:36:57 --> Output Class Initialized
INFO - 2016-05-24 10:36:57 --> Security Class Initialized
DEBUG - 2016-05-24 10:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:36:57 --> CSRF cookie sent
INFO - 2016-05-24 10:36:57 --> Input Class Initialized
INFO - 2016-05-24 10:36:57 --> Language Class Initialized
INFO - 2016-05-24 10:36:57 --> Loader Class Initialized
INFO - 2016-05-24 10:36:57 --> Helper loaded: form_helper
INFO - 2016-05-24 10:36:57 --> Database Driver Class Initialized
INFO - 2016-05-24 10:36:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:36:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:36:57 --> Email Class Initialized
INFO - 2016-05-24 10:36:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:36:57 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:36:57 --> Helper loaded: language_helper
INFO - 2016-05-24 10:36:57 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:36:57 --> Model Class Initialized
INFO - 2016-05-24 10:36:57 --> Helper loaded: date_helper
INFO - 2016-05-24 10:36:57 --> Controller Class Initialized
INFO - 2016-05-24 10:36:57 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:36:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:36:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:36:57 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:36:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:36:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:36:57 --> Migrations Class Initialized
INFO - 2016-05-24 10:39:11 --> Config Class Initialized
INFO - 2016-05-24 10:39:11 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:39:11 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:39:11 --> Utf8 Class Initialized
INFO - 2016-05-24 10:39:11 --> URI Class Initialized
INFO - 2016-05-24 10:39:12 --> Router Class Initialized
INFO - 2016-05-24 10:39:12 --> Output Class Initialized
INFO - 2016-05-24 10:39:12 --> Security Class Initialized
DEBUG - 2016-05-24 10:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:39:12 --> CSRF cookie sent
INFO - 2016-05-24 10:39:12 --> Input Class Initialized
INFO - 2016-05-24 10:39:12 --> Language Class Initialized
INFO - 2016-05-24 10:39:12 --> Loader Class Initialized
INFO - 2016-05-24 10:39:12 --> Helper loaded: form_helper
INFO - 2016-05-24 10:39:12 --> Database Driver Class Initialized
INFO - 2016-05-24 10:39:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:39:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:39:12 --> Email Class Initialized
INFO - 2016-05-24 10:39:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:39:12 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:39:12 --> Helper loaded: language_helper
INFO - 2016-05-24 10:39:12 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:39:12 --> Model Class Initialized
INFO - 2016-05-24 10:39:12 --> Helper loaded: date_helper
INFO - 2016-05-24 10:39:12 --> Controller Class Initialized
INFO - 2016-05-24 10:39:12 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 10:39:12 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 10:39:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 10:39:12 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 10:39:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 10:39:12 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 10:39:12 --> Migrations Class Initialized
INFO - 2016-05-24 10:51:37 --> Config Class Initialized
INFO - 2016-05-24 10:51:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:51:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:51:37 --> Utf8 Class Initialized
INFO - 2016-05-24 10:51:37 --> URI Class Initialized
INFO - 2016-05-24 10:51:37 --> Router Class Initialized
INFO - 2016-05-24 10:51:37 --> Output Class Initialized
INFO - 2016-05-24 10:51:37 --> Security Class Initialized
DEBUG - 2016-05-24 10:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:51:37 --> CSRF cookie sent
INFO - 2016-05-24 10:51:37 --> Input Class Initialized
INFO - 2016-05-24 10:51:37 --> Language Class Initialized
INFO - 2016-05-24 10:51:37 --> Loader Class Initialized
INFO - 2016-05-24 10:51:37 --> Helper loaded: form_helper
INFO - 2016-05-24 10:51:37 --> Database Driver Class Initialized
INFO - 2016-05-24 10:51:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:51:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:51:37 --> Email Class Initialized
INFO - 2016-05-24 10:51:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:51:37 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:51:37 --> Helper loaded: language_helper
INFO - 2016-05-24 10:51:37 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:51:37 --> Model Class Initialized
INFO - 2016-05-24 10:51:37 --> Helper loaded: date_helper
INFO - 2016-05-24 10:51:37 --> Controller Class Initialized
INFO - 2016-05-24 10:51:37 --> Migrations Class Initialized
INFO - 2016-05-24 10:54:10 --> Config Class Initialized
INFO - 2016-05-24 10:54:10 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:54:10 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:54:10 --> Utf8 Class Initialized
INFO - 2016-05-24 10:54:10 --> URI Class Initialized
INFO - 2016-05-24 10:54:10 --> Router Class Initialized
INFO - 2016-05-24 10:54:10 --> Output Class Initialized
INFO - 2016-05-24 10:54:10 --> Security Class Initialized
DEBUG - 2016-05-24 10:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:54:10 --> CSRF cookie sent
INFO - 2016-05-24 10:54:10 --> Input Class Initialized
INFO - 2016-05-24 10:54:10 --> Language Class Initialized
INFO - 2016-05-24 10:54:10 --> Loader Class Initialized
INFO - 2016-05-24 10:54:10 --> Helper loaded: form_helper
INFO - 2016-05-24 10:54:10 --> Database Driver Class Initialized
INFO - 2016-05-24 10:54:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:54:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:54:11 --> Email Class Initialized
INFO - 2016-05-24 10:54:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:54:11 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:54:11 --> Helper loaded: language_helper
INFO - 2016-05-24 10:54:11 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:54:11 --> Model Class Initialized
INFO - 2016-05-24 10:54:11 --> Helper loaded: date_helper
INFO - 2016-05-24 10:54:11 --> Controller Class Initialized
INFO - 2016-05-24 10:54:11 --> Migrations Class Initialized
INFO - 2016-05-24 10:54:11 --> Language file loaded: language/romanian/migration_lang.php
INFO - 2016-05-24 10:54:11 --> Database Forge Class Initialized
INFO - 2016-05-24 10:54:15 --> Final output sent to browser
DEBUG - 2016-05-24 10:54:15 --> Total execution time: 4.8134
INFO - 2016-05-24 10:57:06 --> Config Class Initialized
INFO - 2016-05-24 10:57:06 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:57:06 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:57:06 --> Utf8 Class Initialized
INFO - 2016-05-24 10:57:06 --> URI Class Initialized
INFO - 2016-05-24 10:57:06 --> Router Class Initialized
INFO - 2016-05-24 10:57:06 --> Output Class Initialized
INFO - 2016-05-24 10:57:06 --> Security Class Initialized
DEBUG - 2016-05-24 10:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:57:06 --> CSRF cookie sent
INFO - 2016-05-24 10:57:06 --> Input Class Initialized
INFO - 2016-05-24 10:57:06 --> Language Class Initialized
INFO - 2016-05-24 10:57:06 --> Loader Class Initialized
INFO - 2016-05-24 10:57:06 --> Helper loaded: form_helper
INFO - 2016-05-24 10:57:06 --> Database Driver Class Initialized
INFO - 2016-05-24 10:57:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:57:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:57:06 --> Email Class Initialized
INFO - 2016-05-24 10:57:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:57:06 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:57:06 --> Helper loaded: language_helper
INFO - 2016-05-24 10:57:06 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:57:06 --> Model Class Initialized
INFO - 2016-05-24 10:57:06 --> Helper loaded: date_helper
INFO - 2016-05-24 10:57:06 --> Controller Class Initialized
INFO - 2016-05-24 10:57:06 --> Migrations Class Initialized
INFO - 2016-05-24 10:57:06 --> Language file loaded: language/romanian/migration_lang.php
INFO - 2016-05-24 10:57:06 --> Database Forge Class Initialized
ERROR - 2016-05-24 10:57:07 --> Severity: Compile Error --> Cannot redeclare class Migration_Install_ion_auth /home/demis/www/platformadiabet/application/migrations/002_install_ion_auth.php 0
INFO - 2016-05-24 10:57:58 --> Config Class Initialized
INFO - 2016-05-24 10:57:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 10:57:58 --> UTF-8 Support Enabled
INFO - 2016-05-24 10:57:58 --> Utf8 Class Initialized
INFO - 2016-05-24 10:57:58 --> URI Class Initialized
INFO - 2016-05-24 10:57:58 --> Router Class Initialized
INFO - 2016-05-24 10:57:58 --> Output Class Initialized
INFO - 2016-05-24 10:57:58 --> Security Class Initialized
DEBUG - 2016-05-24 10:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 10:57:58 --> CSRF cookie sent
INFO - 2016-05-24 10:57:58 --> Input Class Initialized
INFO - 2016-05-24 10:57:58 --> Language Class Initialized
INFO - 2016-05-24 10:57:58 --> Loader Class Initialized
INFO - 2016-05-24 10:57:58 --> Helper loaded: form_helper
INFO - 2016-05-24 10:57:58 --> Database Driver Class Initialized
INFO - 2016-05-24 10:57:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 10:57:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 10:57:58 --> Email Class Initialized
INFO - 2016-05-24 10:57:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 10:57:58 --> Helper loaded: cookie_helper
INFO - 2016-05-24 10:57:58 --> Helper loaded: language_helper
INFO - 2016-05-24 10:57:58 --> Helper loaded: url_helper
DEBUG - 2016-05-24 10:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 10:57:58 --> Model Class Initialized
INFO - 2016-05-24 10:57:58 --> Helper loaded: date_helper
INFO - 2016-05-24 10:57:58 --> Controller Class Initialized
INFO - 2016-05-24 10:57:58 --> Migrations Class Initialized
INFO - 2016-05-24 10:57:58 --> Language file loaded: language/romanian/migration_lang.php
INFO - 2016-05-24 10:57:58 --> Database Forge Class Initialized
DEBUG - 2016-05-24 10:57:58 --> Migrating up from version 0 to version 001
ERROR - 2016-05-24 10:57:58 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails - Invalid query: DROP TABLE IF EXISTS `groups`
INFO - 2016-05-24 10:57:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 11:01:10 --> Config Class Initialized
INFO - 2016-05-24 11:01:10 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:01:10 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:01:10 --> Utf8 Class Initialized
INFO - 2016-05-24 11:01:10 --> URI Class Initialized
INFO - 2016-05-24 11:01:10 --> Router Class Initialized
INFO - 2016-05-24 11:01:10 --> Output Class Initialized
INFO - 2016-05-24 11:01:10 --> Security Class Initialized
DEBUG - 2016-05-24 11:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:01:10 --> CSRF cookie sent
INFO - 2016-05-24 11:01:10 --> Input Class Initialized
INFO - 2016-05-24 11:01:10 --> Language Class Initialized
INFO - 2016-05-24 11:01:10 --> Loader Class Initialized
INFO - 2016-05-24 11:01:10 --> Helper loaded: form_helper
INFO - 2016-05-24 11:01:10 --> Database Driver Class Initialized
INFO - 2016-05-24 11:01:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:01:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:01:10 --> Email Class Initialized
INFO - 2016-05-24 11:01:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:01:10 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:01:10 --> Helper loaded: language_helper
INFO - 2016-05-24 11:01:10 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:01:11 --> Model Class Initialized
INFO - 2016-05-24 11:01:11 --> Helper loaded: date_helper
INFO - 2016-05-24 11:01:11 --> Controller Class Initialized
INFO - 2016-05-24 11:01:11 --> Migrations Class Initialized
INFO - 2016-05-24 11:01:11 --> Language file loaded: language/romanian/migration_lang.php
INFO - 2016-05-24 11:01:11 --> Database Forge Class Initialized
DEBUG - 2016-05-24 11:01:11 --> Migrating up from version 0 to version 001
DEBUG - 2016-05-24 11:01:14 --> Migrating up from version 001 to version 002
ERROR - 2016-05-24 11:01:18 --> Query error: Invalid default value for '_create_date' - Invalid query: CREATE TABLE `tokens` (
	`token` VARCHAR(32) NOT NULL,
	`fk_user` INT(11) UNSIGNED NOT NULL,
	`name` VARCHAR(100) NOT NULL,
	`type` ENUM("doctor", "family") NOT NULL,
	`_is_active` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
	`_create_date` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	CONSTRAINT `pk_tokens` PRIMARY KEY(`token`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
INFO - 2016-05-24 11:01:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 11:06:40 --> Config Class Initialized
INFO - 2016-05-24 11:06:40 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:06:40 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:06:40 --> Utf8 Class Initialized
INFO - 2016-05-24 11:06:40 --> URI Class Initialized
INFO - 2016-05-24 11:06:40 --> Router Class Initialized
INFO - 2016-05-24 11:06:40 --> Output Class Initialized
INFO - 2016-05-24 11:06:40 --> Security Class Initialized
DEBUG - 2016-05-24 11:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:06:40 --> CSRF cookie sent
INFO - 2016-05-24 11:06:40 --> Input Class Initialized
INFO - 2016-05-24 11:06:40 --> Language Class Initialized
INFO - 2016-05-24 11:06:40 --> Loader Class Initialized
INFO - 2016-05-24 11:06:40 --> Helper loaded: form_helper
INFO - 2016-05-24 11:06:40 --> Database Driver Class Initialized
INFO - 2016-05-24 11:06:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:06:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:06:40 --> Email Class Initialized
INFO - 2016-05-24 11:06:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:06:40 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:06:40 --> Helper loaded: language_helper
INFO - 2016-05-24 11:06:40 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:06:40 --> Model Class Initialized
INFO - 2016-05-24 11:06:40 --> Helper loaded: date_helper
INFO - 2016-05-24 11:06:40 --> Controller Class Initialized
INFO - 2016-05-24 11:06:40 --> Migrations Class Initialized
INFO - 2016-05-24 11:06:40 --> Language file loaded: language/romanian/migration_lang.php
INFO - 2016-05-24 11:06:40 --> Database Forge Class Initialized
DEBUG - 2016-05-24 11:06:40 --> Migrating up from version 0 to version 001
DEBUG - 2016-05-24 11:06:45 --> Migrating up from version 001 to version 002
ERROR - 2016-05-24 11:06:48 --> Query error: Invalid default value for 'date' - Invalid query: CREATE TABLE `0_glicemie` (
	`fk_user` INT(11) UNSIGNED NOT NULL,
	`interval_1` VARCHAR(100) NOT NULL,
	`interval_2` VARCHAR(100) NOT NULL,
	`interval_3` VARCHAR(100) NOT NULL,
	`interval_4` VARCHAR(100) NOT NULL,
	`interval_5` VARCHAR(100) NOT NULL,
	`interval_6` VARCHAR(100) NOT NULL,
	`interval_7` VARCHAR(100) NOT NULL,
	`interval_8` VARCHAR(100) NOT NULL,
	`interval_9` VARCHAR(100) NOT NULL,
	`interval_10` VARCHAR(100) NOT NULL,
	`notes` VARCHAR(255) NOT NULL,
	`date` TIMESTAMP NOT NULL DEFAULT 'CURRENT_TIMESTAMP'
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
INFO - 2016-05-24 11:06:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 11:07:52 --> Config Class Initialized
INFO - 2016-05-24 11:07:52 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:07:52 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:07:52 --> Utf8 Class Initialized
INFO - 2016-05-24 11:07:52 --> URI Class Initialized
INFO - 2016-05-24 11:07:52 --> Router Class Initialized
INFO - 2016-05-24 11:07:52 --> Output Class Initialized
INFO - 2016-05-24 11:07:52 --> Security Class Initialized
DEBUG - 2016-05-24 11:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:07:52 --> CSRF cookie sent
INFO - 2016-05-24 11:07:52 --> Input Class Initialized
INFO - 2016-05-24 11:07:52 --> Language Class Initialized
INFO - 2016-05-24 11:07:52 --> Loader Class Initialized
INFO - 2016-05-24 11:07:52 --> Helper loaded: form_helper
INFO - 2016-05-24 11:07:52 --> Database Driver Class Initialized
INFO - 2016-05-24 11:07:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:07:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:07:52 --> Email Class Initialized
INFO - 2016-05-24 11:07:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:07:52 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:07:52 --> Helper loaded: language_helper
INFO - 2016-05-24 11:07:52 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:07:52 --> Model Class Initialized
INFO - 2016-05-24 11:07:52 --> Helper loaded: date_helper
INFO - 2016-05-24 11:07:52 --> Controller Class Initialized
INFO - 2016-05-24 11:07:52 --> Migrations Class Initialized
INFO - 2016-05-24 11:07:52 --> Language file loaded: language/romanian/migration_lang.php
INFO - 2016-05-24 11:07:52 --> Database Forge Class Initialized
DEBUG - 2016-05-24 11:07:53 --> Migrating up from version 0 to version 001
DEBUG - 2016-05-24 11:07:56 --> Migrating up from version 001 to version 002
DEBUG - 2016-05-24 11:08:00 --> Finished migrating to 002
INFO - 2016-05-24 11:08:00 --> Final output sent to browser
DEBUG - 2016-05-24 11:08:00 --> Total execution time: 7.8901
INFO - 2016-05-24 11:34:22 --> Config Class Initialized
INFO - 2016-05-24 11:34:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:34:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:34:22 --> Utf8 Class Initialized
INFO - 2016-05-24 11:34:22 --> URI Class Initialized
DEBUG - 2016-05-24 11:34:22 --> No URI present. Default controller set.
INFO - 2016-05-24 11:34:22 --> Router Class Initialized
INFO - 2016-05-24 11:34:22 --> Output Class Initialized
INFO - 2016-05-24 11:34:22 --> Security Class Initialized
DEBUG - 2016-05-24 11:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:34:22 --> CSRF cookie sent
INFO - 2016-05-24 11:34:22 --> Input Class Initialized
INFO - 2016-05-24 11:34:22 --> Language Class Initialized
INFO - 2016-05-24 11:34:22 --> Loader Class Initialized
INFO - 2016-05-24 11:34:22 --> Helper loaded: form_helper
INFO - 2016-05-24 11:34:22 --> Database Driver Class Initialized
INFO - 2016-05-24 11:34:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:34:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:34:22 --> Email Class Initialized
INFO - 2016-05-24 11:34:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:34:22 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:34:22 --> Helper loaded: language_helper
INFO - 2016-05-24 11:34:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:34:22 --> Model Class Initialized
INFO - 2016-05-24 11:34:22 --> Helper loaded: date_helper
INFO - 2016-05-24 11:34:22 --> Controller Class Initialized
INFO - 2016-05-24 11:34:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:34:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:34:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:34:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:34:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:34:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 11:34:22 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:34:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:34:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-24 11:34:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:34:22 --> Final output sent to browser
DEBUG - 2016-05-24 11:34:22 --> Total execution time: 0.1620
INFO - 2016-05-24 11:37:21 --> Config Class Initialized
INFO - 2016-05-24 11:37:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:37:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:37:21 --> Utf8 Class Initialized
INFO - 2016-05-24 11:37:21 --> URI Class Initialized
DEBUG - 2016-05-24 11:37:21 --> No URI present. Default controller set.
INFO - 2016-05-24 11:37:21 --> Router Class Initialized
INFO - 2016-05-24 11:37:21 --> Output Class Initialized
INFO - 2016-05-24 11:37:21 --> Security Class Initialized
DEBUG - 2016-05-24 11:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:37:21 --> CSRF cookie sent
INFO - 2016-05-24 11:37:21 --> Input Class Initialized
INFO - 2016-05-24 11:37:21 --> Language Class Initialized
INFO - 2016-05-24 11:37:21 --> Loader Class Initialized
INFO - 2016-05-24 11:37:21 --> Helper loaded: form_helper
INFO - 2016-05-24 11:37:21 --> Database Driver Class Initialized
INFO - 2016-05-24 11:37:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:37:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:37:22 --> Email Class Initialized
INFO - 2016-05-24 11:37:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:37:22 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:37:22 --> Helper loaded: language_helper
INFO - 2016-05-24 11:37:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:37:22 --> Model Class Initialized
INFO - 2016-05-24 11:37:22 --> Helper loaded: date_helper
INFO - 2016-05-24 11:37:22 --> Controller Class Initialized
INFO - 2016-05-24 11:37:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:37:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:37:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:37:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:37:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:37:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 11:37:22 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-24 11:37:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:37:22 --> Final output sent to browser
DEBUG - 2016-05-24 11:37:22 --> Total execution time: 0.0583
INFO - 2016-05-24 11:46:08 --> Config Class Initialized
INFO - 2016-05-24 11:46:08 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:46:08 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:46:08 --> Utf8 Class Initialized
INFO - 2016-05-24 11:46:08 --> URI Class Initialized
INFO - 2016-05-24 11:46:08 --> Router Class Initialized
INFO - 2016-05-24 11:46:08 --> Output Class Initialized
INFO - 2016-05-24 11:46:08 --> Security Class Initialized
DEBUG - 2016-05-24 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:46:08 --> CSRF cookie sent
INFO - 2016-05-24 11:46:08 --> Input Class Initialized
INFO - 2016-05-24 11:46:08 --> Language Class Initialized
INFO - 2016-05-24 11:46:08 --> Loader Class Initialized
INFO - 2016-05-24 11:46:08 --> Helper loaded: form_helper
INFO - 2016-05-24 11:46:08 --> Database Driver Class Initialized
INFO - 2016-05-24 11:46:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:46:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:46:08 --> Email Class Initialized
INFO - 2016-05-24 11:46:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:46:08 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:46:08 --> Helper loaded: language_helper
INFO - 2016-05-24 11:46:08 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:46:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:08 --> Model Class Initialized
INFO - 2016-05-24 11:46:08 --> Helper loaded: date_helper
INFO - 2016-05-24 11:46:08 --> Controller Class Initialized
INFO - 2016-05-24 11:46:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:46:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:46:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:46:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:46:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:46:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:46:08 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:08 --> Form Validation Class Initialized
INFO - 2016-05-24 11:46:08 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:46:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:46:08 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 11:46:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:46:08 --> Final output sent to browser
DEBUG - 2016-05-24 11:46:08 --> Total execution time: 0.0792
INFO - 2016-05-24 11:46:13 --> Config Class Initialized
INFO - 2016-05-24 11:46:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:46:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:46:13 --> Utf8 Class Initialized
INFO - 2016-05-24 11:46:13 --> URI Class Initialized
INFO - 2016-05-24 11:46:13 --> Router Class Initialized
INFO - 2016-05-24 11:46:13 --> Output Class Initialized
INFO - 2016-05-24 11:46:13 --> Security Class Initialized
DEBUG - 2016-05-24 11:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:46:13 --> CSRF cookie sent
INFO - 2016-05-24 11:46:13 --> CSRF token verified
INFO - 2016-05-24 11:46:13 --> Input Class Initialized
INFO - 2016-05-24 11:46:13 --> Language Class Initialized
INFO - 2016-05-24 11:46:13 --> Loader Class Initialized
INFO - 2016-05-24 11:46:13 --> Helper loaded: form_helper
INFO - 2016-05-24 11:46:13 --> Database Driver Class Initialized
INFO - 2016-05-24 11:46:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:46:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:46:13 --> Email Class Initialized
INFO - 2016-05-24 11:46:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:46:13 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:46:13 --> Helper loaded: language_helper
INFO - 2016-05-24 11:46:13 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:13 --> Model Class Initialized
INFO - 2016-05-24 11:46:13 --> Helper loaded: date_helper
INFO - 2016-05-24 11:46:13 --> Controller Class Initialized
INFO - 2016-05-24 11:46:13 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:46:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:46:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:46:13 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:46:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:46:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:46:13 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:13 --> Form Validation Class Initialized
INFO - 2016-05-24 11:46:14 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:46:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:46:14 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 11:46:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:46:14 --> Final output sent to browser
DEBUG - 2016-05-24 11:46:14 --> Total execution time: 0.5664
INFO - 2016-05-24 11:46:30 --> Config Class Initialized
INFO - 2016-05-24 11:46:30 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:46:30 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:46:30 --> Utf8 Class Initialized
INFO - 2016-05-24 11:46:30 --> URI Class Initialized
INFO - 2016-05-24 11:46:30 --> Router Class Initialized
INFO - 2016-05-24 11:46:30 --> Output Class Initialized
INFO - 2016-05-24 11:46:30 --> Security Class Initialized
DEBUG - 2016-05-24 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:46:30 --> CSRF cookie sent
INFO - 2016-05-24 11:46:30 --> CSRF token verified
INFO - 2016-05-24 11:46:30 --> Input Class Initialized
INFO - 2016-05-24 11:46:30 --> Language Class Initialized
INFO - 2016-05-24 11:46:30 --> Loader Class Initialized
INFO - 2016-05-24 11:46:30 --> Helper loaded: form_helper
INFO - 2016-05-24 11:46:30 --> Database Driver Class Initialized
INFO - 2016-05-24 11:46:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:46:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:46:30 --> Email Class Initialized
INFO - 2016-05-24 11:46:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:46:30 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:46:30 --> Helper loaded: language_helper
INFO - 2016-05-24 11:46:30 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:30 --> Model Class Initialized
INFO - 2016-05-24 11:46:30 --> Helper loaded: date_helper
INFO - 2016-05-24 11:46:30 --> Controller Class Initialized
INFO - 2016-05-24 11:46:30 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:46:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:46:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:46:30 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:46:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:46:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:46:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:30 --> Form Validation Class Initialized
INFO - 2016-05-24 11:46:31 --> Config Class Initialized
INFO - 2016-05-24 11:46:31 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:46:31 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:46:31 --> Utf8 Class Initialized
INFO - 2016-05-24 11:46:31 --> URI Class Initialized
INFO - 2016-05-24 11:46:31 --> Router Class Initialized
INFO - 2016-05-24 11:46:31 --> Output Class Initialized
INFO - 2016-05-24 11:46:31 --> Security Class Initialized
DEBUG - 2016-05-24 11:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:46:31 --> CSRF cookie sent
INFO - 2016-05-24 11:46:31 --> Input Class Initialized
INFO - 2016-05-24 11:46:31 --> Language Class Initialized
INFO - 2016-05-24 11:46:31 --> Loader Class Initialized
INFO - 2016-05-24 11:46:31 --> Helper loaded: form_helper
INFO - 2016-05-24 11:46:31 --> Database Driver Class Initialized
INFO - 2016-05-24 11:46:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:46:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:46:31 --> Email Class Initialized
INFO - 2016-05-24 11:46:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:46:31 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:46:31 --> Helper loaded: language_helper
INFO - 2016-05-24 11:46:31 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:46:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:31 --> Model Class Initialized
INFO - 2016-05-24 11:46:31 --> Helper loaded: date_helper
INFO - 2016-05-24 11:46:31 --> Controller Class Initialized
INFO - 2016-05-24 11:46:31 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:46:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:46:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:46:31 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:46:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:46:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:46:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:31 --> Form Validation Class Initialized
INFO - 2016-05-24 11:46:31 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 11:46:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:46:31 --> Final output sent to browser
DEBUG - 2016-05-24 11:46:31 --> Total execution time: 0.0420
INFO - 2016-05-24 11:46:43 --> Config Class Initialized
INFO - 2016-05-24 11:46:43 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:46:43 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:46:43 --> Utf8 Class Initialized
INFO - 2016-05-24 11:46:43 --> URI Class Initialized
INFO - 2016-05-24 11:46:43 --> Router Class Initialized
INFO - 2016-05-24 11:46:43 --> Output Class Initialized
INFO - 2016-05-24 11:46:43 --> Security Class Initialized
DEBUG - 2016-05-24 11:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:46:43 --> CSRF cookie sent
INFO - 2016-05-24 11:46:43 --> Input Class Initialized
INFO - 2016-05-24 11:46:43 --> Language Class Initialized
INFO - 2016-05-24 11:46:43 --> Loader Class Initialized
INFO - 2016-05-24 11:46:43 --> Helper loaded: form_helper
INFO - 2016-05-24 11:46:43 --> Database Driver Class Initialized
INFO - 2016-05-24 11:46:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:46:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:46:43 --> Email Class Initialized
INFO - 2016-05-24 11:46:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:46:43 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:46:43 --> Helper loaded: language_helper
INFO - 2016-05-24 11:46:43 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:43 --> Model Class Initialized
INFO - 2016-05-24 11:46:43 --> Helper loaded: date_helper
INFO - 2016-05-24 11:46:43 --> Controller Class Initialized
INFO - 2016-05-24 11:46:43 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:46:43 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:46:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:46:43 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:46:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:46:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:46:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:46:43 --> Form Validation Class Initialized
INFO - 2016-05-24 11:46:43 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:46:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:46:43 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-05-24 11:46:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:46:43 --> Final output sent to browser
DEBUG - 2016-05-24 11:46:43 --> Total execution time: 0.1328
INFO - 2016-05-24 11:47:01 --> Config Class Initialized
INFO - 2016-05-24 11:47:01 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:47:01 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:47:01 --> Utf8 Class Initialized
INFO - 2016-05-24 11:47:01 --> URI Class Initialized
INFO - 2016-05-24 11:47:01 --> Router Class Initialized
INFO - 2016-05-24 11:47:01 --> Output Class Initialized
INFO - 2016-05-24 11:47:01 --> Security Class Initialized
DEBUG - 2016-05-24 11:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:47:01 --> CSRF cookie sent
INFO - 2016-05-24 11:47:01 --> CSRF token verified
INFO - 2016-05-24 11:47:01 --> Input Class Initialized
INFO - 2016-05-24 11:47:01 --> Language Class Initialized
INFO - 2016-05-24 11:47:01 --> Loader Class Initialized
INFO - 2016-05-24 11:47:01 --> Helper loaded: form_helper
INFO - 2016-05-24 11:47:01 --> Database Driver Class Initialized
INFO - 2016-05-24 11:47:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:47:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:47:01 --> Email Class Initialized
INFO - 2016-05-24 11:47:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:47:01 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:47:01 --> Helper loaded: language_helper
INFO - 2016-05-24 11:47:01 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:01 --> Model Class Initialized
INFO - 2016-05-24 11:47:01 --> Helper loaded: date_helper
INFO - 2016-05-24 11:47:01 --> Controller Class Initialized
INFO - 2016-05-24 11:47:01 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:47:01 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:47:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:47:01 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:47:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:47:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:47:01 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:01 --> Form Validation Class Initialized
INFO - 2016-05-24 11:47:02 --> Config Class Initialized
INFO - 2016-05-24 11:47:02 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:47:02 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:47:02 --> Utf8 Class Initialized
INFO - 2016-05-24 11:47:02 --> URI Class Initialized
INFO - 2016-05-24 11:47:02 --> Router Class Initialized
INFO - 2016-05-24 11:47:02 --> Output Class Initialized
INFO - 2016-05-24 11:47:02 --> Security Class Initialized
DEBUG - 2016-05-24 11:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:47:02 --> CSRF cookie sent
INFO - 2016-05-24 11:47:02 --> Input Class Initialized
INFO - 2016-05-24 11:47:02 --> Language Class Initialized
INFO - 2016-05-24 11:47:02 --> Loader Class Initialized
INFO - 2016-05-24 11:47:02 --> Helper loaded: form_helper
INFO - 2016-05-24 11:47:02 --> Database Driver Class Initialized
INFO - 2016-05-24 11:47:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:47:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:47:02 --> Email Class Initialized
INFO - 2016-05-24 11:47:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:47:02 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:47:02 --> Helper loaded: language_helper
INFO - 2016-05-24 11:47:02 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:47:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:02 --> Model Class Initialized
INFO - 2016-05-24 11:47:02 --> Helper loaded: date_helper
INFO - 2016-05-24 11:47:02 --> Controller Class Initialized
INFO - 2016-05-24 11:47:02 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:47:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:47:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:47:02 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:47:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:47:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:47:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:02 --> Form Validation Class Initialized
INFO - 2016-05-24 11:47:02 --> Config Class Initialized
INFO - 2016-05-24 11:47:02 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:47:02 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:47:02 --> Utf8 Class Initialized
INFO - 2016-05-24 11:47:02 --> URI Class Initialized
INFO - 2016-05-24 11:47:02 --> Router Class Initialized
INFO - 2016-05-24 11:47:02 --> Output Class Initialized
INFO - 2016-05-24 11:47:02 --> Security Class Initialized
DEBUG - 2016-05-24 11:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:47:02 --> CSRF cookie sent
INFO - 2016-05-24 11:47:02 --> Input Class Initialized
INFO - 2016-05-24 11:47:02 --> Language Class Initialized
INFO - 2016-05-24 11:47:02 --> Loader Class Initialized
INFO - 2016-05-24 11:47:02 --> Helper loaded: form_helper
INFO - 2016-05-24 11:47:02 --> Database Driver Class Initialized
INFO - 2016-05-24 11:47:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:47:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:47:03 --> Email Class Initialized
INFO - 2016-05-24 11:47:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:47:03 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:47:03 --> Helper loaded: language_helper
INFO - 2016-05-24 11:47:03 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:03 --> Model Class Initialized
INFO - 2016-05-24 11:47:03 --> Helper loaded: date_helper
INFO - 2016-05-24 11:47:03 --> Controller Class Initialized
INFO - 2016-05-24 11:47:03 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:47:03 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:47:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:47:03 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:47:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:47:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:47:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:03 --> Form Validation Class Initialized
INFO - 2016-05-24 11:47:03 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:47:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:47:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 11:47:03 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:47:03 --> Final output sent to browser
DEBUG - 2016-05-24 11:47:03 --> Total execution time: 0.2178
INFO - 2016-05-24 11:47:30 --> Config Class Initialized
INFO - 2016-05-24 11:47:30 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:47:30 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:47:30 --> Utf8 Class Initialized
INFO - 2016-05-24 11:47:30 --> URI Class Initialized
INFO - 2016-05-24 11:47:30 --> Router Class Initialized
INFO - 2016-05-24 11:47:30 --> Output Class Initialized
INFO - 2016-05-24 11:47:30 --> Security Class Initialized
DEBUG - 2016-05-24 11:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:47:30 --> CSRF cookie sent
INFO - 2016-05-24 11:47:30 --> CSRF token verified
INFO - 2016-05-24 11:47:30 --> Input Class Initialized
INFO - 2016-05-24 11:47:30 --> Language Class Initialized
INFO - 2016-05-24 11:47:30 --> Loader Class Initialized
INFO - 2016-05-24 11:47:30 --> Helper loaded: form_helper
INFO - 2016-05-24 11:47:30 --> Database Driver Class Initialized
INFO - 2016-05-24 11:47:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:47:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:47:30 --> Email Class Initialized
INFO - 2016-05-24 11:47:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:47:30 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:47:30 --> Helper loaded: language_helper
INFO - 2016-05-24 11:47:30 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:30 --> Model Class Initialized
INFO - 2016-05-24 11:47:30 --> Helper loaded: date_helper
INFO - 2016-05-24 11:47:30 --> Controller Class Initialized
INFO - 2016-05-24 11:47:30 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:47:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:47:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:47:30 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:47:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:47:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 11:47:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:30 --> Form Validation Class Initialized
INFO - 2016-05-24 11:47:31 --> Config Class Initialized
INFO - 2016-05-24 11:47:31 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:47:31 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:47:31 --> Utf8 Class Initialized
INFO - 2016-05-24 11:47:31 --> URI Class Initialized
DEBUG - 2016-05-24 11:47:31 --> No URI present. Default controller set.
INFO - 2016-05-24 11:47:31 --> Router Class Initialized
INFO - 2016-05-24 11:47:31 --> Output Class Initialized
INFO - 2016-05-24 11:47:31 --> Security Class Initialized
DEBUG - 2016-05-24 11:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:47:31 --> CSRF cookie sent
INFO - 2016-05-24 11:47:31 --> Input Class Initialized
INFO - 2016-05-24 11:47:31 --> Language Class Initialized
INFO - 2016-05-24 11:47:31 --> Loader Class Initialized
INFO - 2016-05-24 11:47:31 --> Helper loaded: form_helper
INFO - 2016-05-24 11:47:31 --> Database Driver Class Initialized
INFO - 2016-05-24 11:47:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:47:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:47:31 --> Email Class Initialized
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:47:31 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:47:31 --> Helper loaded: language_helper
INFO - 2016-05-24 11:47:31 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:31 --> Model Class Initialized
INFO - 2016-05-24 11:47:31 --> Helper loaded: date_helper
INFO - 2016-05-24 11:47:31 --> Controller Class Initialized
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 11:47:31 --> Config Class Initialized
INFO - 2016-05-24 11:47:31 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:47:31 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:47:31 --> Utf8 Class Initialized
INFO - 2016-05-24 11:47:31 --> URI Class Initialized
INFO - 2016-05-24 11:47:31 --> Router Class Initialized
INFO - 2016-05-24 11:47:31 --> Output Class Initialized
INFO - 2016-05-24 11:47:31 --> Security Class Initialized
DEBUG - 2016-05-24 11:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:47:31 --> CSRF cookie sent
INFO - 2016-05-24 11:47:31 --> Input Class Initialized
INFO - 2016-05-24 11:47:31 --> Language Class Initialized
INFO - 2016-05-24 11:47:31 --> Loader Class Initialized
INFO - 2016-05-24 11:47:31 --> Helper loaded: form_helper
INFO - 2016-05-24 11:47:31 --> Database Driver Class Initialized
INFO - 2016-05-24 11:47:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:47:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:47:31 --> Email Class Initialized
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:47:31 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:47:31 --> Helper loaded: language_helper
INFO - 2016-05-24 11:47:31 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:47:31 --> Model Class Initialized
INFO - 2016-05-24 11:47:31 --> Helper loaded: date_helper
INFO - 2016-05-24 11:47:31 --> Controller Class Initialized
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 11:47:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 11:47:31 --> Model Class Initialized
INFO - 2016-05-24 11:47:31 --> Helper loaded: languages_helper
INFO - 2016-05-24 11:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 11:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 11:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 11:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 11:47:31 --> Final output sent to browser
DEBUG - 2016-05-24 11:47:31 --> Total execution time: 0.2173
INFO - 2016-05-24 11:48:38 --> Config Class Initialized
INFO - 2016-05-24 11:48:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 11:48:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 11:48:38 --> Utf8 Class Initialized
INFO - 2016-05-24 11:48:38 --> URI Class Initialized
DEBUG - 2016-05-24 11:48:38 --> No URI present. Default controller set.
INFO - 2016-05-24 11:48:38 --> Router Class Initialized
INFO - 2016-05-24 11:48:38 --> Output Class Initialized
INFO - 2016-05-24 11:48:38 --> Security Class Initialized
DEBUG - 2016-05-24 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 11:48:38 --> CSRF cookie sent
INFO - 2016-05-24 11:48:38 --> Input Class Initialized
INFO - 2016-05-24 11:48:38 --> Language Class Initialized
INFO - 2016-05-24 11:48:38 --> Loader Class Initialized
INFO - 2016-05-24 11:48:38 --> Helper loaded: form_helper
INFO - 2016-05-24 11:48:38 --> Database Driver Class Initialized
INFO - 2016-05-24 11:48:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 11:48:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 11:48:38 --> Email Class Initialized
INFO - 2016-05-24 11:48:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 11:48:38 --> Helper loaded: cookie_helper
INFO - 2016-05-24 11:48:38 --> Helper loaded: language_helper
INFO - 2016-05-24 11:48:38 --> Helper loaded: url_helper
DEBUG - 2016-05-24 11:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 11:48:38 --> Model Class Initialized
INFO - 2016-05-24 11:48:38 --> Helper loaded: date_helper
INFO - 2016-05-24 11:48:38 --> Controller Class Initialized
INFO - 2016-05-24 11:48:38 --> Helper loaded: languages_helper
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "terms_conditions"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "terms_conditions"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "terms_description"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "close_btn"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "how_it_works"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "how_it_works"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "terms_description"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "close_btn"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "login_heading"
ERROR - 2016-05-24 11:48:38 --> Could not find the language line "create_user_heading"
INFO - 2016-05-24 11:48:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 11:48:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-24 11:48:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 11:48:38 --> Final output sent to browser
DEBUG - 2016-05-24 11:48:38 --> Total execution time: 0.1085
INFO - 2016-05-24 12:55:56 --> Config Class Initialized
INFO - 2016-05-24 12:55:56 --> Hooks Class Initialized
DEBUG - 2016-05-24 12:55:56 --> UTF-8 Support Enabled
INFO - 2016-05-24 12:55:56 --> Utf8 Class Initialized
INFO - 2016-05-24 12:55:56 --> URI Class Initialized
INFO - 2016-05-24 12:55:56 --> Router Class Initialized
INFO - 2016-05-24 12:55:56 --> Output Class Initialized
INFO - 2016-05-24 12:55:56 --> Security Class Initialized
DEBUG - 2016-05-24 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 12:55:56 --> CSRF cookie sent
INFO - 2016-05-24 12:55:56 --> Input Class Initialized
INFO - 2016-05-24 12:55:56 --> Language Class Initialized
INFO - 2016-05-24 12:55:56 --> Loader Class Initialized
INFO - 2016-05-24 12:55:56 --> Helper loaded: form_helper
INFO - 2016-05-24 12:55:56 --> Database Driver Class Initialized
INFO - 2016-05-24 12:55:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 12:55:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 12:55:56 --> Email Class Initialized
INFO - 2016-05-24 12:55:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 12:55:56 --> Helper loaded: cookie_helper
INFO - 2016-05-24 12:55:56 --> Helper loaded: language_helper
INFO - 2016-05-24 12:55:56 --> Helper loaded: url_helper
DEBUG - 2016-05-24 12:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 12:55:56 --> Model Class Initialized
INFO - 2016-05-24 12:55:56 --> Helper loaded: date_helper
INFO - 2016-05-24 12:55:56 --> Controller Class Initialized
INFO - 2016-05-24 12:55:56 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 12:55:56 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 12:55:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 12:55:56 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 12:55:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 12:55:56 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 12:55:56 --> Model Class Initialized
INFO - 2016-05-24 12:55:56 --> Helper loaded: languages_helper
INFO - 2016-05-24 12:55:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 12:55:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 12:55:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 12:55:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 12:55:56 --> Final output sent to browser
DEBUG - 2016-05-24 12:55:56 --> Total execution time: 0.0635
INFO - 2016-05-24 12:58:00 --> Config Class Initialized
INFO - 2016-05-24 12:58:00 --> Hooks Class Initialized
DEBUG - 2016-05-24 12:58:00 --> UTF-8 Support Enabled
INFO - 2016-05-24 12:58:00 --> Utf8 Class Initialized
INFO - 2016-05-24 12:58:00 --> URI Class Initialized
INFO - 2016-05-24 12:58:00 --> Router Class Initialized
INFO - 2016-05-24 12:58:00 --> Output Class Initialized
INFO - 2016-05-24 12:58:00 --> Security Class Initialized
DEBUG - 2016-05-24 12:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 12:58:00 --> CSRF cookie sent
INFO - 2016-05-24 12:58:00 --> Input Class Initialized
INFO - 2016-05-24 12:58:00 --> Language Class Initialized
INFO - 2016-05-24 12:58:00 --> Loader Class Initialized
INFO - 2016-05-24 12:58:00 --> Helper loaded: form_helper
INFO - 2016-05-24 12:58:00 --> Database Driver Class Initialized
INFO - 2016-05-24 12:58:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 12:58:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 12:58:00 --> Email Class Initialized
INFO - 2016-05-24 12:58:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 12:58:00 --> Helper loaded: cookie_helper
INFO - 2016-05-24 12:58:00 --> Helper loaded: language_helper
INFO - 2016-05-24 12:58:00 --> Helper loaded: url_helper
DEBUG - 2016-05-24 12:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 12:58:00 --> Model Class Initialized
INFO - 2016-05-24 12:58:00 --> Helper loaded: date_helper
INFO - 2016-05-24 12:58:00 --> Controller Class Initialized
INFO - 2016-05-24 12:58:00 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 12:58:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 12:58:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 12:58:00 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 12:58:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 12:58:00 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 12:58:00 --> Model Class Initialized
INFO - 2016-05-24 12:58:00 --> Helper loaded: languages_helper
INFO - 2016-05-24 12:58:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 12:58:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 12:58:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 12:58:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 12:58:00 --> Final output sent to browser
DEBUG - 2016-05-24 12:58:00 --> Total execution time: 0.0561
INFO - 2016-05-24 13:06:14 --> Config Class Initialized
INFO - 2016-05-24 13:06:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:06:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:06:14 --> Utf8 Class Initialized
INFO - 2016-05-24 13:06:14 --> URI Class Initialized
INFO - 2016-05-24 13:06:14 --> Router Class Initialized
INFO - 2016-05-24 13:06:14 --> Output Class Initialized
INFO - 2016-05-24 13:06:14 --> Security Class Initialized
DEBUG - 2016-05-24 13:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:06:14 --> CSRF cookie sent
INFO - 2016-05-24 13:06:14 --> Input Class Initialized
INFO - 2016-05-24 13:06:14 --> Language Class Initialized
INFO - 2016-05-24 13:06:14 --> Loader Class Initialized
INFO - 2016-05-24 13:06:14 --> Helper loaded: form_helper
INFO - 2016-05-24 13:06:14 --> Database Driver Class Initialized
INFO - 2016-05-24 13:06:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:06:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:06:14 --> Email Class Initialized
INFO - 2016-05-24 13:06:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:06:14 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:06:14 --> Helper loaded: language_helper
INFO - 2016-05-24 13:06:14 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:06:14 --> Model Class Initialized
INFO - 2016-05-24 13:06:14 --> Helper loaded: date_helper
INFO - 2016-05-24 13:06:14 --> Controller Class Initialized
INFO - 2016-05-24 13:06:14 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:06:14 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:06:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:06:14 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:06:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:06:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 13:06:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:06:14 --> Form Validation Class Initialized
INFO - 2016-05-24 13:06:15 --> Config Class Initialized
INFO - 2016-05-24 13:06:15 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:06:15 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:06:15 --> Utf8 Class Initialized
INFO - 2016-05-24 13:06:15 --> URI Class Initialized
INFO - 2016-05-24 13:06:15 --> Router Class Initialized
INFO - 2016-05-24 13:06:15 --> Output Class Initialized
INFO - 2016-05-24 13:06:15 --> Security Class Initialized
DEBUG - 2016-05-24 13:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:06:15 --> CSRF cookie sent
INFO - 2016-05-24 13:06:15 --> Input Class Initialized
INFO - 2016-05-24 13:06:15 --> Language Class Initialized
INFO - 2016-05-24 13:06:15 --> Loader Class Initialized
INFO - 2016-05-24 13:06:15 --> Helper loaded: form_helper
INFO - 2016-05-24 13:06:15 --> Database Driver Class Initialized
INFO - 2016-05-24 13:06:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:06:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:06:15 --> Email Class Initialized
INFO - 2016-05-24 13:06:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:06:15 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:06:15 --> Helper loaded: language_helper
INFO - 2016-05-24 13:06:15 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:06:15 --> Model Class Initialized
INFO - 2016-05-24 13:06:15 --> Helper loaded: date_helper
INFO - 2016-05-24 13:06:15 --> Controller Class Initialized
INFO - 2016-05-24 13:06:15 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:06:15 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:06:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:06:15 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:06:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:06:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 13:06:15 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:06:15 --> Form Validation Class Initialized
INFO - 2016-05-24 13:06:15 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:06:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 13:06:15 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 13:06:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 13:06:15 --> Final output sent to browser
DEBUG - 2016-05-24 13:06:15 --> Total execution time: 0.0590
INFO - 2016-05-24 13:06:44 --> Config Class Initialized
INFO - 2016-05-24 13:06:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:06:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:06:44 --> Utf8 Class Initialized
INFO - 2016-05-24 13:06:44 --> URI Class Initialized
INFO - 2016-05-24 13:06:44 --> Router Class Initialized
INFO - 2016-05-24 13:06:44 --> Output Class Initialized
INFO - 2016-05-24 13:06:44 --> Security Class Initialized
DEBUG - 2016-05-24 13:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:06:44 --> CSRF cookie sent
INFO - 2016-05-24 13:06:44 --> CSRF token verified
INFO - 2016-05-24 13:06:44 --> Input Class Initialized
INFO - 2016-05-24 13:06:44 --> Language Class Initialized
INFO - 2016-05-24 13:06:44 --> Loader Class Initialized
INFO - 2016-05-24 13:06:44 --> Helper loaded: form_helper
INFO - 2016-05-24 13:06:44 --> Database Driver Class Initialized
INFO - 2016-05-24 13:06:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:06:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:06:44 --> Email Class Initialized
INFO - 2016-05-24 13:06:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:06:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:06:44 --> Helper loaded: language_helper
INFO - 2016-05-24 13:06:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:06:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:06:44 --> Model Class Initialized
INFO - 2016-05-24 13:06:44 --> Helper loaded: date_helper
INFO - 2016-05-24 13:06:44 --> Controller Class Initialized
INFO - 2016-05-24 13:06:44 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:06:44 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:06:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:06:44 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:06:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:06:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 13:06:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:06:44 --> Form Validation Class Initialized
INFO - 2016-05-24 13:06:44 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:06:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 13:06:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 13:06:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 13:06:44 --> Final output sent to browser
DEBUG - 2016-05-24 13:06:44 --> Total execution time: 0.4332
INFO - 2016-05-24 13:13:33 --> Config Class Initialized
INFO - 2016-05-24 13:13:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:13:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:13:33 --> Utf8 Class Initialized
INFO - 2016-05-24 13:13:33 --> URI Class Initialized
INFO - 2016-05-24 13:13:33 --> Router Class Initialized
INFO - 2016-05-24 13:13:33 --> Output Class Initialized
INFO - 2016-05-24 13:13:33 --> Security Class Initialized
DEBUG - 2016-05-24 13:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:13:33 --> CSRF cookie sent
INFO - 2016-05-24 13:13:33 --> Input Class Initialized
INFO - 2016-05-24 13:13:33 --> Language Class Initialized
INFO - 2016-05-24 13:13:33 --> Loader Class Initialized
INFO - 2016-05-24 13:13:33 --> Helper loaded: form_helper
INFO - 2016-05-24 13:13:33 --> Database Driver Class Initialized
INFO - 2016-05-24 13:13:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:13:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:13:33 --> Email Class Initialized
INFO - 2016-05-24 13:13:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:13:33 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:13:33 --> Helper loaded: language_helper
INFO - 2016-05-24 13:13:33 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:13:33 --> Model Class Initialized
INFO - 2016-05-24 13:13:33 --> Helper loaded: date_helper
INFO - 2016-05-24 13:13:33 --> Controller Class Initialized
INFO - 2016-05-24 13:13:33 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:13:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:13:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:13:33 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:13:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:13:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 13:13:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:13:33 --> Form Validation Class Initialized
INFO - 2016-05-24 13:13:33 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:13:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 13:13:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-05-24 13:13:33 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 13:13:33 --> Final output sent to browser
DEBUG - 2016-05-24 13:13:33 --> Total execution time: 0.0651
INFO - 2016-05-24 13:23:35 --> Config Class Initialized
INFO - 2016-05-24 13:23:35 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:23:35 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:23:35 --> Utf8 Class Initialized
INFO - 2016-05-24 13:23:35 --> URI Class Initialized
INFO - 2016-05-24 13:23:35 --> Router Class Initialized
INFO - 2016-05-24 13:23:35 --> Output Class Initialized
INFO - 2016-05-24 13:23:35 --> Security Class Initialized
DEBUG - 2016-05-24 13:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:23:35 --> CSRF cookie sent
INFO - 2016-05-24 13:23:35 --> Input Class Initialized
INFO - 2016-05-24 13:23:35 --> Language Class Initialized
INFO - 2016-05-24 13:23:35 --> Loader Class Initialized
INFO - 2016-05-24 13:23:35 --> Helper loaded: form_helper
INFO - 2016-05-24 13:23:35 --> Database Driver Class Initialized
INFO - 2016-05-24 13:23:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:23:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:23:35 --> Email Class Initialized
INFO - 2016-05-24 13:23:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:23:35 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:23:35 --> Helper loaded: language_helper
INFO - 2016-05-24 13:23:35 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:23:35 --> Model Class Initialized
INFO - 2016-05-24 13:23:35 --> Helper loaded: date_helper
INFO - 2016-05-24 13:23:35 --> Controller Class Initialized
INFO - 2016-05-24 13:23:35 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:23:35 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:23:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:23:35 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:23:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:23:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 13:23:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:23:35 --> Form Validation Class Initialized
INFO - 2016-05-24 13:23:35 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:23:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 13:23:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-05-24 13:23:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 13:23:35 --> Final output sent to browser
DEBUG - 2016-05-24 13:23:35 --> Total execution time: 0.0176
INFO - 2016-05-24 13:25:08 --> Config Class Initialized
INFO - 2016-05-24 13:25:08 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:25:08 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:25:08 --> Utf8 Class Initialized
INFO - 2016-05-24 13:25:08 --> URI Class Initialized
INFO - 2016-05-24 13:25:08 --> Router Class Initialized
INFO - 2016-05-24 13:25:08 --> Output Class Initialized
INFO - 2016-05-24 13:25:08 --> Security Class Initialized
DEBUG - 2016-05-24 13:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:25:08 --> CSRF cookie sent
INFO - 2016-05-24 13:25:08 --> Input Class Initialized
INFO - 2016-05-24 13:25:08 --> Language Class Initialized
INFO - 2016-05-24 13:25:08 --> Loader Class Initialized
INFO - 2016-05-24 13:25:08 --> Helper loaded: form_helper
INFO - 2016-05-24 13:25:08 --> Database Driver Class Initialized
INFO - 2016-05-24 13:25:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:25:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:25:08 --> Email Class Initialized
INFO - 2016-05-24 13:25:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:25:08 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:25:08 --> Helper loaded: language_helper
INFO - 2016-05-24 13:25:08 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:25:08 --> Model Class Initialized
INFO - 2016-05-24 13:25:08 --> Helper loaded: date_helper
INFO - 2016-05-24 13:25:08 --> Controller Class Initialized
INFO - 2016-05-24 13:25:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:25:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:25:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:25:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:25:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:25:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 13:25:08 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:25:08 --> Form Validation Class Initialized
INFO - 2016-05-24 13:25:08 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:25:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 13:25:08 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 13:25:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 13:25:08 --> Final output sent to browser
DEBUG - 2016-05-24 13:25:08 --> Total execution time: 0.0965
INFO - 2016-05-24 13:25:59 --> Config Class Initialized
INFO - 2016-05-24 13:25:59 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:25:59 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:25:59 --> Utf8 Class Initialized
INFO - 2016-05-24 13:25:59 --> URI Class Initialized
INFO - 2016-05-24 13:25:59 --> Router Class Initialized
INFO - 2016-05-24 13:25:59 --> Output Class Initialized
INFO - 2016-05-24 13:25:59 --> Security Class Initialized
DEBUG - 2016-05-24 13:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:25:59 --> CSRF cookie sent
INFO - 2016-05-24 13:25:59 --> CSRF token verified
INFO - 2016-05-24 13:25:59 --> Input Class Initialized
INFO - 2016-05-24 13:25:59 --> Language Class Initialized
INFO - 2016-05-24 13:25:59 --> Loader Class Initialized
INFO - 2016-05-24 13:25:59 --> Helper loaded: form_helper
INFO - 2016-05-24 13:25:59 --> Database Driver Class Initialized
INFO - 2016-05-24 13:26:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:26:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:26:00 --> Email Class Initialized
INFO - 2016-05-24 13:26:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:26:00 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:26:00 --> Helper loaded: language_helper
INFO - 2016-05-24 13:26:00 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:26:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:26:00 --> Model Class Initialized
INFO - 2016-05-24 13:26:00 --> Helper loaded: date_helper
INFO - 2016-05-24 13:26:00 --> Controller Class Initialized
INFO - 2016-05-24 13:26:00 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:26:00 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:26:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:26:00 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:26:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:26:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-24 13:26:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:26:00 --> Form Validation Class Initialized
INFO - 2016-05-24 13:26:01 --> Config Class Initialized
INFO - 2016-05-24 13:26:01 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:26:01 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:26:01 --> Utf8 Class Initialized
INFO - 2016-05-24 13:26:01 --> URI Class Initialized
DEBUG - 2016-05-24 13:26:01 --> No URI present. Default controller set.
INFO - 2016-05-24 13:26:01 --> Router Class Initialized
INFO - 2016-05-24 13:26:01 --> Output Class Initialized
INFO - 2016-05-24 13:26:01 --> Security Class Initialized
DEBUG - 2016-05-24 13:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:26:01 --> CSRF cookie sent
INFO - 2016-05-24 13:26:01 --> Input Class Initialized
INFO - 2016-05-24 13:26:01 --> Language Class Initialized
INFO - 2016-05-24 13:26:01 --> Loader Class Initialized
INFO - 2016-05-24 13:26:01 --> Helper loaded: form_helper
INFO - 2016-05-24 13:26:01 --> Database Driver Class Initialized
INFO - 2016-05-24 13:26:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:26:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:26:01 --> Email Class Initialized
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:26:01 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:26:01 --> Helper loaded: language_helper
INFO - 2016-05-24 13:26:01 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:26:01 --> Model Class Initialized
INFO - 2016-05-24 13:26:01 --> Helper loaded: date_helper
INFO - 2016-05-24 13:26:01 --> Controller Class Initialized
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 13:26:01 --> Config Class Initialized
INFO - 2016-05-24 13:26:01 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:26:01 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:26:01 --> Utf8 Class Initialized
INFO - 2016-05-24 13:26:01 --> URI Class Initialized
INFO - 2016-05-24 13:26:01 --> Router Class Initialized
INFO - 2016-05-24 13:26:01 --> Output Class Initialized
INFO - 2016-05-24 13:26:01 --> Security Class Initialized
DEBUG - 2016-05-24 13:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:26:01 --> CSRF cookie sent
INFO - 2016-05-24 13:26:01 --> Input Class Initialized
INFO - 2016-05-24 13:26:01 --> Language Class Initialized
INFO - 2016-05-24 13:26:01 --> Loader Class Initialized
INFO - 2016-05-24 13:26:01 --> Helper loaded: form_helper
INFO - 2016-05-24 13:26:01 --> Database Driver Class Initialized
INFO - 2016-05-24 13:26:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:26:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:26:01 --> Email Class Initialized
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:26:01 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:26:01 --> Helper loaded: language_helper
INFO - 2016-05-24 13:26:01 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:26:01 --> Model Class Initialized
INFO - 2016-05-24 13:26:01 --> Helper loaded: date_helper
INFO - 2016-05-24 13:26:01 --> Controller Class Initialized
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:26:01 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 13:26:01 --> Model Class Initialized
INFO - 2016-05-24 13:26:01 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:26:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:26:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:26:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 13:26:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:26:01 --> Final output sent to browser
DEBUG - 2016-05-24 13:26:01 --> Total execution time: 0.0225
INFO - 2016-05-24 13:44:57 --> Config Class Initialized
INFO - 2016-05-24 13:44:57 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:44:57 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:44:57 --> Utf8 Class Initialized
INFO - 2016-05-24 13:44:57 --> URI Class Initialized
INFO - 2016-05-24 13:44:57 --> Router Class Initialized
INFO - 2016-05-24 13:44:57 --> Output Class Initialized
INFO - 2016-05-24 13:44:57 --> Security Class Initialized
DEBUG - 2016-05-24 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:44:57 --> CSRF cookie sent
INFO - 2016-05-24 13:44:57 --> Input Class Initialized
INFO - 2016-05-24 13:44:57 --> Language Class Initialized
INFO - 2016-05-24 13:44:57 --> Loader Class Initialized
INFO - 2016-05-24 13:44:57 --> Helper loaded: form_helper
INFO - 2016-05-24 13:44:57 --> Database Driver Class Initialized
INFO - 2016-05-24 13:44:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:44:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:44:57 --> Email Class Initialized
INFO - 2016-05-24 13:44:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:44:57 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:44:57 --> Helper loaded: language_helper
INFO - 2016-05-24 13:44:57 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:44:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:44:57 --> Model Class Initialized
INFO - 2016-05-24 13:44:57 --> Helper loaded: date_helper
INFO - 2016-05-24 13:44:57 --> Controller Class Initialized
INFO - 2016-05-24 13:44:57 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:44:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:44:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:44:57 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:44:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:44:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 13:44:57 --> Model Class Initialized
ERROR - 2016-05-24 13:44:57 --> Query error: Unknown column 'email' in 'field list' - Invalid query: 
			SELECT
				`token`,
				`fk_user`,
				`name`,
				`email`,
				`type`
			FROM
				`tokens`
			WHERE
				`fk_user` = '2'
			AND
				`_is_active` = 1
			LIMIT 0, 30
			
INFO - 2016-05-24 13:50:51 --> Config Class Initialized
INFO - 2016-05-24 13:50:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:50:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:50:51 --> Utf8 Class Initialized
INFO - 2016-05-24 13:50:51 --> URI Class Initialized
INFO - 2016-05-24 13:50:51 --> Router Class Initialized
INFO - 2016-05-24 13:50:51 --> Output Class Initialized
INFO - 2016-05-24 13:50:51 --> Security Class Initialized
DEBUG - 2016-05-24 13:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:50:51 --> CSRF cookie sent
INFO - 2016-05-24 13:50:51 --> Input Class Initialized
INFO - 2016-05-24 13:50:51 --> Language Class Initialized
INFO - 2016-05-24 13:50:51 --> Loader Class Initialized
INFO - 2016-05-24 13:50:51 --> Helper loaded: form_helper
INFO - 2016-05-24 13:50:51 --> Database Driver Class Initialized
INFO - 2016-05-24 13:50:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:50:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:50:51 --> Email Class Initialized
INFO - 2016-05-24 13:50:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:50:51 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:50:51 --> Helper loaded: language_helper
INFO - 2016-05-24 13:50:51 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:50:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:50:51 --> Model Class Initialized
INFO - 2016-05-24 13:50:51 --> Helper loaded: date_helper
INFO - 2016-05-24 13:50:51 --> Controller Class Initialized
INFO - 2016-05-24 13:50:51 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:50:51 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:50:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:50:51 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:50:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:50:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 13:50:51 --> Model Class Initialized
ERROR - 2016-05-24 13:50:51 --> Query error: Unknown column '_create_date' in 'where clause' - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = '2'
			AND
				`_create_date` > DATE_SUB(NOW(), INTERVAL 24 HOUR)
			
INFO - 2016-05-24 13:51:58 --> Config Class Initialized
INFO - 2016-05-24 13:51:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:51:58 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:51:58 --> Utf8 Class Initialized
INFO - 2016-05-24 13:51:58 --> URI Class Initialized
INFO - 2016-05-24 13:51:58 --> Router Class Initialized
INFO - 2016-05-24 13:51:58 --> Output Class Initialized
INFO - 2016-05-24 13:51:58 --> Security Class Initialized
DEBUG - 2016-05-24 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:51:58 --> CSRF cookie sent
INFO - 2016-05-24 13:51:58 --> Input Class Initialized
INFO - 2016-05-24 13:51:58 --> Language Class Initialized
INFO - 2016-05-24 13:51:58 --> Loader Class Initialized
INFO - 2016-05-24 13:51:58 --> Helper loaded: form_helper
INFO - 2016-05-24 13:51:58 --> Database Driver Class Initialized
INFO - 2016-05-24 13:51:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:51:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:51:58 --> Email Class Initialized
INFO - 2016-05-24 13:51:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:51:58 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:51:58 --> Helper loaded: language_helper
INFO - 2016-05-24 13:51:58 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:51:58 --> Model Class Initialized
INFO - 2016-05-24 13:51:58 --> Helper loaded: date_helper
INFO - 2016-05-24 13:51:58 --> Controller Class Initialized
INFO - 2016-05-24 13:51:58 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:51:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:51:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:51:58 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:51:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:51:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 13:51:58 --> Model Class Initialized
ERROR - 2016-05-24 13:51:58 --> Query error: Unknown column '_create_date' in 'where clause' - Invalid query: 
			SELECT
				count(*) as `total`
			FROM
				`tokens`
			WHERE
				`fk_user` = '2'
			AND
				`_create_date` > DATE_SUB(NOW(), INTERVAL 24 HOUR)
			
INFO - 2016-05-24 13:52:18 --> Config Class Initialized
INFO - 2016-05-24 13:52:18 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:52:18 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:52:18 --> Utf8 Class Initialized
INFO - 2016-05-24 13:52:18 --> URI Class Initialized
INFO - 2016-05-24 13:52:18 --> Router Class Initialized
INFO - 2016-05-24 13:52:18 --> Output Class Initialized
INFO - 2016-05-24 13:52:18 --> Security Class Initialized
DEBUG - 2016-05-24 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:52:18 --> CSRF cookie sent
INFO - 2016-05-24 13:52:18 --> Input Class Initialized
INFO - 2016-05-24 13:52:18 --> Language Class Initialized
INFO - 2016-05-24 13:52:18 --> Loader Class Initialized
INFO - 2016-05-24 13:52:18 --> Helper loaded: form_helper
INFO - 2016-05-24 13:52:18 --> Database Driver Class Initialized
INFO - 2016-05-24 13:52:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:52:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:52:18 --> Email Class Initialized
INFO - 2016-05-24 13:52:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:52:18 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:52:18 --> Helper loaded: language_helper
INFO - 2016-05-24 13:52:18 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:52:18 --> Model Class Initialized
INFO - 2016-05-24 13:52:18 --> Helper loaded: date_helper
INFO - 2016-05-24 13:52:18 --> Controller Class Initialized
INFO - 2016-05-24 13:52:18 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:52:18 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:52:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:52:18 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:52:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:52:18 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 13:52:18 --> Model Class Initialized
INFO - 2016-05-24 13:52:18 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:52:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:52:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:52:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:52:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:52:18 --> Final output sent to browser
DEBUG - 2016-05-24 13:52:18 --> Total execution time: 0.1090
INFO - 2016-05-24 13:53:13 --> Config Class Initialized
INFO - 2016-05-24 13:53:13 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:53:13 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:53:13 --> Utf8 Class Initialized
INFO - 2016-05-24 13:53:13 --> URI Class Initialized
INFO - 2016-05-24 13:53:13 --> Router Class Initialized
INFO - 2016-05-24 13:53:13 --> Output Class Initialized
INFO - 2016-05-24 13:53:14 --> Security Class Initialized
DEBUG - 2016-05-24 13:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:53:14 --> CSRF cookie sent
INFO - 2016-05-24 13:53:14 --> CSRF token verified
INFO - 2016-05-24 13:53:14 --> Input Class Initialized
INFO - 2016-05-24 13:53:14 --> Language Class Initialized
INFO - 2016-05-24 13:53:14 --> Loader Class Initialized
INFO - 2016-05-24 13:53:14 --> Helper loaded: form_helper
INFO - 2016-05-24 13:53:14 --> Database Driver Class Initialized
INFO - 2016-05-24 13:53:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:53:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:53:14 --> Email Class Initialized
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:53:14 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:53:14 --> Helper loaded: language_helper
INFO - 2016-05-24 13:53:14 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:53:14 --> Model Class Initialized
INFO - 2016-05-24 13:53:14 --> Helper loaded: date_helper
INFO - 2016-05-24 13:53:14 --> Controller Class Initialized
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-24 13:53:14 --> Config Class Initialized
INFO - 2016-05-24 13:53:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:53:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:53:14 --> Utf8 Class Initialized
INFO - 2016-05-24 13:53:14 --> URI Class Initialized
INFO - 2016-05-24 13:53:14 --> Router Class Initialized
INFO - 2016-05-24 13:53:14 --> Output Class Initialized
INFO - 2016-05-24 13:53:14 --> Security Class Initialized
DEBUG - 2016-05-24 13:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:53:14 --> CSRF cookie sent
INFO - 2016-05-24 13:53:14 --> Input Class Initialized
INFO - 2016-05-24 13:53:14 --> Language Class Initialized
INFO - 2016-05-24 13:53:14 --> Loader Class Initialized
INFO - 2016-05-24 13:53:14 --> Helper loaded: form_helper
INFO - 2016-05-24 13:53:14 --> Database Driver Class Initialized
INFO - 2016-05-24 13:53:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:53:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:53:14 --> Email Class Initialized
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:53:14 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:53:14 --> Helper loaded: language_helper
INFO - 2016-05-24 13:53:14 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:53:14 --> Model Class Initialized
INFO - 2016-05-24 13:53:14 --> Helper loaded: date_helper
INFO - 2016-05-24 13:53:14 --> Controller Class Initialized
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:53:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:53:14 --> Model Class Initialized
INFO - 2016-05-24 13:53:14 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:53:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:53:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:53:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:53:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:53:14 --> Final output sent to browser
DEBUG - 2016-05-24 13:53:14 --> Total execution time: 0.1634
INFO - 2016-05-24 13:53:54 --> Config Class Initialized
INFO - 2016-05-24 13:53:54 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:53:54 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:53:54 --> Utf8 Class Initialized
INFO - 2016-05-24 13:53:54 --> URI Class Initialized
INFO - 2016-05-24 13:53:54 --> Router Class Initialized
INFO - 2016-05-24 13:53:54 --> Output Class Initialized
INFO - 2016-05-24 13:53:54 --> Security Class Initialized
DEBUG - 2016-05-24 13:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:53:54 --> CSRF cookie sent
INFO - 2016-05-24 13:53:54 --> Input Class Initialized
INFO - 2016-05-24 13:53:54 --> Language Class Initialized
INFO - 2016-05-24 13:53:54 --> Loader Class Initialized
INFO - 2016-05-24 13:53:54 --> Helper loaded: form_helper
INFO - 2016-05-24 13:53:54 --> Database Driver Class Initialized
INFO - 2016-05-24 13:53:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:53:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:53:54 --> Email Class Initialized
INFO - 2016-05-24 13:53:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:53:54 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:53:54 --> Helper loaded: language_helper
INFO - 2016-05-24 13:53:54 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:53:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:53:54 --> Model Class Initialized
INFO - 2016-05-24 13:53:54 --> Helper loaded: date_helper
INFO - 2016-05-24 13:53:54 --> Controller Class Initialized
INFO - 2016-05-24 13:53:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:53:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:53:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:53:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:53:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:53:55 --> Model Class Initialized
INFO - 2016-05-24 13:53:55 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:53:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:53:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:53:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:53:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:53:55 --> Final output sent to browser
DEBUG - 2016-05-24 13:53:55 --> Total execution time: 0.0840
INFO - 2016-05-24 13:54:17 --> Config Class Initialized
INFO - 2016-05-24 13:54:17 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:54:17 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:54:17 --> Utf8 Class Initialized
INFO - 2016-05-24 13:54:17 --> URI Class Initialized
INFO - 2016-05-24 13:54:17 --> Router Class Initialized
INFO - 2016-05-24 13:54:17 --> Output Class Initialized
INFO - 2016-05-24 13:54:17 --> Security Class Initialized
DEBUG - 2016-05-24 13:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:54:17 --> CSRF cookie sent
INFO - 2016-05-24 13:54:17 --> Input Class Initialized
INFO - 2016-05-24 13:54:17 --> Language Class Initialized
INFO - 2016-05-24 13:54:17 --> Loader Class Initialized
INFO - 2016-05-24 13:54:17 --> Helper loaded: form_helper
INFO - 2016-05-24 13:54:17 --> Database Driver Class Initialized
INFO - 2016-05-24 13:54:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:54:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:54:17 --> Email Class Initialized
INFO - 2016-05-24 13:54:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:54:17 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:54:17 --> Helper loaded: language_helper
INFO - 2016-05-24 13:54:17 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:54:17 --> Model Class Initialized
INFO - 2016-05-24 13:54:17 --> Helper loaded: date_helper
INFO - 2016-05-24 13:54:17 --> Controller Class Initialized
INFO - 2016-05-24 13:54:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:54:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:54:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:54:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:54:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:54:17 --> Model Class Initialized
INFO - 2016-05-24 13:54:17 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:54:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:54:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:54:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:54:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:54:17 --> Final output sent to browser
DEBUG - 2016-05-24 13:54:17 --> Total execution time: 0.0992
INFO - 2016-05-24 13:55:44 --> Config Class Initialized
INFO - 2016-05-24 13:55:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:55:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:55:44 --> Utf8 Class Initialized
INFO - 2016-05-24 13:55:44 --> URI Class Initialized
INFO - 2016-05-24 13:55:44 --> Router Class Initialized
INFO - 2016-05-24 13:55:44 --> Output Class Initialized
INFO - 2016-05-24 13:55:44 --> Security Class Initialized
DEBUG - 2016-05-24 13:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:55:44 --> CSRF cookie sent
INFO - 2016-05-24 13:55:44 --> Input Class Initialized
INFO - 2016-05-24 13:55:44 --> Language Class Initialized
INFO - 2016-05-24 13:55:44 --> Loader Class Initialized
INFO - 2016-05-24 13:55:44 --> Helper loaded: form_helper
INFO - 2016-05-24 13:55:44 --> Database Driver Class Initialized
INFO - 2016-05-24 13:55:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:55:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:55:44 --> Email Class Initialized
INFO - 2016-05-24 13:55:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:55:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:55:44 --> Helper loaded: language_helper
INFO - 2016-05-24 13:55:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:55:44 --> Model Class Initialized
INFO - 2016-05-24 13:55:44 --> Helper loaded: date_helper
INFO - 2016-05-24 13:55:44 --> Controller Class Initialized
INFO - 2016-05-24 13:55:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:55:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:55:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:55:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:55:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:55:44 --> Model Class Initialized
INFO - 2016-05-24 13:55:44 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:55:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:55:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:55:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:55:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:55:44 --> Final output sent to browser
DEBUG - 2016-05-24 13:55:44 --> Total execution time: 0.0682
INFO - 2016-05-24 13:56:35 --> Config Class Initialized
INFO - 2016-05-24 13:56:35 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:56:35 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:56:35 --> Utf8 Class Initialized
INFO - 2016-05-24 13:56:35 --> URI Class Initialized
INFO - 2016-05-24 13:56:35 --> Router Class Initialized
INFO - 2016-05-24 13:56:35 --> Output Class Initialized
INFO - 2016-05-24 13:56:35 --> Security Class Initialized
DEBUG - 2016-05-24 13:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:56:35 --> CSRF cookie sent
INFO - 2016-05-24 13:56:35 --> Input Class Initialized
INFO - 2016-05-24 13:56:35 --> Language Class Initialized
INFO - 2016-05-24 13:56:35 --> Loader Class Initialized
INFO - 2016-05-24 13:56:35 --> Helper loaded: form_helper
INFO - 2016-05-24 13:56:35 --> Database Driver Class Initialized
INFO - 2016-05-24 13:56:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:56:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:56:35 --> Email Class Initialized
INFO - 2016-05-24 13:56:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:56:35 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:56:35 --> Helper loaded: language_helper
INFO - 2016-05-24 13:56:35 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:56:35 --> Model Class Initialized
INFO - 2016-05-24 13:56:35 --> Helper loaded: date_helper
INFO - 2016-05-24 13:56:35 --> Controller Class Initialized
INFO - 2016-05-24 13:56:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:56:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:56:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:56:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:56:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:56:35 --> Model Class Initialized
INFO - 2016-05-24 13:56:35 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:56:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:56:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:57:58 --> Config Class Initialized
INFO - 2016-05-24 13:57:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:57:58 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:57:58 --> Utf8 Class Initialized
INFO - 2016-05-24 13:57:58 --> URI Class Initialized
INFO - 2016-05-24 13:57:58 --> Router Class Initialized
INFO - 2016-05-24 13:57:58 --> Output Class Initialized
INFO - 2016-05-24 13:57:58 --> Security Class Initialized
DEBUG - 2016-05-24 13:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:57:58 --> CSRF cookie sent
INFO - 2016-05-24 13:57:58 --> Input Class Initialized
INFO - 2016-05-24 13:57:58 --> Language Class Initialized
INFO - 2016-05-24 13:57:58 --> Loader Class Initialized
INFO - 2016-05-24 13:57:58 --> Helper loaded: form_helper
INFO - 2016-05-24 13:57:58 --> Database Driver Class Initialized
INFO - 2016-05-24 13:57:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:57:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:57:58 --> Email Class Initialized
INFO - 2016-05-24 13:57:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:57:58 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:57:58 --> Helper loaded: language_helper
INFO - 2016-05-24 13:57:58 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:57:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:57:58 --> Model Class Initialized
INFO - 2016-05-24 13:57:58 --> Helper loaded: date_helper
INFO - 2016-05-24 13:57:58 --> Controller Class Initialized
INFO - 2016-05-24 13:57:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:57:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:57:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:57:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:57:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:57:58 --> Model Class Initialized
INFO - 2016-05-24 13:57:58 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:57:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:57:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:58:29 --> Config Class Initialized
INFO - 2016-05-24 13:58:29 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:58:29 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:58:29 --> Utf8 Class Initialized
INFO - 2016-05-24 13:58:29 --> URI Class Initialized
INFO - 2016-05-24 13:58:29 --> Router Class Initialized
INFO - 2016-05-24 13:58:29 --> Output Class Initialized
INFO - 2016-05-24 13:58:29 --> Security Class Initialized
DEBUG - 2016-05-24 13:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:58:29 --> CSRF cookie sent
INFO - 2016-05-24 13:58:29 --> Input Class Initialized
INFO - 2016-05-24 13:58:29 --> Language Class Initialized
INFO - 2016-05-24 13:58:29 --> Loader Class Initialized
INFO - 2016-05-24 13:58:29 --> Helper loaded: form_helper
INFO - 2016-05-24 13:58:29 --> Database Driver Class Initialized
INFO - 2016-05-24 13:58:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:58:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:58:29 --> Email Class Initialized
INFO - 2016-05-24 13:58:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:58:29 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:58:29 --> Helper loaded: language_helper
INFO - 2016-05-24 13:58:29 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:58:29 --> Model Class Initialized
INFO - 2016-05-24 13:58:29 --> Helper loaded: date_helper
INFO - 2016-05-24 13:58:29 --> Controller Class Initialized
INFO - 2016-05-24 13:58:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:58:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:58:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:58:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:58:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:58:29 --> Model Class Initialized
INFO - 2016-05-24 13:58:29 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:58:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:58:29 --> Final output sent to browser
DEBUG - 2016-05-24 13:58:29 --> Total execution time: 0.2072
INFO - 2016-05-24 13:59:37 --> Config Class Initialized
INFO - 2016-05-24 13:59:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:59:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:59:37 --> Utf8 Class Initialized
INFO - 2016-05-24 13:59:37 --> URI Class Initialized
INFO - 2016-05-24 13:59:37 --> Router Class Initialized
INFO - 2016-05-24 13:59:37 --> Output Class Initialized
INFO - 2016-05-24 13:59:37 --> Security Class Initialized
DEBUG - 2016-05-24 13:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:59:37 --> CSRF cookie sent
INFO - 2016-05-24 13:59:37 --> Input Class Initialized
INFO - 2016-05-24 13:59:37 --> Language Class Initialized
INFO - 2016-05-24 13:59:37 --> Loader Class Initialized
INFO - 2016-05-24 13:59:37 --> Helper loaded: form_helper
INFO - 2016-05-24 13:59:37 --> Database Driver Class Initialized
INFO - 2016-05-24 13:59:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:59:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:59:37 --> Email Class Initialized
INFO - 2016-05-24 13:59:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:59:37 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:59:37 --> Helper loaded: language_helper
INFO - 2016-05-24 13:59:37 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:59:37 --> Model Class Initialized
INFO - 2016-05-24 13:59:37 --> Helper loaded: date_helper
INFO - 2016-05-24 13:59:37 --> Controller Class Initialized
INFO - 2016-05-24 13:59:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:59:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:59:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:59:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:59:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:59:37 --> Model Class Initialized
INFO - 2016-05-24 13:59:37 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:59:37 --> Final output sent to browser
DEBUG - 2016-05-24 13:59:37 --> Total execution time: 0.0573
INFO - 2016-05-24 13:59:54 --> Config Class Initialized
INFO - 2016-05-24 13:59:54 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:59:54 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:59:54 --> Utf8 Class Initialized
INFO - 2016-05-24 13:59:54 --> URI Class Initialized
INFO - 2016-05-24 13:59:54 --> Router Class Initialized
INFO - 2016-05-24 13:59:54 --> Output Class Initialized
INFO - 2016-05-24 13:59:54 --> Security Class Initialized
DEBUG - 2016-05-24 13:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:59:54 --> CSRF cookie sent
INFO - 2016-05-24 13:59:54 --> CSRF token verified
INFO - 2016-05-24 13:59:54 --> Input Class Initialized
INFO - 2016-05-24 13:59:54 --> Language Class Initialized
INFO - 2016-05-24 13:59:54 --> Loader Class Initialized
INFO - 2016-05-24 13:59:54 --> Helper loaded: form_helper
INFO - 2016-05-24 13:59:54 --> Database Driver Class Initialized
INFO - 2016-05-24 13:59:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:59:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:59:54 --> Email Class Initialized
INFO - 2016-05-24 13:59:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:59:54 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:59:54 --> Helper loaded: language_helper
INFO - 2016-05-24 13:59:54 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:59:54 --> Model Class Initialized
INFO - 2016-05-24 13:59:54 --> Helper loaded: date_helper
INFO - 2016-05-24 13:59:54 --> Controller Class Initialized
INFO - 2016-05-24 13:59:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:59:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:59:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:59:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:59:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:59:54 --> Model Class Initialized
INFO - 2016-05-24 13:59:54 --> Form Validation Class Initialized
DEBUG - 2016-05-24 13:59:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:59:55 --> Config Class Initialized
INFO - 2016-05-24 13:59:55 --> Hooks Class Initialized
DEBUG - 2016-05-24 13:59:55 --> UTF-8 Support Enabled
INFO - 2016-05-24 13:59:55 --> Utf8 Class Initialized
INFO - 2016-05-24 13:59:55 --> URI Class Initialized
INFO - 2016-05-24 13:59:55 --> Router Class Initialized
INFO - 2016-05-24 13:59:55 --> Output Class Initialized
INFO - 2016-05-24 13:59:55 --> Security Class Initialized
DEBUG - 2016-05-24 13:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 13:59:55 --> CSRF cookie sent
INFO - 2016-05-24 13:59:55 --> Input Class Initialized
INFO - 2016-05-24 13:59:55 --> Language Class Initialized
INFO - 2016-05-24 13:59:55 --> Loader Class Initialized
INFO - 2016-05-24 13:59:55 --> Helper loaded: form_helper
INFO - 2016-05-24 13:59:55 --> Database Driver Class Initialized
INFO - 2016-05-24 13:59:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 13:59:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 13:59:55 --> Email Class Initialized
INFO - 2016-05-24 13:59:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 13:59:55 --> Helper loaded: cookie_helper
INFO - 2016-05-24 13:59:55 --> Helper loaded: language_helper
INFO - 2016-05-24 13:59:55 --> Helper loaded: url_helper
DEBUG - 2016-05-24 13:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 13:59:55 --> Model Class Initialized
INFO - 2016-05-24 13:59:55 --> Helper loaded: date_helper
INFO - 2016-05-24 13:59:55 --> Controller Class Initialized
INFO - 2016-05-24 13:59:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 13:59:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 13:59:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 13:59:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 13:59:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 13:59:55 --> Model Class Initialized
INFO - 2016-05-24 13:59:55 --> Helper loaded: languages_helper
INFO - 2016-05-24 13:59:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 13:59:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 13:59:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 13:59:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 13:59:55 --> Final output sent to browser
DEBUG - 2016-05-24 13:59:55 --> Total execution time: 0.0608
INFO - 2016-05-24 14:42:39 --> Config Class Initialized
INFO - 2016-05-24 14:42:39 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:42:39 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:42:39 --> Utf8 Class Initialized
INFO - 2016-05-24 14:42:39 --> URI Class Initialized
INFO - 2016-05-24 14:42:39 --> Router Class Initialized
INFO - 2016-05-24 14:42:39 --> Output Class Initialized
INFO - 2016-05-24 14:42:39 --> Security Class Initialized
DEBUG - 2016-05-24 14:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:42:39 --> CSRF cookie sent
INFO - 2016-05-24 14:42:39 --> Input Class Initialized
INFO - 2016-05-24 14:42:39 --> Language Class Initialized
INFO - 2016-05-24 14:42:39 --> Loader Class Initialized
INFO - 2016-05-24 14:42:39 --> Helper loaded: form_helper
INFO - 2016-05-24 14:42:39 --> Database Driver Class Initialized
INFO - 2016-05-24 14:42:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:42:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:42:39 --> Email Class Initialized
INFO - 2016-05-24 14:42:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:42:39 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:42:39 --> Helper loaded: language_helper
INFO - 2016-05-24 14:42:39 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:42:39 --> Model Class Initialized
INFO - 2016-05-24 14:42:39 --> Helper loaded: date_helper
INFO - 2016-05-24 14:42:39 --> Controller Class Initialized
INFO - 2016-05-24 14:42:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:42:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:42:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:42:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:42:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 14:42:39 --> Model Class Initialized
INFO - 2016-05-24 14:42:39 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 14:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 14:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-24 14:42:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 14:42:39 --> Final output sent to browser
DEBUG - 2016-05-24 14:42:39 --> Total execution time: 0.0517
INFO - 2016-05-24 14:42:48 --> Config Class Initialized
INFO - 2016-05-24 14:42:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:42:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:42:48 --> Utf8 Class Initialized
INFO - 2016-05-24 14:42:48 --> URI Class Initialized
INFO - 2016-05-24 14:42:48 --> Router Class Initialized
INFO - 2016-05-24 14:42:48 --> Output Class Initialized
INFO - 2016-05-24 14:42:48 --> Security Class Initialized
DEBUG - 2016-05-24 14:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:42:48 --> CSRF cookie sent
INFO - 2016-05-24 14:42:48 --> Input Class Initialized
INFO - 2016-05-24 14:42:48 --> Language Class Initialized
INFO - 2016-05-24 14:42:48 --> Loader Class Initialized
INFO - 2016-05-24 14:42:48 --> Helper loaded: form_helper
INFO - 2016-05-24 14:42:48 --> Database Driver Class Initialized
INFO - 2016-05-24 14:42:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:42:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:42:48 --> Email Class Initialized
INFO - 2016-05-24 14:42:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:42:48 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:42:48 --> Helper loaded: language_helper
INFO - 2016-05-24 14:42:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:42:48 --> Model Class Initialized
INFO - 2016-05-24 14:42:48 --> Helper loaded: date_helper
INFO - 2016-05-24 14:42:48 --> Controller Class Initialized
INFO - 2016-05-24 14:42:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:42:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:42:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:42:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:42:48 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:42:48 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:42:48 --> Form Validation Class Initialized
INFO - 2016-05-24 14:42:48 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:42:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 14:42:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 14:42:48 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/change_password.php
INFO - 2016-05-24 14:42:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 14:42:48 --> Final output sent to browser
DEBUG - 2016-05-24 14:42:48 --> Total execution time: 0.1783
INFO - 2016-05-24 14:43:22 --> Config Class Initialized
INFO - 2016-05-24 14:43:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:43:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:43:22 --> Utf8 Class Initialized
INFO - 2016-05-24 14:43:22 --> URI Class Initialized
INFO - 2016-05-24 14:43:22 --> Router Class Initialized
INFO - 2016-05-24 14:43:22 --> Output Class Initialized
INFO - 2016-05-24 14:43:22 --> Security Class Initialized
DEBUG - 2016-05-24 14:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:43:22 --> CSRF cookie sent
INFO - 2016-05-24 14:43:22 --> CSRF token verified
INFO - 2016-05-24 14:43:22 --> Input Class Initialized
INFO - 2016-05-24 14:43:22 --> Language Class Initialized
INFO - 2016-05-24 14:43:22 --> Loader Class Initialized
INFO - 2016-05-24 14:43:22 --> Helper loaded: form_helper
INFO - 2016-05-24 14:43:22 --> Database Driver Class Initialized
INFO - 2016-05-24 14:43:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:43:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:43:22 --> Email Class Initialized
INFO - 2016-05-24 14:43:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:43:22 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:43:22 --> Helper loaded: language_helper
INFO - 2016-05-24 14:43:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:22 --> Model Class Initialized
INFO - 2016-05-24 14:43:22 --> Helper loaded: date_helper
INFO - 2016-05-24 14:43:22 --> Controller Class Initialized
INFO - 2016-05-24 14:43:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:43:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:43:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:43:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:43:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:43:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:22 --> Form Validation Class Initialized
INFO - 2016-05-24 14:43:23 --> Config Class Initialized
INFO - 2016-05-24 14:43:23 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:43:23 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:43:23 --> Utf8 Class Initialized
INFO - 2016-05-24 14:43:23 --> URI Class Initialized
INFO - 2016-05-24 14:43:23 --> Router Class Initialized
INFO - 2016-05-24 14:43:23 --> Output Class Initialized
INFO - 2016-05-24 14:43:23 --> Security Class Initialized
DEBUG - 2016-05-24 14:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:43:23 --> CSRF cookie sent
INFO - 2016-05-24 14:43:23 --> Input Class Initialized
INFO - 2016-05-24 14:43:23 --> Language Class Initialized
INFO - 2016-05-24 14:43:23 --> Loader Class Initialized
INFO - 2016-05-24 14:43:23 --> Helper loaded: form_helper
INFO - 2016-05-24 14:43:23 --> Database Driver Class Initialized
INFO - 2016-05-24 14:43:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:43:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:43:23 --> Email Class Initialized
INFO - 2016-05-24 14:43:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:43:23 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:43:23 --> Helper loaded: language_helper
INFO - 2016-05-24 14:43:23 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:23 --> Model Class Initialized
INFO - 2016-05-24 14:43:23 --> Helper loaded: date_helper
INFO - 2016-05-24 14:43:23 --> Controller Class Initialized
INFO - 2016-05-24 14:43:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:43:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:43:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:43:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:43:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:43:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:23 --> Form Validation Class Initialized
INFO - 2016-05-24 14:43:23 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:43:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 14:43:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 14:43:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 14:43:23 --> Final output sent to browser
DEBUG - 2016-05-24 14:43:23 --> Total execution time: 0.0395
INFO - 2016-05-24 14:43:49 --> Config Class Initialized
INFO - 2016-05-24 14:43:49 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:43:49 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:43:49 --> Utf8 Class Initialized
INFO - 2016-05-24 14:43:49 --> URI Class Initialized
INFO - 2016-05-24 14:43:49 --> Router Class Initialized
INFO - 2016-05-24 14:43:49 --> Output Class Initialized
INFO - 2016-05-24 14:43:49 --> Security Class Initialized
DEBUG - 2016-05-24 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:43:49 --> CSRF cookie sent
INFO - 2016-05-24 14:43:49 --> CSRF token verified
INFO - 2016-05-24 14:43:49 --> Input Class Initialized
INFO - 2016-05-24 14:43:49 --> Language Class Initialized
INFO - 2016-05-24 14:43:49 --> Loader Class Initialized
INFO - 2016-05-24 14:43:49 --> Helper loaded: form_helper
INFO - 2016-05-24 14:43:49 --> Database Driver Class Initialized
INFO - 2016-05-24 14:43:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:43:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:43:49 --> Email Class Initialized
INFO - 2016-05-24 14:43:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:43:49 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:43:49 --> Helper loaded: language_helper
INFO - 2016-05-24 14:43:49 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:49 --> Model Class Initialized
INFO - 2016-05-24 14:43:49 --> Helper loaded: date_helper
INFO - 2016-05-24 14:43:49 --> Controller Class Initialized
INFO - 2016-05-24 14:43:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:43:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:43:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:43:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:43:49 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:43:49 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:49 --> Form Validation Class Initialized
INFO - 2016-05-24 14:43:50 --> Config Class Initialized
INFO - 2016-05-24 14:43:50 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:43:50 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:43:50 --> Utf8 Class Initialized
INFO - 2016-05-24 14:43:50 --> URI Class Initialized
INFO - 2016-05-24 14:43:50 --> Router Class Initialized
INFO - 2016-05-24 14:43:50 --> Output Class Initialized
INFO - 2016-05-24 14:43:50 --> Security Class Initialized
DEBUG - 2016-05-24 14:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:43:50 --> CSRF cookie sent
INFO - 2016-05-24 14:43:50 --> Input Class Initialized
INFO - 2016-05-24 14:43:50 --> Language Class Initialized
INFO - 2016-05-24 14:43:50 --> Loader Class Initialized
INFO - 2016-05-24 14:43:50 --> Helper loaded: form_helper
INFO - 2016-05-24 14:43:50 --> Database Driver Class Initialized
INFO - 2016-05-24 14:43:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:43:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:43:50 --> Email Class Initialized
INFO - 2016-05-24 14:43:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:43:50 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:43:50 --> Helper loaded: language_helper
INFO - 2016-05-24 14:43:50 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:50 --> Model Class Initialized
INFO - 2016-05-24 14:43:50 --> Helper loaded: date_helper
INFO - 2016-05-24 14:43:50 --> Controller Class Initialized
INFO - 2016-05-24 14:43:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:43:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:43:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:43:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:43:50 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:43:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:43:50 --> Form Validation Class Initialized
INFO - 2016-05-24 14:43:50 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:43:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 14:43:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 14:43:50 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 14:43:50 --> Final output sent to browser
DEBUG - 2016-05-24 14:43:50 --> Total execution time: 0.0883
INFO - 2016-05-24 14:44:42 --> Config Class Initialized
INFO - 2016-05-24 14:44:42 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:44:42 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:44:42 --> Utf8 Class Initialized
INFO - 2016-05-24 14:44:42 --> URI Class Initialized
INFO - 2016-05-24 14:44:42 --> Router Class Initialized
INFO - 2016-05-24 14:44:42 --> Output Class Initialized
INFO - 2016-05-24 14:44:42 --> Security Class Initialized
DEBUG - 2016-05-24 14:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:44:42 --> CSRF cookie sent
INFO - 2016-05-24 14:44:42 --> CSRF token verified
INFO - 2016-05-24 14:44:42 --> Input Class Initialized
INFO - 2016-05-24 14:44:42 --> Language Class Initialized
INFO - 2016-05-24 14:44:42 --> Loader Class Initialized
INFO - 2016-05-24 14:44:42 --> Helper loaded: form_helper
INFO - 2016-05-24 14:44:43 --> Database Driver Class Initialized
INFO - 2016-05-24 14:44:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:44:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:44:43 --> Email Class Initialized
INFO - 2016-05-24 14:44:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:44:43 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:44:43 --> Helper loaded: language_helper
INFO - 2016-05-24 14:44:43 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:44:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:44:43 --> Model Class Initialized
INFO - 2016-05-24 14:44:43 --> Helper loaded: date_helper
INFO - 2016-05-24 14:44:43 --> Controller Class Initialized
INFO - 2016-05-24 14:44:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:44:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:44:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:44:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:44:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:44:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:44:43 --> Form Validation Class Initialized
INFO - 2016-05-24 14:44:44 --> Config Class Initialized
INFO - 2016-05-24 14:44:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:44:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:44:44 --> Utf8 Class Initialized
INFO - 2016-05-24 14:44:44 --> URI Class Initialized
DEBUG - 2016-05-24 14:44:44 --> No URI present. Default controller set.
INFO - 2016-05-24 14:44:44 --> Router Class Initialized
INFO - 2016-05-24 14:44:44 --> Output Class Initialized
INFO - 2016-05-24 14:44:44 --> Security Class Initialized
DEBUG - 2016-05-24 14:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:44:44 --> CSRF cookie sent
INFO - 2016-05-24 14:44:44 --> Input Class Initialized
INFO - 2016-05-24 14:44:44 --> Language Class Initialized
INFO - 2016-05-24 14:44:44 --> Loader Class Initialized
INFO - 2016-05-24 14:44:44 --> Helper loaded: form_helper
INFO - 2016-05-24 14:44:44 --> Database Driver Class Initialized
INFO - 2016-05-24 14:44:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:44:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:44:44 --> Email Class Initialized
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:44:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:44:44 --> Helper loaded: language_helper
INFO - 2016-05-24 14:44:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:44:44 --> Model Class Initialized
INFO - 2016-05-24 14:44:44 --> Helper loaded: date_helper
INFO - 2016-05-24 14:44:44 --> Controller Class Initialized
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 14:44:44 --> Config Class Initialized
INFO - 2016-05-24 14:44:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:44:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:44:44 --> Utf8 Class Initialized
INFO - 2016-05-24 14:44:44 --> URI Class Initialized
INFO - 2016-05-24 14:44:44 --> Router Class Initialized
INFO - 2016-05-24 14:44:44 --> Output Class Initialized
INFO - 2016-05-24 14:44:44 --> Security Class Initialized
DEBUG - 2016-05-24 14:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:44:44 --> CSRF cookie sent
INFO - 2016-05-24 14:44:44 --> Input Class Initialized
INFO - 2016-05-24 14:44:44 --> Language Class Initialized
INFO - 2016-05-24 14:44:44 --> Loader Class Initialized
INFO - 2016-05-24 14:44:44 --> Helper loaded: form_helper
INFO - 2016-05-24 14:44:44 --> Database Driver Class Initialized
INFO - 2016-05-24 14:44:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:44:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:44:44 --> Email Class Initialized
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:44:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:44:44 --> Helper loaded: language_helper
INFO - 2016-05-24 14:44:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:44:44 --> Model Class Initialized
INFO - 2016-05-24 14:44:44 --> Helper loaded: date_helper
INFO - 2016-05-24 14:44:44 --> Controller Class Initialized
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:44:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 14:44:44 --> Model Class Initialized
INFO - 2016-05-24 14:44:44 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 14:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 14:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 14:44:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 14:44:44 --> Final output sent to browser
DEBUG - 2016-05-24 14:44:44 --> Total execution time: 0.0330
INFO - 2016-05-24 14:44:50 --> Config Class Initialized
INFO - 2016-05-24 14:44:50 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:44:50 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:44:50 --> Utf8 Class Initialized
INFO - 2016-05-24 14:44:50 --> URI Class Initialized
INFO - 2016-05-24 14:44:50 --> Router Class Initialized
INFO - 2016-05-24 14:44:50 --> Output Class Initialized
INFO - 2016-05-24 14:44:50 --> Security Class Initialized
DEBUG - 2016-05-24 14:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:44:50 --> CSRF cookie sent
INFO - 2016-05-24 14:44:50 --> Input Class Initialized
INFO - 2016-05-24 14:44:50 --> Language Class Initialized
INFO - 2016-05-24 14:44:50 --> Loader Class Initialized
INFO - 2016-05-24 14:44:50 --> Helper loaded: form_helper
INFO - 2016-05-24 14:44:50 --> Database Driver Class Initialized
INFO - 2016-05-24 14:44:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:44:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:44:50 --> Email Class Initialized
INFO - 2016-05-24 14:44:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:44:50 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:44:50 --> Helper loaded: language_helper
INFO - 2016-05-24 14:44:50 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:44:50 --> Model Class Initialized
INFO - 2016-05-24 14:44:50 --> Helper loaded: date_helper
INFO - 2016-05-24 14:44:50 --> Controller Class Initialized
INFO - 2016-05-24 14:44:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:44:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:44:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:44:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:44:50 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:44:50 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:44:50 --> Form Validation Class Initialized
INFO - 2016-05-24 14:44:50 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:44:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 14:44:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 14:44:50 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/change_password.php
INFO - 2016-05-24 14:44:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 14:44:50 --> Final output sent to browser
DEBUG - 2016-05-24 14:44:50 --> Total execution time: 0.0440
INFO - 2016-05-24 14:45:12 --> Config Class Initialized
INFO - 2016-05-24 14:45:12 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:45:12 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:45:12 --> Utf8 Class Initialized
INFO - 2016-05-24 14:45:12 --> URI Class Initialized
INFO - 2016-05-24 14:45:12 --> Router Class Initialized
INFO - 2016-05-24 14:45:12 --> Output Class Initialized
INFO - 2016-05-24 14:45:12 --> Security Class Initialized
DEBUG - 2016-05-24 14:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:45:12 --> CSRF cookie sent
INFO - 2016-05-24 14:45:12 --> CSRF token verified
INFO - 2016-05-24 14:45:12 --> Input Class Initialized
INFO - 2016-05-24 14:45:12 --> Language Class Initialized
INFO - 2016-05-24 14:45:12 --> Loader Class Initialized
INFO - 2016-05-24 14:45:12 --> Helper loaded: form_helper
INFO - 2016-05-24 14:45:12 --> Database Driver Class Initialized
INFO - 2016-05-24 14:45:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:45:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:45:12 --> Email Class Initialized
INFO - 2016-05-24 14:45:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:45:12 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:45:12 --> Helper loaded: language_helper
INFO - 2016-05-24 14:45:12 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:12 --> Model Class Initialized
INFO - 2016-05-24 14:45:12 --> Helper loaded: date_helper
INFO - 2016-05-24 14:45:12 --> Controller Class Initialized
INFO - 2016-05-24 14:45:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:45:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:45:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:45:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:45:12 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:45:12 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:12 --> Form Validation Class Initialized
INFO - 2016-05-24 14:45:14 --> Config Class Initialized
INFO - 2016-05-24 14:45:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:45:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:45:14 --> Utf8 Class Initialized
INFO - 2016-05-24 14:45:14 --> URI Class Initialized
INFO - 2016-05-24 14:45:14 --> Router Class Initialized
INFO - 2016-05-24 14:45:14 --> Output Class Initialized
INFO - 2016-05-24 14:45:14 --> Security Class Initialized
DEBUG - 2016-05-24 14:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:45:14 --> CSRF cookie sent
INFO - 2016-05-24 14:45:14 --> Input Class Initialized
INFO - 2016-05-24 14:45:14 --> Language Class Initialized
INFO - 2016-05-24 14:45:14 --> Loader Class Initialized
INFO - 2016-05-24 14:45:14 --> Helper loaded: form_helper
INFO - 2016-05-24 14:45:14 --> Database Driver Class Initialized
INFO - 2016-05-24 14:45:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:45:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:45:14 --> Email Class Initialized
INFO - 2016-05-24 14:45:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:45:14 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:45:14 --> Helper loaded: language_helper
INFO - 2016-05-24 14:45:14 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:14 --> Model Class Initialized
INFO - 2016-05-24 14:45:14 --> Helper loaded: date_helper
INFO - 2016-05-24 14:45:14 --> Controller Class Initialized
INFO - 2016-05-24 14:45:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:45:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:45:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:45:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:45:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:45:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:14 --> Form Validation Class Initialized
INFO - 2016-05-24 14:45:14 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:45:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 14:45:14 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 14:45:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 14:45:14 --> Final output sent to browser
DEBUG - 2016-05-24 14:45:14 --> Total execution time: 0.2128
INFO - 2016-05-24 14:45:47 --> Config Class Initialized
INFO - 2016-05-24 14:45:47 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:45:47 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:45:47 --> Utf8 Class Initialized
INFO - 2016-05-24 14:45:47 --> URI Class Initialized
INFO - 2016-05-24 14:45:47 --> Router Class Initialized
INFO - 2016-05-24 14:45:47 --> Output Class Initialized
INFO - 2016-05-24 14:45:47 --> Security Class Initialized
DEBUG - 2016-05-24 14:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:45:47 --> CSRF cookie sent
INFO - 2016-05-24 14:45:47 --> CSRF token verified
INFO - 2016-05-24 14:45:47 --> Input Class Initialized
INFO - 2016-05-24 14:45:47 --> Language Class Initialized
INFO - 2016-05-24 14:45:47 --> Loader Class Initialized
INFO - 2016-05-24 14:45:47 --> Helper loaded: form_helper
INFO - 2016-05-24 14:45:47 --> Database Driver Class Initialized
INFO - 2016-05-24 14:45:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:45:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:45:47 --> Email Class Initialized
INFO - 2016-05-24 14:45:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:45:47 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:45:47 --> Helper loaded: language_helper
INFO - 2016-05-24 14:45:47 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:47 --> Model Class Initialized
INFO - 2016-05-24 14:45:47 --> Helper loaded: date_helper
INFO - 2016-05-24 14:45:47 --> Controller Class Initialized
INFO - 2016-05-24 14:45:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:45:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:45:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:45:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:45:47 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:45:47 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:47 --> Form Validation Class Initialized
INFO - 2016-05-24 14:45:48 --> Config Class Initialized
INFO - 2016-05-24 14:45:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:45:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:45:48 --> Utf8 Class Initialized
INFO - 2016-05-24 14:45:48 --> URI Class Initialized
DEBUG - 2016-05-24 14:45:48 --> No URI present. Default controller set.
INFO - 2016-05-24 14:45:48 --> Router Class Initialized
INFO - 2016-05-24 14:45:48 --> Output Class Initialized
INFO - 2016-05-24 14:45:48 --> Security Class Initialized
DEBUG - 2016-05-24 14:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:45:48 --> CSRF cookie sent
INFO - 2016-05-24 14:45:48 --> Input Class Initialized
INFO - 2016-05-24 14:45:48 --> Language Class Initialized
INFO - 2016-05-24 14:45:48 --> Loader Class Initialized
INFO - 2016-05-24 14:45:48 --> Helper loaded: form_helper
INFO - 2016-05-24 14:45:48 --> Database Driver Class Initialized
INFO - 2016-05-24 14:45:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:45:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:45:48 --> Email Class Initialized
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:45:48 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:45:48 --> Helper loaded: language_helper
INFO - 2016-05-24 14:45:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:48 --> Model Class Initialized
INFO - 2016-05-24 14:45:48 --> Helper loaded: date_helper
INFO - 2016-05-24 14:45:48 --> Controller Class Initialized
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 14:45:48 --> Config Class Initialized
INFO - 2016-05-24 14:45:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:45:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:45:48 --> Utf8 Class Initialized
INFO - 2016-05-24 14:45:48 --> URI Class Initialized
INFO - 2016-05-24 14:45:48 --> Router Class Initialized
INFO - 2016-05-24 14:45:48 --> Output Class Initialized
INFO - 2016-05-24 14:45:48 --> Security Class Initialized
DEBUG - 2016-05-24 14:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:45:48 --> CSRF cookie sent
INFO - 2016-05-24 14:45:48 --> Input Class Initialized
INFO - 2016-05-24 14:45:48 --> Language Class Initialized
INFO - 2016-05-24 14:45:48 --> Loader Class Initialized
INFO - 2016-05-24 14:45:48 --> Helper loaded: form_helper
INFO - 2016-05-24 14:45:48 --> Database Driver Class Initialized
INFO - 2016-05-24 14:45:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:45:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:45:48 --> Email Class Initialized
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:45:48 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:45:48 --> Helper loaded: language_helper
INFO - 2016-05-24 14:45:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:45:48 --> Model Class Initialized
INFO - 2016-05-24 14:45:48 --> Helper loaded: date_helper
INFO - 2016-05-24 14:45:48 --> Controller Class Initialized
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:45:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 14:45:48 --> Model Class Initialized
INFO - 2016-05-24 14:45:48 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:45:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 14:45:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 14:45:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 14:45:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 14:45:48 --> Final output sent to browser
DEBUG - 2016-05-24 14:45:48 --> Total execution time: 0.0706
INFO - 2016-05-24 14:52:40 --> Config Class Initialized
INFO - 2016-05-24 14:52:40 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:52:40 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:52:40 --> Utf8 Class Initialized
INFO - 2016-05-24 14:52:40 --> URI Class Initialized
INFO - 2016-05-24 14:52:40 --> Router Class Initialized
INFO - 2016-05-24 14:52:40 --> Output Class Initialized
INFO - 2016-05-24 14:52:40 --> Security Class Initialized
DEBUG - 2016-05-24 14:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:52:40 --> CSRF cookie sent
INFO - 2016-05-24 14:52:40 --> Input Class Initialized
INFO - 2016-05-24 14:52:40 --> Language Class Initialized
INFO - 2016-05-24 14:52:40 --> Loader Class Initialized
INFO - 2016-05-24 14:52:40 --> Helper loaded: form_helper
INFO - 2016-05-24 14:52:40 --> Database Driver Class Initialized
INFO - 2016-05-24 14:52:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:52:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:52:40 --> Email Class Initialized
INFO - 2016-05-24 14:52:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:52:40 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:52:40 --> Helper loaded: language_helper
INFO - 2016-05-24 14:52:40 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:52:40 --> Model Class Initialized
INFO - 2016-05-24 14:52:40 --> Helper loaded: date_helper
INFO - 2016-05-24 14:52:40 --> Controller Class Initialized
INFO - 2016-05-24 14:52:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:52:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:52:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:52:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:52:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 14:52:40 --> Model Class Initialized
INFO - 2016-05-24 14:52:40 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:52:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 14:52:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: message /home/demis/www/platformadiabet/application/views/auth/edit_user.php 7
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: first_name /home/demis/www/platformadiabet/application/views/auth/edit_user.php 14
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: last_name /home/demis/www/platformadiabet/application/views/auth/edit_user.php 19
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: phone /home/demis/www/platformadiabet/application/views/auth/edit_user.php 24
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: age /home/demis/www/platformadiabet/application/views/auth/edit_user.php 29
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: sex /home/demis/www/platformadiabet/application/views/auth/edit_user.php 32
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: diabetes_type /home/demis/www/platformadiabet/application/views/auth/edit_user.php 36
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: diabetes_period /home/demis/www/platformadiabet/application/views/auth/edit_user.php 42
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: treatment /home/demis/www/platformadiabet/application/views/auth/edit_user.php 46
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: password /home/demis/www/platformadiabet/application/views/auth/edit_user.php 52
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: password_confirm /home/demis/www/platformadiabet/application/views/auth/edit_user.php 57
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: user /home/demis/www/platformadiabet/application/views/auth/edit_user.php 83
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/auth/edit_user.php 83
ERROR - 2016-05-24 14:52:41 --> Severity: Notice --> Undefined variable: csrf /home/demis/www/platformadiabet/application/views/auth/edit_user.php 84
INFO - 2016-05-24 14:52:41 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 14:52:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 14:52:41 --> Final output sent to browser
DEBUG - 2016-05-24 14:52:41 --> Total execution time: 0.0781
INFO - 2016-05-24 14:54:19 --> Config Class Initialized
INFO - 2016-05-24 14:54:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:54:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:54:19 --> Utf8 Class Initialized
INFO - 2016-05-24 14:54:19 --> URI Class Initialized
INFO - 2016-05-24 14:54:19 --> Router Class Initialized
INFO - 2016-05-24 14:54:19 --> Output Class Initialized
INFO - 2016-05-24 14:54:19 --> Security Class Initialized
DEBUG - 2016-05-24 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:54:19 --> CSRF cookie sent
INFO - 2016-05-24 14:54:19 --> Input Class Initialized
INFO - 2016-05-24 14:54:19 --> Language Class Initialized
INFO - 2016-05-24 14:54:19 --> Loader Class Initialized
INFO - 2016-05-24 14:54:19 --> Helper loaded: form_helper
INFO - 2016-05-24 14:54:19 --> Database Driver Class Initialized
INFO - 2016-05-24 14:54:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:54:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:54:19 --> Email Class Initialized
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:54:19 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:54:19 --> Helper loaded: language_helper
INFO - 2016-05-24 14:54:19 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:54:19 --> Model Class Initialized
INFO - 2016-05-24 14:54:19 --> Helper loaded: date_helper
INFO - 2016-05-24 14:54:19 --> Controller Class Initialized
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 14:54:19 --> Model Class Initialized
INFO - 2016-05-24 14:54:19 --> Config Class Initialized
INFO - 2016-05-24 14:54:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 14:54:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 14:54:19 --> Utf8 Class Initialized
INFO - 2016-05-24 14:54:19 --> URI Class Initialized
INFO - 2016-05-24 14:54:19 --> Router Class Initialized
INFO - 2016-05-24 14:54:19 --> Output Class Initialized
INFO - 2016-05-24 14:54:19 --> Security Class Initialized
DEBUG - 2016-05-24 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 14:54:19 --> CSRF cookie sent
INFO - 2016-05-24 14:54:19 --> Input Class Initialized
INFO - 2016-05-24 14:54:19 --> Language Class Initialized
INFO - 2016-05-24 14:54:19 --> Loader Class Initialized
INFO - 2016-05-24 14:54:19 --> Helper loaded: form_helper
INFO - 2016-05-24 14:54:19 --> Database Driver Class Initialized
INFO - 2016-05-24 14:54:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 14:54:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 14:54:19 --> Email Class Initialized
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 14:54:19 --> Helper loaded: cookie_helper
INFO - 2016-05-24 14:54:19 --> Helper loaded: language_helper
INFO - 2016-05-24 14:54:19 --> Helper loaded: url_helper
DEBUG - 2016-05-24 14:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:54:19 --> Model Class Initialized
INFO - 2016-05-24 14:54:19 --> Helper loaded: date_helper
INFO - 2016-05-24 14:54:19 --> Controller Class Initialized
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 14:54:19 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 14:54:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 14:54:19 --> Form Validation Class Initialized
INFO - 2016-05-24 14:54:19 --> Helper loaded: string_helper
INFO - 2016-05-24 14:54:19 --> Helper loaded: languages_helper
INFO - 2016-05-24 14:54:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 14:54:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 14:54:19 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 14:54:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 14:54:19 --> Final output sent to browser
DEBUG - 2016-05-24 14:54:19 --> Total execution time: 0.0838
INFO - 2016-05-24 15:05:53 --> Config Class Initialized
INFO - 2016-05-24 15:05:53 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:05:53 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:05:53 --> Utf8 Class Initialized
INFO - 2016-05-24 15:05:53 --> URI Class Initialized
INFO - 2016-05-24 15:05:53 --> Router Class Initialized
INFO - 2016-05-24 15:05:53 --> Output Class Initialized
INFO - 2016-05-24 15:05:53 --> Security Class Initialized
DEBUG - 2016-05-24 15:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:05:53 --> CSRF cookie sent
INFO - 2016-05-24 15:05:53 --> Input Class Initialized
INFO - 2016-05-24 15:05:53 --> Language Class Initialized
INFO - 2016-05-24 15:05:53 --> Loader Class Initialized
INFO - 2016-05-24 15:05:53 --> Helper loaded: form_helper
INFO - 2016-05-24 15:05:53 --> Database Driver Class Initialized
INFO - 2016-05-24 15:05:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:05:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:05:53 --> Email Class Initialized
INFO - 2016-05-24 15:05:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:05:53 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:05:53 --> Helper loaded: language_helper
INFO - 2016-05-24 15:05:53 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:05:53 --> Model Class Initialized
INFO - 2016-05-24 15:05:53 --> Helper loaded: date_helper
INFO - 2016-05-24 15:05:53 --> Controller Class Initialized
INFO - 2016-05-24 15:05:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:05:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:05:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:05:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:05:53 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 15:05:53 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:05:53 --> Form Validation Class Initialized
INFO - 2016-05-24 15:05:53 --> Helper loaded: string_helper
INFO - 2016-05-24 15:05:53 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:05:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:05:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:05:53 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:05:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:05:53 --> Final output sent to browser
DEBUG - 2016-05-24 15:05:53 --> Total execution time: 0.0583
INFO - 2016-05-24 15:05:55 --> Config Class Initialized
INFO - 2016-05-24 15:05:55 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:05:55 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:05:55 --> Utf8 Class Initialized
INFO - 2016-05-24 15:05:55 --> URI Class Initialized
INFO - 2016-05-24 15:05:55 --> Router Class Initialized
INFO - 2016-05-24 15:05:55 --> Output Class Initialized
INFO - 2016-05-24 15:05:55 --> Security Class Initialized
DEBUG - 2016-05-24 15:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:05:55 --> CSRF cookie sent
INFO - 2016-05-24 15:05:55 --> Input Class Initialized
INFO - 2016-05-24 15:05:55 --> Language Class Initialized
INFO - 2016-05-24 15:05:55 --> Loader Class Initialized
INFO - 2016-05-24 15:05:55 --> Helper loaded: form_helper
INFO - 2016-05-24 15:05:55 --> Database Driver Class Initialized
INFO - 2016-05-24 15:05:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:05:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:05:55 --> Email Class Initialized
INFO - 2016-05-24 15:05:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:05:55 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:05:55 --> Helper loaded: language_helper
INFO - 2016-05-24 15:05:55 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:05:55 --> Model Class Initialized
INFO - 2016-05-24 15:05:55 --> Helper loaded: date_helper
INFO - 2016-05-24 15:05:55 --> Controller Class Initialized
INFO - 2016-05-24 15:05:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:05:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:05:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:05:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:05:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 15:05:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:05:55 --> Form Validation Class Initialized
INFO - 2016-05-24 15:05:55 --> Helper loaded: string_helper
INFO - 2016-05-24 15:05:55 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:05:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:05:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:05:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:05:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:05:55 --> Final output sent to browser
DEBUG - 2016-05-24 15:05:55 --> Total execution time: 0.0218
INFO - 2016-05-24 15:05:57 --> Config Class Initialized
INFO - 2016-05-24 15:05:57 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:05:57 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:05:57 --> Utf8 Class Initialized
INFO - 2016-05-24 15:05:57 --> URI Class Initialized
INFO - 2016-05-24 15:05:57 --> Router Class Initialized
INFO - 2016-05-24 15:05:57 --> Output Class Initialized
INFO - 2016-05-24 15:05:57 --> Security Class Initialized
DEBUG - 2016-05-24 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:05:57 --> CSRF cookie sent
INFO - 2016-05-24 15:05:57 --> Input Class Initialized
INFO - 2016-05-24 15:05:57 --> Language Class Initialized
INFO - 2016-05-24 15:05:57 --> Loader Class Initialized
INFO - 2016-05-24 15:05:57 --> Helper loaded: form_helper
INFO - 2016-05-24 15:05:57 --> Database Driver Class Initialized
INFO - 2016-05-24 15:05:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:05:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:05:57 --> Email Class Initialized
INFO - 2016-05-24 15:05:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:05:57 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:05:57 --> Helper loaded: language_helper
INFO - 2016-05-24 15:05:57 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:05:57 --> Model Class Initialized
INFO - 2016-05-24 15:05:57 --> Helper loaded: date_helper
INFO - 2016-05-24 15:05:57 --> Controller Class Initialized
INFO - 2016-05-24 15:05:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:05:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:05:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:05:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:05:57 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 15:05:57 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:05:57 --> Form Validation Class Initialized
INFO - 2016-05-24 15:05:57 --> Helper loaded: string_helper
INFO - 2016-05-24 15:05:57 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:05:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:05:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:05:57 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:05:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:05:57 --> Final output sent to browser
DEBUG - 2016-05-24 15:05:57 --> Total execution time: 0.0352
INFO - 2016-05-24 15:06:06 --> Config Class Initialized
INFO - 2016-05-24 15:06:06 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:06:06 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:06:06 --> Utf8 Class Initialized
INFO - 2016-05-24 15:06:06 --> URI Class Initialized
DEBUG - 2016-05-24 15:06:06 --> No URI present. Default controller set.
INFO - 2016-05-24 15:06:06 --> Router Class Initialized
INFO - 2016-05-24 15:06:06 --> Output Class Initialized
INFO - 2016-05-24 15:06:06 --> Security Class Initialized
DEBUG - 2016-05-24 15:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:06:06 --> CSRF cookie sent
INFO - 2016-05-24 15:06:06 --> Input Class Initialized
INFO - 2016-05-24 15:06:06 --> Language Class Initialized
INFO - 2016-05-24 15:06:06 --> Loader Class Initialized
INFO - 2016-05-24 15:06:06 --> Helper loaded: form_helper
INFO - 2016-05-24 15:06:06 --> Database Driver Class Initialized
INFO - 2016-05-24 15:06:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:06:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:06:06 --> Email Class Initialized
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:06:06 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:06:06 --> Helper loaded: language_helper
INFO - 2016-05-24 15:06:06 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:06:06 --> Model Class Initialized
INFO - 2016-05-24 15:06:06 --> Helper loaded: date_helper
INFO - 2016-05-24 15:06:06 --> Controller Class Initialized
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:06:06 --> Config Class Initialized
INFO - 2016-05-24 15:06:06 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:06:06 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:06:06 --> Utf8 Class Initialized
INFO - 2016-05-24 15:06:06 --> URI Class Initialized
INFO - 2016-05-24 15:06:06 --> Router Class Initialized
INFO - 2016-05-24 15:06:06 --> Output Class Initialized
INFO - 2016-05-24 15:06:06 --> Security Class Initialized
DEBUG - 2016-05-24 15:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:06:06 --> CSRF cookie sent
INFO - 2016-05-24 15:06:06 --> Input Class Initialized
INFO - 2016-05-24 15:06:06 --> Language Class Initialized
INFO - 2016-05-24 15:06:06 --> Loader Class Initialized
INFO - 2016-05-24 15:06:06 --> Helper loaded: form_helper
INFO - 2016-05-24 15:06:06 --> Database Driver Class Initialized
INFO - 2016-05-24 15:06:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:06:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:06:06 --> Email Class Initialized
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:06:06 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:06:06 --> Helper loaded: language_helper
INFO - 2016-05-24 15:06:06 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:06:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:06:06 --> Model Class Initialized
INFO - 2016-05-24 15:06:06 --> Helper loaded: date_helper
INFO - 2016-05-24 15:06:06 --> Controller Class Initialized
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:06:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:06:06 --> Model Class Initialized
INFO - 2016-05-24 15:06:06 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:06:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:06:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:06:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 15:06:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:06:06 --> Final output sent to browser
DEBUG - 2016-05-24 15:06:06 --> Total execution time: 0.0615
INFO - 2016-05-24 15:35:20 --> Config Class Initialized
INFO - 2016-05-24 15:35:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:35:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:35:20 --> Utf8 Class Initialized
INFO - 2016-05-24 15:35:20 --> URI Class Initialized
INFO - 2016-05-24 15:35:20 --> Router Class Initialized
INFO - 2016-05-24 15:35:20 --> Output Class Initialized
INFO - 2016-05-24 15:35:20 --> Security Class Initialized
DEBUG - 2016-05-24 15:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:35:20 --> CSRF cookie sent
INFO - 2016-05-24 15:35:20 --> Input Class Initialized
INFO - 2016-05-24 15:35:20 --> Language Class Initialized
INFO - 2016-05-24 15:35:20 --> Loader Class Initialized
INFO - 2016-05-24 15:35:20 --> Helper loaded: form_helper
INFO - 2016-05-24 15:35:20 --> Database Driver Class Initialized
INFO - 2016-05-24 15:35:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:35:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:35:20 --> Email Class Initialized
INFO - 2016-05-24 15:35:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:35:20 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:35:20 --> Helper loaded: language_helper
INFO - 2016-05-24 15:35:20 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:35:20 --> Model Class Initialized
INFO - 2016-05-24 15:35:20 --> Helper loaded: date_helper
INFO - 2016-05-24 15:35:20 --> Controller Class Initialized
INFO - 2016-05-24 15:35:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:35:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:35:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:35:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:35:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:35:20 --> Model Class Initialized
ERROR - 2016-05-24 15:35:20 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/controllers/Diabet.php 24
INFO - 2016-05-24 15:35:21 --> Config Class Initialized
INFO - 2016-05-24 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:35:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:35:21 --> Utf8 Class Initialized
INFO - 2016-05-24 15:35:21 --> URI Class Initialized
INFO - 2016-05-24 15:35:21 --> Router Class Initialized
INFO - 2016-05-24 15:35:21 --> Output Class Initialized
INFO - 2016-05-24 15:35:21 --> Security Class Initialized
DEBUG - 2016-05-24 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:35:21 --> CSRF cookie sent
INFO - 2016-05-24 15:35:21 --> Input Class Initialized
INFO - 2016-05-24 15:35:21 --> Language Class Initialized
INFO - 2016-05-24 15:35:21 --> Loader Class Initialized
INFO - 2016-05-24 15:35:21 --> Helper loaded: form_helper
INFO - 2016-05-24 15:35:21 --> Database Driver Class Initialized
INFO - 2016-05-24 15:35:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:35:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:35:21 --> Email Class Initialized
INFO - 2016-05-24 15:35:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:35:21 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:35:21 --> Helper loaded: language_helper
INFO - 2016-05-24 15:35:21 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:35:21 --> Model Class Initialized
INFO - 2016-05-24 15:35:21 --> Helper loaded: date_helper
INFO - 2016-05-24 15:35:21 --> Controller Class Initialized
INFO - 2016-05-24 15:35:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:35:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:35:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:35:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:35:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 15:35:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:35:21 --> Form Validation Class Initialized
INFO - 2016-05-24 15:35:25 --> Config Class Initialized
INFO - 2016-05-24 15:35:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:35:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:35:25 --> Utf8 Class Initialized
INFO - 2016-05-24 15:35:25 --> URI Class Initialized
INFO - 2016-05-24 15:35:25 --> Router Class Initialized
INFO - 2016-05-24 15:35:25 --> Output Class Initialized
INFO - 2016-05-24 15:35:25 --> Security Class Initialized
DEBUG - 2016-05-24 15:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:35:25 --> CSRF cookie sent
INFO - 2016-05-24 15:35:25 --> Input Class Initialized
INFO - 2016-05-24 15:35:25 --> Language Class Initialized
INFO - 2016-05-24 15:35:25 --> Loader Class Initialized
INFO - 2016-05-24 15:35:25 --> Helper loaded: form_helper
INFO - 2016-05-24 15:35:25 --> Database Driver Class Initialized
INFO - 2016-05-24 15:35:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:35:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:35:25 --> Email Class Initialized
INFO - 2016-05-24 15:35:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:35:25 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:35:25 --> Helper loaded: language_helper
INFO - 2016-05-24 15:35:25 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:35:25 --> Model Class Initialized
INFO - 2016-05-24 15:35:25 --> Helper loaded: date_helper
INFO - 2016-05-24 15:35:25 --> Controller Class Initialized
INFO - 2016-05-24 15:35:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:35:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:35:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:35:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:35:25 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 15:35:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:35:25 --> Form Validation Class Initialized
INFO - 2016-05-24 15:35:25 --> Helper loaded: string_helper
INFO - 2016-05-24 15:35:25 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:35:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:35:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:35:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:35:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:35:25 --> Final output sent to browser
DEBUG - 2016-05-24 15:35:25 --> Total execution time: 0.0924
INFO - 2016-05-24 15:38:08 --> Config Class Initialized
INFO - 2016-05-24 15:38:08 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:38:08 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:38:08 --> Utf8 Class Initialized
INFO - 2016-05-24 15:38:08 --> URI Class Initialized
INFO - 2016-05-24 15:38:08 --> Router Class Initialized
INFO - 2016-05-24 15:38:08 --> Output Class Initialized
INFO - 2016-05-24 15:38:08 --> Security Class Initialized
DEBUG - 2016-05-24 15:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:38:08 --> CSRF cookie sent
INFO - 2016-05-24 15:38:08 --> Input Class Initialized
INFO - 2016-05-24 15:38:08 --> Language Class Initialized
INFO - 2016-05-24 15:38:08 --> Loader Class Initialized
INFO - 2016-05-24 15:38:08 --> Helper loaded: form_helper
INFO - 2016-05-24 15:38:08 --> Database Driver Class Initialized
INFO - 2016-05-24 15:38:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:38:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:38:08 --> Email Class Initialized
INFO - 2016-05-24 15:38:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:38:08 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:38:08 --> Helper loaded: language_helper
INFO - 2016-05-24 15:38:08 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:08 --> Model Class Initialized
INFO - 2016-05-24 15:38:08 --> Helper loaded: date_helper
INFO - 2016-05-24 15:38:08 --> Controller Class Initialized
INFO - 2016-05-24 15:38:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:38:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:38:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:38:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:38:08 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 15:38:08 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:08 --> Form Validation Class Initialized
INFO - 2016-05-24 15:38:08 --> Helper loaded: string_helper
INFO - 2016-05-24 15:38:08 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:38:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:38:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:38:08 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:38:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:38:08 --> Final output sent to browser
DEBUG - 2016-05-24 15:38:08 --> Total execution time: 0.0559
INFO - 2016-05-24 15:38:14 --> Config Class Initialized
INFO - 2016-05-24 15:38:14 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:38:14 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:38:14 --> Utf8 Class Initialized
INFO - 2016-05-24 15:38:14 --> URI Class Initialized
DEBUG - 2016-05-24 15:38:14 --> No URI present. Default controller set.
INFO - 2016-05-24 15:38:14 --> Router Class Initialized
INFO - 2016-05-24 15:38:14 --> Output Class Initialized
INFO - 2016-05-24 15:38:14 --> Security Class Initialized
DEBUG - 2016-05-24 15:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:38:14 --> CSRF cookie sent
INFO - 2016-05-24 15:38:14 --> Input Class Initialized
INFO - 2016-05-24 15:38:14 --> Language Class Initialized
INFO - 2016-05-24 15:38:14 --> Loader Class Initialized
INFO - 2016-05-24 15:38:14 --> Helper loaded: form_helper
INFO - 2016-05-24 15:38:14 --> Database Driver Class Initialized
INFO - 2016-05-24 15:38:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:38:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:38:14 --> Email Class Initialized
INFO - 2016-05-24 15:38:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:38:14 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:38:14 --> Helper loaded: language_helper
INFO - 2016-05-24 15:38:14 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:14 --> Model Class Initialized
INFO - 2016-05-24 15:38:14 --> Helper loaded: date_helper
INFO - 2016-05-24 15:38:14 --> Controller Class Initialized
INFO - 2016-05-24 15:38:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:38:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:38:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:38:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:38:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:38:15 --> Config Class Initialized
INFO - 2016-05-24 15:38:15 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:38:15 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:38:15 --> Utf8 Class Initialized
INFO - 2016-05-24 15:38:15 --> URI Class Initialized
INFO - 2016-05-24 15:38:15 --> Router Class Initialized
INFO - 2016-05-24 15:38:15 --> Output Class Initialized
INFO - 2016-05-24 15:38:15 --> Security Class Initialized
DEBUG - 2016-05-24 15:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:38:15 --> CSRF cookie sent
INFO - 2016-05-24 15:38:15 --> Input Class Initialized
INFO - 2016-05-24 15:38:15 --> Language Class Initialized
INFO - 2016-05-24 15:38:15 --> Loader Class Initialized
INFO - 2016-05-24 15:38:15 --> Helper loaded: form_helper
INFO - 2016-05-24 15:38:15 --> Database Driver Class Initialized
INFO - 2016-05-24 15:38:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:38:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:38:15 --> Email Class Initialized
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:38:15 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:38:15 --> Helper loaded: language_helper
INFO - 2016-05-24 15:38:15 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:15 --> Model Class Initialized
INFO - 2016-05-24 15:38:15 --> Helper loaded: date_helper
INFO - 2016-05-24 15:38:15 --> Controller Class Initialized
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:38:15 --> Model Class Initialized
ERROR - 2016-05-24 15:38:15 --> Severity: Notice --> Undefined variable: id /home/demis/www/platformadiabet/application/controllers/Diabet.php 24
INFO - 2016-05-24 15:38:15 --> Config Class Initialized
INFO - 2016-05-24 15:38:15 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:38:15 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:38:15 --> Utf8 Class Initialized
INFO - 2016-05-24 15:38:15 --> URI Class Initialized
INFO - 2016-05-24 15:38:15 --> Router Class Initialized
INFO - 2016-05-24 15:38:15 --> Output Class Initialized
INFO - 2016-05-24 15:38:15 --> Security Class Initialized
DEBUG - 2016-05-24 15:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:38:15 --> CSRF cookie sent
INFO - 2016-05-24 15:38:15 --> Input Class Initialized
INFO - 2016-05-24 15:38:15 --> Language Class Initialized
INFO - 2016-05-24 15:38:15 --> Loader Class Initialized
INFO - 2016-05-24 15:38:15 --> Helper loaded: form_helper
INFO - 2016-05-24 15:38:15 --> Database Driver Class Initialized
INFO - 2016-05-24 15:38:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:38:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:38:15 --> Email Class Initialized
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:38:15 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:38:15 --> Helper loaded: language_helper
INFO - 2016-05-24 15:38:15 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:15 --> Model Class Initialized
INFO - 2016-05-24 15:38:15 --> Helper loaded: date_helper
INFO - 2016-05-24 15:38:15 --> Controller Class Initialized
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:38:15 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 15:38:15 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:15 --> Form Validation Class Initialized
INFO - 2016-05-24 15:38:51 --> Config Class Initialized
INFO - 2016-05-24 15:38:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:38:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:38:51 --> Utf8 Class Initialized
INFO - 2016-05-24 15:38:51 --> URI Class Initialized
DEBUG - 2016-05-24 15:38:51 --> No URI present. Default controller set.
INFO - 2016-05-24 15:38:51 --> Router Class Initialized
INFO - 2016-05-24 15:38:51 --> Output Class Initialized
INFO - 2016-05-24 15:38:51 --> Security Class Initialized
DEBUG - 2016-05-24 15:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:38:51 --> CSRF cookie sent
INFO - 2016-05-24 15:38:51 --> Input Class Initialized
INFO - 2016-05-24 15:38:51 --> Language Class Initialized
INFO - 2016-05-24 15:38:51 --> Loader Class Initialized
INFO - 2016-05-24 15:38:51 --> Helper loaded: form_helper
INFO - 2016-05-24 15:38:51 --> Database Driver Class Initialized
INFO - 2016-05-24 15:38:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:38:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:38:51 --> Email Class Initialized
INFO - 2016-05-24 15:38:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:38:51 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:38:51 --> Helper loaded: language_helper
INFO - 2016-05-24 15:38:51 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:51 --> Model Class Initialized
INFO - 2016-05-24 15:38:51 --> Helper loaded: date_helper
INFO - 2016-05-24 15:38:51 --> Controller Class Initialized
INFO - 2016-05-24 15:38:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:38:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:38:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:38:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:38:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:38:52 --> Config Class Initialized
INFO - 2016-05-24 15:38:52 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:38:52 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:38:52 --> Utf8 Class Initialized
INFO - 2016-05-24 15:38:52 --> URI Class Initialized
INFO - 2016-05-24 15:38:52 --> Router Class Initialized
INFO - 2016-05-24 15:38:52 --> Output Class Initialized
INFO - 2016-05-24 15:38:52 --> Security Class Initialized
DEBUG - 2016-05-24 15:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:38:52 --> CSRF cookie sent
INFO - 2016-05-24 15:38:52 --> Input Class Initialized
INFO - 2016-05-24 15:38:52 --> Language Class Initialized
INFO - 2016-05-24 15:38:52 --> Loader Class Initialized
INFO - 2016-05-24 15:38:52 --> Helper loaded: form_helper
INFO - 2016-05-24 15:38:52 --> Database Driver Class Initialized
INFO - 2016-05-24 15:38:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:38:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:38:52 --> Email Class Initialized
INFO - 2016-05-24 15:38:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:38:52 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:38:52 --> Helper loaded: language_helper
INFO - 2016-05-24 15:38:52 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:38:52 --> Model Class Initialized
INFO - 2016-05-24 15:38:52 --> Helper loaded: date_helper
INFO - 2016-05-24 15:38:52 --> Controller Class Initialized
INFO - 2016-05-24 15:38:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:38:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:38:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:38:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:38:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:38:52 --> Model Class Initialized
ERROR - 2016-05-24 15:38:52 --> Severity: Error --> Call to undefined method Diabet::_get_csrf_nonce() /home/demis/www/platformadiabet/application/controllers/Diabet.php 26
INFO - 2016-05-24 15:41:54 --> Config Class Initialized
INFO - 2016-05-24 15:41:54 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:41:54 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:41:54 --> Utf8 Class Initialized
INFO - 2016-05-24 15:41:54 --> URI Class Initialized
INFO - 2016-05-24 15:41:54 --> Router Class Initialized
INFO - 2016-05-24 15:41:54 --> Output Class Initialized
INFO - 2016-05-24 15:41:54 --> Security Class Initialized
DEBUG - 2016-05-24 15:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:41:54 --> CSRF cookie sent
INFO - 2016-05-24 15:41:54 --> Input Class Initialized
INFO - 2016-05-24 15:41:54 --> Language Class Initialized
INFO - 2016-05-24 15:41:55 --> Loader Class Initialized
INFO - 2016-05-24 15:41:55 --> Helper loaded: form_helper
INFO - 2016-05-24 15:41:55 --> Database Driver Class Initialized
INFO - 2016-05-24 15:41:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:41:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:41:55 --> Email Class Initialized
INFO - 2016-05-24 15:41:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:41:55 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:41:55 --> Helper loaded: language_helper
INFO - 2016-05-24 15:41:55 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:41:55 --> Model Class Initialized
INFO - 2016-05-24 15:41:55 --> Helper loaded: date_helper
INFO - 2016-05-24 15:41:55 --> Controller Class Initialized
INFO - 2016-05-24 15:41:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:41:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:41:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:41:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:41:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:41:55 --> Model Class Initialized
INFO - 2016-05-24 15:41:55 --> Helper loaded: string_helper
ERROR - 2016-05-24 15:41:55 --> Severity: Notice --> Undefined variable: user /home/demis/www/platformadiabet/application/controllers/Diabet.php 32
ERROR - 2016-05-24 15:41:55 --> Severity: Notice --> Undefined variable: groups /home/demis/www/platformadiabet/application/controllers/Diabet.php 33
ERROR - 2016-05-24 15:41:55 --> Severity: Notice --> Undefined variable: currentGroups /home/demis/www/platformadiabet/application/controllers/Diabet.php 34
ERROR - 2016-05-24 15:41:55 --> Severity: Notice --> Undefined property: Diabet::$form_validation /home/demis/www/platformadiabet/application/controllers/Diabet.php 40
ERROR - 2016-05-24 15:41:55 --> Severity: Error --> Call to a member function set_value() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 40
INFO - 2016-05-24 15:45:55 --> Config Class Initialized
INFO - 2016-05-24 15:45:55 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:45:55 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:45:55 --> Utf8 Class Initialized
INFO - 2016-05-24 15:45:55 --> URI Class Initialized
INFO - 2016-05-24 15:45:55 --> Router Class Initialized
INFO - 2016-05-24 15:45:55 --> Output Class Initialized
INFO - 2016-05-24 15:45:55 --> Security Class Initialized
DEBUG - 2016-05-24 15:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:45:55 --> CSRF cookie sent
INFO - 2016-05-24 15:45:55 --> Input Class Initialized
INFO - 2016-05-24 15:45:55 --> Language Class Initialized
INFO - 2016-05-24 15:45:55 --> Loader Class Initialized
INFO - 2016-05-24 15:45:55 --> Helper loaded: form_helper
INFO - 2016-05-24 15:45:55 --> Database Driver Class Initialized
INFO - 2016-05-24 15:45:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:45:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:45:55 --> Email Class Initialized
INFO - 2016-05-24 15:45:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:45:55 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:45:55 --> Helper loaded: language_helper
INFO - 2016-05-24 15:45:55 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:45:55 --> Model Class Initialized
INFO - 2016-05-24 15:45:55 --> Helper loaded: date_helper
INFO - 2016-05-24 15:45:55 --> Controller Class Initialized
INFO - 2016-05-24 15:45:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:45:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:45:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:45:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:45:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:45:55 --> Model Class Initialized
ERROR - 2016-05-24 15:45:55 --> Severity: 4096 --> Object of class stdClass could not be converted to string /home/demis/www/platformadiabet/application/controllers/Diabet.php 27
ERROR - 2016-05-24 15:45:55 --> Severity: Notice --> Object of class stdClass to string conversion /home/demis/www/platformadiabet/application/controllers/Diabet.php 27
ERROR - 2016-05-24 15:45:55 --> Severity: Notice --> Undefined variable: Object /home/demis/www/platformadiabet/application/controllers/Diabet.php 27
ERROR - 2016-05-24 15:45:55 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/controllers/Diabet.php 27
INFO - 2016-05-24 15:45:55 --> Helper loaded: string_helper
ERROR - 2016-05-24 15:45:55 --> Severity: Notice --> Undefined property: Diabet::$form_validation /home/demis/www/platformadiabet/application/controllers/Diabet.php 44
ERROR - 2016-05-24 15:45:55 --> Severity: Error --> Call to a member function set_value() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 44
INFO - 2016-05-24 15:46:48 --> Config Class Initialized
INFO - 2016-05-24 15:46:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:46:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:46:48 --> Utf8 Class Initialized
INFO - 2016-05-24 15:46:48 --> URI Class Initialized
INFO - 2016-05-24 15:46:48 --> Router Class Initialized
INFO - 2016-05-24 15:46:48 --> Output Class Initialized
INFO - 2016-05-24 15:46:48 --> Security Class Initialized
DEBUG - 2016-05-24 15:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:46:48 --> CSRF cookie sent
INFO - 2016-05-24 15:46:48 --> Input Class Initialized
INFO - 2016-05-24 15:46:48 --> Language Class Initialized
INFO - 2016-05-24 15:46:48 --> Loader Class Initialized
INFO - 2016-05-24 15:46:48 --> Helper loaded: form_helper
INFO - 2016-05-24 15:46:48 --> Database Driver Class Initialized
INFO - 2016-05-24 15:46:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:46:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:46:48 --> Email Class Initialized
INFO - 2016-05-24 15:46:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:46:48 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:46:48 --> Helper loaded: language_helper
INFO - 2016-05-24 15:46:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:46:48 --> Model Class Initialized
INFO - 2016-05-24 15:46:48 --> Helper loaded: date_helper
INFO - 2016-05-24 15:46:48 --> Controller Class Initialized
INFO - 2016-05-24 15:46:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:46:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:46:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:46:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:46:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:46:48 --> Model Class Initialized
INFO - 2016-05-24 15:46:48 --> Helper loaded: string_helper
ERROR - 2016-05-24 15:46:48 --> Severity: Notice --> Undefined property: Diabet::$form_validation /home/demis/www/platformadiabet/application/controllers/Diabet.php 46
ERROR - 2016-05-24 15:46:48 --> Severity: Error --> Call to a member function set_value() on null /home/demis/www/platformadiabet/application/controllers/Diabet.php 46
INFO - 2016-05-24 15:48:31 --> Config Class Initialized
INFO - 2016-05-24 15:48:31 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:48:31 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:48:31 --> Utf8 Class Initialized
INFO - 2016-05-24 15:48:31 --> URI Class Initialized
INFO - 2016-05-24 15:48:31 --> Router Class Initialized
INFO - 2016-05-24 15:48:31 --> Output Class Initialized
INFO - 2016-05-24 15:48:31 --> Security Class Initialized
DEBUG - 2016-05-24 15:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:48:31 --> CSRF cookie sent
INFO - 2016-05-24 15:48:31 --> Input Class Initialized
INFO - 2016-05-24 15:48:31 --> Language Class Initialized
INFO - 2016-05-24 15:48:31 --> Loader Class Initialized
INFO - 2016-05-24 15:48:31 --> Helper loaded: form_helper
INFO - 2016-05-24 15:48:31 --> Database Driver Class Initialized
INFO - 2016-05-24 15:48:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:48:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:48:31 --> Email Class Initialized
INFO - 2016-05-24 15:48:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:48:31 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:48:31 --> Helper loaded: language_helper
INFO - 2016-05-24 15:48:31 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:48:31 --> Model Class Initialized
INFO - 2016-05-24 15:48:31 --> Helper loaded: date_helper
INFO - 2016-05-24 15:48:31 --> Controller Class Initialized
INFO - 2016-05-24 15:48:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:48:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:48:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:48:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:48:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:48:31 --> Model Class Initialized
INFO - 2016-05-24 15:48:31 --> Form Validation Class Initialized
INFO - 2016-05-24 15:48:31 --> Helper loaded: string_helper
INFO - 2016-05-24 15:48:31 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:48:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:48:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:48:31 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:48:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:48:31 --> Final output sent to browser
DEBUG - 2016-05-24 15:48:31 --> Total execution time: 0.1122
INFO - 2016-05-24 15:50:33 --> Config Class Initialized
INFO - 2016-05-24 15:50:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:50:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:50:33 --> Utf8 Class Initialized
INFO - 2016-05-24 15:50:33 --> URI Class Initialized
INFO - 2016-05-24 15:50:33 --> Router Class Initialized
INFO - 2016-05-24 15:50:33 --> Output Class Initialized
INFO - 2016-05-24 15:50:33 --> Security Class Initialized
DEBUG - 2016-05-24 15:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:50:33 --> CSRF cookie sent
INFO - 2016-05-24 15:50:33 --> Input Class Initialized
INFO - 2016-05-24 15:50:33 --> Language Class Initialized
INFO - 2016-05-24 15:50:33 --> Loader Class Initialized
INFO - 2016-05-24 15:50:33 --> Helper loaded: form_helper
INFO - 2016-05-24 15:50:33 --> Database Driver Class Initialized
INFO - 2016-05-24 15:50:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:50:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:50:33 --> Email Class Initialized
INFO - 2016-05-24 15:50:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:50:33 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:50:33 --> Helper loaded: language_helper
INFO - 2016-05-24 15:50:33 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:50:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:50:33 --> Model Class Initialized
INFO - 2016-05-24 15:50:33 --> Helper loaded: date_helper
INFO - 2016-05-24 15:50:33 --> Controller Class Initialized
INFO - 2016-05-24 15:50:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:50:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:50:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:50:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:50:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:50:33 --> Model Class Initialized
INFO - 2016-05-24 15:50:33 --> Form Validation Class Initialized
INFO - 2016-05-24 15:50:33 --> Helper loaded: string_helper
INFO - 2016-05-24 15:50:33 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:50:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:50:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:50:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:50:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:50:34 --> Final output sent to browser
DEBUG - 2016-05-24 15:50:34 --> Total execution time: 0.0820
INFO - 2016-05-24 15:52:48 --> Config Class Initialized
INFO - 2016-05-24 15:52:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:52:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:52:48 --> Utf8 Class Initialized
INFO - 2016-05-24 15:52:48 --> URI Class Initialized
INFO - 2016-05-24 15:52:48 --> Router Class Initialized
INFO - 2016-05-24 15:52:48 --> Output Class Initialized
INFO - 2016-05-24 15:52:48 --> Security Class Initialized
DEBUG - 2016-05-24 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:52:48 --> CSRF cookie sent
INFO - 2016-05-24 15:52:48 --> Input Class Initialized
INFO - 2016-05-24 15:52:48 --> Language Class Initialized
INFO - 2016-05-24 15:52:48 --> Loader Class Initialized
INFO - 2016-05-24 15:52:48 --> Helper loaded: form_helper
INFO - 2016-05-24 15:52:48 --> Database Driver Class Initialized
INFO - 2016-05-24 15:52:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:52:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:52:48 --> Email Class Initialized
INFO - 2016-05-24 15:52:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:52:48 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:52:48 --> Helper loaded: language_helper
INFO - 2016-05-24 15:52:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:52:48 --> Model Class Initialized
INFO - 2016-05-24 15:52:48 --> Helper loaded: date_helper
INFO - 2016-05-24 15:52:48 --> Controller Class Initialized
INFO - 2016-05-24 15:52:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:52:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:52:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:52:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:52:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:52:48 --> Model Class Initialized
INFO - 2016-05-24 15:52:48 --> Form Validation Class Initialized
INFO - 2016-05-24 15:52:48 --> Helper loaded: string_helper
INFO - 2016-05-24 15:52:48 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:52:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:52:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:52:48 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:52:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:52:48 --> Final output sent to browser
DEBUG - 2016-05-24 15:52:48 --> Total execution time: 0.0846
INFO - 2016-05-24 15:55:17 --> Config Class Initialized
INFO - 2016-05-24 15:55:17 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:55:17 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:55:17 --> Utf8 Class Initialized
INFO - 2016-05-24 15:55:17 --> URI Class Initialized
INFO - 2016-05-24 15:55:17 --> Router Class Initialized
INFO - 2016-05-24 15:55:17 --> Output Class Initialized
INFO - 2016-05-24 15:55:17 --> Security Class Initialized
DEBUG - 2016-05-24 15:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:55:17 --> CSRF cookie sent
INFO - 2016-05-24 15:55:17 --> Input Class Initialized
INFO - 2016-05-24 15:55:17 --> Language Class Initialized
INFO - 2016-05-24 15:55:17 --> Loader Class Initialized
INFO - 2016-05-24 15:55:17 --> Helper loaded: form_helper
INFO - 2016-05-24 15:55:17 --> Database Driver Class Initialized
INFO - 2016-05-24 15:55:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:55:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:55:17 --> Email Class Initialized
INFO - 2016-05-24 15:55:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:55:17 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:55:17 --> Helper loaded: language_helper
INFO - 2016-05-24 15:55:17 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:55:17 --> Model Class Initialized
INFO - 2016-05-24 15:55:17 --> Helper loaded: date_helper
INFO - 2016-05-24 15:55:17 --> Controller Class Initialized
INFO - 2016-05-24 15:55:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:55:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:55:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:55:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:55:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:55:17 --> Model Class Initialized
INFO - 2016-05-24 15:55:17 --> Form Validation Class Initialized
INFO - 2016-05-24 15:55:17 --> Helper loaded: string_helper
INFO - 2016-05-24 15:55:17 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:55:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:55:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:55:17 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:55:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:55:17 --> Final output sent to browser
DEBUG - 2016-05-24 15:55:17 --> Total execution time: 0.0648
INFO - 2016-05-24 15:55:42 --> Config Class Initialized
INFO - 2016-05-24 15:55:42 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:55:42 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:55:42 --> Utf8 Class Initialized
INFO - 2016-05-24 15:55:42 --> URI Class Initialized
INFO - 2016-05-24 15:55:42 --> Router Class Initialized
INFO - 2016-05-24 15:55:42 --> Output Class Initialized
INFO - 2016-05-24 15:55:42 --> Security Class Initialized
DEBUG - 2016-05-24 15:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:55:42 --> CSRF cookie sent
INFO - 2016-05-24 15:55:42 --> Input Class Initialized
INFO - 2016-05-24 15:55:42 --> Language Class Initialized
INFO - 2016-05-24 15:55:42 --> Loader Class Initialized
INFO - 2016-05-24 15:55:42 --> Helper loaded: form_helper
INFO - 2016-05-24 15:55:42 --> Database Driver Class Initialized
INFO - 2016-05-24 15:55:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:55:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:55:42 --> Email Class Initialized
INFO - 2016-05-24 15:55:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:55:42 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:55:42 --> Helper loaded: language_helper
INFO - 2016-05-24 15:55:42 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:55:42 --> Model Class Initialized
INFO - 2016-05-24 15:55:42 --> Helper loaded: date_helper
INFO - 2016-05-24 15:55:42 --> Controller Class Initialized
INFO - 2016-05-24 15:55:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:55:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:55:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:55:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:55:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:55:42 --> Model Class Initialized
INFO - 2016-05-24 15:55:42 --> Form Validation Class Initialized
INFO - 2016-05-24 15:55:42 --> Helper loaded: string_helper
INFO - 2016-05-24 15:55:42 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:55:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:55:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:55:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:55:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:55:42 --> Final output sent to browser
DEBUG - 2016-05-24 15:55:42 --> Total execution time: 0.0458
INFO - 2016-05-24 15:56:48 --> Config Class Initialized
INFO - 2016-05-24 15:56:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:56:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:56:48 --> Utf8 Class Initialized
INFO - 2016-05-24 15:56:48 --> URI Class Initialized
INFO - 2016-05-24 15:56:48 --> Router Class Initialized
INFO - 2016-05-24 15:56:48 --> Output Class Initialized
INFO - 2016-05-24 15:56:48 --> Security Class Initialized
DEBUG - 2016-05-24 15:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:56:48 --> CSRF cookie sent
INFO - 2016-05-24 15:56:48 --> Input Class Initialized
INFO - 2016-05-24 15:56:48 --> Language Class Initialized
INFO - 2016-05-24 15:56:48 --> Loader Class Initialized
INFO - 2016-05-24 15:56:48 --> Helper loaded: form_helper
INFO - 2016-05-24 15:56:48 --> Database Driver Class Initialized
INFO - 2016-05-24 15:56:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:56:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:56:48 --> Email Class Initialized
INFO - 2016-05-24 15:56:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:56:48 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:56:48 --> Helper loaded: language_helper
INFO - 2016-05-24 15:56:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:56:48 --> Model Class Initialized
INFO - 2016-05-24 15:56:48 --> Helper loaded: date_helper
INFO - 2016-05-24 15:56:48 --> Controller Class Initialized
INFO - 2016-05-24 15:56:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:56:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:56:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:56:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:56:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:56:48 --> Model Class Initialized
INFO - 2016-05-24 15:56:48 --> Form Validation Class Initialized
INFO - 2016-05-24 15:56:48 --> Helper loaded: string_helper
INFO - 2016-05-24 15:56:48 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:56:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:56:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:56:48 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:56:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:56:48 --> Final output sent to browser
DEBUG - 2016-05-24 15:56:48 --> Total execution time: 0.0626
INFO - 2016-05-24 15:57:03 --> Config Class Initialized
INFO - 2016-05-24 15:57:03 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:57:03 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:57:03 --> Utf8 Class Initialized
INFO - 2016-05-24 15:57:03 --> URI Class Initialized
INFO - 2016-05-24 15:57:03 --> Router Class Initialized
INFO - 2016-05-24 15:57:03 --> Output Class Initialized
INFO - 2016-05-24 15:57:03 --> Security Class Initialized
DEBUG - 2016-05-24 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:57:03 --> CSRF cookie sent
INFO - 2016-05-24 15:57:03 --> Input Class Initialized
INFO - 2016-05-24 15:57:03 --> Language Class Initialized
INFO - 2016-05-24 15:57:03 --> Loader Class Initialized
INFO - 2016-05-24 15:57:03 --> Helper loaded: form_helper
INFO - 2016-05-24 15:57:03 --> Database Driver Class Initialized
INFO - 2016-05-24 15:57:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:57:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:57:03 --> Email Class Initialized
INFO - 2016-05-24 15:57:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:57:03 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:57:03 --> Helper loaded: language_helper
INFO - 2016-05-24 15:57:03 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:57:03 --> Model Class Initialized
INFO - 2016-05-24 15:57:03 --> Helper loaded: date_helper
INFO - 2016-05-24 15:57:03 --> Controller Class Initialized
INFO - 2016-05-24 15:57:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:57:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:57:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:57:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:57:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:57:03 --> Model Class Initialized
INFO - 2016-05-24 15:57:03 --> Form Validation Class Initialized
INFO - 2016-05-24 15:57:03 --> Helper loaded: string_helper
INFO - 2016-05-24 15:57:03 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:57:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:57:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:57:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:57:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:57:03 --> Final output sent to browser
DEBUG - 2016-05-24 15:57:03 --> Total execution time: 0.0558
INFO - 2016-05-24 15:57:17 --> Config Class Initialized
INFO - 2016-05-24 15:57:17 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:57:17 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:57:17 --> Utf8 Class Initialized
INFO - 2016-05-24 15:57:17 --> URI Class Initialized
INFO - 2016-05-24 15:57:17 --> Router Class Initialized
INFO - 2016-05-24 15:57:17 --> Output Class Initialized
INFO - 2016-05-24 15:57:17 --> Security Class Initialized
DEBUG - 2016-05-24 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:57:17 --> CSRF cookie sent
INFO - 2016-05-24 15:57:17 --> Input Class Initialized
INFO - 2016-05-24 15:57:17 --> Language Class Initialized
INFO - 2016-05-24 15:57:17 --> Loader Class Initialized
INFO - 2016-05-24 15:57:17 --> Helper loaded: form_helper
INFO - 2016-05-24 15:57:17 --> Database Driver Class Initialized
INFO - 2016-05-24 15:57:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:57:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:57:17 --> Email Class Initialized
INFO - 2016-05-24 15:57:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:57:17 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:57:17 --> Helper loaded: language_helper
INFO - 2016-05-24 15:57:17 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:57:17 --> Model Class Initialized
INFO - 2016-05-24 15:57:17 --> Helper loaded: date_helper
INFO - 2016-05-24 15:57:17 --> Controller Class Initialized
INFO - 2016-05-24 15:57:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:57:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:57:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:57:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:57:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:57:17 --> Model Class Initialized
INFO - 2016-05-24 15:57:17 --> Form Validation Class Initialized
INFO - 2016-05-24 15:57:17 --> Helper loaded: string_helper
INFO - 2016-05-24 15:57:17 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:57:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:57:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:57:17 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:57:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:57:17 --> Final output sent to browser
DEBUG - 2016-05-24 15:57:17 --> Total execution time: 0.0562
INFO - 2016-05-24 15:59:46 --> Config Class Initialized
INFO - 2016-05-24 15:59:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 15:59:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 15:59:46 --> Utf8 Class Initialized
INFO - 2016-05-24 15:59:46 --> URI Class Initialized
INFO - 2016-05-24 15:59:46 --> Router Class Initialized
INFO - 2016-05-24 15:59:46 --> Output Class Initialized
INFO - 2016-05-24 15:59:46 --> Security Class Initialized
DEBUG - 2016-05-24 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 15:59:46 --> CSRF cookie sent
INFO - 2016-05-24 15:59:46 --> Input Class Initialized
INFO - 2016-05-24 15:59:46 --> Language Class Initialized
INFO - 2016-05-24 15:59:46 --> Loader Class Initialized
INFO - 2016-05-24 15:59:46 --> Helper loaded: form_helper
INFO - 2016-05-24 15:59:46 --> Database Driver Class Initialized
INFO - 2016-05-24 15:59:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 15:59:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 15:59:46 --> Email Class Initialized
INFO - 2016-05-24 15:59:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 15:59:46 --> Helper loaded: cookie_helper
INFO - 2016-05-24 15:59:46 --> Helper loaded: language_helper
INFO - 2016-05-24 15:59:46 --> Helper loaded: url_helper
DEBUG - 2016-05-24 15:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 15:59:46 --> Model Class Initialized
INFO - 2016-05-24 15:59:46 --> Helper loaded: date_helper
INFO - 2016-05-24 15:59:46 --> Controller Class Initialized
INFO - 2016-05-24 15:59:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 15:59:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 15:59:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 15:59:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 15:59:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 15:59:46 --> Model Class Initialized
INFO - 2016-05-24 15:59:46 --> Form Validation Class Initialized
INFO - 2016-05-24 15:59:46 --> Helper loaded: string_helper
INFO - 2016-05-24 15:59:46 --> Helper loaded: languages_helper
INFO - 2016-05-24 15:59:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 15:59:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 15:59:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 15:59:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 15:59:46 --> Final output sent to browser
DEBUG - 2016-05-24 15:59:46 --> Total execution time: 0.0771
INFO - 2016-05-24 16:02:35 --> Config Class Initialized
INFO - 2016-05-24 16:02:35 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:02:35 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:02:35 --> Utf8 Class Initialized
INFO - 2016-05-24 16:02:35 --> URI Class Initialized
INFO - 2016-05-24 16:02:35 --> Router Class Initialized
INFO - 2016-05-24 16:02:35 --> Output Class Initialized
INFO - 2016-05-24 16:02:35 --> Security Class Initialized
DEBUG - 2016-05-24 16:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:02:35 --> CSRF cookie sent
INFO - 2016-05-24 16:02:35 --> Input Class Initialized
INFO - 2016-05-24 16:02:35 --> Language Class Initialized
INFO - 2016-05-24 16:02:35 --> Loader Class Initialized
INFO - 2016-05-24 16:02:35 --> Helper loaded: form_helper
INFO - 2016-05-24 16:02:35 --> Database Driver Class Initialized
INFO - 2016-05-24 16:02:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:02:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:02:35 --> Email Class Initialized
INFO - 2016-05-24 16:02:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:02:35 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:02:35 --> Helper loaded: language_helper
INFO - 2016-05-24 16:02:35 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:02:35 --> Model Class Initialized
INFO - 2016-05-24 16:02:35 --> Helper loaded: date_helper
INFO - 2016-05-24 16:02:35 --> Controller Class Initialized
INFO - 2016-05-24 16:02:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:02:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:02:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:02:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:02:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:02:35 --> Model Class Initialized
INFO - 2016-05-24 16:02:35 --> Form Validation Class Initialized
INFO - 2016-05-24 16:02:35 --> Helper loaded: string_helper
INFO - 2016-05-24 16:02:35 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:02:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:02:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:02:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:02:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:02:35 --> Final output sent to browser
DEBUG - 2016-05-24 16:02:35 --> Total execution time: 0.0471
INFO - 2016-05-24 16:05:51 --> Config Class Initialized
INFO - 2016-05-24 16:05:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:05:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:05:51 --> Utf8 Class Initialized
INFO - 2016-05-24 16:05:51 --> URI Class Initialized
INFO - 2016-05-24 16:05:51 --> Router Class Initialized
INFO - 2016-05-24 16:05:51 --> Output Class Initialized
INFO - 2016-05-24 16:05:51 --> Security Class Initialized
DEBUG - 2016-05-24 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:05:51 --> CSRF cookie sent
INFO - 2016-05-24 16:05:51 --> Input Class Initialized
INFO - 2016-05-24 16:05:51 --> Language Class Initialized
INFO - 2016-05-24 16:05:51 --> Loader Class Initialized
INFO - 2016-05-24 16:05:51 --> Helper loaded: form_helper
INFO - 2016-05-24 16:05:51 --> Database Driver Class Initialized
INFO - 2016-05-24 16:05:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:05:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:05:51 --> Email Class Initialized
INFO - 2016-05-24 16:05:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:05:51 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:05:51 --> Helper loaded: language_helper
INFO - 2016-05-24 16:05:51 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:05:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:05:51 --> Model Class Initialized
INFO - 2016-05-24 16:05:51 --> Helper loaded: date_helper
INFO - 2016-05-24 16:05:51 --> Controller Class Initialized
INFO - 2016-05-24 16:05:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:05:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:05:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:05:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:05:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:05:51 --> Model Class Initialized
INFO - 2016-05-24 16:05:51 --> Form Validation Class Initialized
INFO - 2016-05-24 16:05:51 --> Helper loaded: string_helper
INFO - 2016-05-24 16:05:51 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:05:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:05:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:05:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:05:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:05:51 --> Final output sent to browser
DEBUG - 2016-05-24 16:05:51 --> Total execution time: 0.1205
INFO - 2016-05-24 16:09:48 --> Config Class Initialized
INFO - 2016-05-24 16:09:48 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:09:48 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:09:48 --> Utf8 Class Initialized
INFO - 2016-05-24 16:09:48 --> URI Class Initialized
INFO - 2016-05-24 16:09:48 --> Router Class Initialized
INFO - 2016-05-24 16:09:48 --> Output Class Initialized
INFO - 2016-05-24 16:09:48 --> Security Class Initialized
DEBUG - 2016-05-24 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:09:48 --> CSRF cookie sent
INFO - 2016-05-24 16:09:48 --> Input Class Initialized
INFO - 2016-05-24 16:09:48 --> Language Class Initialized
INFO - 2016-05-24 16:09:48 --> Loader Class Initialized
INFO - 2016-05-24 16:09:48 --> Helper loaded: form_helper
INFO - 2016-05-24 16:09:48 --> Database Driver Class Initialized
INFO - 2016-05-24 16:09:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:09:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:09:48 --> Email Class Initialized
INFO - 2016-05-24 16:09:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:09:48 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:09:48 --> Helper loaded: language_helper
INFO - 2016-05-24 16:09:48 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:09:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:09:48 --> Model Class Initialized
INFO - 2016-05-24 16:09:48 --> Helper loaded: date_helper
INFO - 2016-05-24 16:09:48 --> Controller Class Initialized
INFO - 2016-05-24 16:09:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:09:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:09:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:09:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:09:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:09:48 --> Model Class Initialized
INFO - 2016-05-24 16:09:48 --> Form Validation Class Initialized
INFO - 2016-05-24 16:09:48 --> Helper loaded: string_helper
INFO - 2016-05-24 16:09:48 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:09:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:09:48 --> Final output sent to browser
DEBUG - 2016-05-24 16:09:48 --> Total execution time: 0.1189
INFO - 2016-05-24 16:11:51 --> Config Class Initialized
INFO - 2016-05-24 16:11:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:11:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:11:51 --> Utf8 Class Initialized
INFO - 2016-05-24 16:11:51 --> URI Class Initialized
INFO - 2016-05-24 16:11:51 --> Router Class Initialized
INFO - 2016-05-24 16:11:51 --> Output Class Initialized
INFO - 2016-05-24 16:11:51 --> Security Class Initialized
DEBUG - 2016-05-24 16:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:11:51 --> CSRF cookie sent
INFO - 2016-05-24 16:11:51 --> Input Class Initialized
INFO - 2016-05-24 16:11:51 --> Language Class Initialized
INFO - 2016-05-24 16:11:51 --> Loader Class Initialized
INFO - 2016-05-24 16:11:51 --> Helper loaded: form_helper
INFO - 2016-05-24 16:11:51 --> Database Driver Class Initialized
INFO - 2016-05-24 16:11:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:11:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:11:51 --> Email Class Initialized
INFO - 2016-05-24 16:11:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:11:51 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:11:51 --> Helper loaded: language_helper
INFO - 2016-05-24 16:11:51 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:11:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:11:51 --> Model Class Initialized
INFO - 2016-05-24 16:11:51 --> Helper loaded: date_helper
INFO - 2016-05-24 16:11:51 --> Controller Class Initialized
INFO - 2016-05-24 16:11:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:11:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:11:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:11:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:11:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:11:51 --> Model Class Initialized
INFO - 2016-05-24 16:11:51 --> Form Validation Class Initialized
INFO - 2016-05-24 16:11:51 --> Helper loaded: string_helper
INFO - 2016-05-24 16:11:51 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:11:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:11:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:11:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:11:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:11:51 --> Final output sent to browser
DEBUG - 2016-05-24 16:11:51 --> Total execution time: 0.1139
INFO - 2016-05-24 16:12:35 --> Config Class Initialized
INFO - 2016-05-24 16:12:35 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:12:35 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:12:35 --> Utf8 Class Initialized
INFO - 2016-05-24 16:12:35 --> URI Class Initialized
INFO - 2016-05-24 16:12:35 --> Router Class Initialized
INFO - 2016-05-24 16:12:35 --> Output Class Initialized
INFO - 2016-05-24 16:12:35 --> Security Class Initialized
DEBUG - 2016-05-24 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:12:35 --> CSRF cookie sent
INFO - 2016-05-24 16:12:35 --> Input Class Initialized
INFO - 2016-05-24 16:12:35 --> Language Class Initialized
INFO - 2016-05-24 16:12:35 --> Loader Class Initialized
INFO - 2016-05-24 16:12:35 --> Helper loaded: form_helper
INFO - 2016-05-24 16:12:35 --> Database Driver Class Initialized
INFO - 2016-05-24 16:12:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:12:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:12:35 --> Email Class Initialized
INFO - 2016-05-24 16:12:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:12:35 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:12:35 --> Helper loaded: language_helper
INFO - 2016-05-24 16:12:35 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:12:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:12:35 --> Model Class Initialized
INFO - 2016-05-24 16:12:35 --> Helper loaded: date_helper
INFO - 2016-05-24 16:12:35 --> Controller Class Initialized
INFO - 2016-05-24 16:12:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:12:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:12:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:12:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:12:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:12:35 --> Model Class Initialized
INFO - 2016-05-24 16:12:35 --> Form Validation Class Initialized
INFO - 2016-05-24 16:12:35 --> Helper loaded: string_helper
INFO - 2016-05-24 16:12:35 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:12:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:12:35 --> Final output sent to browser
DEBUG - 2016-05-24 16:12:35 --> Total execution time: 0.0891
INFO - 2016-05-24 16:22:20 --> Config Class Initialized
INFO - 2016-05-24 16:22:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:22:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:22:20 --> Utf8 Class Initialized
INFO - 2016-05-24 16:22:20 --> URI Class Initialized
INFO - 2016-05-24 16:22:20 --> Router Class Initialized
INFO - 2016-05-24 16:22:20 --> Output Class Initialized
INFO - 2016-05-24 16:22:20 --> Security Class Initialized
DEBUG - 2016-05-24 16:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:22:20 --> CSRF cookie sent
INFO - 2016-05-24 16:22:20 --> Input Class Initialized
INFO - 2016-05-24 16:22:20 --> Language Class Initialized
INFO - 2016-05-24 16:22:20 --> Loader Class Initialized
INFO - 2016-05-24 16:22:20 --> Helper loaded: form_helper
INFO - 2016-05-24 16:22:20 --> Database Driver Class Initialized
INFO - 2016-05-24 16:22:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:22:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:22:20 --> Email Class Initialized
INFO - 2016-05-24 16:22:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:22:20 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:22:20 --> Helper loaded: language_helper
INFO - 2016-05-24 16:22:20 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:22:20 --> Model Class Initialized
INFO - 2016-05-24 16:22:20 --> Helper loaded: date_helper
INFO - 2016-05-24 16:22:20 --> Controller Class Initialized
INFO - 2016-05-24 16:22:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:22:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:22:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:22:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:22:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:22:20 --> Model Class Initialized
INFO - 2016-05-24 16:22:20 --> Form Validation Class Initialized
INFO - 2016-05-24 16:22:20 --> Helper loaded: string_helper
INFO - 2016-05-24 16:22:20 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:22:20 --> Final output sent to browser
DEBUG - 2016-05-24 16:22:20 --> Total execution time: 0.0900
INFO - 2016-05-24 16:30:01 --> Config Class Initialized
INFO - 2016-05-24 16:30:01 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:30:01 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:30:01 --> Utf8 Class Initialized
INFO - 2016-05-24 16:30:01 --> URI Class Initialized
INFO - 2016-05-24 16:30:01 --> Router Class Initialized
INFO - 2016-05-24 16:30:01 --> Output Class Initialized
INFO - 2016-05-24 16:30:01 --> Security Class Initialized
DEBUG - 2016-05-24 16:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:30:01 --> CSRF cookie sent
INFO - 2016-05-24 16:30:01 --> Input Class Initialized
INFO - 2016-05-24 16:30:01 --> Language Class Initialized
INFO - 2016-05-24 16:30:01 --> Loader Class Initialized
INFO - 2016-05-24 16:30:01 --> Helper loaded: form_helper
INFO - 2016-05-24 16:30:01 --> Database Driver Class Initialized
INFO - 2016-05-24 16:30:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:30:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:30:02 --> Email Class Initialized
INFO - 2016-05-24 16:30:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:30:02 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:30:02 --> Helper loaded: language_helper
INFO - 2016-05-24 16:30:02 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:30:02 --> Model Class Initialized
INFO - 2016-05-24 16:30:02 --> Helper loaded: date_helper
INFO - 2016-05-24 16:30:02 --> Controller Class Initialized
INFO - 2016-05-24 16:30:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:30:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:30:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:30:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:30:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:30:02 --> Model Class Initialized
INFO - 2016-05-24 16:30:02 --> Form Validation Class Initialized
INFO - 2016-05-24 16:30:02 --> Helper loaded: string_helper
INFO - 2016-05-24 16:30:02 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:30:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:30:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:30:02 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:30:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:30:02 --> Final output sent to browser
DEBUG - 2016-05-24 16:30:02 --> Total execution time: 0.1265
INFO - 2016-05-24 16:33:36 --> Config Class Initialized
INFO - 2016-05-24 16:33:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:33:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:33:36 --> Utf8 Class Initialized
INFO - 2016-05-24 16:33:36 --> URI Class Initialized
INFO - 2016-05-24 16:33:36 --> Router Class Initialized
INFO - 2016-05-24 16:33:36 --> Output Class Initialized
INFO - 2016-05-24 16:33:36 --> Security Class Initialized
DEBUG - 2016-05-24 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:33:36 --> CSRF cookie sent
INFO - 2016-05-24 16:33:36 --> Input Class Initialized
INFO - 2016-05-24 16:33:36 --> Language Class Initialized
INFO - 2016-05-24 16:33:36 --> Loader Class Initialized
INFO - 2016-05-24 16:33:36 --> Helper loaded: form_helper
INFO - 2016-05-24 16:33:36 --> Database Driver Class Initialized
INFO - 2016-05-24 16:33:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:33:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:33:36 --> Email Class Initialized
INFO - 2016-05-24 16:33:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:33:36 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:33:36 --> Helper loaded: language_helper
INFO - 2016-05-24 16:33:36 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:33:36 --> Model Class Initialized
INFO - 2016-05-24 16:33:36 --> Helper loaded: date_helper
INFO - 2016-05-24 16:33:36 --> Controller Class Initialized
INFO - 2016-05-24 16:33:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:33:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:33:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:33:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:33:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:33:36 --> Model Class Initialized
INFO - 2016-05-24 16:33:36 --> Form Validation Class Initialized
INFO - 2016-05-24 16:33:36 --> Helper loaded: string_helper
INFO - 2016-05-24 16:33:36 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:33:36 --> Final output sent to browser
DEBUG - 2016-05-24 16:33:36 --> Total execution time: 0.1215
INFO - 2016-05-24 16:33:51 --> Config Class Initialized
INFO - 2016-05-24 16:33:51 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:33:51 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:33:51 --> Utf8 Class Initialized
INFO - 2016-05-24 16:33:51 --> URI Class Initialized
INFO - 2016-05-24 16:33:51 --> Router Class Initialized
INFO - 2016-05-24 16:33:51 --> Output Class Initialized
INFO - 2016-05-24 16:33:51 --> Security Class Initialized
DEBUG - 2016-05-24 16:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:33:51 --> CSRF cookie sent
INFO - 2016-05-24 16:33:51 --> Input Class Initialized
INFO - 2016-05-24 16:33:51 --> Language Class Initialized
INFO - 2016-05-24 16:33:51 --> Loader Class Initialized
INFO - 2016-05-24 16:33:51 --> Helper loaded: form_helper
INFO - 2016-05-24 16:33:51 --> Database Driver Class Initialized
INFO - 2016-05-24 16:33:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:33:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:33:51 --> Email Class Initialized
INFO - 2016-05-24 16:33:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:33:51 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:33:51 --> Helper loaded: language_helper
INFO - 2016-05-24 16:33:51 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:33:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:33:51 --> Model Class Initialized
INFO - 2016-05-24 16:33:51 --> Helper loaded: date_helper
INFO - 2016-05-24 16:33:51 --> Controller Class Initialized
INFO - 2016-05-24 16:33:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:33:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:33:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:33:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:33:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:33:51 --> Model Class Initialized
INFO - 2016-05-24 16:33:51 --> Form Validation Class Initialized
INFO - 2016-05-24 16:33:51 --> Helper loaded: string_helper
INFO - 2016-05-24 16:33:51 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:33:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:33:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:33:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:33:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:33:51 --> Final output sent to browser
DEBUG - 2016-05-24 16:33:51 --> Total execution time: 0.0648
INFO - 2016-05-24 16:34:07 --> Config Class Initialized
INFO - 2016-05-24 16:34:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:34:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:34:07 --> Utf8 Class Initialized
INFO - 2016-05-24 16:34:07 --> URI Class Initialized
INFO - 2016-05-24 16:34:07 --> Router Class Initialized
INFO - 2016-05-24 16:34:07 --> Output Class Initialized
INFO - 2016-05-24 16:34:07 --> Security Class Initialized
DEBUG - 2016-05-24 16:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:34:07 --> CSRF cookie sent
INFO - 2016-05-24 16:34:07 --> Input Class Initialized
INFO - 2016-05-24 16:34:07 --> Language Class Initialized
INFO - 2016-05-24 16:34:07 --> Loader Class Initialized
INFO - 2016-05-24 16:34:07 --> Helper loaded: form_helper
INFO - 2016-05-24 16:34:07 --> Database Driver Class Initialized
INFO - 2016-05-24 16:34:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:34:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:34:07 --> Email Class Initialized
INFO - 2016-05-24 16:34:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:34:07 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:34:07 --> Helper loaded: language_helper
INFO - 2016-05-24 16:34:07 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:34:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:34:07 --> Model Class Initialized
INFO - 2016-05-24 16:34:07 --> Helper loaded: date_helper
INFO - 2016-05-24 16:34:07 --> Controller Class Initialized
INFO - 2016-05-24 16:34:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:34:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:34:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:34:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:34:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:34:07 --> Model Class Initialized
INFO - 2016-05-24 16:34:07 --> Form Validation Class Initialized
INFO - 2016-05-24 16:34:07 --> Helper loaded: string_helper
INFO - 2016-05-24 16:34:07 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:34:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:34:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:34:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:34:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:34:07 --> Final output sent to browser
DEBUG - 2016-05-24 16:34:07 --> Total execution time: 0.0548
INFO - 2016-05-24 16:37:01 --> Config Class Initialized
INFO - 2016-05-24 16:37:01 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:37:01 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:37:01 --> Utf8 Class Initialized
INFO - 2016-05-24 16:37:01 --> URI Class Initialized
INFO - 2016-05-24 16:37:01 --> Router Class Initialized
INFO - 2016-05-24 16:37:01 --> Output Class Initialized
INFO - 2016-05-24 16:37:01 --> Security Class Initialized
DEBUG - 2016-05-24 16:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:37:01 --> CSRF cookie sent
INFO - 2016-05-24 16:37:01 --> Input Class Initialized
INFO - 2016-05-24 16:37:01 --> Language Class Initialized
INFO - 2016-05-24 16:37:01 --> Loader Class Initialized
INFO - 2016-05-24 16:37:01 --> Helper loaded: form_helper
INFO - 2016-05-24 16:37:01 --> Database Driver Class Initialized
INFO - 2016-05-24 16:37:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:37:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:37:01 --> Email Class Initialized
INFO - 2016-05-24 16:37:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:37:01 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:37:01 --> Helper loaded: language_helper
INFO - 2016-05-24 16:37:01 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:37:01 --> Model Class Initialized
INFO - 2016-05-24 16:37:01 --> Helper loaded: date_helper
INFO - 2016-05-24 16:37:01 --> Controller Class Initialized
INFO - 2016-05-24 16:37:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:37:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:37:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:37:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:37:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:37:01 --> Model Class Initialized
INFO - 2016-05-24 16:37:01 --> Form Validation Class Initialized
INFO - 2016-05-24 16:37:01 --> Helper loaded: string_helper
INFO - 2016-05-24 16:37:01 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:37:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:37:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:37:01 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:37:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:37:01 --> Final output sent to browser
DEBUG - 2016-05-24 16:37:01 --> Total execution time: 0.1013
INFO - 2016-05-24 16:38:29 --> Config Class Initialized
INFO - 2016-05-24 16:38:29 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:38:29 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:38:29 --> Utf8 Class Initialized
INFO - 2016-05-24 16:38:29 --> URI Class Initialized
INFO - 2016-05-24 16:38:29 --> Router Class Initialized
INFO - 2016-05-24 16:38:29 --> Output Class Initialized
INFO - 2016-05-24 16:38:29 --> Security Class Initialized
DEBUG - 2016-05-24 16:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:38:29 --> CSRF cookie sent
INFO - 2016-05-24 16:38:29 --> Input Class Initialized
INFO - 2016-05-24 16:38:29 --> Language Class Initialized
INFO - 2016-05-24 16:38:29 --> Loader Class Initialized
INFO - 2016-05-24 16:38:29 --> Helper loaded: form_helper
INFO - 2016-05-24 16:38:29 --> Database Driver Class Initialized
INFO - 2016-05-24 16:38:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:38:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:38:29 --> Email Class Initialized
INFO - 2016-05-24 16:38:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:38:29 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:38:29 --> Helper loaded: language_helper
INFO - 2016-05-24 16:38:29 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:38:29 --> Model Class Initialized
INFO - 2016-05-24 16:38:29 --> Helper loaded: date_helper
INFO - 2016-05-24 16:38:29 --> Controller Class Initialized
INFO - 2016-05-24 16:38:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:38:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:38:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:38:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:38:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:38:29 --> Model Class Initialized
INFO - 2016-05-24 16:38:29 --> Form Validation Class Initialized
INFO - 2016-05-24 16:38:29 --> Helper loaded: string_helper
INFO - 2016-05-24 16:38:29 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:38:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:38:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:38:29 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:38:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:38:29 --> Final output sent to browser
DEBUG - 2016-05-24 16:38:29 --> Total execution time: 0.0768
INFO - 2016-05-24 16:40:08 --> Config Class Initialized
INFO - 2016-05-24 16:40:08 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:40:08 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:40:08 --> Utf8 Class Initialized
INFO - 2016-05-24 16:40:08 --> URI Class Initialized
INFO - 2016-05-24 16:40:08 --> Router Class Initialized
INFO - 2016-05-24 16:40:08 --> Output Class Initialized
INFO - 2016-05-24 16:40:08 --> Security Class Initialized
DEBUG - 2016-05-24 16:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:40:08 --> CSRF cookie sent
INFO - 2016-05-24 16:40:08 --> Input Class Initialized
INFO - 2016-05-24 16:40:08 --> Language Class Initialized
INFO - 2016-05-24 16:40:08 --> Loader Class Initialized
INFO - 2016-05-24 16:40:08 --> Helper loaded: form_helper
INFO - 2016-05-24 16:40:08 --> Database Driver Class Initialized
INFO - 2016-05-24 16:40:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:40:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:40:08 --> Email Class Initialized
INFO - 2016-05-24 16:40:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:40:08 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:40:08 --> Helper loaded: language_helper
INFO - 2016-05-24 16:40:08 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:40:08 --> Model Class Initialized
INFO - 2016-05-24 16:40:08 --> Helper loaded: date_helper
INFO - 2016-05-24 16:40:08 --> Controller Class Initialized
INFO - 2016-05-24 16:40:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:40:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:40:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:40:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:40:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:40:08 --> Model Class Initialized
INFO - 2016-05-24 16:40:08 --> Form Validation Class Initialized
INFO - 2016-05-24 16:40:08 --> Helper loaded: string_helper
INFO - 2016-05-24 16:40:08 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:40:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:40:08 --> Final output sent to browser
DEBUG - 2016-05-24 16:40:08 --> Total execution time: 0.0701
INFO - 2016-05-24 16:41:15 --> Config Class Initialized
INFO - 2016-05-24 16:41:15 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:41:15 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:41:15 --> Utf8 Class Initialized
INFO - 2016-05-24 16:41:15 --> URI Class Initialized
INFO - 2016-05-24 16:41:15 --> Router Class Initialized
INFO - 2016-05-24 16:41:15 --> Output Class Initialized
INFO - 2016-05-24 16:41:15 --> Security Class Initialized
DEBUG - 2016-05-24 16:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:41:15 --> CSRF cookie sent
INFO - 2016-05-24 16:41:15 --> Input Class Initialized
INFO - 2016-05-24 16:41:15 --> Language Class Initialized
INFO - 2016-05-24 16:41:15 --> Loader Class Initialized
INFO - 2016-05-24 16:41:15 --> Helper loaded: form_helper
INFO - 2016-05-24 16:41:15 --> Database Driver Class Initialized
INFO - 2016-05-24 16:41:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:41:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:41:15 --> Email Class Initialized
INFO - 2016-05-24 16:41:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:41:15 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:41:15 --> Helper loaded: language_helper
INFO - 2016-05-24 16:41:15 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:41:15 --> Model Class Initialized
INFO - 2016-05-24 16:41:15 --> Helper loaded: date_helper
INFO - 2016-05-24 16:41:15 --> Controller Class Initialized
INFO - 2016-05-24 16:41:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:41:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:41:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:41:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:41:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:41:15 --> Model Class Initialized
INFO - 2016-05-24 16:41:15 --> Form Validation Class Initialized
INFO - 2016-05-24 16:41:15 --> Helper loaded: string_helper
INFO - 2016-05-24 16:41:15 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:41:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:41:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:41:16 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:41:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:41:16 --> Final output sent to browser
DEBUG - 2016-05-24 16:41:16 --> Total execution time: 0.1437
INFO - 2016-05-24 16:41:22 --> Config Class Initialized
INFO - 2016-05-24 16:41:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:41:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:41:22 --> Utf8 Class Initialized
INFO - 2016-05-24 16:41:22 --> URI Class Initialized
INFO - 2016-05-24 16:41:22 --> Router Class Initialized
INFO - 2016-05-24 16:41:22 --> Output Class Initialized
INFO - 2016-05-24 16:41:22 --> Security Class Initialized
DEBUG - 2016-05-24 16:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:41:22 --> CSRF cookie sent
INFO - 2016-05-24 16:41:22 --> Input Class Initialized
INFO - 2016-05-24 16:41:22 --> Language Class Initialized
INFO - 2016-05-24 16:41:22 --> Loader Class Initialized
INFO - 2016-05-24 16:41:22 --> Helper loaded: form_helper
INFO - 2016-05-24 16:41:22 --> Database Driver Class Initialized
INFO - 2016-05-24 16:41:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:41:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:41:22 --> Email Class Initialized
INFO - 2016-05-24 16:41:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:41:22 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:41:22 --> Helper loaded: language_helper
INFO - 2016-05-24 16:41:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:41:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:41:22 --> Model Class Initialized
INFO - 2016-05-24 16:41:22 --> Helper loaded: date_helper
INFO - 2016-05-24 16:41:22 --> Controller Class Initialized
INFO - 2016-05-24 16:41:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:41:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:41:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:41:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:41:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:41:22 --> Model Class Initialized
INFO - 2016-05-24 16:41:22 --> Form Validation Class Initialized
INFO - 2016-05-24 16:41:22 --> Helper loaded: string_helper
INFO - 2016-05-24 16:41:22 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:41:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:41:22 --> Final output sent to browser
DEBUG - 2016-05-24 16:41:22 --> Total execution time: 0.0569
INFO - 2016-05-24 16:42:54 --> Config Class Initialized
INFO - 2016-05-24 16:42:54 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:42:54 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:42:54 --> Utf8 Class Initialized
INFO - 2016-05-24 16:42:54 --> URI Class Initialized
INFO - 2016-05-24 16:42:54 --> Router Class Initialized
INFO - 2016-05-24 16:42:54 --> Output Class Initialized
INFO - 2016-05-24 16:42:54 --> Security Class Initialized
DEBUG - 2016-05-24 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:42:54 --> CSRF cookie sent
INFO - 2016-05-24 16:42:54 --> Input Class Initialized
INFO - 2016-05-24 16:42:54 --> Language Class Initialized
INFO - 2016-05-24 16:42:54 --> Loader Class Initialized
INFO - 2016-05-24 16:42:54 --> Helper loaded: form_helper
INFO - 2016-05-24 16:42:54 --> Database Driver Class Initialized
INFO - 2016-05-24 16:42:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:42:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:42:54 --> Email Class Initialized
INFO - 2016-05-24 16:42:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:42:55 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:42:55 --> Helper loaded: language_helper
INFO - 2016-05-24 16:42:55 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:42:55 --> Model Class Initialized
INFO - 2016-05-24 16:42:55 --> Helper loaded: date_helper
INFO - 2016-05-24 16:42:55 --> Controller Class Initialized
INFO - 2016-05-24 16:42:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:42:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:42:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:42:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:42:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:42:55 --> Model Class Initialized
INFO - 2016-05-24 16:42:55 --> Form Validation Class Initialized
INFO - 2016-05-24 16:42:55 --> Helper loaded: string_helper
INFO - 2016-05-24 16:42:55 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:42:55 --> Final output sent to browser
DEBUG - 2016-05-24 16:42:55 --> Total execution time: 0.1514
INFO - 2016-05-24 16:44:38 --> Config Class Initialized
INFO - 2016-05-24 16:44:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:44:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:44:38 --> Utf8 Class Initialized
INFO - 2016-05-24 16:44:38 --> URI Class Initialized
INFO - 2016-05-24 16:44:38 --> Router Class Initialized
INFO - 2016-05-24 16:44:38 --> Output Class Initialized
INFO - 2016-05-24 16:44:38 --> Security Class Initialized
DEBUG - 2016-05-24 16:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:44:38 --> CSRF cookie sent
INFO - 2016-05-24 16:44:38 --> Input Class Initialized
INFO - 2016-05-24 16:44:38 --> Language Class Initialized
INFO - 2016-05-24 16:44:38 --> Loader Class Initialized
INFO - 2016-05-24 16:44:38 --> Helper loaded: form_helper
INFO - 2016-05-24 16:44:38 --> Database Driver Class Initialized
INFO - 2016-05-24 16:44:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:44:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:44:38 --> Email Class Initialized
INFO - 2016-05-24 16:44:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:44:38 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:44:38 --> Helper loaded: language_helper
INFO - 2016-05-24 16:44:38 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:44:38 --> Model Class Initialized
INFO - 2016-05-24 16:44:38 --> Helper loaded: date_helper
INFO - 2016-05-24 16:44:38 --> Controller Class Initialized
INFO - 2016-05-24 16:44:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:44:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:44:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:44:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:44:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:44:38 --> Model Class Initialized
INFO - 2016-05-24 16:44:38 --> Form Validation Class Initialized
INFO - 2016-05-24 16:44:38 --> Helper loaded: string_helper
INFO - 2016-05-24 16:44:38 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:44:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:44:38 --> Final output sent to browser
DEBUG - 2016-05-24 16:44:38 --> Total execution time: 0.0560
INFO - 2016-05-24 16:45:54 --> Config Class Initialized
INFO - 2016-05-24 16:45:54 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:45:54 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:45:54 --> Utf8 Class Initialized
INFO - 2016-05-24 16:45:54 --> URI Class Initialized
INFO - 2016-05-24 16:45:54 --> Router Class Initialized
INFO - 2016-05-24 16:45:54 --> Output Class Initialized
INFO - 2016-05-24 16:45:54 --> Security Class Initialized
DEBUG - 2016-05-24 16:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:45:54 --> CSRF cookie sent
INFO - 2016-05-24 16:45:54 --> Input Class Initialized
INFO - 2016-05-24 16:45:54 --> Language Class Initialized
INFO - 2016-05-24 16:45:54 --> Loader Class Initialized
INFO - 2016-05-24 16:45:54 --> Helper loaded: form_helper
INFO - 2016-05-24 16:45:54 --> Database Driver Class Initialized
INFO - 2016-05-24 16:45:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:45:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:45:54 --> Email Class Initialized
INFO - 2016-05-24 16:45:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:45:54 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:45:54 --> Helper loaded: language_helper
INFO - 2016-05-24 16:45:54 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:45:54 --> Model Class Initialized
INFO - 2016-05-24 16:45:54 --> Helper loaded: date_helper
INFO - 2016-05-24 16:45:54 --> Controller Class Initialized
INFO - 2016-05-24 16:45:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:45:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:45:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:45:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:45:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:45:54 --> Model Class Initialized
INFO - 2016-05-24 16:45:54 --> Form Validation Class Initialized
INFO - 2016-05-24 16:45:54 --> Helper loaded: string_helper
INFO - 2016-05-24 16:45:54 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:45:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:45:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:45:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:45:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:45:54 --> Final output sent to browser
DEBUG - 2016-05-24 16:45:54 --> Total execution time: 0.0522
INFO - 2016-05-24 16:46:03 --> Config Class Initialized
INFO - 2016-05-24 16:46:03 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:46:03 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:46:03 --> Utf8 Class Initialized
INFO - 2016-05-24 16:46:03 --> URI Class Initialized
INFO - 2016-05-24 16:46:03 --> Router Class Initialized
INFO - 2016-05-24 16:46:03 --> Output Class Initialized
INFO - 2016-05-24 16:46:03 --> Security Class Initialized
DEBUG - 2016-05-24 16:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:46:03 --> CSRF cookie sent
INFO - 2016-05-24 16:46:03 --> Input Class Initialized
INFO - 2016-05-24 16:46:03 --> Language Class Initialized
INFO - 2016-05-24 16:46:03 --> Loader Class Initialized
INFO - 2016-05-24 16:46:03 --> Helper loaded: form_helper
INFO - 2016-05-24 16:46:03 --> Database Driver Class Initialized
INFO - 2016-05-24 16:46:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:46:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:46:03 --> Email Class Initialized
INFO - 2016-05-24 16:46:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:46:03 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:46:03 --> Helper loaded: language_helper
INFO - 2016-05-24 16:46:03 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:46:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:46:03 --> Model Class Initialized
INFO - 2016-05-24 16:46:03 --> Helper loaded: date_helper
INFO - 2016-05-24 16:46:03 --> Controller Class Initialized
INFO - 2016-05-24 16:46:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:46:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:46:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:46:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:46:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:46:03 --> Model Class Initialized
INFO - 2016-05-24 16:46:03 --> Form Validation Class Initialized
INFO - 2016-05-24 16:46:03 --> Helper loaded: string_helper
INFO - 2016-05-24 16:46:03 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:46:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:46:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:46:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:46:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:46:03 --> Final output sent to browser
DEBUG - 2016-05-24 16:46:03 --> Total execution time: 0.0501
INFO - 2016-05-24 16:46:28 --> Config Class Initialized
INFO - 2016-05-24 16:46:28 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:46:28 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:46:28 --> Utf8 Class Initialized
INFO - 2016-05-24 16:46:28 --> URI Class Initialized
INFO - 2016-05-24 16:46:28 --> Router Class Initialized
INFO - 2016-05-24 16:46:28 --> Output Class Initialized
INFO - 2016-05-24 16:46:28 --> Security Class Initialized
DEBUG - 2016-05-24 16:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:46:28 --> CSRF cookie sent
INFO - 2016-05-24 16:46:28 --> Input Class Initialized
INFO - 2016-05-24 16:46:28 --> Language Class Initialized
INFO - 2016-05-24 16:46:28 --> Loader Class Initialized
INFO - 2016-05-24 16:46:28 --> Helper loaded: form_helper
INFO - 2016-05-24 16:46:28 --> Database Driver Class Initialized
INFO - 2016-05-24 16:46:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:46:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:46:28 --> Email Class Initialized
INFO - 2016-05-24 16:46:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:46:28 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:46:28 --> Helper loaded: language_helper
INFO - 2016-05-24 16:46:28 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:46:28 --> Model Class Initialized
INFO - 2016-05-24 16:46:28 --> Helper loaded: date_helper
INFO - 2016-05-24 16:46:28 --> Controller Class Initialized
INFO - 2016-05-24 16:46:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:46:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:46:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:46:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:46:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:46:28 --> Model Class Initialized
INFO - 2016-05-24 16:46:28 --> Form Validation Class Initialized
INFO - 2016-05-24 16:46:28 --> Helper loaded: string_helper
INFO - 2016-05-24 16:46:28 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:46:28 --> Final output sent to browser
DEBUG - 2016-05-24 16:46:28 --> Total execution time: 0.1233
INFO - 2016-05-24 16:48:36 --> Config Class Initialized
INFO - 2016-05-24 16:48:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:48:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:48:36 --> Utf8 Class Initialized
INFO - 2016-05-24 16:48:36 --> URI Class Initialized
INFO - 2016-05-24 16:48:36 --> Router Class Initialized
INFO - 2016-05-24 16:48:36 --> Output Class Initialized
INFO - 2016-05-24 16:48:36 --> Security Class Initialized
DEBUG - 2016-05-24 16:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:48:36 --> CSRF cookie sent
INFO - 2016-05-24 16:48:36 --> Input Class Initialized
INFO - 2016-05-24 16:48:36 --> Language Class Initialized
INFO - 2016-05-24 16:48:36 --> Loader Class Initialized
INFO - 2016-05-24 16:48:36 --> Helper loaded: form_helper
INFO - 2016-05-24 16:48:36 --> Database Driver Class Initialized
INFO - 2016-05-24 16:48:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:48:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:48:36 --> Email Class Initialized
INFO - 2016-05-24 16:48:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:48:36 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:48:36 --> Helper loaded: language_helper
INFO - 2016-05-24 16:48:36 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:48:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:48:36 --> Model Class Initialized
INFO - 2016-05-24 16:48:36 --> Helper loaded: date_helper
INFO - 2016-05-24 16:48:36 --> Controller Class Initialized
INFO - 2016-05-24 16:48:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:48:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:48:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:48:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:48:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:48:36 --> Model Class Initialized
INFO - 2016-05-24 16:48:36 --> Form Validation Class Initialized
INFO - 2016-05-24 16:48:36 --> Helper loaded: string_helper
INFO - 2016-05-24 16:48:36 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:48:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:48:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:48:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:48:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:48:36 --> Final output sent to browser
DEBUG - 2016-05-24 16:48:36 --> Total execution time: 0.0654
INFO - 2016-05-24 16:49:44 --> Config Class Initialized
INFO - 2016-05-24 16:49:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:49:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:49:44 --> Utf8 Class Initialized
INFO - 2016-05-24 16:49:44 --> URI Class Initialized
INFO - 2016-05-24 16:49:44 --> Router Class Initialized
INFO - 2016-05-24 16:49:44 --> Output Class Initialized
INFO - 2016-05-24 16:49:44 --> Security Class Initialized
DEBUG - 2016-05-24 16:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:49:44 --> CSRF cookie sent
INFO - 2016-05-24 16:49:44 --> Input Class Initialized
INFO - 2016-05-24 16:49:44 --> Language Class Initialized
INFO - 2016-05-24 16:49:44 --> Loader Class Initialized
INFO - 2016-05-24 16:49:44 --> Helper loaded: form_helper
INFO - 2016-05-24 16:49:44 --> Database Driver Class Initialized
INFO - 2016-05-24 16:49:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:49:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:49:44 --> Email Class Initialized
INFO - 2016-05-24 16:49:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:49:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:49:44 --> Helper loaded: language_helper
INFO - 2016-05-24 16:49:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:49:44 --> Model Class Initialized
INFO - 2016-05-24 16:49:44 --> Helper loaded: date_helper
INFO - 2016-05-24 16:49:44 --> Controller Class Initialized
INFO - 2016-05-24 16:49:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:49:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:49:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:49:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:49:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:49:44 --> Model Class Initialized
INFO - 2016-05-24 16:49:44 --> Form Validation Class Initialized
INFO - 2016-05-24 16:49:44 --> Helper loaded: string_helper
INFO - 2016-05-24 16:49:44 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:49:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:49:44 --> Final output sent to browser
DEBUG - 2016-05-24 16:49:44 --> Total execution time: 0.1011
INFO - 2016-05-24 16:50:10 --> Config Class Initialized
INFO - 2016-05-24 16:50:10 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:50:10 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:50:10 --> Utf8 Class Initialized
INFO - 2016-05-24 16:50:10 --> URI Class Initialized
INFO - 2016-05-24 16:50:10 --> Router Class Initialized
INFO - 2016-05-24 16:50:10 --> Output Class Initialized
INFO - 2016-05-24 16:50:10 --> Security Class Initialized
DEBUG - 2016-05-24 16:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:50:10 --> CSRF cookie sent
INFO - 2016-05-24 16:50:10 --> Input Class Initialized
INFO - 2016-05-24 16:50:10 --> Language Class Initialized
INFO - 2016-05-24 16:50:10 --> Loader Class Initialized
INFO - 2016-05-24 16:50:10 --> Helper loaded: form_helper
INFO - 2016-05-24 16:50:10 --> Database Driver Class Initialized
INFO - 2016-05-24 16:50:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:50:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:50:10 --> Email Class Initialized
INFO - 2016-05-24 16:50:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:50:10 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:50:10 --> Helper loaded: language_helper
INFO - 2016-05-24 16:50:10 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:50:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:50:10 --> Model Class Initialized
INFO - 2016-05-24 16:50:10 --> Helper loaded: date_helper
INFO - 2016-05-24 16:50:10 --> Controller Class Initialized
INFO - 2016-05-24 16:50:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:50:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:50:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:50:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:50:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:50:10 --> Model Class Initialized
INFO - 2016-05-24 16:50:10 --> Form Validation Class Initialized
INFO - 2016-05-24 16:50:10 --> Helper loaded: string_helper
INFO - 2016-05-24 16:50:10 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:50:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:50:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:50:10 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:50:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:50:10 --> Final output sent to browser
DEBUG - 2016-05-24 16:50:10 --> Total execution time: 0.0529
INFO - 2016-05-24 16:51:16 --> Config Class Initialized
INFO - 2016-05-24 16:51:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:51:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:51:16 --> Utf8 Class Initialized
INFO - 2016-05-24 16:51:16 --> URI Class Initialized
INFO - 2016-05-24 16:51:16 --> Router Class Initialized
INFO - 2016-05-24 16:51:16 --> Output Class Initialized
INFO - 2016-05-24 16:51:16 --> Security Class Initialized
DEBUG - 2016-05-24 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:51:16 --> CSRF cookie sent
INFO - 2016-05-24 16:51:16 --> Input Class Initialized
INFO - 2016-05-24 16:51:16 --> Language Class Initialized
INFO - 2016-05-24 16:51:16 --> Loader Class Initialized
INFO - 2016-05-24 16:51:16 --> Helper loaded: form_helper
INFO - 2016-05-24 16:51:16 --> Database Driver Class Initialized
INFO - 2016-05-24 16:51:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:51:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:51:16 --> Email Class Initialized
INFO - 2016-05-24 16:51:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:51:16 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:51:16 --> Helper loaded: language_helper
INFO - 2016-05-24 16:51:16 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:51:16 --> Model Class Initialized
INFO - 2016-05-24 16:51:16 --> Helper loaded: date_helper
INFO - 2016-05-24 16:51:16 --> Controller Class Initialized
INFO - 2016-05-24 16:51:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:51:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:51:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:51:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:51:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:51:16 --> Model Class Initialized
INFO - 2016-05-24 16:51:16 --> Form Validation Class Initialized
INFO - 2016-05-24 16:51:16 --> Helper loaded: string_helper
INFO - 2016-05-24 16:51:16 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:51:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:51:16 --> Final output sent to browser
DEBUG - 2016-05-24 16:51:16 --> Total execution time: 0.0543
INFO - 2016-05-24 16:51:54 --> Config Class Initialized
INFO - 2016-05-24 16:51:54 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:51:54 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:51:54 --> Utf8 Class Initialized
INFO - 2016-05-24 16:51:54 --> URI Class Initialized
INFO - 2016-05-24 16:51:54 --> Router Class Initialized
INFO - 2016-05-24 16:51:54 --> Output Class Initialized
INFO - 2016-05-24 16:51:54 --> Security Class Initialized
DEBUG - 2016-05-24 16:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:51:54 --> CSRF cookie sent
INFO - 2016-05-24 16:51:54 --> Input Class Initialized
INFO - 2016-05-24 16:51:54 --> Language Class Initialized
INFO - 2016-05-24 16:51:54 --> Loader Class Initialized
INFO - 2016-05-24 16:51:54 --> Helper loaded: form_helper
INFO - 2016-05-24 16:51:54 --> Database Driver Class Initialized
INFO - 2016-05-24 16:51:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:51:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:51:54 --> Email Class Initialized
INFO - 2016-05-24 16:51:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:51:54 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:51:54 --> Helper loaded: language_helper
INFO - 2016-05-24 16:51:54 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:51:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:51:54 --> Model Class Initialized
INFO - 2016-05-24 16:51:54 --> Helper loaded: date_helper
INFO - 2016-05-24 16:51:54 --> Controller Class Initialized
INFO - 2016-05-24 16:51:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:51:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:51:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:51:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:51:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:51:54 --> Model Class Initialized
INFO - 2016-05-24 16:51:54 --> Form Validation Class Initialized
INFO - 2016-05-24 16:51:54 --> Helper loaded: string_helper
INFO - 2016-05-24 16:51:54 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:51:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:51:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:51:54 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:51:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:51:54 --> Final output sent to browser
DEBUG - 2016-05-24 16:51:54 --> Total execution time: 0.0451
INFO - 2016-05-24 16:53:10 --> Config Class Initialized
INFO - 2016-05-24 16:53:10 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:53:10 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:53:10 --> Utf8 Class Initialized
INFO - 2016-05-24 16:53:10 --> URI Class Initialized
INFO - 2016-05-24 16:53:10 --> Router Class Initialized
INFO - 2016-05-24 16:53:10 --> Output Class Initialized
INFO - 2016-05-24 16:53:10 --> Security Class Initialized
DEBUG - 2016-05-24 16:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:53:10 --> CSRF cookie sent
INFO - 2016-05-24 16:53:10 --> Input Class Initialized
INFO - 2016-05-24 16:53:10 --> Language Class Initialized
INFO - 2016-05-24 16:53:10 --> Loader Class Initialized
INFO - 2016-05-24 16:53:10 --> Helper loaded: form_helper
INFO - 2016-05-24 16:53:10 --> Database Driver Class Initialized
INFO - 2016-05-24 16:53:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:53:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:53:10 --> Email Class Initialized
INFO - 2016-05-24 16:53:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:53:10 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:53:10 --> Helper loaded: language_helper
INFO - 2016-05-24 16:53:10 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:53:10 --> Model Class Initialized
INFO - 2016-05-24 16:53:10 --> Helper loaded: date_helper
INFO - 2016-05-24 16:53:10 --> Controller Class Initialized
INFO - 2016-05-24 16:53:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:53:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:53:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:53:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:53:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:53:10 --> Model Class Initialized
INFO - 2016-05-24 16:53:10 --> Form Validation Class Initialized
INFO - 2016-05-24 16:53:10 --> Helper loaded: string_helper
INFO - 2016-05-24 16:53:10 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:53:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:53:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:53:10 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:53:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:53:10 --> Final output sent to browser
DEBUG - 2016-05-24 16:53:10 --> Total execution time: 0.0557
INFO - 2016-05-24 16:53:32 --> Config Class Initialized
INFO - 2016-05-24 16:53:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:53:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:53:32 --> Utf8 Class Initialized
INFO - 2016-05-24 16:53:32 --> URI Class Initialized
INFO - 2016-05-24 16:53:32 --> Router Class Initialized
INFO - 2016-05-24 16:53:32 --> Output Class Initialized
INFO - 2016-05-24 16:53:32 --> Security Class Initialized
DEBUG - 2016-05-24 16:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:53:32 --> CSRF cookie sent
INFO - 2016-05-24 16:53:32 --> Input Class Initialized
INFO - 2016-05-24 16:53:32 --> Language Class Initialized
INFO - 2016-05-24 16:53:32 --> Loader Class Initialized
INFO - 2016-05-24 16:53:32 --> Helper loaded: form_helper
INFO - 2016-05-24 16:53:32 --> Database Driver Class Initialized
INFO - 2016-05-24 16:53:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:53:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:53:32 --> Email Class Initialized
INFO - 2016-05-24 16:53:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:53:32 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:53:32 --> Helper loaded: language_helper
INFO - 2016-05-24 16:53:32 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:53:32 --> Model Class Initialized
INFO - 2016-05-24 16:53:32 --> Helper loaded: date_helper
INFO - 2016-05-24 16:53:32 --> Controller Class Initialized
INFO - 2016-05-24 16:53:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:53:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:53:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:53:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:53:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:53:32 --> Model Class Initialized
INFO - 2016-05-24 16:53:32 --> Form Validation Class Initialized
INFO - 2016-05-24 16:53:32 --> Helper loaded: string_helper
INFO - 2016-05-24 16:53:32 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:53:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:53:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:53:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:53:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:53:32 --> Final output sent to browser
DEBUG - 2016-05-24 16:53:32 --> Total execution time: 0.0752
INFO - 2016-05-24 16:53:58 --> Config Class Initialized
INFO - 2016-05-24 16:53:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:53:58 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:53:58 --> Utf8 Class Initialized
INFO - 2016-05-24 16:53:58 --> URI Class Initialized
INFO - 2016-05-24 16:53:58 --> Router Class Initialized
INFO - 2016-05-24 16:53:58 --> Output Class Initialized
INFO - 2016-05-24 16:53:58 --> Security Class Initialized
DEBUG - 2016-05-24 16:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:53:58 --> CSRF cookie sent
INFO - 2016-05-24 16:53:58 --> Input Class Initialized
INFO - 2016-05-24 16:53:58 --> Language Class Initialized
INFO - 2016-05-24 16:53:58 --> Loader Class Initialized
INFO - 2016-05-24 16:53:58 --> Helper loaded: form_helper
INFO - 2016-05-24 16:53:58 --> Database Driver Class Initialized
INFO - 2016-05-24 16:53:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:53:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:53:58 --> Email Class Initialized
INFO - 2016-05-24 16:53:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:53:58 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:53:58 --> Helper loaded: language_helper
INFO - 2016-05-24 16:53:58 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:53:58 --> Model Class Initialized
INFO - 2016-05-24 16:53:58 --> Helper loaded: date_helper
INFO - 2016-05-24 16:53:58 --> Controller Class Initialized
INFO - 2016-05-24 16:53:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:53:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:53:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:53:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:53:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:53:58 --> Model Class Initialized
INFO - 2016-05-24 16:53:58 --> Form Validation Class Initialized
INFO - 2016-05-24 16:53:58 --> Helper loaded: string_helper
INFO - 2016-05-24 16:53:58 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:53:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:53:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:53:58 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:53:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:53:58 --> Final output sent to browser
DEBUG - 2016-05-24 16:53:58 --> Total execution time: 0.0219
INFO - 2016-05-24 16:54:20 --> Config Class Initialized
INFO - 2016-05-24 16:54:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:54:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:54:20 --> Utf8 Class Initialized
INFO - 2016-05-24 16:54:20 --> URI Class Initialized
INFO - 2016-05-24 16:54:20 --> Router Class Initialized
INFO - 2016-05-24 16:54:20 --> Output Class Initialized
INFO - 2016-05-24 16:54:20 --> Security Class Initialized
DEBUG - 2016-05-24 16:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:54:20 --> CSRF cookie sent
INFO - 2016-05-24 16:54:20 --> Input Class Initialized
INFO - 2016-05-24 16:54:20 --> Language Class Initialized
INFO - 2016-05-24 16:54:20 --> Loader Class Initialized
INFO - 2016-05-24 16:54:20 --> Helper loaded: form_helper
INFO - 2016-05-24 16:54:20 --> Database Driver Class Initialized
INFO - 2016-05-24 16:54:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:54:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:54:20 --> Email Class Initialized
INFO - 2016-05-24 16:54:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:54:20 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:54:20 --> Helper loaded: language_helper
INFO - 2016-05-24 16:54:20 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:54:20 --> Model Class Initialized
INFO - 2016-05-24 16:54:20 --> Helper loaded: date_helper
INFO - 2016-05-24 16:54:20 --> Controller Class Initialized
INFO - 2016-05-24 16:54:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:54:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:54:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:54:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:54:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:54:20 --> Model Class Initialized
INFO - 2016-05-24 16:54:20 --> Form Validation Class Initialized
INFO - 2016-05-24 16:54:20 --> Helper loaded: string_helper
INFO - 2016-05-24 16:54:20 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:54:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:54:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:54:20 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:54:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:54:20 --> Final output sent to browser
DEBUG - 2016-05-24 16:54:20 --> Total execution time: 0.0747
INFO - 2016-05-24 16:54:33 --> Config Class Initialized
INFO - 2016-05-24 16:54:33 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:54:33 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:54:33 --> Utf8 Class Initialized
INFO - 2016-05-24 16:54:33 --> URI Class Initialized
INFO - 2016-05-24 16:54:33 --> Router Class Initialized
INFO - 2016-05-24 16:54:33 --> Output Class Initialized
INFO - 2016-05-24 16:54:33 --> Security Class Initialized
DEBUG - 2016-05-24 16:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:54:33 --> CSRF cookie sent
INFO - 2016-05-24 16:54:33 --> Input Class Initialized
INFO - 2016-05-24 16:54:33 --> Language Class Initialized
INFO - 2016-05-24 16:54:33 --> Loader Class Initialized
INFO - 2016-05-24 16:54:33 --> Helper loaded: form_helper
INFO - 2016-05-24 16:54:33 --> Database Driver Class Initialized
INFO - 2016-05-24 16:54:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:54:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:54:33 --> Email Class Initialized
INFO - 2016-05-24 16:54:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:54:33 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:54:33 --> Helper loaded: language_helper
INFO - 2016-05-24 16:54:33 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:54:33 --> Model Class Initialized
INFO - 2016-05-24 16:54:33 --> Helper loaded: date_helper
INFO - 2016-05-24 16:54:33 --> Controller Class Initialized
INFO - 2016-05-24 16:54:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:54:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:54:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:54:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:54:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:54:33 --> Model Class Initialized
INFO - 2016-05-24 16:54:33 --> Form Validation Class Initialized
INFO - 2016-05-24 16:54:33 --> Helper loaded: string_helper
INFO - 2016-05-24 16:54:33 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:54:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:54:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:54:33 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:54:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:54:33 --> Final output sent to browser
DEBUG - 2016-05-24 16:54:33 --> Total execution time: 0.0684
INFO - 2016-05-24 16:54:42 --> Config Class Initialized
INFO - 2016-05-24 16:54:42 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:54:42 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:54:42 --> Utf8 Class Initialized
INFO - 2016-05-24 16:54:42 --> URI Class Initialized
INFO - 2016-05-24 16:54:42 --> Router Class Initialized
INFO - 2016-05-24 16:54:42 --> Output Class Initialized
INFO - 2016-05-24 16:54:42 --> Security Class Initialized
DEBUG - 2016-05-24 16:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:54:42 --> CSRF cookie sent
INFO - 2016-05-24 16:54:42 --> Input Class Initialized
INFO - 2016-05-24 16:54:42 --> Language Class Initialized
INFO - 2016-05-24 16:54:42 --> Loader Class Initialized
INFO - 2016-05-24 16:54:42 --> Helper loaded: form_helper
INFO - 2016-05-24 16:54:42 --> Database Driver Class Initialized
INFO - 2016-05-24 16:54:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:54:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:54:42 --> Email Class Initialized
INFO - 2016-05-24 16:54:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:54:42 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:54:42 --> Helper loaded: language_helper
INFO - 2016-05-24 16:54:42 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:54:42 --> Model Class Initialized
INFO - 2016-05-24 16:54:42 --> Helper loaded: date_helper
INFO - 2016-05-24 16:54:42 --> Controller Class Initialized
INFO - 2016-05-24 16:54:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:54:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:54:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:54:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:54:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:54:42 --> Model Class Initialized
INFO - 2016-05-24 16:54:42 --> Form Validation Class Initialized
INFO - 2016-05-24 16:54:42 --> Helper loaded: string_helper
INFO - 2016-05-24 16:54:42 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:54:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:54:42 --> Final output sent to browser
DEBUG - 2016-05-24 16:54:42 --> Total execution time: 0.0618
INFO - 2016-05-24 16:56:32 --> Config Class Initialized
INFO - 2016-05-24 16:56:32 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:56:32 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:56:32 --> Utf8 Class Initialized
INFO - 2016-05-24 16:56:32 --> URI Class Initialized
INFO - 2016-05-24 16:56:32 --> Router Class Initialized
INFO - 2016-05-24 16:56:32 --> Output Class Initialized
INFO - 2016-05-24 16:56:32 --> Security Class Initialized
DEBUG - 2016-05-24 16:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:56:32 --> CSRF cookie sent
INFO - 2016-05-24 16:56:32 --> Input Class Initialized
INFO - 2016-05-24 16:56:32 --> Language Class Initialized
INFO - 2016-05-24 16:56:32 --> Loader Class Initialized
INFO - 2016-05-24 16:56:32 --> Helper loaded: form_helper
INFO - 2016-05-24 16:56:32 --> Database Driver Class Initialized
INFO - 2016-05-24 16:56:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:56:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:56:32 --> Email Class Initialized
INFO - 2016-05-24 16:56:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:56:32 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:56:32 --> Helper loaded: language_helper
INFO - 2016-05-24 16:56:32 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:56:32 --> Model Class Initialized
INFO - 2016-05-24 16:56:32 --> Helper loaded: date_helper
INFO - 2016-05-24 16:56:32 --> Controller Class Initialized
INFO - 2016-05-24 16:56:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:56:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:56:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:56:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:56:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:56:32 --> Model Class Initialized
INFO - 2016-05-24 16:56:32 --> Form Validation Class Initialized
INFO - 2016-05-24 16:56:32 --> Helper loaded: string_helper
INFO - 2016-05-24 16:56:32 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:56:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:56:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:56:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:56:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:56:32 --> Final output sent to browser
DEBUG - 2016-05-24 16:56:32 --> Total execution time: 0.0668
INFO - 2016-05-24 16:56:44 --> Config Class Initialized
INFO - 2016-05-24 16:56:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 16:56:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 16:56:44 --> Utf8 Class Initialized
INFO - 2016-05-24 16:56:44 --> URI Class Initialized
INFO - 2016-05-24 16:56:44 --> Router Class Initialized
INFO - 2016-05-24 16:56:44 --> Output Class Initialized
INFO - 2016-05-24 16:56:44 --> Security Class Initialized
DEBUG - 2016-05-24 16:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 16:56:44 --> CSRF cookie sent
INFO - 2016-05-24 16:56:44 --> Input Class Initialized
INFO - 2016-05-24 16:56:44 --> Language Class Initialized
INFO - 2016-05-24 16:56:44 --> Loader Class Initialized
INFO - 2016-05-24 16:56:44 --> Helper loaded: form_helper
INFO - 2016-05-24 16:56:44 --> Database Driver Class Initialized
INFO - 2016-05-24 16:56:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 16:56:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 16:56:44 --> Email Class Initialized
INFO - 2016-05-24 16:56:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 16:56:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 16:56:44 --> Helper loaded: language_helper
INFO - 2016-05-24 16:56:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 16:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 16:56:44 --> Model Class Initialized
INFO - 2016-05-24 16:56:44 --> Helper loaded: date_helper
INFO - 2016-05-24 16:56:44 --> Controller Class Initialized
INFO - 2016-05-24 16:56:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 16:56:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 16:56:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 16:56:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 16:56:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 16:56:44 --> Model Class Initialized
INFO - 2016-05-24 16:56:44 --> Form Validation Class Initialized
INFO - 2016-05-24 16:56:44 --> Helper loaded: string_helper
INFO - 2016-05-24 16:56:44 --> Helper loaded: languages_helper
INFO - 2016-05-24 16:56:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 16:56:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 16:56:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 16:56:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 16:56:44 --> Final output sent to browser
DEBUG - 2016-05-24 16:56:44 --> Total execution time: 0.0529
INFO - 2016-05-24 17:21:22 --> Config Class Initialized
INFO - 2016-05-24 17:21:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:21:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:21:22 --> Utf8 Class Initialized
INFO - 2016-05-24 17:21:22 --> URI Class Initialized
INFO - 2016-05-24 17:21:22 --> Router Class Initialized
INFO - 2016-05-24 17:21:22 --> Output Class Initialized
INFO - 2016-05-24 17:21:22 --> Security Class Initialized
DEBUG - 2016-05-24 17:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:21:22 --> CSRF cookie sent
INFO - 2016-05-24 17:21:22 --> Input Class Initialized
INFO - 2016-05-24 17:21:22 --> Language Class Initialized
INFO - 2016-05-24 17:21:22 --> Loader Class Initialized
INFO - 2016-05-24 17:21:22 --> Helper loaded: form_helper
INFO - 2016-05-24 17:21:22 --> Database Driver Class Initialized
INFO - 2016-05-24 17:21:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:21:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:21:22 --> Email Class Initialized
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:21:22 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:21:22 --> Helper loaded: language_helper
INFO - 2016-05-24 17:21:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:22 --> Model Class Initialized
INFO - 2016-05-24 17:21:22 --> Helper loaded: date_helper
INFO - 2016-05-24 17:21:22 --> Controller Class Initialized
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:21:22 --> Model Class Initialized
INFO - 2016-05-24 17:21:22 --> Form Validation Class Initialized
INFO - 2016-05-24 17:21:22 --> Config Class Initialized
INFO - 2016-05-24 17:21:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:21:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:21:22 --> Utf8 Class Initialized
INFO - 2016-05-24 17:21:22 --> URI Class Initialized
INFO - 2016-05-24 17:21:22 --> Router Class Initialized
INFO - 2016-05-24 17:21:22 --> Output Class Initialized
INFO - 2016-05-24 17:21:22 --> Security Class Initialized
DEBUG - 2016-05-24 17:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:21:22 --> CSRF cookie sent
INFO - 2016-05-24 17:21:22 --> Input Class Initialized
INFO - 2016-05-24 17:21:22 --> Language Class Initialized
INFO - 2016-05-24 17:21:22 --> Loader Class Initialized
INFO - 2016-05-24 17:21:22 --> Helper loaded: form_helper
INFO - 2016-05-24 17:21:22 --> Database Driver Class Initialized
INFO - 2016-05-24 17:21:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:21:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:21:22 --> Email Class Initialized
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:21:22 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:21:22 --> Helper loaded: language_helper
INFO - 2016-05-24 17:21:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:22 --> Model Class Initialized
INFO - 2016-05-24 17:21:22 --> Helper loaded: date_helper
INFO - 2016-05-24 17:21:22 --> Controller Class Initialized
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:21:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:21:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:22 --> Form Validation Class Initialized
INFO - 2016-05-24 17:21:34 --> Config Class Initialized
INFO - 2016-05-24 17:21:34 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:21:34 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:21:34 --> Utf8 Class Initialized
INFO - 2016-05-24 17:21:34 --> URI Class Initialized
INFO - 2016-05-24 17:21:34 --> Router Class Initialized
INFO - 2016-05-24 17:21:34 --> Output Class Initialized
INFO - 2016-05-24 17:21:34 --> Security Class Initialized
DEBUG - 2016-05-24 17:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:21:34 --> CSRF cookie sent
INFO - 2016-05-24 17:21:34 --> Input Class Initialized
INFO - 2016-05-24 17:21:34 --> Language Class Initialized
INFO - 2016-05-24 17:21:34 --> Loader Class Initialized
INFO - 2016-05-24 17:21:34 --> Helper loaded: form_helper
INFO - 2016-05-24 17:21:34 --> Database Driver Class Initialized
INFO - 2016-05-24 17:21:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:21:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:21:34 --> Email Class Initialized
INFO - 2016-05-24 17:21:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:21:34 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:21:34 --> Helper loaded: language_helper
INFO - 2016-05-24 17:21:34 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:34 --> Model Class Initialized
INFO - 2016-05-24 17:21:34 --> Helper loaded: date_helper
INFO - 2016-05-24 17:21:34 --> Controller Class Initialized
INFO - 2016-05-24 17:21:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:21:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:21:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:21:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:21:34 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:21:34 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:34 --> Form Validation Class Initialized
INFO - 2016-05-24 17:21:36 --> Config Class Initialized
INFO - 2016-05-24 17:21:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:21:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:21:36 --> Utf8 Class Initialized
INFO - 2016-05-24 17:21:36 --> URI Class Initialized
INFO - 2016-05-24 17:21:36 --> Router Class Initialized
INFO - 2016-05-24 17:21:36 --> Output Class Initialized
INFO - 2016-05-24 17:21:36 --> Security Class Initialized
DEBUG - 2016-05-24 17:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:21:36 --> CSRF cookie sent
INFO - 2016-05-24 17:21:36 --> Input Class Initialized
INFO - 2016-05-24 17:21:36 --> Language Class Initialized
INFO - 2016-05-24 17:21:36 --> Loader Class Initialized
INFO - 2016-05-24 17:21:36 --> Helper loaded: form_helper
INFO - 2016-05-24 17:21:36 --> Database Driver Class Initialized
INFO - 2016-05-24 17:21:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:21:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:21:36 --> Email Class Initialized
INFO - 2016-05-24 17:21:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:21:36 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:21:36 --> Helper loaded: language_helper
INFO - 2016-05-24 17:21:36 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:36 --> Model Class Initialized
INFO - 2016-05-24 17:21:36 --> Helper loaded: date_helper
INFO - 2016-05-24 17:21:36 --> Controller Class Initialized
INFO - 2016-05-24 17:21:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:21:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:21:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:21:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:21:36 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:21:36 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:36 --> Form Validation Class Initialized
INFO - 2016-05-24 17:21:36 --> Helper loaded: string_helper
INFO - 2016-05-24 17:21:36 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:21:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:21:36 --> Final output sent to browser
DEBUG - 2016-05-24 17:21:36 --> Total execution time: 0.0255
INFO - 2016-05-24 17:21:43 --> Config Class Initialized
INFO - 2016-05-24 17:21:43 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:21:43 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:21:43 --> Utf8 Class Initialized
INFO - 2016-05-24 17:21:43 --> URI Class Initialized
DEBUG - 2016-05-24 17:21:43 --> No URI present. Default controller set.
INFO - 2016-05-24 17:21:43 --> Router Class Initialized
INFO - 2016-05-24 17:21:43 --> Output Class Initialized
INFO - 2016-05-24 17:21:43 --> Security Class Initialized
DEBUG - 2016-05-24 17:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:21:43 --> CSRF cookie sent
INFO - 2016-05-24 17:21:43 --> Input Class Initialized
INFO - 2016-05-24 17:21:43 --> Language Class Initialized
INFO - 2016-05-24 17:21:43 --> Loader Class Initialized
INFO - 2016-05-24 17:21:43 --> Helper loaded: form_helper
INFO - 2016-05-24 17:21:43 --> Database Driver Class Initialized
INFO - 2016-05-24 17:21:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:21:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:21:43 --> Email Class Initialized
INFO - 2016-05-24 17:21:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:21:43 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:21:43 --> Helper loaded: language_helper
INFO - 2016-05-24 17:21:43 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:43 --> Model Class Initialized
INFO - 2016-05-24 17:21:43 --> Helper loaded: date_helper
INFO - 2016-05-24 17:21:43 --> Controller Class Initialized
INFO - 2016-05-24 17:21:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:21:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:21:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:21:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:21:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:21:43 --> Config Class Initialized
INFO - 2016-05-24 17:21:43 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:21:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:21:44 --> Utf8 Class Initialized
INFO - 2016-05-24 17:21:44 --> URI Class Initialized
INFO - 2016-05-24 17:21:44 --> Router Class Initialized
INFO - 2016-05-24 17:21:44 --> Output Class Initialized
INFO - 2016-05-24 17:21:44 --> Security Class Initialized
DEBUG - 2016-05-24 17:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:21:44 --> CSRF cookie sent
INFO - 2016-05-24 17:21:44 --> Input Class Initialized
INFO - 2016-05-24 17:21:44 --> Language Class Initialized
INFO - 2016-05-24 17:21:44 --> Loader Class Initialized
INFO - 2016-05-24 17:21:44 --> Helper loaded: form_helper
INFO - 2016-05-24 17:21:44 --> Database Driver Class Initialized
INFO - 2016-05-24 17:21:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:21:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:21:44 --> Email Class Initialized
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:21:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:21:44 --> Helper loaded: language_helper
INFO - 2016-05-24 17:21:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:44 --> Model Class Initialized
INFO - 2016-05-24 17:21:44 --> Helper loaded: date_helper
INFO - 2016-05-24 17:21:44 --> Controller Class Initialized
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:21:44 --> Model Class Initialized
INFO - 2016-05-24 17:21:44 --> Form Validation Class Initialized
INFO - 2016-05-24 17:21:44 --> Config Class Initialized
INFO - 2016-05-24 17:21:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:21:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:21:44 --> Utf8 Class Initialized
INFO - 2016-05-24 17:21:44 --> URI Class Initialized
INFO - 2016-05-24 17:21:44 --> Router Class Initialized
INFO - 2016-05-24 17:21:44 --> Output Class Initialized
INFO - 2016-05-24 17:21:44 --> Security Class Initialized
DEBUG - 2016-05-24 17:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:21:44 --> CSRF cookie sent
INFO - 2016-05-24 17:21:44 --> Input Class Initialized
INFO - 2016-05-24 17:21:44 --> Language Class Initialized
INFO - 2016-05-24 17:21:44 --> Loader Class Initialized
INFO - 2016-05-24 17:21:44 --> Helper loaded: form_helper
INFO - 2016-05-24 17:21:44 --> Database Driver Class Initialized
INFO - 2016-05-24 17:21:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:21:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:21:44 --> Email Class Initialized
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:21:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:21:44 --> Helper loaded: language_helper
INFO - 2016-05-24 17:21:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:44 --> Model Class Initialized
INFO - 2016-05-24 17:21:44 --> Helper loaded: date_helper
INFO - 2016-05-24 17:21:44 --> Controller Class Initialized
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:21:44 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:21:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:21:44 --> Form Validation Class Initialized
INFO - 2016-05-24 17:22:36 --> Config Class Initialized
INFO - 2016-05-24 17:22:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:22:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:22:36 --> Utf8 Class Initialized
INFO - 2016-05-24 17:22:36 --> URI Class Initialized
INFO - 2016-05-24 17:22:36 --> Router Class Initialized
INFO - 2016-05-24 17:22:36 --> Output Class Initialized
INFO - 2016-05-24 17:22:36 --> Security Class Initialized
DEBUG - 2016-05-24 17:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:22:36 --> CSRF cookie sent
INFO - 2016-05-24 17:22:36 --> Input Class Initialized
INFO - 2016-05-24 17:22:36 --> Language Class Initialized
INFO - 2016-05-24 17:22:36 --> Loader Class Initialized
INFO - 2016-05-24 17:22:36 --> Helper loaded: form_helper
INFO - 2016-05-24 17:22:36 --> Database Driver Class Initialized
INFO - 2016-05-24 17:22:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:22:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:22:36 --> Email Class Initialized
INFO - 2016-05-24 17:22:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:22:36 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:22:36 --> Helper loaded: language_helper
INFO - 2016-05-24 17:22:36 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:22:36 --> Model Class Initialized
INFO - 2016-05-24 17:22:36 --> Helper loaded: date_helper
INFO - 2016-05-24 17:22:36 --> Controller Class Initialized
INFO - 2016-05-24 17:22:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:22:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:22:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:22:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:22:36 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:22:36 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:22:36 --> Form Validation Class Initialized
INFO - 2016-05-24 17:22:36 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 17:22:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:22:36 --> Final output sent to browser
DEBUG - 2016-05-24 17:22:36 --> Total execution time: 0.0677
INFO - 2016-05-24 17:23:30 --> Config Class Initialized
INFO - 2016-05-24 17:23:30 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:23:30 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:23:30 --> Utf8 Class Initialized
INFO - 2016-05-24 17:23:30 --> URI Class Initialized
INFO - 2016-05-24 17:23:30 --> Router Class Initialized
INFO - 2016-05-24 17:23:30 --> Output Class Initialized
INFO - 2016-05-24 17:23:30 --> Security Class Initialized
DEBUG - 2016-05-24 17:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:23:30 --> CSRF cookie sent
INFO - 2016-05-24 17:23:30 --> Input Class Initialized
INFO - 2016-05-24 17:23:30 --> Language Class Initialized
INFO - 2016-05-24 17:23:30 --> Loader Class Initialized
INFO - 2016-05-24 17:23:30 --> Helper loaded: form_helper
INFO - 2016-05-24 17:23:30 --> Database Driver Class Initialized
INFO - 2016-05-24 17:23:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:23:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:23:30 --> Email Class Initialized
INFO - 2016-05-24 17:23:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:23:30 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:23:30 --> Helper loaded: language_helper
INFO - 2016-05-24 17:23:30 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:23:30 --> Model Class Initialized
INFO - 2016-05-24 17:23:30 --> Helper loaded: date_helper
INFO - 2016-05-24 17:23:30 --> Controller Class Initialized
INFO - 2016-05-24 17:23:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:23:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:23:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:23:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:23:30 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:23:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:23:30 --> Form Validation Class Initialized
INFO - 2016-05-24 17:23:30 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 17:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:23:30 --> Final output sent to browser
DEBUG - 2016-05-24 17:23:30 --> Total execution time: 0.0752
INFO - 2016-05-24 17:24:45 --> Config Class Initialized
INFO - 2016-05-24 17:24:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:24:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:24:45 --> Utf8 Class Initialized
INFO - 2016-05-24 17:24:45 --> URI Class Initialized
INFO - 2016-05-24 17:24:45 --> Router Class Initialized
INFO - 2016-05-24 17:24:45 --> Output Class Initialized
INFO - 2016-05-24 17:24:45 --> Security Class Initialized
DEBUG - 2016-05-24 17:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:24:45 --> CSRF cookie sent
INFO - 2016-05-24 17:24:45 --> Input Class Initialized
INFO - 2016-05-24 17:24:45 --> Language Class Initialized
INFO - 2016-05-24 17:24:45 --> Loader Class Initialized
INFO - 2016-05-24 17:24:45 --> Helper loaded: form_helper
INFO - 2016-05-24 17:24:45 --> Database Driver Class Initialized
INFO - 2016-05-24 17:24:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:24:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:24:45 --> Email Class Initialized
INFO - 2016-05-24 17:24:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:24:45 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:24:45 --> Helper loaded: language_helper
INFO - 2016-05-24 17:24:45 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:24:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:24:45 --> Model Class Initialized
INFO - 2016-05-24 17:24:45 --> Helper loaded: date_helper
INFO - 2016-05-24 17:24:45 --> Controller Class Initialized
INFO - 2016-05-24 17:24:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:24:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:24:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:24:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:24:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:24:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:24:45 --> Form Validation Class Initialized
INFO - 2016-05-24 17:24:46 --> Config Class Initialized
INFO - 2016-05-24 17:24:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:24:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:24:46 --> Utf8 Class Initialized
INFO - 2016-05-24 17:24:46 --> URI Class Initialized
DEBUG - 2016-05-24 17:24:46 --> No URI present. Default controller set.
INFO - 2016-05-24 17:24:46 --> Router Class Initialized
INFO - 2016-05-24 17:24:46 --> Output Class Initialized
INFO - 2016-05-24 17:24:46 --> Security Class Initialized
DEBUG - 2016-05-24 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:24:46 --> CSRF cookie sent
INFO - 2016-05-24 17:24:46 --> Input Class Initialized
INFO - 2016-05-24 17:24:46 --> Language Class Initialized
INFO - 2016-05-24 17:24:46 --> Loader Class Initialized
INFO - 2016-05-24 17:24:46 --> Helper loaded: form_helper
INFO - 2016-05-24 17:24:46 --> Database Driver Class Initialized
INFO - 2016-05-24 17:24:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:24:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:24:46 --> Email Class Initialized
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:24:46 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:24:46 --> Helper loaded: language_helper
INFO - 2016-05-24 17:24:46 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:24:46 --> Model Class Initialized
INFO - 2016-05-24 17:24:46 --> Helper loaded: date_helper
INFO - 2016-05-24 17:24:46 --> Controller Class Initialized
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:24:46 --> Config Class Initialized
INFO - 2016-05-24 17:24:46 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:24:46 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:24:46 --> Utf8 Class Initialized
INFO - 2016-05-24 17:24:46 --> URI Class Initialized
INFO - 2016-05-24 17:24:46 --> Router Class Initialized
INFO - 2016-05-24 17:24:46 --> Output Class Initialized
INFO - 2016-05-24 17:24:46 --> Security Class Initialized
DEBUG - 2016-05-24 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:24:46 --> CSRF cookie sent
INFO - 2016-05-24 17:24:46 --> Input Class Initialized
INFO - 2016-05-24 17:24:46 --> Language Class Initialized
INFO - 2016-05-24 17:24:46 --> Loader Class Initialized
INFO - 2016-05-24 17:24:46 --> Helper loaded: form_helper
INFO - 2016-05-24 17:24:46 --> Database Driver Class Initialized
INFO - 2016-05-24 17:24:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:24:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:24:46 --> Email Class Initialized
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:24:46 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:24:46 --> Helper loaded: language_helper
INFO - 2016-05-24 17:24:46 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:24:46 --> Model Class Initialized
INFO - 2016-05-24 17:24:46 --> Helper loaded: date_helper
INFO - 2016-05-24 17:24:46 --> Controller Class Initialized
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:24:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:24:46 --> Model Class Initialized
INFO - 2016-05-24 17:24:46 --> Form Validation Class Initialized
INFO - 2016-05-24 17:25:06 --> Config Class Initialized
INFO - 2016-05-24 17:25:06 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:25:06 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:25:06 --> Utf8 Class Initialized
INFO - 2016-05-24 17:25:06 --> URI Class Initialized
INFO - 2016-05-24 17:25:06 --> Router Class Initialized
INFO - 2016-05-24 17:25:06 --> Output Class Initialized
INFO - 2016-05-24 17:25:06 --> Security Class Initialized
DEBUG - 2016-05-24 17:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:25:06 --> CSRF cookie sent
INFO - 2016-05-24 17:25:06 --> Input Class Initialized
INFO - 2016-05-24 17:25:06 --> Language Class Initialized
INFO - 2016-05-24 17:25:06 --> Loader Class Initialized
INFO - 2016-05-24 17:25:06 --> Helper loaded: form_helper
INFO - 2016-05-24 17:25:06 --> Database Driver Class Initialized
INFO - 2016-05-24 17:25:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:25:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:25:06 --> Email Class Initialized
INFO - 2016-05-24 17:25:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:25:06 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:25:06 --> Helper loaded: language_helper
INFO - 2016-05-24 17:25:06 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:06 --> Model Class Initialized
INFO - 2016-05-24 17:25:06 --> Helper loaded: date_helper
INFO - 2016-05-24 17:25:06 --> Controller Class Initialized
INFO - 2016-05-24 17:25:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:25:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:25:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:25:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:25:06 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:25:06 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:06 --> Form Validation Class Initialized
INFO - 2016-05-24 17:25:07 --> Config Class Initialized
INFO - 2016-05-24 17:25:07 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:25:07 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:25:07 --> Utf8 Class Initialized
INFO - 2016-05-24 17:25:07 --> URI Class Initialized
INFO - 2016-05-24 17:25:07 --> Router Class Initialized
INFO - 2016-05-24 17:25:07 --> Output Class Initialized
INFO - 2016-05-24 17:25:07 --> Security Class Initialized
DEBUG - 2016-05-24 17:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:25:07 --> CSRF cookie sent
INFO - 2016-05-24 17:25:07 --> Input Class Initialized
INFO - 2016-05-24 17:25:07 --> Language Class Initialized
INFO - 2016-05-24 17:25:07 --> Loader Class Initialized
INFO - 2016-05-24 17:25:07 --> Helper loaded: form_helper
INFO - 2016-05-24 17:25:07 --> Database Driver Class Initialized
INFO - 2016-05-24 17:25:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:25:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:25:07 --> Email Class Initialized
INFO - 2016-05-24 17:25:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:25:07 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:25:07 --> Helper loaded: language_helper
INFO - 2016-05-24 17:25:07 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:25:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:07 --> Model Class Initialized
INFO - 2016-05-24 17:25:07 --> Helper loaded: date_helper
INFO - 2016-05-24 17:25:07 --> Controller Class Initialized
INFO - 2016-05-24 17:25:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:25:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:25:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:25:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:25:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:25:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:07 --> Form Validation Class Initialized
INFO - 2016-05-24 17:25:07 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-24 17:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-24 17:25:07 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-24 17:25:07 --> Final output sent to browser
DEBUG - 2016-05-24 17:25:07 --> Total execution time: 0.0239
INFO - 2016-05-24 17:25:43 --> Config Class Initialized
INFO - 2016-05-24 17:25:43 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:25:43 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:25:43 --> Utf8 Class Initialized
INFO - 2016-05-24 17:25:43 --> URI Class Initialized
INFO - 2016-05-24 17:25:43 --> Router Class Initialized
INFO - 2016-05-24 17:25:43 --> Output Class Initialized
INFO - 2016-05-24 17:25:43 --> Security Class Initialized
DEBUG - 2016-05-24 17:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:25:43 --> CSRF cookie sent
INFO - 2016-05-24 17:25:43 --> CSRF token verified
INFO - 2016-05-24 17:25:43 --> Input Class Initialized
INFO - 2016-05-24 17:25:43 --> Language Class Initialized
INFO - 2016-05-24 17:25:43 --> Loader Class Initialized
INFO - 2016-05-24 17:25:43 --> Helper loaded: form_helper
INFO - 2016-05-24 17:25:43 --> Database Driver Class Initialized
INFO - 2016-05-24 17:25:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:25:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:25:43 --> Email Class Initialized
INFO - 2016-05-24 17:25:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:25:43 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:25:43 --> Helper loaded: language_helper
INFO - 2016-05-24 17:25:43 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:43 --> Model Class Initialized
INFO - 2016-05-24 17:25:43 --> Helper loaded: date_helper
INFO - 2016-05-24 17:25:43 --> Controller Class Initialized
INFO - 2016-05-24 17:25:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:25:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:25:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:25:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:25:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:25:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:43 --> Form Validation Class Initialized
INFO - 2016-05-24 17:25:45 --> Config Class Initialized
INFO - 2016-05-24 17:25:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:25:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:25:45 --> Utf8 Class Initialized
INFO - 2016-05-24 17:25:45 --> URI Class Initialized
DEBUG - 2016-05-24 17:25:45 --> No URI present. Default controller set.
INFO - 2016-05-24 17:25:45 --> Router Class Initialized
INFO - 2016-05-24 17:25:45 --> Output Class Initialized
INFO - 2016-05-24 17:25:45 --> Security Class Initialized
DEBUG - 2016-05-24 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:25:45 --> CSRF cookie sent
INFO - 2016-05-24 17:25:45 --> Input Class Initialized
INFO - 2016-05-24 17:25:45 --> Language Class Initialized
INFO - 2016-05-24 17:25:45 --> Loader Class Initialized
INFO - 2016-05-24 17:25:45 --> Helper loaded: form_helper
INFO - 2016-05-24 17:25:45 --> Database Driver Class Initialized
INFO - 2016-05-24 17:25:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:25:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:25:45 --> Email Class Initialized
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:25:45 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:25:45 --> Helper loaded: language_helper
INFO - 2016-05-24 17:25:45 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:45 --> Model Class Initialized
INFO - 2016-05-24 17:25:45 --> Helper loaded: date_helper
INFO - 2016-05-24 17:25:45 --> Controller Class Initialized
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:25:45 --> Config Class Initialized
INFO - 2016-05-24 17:25:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:25:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:25:45 --> Utf8 Class Initialized
INFO - 2016-05-24 17:25:45 --> URI Class Initialized
INFO - 2016-05-24 17:25:45 --> Router Class Initialized
INFO - 2016-05-24 17:25:45 --> Output Class Initialized
INFO - 2016-05-24 17:25:45 --> Security Class Initialized
DEBUG - 2016-05-24 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:25:45 --> CSRF cookie sent
INFO - 2016-05-24 17:25:45 --> Input Class Initialized
INFO - 2016-05-24 17:25:45 --> Language Class Initialized
INFO - 2016-05-24 17:25:45 --> Loader Class Initialized
INFO - 2016-05-24 17:25:45 --> Helper loaded: form_helper
INFO - 2016-05-24 17:25:45 --> Database Driver Class Initialized
INFO - 2016-05-24 17:25:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:25:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:25:45 --> Email Class Initialized
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:25:45 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:25:45 --> Helper loaded: language_helper
INFO - 2016-05-24 17:25:45 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:25:45 --> Model Class Initialized
INFO - 2016-05-24 17:25:45 --> Helper loaded: date_helper
INFO - 2016-05-24 17:25:45 --> Controller Class Initialized
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:25:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:25:45 --> Model Class Initialized
INFO - 2016-05-24 17:25:45 --> Form Validation Class Initialized
INFO - 2016-05-24 17:27:02 --> Config Class Initialized
INFO - 2016-05-24 17:27:02 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:27:02 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:27:02 --> Utf8 Class Initialized
INFO - 2016-05-24 17:27:02 --> URI Class Initialized
INFO - 2016-05-24 17:27:02 --> Router Class Initialized
INFO - 2016-05-24 17:27:02 --> Output Class Initialized
INFO - 2016-05-24 17:27:02 --> Security Class Initialized
DEBUG - 2016-05-24 17:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:27:02 --> CSRF cookie sent
INFO - 2016-05-24 17:27:02 --> Input Class Initialized
INFO - 2016-05-24 17:27:02 --> Language Class Initialized
INFO - 2016-05-24 17:27:02 --> Loader Class Initialized
INFO - 2016-05-24 17:27:02 --> Helper loaded: form_helper
INFO - 2016-05-24 17:27:02 --> Database Driver Class Initialized
INFO - 2016-05-24 17:27:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:27:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:27:02 --> Email Class Initialized
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:27:02 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:27:02 --> Helper loaded: language_helper
INFO - 2016-05-24 17:27:02 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:27:02 --> Model Class Initialized
INFO - 2016-05-24 17:27:02 --> Helper loaded: date_helper
INFO - 2016-05-24 17:27:02 --> Controller Class Initialized
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:27:02 --> Model Class Initialized
INFO - 2016-05-24 17:27:02 --> Form Validation Class Initialized
INFO - 2016-05-24 17:27:02 --> Config Class Initialized
INFO - 2016-05-24 17:27:02 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:27:02 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:27:02 --> Utf8 Class Initialized
INFO - 2016-05-24 17:27:02 --> URI Class Initialized
INFO - 2016-05-24 17:27:02 --> Router Class Initialized
INFO - 2016-05-24 17:27:02 --> Output Class Initialized
INFO - 2016-05-24 17:27:02 --> Security Class Initialized
DEBUG - 2016-05-24 17:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:27:02 --> CSRF cookie sent
INFO - 2016-05-24 17:27:02 --> Input Class Initialized
INFO - 2016-05-24 17:27:02 --> Language Class Initialized
INFO - 2016-05-24 17:27:02 --> Loader Class Initialized
INFO - 2016-05-24 17:27:02 --> Helper loaded: form_helper
INFO - 2016-05-24 17:27:02 --> Database Driver Class Initialized
INFO - 2016-05-24 17:27:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:27:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:27:02 --> Email Class Initialized
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:27:02 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:27:02 --> Helper loaded: language_helper
INFO - 2016-05-24 17:27:02 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:27:02 --> Model Class Initialized
INFO - 2016-05-24 17:27:02 --> Helper loaded: date_helper
INFO - 2016-05-24 17:27:02 --> Controller Class Initialized
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:27:02 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:27:02 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:27:02 --> Form Validation Class Initialized
INFO - 2016-05-24 17:27:16 --> Config Class Initialized
INFO - 2016-05-24 17:27:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:27:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:27:16 --> Utf8 Class Initialized
INFO - 2016-05-24 17:27:16 --> URI Class Initialized
DEBUG - 2016-05-24 17:27:16 --> No URI present. Default controller set.
INFO - 2016-05-24 17:27:16 --> Router Class Initialized
INFO - 2016-05-24 17:27:16 --> Output Class Initialized
INFO - 2016-05-24 17:27:16 --> Security Class Initialized
DEBUG - 2016-05-24 17:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:27:16 --> CSRF cookie sent
INFO - 2016-05-24 17:27:16 --> Input Class Initialized
INFO - 2016-05-24 17:27:16 --> Language Class Initialized
INFO - 2016-05-24 17:27:16 --> Loader Class Initialized
INFO - 2016-05-24 17:27:16 --> Helper loaded: form_helper
INFO - 2016-05-24 17:27:16 --> Database Driver Class Initialized
INFO - 2016-05-24 17:27:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:27:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:27:16 --> Email Class Initialized
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:27:16 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:27:16 --> Helper loaded: language_helper
INFO - 2016-05-24 17:27:16 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:27:16 --> Model Class Initialized
INFO - 2016-05-24 17:27:16 --> Helper loaded: date_helper
INFO - 2016-05-24 17:27:16 --> Controller Class Initialized
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:27:16 --> Config Class Initialized
INFO - 2016-05-24 17:27:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:27:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:27:16 --> Utf8 Class Initialized
INFO - 2016-05-24 17:27:16 --> URI Class Initialized
INFO - 2016-05-24 17:27:16 --> Router Class Initialized
INFO - 2016-05-24 17:27:16 --> Output Class Initialized
INFO - 2016-05-24 17:27:16 --> Security Class Initialized
DEBUG - 2016-05-24 17:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:27:16 --> CSRF cookie sent
INFO - 2016-05-24 17:27:16 --> Input Class Initialized
INFO - 2016-05-24 17:27:16 --> Language Class Initialized
INFO - 2016-05-24 17:27:16 --> Loader Class Initialized
INFO - 2016-05-24 17:27:16 --> Helper loaded: form_helper
INFO - 2016-05-24 17:27:16 --> Database Driver Class Initialized
INFO - 2016-05-24 17:27:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:27:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:27:16 --> Email Class Initialized
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:27:16 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:27:16 --> Helper loaded: language_helper
INFO - 2016-05-24 17:27:16 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:27:16 --> Model Class Initialized
INFO - 2016-05-24 17:27:16 --> Helper loaded: date_helper
INFO - 2016-05-24 17:27:16 --> Controller Class Initialized
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:27:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:27:16 --> Model Class Initialized
INFO - 2016-05-24 17:27:16 --> Form Validation Class Initialized
INFO - 2016-05-24 17:27:35 --> Config Class Initialized
INFO - 2016-05-24 17:27:35 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:27:35 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:27:35 --> Utf8 Class Initialized
INFO - 2016-05-24 17:27:35 --> URI Class Initialized
INFO - 2016-05-24 17:27:35 --> Router Class Initialized
INFO - 2016-05-24 17:27:35 --> Output Class Initialized
INFO - 2016-05-24 17:27:35 --> Security Class Initialized
DEBUG - 2016-05-24 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:27:35 --> CSRF cookie sent
INFO - 2016-05-24 17:27:35 --> Input Class Initialized
INFO - 2016-05-24 17:27:35 --> Language Class Initialized
ERROR - 2016-05-24 17:27:35 --> Severity: Parsing Error --> syntax error, unexpected ';' /home/demis/www/platformadiabet/application/controllers/Diabet.php 29
INFO - 2016-05-24 17:27:47 --> Config Class Initialized
INFO - 2016-05-24 17:27:47 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:27:47 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:27:47 --> Utf8 Class Initialized
INFO - 2016-05-24 17:27:47 --> URI Class Initialized
INFO - 2016-05-24 17:27:47 --> Router Class Initialized
INFO - 2016-05-24 17:27:47 --> Output Class Initialized
INFO - 2016-05-24 17:27:47 --> Security Class Initialized
DEBUG - 2016-05-24 17:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:27:47 --> CSRF cookie sent
INFO - 2016-05-24 17:27:47 --> Input Class Initialized
INFO - 2016-05-24 17:27:47 --> Language Class Initialized
INFO - 2016-05-24 17:27:47 --> Loader Class Initialized
INFO - 2016-05-24 17:27:47 --> Helper loaded: form_helper
INFO - 2016-05-24 17:27:47 --> Database Driver Class Initialized
INFO - 2016-05-24 17:27:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:27:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:27:47 --> Email Class Initialized
INFO - 2016-05-24 17:27:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:27:47 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:27:47 --> Helper loaded: language_helper
INFO - 2016-05-24 17:27:47 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:27:47 --> Model Class Initialized
INFO - 2016-05-24 17:27:47 --> Helper loaded: date_helper
INFO - 2016-05-24 17:27:47 --> Controller Class Initialized
INFO - 2016-05-24 17:27:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:27:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:27:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:27:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:27:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:27:47 --> Model Class Initialized
INFO - 2016-05-24 17:27:47 --> Form Validation Class Initialized
INFO - 2016-05-24 17:28:17 --> Config Class Initialized
INFO - 2016-05-24 17:28:17 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:28:17 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:28:17 --> Utf8 Class Initialized
INFO - 2016-05-24 17:28:17 --> URI Class Initialized
INFO - 2016-05-24 17:28:17 --> Router Class Initialized
INFO - 2016-05-24 17:28:17 --> Output Class Initialized
INFO - 2016-05-24 17:28:17 --> Security Class Initialized
DEBUG - 2016-05-24 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:28:17 --> CSRF cookie sent
INFO - 2016-05-24 17:28:17 --> Input Class Initialized
INFO - 2016-05-24 17:28:17 --> Language Class Initialized
INFO - 2016-05-24 17:28:17 --> Loader Class Initialized
INFO - 2016-05-24 17:28:17 --> Helper loaded: form_helper
INFO - 2016-05-24 17:28:17 --> Database Driver Class Initialized
INFO - 2016-05-24 17:28:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:28:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:28:17 --> Email Class Initialized
INFO - 2016-05-24 17:28:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:28:17 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:28:17 --> Helper loaded: language_helper
INFO - 2016-05-24 17:28:17 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:28:17 --> Model Class Initialized
INFO - 2016-05-24 17:28:17 --> Helper loaded: date_helper
INFO - 2016-05-24 17:28:17 --> Controller Class Initialized
INFO - 2016-05-24 17:28:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:28:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:28:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:28:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:28:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:28:17 --> Model Class Initialized
INFO - 2016-05-24 17:28:17 --> Form Validation Class Initialized
INFO - 2016-05-24 17:28:36 --> Config Class Initialized
INFO - 2016-05-24 17:28:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:28:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:28:36 --> Utf8 Class Initialized
INFO - 2016-05-24 17:28:36 --> URI Class Initialized
INFO - 2016-05-24 17:28:36 --> Router Class Initialized
INFO - 2016-05-24 17:28:36 --> Output Class Initialized
INFO - 2016-05-24 17:28:36 --> Security Class Initialized
DEBUG - 2016-05-24 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:28:36 --> CSRF cookie sent
INFO - 2016-05-24 17:28:36 --> Input Class Initialized
INFO - 2016-05-24 17:28:36 --> Language Class Initialized
INFO - 2016-05-24 17:28:36 --> Loader Class Initialized
INFO - 2016-05-24 17:28:36 --> Helper loaded: form_helper
INFO - 2016-05-24 17:28:36 --> Database Driver Class Initialized
INFO - 2016-05-24 17:28:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:28:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:28:36 --> Email Class Initialized
INFO - 2016-05-24 17:28:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:28:36 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:28:36 --> Helper loaded: language_helper
INFO - 2016-05-24 17:28:36 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:28:36 --> Model Class Initialized
INFO - 2016-05-24 17:28:36 --> Helper loaded: date_helper
INFO - 2016-05-24 17:28:36 --> Controller Class Initialized
INFO - 2016-05-24 17:28:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:28:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:28:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:28:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:28:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:28:36 --> Model Class Initialized
INFO - 2016-05-24 17:28:36 --> Form Validation Class Initialized
INFO - 2016-05-24 17:28:44 --> Config Class Initialized
INFO - 2016-05-24 17:28:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:28:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:28:44 --> Utf8 Class Initialized
INFO - 2016-05-24 17:28:44 --> URI Class Initialized
INFO - 2016-05-24 17:28:44 --> Router Class Initialized
INFO - 2016-05-24 17:28:44 --> Output Class Initialized
INFO - 2016-05-24 17:28:44 --> Security Class Initialized
DEBUG - 2016-05-24 17:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:28:44 --> CSRF cookie sent
INFO - 2016-05-24 17:28:44 --> Input Class Initialized
INFO - 2016-05-24 17:28:44 --> Language Class Initialized
INFO - 2016-05-24 17:28:44 --> Loader Class Initialized
INFO - 2016-05-24 17:28:44 --> Helper loaded: form_helper
INFO - 2016-05-24 17:28:44 --> Database Driver Class Initialized
INFO - 2016-05-24 17:28:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:28:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:28:44 --> Email Class Initialized
INFO - 2016-05-24 17:28:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:28:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:28:44 --> Helper loaded: language_helper
INFO - 2016-05-24 17:28:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:28:44 --> Model Class Initialized
INFO - 2016-05-24 17:28:44 --> Helper loaded: date_helper
INFO - 2016-05-24 17:28:44 --> Controller Class Initialized
INFO - 2016-05-24 17:28:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:28:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:28:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:28:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:28:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:28:44 --> Model Class Initialized
INFO - 2016-05-24 17:28:44 --> Form Validation Class Initialized
INFO - 2016-05-24 17:28:53 --> Config Class Initialized
INFO - 2016-05-24 17:28:53 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:28:53 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:28:53 --> Utf8 Class Initialized
INFO - 2016-05-24 17:28:53 --> URI Class Initialized
INFO - 2016-05-24 17:28:53 --> Router Class Initialized
INFO - 2016-05-24 17:28:53 --> Output Class Initialized
INFO - 2016-05-24 17:28:53 --> Security Class Initialized
DEBUG - 2016-05-24 17:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:28:53 --> CSRF cookie sent
INFO - 2016-05-24 17:28:53 --> Input Class Initialized
INFO - 2016-05-24 17:28:53 --> Language Class Initialized
INFO - 2016-05-24 17:28:53 --> Loader Class Initialized
INFO - 2016-05-24 17:28:53 --> Helper loaded: form_helper
INFO - 2016-05-24 17:28:53 --> Database Driver Class Initialized
INFO - 2016-05-24 17:28:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:28:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:28:53 --> Email Class Initialized
INFO - 2016-05-24 17:28:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:28:53 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:28:53 --> Helper loaded: language_helper
INFO - 2016-05-24 17:28:53 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:28:53 --> Model Class Initialized
INFO - 2016-05-24 17:28:53 --> Helper loaded: date_helper
INFO - 2016-05-24 17:28:53 --> Controller Class Initialized
INFO - 2016-05-24 17:28:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:28:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:28:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:28:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:28:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:28:53 --> Model Class Initialized
INFO - 2016-05-24 17:28:53 --> Form Validation Class Initialized
INFO - 2016-05-24 17:29:00 --> Config Class Initialized
INFO - 2016-05-24 17:29:00 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:29:00 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:29:00 --> Utf8 Class Initialized
INFO - 2016-05-24 17:29:00 --> URI Class Initialized
INFO - 2016-05-24 17:29:00 --> Router Class Initialized
INFO - 2016-05-24 17:29:00 --> Output Class Initialized
INFO - 2016-05-24 17:29:00 --> Security Class Initialized
DEBUG - 2016-05-24 17:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:29:00 --> CSRF cookie sent
INFO - 2016-05-24 17:29:00 --> Input Class Initialized
INFO - 2016-05-24 17:29:00 --> Language Class Initialized
INFO - 2016-05-24 17:29:00 --> Loader Class Initialized
INFO - 2016-05-24 17:29:00 --> Helper loaded: form_helper
INFO - 2016-05-24 17:29:00 --> Database Driver Class Initialized
INFO - 2016-05-24 17:29:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:29:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:29:00 --> Email Class Initialized
INFO - 2016-05-24 17:29:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:29:00 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:29:00 --> Helper loaded: language_helper
INFO - 2016-05-24 17:29:00 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:29:00 --> Model Class Initialized
INFO - 2016-05-24 17:29:00 --> Helper loaded: date_helper
INFO - 2016-05-24 17:29:00 --> Controller Class Initialized
INFO - 2016-05-24 17:29:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:29:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:29:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:29:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:29:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:29:00 --> Model Class Initialized
INFO - 2016-05-24 17:29:00 --> Form Validation Class Initialized
INFO - 2016-05-24 17:29:00 --> Helper loaded: string_helper
INFO - 2016-05-24 17:29:00 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:29:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:29:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:29:00 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:29:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:29:00 --> Final output sent to browser
DEBUG - 2016-05-24 17:29:00 --> Total execution time: 0.0542
INFO - 2016-05-24 17:29:45 --> Config Class Initialized
INFO - 2016-05-24 17:29:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:29:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:29:45 --> Utf8 Class Initialized
INFO - 2016-05-24 17:29:45 --> URI Class Initialized
INFO - 2016-05-24 17:29:45 --> Router Class Initialized
INFO - 2016-05-24 17:29:45 --> Output Class Initialized
INFO - 2016-05-24 17:29:45 --> Security Class Initialized
DEBUG - 2016-05-24 17:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:29:45 --> CSRF cookie sent
INFO - 2016-05-24 17:29:45 --> Input Class Initialized
INFO - 2016-05-24 17:29:45 --> Language Class Initialized
INFO - 2016-05-24 17:29:45 --> Loader Class Initialized
INFO - 2016-05-24 17:29:45 --> Helper loaded: form_helper
INFO - 2016-05-24 17:29:45 --> Database Driver Class Initialized
INFO - 2016-05-24 17:29:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:29:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:29:45 --> Email Class Initialized
INFO - 2016-05-24 17:29:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:29:45 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:29:45 --> Helper loaded: language_helper
INFO - 2016-05-24 17:29:45 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:29:45 --> Model Class Initialized
INFO - 2016-05-24 17:29:45 --> Helper loaded: date_helper
INFO - 2016-05-24 17:29:45 --> Controller Class Initialized
INFO - 2016-05-24 17:29:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:29:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:29:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:29:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:29:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:29:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:29:45 --> Form Validation Class Initialized
INFO - 2016-05-24 17:29:45 --> Helper loaded: string_helper
INFO - 2016-05-24 17:29:45 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:29:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:29:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:29:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:29:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:29:45 --> Final output sent to browser
DEBUG - 2016-05-24 17:29:45 --> Total execution time: 0.1217
INFO - 2016-05-24 17:29:52 --> Config Class Initialized
INFO - 2016-05-24 17:29:52 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:29:52 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:29:52 --> Utf8 Class Initialized
INFO - 2016-05-24 17:29:52 --> URI Class Initialized
INFO - 2016-05-24 17:29:52 --> Router Class Initialized
INFO - 2016-05-24 17:29:52 --> Output Class Initialized
INFO - 2016-05-24 17:29:52 --> Security Class Initialized
DEBUG - 2016-05-24 17:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:29:52 --> CSRF cookie sent
INFO - 2016-05-24 17:29:52 --> Input Class Initialized
INFO - 2016-05-24 17:29:52 --> Language Class Initialized
INFO - 2016-05-24 17:29:52 --> Loader Class Initialized
INFO - 2016-05-24 17:29:52 --> Helper loaded: form_helper
INFO - 2016-05-24 17:29:52 --> Database Driver Class Initialized
INFO - 2016-05-24 17:29:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:29:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:29:52 --> Email Class Initialized
INFO - 2016-05-24 17:29:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:29:52 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:29:52 --> Helper loaded: language_helper
INFO - 2016-05-24 17:29:52 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:29:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:29:52 --> Model Class Initialized
INFO - 2016-05-24 17:29:52 --> Helper loaded: date_helper
INFO - 2016-05-24 17:29:52 --> Controller Class Initialized
INFO - 2016-05-24 17:29:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:29:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:29:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:29:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:29:52 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:29:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:29:52 --> Form Validation Class Initialized
INFO - 2016-05-24 17:29:52 --> Helper loaded: string_helper
INFO - 2016-05-24 17:29:52 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:29:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:29:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:29:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:29:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:29:52 --> Final output sent to browser
DEBUG - 2016-05-24 17:29:52 --> Total execution time: 0.1019
INFO - 2016-05-24 17:30:16 --> Config Class Initialized
INFO - 2016-05-24 17:30:16 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:30:16 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:30:16 --> Utf8 Class Initialized
INFO - 2016-05-24 17:30:16 --> URI Class Initialized
INFO - 2016-05-24 17:30:16 --> Router Class Initialized
INFO - 2016-05-24 17:30:16 --> Output Class Initialized
INFO - 2016-05-24 17:30:16 --> Security Class Initialized
DEBUG - 2016-05-24 17:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:30:16 --> CSRF cookie sent
INFO - 2016-05-24 17:30:16 --> Input Class Initialized
INFO - 2016-05-24 17:30:16 --> Language Class Initialized
INFO - 2016-05-24 17:30:16 --> Loader Class Initialized
INFO - 2016-05-24 17:30:16 --> Helper loaded: form_helper
INFO - 2016-05-24 17:30:16 --> Database Driver Class Initialized
INFO - 2016-05-24 17:30:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:30:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:30:16 --> Email Class Initialized
INFO - 2016-05-24 17:30:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:30:16 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:30:16 --> Helper loaded: language_helper
INFO - 2016-05-24 17:30:16 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:30:16 --> Model Class Initialized
INFO - 2016-05-24 17:30:16 --> Helper loaded: date_helper
INFO - 2016-05-24 17:30:16 --> Controller Class Initialized
INFO - 2016-05-24 17:30:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:30:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:30:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:30:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:30:16 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 17:30:16 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:30:16 --> Form Validation Class Initialized
INFO - 2016-05-24 17:30:16 --> Helper loaded: string_helper
INFO - 2016-05-24 17:30:16 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:30:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:30:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:30:16 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:30:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:30:16 --> Final output sent to browser
DEBUG - 2016-05-24 17:30:16 --> Total execution time: 0.0515
INFO - 2016-05-24 17:30:21 --> Config Class Initialized
INFO - 2016-05-24 17:30:21 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:30:21 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:30:21 --> Utf8 Class Initialized
INFO - 2016-05-24 17:30:21 --> URI Class Initialized
DEBUG - 2016-05-24 17:30:21 --> No URI present. Default controller set.
INFO - 2016-05-24 17:30:21 --> Router Class Initialized
INFO - 2016-05-24 17:30:21 --> Output Class Initialized
INFO - 2016-05-24 17:30:21 --> Security Class Initialized
DEBUG - 2016-05-24 17:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:30:21 --> CSRF cookie sent
INFO - 2016-05-24 17:30:21 --> Input Class Initialized
INFO - 2016-05-24 17:30:21 --> Language Class Initialized
INFO - 2016-05-24 17:30:21 --> Loader Class Initialized
INFO - 2016-05-24 17:30:21 --> Helper loaded: form_helper
INFO - 2016-05-24 17:30:21 --> Database Driver Class Initialized
INFO - 2016-05-24 17:30:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:30:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:30:21 --> Email Class Initialized
INFO - 2016-05-24 17:30:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:30:21 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:30:21 --> Helper loaded: language_helper
INFO - 2016-05-24 17:30:21 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:30:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:30:21 --> Model Class Initialized
INFO - 2016-05-24 17:30:21 --> Helper loaded: date_helper
INFO - 2016-05-24 17:30:21 --> Controller Class Initialized
INFO - 2016-05-24 17:30:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:30:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:30:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:30:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:30:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:30:22 --> Config Class Initialized
INFO - 2016-05-24 17:30:22 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:30:22 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:30:22 --> Utf8 Class Initialized
INFO - 2016-05-24 17:30:22 --> URI Class Initialized
INFO - 2016-05-24 17:30:22 --> Router Class Initialized
INFO - 2016-05-24 17:30:22 --> Output Class Initialized
INFO - 2016-05-24 17:30:22 --> Security Class Initialized
DEBUG - 2016-05-24 17:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:30:22 --> CSRF cookie sent
INFO - 2016-05-24 17:30:22 --> Input Class Initialized
INFO - 2016-05-24 17:30:22 --> Language Class Initialized
INFO - 2016-05-24 17:30:22 --> Loader Class Initialized
INFO - 2016-05-24 17:30:22 --> Helper loaded: form_helper
INFO - 2016-05-24 17:30:22 --> Database Driver Class Initialized
INFO - 2016-05-24 17:30:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:30:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:30:22 --> Email Class Initialized
INFO - 2016-05-24 17:30:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:30:22 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:30:22 --> Helper loaded: language_helper
INFO - 2016-05-24 17:30:22 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:30:22 --> Model Class Initialized
INFO - 2016-05-24 17:30:22 --> Helper loaded: date_helper
INFO - 2016-05-24 17:30:22 --> Controller Class Initialized
INFO - 2016-05-24 17:30:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:30:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:30:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:30:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:30:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:30:22 --> Model Class Initialized
INFO - 2016-05-24 17:30:22 --> Form Validation Class Initialized
INFO - 2016-05-24 17:30:22 --> Helper loaded: string_helper
INFO - 2016-05-24 17:30:22 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:30:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:30:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:30:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:30:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:30:22 --> Final output sent to browser
DEBUG - 2016-05-24 17:30:22 --> Total execution time: 0.0320
INFO - 2016-05-24 17:33:36 --> Config Class Initialized
INFO - 2016-05-24 17:33:36 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:33:36 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:33:36 --> Utf8 Class Initialized
INFO - 2016-05-24 17:33:36 --> URI Class Initialized
INFO - 2016-05-24 17:33:36 --> Router Class Initialized
INFO - 2016-05-24 17:33:36 --> Output Class Initialized
INFO - 2016-05-24 17:33:36 --> Security Class Initialized
DEBUG - 2016-05-24 17:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:33:36 --> CSRF cookie sent
INFO - 2016-05-24 17:33:36 --> Input Class Initialized
INFO - 2016-05-24 17:33:36 --> Language Class Initialized
INFO - 2016-05-24 17:33:36 --> Loader Class Initialized
INFO - 2016-05-24 17:33:36 --> Helper loaded: form_helper
INFO - 2016-05-24 17:33:36 --> Database Driver Class Initialized
INFO - 2016-05-24 17:33:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:33:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:33:36 --> Email Class Initialized
INFO - 2016-05-24 17:33:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:33:36 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:33:36 --> Helper loaded: language_helper
INFO - 2016-05-24 17:33:36 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:33:36 --> Model Class Initialized
INFO - 2016-05-24 17:33:36 --> Helper loaded: date_helper
INFO - 2016-05-24 17:33:36 --> Controller Class Initialized
INFO - 2016-05-24 17:33:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:33:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:33:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:33:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:33:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:33:36 --> Model Class Initialized
INFO - 2016-05-24 17:33:36 --> Form Validation Class Initialized
INFO - 2016-05-24 17:33:36 --> Helper loaded: string_helper
INFO - 2016-05-24 17:33:36 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:33:36 --> Final output sent to browser
DEBUG - 2016-05-24 17:33:36 --> Total execution time: 0.0784
INFO - 2016-05-24 17:35:23 --> Config Class Initialized
INFO - 2016-05-24 17:35:23 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:35:23 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:35:23 --> Utf8 Class Initialized
INFO - 2016-05-24 17:35:23 --> URI Class Initialized
INFO - 2016-05-24 17:35:23 --> Router Class Initialized
INFO - 2016-05-24 17:35:23 --> Output Class Initialized
INFO - 2016-05-24 17:35:23 --> Security Class Initialized
DEBUG - 2016-05-24 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:35:23 --> CSRF cookie sent
INFO - 2016-05-24 17:35:23 --> Input Class Initialized
INFO - 2016-05-24 17:35:23 --> Language Class Initialized
INFO - 2016-05-24 17:35:23 --> Loader Class Initialized
INFO - 2016-05-24 17:35:23 --> Helper loaded: form_helper
INFO - 2016-05-24 17:35:23 --> Database Driver Class Initialized
INFO - 2016-05-24 17:35:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:35:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:35:23 --> Email Class Initialized
INFO - 2016-05-24 17:35:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:35:23 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:35:23 --> Helper loaded: language_helper
INFO - 2016-05-24 17:35:23 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:35:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:35:23 --> Model Class Initialized
INFO - 2016-05-24 17:35:23 --> Helper loaded: date_helper
INFO - 2016-05-24 17:35:23 --> Controller Class Initialized
INFO - 2016-05-24 17:35:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:35:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:35:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:35:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:35:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:35:23 --> Model Class Initialized
INFO - 2016-05-24 17:35:23 --> Form Validation Class Initialized
INFO - 2016-05-24 17:35:23 --> Helper loaded: string_helper
INFO - 2016-05-24 17:35:23 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:35:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:35:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:35:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:35:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:35:23 --> Final output sent to browser
DEBUG - 2016-05-24 17:35:23 --> Total execution time: 0.0599
INFO - 2016-05-24 17:36:38 --> Config Class Initialized
INFO - 2016-05-24 17:36:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:36:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:36:38 --> Utf8 Class Initialized
INFO - 2016-05-24 17:36:38 --> URI Class Initialized
INFO - 2016-05-24 17:36:38 --> Router Class Initialized
INFO - 2016-05-24 17:36:38 --> Output Class Initialized
INFO - 2016-05-24 17:36:38 --> Security Class Initialized
DEBUG - 2016-05-24 17:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:36:38 --> CSRF cookie sent
INFO - 2016-05-24 17:36:38 --> Input Class Initialized
INFO - 2016-05-24 17:36:38 --> Language Class Initialized
INFO - 2016-05-24 17:36:38 --> Loader Class Initialized
INFO - 2016-05-24 17:36:38 --> Helper loaded: form_helper
INFO - 2016-05-24 17:36:38 --> Database Driver Class Initialized
INFO - 2016-05-24 17:36:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:36:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:36:38 --> Email Class Initialized
INFO - 2016-05-24 17:36:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:36:38 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:36:38 --> Helper loaded: language_helper
INFO - 2016-05-24 17:36:38 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:36:38 --> Model Class Initialized
INFO - 2016-05-24 17:36:38 --> Helper loaded: date_helper
INFO - 2016-05-24 17:36:38 --> Controller Class Initialized
INFO - 2016-05-24 17:36:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:36:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:36:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:36:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:36:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:36:38 --> Model Class Initialized
INFO - 2016-05-24 17:36:38 --> Form Validation Class Initialized
INFO - 2016-05-24 17:36:38 --> Helper loaded: string_helper
INFO - 2016-05-24 17:36:38 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:36:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:36:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:36:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:36:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:36:38 --> Final output sent to browser
DEBUG - 2016-05-24 17:36:38 --> Total execution time: 0.0565
INFO - 2016-05-24 17:38:58 --> Config Class Initialized
INFO - 2016-05-24 17:38:58 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:38:58 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:38:58 --> Utf8 Class Initialized
INFO - 2016-05-24 17:38:58 --> URI Class Initialized
INFO - 2016-05-24 17:38:58 --> Router Class Initialized
INFO - 2016-05-24 17:38:58 --> Output Class Initialized
INFO - 2016-05-24 17:38:58 --> Security Class Initialized
DEBUG - 2016-05-24 17:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:38:58 --> CSRF cookie sent
INFO - 2016-05-24 17:38:58 --> CSRF token verified
INFO - 2016-05-24 17:38:58 --> Input Class Initialized
INFO - 2016-05-24 17:38:58 --> Language Class Initialized
INFO - 2016-05-24 17:38:58 --> Loader Class Initialized
INFO - 2016-05-24 17:38:58 --> Helper loaded: form_helper
INFO - 2016-05-24 17:38:58 --> Database Driver Class Initialized
INFO - 2016-05-24 17:38:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:38:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:38:58 --> Email Class Initialized
INFO - 2016-05-24 17:38:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:38:58 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:38:58 --> Helper loaded: language_helper
INFO - 2016-05-24 17:38:58 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:38:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:38:58 --> Model Class Initialized
INFO - 2016-05-24 17:38:58 --> Helper loaded: date_helper
INFO - 2016-05-24 17:38:58 --> Controller Class Initialized
INFO - 2016-05-24 17:38:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:38:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:38:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:38:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:38:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:38:58 --> Model Class Initialized
INFO - 2016-05-24 17:38:58 --> Form Validation Class Initialized
INFO - 2016-05-24 17:38:58 --> Helper loaded: string_helper
INFO - 2016-05-24 17:38:58 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:38:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:38:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:38:58 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:38:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:38:58 --> Final output sent to browser
DEBUG - 2016-05-24 17:38:58 --> Total execution time: 0.2311
INFO - 2016-05-24 17:42:52 --> Config Class Initialized
INFO - 2016-05-24 17:42:52 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:42:52 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:42:52 --> Utf8 Class Initialized
INFO - 2016-05-24 17:42:52 --> URI Class Initialized
INFO - 2016-05-24 17:42:52 --> Router Class Initialized
INFO - 2016-05-24 17:42:52 --> Output Class Initialized
INFO - 2016-05-24 17:42:52 --> Security Class Initialized
DEBUG - 2016-05-24 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:42:52 --> CSRF cookie sent
INFO - 2016-05-24 17:42:52 --> Input Class Initialized
INFO - 2016-05-24 17:42:52 --> Language Class Initialized
INFO - 2016-05-24 17:42:52 --> Loader Class Initialized
INFO - 2016-05-24 17:42:52 --> Helper loaded: form_helper
INFO - 2016-05-24 17:42:52 --> Database Driver Class Initialized
INFO - 2016-05-24 17:42:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:42:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:42:52 --> Email Class Initialized
INFO - 2016-05-24 17:42:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:42:52 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:42:52 --> Helper loaded: language_helper
INFO - 2016-05-24 17:42:52 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:42:52 --> Model Class Initialized
INFO - 2016-05-24 17:42:52 --> Helper loaded: date_helper
INFO - 2016-05-24 17:42:52 --> Controller Class Initialized
INFO - 2016-05-24 17:42:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:42:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:42:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:42:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:42:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:42:52 --> Model Class Initialized
INFO - 2016-05-24 17:42:52 --> Form Validation Class Initialized
INFO - 2016-05-24 17:42:52 --> Helper loaded: string_helper
INFO - 2016-05-24 17:42:52 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:42:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:42:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:42:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:42:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:42:52 --> Final output sent to browser
DEBUG - 2016-05-24 17:42:52 --> Total execution time: 0.1395
INFO - 2016-05-24 17:43:03 --> Config Class Initialized
INFO - 2016-05-24 17:43:03 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:43:03 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:43:03 --> Utf8 Class Initialized
INFO - 2016-05-24 17:43:03 --> URI Class Initialized
INFO - 2016-05-24 17:43:03 --> Router Class Initialized
INFO - 2016-05-24 17:43:03 --> Output Class Initialized
INFO - 2016-05-24 17:43:03 --> Security Class Initialized
DEBUG - 2016-05-24 17:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:43:03 --> CSRF cookie sent
INFO - 2016-05-24 17:43:03 --> Input Class Initialized
INFO - 2016-05-24 17:43:03 --> Language Class Initialized
INFO - 2016-05-24 17:43:03 --> Loader Class Initialized
INFO - 2016-05-24 17:43:03 --> Helper loaded: form_helper
INFO - 2016-05-24 17:43:03 --> Database Driver Class Initialized
INFO - 2016-05-24 17:43:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:43:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:43:03 --> Email Class Initialized
INFO - 2016-05-24 17:43:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:43:03 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:43:03 --> Helper loaded: language_helper
INFO - 2016-05-24 17:43:03 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:43:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:43:03 --> Model Class Initialized
INFO - 2016-05-24 17:43:03 --> Helper loaded: date_helper
INFO - 2016-05-24 17:43:03 --> Controller Class Initialized
INFO - 2016-05-24 17:43:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:43:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:43:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:43:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:43:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:43:03 --> Model Class Initialized
INFO - 2016-05-24 17:43:03 --> Form Validation Class Initialized
INFO - 2016-05-24 17:43:03 --> Helper loaded: string_helper
INFO - 2016-05-24 17:43:03 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:43:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:43:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:43:03 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:43:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:43:03 --> Final output sent to browser
DEBUG - 2016-05-24 17:43:03 --> Total execution time: 0.0600
INFO - 2016-05-24 17:44:25 --> Config Class Initialized
INFO - 2016-05-24 17:44:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:44:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:44:25 --> Utf8 Class Initialized
INFO - 2016-05-24 17:44:25 --> URI Class Initialized
INFO - 2016-05-24 17:44:25 --> Router Class Initialized
INFO - 2016-05-24 17:44:25 --> Output Class Initialized
INFO - 2016-05-24 17:44:25 --> Security Class Initialized
DEBUG - 2016-05-24 17:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:44:25 --> CSRF cookie sent
INFO - 2016-05-24 17:44:25 --> Input Class Initialized
INFO - 2016-05-24 17:44:25 --> Language Class Initialized
INFO - 2016-05-24 17:44:25 --> Loader Class Initialized
INFO - 2016-05-24 17:44:25 --> Helper loaded: form_helper
INFO - 2016-05-24 17:44:25 --> Database Driver Class Initialized
INFO - 2016-05-24 17:44:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:44:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:44:25 --> Email Class Initialized
INFO - 2016-05-24 17:44:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:44:25 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:44:25 --> Helper loaded: language_helper
INFO - 2016-05-24 17:44:25 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:44:25 --> Model Class Initialized
INFO - 2016-05-24 17:44:25 --> Helper loaded: date_helper
INFO - 2016-05-24 17:44:25 --> Controller Class Initialized
INFO - 2016-05-24 17:44:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:44:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:44:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:44:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:44:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:44:25 --> Model Class Initialized
INFO - 2016-05-24 17:44:25 --> Form Validation Class Initialized
INFO - 2016-05-24 17:44:25 --> Helper loaded: string_helper
INFO - 2016-05-24 17:44:25 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:44:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:44:25 --> Final output sent to browser
DEBUG - 2016-05-24 17:44:25 --> Total execution time: 0.1175
INFO - 2016-05-24 17:45:38 --> Config Class Initialized
INFO - 2016-05-24 17:45:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:45:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:45:38 --> Utf8 Class Initialized
INFO - 2016-05-24 17:45:38 --> URI Class Initialized
INFO - 2016-05-24 17:45:38 --> Router Class Initialized
INFO - 2016-05-24 17:45:38 --> Output Class Initialized
INFO - 2016-05-24 17:45:38 --> Security Class Initialized
DEBUG - 2016-05-24 17:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:45:38 --> CSRF cookie sent
INFO - 2016-05-24 17:45:38 --> Input Class Initialized
INFO - 2016-05-24 17:45:38 --> Language Class Initialized
INFO - 2016-05-24 17:45:38 --> Loader Class Initialized
INFO - 2016-05-24 17:45:38 --> Helper loaded: form_helper
INFO - 2016-05-24 17:45:38 --> Database Driver Class Initialized
INFO - 2016-05-24 17:45:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:45:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:45:38 --> Email Class Initialized
INFO - 2016-05-24 17:45:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:45:38 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:45:38 --> Helper loaded: language_helper
INFO - 2016-05-24 17:45:38 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:45:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:45:38 --> Model Class Initialized
INFO - 2016-05-24 17:45:38 --> Helper loaded: date_helper
INFO - 2016-05-24 17:45:38 --> Controller Class Initialized
INFO - 2016-05-24 17:45:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:45:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:45:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:45:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:45:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:45:38 --> Model Class Initialized
INFO - 2016-05-24 17:45:38 --> Form Validation Class Initialized
INFO - 2016-05-24 17:45:38 --> Helper loaded: string_helper
INFO - 2016-05-24 17:45:38 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:45:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:45:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:45:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:45:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:45:38 --> Final output sent to browser
DEBUG - 2016-05-24 17:45:38 --> Total execution time: 0.0737
INFO - 2016-05-24 17:46:17 --> Config Class Initialized
INFO - 2016-05-24 17:46:17 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:46:17 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:46:17 --> Utf8 Class Initialized
INFO - 2016-05-24 17:46:17 --> URI Class Initialized
INFO - 2016-05-24 17:46:17 --> Router Class Initialized
INFO - 2016-05-24 17:46:17 --> Output Class Initialized
INFO - 2016-05-24 17:46:17 --> Security Class Initialized
DEBUG - 2016-05-24 17:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:46:17 --> CSRF cookie sent
INFO - 2016-05-24 17:46:17 --> Input Class Initialized
INFO - 2016-05-24 17:46:17 --> Language Class Initialized
INFO - 2016-05-24 17:46:17 --> Loader Class Initialized
INFO - 2016-05-24 17:46:17 --> Helper loaded: form_helper
INFO - 2016-05-24 17:46:17 --> Database Driver Class Initialized
INFO - 2016-05-24 17:46:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:46:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:46:17 --> Email Class Initialized
INFO - 2016-05-24 17:46:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:46:17 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:46:17 --> Helper loaded: language_helper
INFO - 2016-05-24 17:46:17 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:46:17 --> Model Class Initialized
INFO - 2016-05-24 17:46:17 --> Helper loaded: date_helper
INFO - 2016-05-24 17:46:17 --> Controller Class Initialized
INFO - 2016-05-24 17:46:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:46:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:46:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:46:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:46:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:46:17 --> Model Class Initialized
INFO - 2016-05-24 17:46:17 --> Form Validation Class Initialized
INFO - 2016-05-24 17:46:17 --> Helper loaded: string_helper
INFO - 2016-05-24 17:46:17 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:46:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:46:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-24 17:46:17 --> Severity: Notice --> Array to string conversion /home/demis/www/platformadiabet/application/views/auth/edit_user.php 33
INFO - 2016-05-24 17:46:17 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:46:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:46:17 --> Final output sent to browser
DEBUG - 2016-05-24 17:46:17 --> Total execution time: 0.1252
INFO - 2016-05-24 17:47:25 --> Config Class Initialized
INFO - 2016-05-24 17:47:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:47:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:47:25 --> Utf8 Class Initialized
INFO - 2016-05-24 17:47:25 --> URI Class Initialized
INFO - 2016-05-24 17:47:25 --> Router Class Initialized
INFO - 2016-05-24 17:47:25 --> Output Class Initialized
INFO - 2016-05-24 17:47:25 --> Security Class Initialized
DEBUG - 2016-05-24 17:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:47:25 --> CSRF cookie sent
INFO - 2016-05-24 17:47:25 --> Input Class Initialized
INFO - 2016-05-24 17:47:25 --> Language Class Initialized
INFO - 2016-05-24 17:47:25 --> Loader Class Initialized
INFO - 2016-05-24 17:47:25 --> Helper loaded: form_helper
INFO - 2016-05-24 17:47:25 --> Database Driver Class Initialized
INFO - 2016-05-24 17:47:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:47:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:47:25 --> Email Class Initialized
INFO - 2016-05-24 17:47:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:47:25 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:47:25 --> Helper loaded: language_helper
INFO - 2016-05-24 17:47:25 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:47:25 --> Model Class Initialized
INFO - 2016-05-24 17:47:25 --> Helper loaded: date_helper
INFO - 2016-05-24 17:47:25 --> Controller Class Initialized
INFO - 2016-05-24 17:47:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:47:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:47:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:47:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:47:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:47:25 --> Model Class Initialized
INFO - 2016-05-24 17:47:25 --> Form Validation Class Initialized
INFO - 2016-05-24 17:47:25 --> Helper loaded: string_helper
INFO - 2016-05-24 17:47:25 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:47:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:47:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:47:25 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:47:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:47:25 --> Final output sent to browser
DEBUG - 2016-05-24 17:47:25 --> Total execution time: 0.0633
INFO - 2016-05-24 17:57:44 --> Config Class Initialized
INFO - 2016-05-24 17:57:44 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:57:44 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:57:44 --> Utf8 Class Initialized
INFO - 2016-05-24 17:57:44 --> URI Class Initialized
INFO - 2016-05-24 17:57:44 --> Router Class Initialized
INFO - 2016-05-24 17:57:44 --> Output Class Initialized
INFO - 2016-05-24 17:57:44 --> Security Class Initialized
DEBUG - 2016-05-24 17:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:57:44 --> CSRF cookie sent
INFO - 2016-05-24 17:57:44 --> Input Class Initialized
INFO - 2016-05-24 17:57:44 --> Language Class Initialized
INFO - 2016-05-24 17:57:44 --> Loader Class Initialized
INFO - 2016-05-24 17:57:44 --> Helper loaded: form_helper
INFO - 2016-05-24 17:57:44 --> Database Driver Class Initialized
INFO - 2016-05-24 17:57:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:57:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:57:44 --> Email Class Initialized
INFO - 2016-05-24 17:57:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:57:44 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:57:44 --> Helper loaded: language_helper
INFO - 2016-05-24 17:57:44 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:57:44 --> Model Class Initialized
INFO - 2016-05-24 17:57:44 --> Helper loaded: date_helper
INFO - 2016-05-24 17:57:44 --> Controller Class Initialized
INFO - 2016-05-24 17:57:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:57:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:57:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:57:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:57:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:57:44 --> Model Class Initialized
INFO - 2016-05-24 17:57:44 --> Form Validation Class Initialized
INFO - 2016-05-24 17:57:44 --> Helper loaded: string_helper
INFO - 2016-05-24 17:57:44 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:57:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:57:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:57:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:57:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:57:44 --> Final output sent to browser
DEBUG - 2016-05-24 17:57:44 --> Total execution time: 0.1035
INFO - 2016-05-24 17:58:04 --> Config Class Initialized
INFO - 2016-05-24 17:58:04 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:58:04 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:58:04 --> Utf8 Class Initialized
INFO - 2016-05-24 17:58:04 --> URI Class Initialized
INFO - 2016-05-24 17:58:04 --> Router Class Initialized
INFO - 2016-05-24 17:58:04 --> Output Class Initialized
INFO - 2016-05-24 17:58:04 --> Security Class Initialized
DEBUG - 2016-05-24 17:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:58:04 --> CSRF cookie sent
INFO - 2016-05-24 17:58:04 --> Input Class Initialized
INFO - 2016-05-24 17:58:04 --> Language Class Initialized
INFO - 2016-05-24 17:58:04 --> Loader Class Initialized
INFO - 2016-05-24 17:58:04 --> Helper loaded: form_helper
INFO - 2016-05-24 17:58:04 --> Database Driver Class Initialized
INFO - 2016-05-24 17:58:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:58:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:58:04 --> Email Class Initialized
INFO - 2016-05-24 17:58:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:58:04 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:58:04 --> Helper loaded: language_helper
INFO - 2016-05-24 17:58:04 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:58:04 --> Model Class Initialized
INFO - 2016-05-24 17:58:04 --> Helper loaded: date_helper
INFO - 2016-05-24 17:58:04 --> Controller Class Initialized
INFO - 2016-05-24 17:58:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:58:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:58:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:58:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:58:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:58:04 --> Model Class Initialized
INFO - 2016-05-24 17:58:04 --> Form Validation Class Initialized
INFO - 2016-05-24 17:58:04 --> Helper loaded: string_helper
INFO - 2016-05-24 17:58:04 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:58:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:58:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:58:04 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:58:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:58:04 --> Final output sent to browser
DEBUG - 2016-05-24 17:58:04 --> Total execution time: 0.0634
INFO - 2016-05-24 17:59:19 --> Config Class Initialized
INFO - 2016-05-24 17:59:19 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:59:19 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:59:19 --> Utf8 Class Initialized
INFO - 2016-05-24 17:59:19 --> URI Class Initialized
INFO - 2016-05-24 17:59:19 --> Router Class Initialized
INFO - 2016-05-24 17:59:19 --> Output Class Initialized
INFO - 2016-05-24 17:59:19 --> Security Class Initialized
DEBUG - 2016-05-24 17:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:59:19 --> CSRF cookie sent
INFO - 2016-05-24 17:59:19 --> Input Class Initialized
INFO - 2016-05-24 17:59:19 --> Language Class Initialized
INFO - 2016-05-24 17:59:19 --> Loader Class Initialized
INFO - 2016-05-24 17:59:19 --> Helper loaded: form_helper
INFO - 2016-05-24 17:59:19 --> Database Driver Class Initialized
INFO - 2016-05-24 17:59:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:59:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:59:19 --> Email Class Initialized
INFO - 2016-05-24 17:59:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:59:19 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:59:19 --> Helper loaded: language_helper
INFO - 2016-05-24 17:59:19 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:59:19 --> Model Class Initialized
INFO - 2016-05-24 17:59:19 --> Helper loaded: date_helper
INFO - 2016-05-24 17:59:19 --> Controller Class Initialized
INFO - 2016-05-24 17:59:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:59:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:59:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:59:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:59:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:59:19 --> Model Class Initialized
INFO - 2016-05-24 17:59:19 --> Form Validation Class Initialized
INFO - 2016-05-24 17:59:19 --> Helper loaded: string_helper
INFO - 2016-05-24 17:59:19 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:59:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:59:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:59:19 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:59:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:59:19 --> Final output sent to browser
DEBUG - 2016-05-24 17:59:19 --> Total execution time: 0.1264
INFO - 2016-05-24 17:59:37 --> Config Class Initialized
INFO - 2016-05-24 17:59:37 --> Hooks Class Initialized
DEBUG - 2016-05-24 17:59:37 --> UTF-8 Support Enabled
INFO - 2016-05-24 17:59:37 --> Utf8 Class Initialized
INFO - 2016-05-24 17:59:37 --> URI Class Initialized
INFO - 2016-05-24 17:59:37 --> Router Class Initialized
INFO - 2016-05-24 17:59:37 --> Output Class Initialized
INFO - 2016-05-24 17:59:37 --> Security Class Initialized
DEBUG - 2016-05-24 17:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 17:59:37 --> CSRF cookie sent
INFO - 2016-05-24 17:59:37 --> Input Class Initialized
INFO - 2016-05-24 17:59:37 --> Language Class Initialized
INFO - 2016-05-24 17:59:37 --> Loader Class Initialized
INFO - 2016-05-24 17:59:37 --> Helper loaded: form_helper
INFO - 2016-05-24 17:59:37 --> Database Driver Class Initialized
INFO - 2016-05-24 17:59:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 17:59:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 17:59:37 --> Email Class Initialized
INFO - 2016-05-24 17:59:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 17:59:37 --> Helper loaded: cookie_helper
INFO - 2016-05-24 17:59:37 --> Helper loaded: language_helper
INFO - 2016-05-24 17:59:37 --> Helper loaded: url_helper
DEBUG - 2016-05-24 17:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 17:59:37 --> Model Class Initialized
INFO - 2016-05-24 17:59:37 --> Helper loaded: date_helper
INFO - 2016-05-24 17:59:37 --> Controller Class Initialized
INFO - 2016-05-24 17:59:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 17:59:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 17:59:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 17:59:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 17:59:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 17:59:37 --> Model Class Initialized
INFO - 2016-05-24 17:59:37 --> Form Validation Class Initialized
INFO - 2016-05-24 17:59:37 --> Helper loaded: string_helper
INFO - 2016-05-24 17:59:37 --> Helper loaded: languages_helper
INFO - 2016-05-24 17:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 17:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 17:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 17:59:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 17:59:37 --> Final output sent to browser
DEBUG - 2016-05-24 17:59:37 --> Total execution time: 0.0591
INFO - 2016-05-24 18:00:23 --> Config Class Initialized
INFO - 2016-05-24 18:00:23 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:00:23 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:00:23 --> Utf8 Class Initialized
INFO - 2016-05-24 18:00:23 --> URI Class Initialized
INFO - 2016-05-24 18:00:23 --> Router Class Initialized
INFO - 2016-05-24 18:00:23 --> Output Class Initialized
INFO - 2016-05-24 18:00:23 --> Security Class Initialized
DEBUG - 2016-05-24 18:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:00:23 --> CSRF cookie sent
INFO - 2016-05-24 18:00:23 --> Input Class Initialized
INFO - 2016-05-24 18:00:23 --> Language Class Initialized
INFO - 2016-05-24 18:00:23 --> Loader Class Initialized
INFO - 2016-05-24 18:00:23 --> Helper loaded: form_helper
INFO - 2016-05-24 18:00:23 --> Database Driver Class Initialized
INFO - 2016-05-24 18:00:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:00:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:00:23 --> Email Class Initialized
INFO - 2016-05-24 18:00:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:00:23 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:00:23 --> Helper loaded: language_helper
INFO - 2016-05-24 18:00:23 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:00:23 --> Model Class Initialized
INFO - 2016-05-24 18:00:23 --> Helper loaded: date_helper
INFO - 2016-05-24 18:00:23 --> Controller Class Initialized
INFO - 2016-05-24 18:00:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:00:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:00:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:00:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:00:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:00:23 --> Model Class Initialized
INFO - 2016-05-24 18:00:23 --> Form Validation Class Initialized
INFO - 2016-05-24 18:00:23 --> Helper loaded: string_helper
INFO - 2016-05-24 18:00:23 --> Helper loaded: languages_helper
INFO - 2016-05-24 18:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 18:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 18:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 18:00:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 18:00:23 --> Final output sent to browser
DEBUG - 2016-05-24 18:00:23 --> Total execution time: 0.0635
INFO - 2016-05-24 18:02:38 --> Config Class Initialized
INFO - 2016-05-24 18:02:38 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:02:38 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:02:38 --> Utf8 Class Initialized
INFO - 2016-05-24 18:02:38 --> URI Class Initialized
INFO - 2016-05-24 18:02:38 --> Router Class Initialized
INFO - 2016-05-24 18:02:38 --> Output Class Initialized
INFO - 2016-05-24 18:02:38 --> Security Class Initialized
DEBUG - 2016-05-24 18:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:02:38 --> CSRF cookie sent
INFO - 2016-05-24 18:02:38 --> Input Class Initialized
INFO - 2016-05-24 18:02:38 --> Language Class Initialized
INFO - 2016-05-24 18:02:38 --> Loader Class Initialized
INFO - 2016-05-24 18:02:38 --> Helper loaded: form_helper
INFO - 2016-05-24 18:02:38 --> Database Driver Class Initialized
INFO - 2016-05-24 18:02:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:02:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:02:38 --> Email Class Initialized
INFO - 2016-05-24 18:02:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:02:38 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:02:38 --> Helper loaded: language_helper
INFO - 2016-05-24 18:02:38 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:02:38 --> Model Class Initialized
INFO - 2016-05-24 18:02:38 --> Helper loaded: date_helper
INFO - 2016-05-24 18:02:38 --> Controller Class Initialized
INFO - 2016-05-24 18:02:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:02:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:02:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:02:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:02:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:02:38 --> Model Class Initialized
INFO - 2016-05-24 18:02:38 --> Form Validation Class Initialized
INFO - 2016-05-24 18:02:38 --> Helper loaded: string_helper
INFO - 2016-05-24 18:02:38 --> Helper loaded: languages_helper
INFO - 2016-05-24 18:02:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 18:02:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 18:02:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 18:02:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 18:02:38 --> Final output sent to browser
DEBUG - 2016-05-24 18:02:38 --> Total execution time: 0.0887
INFO - 2016-05-24 18:05:45 --> Config Class Initialized
INFO - 2016-05-24 18:05:45 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:05:45 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:05:45 --> Utf8 Class Initialized
INFO - 2016-05-24 18:05:45 --> URI Class Initialized
INFO - 2016-05-24 18:05:45 --> Router Class Initialized
INFO - 2016-05-24 18:05:45 --> Output Class Initialized
INFO - 2016-05-24 18:05:45 --> Security Class Initialized
DEBUG - 2016-05-24 18:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:05:45 --> CSRF cookie sent
INFO - 2016-05-24 18:05:45 --> Input Class Initialized
INFO - 2016-05-24 18:05:45 --> Language Class Initialized
INFO - 2016-05-24 18:05:45 --> Loader Class Initialized
INFO - 2016-05-24 18:05:45 --> Helper loaded: form_helper
INFO - 2016-05-24 18:05:45 --> Database Driver Class Initialized
INFO - 2016-05-24 18:05:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:05:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:05:45 --> Email Class Initialized
INFO - 2016-05-24 18:05:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:05:45 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:05:45 --> Helper loaded: language_helper
INFO - 2016-05-24 18:05:45 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:05:45 --> Model Class Initialized
INFO - 2016-05-24 18:05:45 --> Helper loaded: date_helper
INFO - 2016-05-24 18:05:45 --> Controller Class Initialized
INFO - 2016-05-24 18:05:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:05:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:05:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:05:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:05:45 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-24 18:05:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:05:45 --> Form Validation Class Initialized
INFO - 2016-05-24 18:05:45 --> Helper loaded: string_helper
INFO - 2016-05-24 18:05:45 --> Helper loaded: languages_helper
INFO - 2016-05-24 18:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 18:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 18:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 18:05:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 18:05:45 --> Final output sent to browser
DEBUG - 2016-05-24 18:05:45 --> Total execution time: 0.1241
INFO - 2016-05-24 18:07:25 --> Config Class Initialized
INFO - 2016-05-24 18:07:25 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:07:25 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:07:25 --> Utf8 Class Initialized
INFO - 2016-05-24 18:07:25 --> URI Class Initialized
DEBUG - 2016-05-24 18:07:25 --> No URI present. Default controller set.
INFO - 2016-05-24 18:07:25 --> Router Class Initialized
INFO - 2016-05-24 18:07:25 --> Output Class Initialized
INFO - 2016-05-24 18:07:25 --> Security Class Initialized
DEBUG - 2016-05-24 18:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:07:25 --> CSRF cookie sent
INFO - 2016-05-24 18:07:25 --> Input Class Initialized
INFO - 2016-05-24 18:07:25 --> Language Class Initialized
INFO - 2016-05-24 18:07:25 --> Loader Class Initialized
INFO - 2016-05-24 18:07:25 --> Helper loaded: form_helper
INFO - 2016-05-24 18:07:25 --> Database Driver Class Initialized
INFO - 2016-05-24 18:07:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:07:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:07:25 --> Email Class Initialized
INFO - 2016-05-24 18:07:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:07:25 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:07:25 --> Helper loaded: language_helper
INFO - 2016-05-24 18:07:25 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:07:25 --> Model Class Initialized
INFO - 2016-05-24 18:07:25 --> Helper loaded: date_helper
INFO - 2016-05-24 18:07:25 --> Controller Class Initialized
INFO - 2016-05-24 18:07:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:07:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:07:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:07:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:07:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:07:27 --> Config Class Initialized
INFO - 2016-05-24 18:07:27 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:07:27 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:07:27 --> Utf8 Class Initialized
INFO - 2016-05-24 18:07:27 --> URI Class Initialized
INFO - 2016-05-24 18:07:27 --> Router Class Initialized
INFO - 2016-05-24 18:07:27 --> Output Class Initialized
INFO - 2016-05-24 18:07:27 --> Security Class Initialized
DEBUG - 2016-05-24 18:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:07:27 --> CSRF cookie sent
INFO - 2016-05-24 18:07:27 --> Input Class Initialized
INFO - 2016-05-24 18:07:27 --> Language Class Initialized
INFO - 2016-05-24 18:07:27 --> Loader Class Initialized
INFO - 2016-05-24 18:07:27 --> Helper loaded: form_helper
INFO - 2016-05-24 18:07:27 --> Database Driver Class Initialized
INFO - 2016-05-24 18:07:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:07:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:07:27 --> Email Class Initialized
INFO - 2016-05-24 18:07:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:07:27 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:07:27 --> Helper loaded: language_helper
INFO - 2016-05-24 18:07:27 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:07:27 --> Model Class Initialized
INFO - 2016-05-24 18:07:27 --> Helper loaded: date_helper
INFO - 2016-05-24 18:07:27 --> Controller Class Initialized
INFO - 2016-05-24 18:07:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:07:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:07:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:07:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:07:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:07:27 --> Model Class Initialized
INFO - 2016-05-24 18:07:27 --> Form Validation Class Initialized
INFO - 2016-05-24 18:07:27 --> Helper loaded: string_helper
INFO - 2016-05-24 18:07:27 --> Helper loaded: languages_helper
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 18:07:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 18:07:27 --> Final output sent to browser
DEBUG - 2016-05-24 18:07:27 --> Total execution time: 0.0638
INFO - 2016-05-24 18:14:52 --> Config Class Initialized
INFO - 2016-05-24 18:14:52 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:14:52 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:14:52 --> Utf8 Class Initialized
INFO - 2016-05-24 18:14:52 --> URI Class Initialized
INFO - 2016-05-24 18:14:52 --> Router Class Initialized
INFO - 2016-05-24 18:14:52 --> Output Class Initialized
INFO - 2016-05-24 18:14:52 --> Security Class Initialized
DEBUG - 2016-05-24 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:14:52 --> CSRF cookie sent
INFO - 2016-05-24 18:14:52 --> Input Class Initialized
INFO - 2016-05-24 18:14:52 --> Language Class Initialized
INFO - 2016-05-24 18:14:52 --> Loader Class Initialized
INFO - 2016-05-24 18:14:52 --> Helper loaded: form_helper
INFO - 2016-05-24 18:14:52 --> Database Driver Class Initialized
INFO - 2016-05-24 18:14:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:14:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:14:52 --> Email Class Initialized
INFO - 2016-05-24 18:14:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:14:52 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:14:52 --> Helper loaded: language_helper
INFO - 2016-05-24 18:14:52 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:14:52 --> Model Class Initialized
INFO - 2016-05-24 18:14:52 --> Helper loaded: date_helper
INFO - 2016-05-24 18:14:52 --> Controller Class Initialized
INFO - 2016-05-24 18:14:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:14:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:14:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:14:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:14:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:14:52 --> Model Class Initialized
INFO - 2016-05-24 18:14:52 --> Form Validation Class Initialized
INFO - 2016-05-24 18:14:52 --> Helper loaded: string_helper
ERROR - 2016-05-24 18:14:52 --> Severity: Notice --> Undefined variable: languages /home/demis/www/platformadiabet/application/views/user_area/res/header.php 46
INFO - 2016-05-24 18:14:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 18:14:52 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-24 18:14:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 18:14:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 18:14:52 --> Final output sent to browser
DEBUG - 2016-05-24 18:14:52 --> Total execution time: 0.1005
INFO - 2016-05-24 18:19:56 --> Config Class Initialized
INFO - 2016-05-24 18:19:56 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:19:56 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:19:56 --> Utf8 Class Initialized
INFO - 2016-05-24 18:19:56 --> URI Class Initialized
INFO - 2016-05-24 18:19:56 --> Router Class Initialized
INFO - 2016-05-24 18:19:56 --> Output Class Initialized
INFO - 2016-05-24 18:19:56 --> Security Class Initialized
DEBUG - 2016-05-24 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:19:56 --> CSRF cookie sent
INFO - 2016-05-24 18:19:56 --> Input Class Initialized
INFO - 2016-05-24 18:19:56 --> Language Class Initialized
INFO - 2016-05-24 18:19:56 --> Loader Class Initialized
INFO - 2016-05-24 18:19:56 --> Helper loaded: form_helper
INFO - 2016-05-24 18:19:56 --> Database Driver Class Initialized
INFO - 2016-05-24 18:19:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:19:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:19:56 --> Email Class Initialized
INFO - 2016-05-24 18:19:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:19:56 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:19:56 --> Helper loaded: language_helper
INFO - 2016-05-24 18:19:56 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:19:56 --> Model Class Initialized
INFO - 2016-05-24 18:19:56 --> Helper loaded: date_helper
INFO - 2016-05-24 18:19:56 --> Controller Class Initialized
INFO - 2016-05-24 18:19:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:19:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:19:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:19:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:19:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:19:56 --> Model Class Initialized
INFO - 2016-05-24 18:19:56 --> Form Validation Class Initialized
INFO - 2016-05-24 18:19:56 --> Helper loaded: string_helper
ERROR - 2016-05-24 18:19:56 --> Severity: Notice --> Undefined variable: languages /home/demis/www/platformadiabet/application/views/user_area/res/header.php 46
INFO - 2016-05-24 18:24:20 --> Config Class Initialized
INFO - 2016-05-24 18:24:20 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:24:20 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:24:20 --> Utf8 Class Initialized
INFO - 2016-05-24 18:24:20 --> URI Class Initialized
INFO - 2016-05-24 18:24:20 --> Router Class Initialized
INFO - 2016-05-24 18:24:20 --> Output Class Initialized
INFO - 2016-05-24 18:24:20 --> Security Class Initialized
DEBUG - 2016-05-24 18:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:24:20 --> CSRF cookie sent
INFO - 2016-05-24 18:24:20 --> Input Class Initialized
INFO - 2016-05-24 18:24:20 --> Language Class Initialized
INFO - 2016-05-24 18:24:20 --> Loader Class Initialized
INFO - 2016-05-24 18:24:20 --> Helper loaded: form_helper
INFO - 2016-05-24 18:24:20 --> Database Driver Class Initialized
INFO - 2016-05-24 18:24:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:24:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:24:20 --> Email Class Initialized
INFO - 2016-05-24 18:24:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:24:20 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:24:20 --> Helper loaded: language_helper
INFO - 2016-05-24 18:24:20 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:24:20 --> Model Class Initialized
INFO - 2016-05-24 18:24:20 --> Helper loaded: date_helper
INFO - 2016-05-24 18:24:20 --> Controller Class Initialized
INFO - 2016-05-24 18:24:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:24:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:24:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:24:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:24:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:24:20 --> Model Class Initialized
INFO - 2016-05-24 18:24:20 --> Form Validation Class Initialized
INFO - 2016-05-24 18:24:20 --> Helper loaded: string_helper
INFO - 2016-05-24 18:24:20 --> Helper loaded: languages_helper
INFO - 2016-05-24 18:24:34 --> Config Class Initialized
INFO - 2016-05-24 18:24:34 --> Hooks Class Initialized
DEBUG - 2016-05-24 18:24:34 --> UTF-8 Support Enabled
INFO - 2016-05-24 18:24:34 --> Utf8 Class Initialized
INFO - 2016-05-24 18:24:34 --> URI Class Initialized
INFO - 2016-05-24 18:24:34 --> Router Class Initialized
INFO - 2016-05-24 18:24:34 --> Output Class Initialized
INFO - 2016-05-24 18:24:34 --> Security Class Initialized
DEBUG - 2016-05-24 18:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-24 18:24:34 --> CSRF cookie sent
INFO - 2016-05-24 18:24:34 --> Input Class Initialized
INFO - 2016-05-24 18:24:34 --> Language Class Initialized
INFO - 2016-05-24 18:24:34 --> Loader Class Initialized
INFO - 2016-05-24 18:24:34 --> Helper loaded: form_helper
INFO - 2016-05-24 18:24:34 --> Database Driver Class Initialized
INFO - 2016-05-24 18:24:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-24 18:24:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-24 18:24:34 --> Email Class Initialized
INFO - 2016-05-24 18:24:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-24 18:24:34 --> Helper loaded: cookie_helper
INFO - 2016-05-24 18:24:34 --> Helper loaded: language_helper
INFO - 2016-05-24 18:24:34 --> Helper loaded: url_helper
DEBUG - 2016-05-24 18:24:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-24 18:24:34 --> Model Class Initialized
INFO - 2016-05-24 18:24:34 --> Helper loaded: date_helper
INFO - 2016-05-24 18:24:34 --> Controller Class Initialized
INFO - 2016-05-24 18:24:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-24 18:24:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-24 18:24:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-24 18:24:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-24 18:24:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-24 18:24:34 --> Model Class Initialized
INFO - 2016-05-24 18:24:34 --> Form Validation Class Initialized
INFO - 2016-05-24 18:24:34 --> Helper loaded: string_helper
INFO - 2016-05-24 18:24:34 --> Helper loaded: languages_helper
INFO - 2016-05-24 18:24:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-24 18:24:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-24 18:24:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-24 18:24:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-24 18:24:34 --> Final output sent to browser
DEBUG - 2016-05-24 18:24:34 --> Total execution time: 0.0589
