<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-12 07:25:14 --> Config Class Initialized
INFO - 2016-06-12 07:25:14 --> Hooks Class Initialized
DEBUG - 2016-06-12 07:25:14 --> UTF-8 Support Enabled
INFO - 2016-06-12 07:25:14 --> Utf8 Class Initialized
INFO - 2016-06-12 07:25:14 --> URI Class Initialized
DEBUG - 2016-06-12 07:25:14 --> No URI present. Default controller set.
INFO - 2016-06-12 07:25:14 --> Router Class Initialized
INFO - 2016-06-12 07:25:14 --> Output Class Initialized
INFO - 2016-06-12 07:25:14 --> Security Class Initialized
DEBUG - 2016-06-12 07:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-12 07:25:14 --> Input Class Initialized
INFO - 2016-06-12 07:25:14 --> Language Class Initialized
INFO - 2016-06-12 07:25:14 --> Loader Class Initialized
INFO - 2016-06-12 07:25:14 --> Helper loaded: form_helper
INFO - 2016-06-12 07:25:15 --> Database Driver Class Initialized
INFO - 2016-06-12 07:25:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-12 07:25:15 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-12 07:25:15 --> Email Class Initialized
INFO - 2016-06-12 07:25:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-12 07:25:15 --> Helper loaded: cookie_helper
INFO - 2016-06-12 07:25:15 --> Helper loaded: language_helper
INFO - 2016-06-12 07:25:16 --> Helper loaded: url_helper
DEBUG - 2016-06-12 07:25:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-12 07:25:17 --> Model Class Initialized
INFO - 2016-06-12 07:25:17 --> Helper loaded: date_helper
INFO - 2016-06-12 07:25:17 --> Controller Class Initialized
INFO - 2016-06-12 07:25:17 --> Helper loaded: languages_helper
INFO - 2016-06-12 07:25:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-12 07:25:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-12 07:25:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-12 07:25:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-12 07:25:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-12 10:25:17 --> Model Class Initialized
INFO - 2016-06-12 10:25:17 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-12 10:25:17 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-12 10:25:18 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-12 10:25:18 --> Final output sent to browser
DEBUG - 2016-06-12 10:25:18 --> Total execution time: 3.5773
INFO - 2016-06-12 07:31:11 --> Config Class Initialized
INFO - 2016-06-12 07:31:11 --> Hooks Class Initialized
DEBUG - 2016-06-12 07:31:11 --> UTF-8 Support Enabled
INFO - 2016-06-12 07:31:11 --> Utf8 Class Initialized
INFO - 2016-06-12 07:31:11 --> URI Class Initialized
INFO - 2016-06-12 07:31:11 --> Router Class Initialized
INFO - 2016-06-12 07:31:11 --> Output Class Initialized
INFO - 2016-06-12 07:31:11 --> Security Class Initialized
DEBUG - 2016-06-12 07:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-12 07:31:11 --> Input Class Initialized
INFO - 2016-06-12 07:31:11 --> Language Class Initialized
INFO - 2016-06-12 07:31:11 --> Loader Class Initialized
INFO - 2016-06-12 07:31:11 --> Helper loaded: form_helper
INFO - 2016-06-12 07:31:11 --> Database Driver Class Initialized
INFO - 2016-06-12 07:31:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-12 07:31:11 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-12 07:31:11 --> Email Class Initialized
INFO - 2016-06-12 07:31:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-12 07:31:11 --> Helper loaded: cookie_helper
INFO - 2016-06-12 07:31:11 --> Helper loaded: language_helper
INFO - 2016-06-12 07:31:11 --> Helper loaded: url_helper
DEBUG - 2016-06-12 07:31:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-12 07:31:11 --> Model Class Initialized
INFO - 2016-06-12 07:31:11 --> Helper loaded: date_helper
INFO - 2016-06-12 07:31:11 --> Controller Class Initialized
INFO - 2016-06-12 07:31:11 --> Helper loaded: languages_helper
INFO - 2016-06-12 07:31:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-12 07:31:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-12 07:31:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-12 07:31:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-12 07:31:11 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-12 10:31:11 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-12 10:31:12 --> Form Validation Class Initialized
DEBUG - 2016-06-12 10:31:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-12 10:31:12 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-12 10:31:12 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-12 10:31:12 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-12 10:31:12 --> Final output sent to browser
DEBUG - 2016-06-12 10:31:12 --> Total execution time: 0.6105
INFO - 2016-06-12 14:22:36 --> Config Class Initialized
INFO - 2016-06-12 14:22:36 --> Hooks Class Initialized
DEBUG - 2016-06-12 14:22:36 --> UTF-8 Support Enabled
INFO - 2016-06-12 14:22:36 --> Utf8 Class Initialized
INFO - 2016-06-12 14:22:36 --> URI Class Initialized
DEBUG - 2016-06-12 14:22:36 --> No URI present. Default controller set.
INFO - 2016-06-12 14:22:36 --> Router Class Initialized
INFO - 2016-06-12 14:22:36 --> Output Class Initialized
INFO - 2016-06-12 14:22:36 --> Security Class Initialized
DEBUG - 2016-06-12 14:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-12 14:22:36 --> Input Class Initialized
INFO - 2016-06-12 14:22:36 --> Language Class Initialized
INFO - 2016-06-12 14:22:36 --> Loader Class Initialized
INFO - 2016-06-12 14:22:36 --> Helper loaded: form_helper
INFO - 2016-06-12 14:22:36 --> Database Driver Class Initialized
INFO - 2016-06-12 14:22:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-12 14:22:36 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-12 14:22:36 --> Email Class Initialized
INFO - 2016-06-12 14:22:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-12 14:22:36 --> Helper loaded: cookie_helper
INFO - 2016-06-12 14:22:36 --> Helper loaded: language_helper
INFO - 2016-06-12 14:22:36 --> Helper loaded: url_helper
DEBUG - 2016-06-12 14:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-12 14:22:36 --> Model Class Initialized
INFO - 2016-06-12 14:22:36 --> Helper loaded: date_helper
INFO - 2016-06-12 14:22:36 --> Controller Class Initialized
INFO - 2016-06-12 14:22:36 --> Helper loaded: languages_helper
INFO - 2016-06-12 14:22:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-12 14:22:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-12 14:22:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-12 14:22:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-12 14:22:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-12 17:22:36 --> Model Class Initialized
INFO - 2016-06-12 17:22:36 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-12 17:22:36 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-12 17:22:36 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-12 17:22:36 --> Final output sent to browser
DEBUG - 2016-06-12 17:22:36 --> Total execution time: 0.0945
