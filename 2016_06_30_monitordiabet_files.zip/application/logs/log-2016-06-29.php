<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-29 14:03:49 --> Config Class Initialized
INFO - 2016-06-29 14:03:49 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:03:49 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:03:49 --> Utf8 Class Initialized
INFO - 2016-06-29 14:03:49 --> URI Class Initialized
DEBUG - 2016-06-29 14:03:49 --> No URI present. Default controller set.
INFO - 2016-06-29 14:03:49 --> Router Class Initialized
INFO - 2016-06-29 14:03:49 --> Output Class Initialized
INFO - 2016-06-29 14:03:49 --> Security Class Initialized
DEBUG - 2016-06-29 14:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:03:49 --> Input Class Initialized
INFO - 2016-06-29 14:03:49 --> Language Class Initialized
INFO - 2016-06-29 14:03:49 --> Loader Class Initialized
INFO - 2016-06-29 14:03:50 --> Helper loaded: form_helper
INFO - 2016-06-29 14:03:50 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:03:50 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:03:50 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:03:50 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:03:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:03:50 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:03:50 --> Email Class Initialized
INFO - 2016-06-29 14:03:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:03:50 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:03:50 --> Helper loaded: language_helper
INFO - 2016-06-29 14:03:50 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:03:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:03:50 --> Model Class Initialized
INFO - 2016-06-29 14:03:50 --> Helper loaded: date_helper
INFO - 2016-06-29 14:03:50 --> Controller Class Initialized
INFO - 2016-06-29 14:03:50 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:03:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:03:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:03:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:03:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:03:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:03:50 --> Model Class Initialized
INFO - 2016-06-29 17:03:50 --> Form Validation Class Initialized
INFO - 2016-06-29 17:03:50 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-29 17:03:50 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-29 17:03:50 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-29 17:03:50 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-29 17:03:50 --> Final output sent to browser
DEBUG - 2016-06-29 17:03:50 --> Total execution time: 1.4606
INFO - 2016-06-29 14:03:54 --> Config Class Initialized
INFO - 2016-06-29 14:03:54 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:03:54 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:03:54 --> Utf8 Class Initialized
INFO - 2016-06-29 14:03:54 --> URI Class Initialized
INFO - 2016-06-29 14:03:54 --> Router Class Initialized
INFO - 2016-06-29 14:03:54 --> Output Class Initialized
INFO - 2016-06-29 14:03:54 --> Security Class Initialized
DEBUG - 2016-06-29 14:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:03:54 --> Input Class Initialized
INFO - 2016-06-29 14:03:54 --> Language Class Initialized
INFO - 2016-06-29 14:03:54 --> Loader Class Initialized
INFO - 2016-06-29 14:03:54 --> Helper loaded: form_helper
INFO - 2016-06-29 14:03:54 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:03:54 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:03:54 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:03:54 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:03:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:03:54 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:03:54 --> Email Class Initialized
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:03:54 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:03:54 --> Helper loaded: language_helper
INFO - 2016-06-29 14:03:54 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:03:54 --> Model Class Initialized
INFO - 2016-06-29 14:03:54 --> Helper loaded: date_helper
INFO - 2016-06-29 14:03:54 --> Controller Class Initialized
INFO - 2016-06-29 14:03:54 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:03:54 --> Model Class Initialized
INFO - 2016-06-29 17:03:54 --> Final output sent to browser
DEBUG - 2016-06-29 17:03:54 --> Total execution time: 0.1498
INFO - 2016-06-29 14:03:54 --> Config Class Initialized
INFO - 2016-06-29 14:03:54 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:03:54 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:03:54 --> Utf8 Class Initialized
INFO - 2016-06-29 14:03:54 --> URI Class Initialized
DEBUG - 2016-06-29 14:03:54 --> No URI present. Default controller set.
INFO - 2016-06-29 14:03:54 --> Router Class Initialized
INFO - 2016-06-29 14:03:54 --> Output Class Initialized
INFO - 2016-06-29 14:03:54 --> Security Class Initialized
DEBUG - 2016-06-29 14:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:03:54 --> Input Class Initialized
INFO - 2016-06-29 14:03:54 --> Language Class Initialized
INFO - 2016-06-29 14:03:54 --> Loader Class Initialized
INFO - 2016-06-29 14:03:54 --> Helper loaded: form_helper
INFO - 2016-06-29 14:03:54 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:03:54 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:03:54 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:03:54 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:03:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:03:54 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:03:54 --> Email Class Initialized
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:03:54 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:03:54 --> Helper loaded: language_helper
INFO - 2016-06-29 14:03:54 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:03:54 --> Model Class Initialized
INFO - 2016-06-29 14:03:54 --> Helper loaded: date_helper
INFO - 2016-06-29 14:03:54 --> Controller Class Initialized
INFO - 2016-06-29 14:03:54 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:03:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:03:54 --> Model Class Initialized
INFO - 2016-06-29 17:03:54 --> Form Validation Class Initialized
INFO - 2016-06-29 17:03:54 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-29 17:03:54 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-29 17:03:54 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-29 17:03:54 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-29 17:03:54 --> Final output sent to browser
DEBUG - 2016-06-29 17:03:54 --> Total execution time: 0.0873
INFO - 2016-06-29 14:03:55 --> Config Class Initialized
INFO - 2016-06-29 14:03:55 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:03:55 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:03:55 --> Utf8 Class Initialized
INFO - 2016-06-29 14:03:55 --> URI Class Initialized
INFO - 2016-06-29 14:03:55 --> Router Class Initialized
INFO - 2016-06-29 14:03:55 --> Output Class Initialized
INFO - 2016-06-29 14:03:55 --> Security Class Initialized
DEBUG - 2016-06-29 14:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:03:55 --> Input Class Initialized
INFO - 2016-06-29 14:03:55 --> Language Class Initialized
INFO - 2016-06-29 14:03:55 --> Loader Class Initialized
INFO - 2016-06-29 14:03:55 --> Helper loaded: form_helper
INFO - 2016-06-29 14:03:55 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:03:55 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:03:55 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:03:55 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:03:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:03:55 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:03:55 --> Email Class Initialized
INFO - 2016-06-29 14:03:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:03:55 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:03:55 --> Helper loaded: language_helper
INFO - 2016-06-29 14:03:55 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:03:55 --> Model Class Initialized
INFO - 2016-06-29 14:03:55 --> Helper loaded: date_helper
INFO - 2016-06-29 14:03:55 --> Controller Class Initialized
INFO - 2016-06-29 14:03:55 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:03:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:03:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:03:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:03:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:03:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:03:55 --> Model Class Initialized
INFO - 2016-06-29 17:03:55 --> Final output sent to browser
DEBUG - 2016-06-29 17:03:55 --> Total execution time: 0.0765
INFO - 2016-06-29 14:04:02 --> Config Class Initialized
INFO - 2016-06-29 14:04:02 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:04:02 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:04:02 --> Utf8 Class Initialized
INFO - 2016-06-29 14:04:02 --> URI Class Initialized
DEBUG - 2016-06-29 14:04:02 --> No URI present. Default controller set.
INFO - 2016-06-29 14:04:02 --> Router Class Initialized
INFO - 2016-06-29 14:04:02 --> Output Class Initialized
INFO - 2016-06-29 14:04:02 --> Security Class Initialized
DEBUG - 2016-06-29 14:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:04:02 --> Input Class Initialized
INFO - 2016-06-29 14:04:02 --> Language Class Initialized
INFO - 2016-06-29 14:04:02 --> Loader Class Initialized
INFO - 2016-06-29 14:04:02 --> Helper loaded: form_helper
INFO - 2016-06-29 14:04:02 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:04:02 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:04:02 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:04:02 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:04:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:04:02 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:04:02 --> Email Class Initialized
INFO - 2016-06-29 14:04:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:04:02 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:04:02 --> Helper loaded: language_helper
INFO - 2016-06-29 14:04:02 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:04:02 --> Model Class Initialized
INFO - 2016-06-29 14:04:02 --> Helper loaded: date_helper
INFO - 2016-06-29 14:04:02 --> Controller Class Initialized
INFO - 2016-06-29 14:04:02 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:04:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:04:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:04:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:04:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:04:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:04:02 --> Model Class Initialized
INFO - 2016-06-29 17:04:02 --> Form Validation Class Initialized
INFO - 2016-06-29 17:04:02 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-29 17:04:02 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-29 17:04:02 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-29 17:04:02 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-29 17:04:02 --> Final output sent to browser
DEBUG - 2016-06-29 17:04:02 --> Total execution time: 0.1845
INFO - 2016-06-29 14:04:03 --> Config Class Initialized
INFO - 2016-06-29 14:04:03 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:04:03 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:04:03 --> Utf8 Class Initialized
INFO - 2016-06-29 14:04:03 --> URI Class Initialized
INFO - 2016-06-29 14:04:03 --> Router Class Initialized
INFO - 2016-06-29 14:04:03 --> Output Class Initialized
INFO - 2016-06-29 14:04:03 --> Security Class Initialized
DEBUG - 2016-06-29 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:04:03 --> Input Class Initialized
INFO - 2016-06-29 14:04:03 --> Language Class Initialized
INFO - 2016-06-29 14:04:03 --> Loader Class Initialized
INFO - 2016-06-29 14:04:03 --> Helper loaded: form_helper
INFO - 2016-06-29 14:04:03 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:04:03 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:04:03 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:04:03 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:04:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:04:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:04:03 --> Email Class Initialized
INFO - 2016-06-29 14:04:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:04:03 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:04:03 --> Helper loaded: language_helper
INFO - 2016-06-29 14:04:03 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:04:03 --> Model Class Initialized
INFO - 2016-06-29 14:04:03 --> Helper loaded: date_helper
INFO - 2016-06-29 14:04:03 --> Controller Class Initialized
INFO - 2016-06-29 14:04:03 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:04:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:04:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:04:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:04:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:04:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:04:03 --> Model Class Initialized
INFO - 2016-06-29 17:04:03 --> Final output sent to browser
DEBUG - 2016-06-29 17:04:03 --> Total execution time: 0.0808
INFO - 2016-06-29 14:12:51 --> Config Class Initialized
INFO - 2016-06-29 14:12:51 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:12:51 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:12:51 --> Utf8 Class Initialized
INFO - 2016-06-29 14:12:51 --> URI Class Initialized
DEBUG - 2016-06-29 14:12:51 --> No URI present. Default controller set.
INFO - 2016-06-29 14:12:51 --> Router Class Initialized
INFO - 2016-06-29 14:12:51 --> Output Class Initialized
INFO - 2016-06-29 14:12:51 --> Security Class Initialized
DEBUG - 2016-06-29 14:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:12:51 --> Input Class Initialized
INFO - 2016-06-29 14:12:51 --> Language Class Initialized
INFO - 2016-06-29 14:12:51 --> Loader Class Initialized
INFO - 2016-06-29 14:12:51 --> Helper loaded: form_helper
INFO - 2016-06-29 14:12:51 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:12:51 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:12:51 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:12:51 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:12:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:12:51 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:12:51 --> Email Class Initialized
INFO - 2016-06-29 14:12:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:12:51 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:12:51 --> Helper loaded: language_helper
INFO - 2016-06-29 14:12:51 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:12:51 --> Model Class Initialized
INFO - 2016-06-29 14:12:51 --> Helper loaded: date_helper
INFO - 2016-06-29 14:12:51 --> Controller Class Initialized
INFO - 2016-06-29 14:12:51 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:12:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:12:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:12:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:12:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:12:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:12:51 --> Model Class Initialized
INFO - 2016-06-29 17:12:51 --> Form Validation Class Initialized
INFO - 2016-06-29 17:12:51 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-29 17:12:51 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-29 17:12:51 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-29 17:12:51 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-29 17:12:51 --> Final output sent to browser
DEBUG - 2016-06-29 17:12:51 --> Total execution time: 0.1651
INFO - 2016-06-29 14:12:57 --> Config Class Initialized
INFO - 2016-06-29 14:12:57 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:12:57 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:12:57 --> Utf8 Class Initialized
INFO - 2016-06-29 14:12:57 --> URI Class Initialized
INFO - 2016-06-29 14:12:57 --> Router Class Initialized
INFO - 2016-06-29 14:12:57 --> Output Class Initialized
INFO - 2016-06-29 14:12:57 --> Security Class Initialized
DEBUG - 2016-06-29 14:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:12:57 --> Input Class Initialized
INFO - 2016-06-29 14:12:57 --> Language Class Initialized
INFO - 2016-06-29 14:12:57 --> Loader Class Initialized
INFO - 2016-06-29 14:12:57 --> Helper loaded: form_helper
INFO - 2016-06-29 14:12:57 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:12:57 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:12:57 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:12:57 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:12:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:12:57 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:12:57 --> Email Class Initialized
INFO - 2016-06-29 14:12:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:12:57 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:12:57 --> Helper loaded: language_helper
INFO - 2016-06-29 14:12:57 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:12:57 --> Model Class Initialized
INFO - 2016-06-29 14:12:57 --> Helper loaded: date_helper
INFO - 2016-06-29 14:12:57 --> Controller Class Initialized
INFO - 2016-06-29 14:12:57 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:12:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:12:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:12:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:12:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:12:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:12:57 --> Model Class Initialized
INFO - 2016-06-29 17:12:57 --> Final output sent to browser
DEBUG - 2016-06-29 17:12:57 --> Total execution time: 0.1400
INFO - 2016-06-29 14:13:24 --> Config Class Initialized
INFO - 2016-06-29 14:13:24 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:13:24 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:13:24 --> Utf8 Class Initialized
INFO - 2016-06-29 14:13:24 --> URI Class Initialized
DEBUG - 2016-06-29 14:13:24 --> No URI present. Default controller set.
INFO - 2016-06-29 14:13:24 --> Router Class Initialized
INFO - 2016-06-29 14:13:25 --> Output Class Initialized
INFO - 2016-06-29 14:13:25 --> Security Class Initialized
DEBUG - 2016-06-29 14:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:13:25 --> Input Class Initialized
INFO - 2016-06-29 14:13:25 --> Language Class Initialized
INFO - 2016-06-29 14:13:25 --> Loader Class Initialized
INFO - 2016-06-29 14:13:25 --> Helper loaded: form_helper
INFO - 2016-06-29 14:13:25 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:13:25 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:13:25 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:13:25 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:13:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:13:25 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:13:25 --> Email Class Initialized
INFO - 2016-06-29 14:13:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:13:25 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:13:25 --> Helper loaded: language_helper
INFO - 2016-06-29 14:13:25 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:13:25 --> Model Class Initialized
INFO - 2016-06-29 14:13:25 --> Helper loaded: date_helper
INFO - 2016-06-29 14:13:25 --> Controller Class Initialized
INFO - 2016-06-29 14:13:25 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:13:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:13:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:13:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:13:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:13:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:13:25 --> Model Class Initialized
INFO - 2016-06-29 17:13:25 --> Form Validation Class Initialized
INFO - 2016-06-29 17:13:25 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-29 17:13:25 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-29 17:13:25 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-29 17:13:25 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-29 17:13:25 --> Final output sent to browser
DEBUG - 2016-06-29 17:13:25 --> Total execution time: 0.1862
INFO - 2016-06-29 14:13:30 --> Config Class Initialized
INFO - 2016-06-29 14:13:30 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:13:30 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:13:30 --> Utf8 Class Initialized
INFO - 2016-06-29 14:13:30 --> URI Class Initialized
INFO - 2016-06-29 14:13:30 --> Router Class Initialized
INFO - 2016-06-29 14:13:30 --> Output Class Initialized
INFO - 2016-06-29 14:13:30 --> Security Class Initialized
DEBUG - 2016-06-29 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:13:30 --> Input Class Initialized
INFO - 2016-06-29 14:13:30 --> Language Class Initialized
INFO - 2016-06-29 14:13:30 --> Loader Class Initialized
INFO - 2016-06-29 14:13:30 --> Helper loaded: form_helper
INFO - 2016-06-29 14:13:30 --> Database Driver Class Initialized
ERROR - 2016-06-29 14:13:31 --> Severity: Warning --> mysqli::real_connect(): Headers and client library minor version mismatch. Headers:50549 Library:50630 /home/diabet/public_html/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2016-06-29 14:13:31 --> Severity: Warning --> session_start(): Cannot send session cookie - headers already sent by (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
ERROR - 2016-06-29 14:13:31 --> Severity: Warning --> session_start(): Cannot send session cache limiter - headers already sent (output started at /home/diabet/public_html/system/core/Exceptions.php:272) /home/diabet/public_html/system/libraries/Session/Session.php 140
INFO - 2016-06-29 14:13:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:13:31 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:13:31 --> Email Class Initialized
INFO - 2016-06-29 14:13:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:13:31 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:13:31 --> Helper loaded: language_helper
INFO - 2016-06-29 14:13:31 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:13:31 --> Model Class Initialized
INFO - 2016-06-29 14:13:31 --> Helper loaded: date_helper
INFO - 2016-06-29 14:13:31 --> Controller Class Initialized
INFO - 2016-06-29 14:13:31 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:13:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:13:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:13:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:13:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:13:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:13:31 --> Model Class Initialized
INFO - 2016-06-29 17:13:31 --> Final output sent to browser
DEBUG - 2016-06-29 17:13:31 --> Total execution time: 0.1680
INFO - 2016-06-29 14:20:04 --> Config Class Initialized
INFO - 2016-06-29 14:20:04 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:20:04 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:20:04 --> Utf8 Class Initialized
INFO - 2016-06-29 14:20:04 --> URI Class Initialized
DEBUG - 2016-06-29 14:20:04 --> No URI present. Default controller set.
INFO - 2016-06-29 14:20:04 --> Router Class Initialized
INFO - 2016-06-29 14:20:04 --> Output Class Initialized
INFO - 2016-06-29 14:20:04 --> Security Class Initialized
DEBUG - 2016-06-29 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:20:04 --> Input Class Initialized
INFO - 2016-06-29 14:20:04 --> Language Class Initialized
INFO - 2016-06-29 14:20:04 --> Loader Class Initialized
INFO - 2016-06-29 14:20:04 --> Helper loaded: form_helper
INFO - 2016-06-29 14:20:04 --> Database Driver Class Initialized
INFO - 2016-06-29 14:20:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:20:04 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:20:04 --> Email Class Initialized
INFO - 2016-06-29 14:20:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:20:04 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:20:04 --> Helper loaded: language_helper
INFO - 2016-06-29 14:20:04 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:20:04 --> Model Class Initialized
INFO - 2016-06-29 14:20:04 --> Helper loaded: date_helper
INFO - 2016-06-29 14:20:04 --> Controller Class Initialized
INFO - 2016-06-29 14:20:04 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:20:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:20:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:20:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:20:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:20:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:20:04 --> Model Class Initialized
INFO - 2016-06-29 17:20:04 --> Form Validation Class Initialized
INFO - 2016-06-29 17:20:04 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-29 17:20:04 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-29 17:20:04 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-29 17:20:04 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-29 17:20:04 --> Final output sent to browser
DEBUG - 2016-06-29 17:20:04 --> Total execution time: 0.0799
INFO - 2016-06-29 14:20:07 --> Config Class Initialized
INFO - 2016-06-29 14:20:07 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:20:07 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:20:07 --> Utf8 Class Initialized
INFO - 2016-06-29 14:20:07 --> URI Class Initialized
INFO - 2016-06-29 14:20:07 --> Router Class Initialized
INFO - 2016-06-29 14:20:07 --> Output Class Initialized
INFO - 2016-06-29 14:20:07 --> Security Class Initialized
DEBUG - 2016-06-29 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:20:07 --> Input Class Initialized
INFO - 2016-06-29 14:20:07 --> Language Class Initialized
INFO - 2016-06-29 14:20:07 --> Loader Class Initialized
INFO - 2016-06-29 14:20:07 --> Helper loaded: form_helper
INFO - 2016-06-29 14:20:07 --> Database Driver Class Initialized
INFO - 2016-06-29 14:20:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:20:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:20:07 --> Email Class Initialized
INFO - 2016-06-29 14:20:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:20:07 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:20:07 --> Helper loaded: language_helper
INFO - 2016-06-29 14:20:07 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:20:07 --> Model Class Initialized
INFO - 2016-06-29 14:20:07 --> Helper loaded: date_helper
INFO - 2016-06-29 14:20:07 --> Controller Class Initialized
INFO - 2016-06-29 14:20:07 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:20:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:20:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:20:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:20:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:20:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:20:07 --> Model Class Initialized
INFO - 2016-06-29 17:20:07 --> Final output sent to browser
DEBUG - 2016-06-29 17:20:07 --> Total execution time: 0.0843
INFO - 2016-06-29 14:20:07 --> Config Class Initialized
INFO - 2016-06-29 14:20:07 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:20:07 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:20:07 --> Utf8 Class Initialized
INFO - 2016-06-29 14:20:07 --> URI Class Initialized
INFO - 2016-06-29 14:20:07 --> Router Class Initialized
INFO - 2016-06-29 14:20:07 --> Output Class Initialized
INFO - 2016-06-29 14:20:07 --> Security Class Initialized
DEBUG - 2016-06-29 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:20:07 --> Input Class Initialized
INFO - 2016-06-29 14:20:07 --> Language Class Initialized
ERROR - 2016-06-29 14:20:07 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-29 14:23:39 --> Config Class Initialized
INFO - 2016-06-29 14:23:39 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:23:39 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:23:39 --> Utf8 Class Initialized
INFO - 2016-06-29 14:23:39 --> URI Class Initialized
INFO - 2016-06-29 14:23:39 --> Router Class Initialized
INFO - 2016-06-29 14:23:39 --> Output Class Initialized
INFO - 2016-06-29 14:23:39 --> Security Class Initialized
DEBUG - 2016-06-29 14:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:23:39 --> Input Class Initialized
INFO - 2016-06-29 14:23:39 --> Language Class Initialized
INFO - 2016-06-29 14:23:39 --> Loader Class Initialized
INFO - 2016-06-29 14:23:39 --> Helper loaded: form_helper
INFO - 2016-06-29 14:23:39 --> Database Driver Class Initialized
INFO - 2016-06-29 14:23:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:23:39 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:23:39 --> Email Class Initialized
INFO - 2016-06-29 14:23:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:23:39 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:23:39 --> Helper loaded: language_helper
INFO - 2016-06-29 14:23:39 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:23:39 --> Model Class Initialized
INFO - 2016-06-29 14:23:39 --> Helper loaded: date_helper
INFO - 2016-06-29 14:23:39 --> Controller Class Initialized
INFO - 2016-06-29 14:23:39 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:23:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:23:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:23:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:23:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:23:39 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-29 17:23:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-29 17:23:39 --> Form Validation Class Initialized
DEBUG - 2016-06-29 17:23:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:23:39 --> Config Class Initialized
INFO - 2016-06-29 14:23:39 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:23:39 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:23:39 --> Utf8 Class Initialized
INFO - 2016-06-29 14:23:39 --> URI Class Initialized
DEBUG - 2016-06-29 14:23:39 --> No URI present. Default controller set.
INFO - 2016-06-29 14:23:39 --> Router Class Initialized
INFO - 2016-06-29 14:23:39 --> Output Class Initialized
INFO - 2016-06-29 14:23:39 --> Security Class Initialized
DEBUG - 2016-06-29 14:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:23:39 --> Input Class Initialized
INFO - 2016-06-29 14:23:39 --> Language Class Initialized
INFO - 2016-06-29 14:23:39 --> Loader Class Initialized
INFO - 2016-06-29 14:23:39 --> Helper loaded: form_helper
INFO - 2016-06-29 14:23:39 --> Database Driver Class Initialized
INFO - 2016-06-29 14:23:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:23:39 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:23:39 --> Email Class Initialized
INFO - 2016-06-29 14:23:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:23:39 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:23:39 --> Helper loaded: language_helper
INFO - 2016-06-29 14:23:39 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:23:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:23:40 --> Model Class Initialized
INFO - 2016-06-29 14:23:40 --> Helper loaded: date_helper
INFO - 2016-06-29 14:23:40 --> Controller Class Initialized
INFO - 2016-06-29 14:23:40 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 14:23:40 --> Config Class Initialized
INFO - 2016-06-29 14:23:40 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:23:40 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:23:40 --> Utf8 Class Initialized
INFO - 2016-06-29 14:23:40 --> URI Class Initialized
INFO - 2016-06-29 14:23:40 --> Router Class Initialized
INFO - 2016-06-29 14:23:40 --> Output Class Initialized
INFO - 2016-06-29 14:23:40 --> Security Class Initialized
DEBUG - 2016-06-29 14:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:23:40 --> Input Class Initialized
INFO - 2016-06-29 14:23:40 --> Language Class Initialized
INFO - 2016-06-29 14:23:40 --> Loader Class Initialized
INFO - 2016-06-29 14:23:40 --> Helper loaded: form_helper
INFO - 2016-06-29 14:23:40 --> Database Driver Class Initialized
INFO - 2016-06-29 14:23:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:23:40 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:23:40 --> Email Class Initialized
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:23:40 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:23:40 --> Helper loaded: language_helper
INFO - 2016-06-29 14:23:40 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:23:40 --> Model Class Initialized
INFO - 2016-06-29 14:23:40 --> Helper loaded: date_helper
INFO - 2016-06-29 14:23:40 --> Controller Class Initialized
INFO - 2016-06-29 14:23:40 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:23:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:23:40 --> Model Class Initialized
INFO - 2016-06-29 17:23:40 --> Form Validation Class Initialized
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-29 17:23:40 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-29 17:23:40 --> Final output sent to browser
DEBUG - 2016-06-29 17:23:40 --> Total execution time: 0.3192
INFO - 2016-06-29 14:23:42 --> Config Class Initialized
INFO - 2016-06-29 14:23:42 --> Hooks Class Initialized
DEBUG - 2016-06-29 14:23:42 --> UTF-8 Support Enabled
INFO - 2016-06-29 14:23:42 --> Utf8 Class Initialized
INFO - 2016-06-29 14:23:42 --> URI Class Initialized
INFO - 2016-06-29 14:23:42 --> Router Class Initialized
INFO - 2016-06-29 14:23:42 --> Output Class Initialized
INFO - 2016-06-29 14:23:42 --> Security Class Initialized
DEBUG - 2016-06-29 14:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 14:23:42 --> Input Class Initialized
INFO - 2016-06-29 14:23:42 --> Language Class Initialized
INFO - 2016-06-29 14:23:42 --> Loader Class Initialized
INFO - 2016-06-29 14:23:42 --> Helper loaded: form_helper
INFO - 2016-06-29 14:23:42 --> Database Driver Class Initialized
INFO - 2016-06-29 14:23:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-29 14:23:42 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-29 14:23:42 --> Email Class Initialized
INFO - 2016-06-29 14:23:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-29 14:23:42 --> Helper loaded: cookie_helper
INFO - 2016-06-29 14:23:42 --> Helper loaded: language_helper
INFO - 2016-06-29 14:23:42 --> Helper loaded: url_helper
DEBUG - 2016-06-29 14:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-29 14:23:42 --> Model Class Initialized
INFO - 2016-06-29 14:23:42 --> Helper loaded: date_helper
INFO - 2016-06-29 14:23:42 --> Controller Class Initialized
INFO - 2016-06-29 14:23:42 --> Helper loaded: languages_helper
INFO - 2016-06-29 14:23:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-29 14:23:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-29 14:23:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-29 14:23:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-29 14:23:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-29 17:23:42 --> Model Class Initialized
INFO - 2016-06-29 17:23:42 --> Form Validation Class Initialized
INFO - 2016-06-29 17:23:42 --> Final output sent to browser
DEBUG - 2016-06-29 17:23:42 --> Total execution time: 0.0846
INFO - 2016-06-29 16:31:42 --> Config Class Initialized
INFO - 2016-06-29 16:31:42 --> Hooks Class Initialized
DEBUG - 2016-06-29 16:31:42 --> UTF-8 Support Enabled
INFO - 2016-06-29 16:31:42 --> Utf8 Class Initialized
INFO - 2016-06-29 16:31:42 --> URI Class Initialized
INFO - 2016-06-29 16:31:42 --> Router Class Initialized
INFO - 2016-06-29 16:31:42 --> Output Class Initialized
INFO - 2016-06-29 16:31:42 --> Security Class Initialized
DEBUG - 2016-06-29 16:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-29 16:31:42 --> Input Class Initialized
INFO - 2016-06-29 16:31:42 --> Language Class Initialized
ERROR - 2016-06-29 16:31:42 --> 404 Page Not Found: Zcqqcom/cgi-bin
