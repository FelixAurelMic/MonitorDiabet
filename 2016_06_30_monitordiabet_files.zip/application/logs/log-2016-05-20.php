<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-05-20 09:59:49 --> Config Class Initialized
INFO - 2016-05-20 09:59:49 --> Hooks Class Initialized
DEBUG - 2016-05-20 09:59:50 --> UTF-8 Support Enabled
INFO - 2016-05-20 09:59:50 --> Utf8 Class Initialized
INFO - 2016-05-20 09:59:50 --> URI Class Initialized
INFO - 2016-05-20 09:59:50 --> Router Class Initialized
INFO - 2016-05-20 09:59:50 --> Output Class Initialized
INFO - 2016-05-20 09:59:50 --> Security Class Initialized
DEBUG - 2016-05-20 09:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 09:59:50 --> CSRF cookie sent
INFO - 2016-05-20 09:59:50 --> Input Class Initialized
INFO - 2016-05-20 09:59:51 --> Language Class Initialized
INFO - 2016-05-20 09:59:51 --> Loader Class Initialized
INFO - 2016-05-20 09:59:51 --> Helper loaded: form_helper
INFO - 2016-05-20 09:59:52 --> Database Driver Class Initialized
INFO - 2016-05-20 09:59:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 09:59:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 09:59:54 --> Email Class Initialized
INFO - 2016-05-20 09:59:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 09:59:54 --> Helper loaded: cookie_helper
INFO - 2016-05-20 09:59:54 --> Helper loaded: language_helper
INFO - 2016-05-20 09:59:54 --> Helper loaded: url_helper
DEBUG - 2016-05-20 09:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 09:59:54 --> Model Class Initialized
INFO - 2016-05-20 09:59:54 --> Helper loaded: date_helper
INFO - 2016-05-20 09:59:54 --> Controller Class Initialized
INFO - 2016-05-20 09:59:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 09:59:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 09:59:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 09:59:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 09:59:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 09:59:55 --> Model Class Initialized
INFO - 2016-05-20 09:59:55 --> Config Class Initialized
INFO - 2016-05-20 09:59:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 09:59:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 09:59:55 --> Utf8 Class Initialized
INFO - 2016-05-20 09:59:55 --> URI Class Initialized
INFO - 2016-05-20 09:59:55 --> Router Class Initialized
INFO - 2016-05-20 09:59:55 --> Output Class Initialized
INFO - 2016-05-20 09:59:55 --> Security Class Initialized
DEBUG - 2016-05-20 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 09:59:55 --> CSRF cookie sent
INFO - 2016-05-20 09:59:55 --> Input Class Initialized
INFO - 2016-05-20 09:59:55 --> Language Class Initialized
INFO - 2016-05-20 09:59:55 --> Loader Class Initialized
INFO - 2016-05-20 09:59:55 --> Helper loaded: form_helper
INFO - 2016-05-20 09:59:55 --> Database Driver Class Initialized
INFO - 2016-05-20 09:59:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 09:59:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 09:59:55 --> Email Class Initialized
INFO - 2016-05-20 09:59:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 09:59:55 --> Helper loaded: cookie_helper
INFO - 2016-05-20 09:59:55 --> Helper loaded: language_helper
INFO - 2016-05-20 09:59:55 --> Helper loaded: url_helper
DEBUG - 2016-05-20 09:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 09:59:55 --> Model Class Initialized
INFO - 2016-05-20 09:59:55 --> Helper loaded: date_helper
INFO - 2016-05-20 09:59:55 --> Controller Class Initialized
INFO - 2016-05-20 09:59:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 09:59:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 09:59:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 09:59:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 09:59:55 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 09:59:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 09:59:55 --> Form Validation Class Initialized
ERROR - 2016-05-20 09:59:55 --> Severity: Notice --> Undefined property: Auth::$callType /home/demis/www/platformadiabet/application/core/SVS_Controller.php 116
INFO - 2016-05-20 09:59:56 --> Helper loaded: languages_helper
INFO - 2016-05-20 09:59:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 09:59:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 09:59:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 09:59:56 --> Final output sent to browser
DEBUG - 2016-05-20 09:59:56 --> Total execution time: 0.7789
INFO - 2016-05-20 10:00:01 --> Config Class Initialized
INFO - 2016-05-20 10:00:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:00:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:00:01 --> Utf8 Class Initialized
INFO - 2016-05-20 10:00:01 --> URI Class Initialized
INFO - 2016-05-20 10:00:01 --> Router Class Initialized
INFO - 2016-05-20 10:00:01 --> Output Class Initialized
INFO - 2016-05-20 10:00:01 --> Security Class Initialized
DEBUG - 2016-05-20 10:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:00:01 --> CSRF cookie sent
INFO - 2016-05-20 10:00:01 --> Input Class Initialized
INFO - 2016-05-20 10:00:01 --> Language Class Initialized
ERROR - 2016-05-20 10:00:01 --> 404 Page Not Found: Faviconico/index
INFO - 2016-05-20 10:00:02 --> Config Class Initialized
INFO - 2016-05-20 10:00:02 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:00:02 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:00:02 --> Utf8 Class Initialized
INFO - 2016-05-20 10:00:02 --> URI Class Initialized
INFO - 2016-05-20 10:00:02 --> Router Class Initialized
INFO - 2016-05-20 10:00:02 --> Output Class Initialized
INFO - 2016-05-20 10:00:02 --> Security Class Initialized
DEBUG - 2016-05-20 10:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:00:02 --> CSRF cookie sent
INFO - 2016-05-20 10:00:02 --> Input Class Initialized
INFO - 2016-05-20 10:00:02 --> Language Class Initialized
ERROR - 2016-05-20 10:00:02 --> 404 Page Not Found: Faviconico/index
INFO - 2016-05-20 10:27:29 --> Config Class Initialized
INFO - 2016-05-20 10:27:29 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:27:29 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:27:29 --> Utf8 Class Initialized
INFO - 2016-05-20 10:27:29 --> URI Class Initialized
INFO - 2016-05-20 10:27:29 --> Router Class Initialized
INFO - 2016-05-20 10:27:29 --> Output Class Initialized
INFO - 2016-05-20 10:27:29 --> Security Class Initialized
DEBUG - 2016-05-20 10:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:27:29 --> CSRF cookie sent
INFO - 2016-05-20 10:27:29 --> Input Class Initialized
INFO - 2016-05-20 10:27:29 --> Language Class Initialized
INFO - 2016-05-20 10:27:29 --> Loader Class Initialized
INFO - 2016-05-20 10:27:29 --> Helper loaded: form_helper
INFO - 2016-05-20 10:27:30 --> Database Driver Class Initialized
INFO - 2016-05-20 10:27:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:27:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:27:34 --> Email Class Initialized
INFO - 2016-05-20 10:27:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:27:34 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:27:34 --> Helper loaded: language_helper
INFO - 2016-05-20 10:27:34 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:27:34 --> Model Class Initialized
INFO - 2016-05-20 10:27:34 --> Helper loaded: date_helper
INFO - 2016-05-20 10:27:35 --> Controller Class Initialized
INFO - 2016-05-20 10:27:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:27:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:27:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:27:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:27:35 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 10:27:35 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:27:35 --> Form Validation Class Initialized
INFO - 2016-05-20 10:27:35 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 10:27:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 10:27:35 --> Final output sent to browser
DEBUG - 2016-05-20 10:27:35 --> Total execution time: 6.7395
INFO - 2016-05-20 10:27:56 --> Config Class Initialized
INFO - 2016-05-20 10:27:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:27:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:27:56 --> Utf8 Class Initialized
INFO - 2016-05-20 10:27:56 --> URI Class Initialized
INFO - 2016-05-20 10:27:56 --> Router Class Initialized
INFO - 2016-05-20 10:27:56 --> Output Class Initialized
INFO - 2016-05-20 10:27:56 --> Security Class Initialized
DEBUG - 2016-05-20 10:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:27:56 --> CSRF cookie sent
INFO - 2016-05-20 10:27:56 --> CSRF token verified
INFO - 2016-05-20 10:27:56 --> Input Class Initialized
INFO - 2016-05-20 10:27:56 --> Language Class Initialized
INFO - 2016-05-20 10:27:56 --> Loader Class Initialized
INFO - 2016-05-20 10:27:56 --> Helper loaded: form_helper
INFO - 2016-05-20 10:27:56 --> Database Driver Class Initialized
INFO - 2016-05-20 10:27:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:27:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:27:56 --> Email Class Initialized
INFO - 2016-05-20 10:27:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:27:56 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:27:56 --> Helper loaded: language_helper
INFO - 2016-05-20 10:27:56 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:27:56 --> Model Class Initialized
INFO - 2016-05-20 10:27:56 --> Helper loaded: date_helper
INFO - 2016-05-20 10:27:56 --> Controller Class Initialized
INFO - 2016-05-20 10:27:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:27:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:27:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:27:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:27:56 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 10:27:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:27:56 --> Form Validation Class Initialized
INFO - 2016-05-20 10:27:58 --> Config Class Initialized
INFO - 2016-05-20 10:27:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:27:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:27:58 --> Utf8 Class Initialized
INFO - 2016-05-20 10:27:58 --> URI Class Initialized
DEBUG - 2016-05-20 10:27:58 --> No URI present. Default controller set.
INFO - 2016-05-20 10:27:58 --> Router Class Initialized
INFO - 2016-05-20 10:27:58 --> Output Class Initialized
INFO - 2016-05-20 10:27:58 --> Security Class Initialized
DEBUG - 2016-05-20 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:27:58 --> CSRF cookie sent
INFO - 2016-05-20 10:27:58 --> Input Class Initialized
INFO - 2016-05-20 10:27:58 --> Language Class Initialized
INFO - 2016-05-20 10:27:58 --> Loader Class Initialized
INFO - 2016-05-20 10:27:58 --> Helper loaded: form_helper
INFO - 2016-05-20 10:27:58 --> Database Driver Class Initialized
INFO - 2016-05-20 10:27:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:27:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:27:59 --> Email Class Initialized
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:27:59 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:27:59 --> Helper loaded: language_helper
INFO - 2016-05-20 10:27:59 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:27:59 --> Model Class Initialized
INFO - 2016-05-20 10:27:59 --> Helper loaded: date_helper
INFO - 2016-05-20 10:27:59 --> Controller Class Initialized
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:27:59 --> Config Class Initialized
INFO - 2016-05-20 10:27:59 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:27:59 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:27:59 --> Utf8 Class Initialized
INFO - 2016-05-20 10:27:59 --> URI Class Initialized
INFO - 2016-05-20 10:27:59 --> Router Class Initialized
INFO - 2016-05-20 10:27:59 --> Output Class Initialized
INFO - 2016-05-20 10:27:59 --> Security Class Initialized
DEBUG - 2016-05-20 10:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:27:59 --> CSRF cookie sent
INFO - 2016-05-20 10:27:59 --> Input Class Initialized
INFO - 2016-05-20 10:27:59 --> Language Class Initialized
INFO - 2016-05-20 10:27:59 --> Loader Class Initialized
INFO - 2016-05-20 10:27:59 --> Helper loaded: form_helper
INFO - 2016-05-20 10:27:59 --> Database Driver Class Initialized
INFO - 2016-05-20 10:27:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:27:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:27:59 --> Email Class Initialized
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:27:59 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:27:59 --> Helper loaded: language_helper
INFO - 2016-05-20 10:27:59 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:27:59 --> Model Class Initialized
INFO - 2016-05-20 10:27:59 --> Helper loaded: date_helper
INFO - 2016-05-20 10:27:59 --> Controller Class Initialized
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:27:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:27:59 --> Model Class Initialized
INFO - 2016-05-20 10:27:59 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:27:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:28:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:28:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 10:28:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:28:00 --> Final output sent to browser
DEBUG - 2016-05-20 10:28:00 --> Total execution time: 0.9846
INFO - 2016-05-20 10:28:24 --> Config Class Initialized
INFO - 2016-05-20 10:28:24 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:28:24 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:28:24 --> Utf8 Class Initialized
INFO - 2016-05-20 10:28:24 --> URI Class Initialized
INFO - 2016-05-20 10:28:24 --> Router Class Initialized
INFO - 2016-05-20 10:28:24 --> Output Class Initialized
INFO - 2016-05-20 10:28:24 --> Security Class Initialized
DEBUG - 2016-05-20 10:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:28:24 --> CSRF cookie sent
INFO - 2016-05-20 10:28:24 --> Input Class Initialized
INFO - 2016-05-20 10:28:24 --> Language Class Initialized
ERROR - 2016-05-20 10:28:25 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING), expecting function (T_FUNCTION) /home/demis/www/platformadiabet/application/controllers/Diabet.php 9
INFO - 2016-05-20 10:28:36 --> Config Class Initialized
INFO - 2016-05-20 10:28:36 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:28:36 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:28:36 --> Utf8 Class Initialized
INFO - 2016-05-20 10:28:36 --> URI Class Initialized
INFO - 2016-05-20 10:28:36 --> Router Class Initialized
INFO - 2016-05-20 10:28:36 --> Output Class Initialized
INFO - 2016-05-20 10:28:36 --> Security Class Initialized
DEBUG - 2016-05-20 10:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:28:36 --> CSRF cookie sent
INFO - 2016-05-20 10:28:36 --> Input Class Initialized
INFO - 2016-05-20 10:28:36 --> Language Class Initialized
INFO - 2016-05-20 10:28:36 --> Loader Class Initialized
INFO - 2016-05-20 10:28:36 --> Helper loaded: form_helper
INFO - 2016-05-20 10:28:36 --> Database Driver Class Initialized
INFO - 2016-05-20 10:28:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:28:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:28:36 --> Email Class Initialized
INFO - 2016-05-20 10:28:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:28:36 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:28:36 --> Helper loaded: language_helper
INFO - 2016-05-20 10:28:36 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:28:36 --> Model Class Initialized
INFO - 2016-05-20 10:28:36 --> Helper loaded: date_helper
INFO - 2016-05-20 10:28:36 --> Controller Class Initialized
INFO - 2016-05-20 10:28:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:28:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:28:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:28:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:28:36 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-20 10:28:36 --> Severity: Notice --> Undefined variable: outputFormat /home/demis/www/platformadiabet/application/controllers/Diabet.php 12
INFO - 2016-05-20 10:28:36 --> Model Class Initialized
INFO - 2016-05-20 10:28:36 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:28:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:28:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:28:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 10:28:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:28:36 --> Final output sent to browser
DEBUG - 2016-05-20 10:28:36 --> Total execution time: 0.0719
INFO - 2016-05-20 10:29:55 --> Config Class Initialized
INFO - 2016-05-20 10:29:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:29:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:29:55 --> Utf8 Class Initialized
INFO - 2016-05-20 10:29:55 --> URI Class Initialized
INFO - 2016-05-20 10:29:55 --> Router Class Initialized
INFO - 2016-05-20 10:29:55 --> Output Class Initialized
INFO - 2016-05-20 10:29:55 --> Security Class Initialized
DEBUG - 2016-05-20 10:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:29:55 --> CSRF cookie sent
INFO - 2016-05-20 10:29:55 --> Input Class Initialized
INFO - 2016-05-20 10:29:55 --> Language Class Initialized
INFO - 2016-05-20 10:29:55 --> Loader Class Initialized
INFO - 2016-05-20 10:29:55 --> Helper loaded: form_helper
INFO - 2016-05-20 10:29:55 --> Database Driver Class Initialized
INFO - 2016-05-20 10:29:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:29:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:29:55 --> Email Class Initialized
INFO - 2016-05-20 10:29:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:29:55 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:29:55 --> Helper loaded: language_helper
INFO - 2016-05-20 10:29:55 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:29:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:29:55 --> Model Class Initialized
INFO - 2016-05-20 10:29:55 --> Helper loaded: date_helper
INFO - 2016-05-20 10:29:55 --> Controller Class Initialized
INFO - 2016-05-20 10:29:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:29:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:29:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:29:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:29:55 --> Language file loaded: language/romanian/form_validation_lang.php
ERROR - 2016-05-20 10:29:55 --> Severity: Notice --> Undefined variable: outputFormat /home/demis/www/platformadiabet/application/controllers/Diabet.php 12
ERROR - 2016-05-20 10:29:55 --> Severity: Error --> Cannot access empty property /home/demis/www/platformadiabet/application/controllers/Diabet.php 12
INFO - 2016-05-20 10:30:04 --> Config Class Initialized
INFO - 2016-05-20 10:30:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:30:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:30:04 --> Utf8 Class Initialized
INFO - 2016-05-20 10:30:04 --> URI Class Initialized
INFO - 2016-05-20 10:30:04 --> Router Class Initialized
INFO - 2016-05-20 10:30:04 --> Output Class Initialized
INFO - 2016-05-20 10:30:04 --> Security Class Initialized
DEBUG - 2016-05-20 10:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:30:04 --> CSRF cookie sent
INFO - 2016-05-20 10:30:04 --> Input Class Initialized
INFO - 2016-05-20 10:30:04 --> Language Class Initialized
INFO - 2016-05-20 10:30:04 --> Loader Class Initialized
INFO - 2016-05-20 10:30:04 --> Helper loaded: form_helper
INFO - 2016-05-20 10:30:04 --> Database Driver Class Initialized
INFO - 2016-05-20 10:30:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:30:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:30:04 --> Email Class Initialized
INFO - 2016-05-20 10:30:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:30:04 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:30:04 --> Helper loaded: language_helper
INFO - 2016-05-20 10:30:04 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:30:04 --> Model Class Initialized
INFO - 2016-05-20 10:30:04 --> Helper loaded: date_helper
INFO - 2016-05-20 10:30:04 --> Controller Class Initialized
INFO - 2016-05-20 10:30:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:30:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:30:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:30:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:30:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:30:04 --> Model Class Initialized
INFO - 2016-05-20 10:30:04 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 10:30:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:30:04 --> Final output sent to browser
DEBUG - 2016-05-20 10:30:04 --> Total execution time: 0.0453
INFO - 2016-05-20 10:31:17 --> Config Class Initialized
INFO - 2016-05-20 10:31:17 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:31:17 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:31:17 --> Utf8 Class Initialized
INFO - 2016-05-20 10:31:31 --> Config Class Initialized
INFO - 2016-05-20 10:31:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:31:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:31:31 --> Utf8 Class Initialized
INFO - 2016-05-20 10:31:31 --> URI Class Initialized
INFO - 2016-05-20 10:31:31 --> Router Class Initialized
INFO - 2016-05-20 10:31:31 --> Output Class Initialized
INFO - 2016-05-20 10:31:31 --> Security Class Initialized
DEBUG - 2016-05-20 10:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:31:31 --> CSRF cookie sent
INFO - 2016-05-20 10:31:31 --> Input Class Initialized
INFO - 2016-05-20 10:31:31 --> Language Class Initialized
INFO - 2016-05-20 10:31:31 --> Loader Class Initialized
INFO - 2016-05-20 10:31:31 --> Helper loaded: form_helper
INFO - 2016-05-20 10:31:31 --> Database Driver Class Initialized
INFO - 2016-05-20 10:31:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:31:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:31:31 --> Email Class Initialized
INFO - 2016-05-20 10:31:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:31:31 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:31:31 --> Helper loaded: language_helper
INFO - 2016-05-20 10:31:31 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:31:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:31:31 --> Model Class Initialized
INFO - 2016-05-20 10:31:31 --> Helper loaded: date_helper
INFO - 2016-05-20 10:31:31 --> Controller Class Initialized
INFO - 2016-05-20 10:31:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:31:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:31:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:31:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:31:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:31:31 --> Model Class Initialized
INFO - 2016-05-20 10:31:31 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:31:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:31:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:31:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 10:31:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:31:31 --> Final output sent to browser
DEBUG - 2016-05-20 10:31:31 --> Total execution time: 0.0907
INFO - 2016-05-20 10:31:43 --> Config Class Initialized
INFO - 2016-05-20 10:31:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:31:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:31:43 --> Utf8 Class Initialized
INFO - 2016-05-20 10:31:43 --> URI Class Initialized
INFO - 2016-05-20 10:31:43 --> Router Class Initialized
INFO - 2016-05-20 10:31:43 --> Output Class Initialized
INFO - 2016-05-20 10:31:43 --> Security Class Initialized
DEBUG - 2016-05-20 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:31:43 --> CSRF cookie sent
INFO - 2016-05-20 10:31:43 --> Input Class Initialized
INFO - 2016-05-20 10:31:43 --> Language Class Initialized
INFO - 2016-05-20 10:31:43 --> Loader Class Initialized
INFO - 2016-05-20 10:31:43 --> Helper loaded: form_helper
INFO - 2016-05-20 10:31:43 --> Database Driver Class Initialized
INFO - 2016-05-20 10:31:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:31:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:31:43 --> Email Class Initialized
INFO - 2016-05-20 10:31:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:31:43 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:31:43 --> Helper loaded: language_helper
INFO - 2016-05-20 10:31:43 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:31:43 --> Model Class Initialized
INFO - 2016-05-20 10:31:43 --> Helper loaded: date_helper
INFO - 2016-05-20 10:31:43 --> Controller Class Initialized
INFO - 2016-05-20 10:31:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:31:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:31:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:31:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:31:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:31:43 --> Model Class Initialized
INFO - 2016-05-20 10:31:44 --> Helper loaded: languages_helper
ERROR - 2016-05-20 10:31:44 --> Mesaj nu are access
INFO - 2016-05-20 10:31:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:31:44 --> File loaded: /home/demis/www/platformadiabet/application/views/errors/error_general.php
INFO - 2016-05-20 10:31:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:31:54 --> Config Class Initialized
INFO - 2016-05-20 10:31:54 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:31:54 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:31:54 --> Utf8 Class Initialized
INFO - 2016-05-20 10:31:54 --> URI Class Initialized
INFO - 2016-05-20 10:31:54 --> Router Class Initialized
INFO - 2016-05-20 10:31:54 --> Output Class Initialized
INFO - 2016-05-20 10:31:54 --> Security Class Initialized
DEBUG - 2016-05-20 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:31:54 --> CSRF cookie sent
INFO - 2016-05-20 10:31:54 --> Input Class Initialized
INFO - 2016-05-20 10:31:54 --> Language Class Initialized
INFO - 2016-05-20 10:31:54 --> Loader Class Initialized
INFO - 2016-05-20 10:31:54 --> Helper loaded: form_helper
INFO - 2016-05-20 10:31:54 --> Database Driver Class Initialized
INFO - 2016-05-20 10:31:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:31:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:31:54 --> Email Class Initialized
INFO - 2016-05-20 10:31:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:31:54 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:31:54 --> Helper loaded: language_helper
INFO - 2016-05-20 10:31:54 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:31:54 --> Model Class Initialized
INFO - 2016-05-20 10:31:54 --> Helper loaded: date_helper
INFO - 2016-05-20 10:31:54 --> Controller Class Initialized
INFO - 2016-05-20 10:31:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:31:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:31:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:31:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:31:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:31:54 --> Model Class Initialized
INFO - 2016-05-20 10:31:54 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:31:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:31:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:31:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 10:31:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:31:54 --> Final output sent to browser
DEBUG - 2016-05-20 10:31:54 --> Total execution time: 0.0953
INFO - 2016-05-20 10:32:08 --> Config Class Initialized
INFO - 2016-05-20 10:32:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:32:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:32:08 --> Utf8 Class Initialized
INFO - 2016-05-20 10:32:08 --> URI Class Initialized
INFO - 2016-05-20 10:32:08 --> Router Class Initialized
INFO - 2016-05-20 10:32:08 --> Output Class Initialized
INFO - 2016-05-20 10:32:08 --> Security Class Initialized
DEBUG - 2016-05-20 10:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:32:08 --> CSRF cookie sent
INFO - 2016-05-20 10:32:08 --> Input Class Initialized
INFO - 2016-05-20 10:32:08 --> Language Class Initialized
INFO - 2016-05-20 10:32:08 --> Loader Class Initialized
INFO - 2016-05-20 10:32:08 --> Helper loaded: form_helper
INFO - 2016-05-20 10:32:08 --> Database Driver Class Initialized
INFO - 2016-05-20 10:32:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:32:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:32:08 --> Email Class Initialized
INFO - 2016-05-20 10:32:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:32:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:32:08 --> Helper loaded: language_helper
INFO - 2016-05-20 10:32:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:32:08 --> Model Class Initialized
INFO - 2016-05-20 10:32:08 --> Helper loaded: date_helper
INFO - 2016-05-20 10:32:08 --> Controller Class Initialized
INFO - 2016-05-20 10:32:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:32:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:32:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:32:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:32:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:32:08 --> Model Class Initialized
INFO - 2016-05-20 10:32:08 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:32:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:32:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:32:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 10:32:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:32:08 --> Final output sent to browser
DEBUG - 2016-05-20 10:32:08 --> Total execution time: 0.0920
INFO - 2016-05-20 10:33:44 --> Config Class Initialized
INFO - 2016-05-20 10:33:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:33:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:33:44 --> Utf8 Class Initialized
INFO - 2016-05-20 10:33:44 --> URI Class Initialized
INFO - 2016-05-20 10:33:44 --> Router Class Initialized
INFO - 2016-05-20 10:33:44 --> Output Class Initialized
INFO - 2016-05-20 10:33:44 --> Security Class Initialized
DEBUG - 2016-05-20 10:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:33:44 --> CSRF cookie sent
INFO - 2016-05-20 10:33:44 --> Input Class Initialized
INFO - 2016-05-20 10:33:44 --> Language Class Initialized
INFO - 2016-05-20 10:33:44 --> Loader Class Initialized
INFO - 2016-05-20 10:33:44 --> Helper loaded: form_helper
INFO - 2016-05-20 10:33:44 --> Database Driver Class Initialized
INFO - 2016-05-20 10:33:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:33:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:33:44 --> Email Class Initialized
INFO - 2016-05-20 10:33:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:33:44 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:33:44 --> Helper loaded: language_helper
INFO - 2016-05-20 10:33:44 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:33:44 --> Model Class Initialized
INFO - 2016-05-20 10:33:44 --> Helper loaded: date_helper
INFO - 2016-05-20 10:33:44 --> Controller Class Initialized
INFO - 2016-05-20 10:33:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:33:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:33:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:33:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:33:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:33:44 --> Model Class Initialized
INFO - 2016-05-20 10:33:44 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:33:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:33:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:33:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 10:33:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:33:44 --> Final output sent to browser
DEBUG - 2016-05-20 10:33:44 --> Total execution time: 0.0733
INFO - 2016-05-20 10:33:48 --> Config Class Initialized
INFO - 2016-05-20 10:33:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:33:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:33:48 --> Utf8 Class Initialized
INFO - 2016-05-20 10:33:48 --> URI Class Initialized
INFO - 2016-05-20 10:33:48 --> Router Class Initialized
INFO - 2016-05-20 10:33:48 --> Output Class Initialized
INFO - 2016-05-20 10:33:48 --> Security Class Initialized
DEBUG - 2016-05-20 10:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:33:48 --> CSRF cookie sent
INFO - 2016-05-20 10:33:48 --> Input Class Initialized
INFO - 2016-05-20 10:33:48 --> Language Class Initialized
INFO - 2016-05-20 10:33:48 --> Loader Class Initialized
INFO - 2016-05-20 10:33:48 --> Helper loaded: form_helper
INFO - 2016-05-20 10:33:48 --> Database Driver Class Initialized
INFO - 2016-05-20 10:33:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:33:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:33:48 --> Email Class Initialized
INFO - 2016-05-20 10:33:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:33:48 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:33:48 --> Helper loaded: language_helper
INFO - 2016-05-20 10:33:48 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:33:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:33:48 --> Model Class Initialized
INFO - 2016-05-20 10:33:48 --> Helper loaded: date_helper
INFO - 2016-05-20 10:33:48 --> Controller Class Initialized
INFO - 2016-05-20 10:33:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:33:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:33:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:33:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:33:48 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 10:33:48 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:33:48 --> Form Validation Class Initialized
INFO - 2016-05-20 10:33:48 --> Helper loaded: string_helper
INFO - 2016-05-20 10:33:48 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:33:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:33:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:33:48 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 10:33:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:33:48 --> Final output sent to browser
DEBUG - 2016-05-20 10:33:48 --> Total execution time: 0.1373
INFO - 2016-05-20 10:34:00 --> Config Class Initialized
INFO - 2016-05-20 10:34:00 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:34:00 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:34:00 --> Utf8 Class Initialized
INFO - 2016-05-20 10:34:00 --> URI Class Initialized
INFO - 2016-05-20 10:34:00 --> Router Class Initialized
INFO - 2016-05-20 10:34:00 --> Output Class Initialized
INFO - 2016-05-20 10:34:00 --> Security Class Initialized
DEBUG - 2016-05-20 10:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:34:00 --> CSRF cookie sent
INFO - 2016-05-20 10:34:00 --> Input Class Initialized
INFO - 2016-05-20 10:34:00 --> Language Class Initialized
INFO - 2016-05-20 10:34:00 --> Loader Class Initialized
INFO - 2016-05-20 10:34:00 --> Helper loaded: form_helper
INFO - 2016-05-20 10:34:00 --> Database Driver Class Initialized
INFO - 2016-05-20 10:34:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:34:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:34:00 --> Email Class Initialized
INFO - 2016-05-20 10:34:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:34:00 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:34:00 --> Helper loaded: language_helper
INFO - 2016-05-20 10:34:00 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:34:00 --> Model Class Initialized
INFO - 2016-05-20 10:34:00 --> Helper loaded: date_helper
INFO - 2016-05-20 10:34:00 --> Controller Class Initialized
INFO - 2016-05-20 10:34:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:34:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:34:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:34:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:34:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:34:00 --> Model Class Initialized
INFO - 2016-05-20 10:34:00 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:34:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:34:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:34:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 10:34:00 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:34:00 --> Final output sent to browser
DEBUG - 2016-05-20 10:34:00 --> Total execution time: 0.0876
INFO - 2016-05-20 10:34:16 --> Config Class Initialized
INFO - 2016-05-20 10:34:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:34:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:34:16 --> Utf8 Class Initialized
INFO - 2016-05-20 10:34:16 --> URI Class Initialized
DEBUG - 2016-05-20 10:34:16 --> No URI present. Default controller set.
INFO - 2016-05-20 10:34:16 --> Router Class Initialized
INFO - 2016-05-20 10:34:16 --> Output Class Initialized
INFO - 2016-05-20 10:34:16 --> Security Class Initialized
DEBUG - 2016-05-20 10:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:34:16 --> CSRF cookie sent
INFO - 2016-05-20 10:34:16 --> Input Class Initialized
INFO - 2016-05-20 10:34:16 --> Language Class Initialized
INFO - 2016-05-20 10:34:16 --> Loader Class Initialized
INFO - 2016-05-20 10:34:16 --> Helper loaded: form_helper
INFO - 2016-05-20 10:34:16 --> Database Driver Class Initialized
INFO - 2016-05-20 10:34:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:34:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:34:16 --> Email Class Initialized
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:34:16 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:34:16 --> Helper loaded: language_helper
INFO - 2016-05-20 10:34:16 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:34:16 --> Model Class Initialized
INFO - 2016-05-20 10:34:16 --> Helper loaded: date_helper
INFO - 2016-05-20 10:34:16 --> Controller Class Initialized
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:34:16 --> Config Class Initialized
INFO - 2016-05-20 10:34:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 10:34:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 10:34:16 --> Utf8 Class Initialized
INFO - 2016-05-20 10:34:16 --> URI Class Initialized
INFO - 2016-05-20 10:34:16 --> Router Class Initialized
INFO - 2016-05-20 10:34:16 --> Output Class Initialized
INFO - 2016-05-20 10:34:16 --> Security Class Initialized
DEBUG - 2016-05-20 10:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 10:34:16 --> CSRF cookie sent
INFO - 2016-05-20 10:34:16 --> Input Class Initialized
INFO - 2016-05-20 10:34:16 --> Language Class Initialized
INFO - 2016-05-20 10:34:16 --> Loader Class Initialized
INFO - 2016-05-20 10:34:16 --> Helper loaded: form_helper
INFO - 2016-05-20 10:34:16 --> Database Driver Class Initialized
INFO - 2016-05-20 10:34:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 10:34:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 10:34:16 --> Email Class Initialized
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 10:34:16 --> Helper loaded: cookie_helper
INFO - 2016-05-20 10:34:16 --> Helper loaded: language_helper
INFO - 2016-05-20 10:34:16 --> Helper loaded: url_helper
DEBUG - 2016-05-20 10:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 10:34:16 --> Model Class Initialized
INFO - 2016-05-20 10:34:16 --> Helper loaded: date_helper
INFO - 2016-05-20 10:34:16 --> Controller Class Initialized
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 10:34:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 10:34:16 --> Model Class Initialized
INFO - 2016-05-20 10:34:16 --> Helper loaded: languages_helper
INFO - 2016-05-20 10:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 10:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 10:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 10:34:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 10:34:16 --> Final output sent to browser
DEBUG - 2016-05-20 10:34:16 --> Total execution time: 0.0716
INFO - 2016-05-20 11:09:41 --> Config Class Initialized
INFO - 2016-05-20 11:09:41 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:09:41 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:09:41 --> Utf8 Class Initialized
INFO - 2016-05-20 11:09:41 --> URI Class Initialized
INFO - 2016-05-20 11:09:41 --> Router Class Initialized
INFO - 2016-05-20 11:09:41 --> Output Class Initialized
INFO - 2016-05-20 11:09:41 --> Security Class Initialized
DEBUG - 2016-05-20 11:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:09:41 --> CSRF cookie sent
INFO - 2016-05-20 11:09:41 --> Input Class Initialized
INFO - 2016-05-20 11:09:41 --> Language Class Initialized
INFO - 2016-05-20 11:09:41 --> Loader Class Initialized
INFO - 2016-05-20 11:09:41 --> Helper loaded: form_helper
INFO - 2016-05-20 11:09:41 --> Database Driver Class Initialized
INFO - 2016-05-20 11:09:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:09:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:09:41 --> Email Class Initialized
INFO - 2016-05-20 11:09:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:09:41 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:09:41 --> Helper loaded: language_helper
INFO - 2016-05-20 11:09:41 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:09:41 --> Model Class Initialized
INFO - 2016-05-20 11:09:41 --> Helper loaded: date_helper
INFO - 2016-05-20 11:09:41 --> Controller Class Initialized
INFO - 2016-05-20 11:09:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:09:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:09:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:09:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:09:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:09:41 --> Model Class Initialized
INFO - 2016-05-20 11:09:41 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:09:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:09:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:09:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:09:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:09:41 --> Final output sent to browser
DEBUG - 2016-05-20 11:09:41 --> Total execution time: 0.0690
INFO - 2016-05-20 11:11:34 --> Config Class Initialized
INFO - 2016-05-20 11:11:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:11:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:11:34 --> Utf8 Class Initialized
INFO - 2016-05-20 11:11:34 --> URI Class Initialized
INFO - 2016-05-20 11:11:34 --> Router Class Initialized
INFO - 2016-05-20 11:11:34 --> Output Class Initialized
INFO - 2016-05-20 11:11:34 --> Security Class Initialized
DEBUG - 2016-05-20 11:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:11:34 --> CSRF cookie sent
INFO - 2016-05-20 11:11:34 --> CSRF token verified
INFO - 2016-05-20 11:11:34 --> Input Class Initialized
INFO - 2016-05-20 11:11:34 --> Language Class Initialized
INFO - 2016-05-20 11:11:34 --> Loader Class Initialized
INFO - 2016-05-20 11:11:34 --> Helper loaded: form_helper
INFO - 2016-05-20 11:11:34 --> Database Driver Class Initialized
INFO - 2016-05-20 11:11:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:11:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:11:34 --> Email Class Initialized
INFO - 2016-05-20 11:11:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:11:34 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:11:34 --> Helper loaded: language_helper
INFO - 2016-05-20 11:11:34 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:11:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:11:34 --> Model Class Initialized
INFO - 2016-05-20 11:11:34 --> Helper loaded: date_helper
INFO - 2016-05-20 11:11:34 --> Controller Class Initialized
INFO - 2016-05-20 11:11:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:11:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:11:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:11:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:11:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:11:34 --> Model Class Initialized
INFO - 2016-05-20 11:11:34 --> Form Validation Class Initialized
ERROR - 2016-05-20 11:11:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 18 - Invalid query: 
        INSERT INTO 
        	`tokens`
            (
            `token`,
            `fk_user`,
            `name`,
            `email`,
            `type`,
            `_is_active` 
            )
	    VALUES
            (
            'gMhoC0TUx57X4dmYKEsBqZt3DAF8IjeW',
            '2',
            'Eu',
            'dsadsa@yahoo.com',
            'family',
            '1'
            
INFO - 2016-05-20 11:12:08 --> Config Class Initialized
INFO - 2016-05-20 11:12:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:12:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:12:08 --> Utf8 Class Initialized
INFO - 2016-05-20 11:12:08 --> URI Class Initialized
INFO - 2016-05-20 11:12:08 --> Router Class Initialized
INFO - 2016-05-20 11:12:08 --> Output Class Initialized
INFO - 2016-05-20 11:12:08 --> Security Class Initialized
DEBUG - 2016-05-20 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:12:08 --> CSRF cookie sent
INFO - 2016-05-20 11:12:08 --> Input Class Initialized
INFO - 2016-05-20 11:12:08 --> Language Class Initialized
INFO - 2016-05-20 11:12:08 --> Loader Class Initialized
INFO - 2016-05-20 11:12:08 --> Helper loaded: form_helper
INFO - 2016-05-20 11:12:08 --> Database Driver Class Initialized
INFO - 2016-05-20 11:12:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:12:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:12:08 --> Email Class Initialized
INFO - 2016-05-20 11:12:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:12:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:12:08 --> Helper loaded: language_helper
INFO - 2016-05-20 11:12:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:12:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:12:08 --> Model Class Initialized
INFO - 2016-05-20 11:12:08 --> Helper loaded: date_helper
INFO - 2016-05-20 11:12:08 --> Controller Class Initialized
INFO - 2016-05-20 11:12:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:12:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:12:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:12:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:12:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:12:08 --> Model Class Initialized
INFO - 2016-05-20 11:12:08 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:12:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:12:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:12:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:12:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:12:08 --> Final output sent to browser
DEBUG - 2016-05-20 11:12:08 --> Total execution time: 0.0486
INFO - 2016-05-20 11:12:18 --> Config Class Initialized
INFO - 2016-05-20 11:12:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:12:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:12:18 --> Utf8 Class Initialized
INFO - 2016-05-20 11:12:18 --> URI Class Initialized
INFO - 2016-05-20 11:12:18 --> Router Class Initialized
INFO - 2016-05-20 11:12:18 --> Output Class Initialized
INFO - 2016-05-20 11:12:18 --> Security Class Initialized
DEBUG - 2016-05-20 11:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:12:18 --> CSRF cookie sent
INFO - 2016-05-20 11:12:18 --> CSRF token verified
INFO - 2016-05-20 11:12:18 --> Input Class Initialized
INFO - 2016-05-20 11:12:18 --> Language Class Initialized
INFO - 2016-05-20 11:12:18 --> Loader Class Initialized
INFO - 2016-05-20 11:12:18 --> Helper loaded: form_helper
INFO - 2016-05-20 11:12:18 --> Database Driver Class Initialized
INFO - 2016-05-20 11:12:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:12:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:12:18 --> Email Class Initialized
INFO - 2016-05-20 11:12:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:12:18 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:12:18 --> Helper loaded: language_helper
INFO - 2016-05-20 11:12:18 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:12:18 --> Model Class Initialized
INFO - 2016-05-20 11:12:18 --> Helper loaded: date_helper
INFO - 2016-05-20 11:12:18 --> Controller Class Initialized
INFO - 2016-05-20 11:12:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:12:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:12:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:12:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:12:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:12:18 --> Model Class Initialized
INFO - 2016-05-20 11:12:18 --> Form Validation Class Initialized
DEBUG - 2016-05-20 11:12:18 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:12:19 --> Config Class Initialized
INFO - 2016-05-20 11:12:19 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:12:19 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:12:19 --> Utf8 Class Initialized
INFO - 2016-05-20 11:12:19 --> URI Class Initialized
INFO - 2016-05-20 11:12:19 --> Router Class Initialized
INFO - 2016-05-20 11:12:19 --> Output Class Initialized
INFO - 2016-05-20 11:12:19 --> Security Class Initialized
DEBUG - 2016-05-20 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:12:19 --> CSRF cookie sent
INFO - 2016-05-20 11:12:19 --> Input Class Initialized
INFO - 2016-05-20 11:12:19 --> Language Class Initialized
INFO - 2016-05-20 11:12:19 --> Loader Class Initialized
INFO - 2016-05-20 11:12:19 --> Helper loaded: form_helper
INFO - 2016-05-20 11:12:19 --> Database Driver Class Initialized
INFO - 2016-05-20 11:12:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:12:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:12:19 --> Email Class Initialized
INFO - 2016-05-20 11:12:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:12:19 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:12:19 --> Helper loaded: language_helper
INFO - 2016-05-20 11:12:19 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:12:19 --> Model Class Initialized
INFO - 2016-05-20 11:12:19 --> Helper loaded: date_helper
INFO - 2016-05-20 11:12:19 --> Controller Class Initialized
INFO - 2016-05-20 11:12:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:12:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:12:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:12:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:12:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:12:19 --> Model Class Initialized
INFO - 2016-05-20 11:12:19 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:12:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:12:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:12:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:12:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:12:19 --> Final output sent to browser
DEBUG - 2016-05-20 11:12:19 --> Total execution time: 0.0464
INFO - 2016-05-20 11:18:57 --> Config Class Initialized
INFO - 2016-05-20 11:18:57 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:18:57 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:18:57 --> Utf8 Class Initialized
INFO - 2016-05-20 11:18:57 --> URI Class Initialized
DEBUG - 2016-05-20 11:18:57 --> No URI present. Default controller set.
INFO - 2016-05-20 11:18:57 --> Router Class Initialized
INFO - 2016-05-20 11:18:57 --> Output Class Initialized
INFO - 2016-05-20 11:18:57 --> Security Class Initialized
DEBUG - 2016-05-20 11:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:18:57 --> CSRF cookie sent
INFO - 2016-05-20 11:18:57 --> Input Class Initialized
INFO - 2016-05-20 11:18:57 --> Language Class Initialized
INFO - 2016-05-20 11:18:57 --> Loader Class Initialized
INFO - 2016-05-20 11:18:57 --> Helper loaded: form_helper
INFO - 2016-05-20 11:18:57 --> Database Driver Class Initialized
INFO - 2016-05-20 11:18:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:18:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:18:57 --> Email Class Initialized
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:18:57 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:18:57 --> Helper loaded: language_helper
INFO - 2016-05-20 11:18:57 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:18:57 --> Model Class Initialized
INFO - 2016-05-20 11:18:57 --> Helper loaded: date_helper
INFO - 2016-05-20 11:18:57 --> Controller Class Initialized
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:18:57 --> Config Class Initialized
INFO - 2016-05-20 11:18:57 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:18:57 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:18:57 --> Utf8 Class Initialized
INFO - 2016-05-20 11:18:57 --> URI Class Initialized
INFO - 2016-05-20 11:18:57 --> Router Class Initialized
INFO - 2016-05-20 11:18:57 --> Output Class Initialized
INFO - 2016-05-20 11:18:57 --> Security Class Initialized
DEBUG - 2016-05-20 11:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:18:57 --> CSRF cookie sent
INFO - 2016-05-20 11:18:57 --> Input Class Initialized
INFO - 2016-05-20 11:18:57 --> Language Class Initialized
INFO - 2016-05-20 11:18:57 --> Loader Class Initialized
INFO - 2016-05-20 11:18:57 --> Helper loaded: form_helper
INFO - 2016-05-20 11:18:57 --> Database Driver Class Initialized
INFO - 2016-05-20 11:18:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:18:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:18:57 --> Email Class Initialized
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:18:57 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:18:57 --> Helper loaded: language_helper
INFO - 2016-05-20 11:18:57 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:18:57 --> Model Class Initialized
INFO - 2016-05-20 11:18:57 --> Helper loaded: date_helper
INFO - 2016-05-20 11:18:57 --> Controller Class Initialized
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:18:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:18:57 --> Model Class Initialized
INFO - 2016-05-20 11:18:57 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 11:18:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:18:57 --> Final output sent to browser
DEBUG - 2016-05-20 11:18:57 --> Total execution time: 0.0360
INFO - 2016-05-20 11:50:34 --> Config Class Initialized
INFO - 2016-05-20 11:50:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:50:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:50:34 --> Utf8 Class Initialized
INFO - 2016-05-20 11:50:34 --> URI Class Initialized
INFO - 2016-05-20 11:50:34 --> Router Class Initialized
INFO - 2016-05-20 11:50:34 --> Output Class Initialized
INFO - 2016-05-20 11:50:34 --> Security Class Initialized
DEBUG - 2016-05-20 11:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:50:34 --> CSRF cookie sent
INFO - 2016-05-20 11:50:34 --> Input Class Initialized
INFO - 2016-05-20 11:50:34 --> Language Class Initialized
INFO - 2016-05-20 11:50:34 --> Loader Class Initialized
INFO - 2016-05-20 11:50:34 --> Helper loaded: form_helper
INFO - 2016-05-20 11:50:34 --> Database Driver Class Initialized
INFO - 2016-05-20 11:50:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:50:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:50:34 --> Email Class Initialized
INFO - 2016-05-20 11:50:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:50:34 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:50:34 --> Helper loaded: language_helper
INFO - 2016-05-20 11:50:34 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:50:34 --> Model Class Initialized
INFO - 2016-05-20 11:50:34 --> Helper loaded: date_helper
INFO - 2016-05-20 11:50:34 --> Controller Class Initialized
INFO - 2016-05-20 11:50:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:50:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:50:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:50:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:50:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:50:34 --> Model Class Initialized
INFO - 2016-05-20 11:50:34 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:50:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:50:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:50:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 11:50:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:50:34 --> Final output sent to browser
DEBUG - 2016-05-20 11:50:34 --> Total execution time: 0.0670
INFO - 2016-05-20 11:50:38 --> Config Class Initialized
INFO - 2016-05-20 11:50:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:50:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:50:38 --> Utf8 Class Initialized
INFO - 2016-05-20 11:50:38 --> URI Class Initialized
INFO - 2016-05-20 11:50:38 --> Router Class Initialized
INFO - 2016-05-20 11:50:38 --> Output Class Initialized
INFO - 2016-05-20 11:50:38 --> Security Class Initialized
DEBUG - 2016-05-20 11:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:50:38 --> CSRF cookie sent
INFO - 2016-05-20 11:50:38 --> Input Class Initialized
INFO - 2016-05-20 11:50:38 --> Language Class Initialized
INFO - 2016-05-20 11:50:38 --> Loader Class Initialized
INFO - 2016-05-20 11:50:38 --> Helper loaded: form_helper
INFO - 2016-05-20 11:50:38 --> Database Driver Class Initialized
INFO - 2016-05-20 11:50:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:50:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:50:38 --> Email Class Initialized
INFO - 2016-05-20 11:50:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:50:38 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:50:38 --> Helper loaded: language_helper
INFO - 2016-05-20 11:50:38 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:50:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:50:38 --> Model Class Initialized
INFO - 2016-05-20 11:50:38 --> Helper loaded: date_helper
INFO - 2016-05-20 11:50:38 --> Controller Class Initialized
INFO - 2016-05-20 11:50:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:50:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:50:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:50:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:50:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:50:38 --> Model Class Initialized
INFO - 2016-05-20 11:50:38 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:50:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:50:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:50:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:50:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:50:38 --> Final output sent to browser
DEBUG - 2016-05-20 11:50:38 --> Total execution time: 0.0580
INFO - 2016-05-20 11:50:56 --> Config Class Initialized
INFO - 2016-05-20 11:50:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:50:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:50:56 --> Utf8 Class Initialized
INFO - 2016-05-20 11:50:56 --> URI Class Initialized
INFO - 2016-05-20 11:50:56 --> Router Class Initialized
INFO - 2016-05-20 11:50:56 --> Output Class Initialized
INFO - 2016-05-20 11:50:56 --> Security Class Initialized
DEBUG - 2016-05-20 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:50:56 --> CSRF cookie sent
INFO - 2016-05-20 11:50:56 --> CSRF token verified
INFO - 2016-05-20 11:50:56 --> Input Class Initialized
INFO - 2016-05-20 11:50:56 --> Language Class Initialized
INFO - 2016-05-20 11:50:56 --> Loader Class Initialized
INFO - 2016-05-20 11:50:56 --> Helper loaded: form_helper
INFO - 2016-05-20 11:50:56 --> Database Driver Class Initialized
INFO - 2016-05-20 11:50:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:50:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:50:56 --> Email Class Initialized
INFO - 2016-05-20 11:50:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:50:56 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:50:56 --> Helper loaded: language_helper
INFO - 2016-05-20 11:50:56 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:50:56 --> Model Class Initialized
INFO - 2016-05-20 11:50:56 --> Helper loaded: date_helper
INFO - 2016-05-20 11:50:56 --> Controller Class Initialized
INFO - 2016-05-20 11:50:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:50:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:50:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:50:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:50:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:50:56 --> Model Class Initialized
INFO - 2016-05-20 11:50:56 --> Form Validation Class Initialized
ERROR - 2016-05-20 11:50:56 --> Severity: Notice --> Undefined property: Diabet::$settings_model /home/demis/www/platformadiabet/application/libraries/SVS_Form_validation.php 32
ERROR - 2016-05-20 11:50:56 --> Severity: Error --> Call to a member function check_email() on null /home/demis/www/platformadiabet/application/libraries/SVS_Form_validation.php 32
INFO - 2016-05-20 11:51:18 --> Config Class Initialized
INFO - 2016-05-20 11:51:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:51:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:51:18 --> Utf8 Class Initialized
INFO - 2016-05-20 11:51:18 --> URI Class Initialized
INFO - 2016-05-20 11:51:18 --> Router Class Initialized
INFO - 2016-05-20 11:51:18 --> Output Class Initialized
INFO - 2016-05-20 11:51:18 --> Security Class Initialized
DEBUG - 2016-05-20 11:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:51:18 --> CSRF cookie sent
INFO - 2016-05-20 11:51:18 --> Input Class Initialized
INFO - 2016-05-20 11:51:18 --> Language Class Initialized
INFO - 2016-05-20 11:51:18 --> Loader Class Initialized
INFO - 2016-05-20 11:51:18 --> Helper loaded: form_helper
INFO - 2016-05-20 11:51:18 --> Database Driver Class Initialized
INFO - 2016-05-20 11:51:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:51:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:51:18 --> Email Class Initialized
INFO - 2016-05-20 11:51:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:51:18 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:51:18 --> Helper loaded: language_helper
INFO - 2016-05-20 11:51:18 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:51:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:51:18 --> Model Class Initialized
INFO - 2016-05-20 11:51:18 --> Helper loaded: date_helper
INFO - 2016-05-20 11:51:18 --> Controller Class Initialized
INFO - 2016-05-20 11:51:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:51:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:51:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:51:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:51:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:51:18 --> Model Class Initialized
INFO - 2016-05-20 11:51:18 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:51:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:51:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:51:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:51:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:51:18 --> Final output sent to browser
DEBUG - 2016-05-20 11:51:18 --> Total execution time: 0.0308
INFO - 2016-05-20 11:51:28 --> Config Class Initialized
INFO - 2016-05-20 11:51:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:51:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:51:28 --> Utf8 Class Initialized
INFO - 2016-05-20 11:51:28 --> URI Class Initialized
INFO - 2016-05-20 11:51:28 --> Router Class Initialized
INFO - 2016-05-20 11:51:28 --> Output Class Initialized
INFO - 2016-05-20 11:51:28 --> Security Class Initialized
DEBUG - 2016-05-20 11:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:51:28 --> CSRF cookie sent
INFO - 2016-05-20 11:51:28 --> CSRF token verified
INFO - 2016-05-20 11:51:28 --> Input Class Initialized
INFO - 2016-05-20 11:51:28 --> Language Class Initialized
INFO - 2016-05-20 11:51:28 --> Loader Class Initialized
INFO - 2016-05-20 11:51:28 --> Helper loaded: form_helper
INFO - 2016-05-20 11:51:28 --> Database Driver Class Initialized
INFO - 2016-05-20 11:51:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:51:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:51:28 --> Email Class Initialized
INFO - 2016-05-20 11:51:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:51:28 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:51:28 --> Helper loaded: language_helper
INFO - 2016-05-20 11:51:28 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:51:28 --> Model Class Initialized
INFO - 2016-05-20 11:51:28 --> Helper loaded: date_helper
INFO - 2016-05-20 11:51:28 --> Controller Class Initialized
INFO - 2016-05-20 11:51:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:51:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:51:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:51:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:51:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:51:28 --> Model Class Initialized
INFO - 2016-05-20 11:51:28 --> Form Validation Class Initialized
ERROR - 2016-05-20 11:51:28 --> Severity: Error --> Call to undefined method Diabet_model::check_email() /home/demis/www/platformadiabet/application/libraries/SVS_Form_validation.php 32
INFO - 2016-05-20 11:51:47 --> Config Class Initialized
INFO - 2016-05-20 11:51:47 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:51:47 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:51:47 --> Utf8 Class Initialized
INFO - 2016-05-20 11:51:47 --> URI Class Initialized
INFO - 2016-05-20 11:51:47 --> Router Class Initialized
INFO - 2016-05-20 11:51:47 --> Output Class Initialized
INFO - 2016-05-20 11:51:47 --> Security Class Initialized
DEBUG - 2016-05-20 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:51:47 --> CSRF cookie sent
INFO - 2016-05-20 11:51:47 --> Input Class Initialized
INFO - 2016-05-20 11:51:47 --> Language Class Initialized
INFO - 2016-05-20 11:51:47 --> Loader Class Initialized
INFO - 2016-05-20 11:51:47 --> Helper loaded: form_helper
INFO - 2016-05-20 11:51:47 --> Database Driver Class Initialized
INFO - 2016-05-20 11:51:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:51:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:51:47 --> Email Class Initialized
INFO - 2016-05-20 11:51:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:51:47 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:51:47 --> Helper loaded: language_helper
INFO - 2016-05-20 11:51:47 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:51:47 --> Model Class Initialized
INFO - 2016-05-20 11:51:47 --> Helper loaded: date_helper
INFO - 2016-05-20 11:51:47 --> Controller Class Initialized
INFO - 2016-05-20 11:51:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:51:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:51:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:51:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:51:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:51:47 --> Model Class Initialized
INFO - 2016-05-20 11:51:47 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:51:47 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:51:47 --> Final output sent to browser
DEBUG - 2016-05-20 11:51:47 --> Total execution time: 0.0782
INFO - 2016-05-20 11:51:54 --> Config Class Initialized
INFO - 2016-05-20 11:51:54 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:51:54 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:51:54 --> Utf8 Class Initialized
INFO - 2016-05-20 11:51:54 --> URI Class Initialized
INFO - 2016-05-20 11:51:54 --> Router Class Initialized
INFO - 2016-05-20 11:51:54 --> Output Class Initialized
INFO - 2016-05-20 11:51:54 --> Security Class Initialized
DEBUG - 2016-05-20 11:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:51:54 --> CSRF cookie sent
INFO - 2016-05-20 11:51:54 --> CSRF token verified
INFO - 2016-05-20 11:51:54 --> Input Class Initialized
INFO - 2016-05-20 11:51:54 --> Language Class Initialized
INFO - 2016-05-20 11:51:54 --> Loader Class Initialized
INFO - 2016-05-20 11:51:54 --> Helper loaded: form_helper
INFO - 2016-05-20 11:51:54 --> Database Driver Class Initialized
INFO - 2016-05-20 11:51:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:51:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:51:54 --> Email Class Initialized
INFO - 2016-05-20 11:51:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:51:54 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:51:54 --> Helper loaded: language_helper
INFO - 2016-05-20 11:51:54 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:51:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:51:54 --> Model Class Initialized
INFO - 2016-05-20 11:51:54 --> Helper loaded: date_helper
INFO - 2016-05-20 11:51:54 --> Controller Class Initialized
INFO - 2016-05-20 11:51:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:51:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:51:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:51:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:51:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:51:54 --> Model Class Initialized
INFO - 2016-05-20 11:51:54 --> Form Validation Class Initialized
DEBUG - 2016-05-20 11:51:54 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:51:55 --> Config Class Initialized
INFO - 2016-05-20 11:51:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:51:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:51:55 --> Utf8 Class Initialized
INFO - 2016-05-20 11:51:55 --> URI Class Initialized
INFO - 2016-05-20 11:51:55 --> Router Class Initialized
INFO - 2016-05-20 11:51:55 --> Output Class Initialized
INFO - 2016-05-20 11:51:55 --> Security Class Initialized
DEBUG - 2016-05-20 11:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:51:55 --> CSRF cookie sent
INFO - 2016-05-20 11:51:55 --> Input Class Initialized
INFO - 2016-05-20 11:51:55 --> Language Class Initialized
INFO - 2016-05-20 11:51:55 --> Loader Class Initialized
INFO - 2016-05-20 11:51:55 --> Helper loaded: form_helper
INFO - 2016-05-20 11:51:55 --> Database Driver Class Initialized
INFO - 2016-05-20 11:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:51:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:51:55 --> Email Class Initialized
INFO - 2016-05-20 11:51:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:51:55 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:51:55 --> Helper loaded: language_helper
INFO - 2016-05-20 11:51:55 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:51:55 --> Model Class Initialized
INFO - 2016-05-20 11:51:55 --> Helper loaded: date_helper
INFO - 2016-05-20 11:51:55 --> Controller Class Initialized
INFO - 2016-05-20 11:51:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:51:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:51:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:51:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:51:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:51:55 --> Model Class Initialized
INFO - 2016-05-20 11:51:55 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:51:55 --> Final output sent to browser
DEBUG - 2016-05-20 11:51:55 --> Total execution time: 0.0473
INFO - 2016-05-20 11:53:08 --> Config Class Initialized
INFO - 2016-05-20 11:53:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:53:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:53:08 --> Utf8 Class Initialized
INFO - 2016-05-20 11:53:08 --> URI Class Initialized
INFO - 2016-05-20 11:53:08 --> Router Class Initialized
INFO - 2016-05-20 11:53:08 --> Output Class Initialized
INFO - 2016-05-20 11:53:08 --> Security Class Initialized
DEBUG - 2016-05-20 11:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:53:08 --> CSRF cookie sent
INFO - 2016-05-20 11:53:08 --> Input Class Initialized
INFO - 2016-05-20 11:53:08 --> Language Class Initialized
INFO - 2016-05-20 11:53:08 --> Loader Class Initialized
INFO - 2016-05-20 11:53:08 --> Helper loaded: form_helper
INFO - 2016-05-20 11:53:08 --> Database Driver Class Initialized
INFO - 2016-05-20 11:53:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:53:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:53:08 --> Email Class Initialized
INFO - 2016-05-20 11:53:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:53:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:53:08 --> Helper loaded: language_helper
INFO - 2016-05-20 11:53:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:53:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:53:08 --> Model Class Initialized
INFO - 2016-05-20 11:53:08 --> Helper loaded: date_helper
INFO - 2016-05-20 11:53:08 --> Controller Class Initialized
INFO - 2016-05-20 11:53:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:53:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:53:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:53:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:53:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:53:08 --> Model Class Initialized
INFO - 2016-05-20 11:53:08 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:53:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:53:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:53:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:53:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:53:08 --> Final output sent to browser
DEBUG - 2016-05-20 11:53:08 --> Total execution time: 0.0532
INFO - 2016-05-20 11:53:16 --> Config Class Initialized
INFO - 2016-05-20 11:53:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:53:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:53:16 --> Utf8 Class Initialized
INFO - 2016-05-20 11:53:16 --> URI Class Initialized
INFO - 2016-05-20 11:53:16 --> Router Class Initialized
INFO - 2016-05-20 11:53:16 --> Output Class Initialized
INFO - 2016-05-20 11:53:16 --> Security Class Initialized
DEBUG - 2016-05-20 11:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:53:16 --> CSRF cookie sent
INFO - 2016-05-20 11:53:16 --> CSRF token verified
INFO - 2016-05-20 11:53:16 --> Input Class Initialized
INFO - 2016-05-20 11:53:16 --> Language Class Initialized
INFO - 2016-05-20 11:53:16 --> Loader Class Initialized
INFO - 2016-05-20 11:53:16 --> Helper loaded: form_helper
INFO - 2016-05-20 11:53:16 --> Database Driver Class Initialized
INFO - 2016-05-20 11:53:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:53:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:53:16 --> Email Class Initialized
INFO - 2016-05-20 11:53:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:53:16 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:53:16 --> Helper loaded: language_helper
INFO - 2016-05-20 11:53:16 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:53:16 --> Model Class Initialized
INFO - 2016-05-20 11:53:16 --> Helper loaded: date_helper
INFO - 2016-05-20 11:53:16 --> Controller Class Initialized
INFO - 2016-05-20 11:53:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:53:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:53:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:53:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:53:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:53:16 --> Model Class Initialized
INFO - 2016-05-20 11:53:16 --> Form Validation Class Initialized
INFO - 2016-05-20 11:53:53 --> Config Class Initialized
INFO - 2016-05-20 11:53:53 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:53:53 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:53:53 --> Utf8 Class Initialized
INFO - 2016-05-20 11:53:53 --> URI Class Initialized
INFO - 2016-05-20 11:53:53 --> Router Class Initialized
INFO - 2016-05-20 11:53:53 --> Output Class Initialized
INFO - 2016-05-20 11:53:53 --> Security Class Initialized
DEBUG - 2016-05-20 11:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:53:53 --> CSRF cookie sent
INFO - 2016-05-20 11:53:53 --> Input Class Initialized
INFO - 2016-05-20 11:53:53 --> Language Class Initialized
INFO - 2016-05-20 11:53:53 --> Loader Class Initialized
INFO - 2016-05-20 11:53:53 --> Helper loaded: form_helper
INFO - 2016-05-20 11:53:53 --> Database Driver Class Initialized
INFO - 2016-05-20 11:53:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:53:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:53:53 --> Email Class Initialized
INFO - 2016-05-20 11:53:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:53:53 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:53:53 --> Helper loaded: language_helper
INFO - 2016-05-20 11:53:53 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:53:53 --> Model Class Initialized
INFO - 2016-05-20 11:53:53 --> Helper loaded: date_helper
INFO - 2016-05-20 11:53:53 --> Controller Class Initialized
INFO - 2016-05-20 11:53:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:53:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:53:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:53:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:53:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:53:53 --> Model Class Initialized
INFO - 2016-05-20 11:53:53 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:53:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:53:53 --> Final output sent to browser
DEBUG - 2016-05-20 11:53:53 --> Total execution time: 0.0726
INFO - 2016-05-20 11:54:00 --> Config Class Initialized
INFO - 2016-05-20 11:54:00 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:00 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:00 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:00 --> URI Class Initialized
INFO - 2016-05-20 11:54:00 --> Router Class Initialized
INFO - 2016-05-20 11:54:00 --> Output Class Initialized
INFO - 2016-05-20 11:54:00 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:00 --> CSRF cookie sent
INFO - 2016-05-20 11:54:00 --> CSRF token verified
INFO - 2016-05-20 11:54:00 --> Input Class Initialized
INFO - 2016-05-20 11:54:00 --> Language Class Initialized
INFO - 2016-05-20 11:54:00 --> Loader Class Initialized
INFO - 2016-05-20 11:54:00 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:00 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:00 --> Email Class Initialized
INFO - 2016-05-20 11:54:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:00 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:00 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:00 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:00 --> Model Class Initialized
INFO - 2016-05-20 11:54:00 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:00 --> Controller Class Initialized
INFO - 2016-05-20 11:54:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:00 --> Model Class Initialized
INFO - 2016-05-20 11:54:00 --> Form Validation Class Initialized
INFO - 2016-05-20 11:54:10 --> Config Class Initialized
INFO - 2016-05-20 11:54:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:10 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:10 --> URI Class Initialized
INFO - 2016-05-20 11:54:10 --> Router Class Initialized
INFO - 2016-05-20 11:54:10 --> Output Class Initialized
INFO - 2016-05-20 11:54:10 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:10 --> CSRF cookie sent
INFO - 2016-05-20 11:54:10 --> Input Class Initialized
INFO - 2016-05-20 11:54:10 --> Language Class Initialized
INFO - 2016-05-20 11:54:10 --> Loader Class Initialized
INFO - 2016-05-20 11:54:10 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:10 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:10 --> Email Class Initialized
INFO - 2016-05-20 11:54:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:10 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:10 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:10 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:10 --> Model Class Initialized
INFO - 2016-05-20 11:54:10 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:10 --> Controller Class Initialized
INFO - 2016-05-20 11:54:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:10 --> Model Class Initialized
INFO - 2016-05-20 11:54:10 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:54:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:54:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:54:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:54:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:54:10 --> Final output sent to browser
DEBUG - 2016-05-20 11:54:10 --> Total execution time: 0.0775
INFO - 2016-05-20 11:54:13 --> Config Class Initialized
INFO - 2016-05-20 11:54:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:13 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:13 --> URI Class Initialized
INFO - 2016-05-20 11:54:13 --> Router Class Initialized
INFO - 2016-05-20 11:54:13 --> Output Class Initialized
INFO - 2016-05-20 11:54:13 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:13 --> CSRF cookie sent
INFO - 2016-05-20 11:54:13 --> Input Class Initialized
INFO - 2016-05-20 11:54:13 --> Language Class Initialized
INFO - 2016-05-20 11:54:13 --> Loader Class Initialized
INFO - 2016-05-20 11:54:13 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:13 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:13 --> Email Class Initialized
INFO - 2016-05-20 11:54:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:13 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:13 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:13 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:13 --> Model Class Initialized
INFO - 2016-05-20 11:54:13 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:13 --> Controller Class Initialized
INFO - 2016-05-20 11:54:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:13 --> Model Class Initialized
INFO - 2016-05-20 11:54:13 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:54:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:54:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:54:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:54:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:54:13 --> Final output sent to browser
DEBUG - 2016-05-20 11:54:13 --> Total execution time: 0.1016
INFO - 2016-05-20 11:54:21 --> Config Class Initialized
INFO - 2016-05-20 11:54:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:21 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:21 --> URI Class Initialized
INFO - 2016-05-20 11:54:21 --> Router Class Initialized
INFO - 2016-05-20 11:54:21 --> Output Class Initialized
INFO - 2016-05-20 11:54:21 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:21 --> CSRF cookie sent
INFO - 2016-05-20 11:54:21 --> CSRF token verified
INFO - 2016-05-20 11:54:21 --> Input Class Initialized
INFO - 2016-05-20 11:54:21 --> Language Class Initialized
INFO - 2016-05-20 11:54:21 --> Loader Class Initialized
INFO - 2016-05-20 11:54:21 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:21 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:21 --> Email Class Initialized
INFO - 2016-05-20 11:54:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:21 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:21 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:21 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:21 --> Model Class Initialized
INFO - 2016-05-20 11:54:21 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:21 --> Controller Class Initialized
INFO - 2016-05-20 11:54:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:21 --> Model Class Initialized
INFO - 2016-05-20 11:54:21 --> Form Validation Class Initialized
INFO - 2016-05-20 11:54:21 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:54:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:54:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:54:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:54:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:54:21 --> Final output sent to browser
DEBUG - 2016-05-20 11:54:21 --> Total execution time: 0.1282
INFO - 2016-05-20 11:54:52 --> Config Class Initialized
INFO - 2016-05-20 11:54:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:52 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:52 --> URI Class Initialized
INFO - 2016-05-20 11:54:52 --> Router Class Initialized
INFO - 2016-05-20 11:54:52 --> Output Class Initialized
INFO - 2016-05-20 11:54:52 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:52 --> CSRF cookie sent
INFO - 2016-05-20 11:54:52 --> Input Class Initialized
INFO - 2016-05-20 11:54:52 --> Language Class Initialized
INFO - 2016-05-20 11:54:52 --> Loader Class Initialized
INFO - 2016-05-20 11:54:52 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:52 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:52 --> Email Class Initialized
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:52 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:52 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:52 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:52 --> Model Class Initialized
INFO - 2016-05-20 11:54:52 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:52 --> Controller Class Initialized
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:52 --> Model Class Initialized
INFO - 2016-05-20 11:54:52 --> Config Class Initialized
INFO - 2016-05-20 11:54:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:52 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:52 --> URI Class Initialized
INFO - 2016-05-20 11:54:52 --> Router Class Initialized
INFO - 2016-05-20 11:54:52 --> Output Class Initialized
INFO - 2016-05-20 11:54:52 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:52 --> CSRF cookie sent
INFO - 2016-05-20 11:54:52 --> Input Class Initialized
INFO - 2016-05-20 11:54:52 --> Language Class Initialized
INFO - 2016-05-20 11:54:52 --> Loader Class Initialized
INFO - 2016-05-20 11:54:52 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:52 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:52 --> Email Class Initialized
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:52 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:52 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:52 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:52 --> Model Class Initialized
INFO - 2016-05-20 11:54:52 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:52 --> Controller Class Initialized
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:52 --> Model Class Initialized
INFO - 2016-05-20 11:54:52 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:54:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:54:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:54:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:54:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:54:52 --> Final output sent to browser
DEBUG - 2016-05-20 11:54:52 --> Total execution time: 0.0715
INFO - 2016-05-20 11:54:56 --> Config Class Initialized
INFO - 2016-05-20 11:54:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:56 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:56 --> URI Class Initialized
INFO - 2016-05-20 11:54:56 --> Router Class Initialized
INFO - 2016-05-20 11:54:56 --> Output Class Initialized
INFO - 2016-05-20 11:54:56 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:56 --> CSRF cookie sent
INFO - 2016-05-20 11:54:56 --> Input Class Initialized
INFO - 2016-05-20 11:54:56 --> Language Class Initialized
INFO - 2016-05-20 11:54:56 --> Loader Class Initialized
INFO - 2016-05-20 11:54:56 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:56 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:56 --> Email Class Initialized
INFO - 2016-05-20 11:54:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:56 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:56 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:56 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:56 --> Model Class Initialized
INFO - 2016-05-20 11:54:56 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:56 --> Controller Class Initialized
INFO - 2016-05-20 11:54:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:56 --> Model Class Initialized
INFO - 2016-05-20 11:54:56 --> Config Class Initialized
INFO - 2016-05-20 11:54:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:54:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:54:56 --> Utf8 Class Initialized
INFO - 2016-05-20 11:54:56 --> URI Class Initialized
INFO - 2016-05-20 11:54:56 --> Router Class Initialized
INFO - 2016-05-20 11:54:56 --> Output Class Initialized
INFO - 2016-05-20 11:54:56 --> Security Class Initialized
DEBUG - 2016-05-20 11:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:54:57 --> CSRF cookie sent
INFO - 2016-05-20 11:54:57 --> Input Class Initialized
INFO - 2016-05-20 11:54:57 --> Language Class Initialized
INFO - 2016-05-20 11:54:57 --> Loader Class Initialized
INFO - 2016-05-20 11:54:57 --> Helper loaded: form_helper
INFO - 2016-05-20 11:54:57 --> Database Driver Class Initialized
INFO - 2016-05-20 11:54:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:54:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:54:57 --> Email Class Initialized
INFO - 2016-05-20 11:54:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:54:57 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:54:57 --> Helper loaded: language_helper
INFO - 2016-05-20 11:54:57 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:54:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:54:57 --> Model Class Initialized
INFO - 2016-05-20 11:54:57 --> Helper loaded: date_helper
INFO - 2016-05-20 11:54:57 --> Controller Class Initialized
INFO - 2016-05-20 11:54:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:54:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:54:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:54:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:54:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:54:57 --> Model Class Initialized
INFO - 2016-05-20 11:54:57 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:54:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:54:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:54:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:54:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:54:57 --> Final output sent to browser
DEBUG - 2016-05-20 11:54:57 --> Total execution time: 0.0302
INFO - 2016-05-20 11:55:13 --> Config Class Initialized
INFO - 2016-05-20 11:55:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:55:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:55:13 --> Utf8 Class Initialized
INFO - 2016-05-20 11:55:13 --> URI Class Initialized
INFO - 2016-05-20 11:55:13 --> Router Class Initialized
INFO - 2016-05-20 11:55:13 --> Output Class Initialized
INFO - 2016-05-20 11:55:13 --> Security Class Initialized
DEBUG - 2016-05-20 11:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:55:13 --> CSRF cookie sent
INFO - 2016-05-20 11:55:13 --> CSRF token verified
INFO - 2016-05-20 11:55:13 --> Input Class Initialized
INFO - 2016-05-20 11:55:13 --> Language Class Initialized
INFO - 2016-05-20 11:55:13 --> Loader Class Initialized
INFO - 2016-05-20 11:55:13 --> Helper loaded: form_helper
INFO - 2016-05-20 11:55:13 --> Database Driver Class Initialized
INFO - 2016-05-20 11:55:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:55:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:55:13 --> Email Class Initialized
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:55:13 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:55:13 --> Helper loaded: language_helper
INFO - 2016-05-20 11:55:13 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:55:13 --> Model Class Initialized
INFO - 2016-05-20 11:55:13 --> Helper loaded: date_helper
INFO - 2016-05-20 11:55:13 --> Controller Class Initialized
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:55:13 --> Model Class Initialized
INFO - 2016-05-20 11:55:13 --> Form Validation Class Initialized
DEBUG - 2016-05-20 11:55:13 --> Email class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:55:13 --> Config Class Initialized
INFO - 2016-05-20 11:55:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:55:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:55:13 --> Utf8 Class Initialized
INFO - 2016-05-20 11:55:13 --> URI Class Initialized
INFO - 2016-05-20 11:55:13 --> Router Class Initialized
INFO - 2016-05-20 11:55:13 --> Output Class Initialized
INFO - 2016-05-20 11:55:13 --> Security Class Initialized
DEBUG - 2016-05-20 11:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:55:13 --> CSRF cookie sent
INFO - 2016-05-20 11:55:13 --> Input Class Initialized
INFO - 2016-05-20 11:55:13 --> Language Class Initialized
INFO - 2016-05-20 11:55:13 --> Loader Class Initialized
INFO - 2016-05-20 11:55:13 --> Helper loaded: form_helper
INFO - 2016-05-20 11:55:13 --> Database Driver Class Initialized
INFO - 2016-05-20 11:55:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:55:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:55:13 --> Email Class Initialized
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:55:13 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:55:13 --> Helper loaded: language_helper
INFO - 2016-05-20 11:55:13 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:55:13 --> Model Class Initialized
INFO - 2016-05-20 11:55:13 --> Helper loaded: date_helper
INFO - 2016-05-20 11:55:13 --> Controller Class Initialized
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:55:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:55:13 --> Model Class Initialized
INFO - 2016-05-20 11:55:13 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:55:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:55:13 --> Final output sent to browser
DEBUG - 2016-05-20 11:55:13 --> Total execution time: 0.0758
INFO - 2016-05-20 11:56:23 --> Config Class Initialized
INFO - 2016-05-20 11:56:23 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:56:23 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:56:23 --> Utf8 Class Initialized
INFO - 2016-05-20 11:56:23 --> URI Class Initialized
INFO - 2016-05-20 11:56:23 --> Router Class Initialized
INFO - 2016-05-20 11:56:23 --> Output Class Initialized
INFO - 2016-05-20 11:56:23 --> Security Class Initialized
DEBUG - 2016-05-20 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:56:23 --> CSRF cookie sent
INFO - 2016-05-20 11:56:23 --> Input Class Initialized
INFO - 2016-05-20 11:56:23 --> Language Class Initialized
INFO - 2016-05-20 11:56:23 --> Loader Class Initialized
INFO - 2016-05-20 11:56:23 --> Helper loaded: form_helper
INFO - 2016-05-20 11:56:23 --> Database Driver Class Initialized
INFO - 2016-05-20 11:56:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:56:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:56:23 --> Email Class Initialized
INFO - 2016-05-20 11:56:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:56:23 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:56:23 --> Helper loaded: language_helper
INFO - 2016-05-20 11:56:23 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:56:23 --> Model Class Initialized
INFO - 2016-05-20 11:56:23 --> Helper loaded: date_helper
INFO - 2016-05-20 11:56:23 --> Controller Class Initialized
INFO - 2016-05-20 11:56:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:56:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:56:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:56:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:56:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:56:23 --> Model Class Initialized
INFO - 2016-05-20 11:56:23 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:56:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:56:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:56:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:56:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:56:23 --> Final output sent to browser
DEBUG - 2016-05-20 11:56:23 --> Total execution time: 0.0540
INFO - 2016-05-20 11:56:26 --> Config Class Initialized
INFO - 2016-05-20 11:56:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:56:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:56:26 --> Utf8 Class Initialized
INFO - 2016-05-20 11:56:26 --> URI Class Initialized
INFO - 2016-05-20 11:56:26 --> Router Class Initialized
INFO - 2016-05-20 11:56:26 --> Output Class Initialized
INFO - 2016-05-20 11:56:26 --> Security Class Initialized
DEBUG - 2016-05-20 11:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:56:26 --> CSRF cookie sent
INFO - 2016-05-20 11:56:26 --> CSRF token verified
INFO - 2016-05-20 11:56:26 --> Input Class Initialized
INFO - 2016-05-20 11:56:26 --> Language Class Initialized
INFO - 2016-05-20 11:56:26 --> Loader Class Initialized
INFO - 2016-05-20 11:56:26 --> Helper loaded: form_helper
INFO - 2016-05-20 11:56:26 --> Database Driver Class Initialized
INFO - 2016-05-20 11:56:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:56:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:56:26 --> Email Class Initialized
INFO - 2016-05-20 11:56:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:56:26 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:56:26 --> Helper loaded: language_helper
INFO - 2016-05-20 11:56:26 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:56:26 --> Model Class Initialized
INFO - 2016-05-20 11:56:26 --> Helper loaded: date_helper
INFO - 2016-05-20 11:56:26 --> Controller Class Initialized
INFO - 2016-05-20 11:56:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:56:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:56:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:56:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:56:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:56:26 --> Model Class Initialized
INFO - 2016-05-20 11:56:26 --> Form Validation Class Initialized
INFO - 2016-05-20 11:56:26 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:56:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:56:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:56:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:56:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:56:26 --> Final output sent to browser
DEBUG - 2016-05-20 11:56:26 --> Total execution time: 0.0428
INFO - 2016-05-20 11:57:02 --> Config Class Initialized
INFO - 2016-05-20 11:57:02 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:57:02 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:57:02 --> Utf8 Class Initialized
INFO - 2016-05-20 11:57:02 --> URI Class Initialized
INFO - 2016-05-20 11:57:02 --> Router Class Initialized
INFO - 2016-05-20 11:57:02 --> Output Class Initialized
INFO - 2016-05-20 11:57:02 --> Security Class Initialized
DEBUG - 2016-05-20 11:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:57:02 --> CSRF cookie sent
INFO - 2016-05-20 11:57:02 --> CSRF token verified
INFO - 2016-05-20 11:57:02 --> Input Class Initialized
INFO - 2016-05-20 11:57:02 --> Language Class Initialized
INFO - 2016-05-20 11:57:02 --> Loader Class Initialized
INFO - 2016-05-20 11:57:02 --> Helper loaded: form_helper
INFO - 2016-05-20 11:57:02 --> Database Driver Class Initialized
INFO - 2016-05-20 11:57:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:57:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:57:02 --> Email Class Initialized
INFO - 2016-05-20 11:57:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:57:02 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:57:02 --> Helper loaded: language_helper
INFO - 2016-05-20 11:57:02 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:57:02 --> Model Class Initialized
INFO - 2016-05-20 11:57:02 --> Helper loaded: date_helper
INFO - 2016-05-20 11:57:02 --> Controller Class Initialized
INFO - 2016-05-20 11:57:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:57:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:57:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:57:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:57:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:57:02 --> Model Class Initialized
INFO - 2016-05-20 11:57:02 --> Form Validation Class Initialized
INFO - 2016-05-20 11:57:02 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:57:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:57:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:57:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:57:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:57:02 --> Final output sent to browser
DEBUG - 2016-05-20 11:57:02 --> Total execution time: 0.0646
INFO - 2016-05-20 11:58:07 --> Config Class Initialized
INFO - 2016-05-20 11:58:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:58:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:58:07 --> Utf8 Class Initialized
INFO - 2016-05-20 11:58:07 --> URI Class Initialized
INFO - 2016-05-20 11:58:07 --> Router Class Initialized
INFO - 2016-05-20 11:58:07 --> Output Class Initialized
INFO - 2016-05-20 11:58:07 --> Security Class Initialized
DEBUG - 2016-05-20 11:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:58:11 --> Config Class Initialized
INFO - 2016-05-20 11:58:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 11:58:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 11:58:11 --> Utf8 Class Initialized
INFO - 2016-05-20 11:58:11 --> URI Class Initialized
INFO - 2016-05-20 11:58:11 --> Router Class Initialized
INFO - 2016-05-20 11:58:11 --> Output Class Initialized
INFO - 2016-05-20 11:58:11 --> Security Class Initialized
DEBUG - 2016-05-20 11:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 11:58:11 --> CSRF cookie sent
INFO - 2016-05-20 11:58:11 --> Input Class Initialized
INFO - 2016-05-20 11:58:11 --> Language Class Initialized
INFO - 2016-05-20 11:58:11 --> Loader Class Initialized
INFO - 2016-05-20 11:58:11 --> Helper loaded: form_helper
INFO - 2016-05-20 11:58:11 --> Database Driver Class Initialized
INFO - 2016-05-20 11:58:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 11:58:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 11:58:11 --> Email Class Initialized
INFO - 2016-05-20 11:58:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 11:58:11 --> Helper loaded: cookie_helper
INFO - 2016-05-20 11:58:11 --> Helper loaded: language_helper
INFO - 2016-05-20 11:58:11 --> Helper loaded: url_helper
DEBUG - 2016-05-20 11:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 11:58:11 --> Model Class Initialized
INFO - 2016-05-20 11:58:11 --> Helper loaded: date_helper
INFO - 2016-05-20 11:58:11 --> Controller Class Initialized
INFO - 2016-05-20 11:58:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 11:58:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 11:58:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 11:58:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 11:58:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 11:58:11 --> Model Class Initialized
INFO - 2016-05-20 11:58:11 --> Helper loaded: languages_helper
INFO - 2016-05-20 11:58:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 11:58:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 11:58:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 11:58:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 11:58:11 --> Final output sent to browser
DEBUG - 2016-05-20 11:58:11 --> Total execution time: 0.0888
INFO - 2016-05-20 12:51:55 --> Config Class Initialized
INFO - 2016-05-20 12:51:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 12:51:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 12:51:55 --> Utf8 Class Initialized
INFO - 2016-05-20 12:51:55 --> URI Class Initialized
INFO - 2016-05-20 12:51:55 --> Router Class Initialized
INFO - 2016-05-20 12:51:55 --> Output Class Initialized
INFO - 2016-05-20 12:51:55 --> Security Class Initialized
DEBUG - 2016-05-20 12:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 12:51:55 --> CSRF cookie sent
INFO - 2016-05-20 12:51:55 --> Input Class Initialized
INFO - 2016-05-20 12:51:55 --> Language Class Initialized
INFO - 2016-05-20 12:51:55 --> Loader Class Initialized
INFO - 2016-05-20 12:51:55 --> Helper loaded: form_helper
INFO - 2016-05-20 12:51:55 --> Database Driver Class Initialized
INFO - 2016-05-20 12:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 12:51:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 12:51:55 --> Email Class Initialized
INFO - 2016-05-20 12:51:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 12:51:55 --> Helper loaded: cookie_helper
INFO - 2016-05-20 12:51:55 --> Helper loaded: language_helper
INFO - 2016-05-20 12:51:55 --> Helper loaded: url_helper
DEBUG - 2016-05-20 12:51:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:51:55 --> Model Class Initialized
INFO - 2016-05-20 12:51:55 --> Helper loaded: date_helper
INFO - 2016-05-20 12:51:55 --> Controller Class Initialized
INFO - 2016-05-20 12:51:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 12:51:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 12:51:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 12:51:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 12:51:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 12:51:55 --> Model Class Initialized
INFO - 2016-05-20 12:51:55 --> Helper loaded: languages_helper
INFO - 2016-05-20 12:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 12:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 12:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 12:51:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 12:51:55 --> Final output sent to browser
DEBUG - 2016-05-20 12:51:55 --> Total execution time: 0.0990
INFO - 2016-05-20 12:51:59 --> Config Class Initialized
INFO - 2016-05-20 12:51:59 --> Hooks Class Initialized
DEBUG - 2016-05-20 12:51:59 --> UTF-8 Support Enabled
INFO - 2016-05-20 12:51:59 --> Utf8 Class Initialized
INFO - 2016-05-20 12:51:59 --> URI Class Initialized
INFO - 2016-05-20 12:51:59 --> Router Class Initialized
INFO - 2016-05-20 12:51:59 --> Output Class Initialized
INFO - 2016-05-20 12:51:59 --> Security Class Initialized
DEBUG - 2016-05-20 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 12:51:59 --> CSRF cookie sent
INFO - 2016-05-20 12:51:59 --> CSRF token verified
INFO - 2016-05-20 12:51:59 --> Input Class Initialized
INFO - 2016-05-20 12:51:59 --> Language Class Initialized
INFO - 2016-05-20 12:51:59 --> Loader Class Initialized
INFO - 2016-05-20 12:51:59 --> Helper loaded: form_helper
INFO - 2016-05-20 12:51:59 --> Database Driver Class Initialized
INFO - 2016-05-20 12:51:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 12:51:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 12:51:59 --> Email Class Initialized
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 12:51:59 --> Helper loaded: cookie_helper
INFO - 2016-05-20 12:51:59 --> Helper loaded: language_helper
INFO - 2016-05-20 12:51:59 --> Helper loaded: url_helper
DEBUG - 2016-05-20 12:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:51:59 --> Model Class Initialized
INFO - 2016-05-20 12:51:59 --> Helper loaded: date_helper
INFO - 2016-05-20 12:51:59 --> Controller Class Initialized
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 12:51:59 --> Config Class Initialized
INFO - 2016-05-20 12:51:59 --> Hooks Class Initialized
DEBUG - 2016-05-20 12:51:59 --> UTF-8 Support Enabled
INFO - 2016-05-20 12:51:59 --> Utf8 Class Initialized
INFO - 2016-05-20 12:51:59 --> URI Class Initialized
INFO - 2016-05-20 12:51:59 --> Router Class Initialized
INFO - 2016-05-20 12:51:59 --> Output Class Initialized
INFO - 2016-05-20 12:51:59 --> Security Class Initialized
DEBUG - 2016-05-20 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 12:51:59 --> CSRF cookie sent
INFO - 2016-05-20 12:51:59 --> Input Class Initialized
INFO - 2016-05-20 12:51:59 --> Language Class Initialized
INFO - 2016-05-20 12:51:59 --> Loader Class Initialized
INFO - 2016-05-20 12:51:59 --> Helper loaded: form_helper
INFO - 2016-05-20 12:51:59 --> Database Driver Class Initialized
INFO - 2016-05-20 12:51:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 12:51:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 12:51:59 --> Email Class Initialized
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 12:51:59 --> Helper loaded: cookie_helper
INFO - 2016-05-20 12:51:59 --> Helper loaded: language_helper
INFO - 2016-05-20 12:51:59 --> Helper loaded: url_helper
DEBUG - 2016-05-20 12:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:51:59 --> Model Class Initialized
INFO - 2016-05-20 12:51:59 --> Helper loaded: date_helper
INFO - 2016-05-20 12:51:59 --> Controller Class Initialized
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 12:51:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 12:51:59 --> Model Class Initialized
INFO - 2016-05-20 12:51:59 --> Helper loaded: languages_helper
INFO - 2016-05-20 12:51:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 12:51:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 12:51:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 12:51:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 12:51:59 --> Final output sent to browser
DEBUG - 2016-05-20 12:51:59 --> Total execution time: 0.0300
INFO - 2016-05-20 12:52:08 --> Config Class Initialized
INFO - 2016-05-20 12:52:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 12:52:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 12:52:08 --> Utf8 Class Initialized
INFO - 2016-05-20 12:52:08 --> URI Class Initialized
INFO - 2016-05-20 12:52:08 --> Router Class Initialized
INFO - 2016-05-20 12:52:08 --> Output Class Initialized
INFO - 2016-05-20 12:52:08 --> Security Class Initialized
DEBUG - 2016-05-20 12:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 12:52:08 --> CSRF cookie sent
INFO - 2016-05-20 12:52:08 --> CSRF token verified
INFO - 2016-05-20 12:52:08 --> Input Class Initialized
INFO - 2016-05-20 12:52:08 --> Language Class Initialized
INFO - 2016-05-20 12:52:08 --> Loader Class Initialized
INFO - 2016-05-20 12:52:08 --> Helper loaded: form_helper
INFO - 2016-05-20 12:52:08 --> Database Driver Class Initialized
INFO - 2016-05-20 12:52:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 12:52:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 12:52:08 --> Email Class Initialized
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 12:52:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 12:52:08 --> Helper loaded: language_helper
INFO - 2016-05-20 12:52:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 12:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:52:08 --> Model Class Initialized
INFO - 2016-05-20 12:52:08 --> Helper loaded: date_helper
INFO - 2016-05-20 12:52:08 --> Controller Class Initialized
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 12:52:08 --> Config Class Initialized
INFO - 2016-05-20 12:52:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 12:52:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 12:52:08 --> Utf8 Class Initialized
INFO - 2016-05-20 12:52:08 --> URI Class Initialized
INFO - 2016-05-20 12:52:08 --> Router Class Initialized
INFO - 2016-05-20 12:52:08 --> Output Class Initialized
INFO - 2016-05-20 12:52:08 --> Security Class Initialized
DEBUG - 2016-05-20 12:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 12:52:08 --> CSRF cookie sent
INFO - 2016-05-20 12:52:08 --> Input Class Initialized
INFO - 2016-05-20 12:52:08 --> Language Class Initialized
INFO - 2016-05-20 12:52:08 --> Loader Class Initialized
INFO - 2016-05-20 12:52:08 --> Helper loaded: form_helper
INFO - 2016-05-20 12:52:08 --> Database Driver Class Initialized
INFO - 2016-05-20 12:52:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 12:52:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 12:52:08 --> Email Class Initialized
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 12:52:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 12:52:08 --> Helper loaded: language_helper
INFO - 2016-05-20 12:52:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 12:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:52:08 --> Model Class Initialized
INFO - 2016-05-20 12:52:08 --> Helper loaded: date_helper
INFO - 2016-05-20 12:52:08 --> Controller Class Initialized
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 12:52:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 12:52:08 --> Model Class Initialized
INFO - 2016-05-20 12:52:08 --> Helper loaded: languages_helper
INFO - 2016-05-20 12:52:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 12:52:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 12:52:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 12:52:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 12:52:08 --> Final output sent to browser
DEBUG - 2016-05-20 12:52:08 --> Total execution time: 0.0513
INFO - 2016-05-20 12:52:18 --> Config Class Initialized
INFO - 2016-05-20 12:52:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 12:52:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 12:52:18 --> Utf8 Class Initialized
INFO - 2016-05-20 12:52:18 --> URI Class Initialized
INFO - 2016-05-20 12:52:18 --> Router Class Initialized
INFO - 2016-05-20 12:52:18 --> Output Class Initialized
INFO - 2016-05-20 12:52:18 --> Security Class Initialized
DEBUG - 2016-05-20 12:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 12:52:18 --> CSRF cookie sent
INFO - 2016-05-20 12:52:18 --> Input Class Initialized
INFO - 2016-05-20 12:52:18 --> Language Class Initialized
INFO - 2016-05-20 12:52:18 --> Loader Class Initialized
INFO - 2016-05-20 12:52:18 --> Helper loaded: form_helper
INFO - 2016-05-20 12:52:18 --> Database Driver Class Initialized
INFO - 2016-05-20 12:52:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 12:52:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 12:52:18 --> Email Class Initialized
INFO - 2016-05-20 12:52:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 12:52:18 --> Helper loaded: cookie_helper
INFO - 2016-05-20 12:52:18 --> Helper loaded: language_helper
INFO - 2016-05-20 12:52:18 --> Helper loaded: url_helper
DEBUG - 2016-05-20 12:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:52:18 --> Model Class Initialized
INFO - 2016-05-20 12:52:18 --> Helper loaded: date_helper
INFO - 2016-05-20 12:52:18 --> Controller Class Initialized
INFO - 2016-05-20 12:52:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 12:52:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 12:52:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 12:52:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 12:52:18 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 12:52:18 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:52:18 --> Form Validation Class Initialized
INFO - 2016-05-20 12:52:19 --> Config Class Initialized
INFO - 2016-05-20 12:52:19 --> Hooks Class Initialized
DEBUG - 2016-05-20 12:52:19 --> UTF-8 Support Enabled
INFO - 2016-05-20 12:52:19 --> Utf8 Class Initialized
INFO - 2016-05-20 12:52:19 --> URI Class Initialized
INFO - 2016-05-20 12:52:19 --> Router Class Initialized
INFO - 2016-05-20 12:52:19 --> Output Class Initialized
INFO - 2016-05-20 12:52:19 --> Security Class Initialized
DEBUG - 2016-05-20 12:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 12:52:19 --> CSRF cookie sent
INFO - 2016-05-20 12:52:19 --> Input Class Initialized
INFO - 2016-05-20 12:52:19 --> Language Class Initialized
INFO - 2016-05-20 12:52:19 --> Loader Class Initialized
INFO - 2016-05-20 12:52:19 --> Helper loaded: form_helper
INFO - 2016-05-20 12:52:19 --> Database Driver Class Initialized
INFO - 2016-05-20 12:52:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 12:52:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 12:52:19 --> Email Class Initialized
INFO - 2016-05-20 12:52:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 12:52:19 --> Helper loaded: cookie_helper
INFO - 2016-05-20 12:52:19 --> Helper loaded: language_helper
INFO - 2016-05-20 12:52:19 --> Helper loaded: url_helper
DEBUG - 2016-05-20 12:52:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:52:19 --> Model Class Initialized
INFO - 2016-05-20 12:52:19 --> Helper loaded: date_helper
INFO - 2016-05-20 12:52:19 --> Controller Class Initialized
INFO - 2016-05-20 12:52:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 12:52:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 12:52:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 12:52:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 12:52:19 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 12:52:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 12:52:19 --> Form Validation Class Initialized
INFO - 2016-05-20 12:52:19 --> Helper loaded: languages_helper
INFO - 2016-05-20 12:52:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 12:52:19 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 12:52:19 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 12:52:19 --> Final output sent to browser
DEBUG - 2016-05-20 12:52:19 --> Total execution time: 0.0156
INFO - 2016-05-20 13:14:32 --> Config Class Initialized
INFO - 2016-05-20 13:14:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:32 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:32 --> URI Class Initialized
INFO - 2016-05-20 13:14:32 --> Router Class Initialized
INFO - 2016-05-20 13:14:32 --> Output Class Initialized
INFO - 2016-05-20 13:14:32 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:32 --> CSRF cookie sent
INFO - 2016-05-20 13:14:32 --> Input Class Initialized
INFO - 2016-05-20 13:14:32 --> Language Class Initialized
INFO - 2016-05-20 13:14:32 --> Loader Class Initialized
INFO - 2016-05-20 13:14:32 --> Helper loaded: form_helper
INFO - 2016-05-20 13:14:32 --> Database Driver Class Initialized
INFO - 2016-05-20 13:14:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:14:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:14:32 --> Email Class Initialized
INFO - 2016-05-20 13:14:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:14:32 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:14:32 --> Helper loaded: language_helper
INFO - 2016-05-20 13:14:32 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:14:32 --> Model Class Initialized
INFO - 2016-05-20 13:14:32 --> Helper loaded: date_helper
INFO - 2016-05-20 13:14:32 --> Controller Class Initialized
INFO - 2016-05-20 13:14:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:14:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:14:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:14:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:14:32 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 13:14:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:14:32 --> Form Validation Class Initialized
INFO - 2016-05-20 13:14:32 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:14:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:14:32 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 13:14:32 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:14:32 --> Final output sent to browser
DEBUG - 2016-05-20 13:14:32 --> Total execution time: 0.0576
INFO - 2016-05-20 13:14:32 --> Config Class Initialized
INFO - 2016-05-20 13:14:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:32 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:32 --> URI Class Initialized
INFO - 2016-05-20 13:14:32 --> Router Class Initialized
INFO - 2016-05-20 13:14:32 --> Output Class Initialized
INFO - 2016-05-20 13:14:32 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:32 --> CSRF cookie sent
INFO - 2016-05-20 13:14:32 --> Input Class Initialized
INFO - 2016-05-20 13:14:32 --> Language Class Initialized
ERROR - 2016-05-20 13:14:32 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:14:32 --> Config Class Initialized
INFO - 2016-05-20 13:14:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:32 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:32 --> URI Class Initialized
INFO - 2016-05-20 13:14:32 --> Router Class Initialized
INFO - 2016-05-20 13:14:32 --> Output Class Initialized
INFO - 2016-05-20 13:14:32 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:32 --> CSRF cookie sent
INFO - 2016-05-20 13:14:32 --> Input Class Initialized
INFO - 2016-05-20 13:14:32 --> Language Class Initialized
ERROR - 2016-05-20 13:14:32 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:14:33 --> Config Class Initialized
INFO - 2016-05-20 13:14:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:33 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:33 --> URI Class Initialized
INFO - 2016-05-20 13:14:33 --> Router Class Initialized
INFO - 2016-05-20 13:14:33 --> Output Class Initialized
INFO - 2016-05-20 13:14:33 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:33 --> CSRF cookie sent
INFO - 2016-05-20 13:14:33 --> Input Class Initialized
INFO - 2016-05-20 13:14:33 --> Language Class Initialized
ERROR - 2016-05-20 13:14:33 --> 404 Page Not Found: Auth/images
INFO - 2016-05-20 13:14:33 --> Config Class Initialized
INFO - 2016-05-20 13:14:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:33 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:33 --> URI Class Initialized
INFO - 2016-05-20 13:14:33 --> Router Class Initialized
INFO - 2016-05-20 13:14:33 --> Output Class Initialized
INFO - 2016-05-20 13:14:33 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:33 --> CSRF cookie sent
INFO - 2016-05-20 13:14:33 --> Input Class Initialized
INFO - 2016-05-20 13:14:33 --> Language Class Initialized
ERROR - 2016-05-20 13:14:33 --> 404 Page Not Found: Auth/images
INFO - 2016-05-20 13:14:33 --> Config Class Initialized
INFO - 2016-05-20 13:14:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:33 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:33 --> URI Class Initialized
INFO - 2016-05-20 13:14:33 --> Router Class Initialized
INFO - 2016-05-20 13:14:33 --> Output Class Initialized
INFO - 2016-05-20 13:14:33 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:33 --> CSRF cookie sent
INFO - 2016-05-20 13:14:33 --> Input Class Initialized
INFO - 2016-05-20 13:14:33 --> Language Class Initialized
ERROR - 2016-05-20 13:14:33 --> 404 Page Not Found: Auth/images
INFO - 2016-05-20 13:14:33 --> Config Class Initialized
INFO - 2016-05-20 13:14:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:33 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:33 --> URI Class Initialized
INFO - 2016-05-20 13:14:33 --> Router Class Initialized
INFO - 2016-05-20 13:14:33 --> Output Class Initialized
INFO - 2016-05-20 13:14:33 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:33 --> CSRF cookie sent
INFO - 2016-05-20 13:14:33 --> Input Class Initialized
INFO - 2016-05-20 13:14:33 --> Language Class Initialized
ERROR - 2016-05-20 13:14:33 --> 404 Page Not Found: Auth/images
INFO - 2016-05-20 13:14:33 --> Config Class Initialized
INFO - 2016-05-20 13:14:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:33 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:33 --> URI Class Initialized
INFO - 2016-05-20 13:14:33 --> Router Class Initialized
INFO - 2016-05-20 13:14:33 --> Output Class Initialized
INFO - 2016-05-20 13:14:33 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:33 --> CSRF cookie sent
INFO - 2016-05-20 13:14:33 --> Input Class Initialized
INFO - 2016-05-20 13:14:33 --> Language Class Initialized
ERROR - 2016-05-20 13:14:33 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:14:33 --> Config Class Initialized
INFO - 2016-05-20 13:14:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:14:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:14:33 --> Utf8 Class Initialized
INFO - 2016-05-20 13:14:33 --> URI Class Initialized
INFO - 2016-05-20 13:14:33 --> Router Class Initialized
INFO - 2016-05-20 13:14:33 --> Output Class Initialized
INFO - 2016-05-20 13:14:33 --> Security Class Initialized
DEBUG - 2016-05-20 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:14:33 --> CSRF cookie sent
INFO - 2016-05-20 13:14:33 --> Input Class Initialized
INFO - 2016-05-20 13:14:33 --> Language Class Initialized
ERROR - 2016-05-20 13:14:33 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:15:09 --> Config Class Initialized
INFO - 2016-05-20 13:15:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:09 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:09 --> URI Class Initialized
INFO - 2016-05-20 13:15:09 --> Router Class Initialized
INFO - 2016-05-20 13:15:09 --> Output Class Initialized
INFO - 2016-05-20 13:15:09 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:09 --> CSRF cookie sent
INFO - 2016-05-20 13:15:09 --> Input Class Initialized
INFO - 2016-05-20 13:15:09 --> Language Class Initialized
INFO - 2016-05-20 13:15:09 --> Loader Class Initialized
INFO - 2016-05-20 13:15:09 --> Helper loaded: form_helper
INFO - 2016-05-20 13:15:09 --> Database Driver Class Initialized
INFO - 2016-05-20 13:15:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:15:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:15:09 --> Email Class Initialized
INFO - 2016-05-20 13:15:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:15:09 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:15:09 --> Helper loaded: language_helper
INFO - 2016-05-20 13:15:09 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:15:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:15:09 --> Model Class Initialized
INFO - 2016-05-20 13:15:09 --> Helper loaded: date_helper
INFO - 2016-05-20 13:15:09 --> Controller Class Initialized
INFO - 2016-05-20 13:15:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:15:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:15:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:15:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:15:09 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 13:15:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:15:09 --> Form Validation Class Initialized
INFO - 2016-05-20 13:15:09 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:15:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:15:09 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 13:15:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:15:09 --> Final output sent to browser
DEBUG - 2016-05-20 13:15:09 --> Total execution time: 0.0384
INFO - 2016-05-20 13:15:09 --> Config Class Initialized
INFO - 2016-05-20 13:15:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:09 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:09 --> URI Class Initialized
INFO - 2016-05-20 13:15:09 --> Router Class Initialized
INFO - 2016-05-20 13:15:09 --> Output Class Initialized
INFO - 2016-05-20 13:15:09 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:09 --> CSRF cookie sent
INFO - 2016-05-20 13:15:09 --> Input Class Initialized
INFO - 2016-05-20 13:15:09 --> Language Class Initialized
ERROR - 2016-05-20 13:15:09 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:15:09 --> Config Class Initialized
INFO - 2016-05-20 13:15:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:09 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:09 --> URI Class Initialized
INFO - 2016-05-20 13:15:09 --> Router Class Initialized
INFO - 2016-05-20 13:15:09 --> Output Class Initialized
INFO - 2016-05-20 13:15:09 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:09 --> CSRF cookie sent
INFO - 2016-05-20 13:15:09 --> Input Class Initialized
INFO - 2016-05-20 13:15:09 --> Language Class Initialized
ERROR - 2016-05-20 13:15:09 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:15:09 --> Config Class Initialized
INFO - 2016-05-20 13:15:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:09 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:09 --> URI Class Initialized
INFO - 2016-05-20 13:15:09 --> Router Class Initialized
INFO - 2016-05-20 13:15:09 --> Output Class Initialized
INFO - 2016-05-20 13:15:09 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:09 --> CSRF cookie sent
INFO - 2016-05-20 13:15:09 --> Input Class Initialized
INFO - 2016-05-20 13:15:09 --> Language Class Initialized
ERROR - 2016-05-20 13:15:09 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:15:10 --> Config Class Initialized
INFO - 2016-05-20 13:15:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:10 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:10 --> URI Class Initialized
INFO - 2016-05-20 13:15:10 --> Router Class Initialized
INFO - 2016-05-20 13:15:10 --> Output Class Initialized
INFO - 2016-05-20 13:15:10 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:10 --> CSRF cookie sent
INFO - 2016-05-20 13:15:10 --> Input Class Initialized
INFO - 2016-05-20 13:15:10 --> Language Class Initialized
ERROR - 2016-05-20 13:15:10 --> 404 Page Not Found: Auth/js
INFO - 2016-05-20 13:15:24 --> Config Class Initialized
INFO - 2016-05-20 13:15:24 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:24 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:24 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:24 --> URI Class Initialized
DEBUG - 2016-05-20 13:15:24 --> No URI present. Default controller set.
INFO - 2016-05-20 13:15:24 --> Router Class Initialized
INFO - 2016-05-20 13:15:24 --> Output Class Initialized
INFO - 2016-05-20 13:15:24 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:24 --> CSRF cookie sent
INFO - 2016-05-20 13:15:24 --> Input Class Initialized
INFO - 2016-05-20 13:15:24 --> Language Class Initialized
INFO - 2016-05-20 13:15:24 --> Loader Class Initialized
INFO - 2016-05-20 13:15:24 --> Helper loaded: form_helper
INFO - 2016-05-20 13:15:24 --> Database Driver Class Initialized
INFO - 2016-05-20 13:15:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:15:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:15:24 --> Email Class Initialized
INFO - 2016-05-20 13:15:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:15:24 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:15:24 --> Helper loaded: language_helper
INFO - 2016-05-20 13:15:24 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:15:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:15:24 --> Model Class Initialized
INFO - 2016-05-20 13:15:24 --> Helper loaded: date_helper
INFO - 2016-05-20 13:15:24 --> Controller Class Initialized
INFO - 2016-05-20 13:15:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:15:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:15:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:15:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:15:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:15:24 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:15:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:15:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:15:24 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:15:24 --> Final output sent to browser
DEBUG - 2016-05-20 13:15:24 --> Total execution time: 0.0630
INFO - 2016-05-20 13:15:24 --> Config Class Initialized
INFO - 2016-05-20 13:15:24 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:24 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:24 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:24 --> Config Class Initialized
INFO - 2016-05-20 13:15:24 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:24 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:24 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:24 --> URI Class Initialized
INFO - 2016-05-20 13:15:24 --> URI Class Initialized
INFO - 2016-05-20 13:15:24 --> Router Class Initialized
INFO - 2016-05-20 13:15:24 --> Output Class Initialized
INFO - 2016-05-20 13:15:24 --> Router Class Initialized
INFO - 2016-05-20 13:15:24 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:24 --> CSRF cookie sent
INFO - 2016-05-20 13:15:24 --> Output Class Initialized
INFO - 2016-05-20 13:15:24 --> Input Class Initialized
INFO - 2016-05-20 13:15:24 --> Language Class Initialized
INFO - 2016-05-20 13:15:24 --> Security Class Initialized
ERROR - 2016-05-20 13:15:24 --> 404 Page Not Found: Js/owl.carousel.min.js
DEBUG - 2016-05-20 13:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:24 --> CSRF cookie sent
INFO - 2016-05-20 13:15:24 --> Input Class Initialized
INFO - 2016-05-20 13:15:24 --> Language Class Initialized
ERROR - 2016-05-20 13:15:24 --> 404 Page Not Found: Js/jquery.easing.1.3.js
INFO - 2016-05-20 13:15:25 --> Config Class Initialized
INFO - 2016-05-20 13:15:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:25 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:25 --> URI Class Initialized
INFO - 2016-05-20 13:15:25 --> Router Class Initialized
INFO - 2016-05-20 13:15:25 --> Output Class Initialized
INFO - 2016-05-20 13:15:25 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:25 --> CSRF cookie sent
INFO - 2016-05-20 13:15:25 --> Input Class Initialized
INFO - 2016-05-20 13:15:25 --> Language Class Initialized
ERROR - 2016-05-20 13:15:25 --> 404 Page Not Found: Js/jquery.easing.1.3.js
INFO - 2016-05-20 13:15:25 --> Config Class Initialized
INFO - 2016-05-20 13:15:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:15:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:15:25 --> Utf8 Class Initialized
INFO - 2016-05-20 13:15:25 --> URI Class Initialized
INFO - 2016-05-20 13:15:25 --> Router Class Initialized
INFO - 2016-05-20 13:15:25 --> Output Class Initialized
INFO - 2016-05-20 13:15:25 --> Security Class Initialized
DEBUG - 2016-05-20 13:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:15:25 --> CSRF cookie sent
INFO - 2016-05-20 13:15:25 --> Input Class Initialized
INFO - 2016-05-20 13:15:25 --> Language Class Initialized
ERROR - 2016-05-20 13:15:25 --> 404 Page Not Found: Js/owl.carousel.min.js
INFO - 2016-05-20 13:22:01 --> Config Class Initialized
INFO - 2016-05-20 13:22:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:22:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:22:01 --> Utf8 Class Initialized
INFO - 2016-05-20 13:22:01 --> URI Class Initialized
DEBUG - 2016-05-20 13:22:01 --> No URI present. Default controller set.
INFO - 2016-05-20 13:22:01 --> Router Class Initialized
INFO - 2016-05-20 13:22:01 --> Output Class Initialized
INFO - 2016-05-20 13:22:01 --> Security Class Initialized
DEBUG - 2016-05-20 13:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:22:01 --> CSRF cookie sent
INFO - 2016-05-20 13:22:01 --> Input Class Initialized
INFO - 2016-05-20 13:22:01 --> Language Class Initialized
INFO - 2016-05-20 13:22:01 --> Loader Class Initialized
INFO - 2016-05-20 13:22:01 --> Helper loaded: form_helper
INFO - 2016-05-20 13:22:01 --> Database Driver Class Initialized
INFO - 2016-05-20 13:22:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:22:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:22:01 --> Email Class Initialized
INFO - 2016-05-20 13:22:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:22:01 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:22:01 --> Helper loaded: language_helper
INFO - 2016-05-20 13:22:01 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:22:01 --> Model Class Initialized
INFO - 2016-05-20 13:22:01 --> Helper loaded: date_helper
INFO - 2016-05-20 13:22:01 --> Controller Class Initialized
INFO - 2016-05-20 13:22:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:22:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:22:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:22:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:22:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:22:01 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:22:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:22:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:22:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:22:01 --> Final output sent to browser
DEBUG - 2016-05-20 13:22:01 --> Total execution time: 0.0428
INFO - 2016-05-20 13:23:08 --> Config Class Initialized
INFO - 2016-05-20 13:23:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:23:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:23:08 --> Utf8 Class Initialized
INFO - 2016-05-20 13:23:08 --> URI Class Initialized
DEBUG - 2016-05-20 13:23:08 --> No URI present. Default controller set.
INFO - 2016-05-20 13:23:08 --> Router Class Initialized
INFO - 2016-05-20 13:23:08 --> Output Class Initialized
INFO - 2016-05-20 13:23:08 --> Security Class Initialized
DEBUG - 2016-05-20 13:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:23:08 --> CSRF cookie sent
INFO - 2016-05-20 13:23:08 --> Input Class Initialized
INFO - 2016-05-20 13:23:08 --> Language Class Initialized
INFO - 2016-05-20 13:23:08 --> Loader Class Initialized
INFO - 2016-05-20 13:23:08 --> Helper loaded: form_helper
INFO - 2016-05-20 13:23:08 --> Database Driver Class Initialized
INFO - 2016-05-20 13:23:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:23:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:23:08 --> Email Class Initialized
INFO - 2016-05-20 13:23:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:23:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:23:08 --> Helper loaded: language_helper
INFO - 2016-05-20 13:23:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:23:08 --> Model Class Initialized
INFO - 2016-05-20 13:23:08 --> Helper loaded: date_helper
INFO - 2016-05-20 13:23:08 --> Controller Class Initialized
INFO - 2016-05-20 13:23:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:23:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:23:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:23:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:23:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:23:08 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:23:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:23:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:23:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:23:08 --> Final output sent to browser
DEBUG - 2016-05-20 13:23:08 --> Total execution time: 0.0519
INFO - 2016-05-20 13:24:23 --> Config Class Initialized
INFO - 2016-05-20 13:24:23 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:24:23 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:24:23 --> Utf8 Class Initialized
INFO - 2016-05-20 13:24:23 --> URI Class Initialized
DEBUG - 2016-05-20 13:24:23 --> No URI present. Default controller set.
INFO - 2016-05-20 13:24:23 --> Router Class Initialized
INFO - 2016-05-20 13:24:23 --> Output Class Initialized
INFO - 2016-05-20 13:24:23 --> Security Class Initialized
DEBUG - 2016-05-20 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:24:23 --> CSRF cookie sent
INFO - 2016-05-20 13:24:23 --> Input Class Initialized
INFO - 2016-05-20 13:24:23 --> Language Class Initialized
INFO - 2016-05-20 13:24:23 --> Loader Class Initialized
INFO - 2016-05-20 13:24:23 --> Helper loaded: form_helper
INFO - 2016-05-20 13:24:23 --> Database Driver Class Initialized
INFO - 2016-05-20 13:24:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:24:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:24:23 --> Email Class Initialized
INFO - 2016-05-20 13:24:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:24:23 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:24:23 --> Helper loaded: language_helper
INFO - 2016-05-20 13:24:23 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:24:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:24:23 --> Model Class Initialized
INFO - 2016-05-20 13:24:23 --> Helper loaded: date_helper
INFO - 2016-05-20 13:24:23 --> Controller Class Initialized
INFO - 2016-05-20 13:24:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:24:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:24:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:24:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:24:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:24:23 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:24:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:24:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:24:23 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:24:23 --> Final output sent to browser
DEBUG - 2016-05-20 13:24:23 --> Total execution time: 0.0689
INFO - 2016-05-20 13:36:36 --> Config Class Initialized
INFO - 2016-05-20 13:36:36 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:36:36 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:36:36 --> Utf8 Class Initialized
INFO - 2016-05-20 13:36:36 --> URI Class Initialized
DEBUG - 2016-05-20 13:36:36 --> No URI present. Default controller set.
INFO - 2016-05-20 13:36:36 --> Router Class Initialized
INFO - 2016-05-20 13:36:36 --> Output Class Initialized
INFO - 2016-05-20 13:36:36 --> Security Class Initialized
DEBUG - 2016-05-20 13:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:36:36 --> CSRF cookie sent
INFO - 2016-05-20 13:36:36 --> Input Class Initialized
INFO - 2016-05-20 13:36:36 --> Language Class Initialized
INFO - 2016-05-20 13:36:36 --> Loader Class Initialized
INFO - 2016-05-20 13:36:36 --> Helper loaded: form_helper
INFO - 2016-05-20 13:36:36 --> Database Driver Class Initialized
INFO - 2016-05-20 13:36:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:36:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:36:36 --> Email Class Initialized
INFO - 2016-05-20 13:36:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:36:36 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:36:36 --> Helper loaded: language_helper
INFO - 2016-05-20 13:36:36 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:36:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:36:36 --> Model Class Initialized
INFO - 2016-05-20 13:36:36 --> Helper loaded: date_helper
INFO - 2016-05-20 13:36:36 --> Controller Class Initialized
INFO - 2016-05-20 13:36:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:36:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:36:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:36:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:36:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:36:36 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:36:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:36:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:36:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:36:36 --> Final output sent to browser
DEBUG - 2016-05-20 13:36:36 --> Total execution time: 0.0516
INFO - 2016-05-20 13:36:36 --> Config Class Initialized
INFO - 2016-05-20 13:36:36 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:36:36 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:36:36 --> Utf8 Class Initialized
INFO - 2016-05-20 13:36:36 --> URI Class Initialized
INFO - 2016-05-20 13:36:36 --> Router Class Initialized
INFO - 2016-05-20 13:36:36 --> Output Class Initialized
INFO - 2016-05-20 13:36:36 --> Security Class Initialized
DEBUG - 2016-05-20 13:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:36:36 --> CSRF cookie sent
INFO - 2016-05-20 13:36:36 --> Input Class Initialized
INFO - 2016-05-20 13:36:36 --> Language Class Initialized
ERROR - 2016-05-20 13:36:36 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 13:38:18 --> Config Class Initialized
INFO - 2016-05-20 13:38:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:38:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:38:18 --> Utf8 Class Initialized
INFO - 2016-05-20 13:38:18 --> URI Class Initialized
DEBUG - 2016-05-20 13:38:18 --> No URI present. Default controller set.
INFO - 2016-05-20 13:38:18 --> Router Class Initialized
INFO - 2016-05-20 13:38:18 --> Output Class Initialized
INFO - 2016-05-20 13:38:18 --> Security Class Initialized
DEBUG - 2016-05-20 13:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:38:18 --> CSRF cookie sent
INFO - 2016-05-20 13:38:18 --> Input Class Initialized
INFO - 2016-05-20 13:38:18 --> Language Class Initialized
INFO - 2016-05-20 13:38:18 --> Loader Class Initialized
INFO - 2016-05-20 13:38:18 --> Helper loaded: form_helper
INFO - 2016-05-20 13:38:18 --> Database Driver Class Initialized
INFO - 2016-05-20 13:38:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:38:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:38:18 --> Email Class Initialized
INFO - 2016-05-20 13:38:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:38:18 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:38:18 --> Helper loaded: language_helper
INFO - 2016-05-20 13:38:18 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:38:18 --> Model Class Initialized
INFO - 2016-05-20 13:38:18 --> Helper loaded: date_helper
INFO - 2016-05-20 13:38:18 --> Controller Class Initialized
INFO - 2016-05-20 13:38:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:38:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:38:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:38:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:38:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:38:18 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:38:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:38:18 --> Final output sent to browser
DEBUG - 2016-05-20 13:38:18 --> Total execution time: 0.0481
INFO - 2016-05-20 13:38:18 --> Config Class Initialized
INFO - 2016-05-20 13:38:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:38:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:38:18 --> Utf8 Class Initialized
INFO - 2016-05-20 13:38:18 --> URI Class Initialized
INFO - 2016-05-20 13:38:18 --> Router Class Initialized
INFO - 2016-05-20 13:38:18 --> Output Class Initialized
INFO - 2016-05-20 13:38:18 --> Security Class Initialized
DEBUG - 2016-05-20 13:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:38:18 --> CSRF cookie sent
INFO - 2016-05-20 13:38:18 --> Input Class Initialized
INFO - 2016-05-20 13:38:18 --> Language Class Initialized
ERROR - 2016-05-20 13:38:18 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 13:41:55 --> Config Class Initialized
INFO - 2016-05-20 13:41:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:41:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:41:55 --> Utf8 Class Initialized
INFO - 2016-05-20 13:41:55 --> URI Class Initialized
DEBUG - 2016-05-20 13:41:55 --> No URI present. Default controller set.
INFO - 2016-05-20 13:41:55 --> Router Class Initialized
INFO - 2016-05-20 13:41:55 --> Output Class Initialized
INFO - 2016-05-20 13:41:55 --> Security Class Initialized
DEBUG - 2016-05-20 13:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:41:55 --> CSRF cookie sent
INFO - 2016-05-20 13:41:55 --> Input Class Initialized
INFO - 2016-05-20 13:41:55 --> Language Class Initialized
INFO - 2016-05-20 13:41:55 --> Loader Class Initialized
INFO - 2016-05-20 13:41:55 --> Helper loaded: form_helper
INFO - 2016-05-20 13:41:55 --> Database Driver Class Initialized
INFO - 2016-05-20 13:41:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:41:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:41:55 --> Email Class Initialized
INFO - 2016-05-20 13:41:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:41:55 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:41:55 --> Helper loaded: language_helper
INFO - 2016-05-20 13:41:55 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:41:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:41:55 --> Model Class Initialized
INFO - 2016-05-20 13:41:55 --> Helper loaded: date_helper
INFO - 2016-05-20 13:41:55 --> Controller Class Initialized
INFO - 2016-05-20 13:41:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:41:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:41:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:41:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:41:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:41:55 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:41:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:41:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:41:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:41:55 --> Final output sent to browser
DEBUG - 2016-05-20 13:41:55 --> Total execution time: 0.0430
INFO - 2016-05-20 13:41:56 --> Config Class Initialized
INFO - 2016-05-20 13:41:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:41:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:41:56 --> Utf8 Class Initialized
INFO - 2016-05-20 13:41:56 --> URI Class Initialized
INFO - 2016-05-20 13:41:56 --> Router Class Initialized
INFO - 2016-05-20 13:41:56 --> Output Class Initialized
INFO - 2016-05-20 13:41:56 --> Security Class Initialized
DEBUG - 2016-05-20 13:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:41:56 --> CSRF cookie sent
INFO - 2016-05-20 13:41:56 --> Input Class Initialized
INFO - 2016-05-20 13:41:56 --> Language Class Initialized
ERROR - 2016-05-20 13:41:56 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 13:43:57 --> Config Class Initialized
INFO - 2016-05-20 13:43:57 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:43:57 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:43:57 --> Utf8 Class Initialized
INFO - 2016-05-20 13:43:57 --> URI Class Initialized
DEBUG - 2016-05-20 13:43:57 --> No URI present. Default controller set.
INFO - 2016-05-20 13:43:57 --> Router Class Initialized
INFO - 2016-05-20 13:43:57 --> Output Class Initialized
INFO - 2016-05-20 13:43:57 --> Security Class Initialized
DEBUG - 2016-05-20 13:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:43:57 --> CSRF cookie sent
INFO - 2016-05-20 13:43:57 --> Input Class Initialized
INFO - 2016-05-20 13:43:57 --> Language Class Initialized
INFO - 2016-05-20 13:43:57 --> Loader Class Initialized
INFO - 2016-05-20 13:43:57 --> Helper loaded: form_helper
INFO - 2016-05-20 13:43:57 --> Database Driver Class Initialized
INFO - 2016-05-20 13:43:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 13:43:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 13:43:57 --> Email Class Initialized
INFO - 2016-05-20 13:43:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 13:43:57 --> Helper loaded: cookie_helper
INFO - 2016-05-20 13:43:57 --> Helper loaded: language_helper
INFO - 2016-05-20 13:43:57 --> Helper loaded: url_helper
DEBUG - 2016-05-20 13:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 13:43:57 --> Model Class Initialized
INFO - 2016-05-20 13:43:57 --> Helper loaded: date_helper
INFO - 2016-05-20 13:43:57 --> Controller Class Initialized
INFO - 2016-05-20 13:43:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 13:43:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 13:43:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 13:43:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 13:43:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 13:43:57 --> Helper loaded: languages_helper
INFO - 2016-05-20 13:43:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 13:43:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 13:43:57 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 13:43:57 --> Final output sent to browser
DEBUG - 2016-05-20 13:43:57 --> Total execution time: 0.0498
INFO - 2016-05-20 13:43:57 --> Config Class Initialized
INFO - 2016-05-20 13:43:57 --> Hooks Class Initialized
DEBUG - 2016-05-20 13:43:57 --> UTF-8 Support Enabled
INFO - 2016-05-20 13:43:57 --> Utf8 Class Initialized
INFO - 2016-05-20 13:43:57 --> URI Class Initialized
INFO - 2016-05-20 13:43:57 --> Router Class Initialized
INFO - 2016-05-20 13:43:57 --> Output Class Initialized
INFO - 2016-05-20 13:43:57 --> Security Class Initialized
DEBUG - 2016-05-20 13:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 13:43:58 --> CSRF cookie sent
INFO - 2016-05-20 13:43:58 --> Input Class Initialized
INFO - 2016-05-20 13:43:58 --> Language Class Initialized
ERROR - 2016-05-20 13:43:58 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:20:43 --> Config Class Initialized
INFO - 2016-05-20 14:20:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:20:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:20:43 --> Utf8 Class Initialized
INFO - 2016-05-20 14:20:43 --> URI Class Initialized
DEBUG - 2016-05-20 14:20:43 --> No URI present. Default controller set.
INFO - 2016-05-20 14:20:43 --> Router Class Initialized
INFO - 2016-05-20 14:20:43 --> Output Class Initialized
INFO - 2016-05-20 14:20:43 --> Security Class Initialized
DEBUG - 2016-05-20 14:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:20:43 --> CSRF cookie sent
INFO - 2016-05-20 14:20:43 --> Input Class Initialized
INFO - 2016-05-20 14:20:43 --> Language Class Initialized
INFO - 2016-05-20 14:20:43 --> Loader Class Initialized
INFO - 2016-05-20 14:20:43 --> Helper loaded: form_helper
INFO - 2016-05-20 14:20:43 --> Database Driver Class Initialized
INFO - 2016-05-20 14:20:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:20:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:20:43 --> Email Class Initialized
INFO - 2016-05-20 14:20:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:20:43 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:20:43 --> Helper loaded: language_helper
INFO - 2016-05-20 14:20:43 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:20:43 --> Model Class Initialized
INFO - 2016-05-20 14:20:43 --> Helper loaded: date_helper
INFO - 2016-05-20 14:20:43 --> Controller Class Initialized
INFO - 2016-05-20 14:20:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:20:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:20:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:20:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:20:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:20:43 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:20:43 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:20:43 --> Final output sent to browser
DEBUG - 2016-05-20 14:20:43 --> Total execution time: 0.0378
INFO - 2016-05-20 14:20:43 --> Config Class Initialized
INFO - 2016-05-20 14:20:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:20:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:20:43 --> Utf8 Class Initialized
INFO - 2016-05-20 14:20:43 --> URI Class Initialized
INFO - 2016-05-20 14:20:43 --> Router Class Initialized
INFO - 2016-05-20 14:20:43 --> Output Class Initialized
INFO - 2016-05-20 14:20:43 --> Security Class Initialized
DEBUG - 2016-05-20 14:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:20:43 --> CSRF cookie sent
INFO - 2016-05-20 14:20:43 --> Input Class Initialized
INFO - 2016-05-20 14:20:43 --> Language Class Initialized
ERROR - 2016-05-20 14:20:43 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:21:20 --> Config Class Initialized
INFO - 2016-05-20 14:21:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:21:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:21:20 --> Utf8 Class Initialized
INFO - 2016-05-20 14:21:20 --> URI Class Initialized
INFO - 2016-05-20 14:21:20 --> Router Class Initialized
INFO - 2016-05-20 14:21:20 --> Output Class Initialized
INFO - 2016-05-20 14:21:20 --> Security Class Initialized
DEBUG - 2016-05-20 14:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:21:20 --> CSRF cookie sent
INFO - 2016-05-20 14:21:20 --> Input Class Initialized
INFO - 2016-05-20 14:21:20 --> Language Class Initialized
ERROR - 2016-05-20 14:21:20 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:22:37 --> Config Class Initialized
INFO - 2016-05-20 14:22:37 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:22:37 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:22:37 --> Utf8 Class Initialized
INFO - 2016-05-20 14:22:37 --> URI Class Initialized
DEBUG - 2016-05-20 14:22:37 --> No URI present. Default controller set.
INFO - 2016-05-20 14:22:37 --> Router Class Initialized
INFO - 2016-05-20 14:22:37 --> Output Class Initialized
INFO - 2016-05-20 14:22:37 --> Security Class Initialized
DEBUG - 2016-05-20 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:22:37 --> CSRF cookie sent
INFO - 2016-05-20 14:22:37 --> Input Class Initialized
INFO - 2016-05-20 14:22:37 --> Language Class Initialized
INFO - 2016-05-20 14:22:37 --> Loader Class Initialized
INFO - 2016-05-20 14:22:37 --> Helper loaded: form_helper
INFO - 2016-05-20 14:22:37 --> Database Driver Class Initialized
INFO - 2016-05-20 14:22:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:22:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:22:37 --> Email Class Initialized
INFO - 2016-05-20 14:22:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:22:37 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:22:37 --> Helper loaded: language_helper
INFO - 2016-05-20 14:22:37 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:22:37 --> Model Class Initialized
INFO - 2016-05-20 14:22:37 --> Helper loaded: date_helper
INFO - 2016-05-20 14:22:37 --> Controller Class Initialized
INFO - 2016-05-20 14:22:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:22:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:22:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:22:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:22:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:22:37 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:22:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:22:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:22:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:22:37 --> Final output sent to browser
DEBUG - 2016-05-20 14:22:37 --> Total execution time: 0.0172
INFO - 2016-05-20 14:22:38 --> Config Class Initialized
INFO - 2016-05-20 14:22:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:22:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:22:38 --> Utf8 Class Initialized
INFO - 2016-05-20 14:22:38 --> URI Class Initialized
INFO - 2016-05-20 14:22:38 --> Router Class Initialized
INFO - 2016-05-20 14:22:38 --> Output Class Initialized
INFO - 2016-05-20 14:22:38 --> Security Class Initialized
DEBUG - 2016-05-20 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:22:38 --> CSRF cookie sent
INFO - 2016-05-20 14:22:38 --> Input Class Initialized
INFO - 2016-05-20 14:22:38 --> Language Class Initialized
ERROR - 2016-05-20 14:22:38 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:22:45 --> Config Class Initialized
INFO - 2016-05-20 14:22:45 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:22:45 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:22:45 --> Utf8 Class Initialized
INFO - 2016-05-20 14:22:45 --> URI Class Initialized
INFO - 2016-05-20 14:22:45 --> Router Class Initialized
INFO - 2016-05-20 14:22:45 --> Output Class Initialized
INFO - 2016-05-20 14:22:45 --> Security Class Initialized
DEBUG - 2016-05-20 14:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:22:45 --> CSRF cookie sent
INFO - 2016-05-20 14:22:45 --> Input Class Initialized
INFO - 2016-05-20 14:22:45 --> Language Class Initialized
ERROR - 2016-05-20 14:22:45 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:23:12 --> Config Class Initialized
INFO - 2016-05-20 14:23:12 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:23:12 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:23:12 --> Utf8 Class Initialized
INFO - 2016-05-20 14:23:12 --> URI Class Initialized
DEBUG - 2016-05-20 14:23:12 --> No URI present. Default controller set.
INFO - 2016-05-20 14:23:12 --> Router Class Initialized
INFO - 2016-05-20 14:23:12 --> Output Class Initialized
INFO - 2016-05-20 14:23:12 --> Security Class Initialized
DEBUG - 2016-05-20 14:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:23:12 --> CSRF cookie sent
INFO - 2016-05-20 14:23:12 --> Input Class Initialized
INFO - 2016-05-20 14:23:12 --> Language Class Initialized
INFO - 2016-05-20 14:23:12 --> Loader Class Initialized
INFO - 2016-05-20 14:23:12 --> Helper loaded: form_helper
INFO - 2016-05-20 14:23:12 --> Database Driver Class Initialized
INFO - 2016-05-20 14:23:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:23:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:23:12 --> Email Class Initialized
INFO - 2016-05-20 14:23:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:23:12 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:23:12 --> Helper loaded: language_helper
INFO - 2016-05-20 14:23:12 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:23:12 --> Model Class Initialized
INFO - 2016-05-20 14:23:12 --> Helper loaded: date_helper
INFO - 2016-05-20 14:23:12 --> Controller Class Initialized
INFO - 2016-05-20 14:23:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:23:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:23:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:23:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:23:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:23:12 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:23:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:23:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:23:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:23:12 --> Final output sent to browser
DEBUG - 2016-05-20 14:23:12 --> Total execution time: 0.0394
INFO - 2016-05-20 14:23:13 --> Config Class Initialized
INFO - 2016-05-20 14:23:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:23:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:23:13 --> Utf8 Class Initialized
INFO - 2016-05-20 14:23:13 --> URI Class Initialized
INFO - 2016-05-20 14:23:13 --> Router Class Initialized
INFO - 2016-05-20 14:23:13 --> Output Class Initialized
INFO - 2016-05-20 14:23:13 --> Security Class Initialized
DEBUG - 2016-05-20 14:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:23:13 --> CSRF cookie sent
INFO - 2016-05-20 14:23:13 --> Input Class Initialized
INFO - 2016-05-20 14:23:13 --> Language Class Initialized
ERROR - 2016-05-20 14:23:13 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:23:20 --> Config Class Initialized
INFO - 2016-05-20 14:23:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:23:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:23:20 --> Utf8 Class Initialized
INFO - 2016-05-20 14:23:20 --> URI Class Initialized
INFO - 2016-05-20 14:23:20 --> Router Class Initialized
INFO - 2016-05-20 14:23:20 --> Output Class Initialized
INFO - 2016-05-20 14:23:20 --> Security Class Initialized
DEBUG - 2016-05-20 14:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:23:20 --> CSRF cookie sent
INFO - 2016-05-20 14:23:20 --> Input Class Initialized
INFO - 2016-05-20 14:23:20 --> Language Class Initialized
ERROR - 2016-05-20 14:23:20 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:23:30 --> Config Class Initialized
INFO - 2016-05-20 14:23:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:23:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:23:30 --> Utf8 Class Initialized
INFO - 2016-05-20 14:23:30 --> URI Class Initialized
DEBUG - 2016-05-20 14:23:30 --> No URI present. Default controller set.
INFO - 2016-05-20 14:23:30 --> Router Class Initialized
INFO - 2016-05-20 14:23:30 --> Output Class Initialized
INFO - 2016-05-20 14:23:30 --> Security Class Initialized
DEBUG - 2016-05-20 14:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:23:30 --> CSRF cookie sent
INFO - 2016-05-20 14:23:30 --> Input Class Initialized
INFO - 2016-05-20 14:23:30 --> Language Class Initialized
INFO - 2016-05-20 14:23:30 --> Loader Class Initialized
INFO - 2016-05-20 14:23:30 --> Helper loaded: form_helper
INFO - 2016-05-20 14:23:30 --> Database Driver Class Initialized
INFO - 2016-05-20 14:23:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:23:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:23:30 --> Email Class Initialized
INFO - 2016-05-20 14:23:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:23:30 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:23:30 --> Helper loaded: language_helper
INFO - 2016-05-20 14:23:30 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:23:30 --> Model Class Initialized
INFO - 2016-05-20 14:23:30 --> Helper loaded: date_helper
INFO - 2016-05-20 14:23:30 --> Controller Class Initialized
INFO - 2016-05-20 14:23:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:23:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:23:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:23:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:23:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:23:30 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:23:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:23:30 --> Final output sent to browser
DEBUG - 2016-05-20 14:23:30 --> Total execution time: 0.0361
INFO - 2016-05-20 14:23:31 --> Config Class Initialized
INFO - 2016-05-20 14:23:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:23:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:23:31 --> Utf8 Class Initialized
INFO - 2016-05-20 14:23:31 --> URI Class Initialized
INFO - 2016-05-20 14:23:31 --> Router Class Initialized
INFO - 2016-05-20 14:23:31 --> Output Class Initialized
INFO - 2016-05-20 14:23:31 --> Security Class Initialized
DEBUG - 2016-05-20 14:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:23:31 --> CSRF cookie sent
INFO - 2016-05-20 14:23:31 --> Input Class Initialized
INFO - 2016-05-20 14:23:31 --> Language Class Initialized
ERROR - 2016-05-20 14:23:31 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:23:40 --> Config Class Initialized
INFO - 2016-05-20 14:23:40 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:23:40 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:23:40 --> Utf8 Class Initialized
INFO - 2016-05-20 14:23:40 --> URI Class Initialized
INFO - 2016-05-20 14:23:40 --> Router Class Initialized
INFO - 2016-05-20 14:23:40 --> Output Class Initialized
INFO - 2016-05-20 14:23:40 --> Security Class Initialized
DEBUG - 2016-05-20 14:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:23:40 --> CSRF cookie sent
INFO - 2016-05-20 14:23:40 --> Input Class Initialized
INFO - 2016-05-20 14:23:40 --> Language Class Initialized
ERROR - 2016-05-20 14:23:40 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:25:45 --> Config Class Initialized
INFO - 2016-05-20 14:25:45 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:25:45 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:25:45 --> Utf8 Class Initialized
INFO - 2016-05-20 14:25:45 --> URI Class Initialized
DEBUG - 2016-05-20 14:25:45 --> No URI present. Default controller set.
INFO - 2016-05-20 14:25:45 --> Router Class Initialized
INFO - 2016-05-20 14:25:45 --> Output Class Initialized
INFO - 2016-05-20 14:25:45 --> Security Class Initialized
DEBUG - 2016-05-20 14:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:25:45 --> CSRF cookie sent
INFO - 2016-05-20 14:25:45 --> Input Class Initialized
INFO - 2016-05-20 14:25:45 --> Language Class Initialized
INFO - 2016-05-20 14:25:45 --> Loader Class Initialized
INFO - 2016-05-20 14:25:45 --> Helper loaded: form_helper
INFO - 2016-05-20 14:25:45 --> Database Driver Class Initialized
INFO - 2016-05-20 14:25:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:25:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:25:45 --> Email Class Initialized
INFO - 2016-05-20 14:25:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:25:45 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:25:45 --> Helper loaded: language_helper
INFO - 2016-05-20 14:25:45 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:25:45 --> Model Class Initialized
INFO - 2016-05-20 14:25:45 --> Helper loaded: date_helper
INFO - 2016-05-20 14:25:45 --> Controller Class Initialized
INFO - 2016-05-20 14:25:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:25:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:25:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:25:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:25:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:25:45 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:25:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:25:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:25:45 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:25:45 --> Final output sent to browser
DEBUG - 2016-05-20 14:25:45 --> Total execution time: 0.0268
INFO - 2016-05-20 14:25:46 --> Config Class Initialized
INFO - 2016-05-20 14:25:46 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:25:46 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:25:46 --> Utf8 Class Initialized
INFO - 2016-05-20 14:25:46 --> URI Class Initialized
INFO - 2016-05-20 14:25:46 --> Router Class Initialized
INFO - 2016-05-20 14:25:46 --> Output Class Initialized
INFO - 2016-05-20 14:25:46 --> Security Class Initialized
DEBUG - 2016-05-20 14:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:25:46 --> CSRF cookie sent
INFO - 2016-05-20 14:25:46 --> Input Class Initialized
INFO - 2016-05-20 14:25:46 --> Language Class Initialized
ERROR - 2016-05-20 14:25:46 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:25:54 --> Config Class Initialized
INFO - 2016-05-20 14:25:54 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:25:54 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:25:54 --> Utf8 Class Initialized
INFO - 2016-05-20 14:25:54 --> URI Class Initialized
INFO - 2016-05-20 14:25:54 --> Router Class Initialized
INFO - 2016-05-20 14:25:54 --> Output Class Initialized
INFO - 2016-05-20 14:25:54 --> Security Class Initialized
DEBUG - 2016-05-20 14:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:25:54 --> CSRF cookie sent
INFO - 2016-05-20 14:25:54 --> Input Class Initialized
INFO - 2016-05-20 14:25:54 --> Language Class Initialized
ERROR - 2016-05-20 14:25:54 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:26:08 --> Config Class Initialized
INFO - 2016-05-20 14:26:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:26:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:26:08 --> Utf8 Class Initialized
INFO - 2016-05-20 14:26:08 --> URI Class Initialized
DEBUG - 2016-05-20 14:26:08 --> No URI present. Default controller set.
INFO - 2016-05-20 14:26:08 --> Router Class Initialized
INFO - 2016-05-20 14:26:08 --> Output Class Initialized
INFO - 2016-05-20 14:26:08 --> Security Class Initialized
DEBUG - 2016-05-20 14:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:26:08 --> CSRF cookie sent
INFO - 2016-05-20 14:26:08 --> Input Class Initialized
INFO - 2016-05-20 14:26:08 --> Language Class Initialized
INFO - 2016-05-20 14:26:08 --> Loader Class Initialized
INFO - 2016-05-20 14:26:08 --> Helper loaded: form_helper
INFO - 2016-05-20 14:26:08 --> Database Driver Class Initialized
INFO - 2016-05-20 14:26:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:26:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:26:08 --> Email Class Initialized
INFO - 2016-05-20 14:26:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:26:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:26:08 --> Helper loaded: language_helper
INFO - 2016-05-20 14:26:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:26:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:26:08 --> Model Class Initialized
INFO - 2016-05-20 14:26:08 --> Helper loaded: date_helper
INFO - 2016-05-20 14:26:08 --> Controller Class Initialized
INFO - 2016-05-20 14:26:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:26:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:26:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:26:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:26:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:26:08 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:26:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:26:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:26:08 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:26:08 --> Final output sent to browser
DEBUG - 2016-05-20 14:26:08 --> Total execution time: 0.0659
INFO - 2016-05-20 14:26:09 --> Config Class Initialized
INFO - 2016-05-20 14:26:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:26:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:26:09 --> Utf8 Class Initialized
INFO - 2016-05-20 14:26:09 --> URI Class Initialized
INFO - 2016-05-20 14:26:09 --> Router Class Initialized
INFO - 2016-05-20 14:26:09 --> Output Class Initialized
INFO - 2016-05-20 14:26:09 --> Security Class Initialized
DEBUG - 2016-05-20 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:26:09 --> CSRF cookie sent
INFO - 2016-05-20 14:26:09 --> Input Class Initialized
INFO - 2016-05-20 14:26:09 --> Language Class Initialized
ERROR - 2016-05-20 14:26:09 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:26:17 --> Config Class Initialized
INFO - 2016-05-20 14:26:17 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:26:17 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:26:17 --> Utf8 Class Initialized
INFO - 2016-05-20 14:26:17 --> URI Class Initialized
INFO - 2016-05-20 14:26:17 --> Router Class Initialized
INFO - 2016-05-20 14:26:17 --> Output Class Initialized
INFO - 2016-05-20 14:26:17 --> Security Class Initialized
DEBUG - 2016-05-20 14:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:26:17 --> CSRF cookie sent
INFO - 2016-05-20 14:26:17 --> Input Class Initialized
INFO - 2016-05-20 14:26:17 --> Language Class Initialized
ERROR - 2016-05-20 14:26:17 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:26:28 --> Config Class Initialized
INFO - 2016-05-20 14:26:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:26:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:26:28 --> Utf8 Class Initialized
INFO - 2016-05-20 14:26:28 --> URI Class Initialized
DEBUG - 2016-05-20 14:26:28 --> No URI present. Default controller set.
INFO - 2016-05-20 14:26:28 --> Router Class Initialized
INFO - 2016-05-20 14:26:28 --> Output Class Initialized
INFO - 2016-05-20 14:26:28 --> Security Class Initialized
DEBUG - 2016-05-20 14:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:26:28 --> CSRF cookie sent
INFO - 2016-05-20 14:26:28 --> Input Class Initialized
INFO - 2016-05-20 14:26:28 --> Language Class Initialized
INFO - 2016-05-20 14:26:28 --> Loader Class Initialized
INFO - 2016-05-20 14:26:28 --> Helper loaded: form_helper
INFO - 2016-05-20 14:26:28 --> Database Driver Class Initialized
INFO - 2016-05-20 14:26:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:26:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:26:28 --> Email Class Initialized
INFO - 2016-05-20 14:26:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:26:28 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:26:28 --> Helper loaded: language_helper
INFO - 2016-05-20 14:26:28 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:26:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:26:28 --> Model Class Initialized
INFO - 2016-05-20 14:26:28 --> Helper loaded: date_helper
INFO - 2016-05-20 14:26:28 --> Controller Class Initialized
INFO - 2016-05-20 14:26:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:26:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:26:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:26:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:26:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:26:28 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:26:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:26:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:26:28 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:26:28 --> Final output sent to browser
DEBUG - 2016-05-20 14:26:28 --> Total execution time: 0.0135
INFO - 2016-05-20 14:26:29 --> Config Class Initialized
INFO - 2016-05-20 14:26:29 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:26:29 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:26:29 --> Utf8 Class Initialized
INFO - 2016-05-20 14:26:29 --> URI Class Initialized
INFO - 2016-05-20 14:26:29 --> Router Class Initialized
INFO - 2016-05-20 14:26:29 --> Output Class Initialized
INFO - 2016-05-20 14:26:29 --> Security Class Initialized
DEBUG - 2016-05-20 14:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:26:29 --> CSRF cookie sent
INFO - 2016-05-20 14:26:29 --> Input Class Initialized
INFO - 2016-05-20 14:26:29 --> Language Class Initialized
ERROR - 2016-05-20 14:26:29 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:26:39 --> Config Class Initialized
INFO - 2016-05-20 14:26:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:26:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:26:39 --> Utf8 Class Initialized
INFO - 2016-05-20 14:26:39 --> URI Class Initialized
INFO - 2016-05-20 14:26:39 --> Router Class Initialized
INFO - 2016-05-20 14:26:39 --> Output Class Initialized
INFO - 2016-05-20 14:26:39 --> Security Class Initialized
DEBUG - 2016-05-20 14:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:26:39 --> CSRF cookie sent
INFO - 2016-05-20 14:26:39 --> Input Class Initialized
INFO - 2016-05-20 14:26:39 --> Language Class Initialized
ERROR - 2016-05-20 14:26:39 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:27:27 --> Config Class Initialized
INFO - 2016-05-20 14:27:27 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:27:27 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:27:27 --> Utf8 Class Initialized
INFO - 2016-05-20 14:27:27 --> URI Class Initialized
DEBUG - 2016-05-20 14:27:27 --> No URI present. Default controller set.
INFO - 2016-05-20 14:27:27 --> Router Class Initialized
INFO - 2016-05-20 14:27:27 --> Output Class Initialized
INFO - 2016-05-20 14:27:27 --> Security Class Initialized
DEBUG - 2016-05-20 14:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:27:27 --> CSRF cookie sent
INFO - 2016-05-20 14:27:27 --> Input Class Initialized
INFO - 2016-05-20 14:27:27 --> Language Class Initialized
INFO - 2016-05-20 14:27:27 --> Loader Class Initialized
INFO - 2016-05-20 14:27:27 --> Helper loaded: form_helper
INFO - 2016-05-20 14:27:27 --> Database Driver Class Initialized
INFO - 2016-05-20 14:27:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:27:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:27:27 --> Email Class Initialized
INFO - 2016-05-20 14:27:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:27:27 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:27:27 --> Helper loaded: language_helper
INFO - 2016-05-20 14:27:27 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:27:27 --> Model Class Initialized
INFO - 2016-05-20 14:27:27 --> Helper loaded: date_helper
INFO - 2016-05-20 14:27:27 --> Controller Class Initialized
INFO - 2016-05-20 14:27:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:27:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:27:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:27:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:27:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:27:27 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:27:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:27:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:27:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:27:27 --> Final output sent to browser
DEBUG - 2016-05-20 14:27:27 --> Total execution time: 0.0383
INFO - 2016-05-20 14:27:28 --> Config Class Initialized
INFO - 2016-05-20 14:27:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:27:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:27:28 --> Utf8 Class Initialized
INFO - 2016-05-20 14:27:28 --> URI Class Initialized
INFO - 2016-05-20 14:27:28 --> Router Class Initialized
INFO - 2016-05-20 14:27:28 --> Output Class Initialized
INFO - 2016-05-20 14:27:28 --> Security Class Initialized
DEBUG - 2016-05-20 14:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:27:28 --> CSRF cookie sent
INFO - 2016-05-20 14:27:28 --> Input Class Initialized
INFO - 2016-05-20 14:27:28 --> Language Class Initialized
ERROR - 2016-05-20 14:27:28 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:27:39 --> Config Class Initialized
INFO - 2016-05-20 14:27:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:27:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:27:39 --> Utf8 Class Initialized
INFO - 2016-05-20 14:27:39 --> URI Class Initialized
INFO - 2016-05-20 14:27:39 --> Router Class Initialized
INFO - 2016-05-20 14:27:39 --> Output Class Initialized
INFO - 2016-05-20 14:27:39 --> Security Class Initialized
DEBUG - 2016-05-20 14:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:27:39 --> CSRF cookie sent
INFO - 2016-05-20 14:27:39 --> Input Class Initialized
INFO - 2016-05-20 14:27:39 --> Language Class Initialized
ERROR - 2016-05-20 14:27:39 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:29:48 --> Config Class Initialized
INFO - 2016-05-20 14:29:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:29:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:29:48 --> Utf8 Class Initialized
INFO - 2016-05-20 14:29:48 --> URI Class Initialized
DEBUG - 2016-05-20 14:29:48 --> No URI present. Default controller set.
INFO - 2016-05-20 14:29:48 --> Router Class Initialized
INFO - 2016-05-20 14:29:48 --> Output Class Initialized
INFO - 2016-05-20 14:29:48 --> Security Class Initialized
DEBUG - 2016-05-20 14:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:29:48 --> CSRF cookie sent
INFO - 2016-05-20 14:29:48 --> Input Class Initialized
INFO - 2016-05-20 14:29:48 --> Language Class Initialized
INFO - 2016-05-20 14:29:48 --> Loader Class Initialized
INFO - 2016-05-20 14:29:48 --> Helper loaded: form_helper
INFO - 2016-05-20 14:29:48 --> Database Driver Class Initialized
INFO - 2016-05-20 14:29:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:29:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:29:48 --> Email Class Initialized
INFO - 2016-05-20 14:29:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:29:48 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:29:48 --> Helper loaded: language_helper
INFO - 2016-05-20 14:29:48 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:29:48 --> Model Class Initialized
INFO - 2016-05-20 14:29:48 --> Helper loaded: date_helper
INFO - 2016-05-20 14:29:48 --> Controller Class Initialized
INFO - 2016-05-20 14:29:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:29:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:29:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:29:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:29:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:29:48 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:29:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:29:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:29:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:29:48 --> Final output sent to browser
DEBUG - 2016-05-20 14:29:48 --> Total execution time: 0.0378
INFO - 2016-05-20 14:29:49 --> Config Class Initialized
INFO - 2016-05-20 14:29:49 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:29:49 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:29:49 --> Utf8 Class Initialized
INFO - 2016-05-20 14:29:49 --> URI Class Initialized
INFO - 2016-05-20 14:29:49 --> Router Class Initialized
INFO - 2016-05-20 14:29:49 --> Output Class Initialized
INFO - 2016-05-20 14:29:49 --> Security Class Initialized
DEBUG - 2016-05-20 14:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:29:49 --> CSRF cookie sent
INFO - 2016-05-20 14:29:49 --> Input Class Initialized
INFO - 2016-05-20 14:29:49 --> Language Class Initialized
ERROR - 2016-05-20 14:29:49 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:29:55 --> Config Class Initialized
INFO - 2016-05-20 14:29:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:29:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:29:55 --> Utf8 Class Initialized
INFO - 2016-05-20 14:29:55 --> URI Class Initialized
INFO - 2016-05-20 14:29:55 --> Router Class Initialized
INFO - 2016-05-20 14:29:55 --> Output Class Initialized
INFO - 2016-05-20 14:29:55 --> Security Class Initialized
DEBUG - 2016-05-20 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:29:55 --> CSRF cookie sent
INFO - 2016-05-20 14:29:55 --> Input Class Initialized
INFO - 2016-05-20 14:29:55 --> Language Class Initialized
ERROR - 2016-05-20 14:29:55 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:35:26 --> Config Class Initialized
INFO - 2016-05-20 14:35:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:35:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:35:26 --> Utf8 Class Initialized
INFO - 2016-05-20 14:35:26 --> URI Class Initialized
INFO - 2016-05-20 14:35:26 --> Router Class Initialized
INFO - 2016-05-20 14:35:26 --> Output Class Initialized
INFO - 2016-05-20 14:35:26 --> Security Class Initialized
DEBUG - 2016-05-20 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:35:26 --> CSRF cookie sent
INFO - 2016-05-20 14:35:26 --> Input Class Initialized
INFO - 2016-05-20 14:35:26 --> Language Class Initialized
INFO - 2016-05-20 14:35:26 --> Loader Class Initialized
INFO - 2016-05-20 14:35:26 --> Helper loaded: form_helper
INFO - 2016-05-20 14:35:26 --> Database Driver Class Initialized
INFO - 2016-05-20 14:35:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:35:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:35:26 --> Email Class Initialized
INFO - 2016-05-20 14:35:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:35:26 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:35:26 --> Helper loaded: language_helper
INFO - 2016-05-20 14:35:26 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:35:26 --> Model Class Initialized
INFO - 2016-05-20 14:35:26 --> Helper loaded: date_helper
INFO - 2016-05-20 14:35:26 --> Controller Class Initialized
INFO - 2016-05-20 14:35:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:35:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:35:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:35:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:35:26 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:35:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:35:26 --> Form Validation Class Initialized
INFO - 2016-05-20 14:35:26 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:35:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:35:26 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:35:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:35:26 --> Final output sent to browser
DEBUG - 2016-05-20 14:35:26 --> Total execution time: 0.0591
INFO - 2016-05-20 14:35:27 --> Config Class Initialized
INFO - 2016-05-20 14:35:27 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:35:27 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:35:27 --> Utf8 Class Initialized
INFO - 2016-05-20 14:35:27 --> URI Class Initialized
INFO - 2016-05-20 14:35:27 --> Router Class Initialized
INFO - 2016-05-20 14:35:27 --> Output Class Initialized
INFO - 2016-05-20 14:35:27 --> Security Class Initialized
DEBUG - 2016-05-20 14:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:35:27 --> CSRF cookie sent
INFO - 2016-05-20 14:35:27 --> Input Class Initialized
INFO - 2016-05-20 14:35:27 --> Language Class Initialized
ERROR - 2016-05-20 14:35:27 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:35:55 --> Config Class Initialized
INFO - 2016-05-20 14:35:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:35:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:35:55 --> Utf8 Class Initialized
INFO - 2016-05-20 14:35:55 --> URI Class Initialized
DEBUG - 2016-05-20 14:35:55 --> No URI present. Default controller set.
INFO - 2016-05-20 14:35:55 --> Router Class Initialized
INFO - 2016-05-20 14:35:55 --> Output Class Initialized
INFO - 2016-05-20 14:35:55 --> Security Class Initialized
DEBUG - 2016-05-20 14:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:35:55 --> CSRF cookie sent
INFO - 2016-05-20 14:35:55 --> Input Class Initialized
INFO - 2016-05-20 14:35:55 --> Language Class Initialized
INFO - 2016-05-20 14:35:55 --> Loader Class Initialized
INFO - 2016-05-20 14:35:55 --> Helper loaded: form_helper
INFO - 2016-05-20 14:35:55 --> Database Driver Class Initialized
INFO - 2016-05-20 14:35:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:35:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:35:55 --> Email Class Initialized
INFO - 2016-05-20 14:35:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:35:55 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:35:55 --> Helper loaded: language_helper
INFO - 2016-05-20 14:35:55 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:35:55 --> Model Class Initialized
INFO - 2016-05-20 14:35:55 --> Helper loaded: date_helper
INFO - 2016-05-20 14:35:55 --> Controller Class Initialized
INFO - 2016-05-20 14:35:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:35:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:35:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:35:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:35:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:35:55 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:35:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:35:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:35:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:35:55 --> Final output sent to browser
DEBUG - 2016-05-20 14:35:55 --> Total execution time: 0.0539
INFO - 2016-05-20 14:35:56 --> Config Class Initialized
INFO - 2016-05-20 14:35:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:35:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:35:56 --> Utf8 Class Initialized
INFO - 2016-05-20 14:35:56 --> URI Class Initialized
INFO - 2016-05-20 14:35:56 --> Router Class Initialized
INFO - 2016-05-20 14:35:56 --> Output Class Initialized
INFO - 2016-05-20 14:35:56 --> Security Class Initialized
DEBUG - 2016-05-20 14:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:35:56 --> CSRF cookie sent
INFO - 2016-05-20 14:35:56 --> Input Class Initialized
INFO - 2016-05-20 14:35:56 --> Language Class Initialized
ERROR - 2016-05-20 14:35:56 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:36:00 --> Config Class Initialized
INFO - 2016-05-20 14:36:00 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:36:00 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:36:00 --> Utf8 Class Initialized
INFO - 2016-05-20 14:36:00 --> URI Class Initialized
INFO - 2016-05-20 14:36:00 --> Router Class Initialized
INFO - 2016-05-20 14:36:00 --> Output Class Initialized
INFO - 2016-05-20 14:36:00 --> Security Class Initialized
DEBUG - 2016-05-20 14:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:36:00 --> CSRF cookie sent
INFO - 2016-05-20 14:36:00 --> Input Class Initialized
INFO - 2016-05-20 14:36:00 --> Language Class Initialized
INFO - 2016-05-20 14:36:00 --> Loader Class Initialized
INFO - 2016-05-20 14:36:00 --> Helper loaded: form_helper
INFO - 2016-05-20 14:36:00 --> Database Driver Class Initialized
INFO - 2016-05-20 14:36:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:36:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:36:00 --> Email Class Initialized
INFO - 2016-05-20 14:36:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:36:00 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:36:00 --> Helper loaded: language_helper
INFO - 2016-05-20 14:36:00 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:36:00 --> Model Class Initialized
INFO - 2016-05-20 14:36:00 --> Helper loaded: date_helper
INFO - 2016-05-20 14:36:00 --> Controller Class Initialized
INFO - 2016-05-20 14:36:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:36:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:36:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:36:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:36:00 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:36:00 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:36:00 --> Form Validation Class Initialized
INFO - 2016-05-20 14:36:00 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:36:00 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:36:00 --> Final output sent to browser
DEBUG - 2016-05-20 14:36:00 --> Total execution time: 0.0196
INFO - 2016-05-20 14:36:00 --> Config Class Initialized
INFO - 2016-05-20 14:36:00 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:36:00 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:36:00 --> Utf8 Class Initialized
INFO - 2016-05-20 14:36:00 --> URI Class Initialized
INFO - 2016-05-20 14:36:00 --> Router Class Initialized
INFO - 2016-05-20 14:36:00 --> Output Class Initialized
INFO - 2016-05-20 14:36:00 --> Security Class Initialized
DEBUG - 2016-05-20 14:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:36:00 --> CSRF cookie sent
INFO - 2016-05-20 14:36:00 --> Input Class Initialized
INFO - 2016-05-20 14:36:00 --> Language Class Initialized
ERROR - 2016-05-20 14:36:00 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:37:01 --> Config Class Initialized
INFO - 2016-05-20 14:37:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:37:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:37:01 --> Utf8 Class Initialized
INFO - 2016-05-20 14:37:01 --> URI Class Initialized
INFO - 2016-05-20 14:37:01 --> Router Class Initialized
INFO - 2016-05-20 14:37:01 --> Output Class Initialized
INFO - 2016-05-20 14:37:01 --> Security Class Initialized
DEBUG - 2016-05-20 14:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:37:01 --> CSRF cookie sent
INFO - 2016-05-20 14:37:01 --> Input Class Initialized
INFO - 2016-05-20 14:37:01 --> Language Class Initialized
INFO - 2016-05-20 14:37:01 --> Loader Class Initialized
INFO - 2016-05-20 14:37:01 --> Helper loaded: form_helper
INFO - 2016-05-20 14:37:01 --> Database Driver Class Initialized
INFO - 2016-05-20 14:37:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:37:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:37:01 --> Email Class Initialized
INFO - 2016-05-20 14:37:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:37:01 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:37:01 --> Helper loaded: language_helper
INFO - 2016-05-20 14:37:01 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:37:01 --> Model Class Initialized
INFO - 2016-05-20 14:37:01 --> Helper loaded: date_helper
INFO - 2016-05-20 14:37:01 --> Controller Class Initialized
INFO - 2016-05-20 14:37:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:37:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:37:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:37:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:37:01 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:37:01 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:37:01 --> Form Validation Class Initialized
INFO - 2016-05-20 14:37:01 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:37:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:37:01 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:37:01 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:37:01 --> Final output sent to browser
DEBUG - 2016-05-20 14:37:01 --> Total execution time: 0.0667
INFO - 2016-05-20 14:37:02 --> Config Class Initialized
INFO - 2016-05-20 14:37:02 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:37:02 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:37:02 --> Utf8 Class Initialized
INFO - 2016-05-20 14:37:02 --> URI Class Initialized
INFO - 2016-05-20 14:37:02 --> Router Class Initialized
INFO - 2016-05-20 14:37:02 --> Output Class Initialized
INFO - 2016-05-20 14:37:02 --> Security Class Initialized
DEBUG - 2016-05-20 14:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:37:02 --> CSRF cookie sent
INFO - 2016-05-20 14:37:02 --> Input Class Initialized
INFO - 2016-05-20 14:37:02 --> Language Class Initialized
ERROR - 2016-05-20 14:37:02 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:38:10 --> Config Class Initialized
INFO - 2016-05-20 14:38:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:38:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:38:10 --> Utf8 Class Initialized
INFO - 2016-05-20 14:38:10 --> URI Class Initialized
INFO - 2016-05-20 14:38:10 --> Router Class Initialized
INFO - 2016-05-20 14:38:10 --> Output Class Initialized
INFO - 2016-05-20 14:38:10 --> Security Class Initialized
DEBUG - 2016-05-20 14:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:38:10 --> CSRF cookie sent
INFO - 2016-05-20 14:38:10 --> Input Class Initialized
INFO - 2016-05-20 14:38:10 --> Language Class Initialized
INFO - 2016-05-20 14:38:10 --> Loader Class Initialized
INFO - 2016-05-20 14:38:10 --> Helper loaded: form_helper
INFO - 2016-05-20 14:38:10 --> Database Driver Class Initialized
INFO - 2016-05-20 14:38:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:38:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:38:10 --> Email Class Initialized
INFO - 2016-05-20 14:38:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:38:10 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:38:10 --> Helper loaded: language_helper
INFO - 2016-05-20 14:38:10 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:38:10 --> Model Class Initialized
INFO - 2016-05-20 14:38:10 --> Helper loaded: date_helper
INFO - 2016-05-20 14:38:10 --> Controller Class Initialized
INFO - 2016-05-20 14:38:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:38:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:38:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:38:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:38:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:38:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:38:10 --> Form Validation Class Initialized
INFO - 2016-05-20 14:38:10 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:38:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:38:10 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:38:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:38:10 --> Final output sent to browser
DEBUG - 2016-05-20 14:38:10 --> Total execution time: 0.0366
INFO - 2016-05-20 14:38:11 --> Config Class Initialized
INFO - 2016-05-20 14:38:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:38:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:38:11 --> Utf8 Class Initialized
INFO - 2016-05-20 14:38:11 --> URI Class Initialized
INFO - 2016-05-20 14:38:11 --> Router Class Initialized
INFO - 2016-05-20 14:38:11 --> Output Class Initialized
INFO - 2016-05-20 14:38:11 --> Security Class Initialized
DEBUG - 2016-05-20 14:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:38:11 --> CSRF cookie sent
INFO - 2016-05-20 14:38:11 --> Input Class Initialized
INFO - 2016-05-20 14:38:11 --> Language Class Initialized
ERROR - 2016-05-20 14:38:11 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:38:21 --> Config Class Initialized
INFO - 2016-05-20 14:38:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:38:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:38:21 --> Utf8 Class Initialized
INFO - 2016-05-20 14:38:21 --> URI Class Initialized
INFO - 2016-05-20 14:38:21 --> Router Class Initialized
INFO - 2016-05-20 14:38:21 --> Output Class Initialized
INFO - 2016-05-20 14:38:21 --> Security Class Initialized
DEBUG - 2016-05-20 14:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:38:21 --> CSRF cookie sent
INFO - 2016-05-20 14:38:21 --> Input Class Initialized
INFO - 2016-05-20 14:38:21 --> Language Class Initialized
INFO - 2016-05-20 14:38:21 --> Loader Class Initialized
INFO - 2016-05-20 14:38:21 --> Helper loaded: form_helper
INFO - 2016-05-20 14:38:21 --> Database Driver Class Initialized
INFO - 2016-05-20 14:38:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:38:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:38:21 --> Email Class Initialized
INFO - 2016-05-20 14:38:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:38:21 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:38:21 --> Helper loaded: language_helper
INFO - 2016-05-20 14:38:21 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:38:21 --> Model Class Initialized
INFO - 2016-05-20 14:38:21 --> Helper loaded: date_helper
INFO - 2016-05-20 14:38:21 --> Controller Class Initialized
INFO - 2016-05-20 14:38:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:38:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:38:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:38:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:38:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:38:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:38:21 --> Form Validation Class Initialized
INFO - 2016-05-20 14:38:21 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:38:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:38:21 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:38:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:38:21 --> Final output sent to browser
DEBUG - 2016-05-20 14:38:21 --> Total execution time: 0.0368
INFO - 2016-05-20 14:38:21 --> Config Class Initialized
INFO - 2016-05-20 14:38:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:38:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:38:21 --> Utf8 Class Initialized
INFO - 2016-05-20 14:38:21 --> URI Class Initialized
INFO - 2016-05-20 14:38:21 --> Router Class Initialized
INFO - 2016-05-20 14:38:21 --> Output Class Initialized
INFO - 2016-05-20 14:38:21 --> Security Class Initialized
DEBUG - 2016-05-20 14:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:38:21 --> CSRF cookie sent
INFO - 2016-05-20 14:38:21 --> Input Class Initialized
INFO - 2016-05-20 14:38:21 --> Language Class Initialized
ERROR - 2016-05-20 14:38:21 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:38:30 --> Config Class Initialized
INFO - 2016-05-20 14:38:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:38:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:38:30 --> Utf8 Class Initialized
INFO - 2016-05-20 14:38:30 --> URI Class Initialized
INFO - 2016-05-20 14:38:30 --> Router Class Initialized
INFO - 2016-05-20 14:38:30 --> Output Class Initialized
INFO - 2016-05-20 14:38:30 --> Security Class Initialized
DEBUG - 2016-05-20 14:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:38:30 --> CSRF cookie sent
INFO - 2016-05-20 14:38:30 --> Input Class Initialized
INFO - 2016-05-20 14:38:30 --> Language Class Initialized
INFO - 2016-05-20 14:38:30 --> Loader Class Initialized
INFO - 2016-05-20 14:38:30 --> Helper loaded: form_helper
INFO - 2016-05-20 14:38:30 --> Database Driver Class Initialized
INFO - 2016-05-20 14:38:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:38:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:38:30 --> Email Class Initialized
INFO - 2016-05-20 14:38:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:38:30 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:38:30 --> Helper loaded: language_helper
INFO - 2016-05-20 14:38:30 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:38:30 --> Model Class Initialized
INFO - 2016-05-20 14:38:30 --> Helper loaded: date_helper
INFO - 2016-05-20 14:38:30 --> Controller Class Initialized
INFO - 2016-05-20 14:38:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:38:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:38:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:38:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:38:30 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:38:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:38:30 --> Form Validation Class Initialized
INFO - 2016-05-20 14:38:30 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:38:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:38:30 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:38:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:38:30 --> Final output sent to browser
DEBUG - 2016-05-20 14:38:30 --> Total execution time: 0.0655
INFO - 2016-05-20 14:38:31 --> Config Class Initialized
INFO - 2016-05-20 14:38:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:38:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:38:31 --> Utf8 Class Initialized
INFO - 2016-05-20 14:38:31 --> URI Class Initialized
INFO - 2016-05-20 14:38:31 --> Router Class Initialized
INFO - 2016-05-20 14:38:31 --> Output Class Initialized
INFO - 2016-05-20 14:38:31 --> Security Class Initialized
DEBUG - 2016-05-20 14:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:38:31 --> CSRF cookie sent
INFO - 2016-05-20 14:38:31 --> Input Class Initialized
INFO - 2016-05-20 14:38:31 --> Language Class Initialized
ERROR - 2016-05-20 14:38:31 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:40:09 --> Config Class Initialized
INFO - 2016-05-20 14:40:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:40:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:40:09 --> Utf8 Class Initialized
INFO - 2016-05-20 14:40:09 --> URI Class Initialized
INFO - 2016-05-20 14:40:09 --> Router Class Initialized
INFO - 2016-05-20 14:40:09 --> Output Class Initialized
INFO - 2016-05-20 14:40:09 --> Security Class Initialized
DEBUG - 2016-05-20 14:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:40:09 --> CSRF cookie sent
INFO - 2016-05-20 14:40:09 --> Input Class Initialized
INFO - 2016-05-20 14:40:09 --> Language Class Initialized
INFO - 2016-05-20 14:40:09 --> Loader Class Initialized
INFO - 2016-05-20 14:40:09 --> Helper loaded: form_helper
INFO - 2016-05-20 14:40:09 --> Database Driver Class Initialized
INFO - 2016-05-20 14:40:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:40:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:40:09 --> Email Class Initialized
INFO - 2016-05-20 14:40:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:40:09 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:40:09 --> Helper loaded: language_helper
INFO - 2016-05-20 14:40:09 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:40:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:40:09 --> Model Class Initialized
INFO - 2016-05-20 14:40:09 --> Helper loaded: date_helper
INFO - 2016-05-20 14:40:09 --> Controller Class Initialized
INFO - 2016-05-20 14:40:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:40:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:40:09 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:40:09 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:40:09 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:40:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:40:09 --> Form Validation Class Initialized
INFO - 2016-05-20 14:40:09 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:40:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:40:09 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:40:09 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:40:09 --> Final output sent to browser
DEBUG - 2016-05-20 14:40:09 --> Total execution time: 0.0481
INFO - 2016-05-20 14:40:10 --> Config Class Initialized
INFO - 2016-05-20 14:40:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:40:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:40:10 --> Utf8 Class Initialized
INFO - 2016-05-20 14:40:10 --> URI Class Initialized
INFO - 2016-05-20 14:40:10 --> Router Class Initialized
INFO - 2016-05-20 14:40:10 --> Output Class Initialized
INFO - 2016-05-20 14:40:10 --> Security Class Initialized
DEBUG - 2016-05-20 14:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:40:10 --> CSRF cookie sent
INFO - 2016-05-20 14:40:10 --> Input Class Initialized
INFO - 2016-05-20 14:40:10 --> Language Class Initialized
ERROR - 2016-05-20 14:40:10 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:40:22 --> Config Class Initialized
INFO - 2016-05-20 14:40:22 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:40:22 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:40:22 --> Utf8 Class Initialized
INFO - 2016-05-20 14:40:22 --> URI Class Initialized
INFO - 2016-05-20 14:40:22 --> Router Class Initialized
INFO - 2016-05-20 14:40:22 --> Output Class Initialized
INFO - 2016-05-20 14:40:22 --> Security Class Initialized
DEBUG - 2016-05-20 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:40:22 --> CSRF cookie sent
INFO - 2016-05-20 14:40:22 --> Input Class Initialized
INFO - 2016-05-20 14:40:22 --> Language Class Initialized
INFO - 2016-05-20 14:40:22 --> Loader Class Initialized
INFO - 2016-05-20 14:40:22 --> Helper loaded: form_helper
INFO - 2016-05-20 14:40:22 --> Database Driver Class Initialized
INFO - 2016-05-20 14:40:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:40:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:40:22 --> Email Class Initialized
INFO - 2016-05-20 14:40:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:40:22 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:40:22 --> Helper loaded: language_helper
INFO - 2016-05-20 14:40:22 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:40:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:40:22 --> Model Class Initialized
INFO - 2016-05-20 14:40:22 --> Helper loaded: date_helper
INFO - 2016-05-20 14:40:22 --> Controller Class Initialized
INFO - 2016-05-20 14:40:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:40:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:40:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:40:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:40:22 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:40:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:40:22 --> Form Validation Class Initialized
INFO - 2016-05-20 14:40:22 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:40:22 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:40:22 --> Final output sent to browser
DEBUG - 2016-05-20 14:40:22 --> Total execution time: 0.0445
INFO - 2016-05-20 14:40:22 --> Config Class Initialized
INFO - 2016-05-20 14:40:22 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:40:22 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:40:22 --> Utf8 Class Initialized
INFO - 2016-05-20 14:40:22 --> URI Class Initialized
INFO - 2016-05-20 14:40:22 --> Router Class Initialized
INFO - 2016-05-20 14:40:22 --> Output Class Initialized
INFO - 2016-05-20 14:40:22 --> Security Class Initialized
DEBUG - 2016-05-20 14:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:40:22 --> CSRF cookie sent
INFO - 2016-05-20 14:40:22 --> Input Class Initialized
INFO - 2016-05-20 14:40:22 --> Language Class Initialized
ERROR - 2016-05-20 14:40:22 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:40:46 --> Config Class Initialized
INFO - 2016-05-20 14:40:46 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:40:46 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:40:46 --> Utf8 Class Initialized
INFO - 2016-05-20 14:40:46 --> URI Class Initialized
INFO - 2016-05-20 14:40:46 --> Router Class Initialized
INFO - 2016-05-20 14:40:46 --> Output Class Initialized
INFO - 2016-05-20 14:40:46 --> Security Class Initialized
DEBUG - 2016-05-20 14:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:40:46 --> CSRF cookie sent
INFO - 2016-05-20 14:40:46 --> Input Class Initialized
INFO - 2016-05-20 14:40:46 --> Language Class Initialized
INFO - 2016-05-20 14:40:46 --> Loader Class Initialized
INFO - 2016-05-20 14:40:46 --> Helper loaded: form_helper
INFO - 2016-05-20 14:40:46 --> Database Driver Class Initialized
INFO - 2016-05-20 14:40:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:40:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:40:46 --> Email Class Initialized
INFO - 2016-05-20 14:40:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:40:46 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:40:46 --> Helper loaded: language_helper
INFO - 2016-05-20 14:40:46 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:40:46 --> Model Class Initialized
INFO - 2016-05-20 14:40:46 --> Helper loaded: date_helper
INFO - 2016-05-20 14:40:46 --> Controller Class Initialized
INFO - 2016-05-20 14:40:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:40:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:40:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:40:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:40:46 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:40:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:40:46 --> Form Validation Class Initialized
INFO - 2016-05-20 14:40:46 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:40:46 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:40:46 --> Final output sent to browser
DEBUG - 2016-05-20 14:40:46 --> Total execution time: 0.0142
INFO - 2016-05-20 14:40:47 --> Config Class Initialized
INFO - 2016-05-20 14:40:47 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:40:47 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:40:47 --> Utf8 Class Initialized
INFO - 2016-05-20 14:40:47 --> URI Class Initialized
INFO - 2016-05-20 14:40:47 --> Router Class Initialized
INFO - 2016-05-20 14:40:47 --> Output Class Initialized
INFO - 2016-05-20 14:40:47 --> Security Class Initialized
DEBUG - 2016-05-20 14:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:40:47 --> CSRF cookie sent
INFO - 2016-05-20 14:40:47 --> Input Class Initialized
INFO - 2016-05-20 14:40:47 --> Language Class Initialized
ERROR - 2016-05-20 14:40:47 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:41:03 --> Config Class Initialized
INFO - 2016-05-20 14:41:03 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:41:03 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:41:03 --> Utf8 Class Initialized
INFO - 2016-05-20 14:41:03 --> URI Class Initialized
INFO - 2016-05-20 14:41:03 --> Router Class Initialized
INFO - 2016-05-20 14:41:03 --> Output Class Initialized
INFO - 2016-05-20 14:41:03 --> Security Class Initialized
DEBUG - 2016-05-20 14:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:41:03 --> CSRF cookie sent
INFO - 2016-05-20 14:41:03 --> Input Class Initialized
INFO - 2016-05-20 14:41:03 --> Language Class Initialized
ERROR - 2016-05-20 14:41:03 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:42:15 --> Config Class Initialized
INFO - 2016-05-20 14:42:15 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:42:15 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:42:15 --> Utf8 Class Initialized
INFO - 2016-05-20 14:42:15 --> URI Class Initialized
INFO - 2016-05-20 14:42:15 --> Router Class Initialized
INFO - 2016-05-20 14:42:15 --> Output Class Initialized
INFO - 2016-05-20 14:42:15 --> Security Class Initialized
DEBUG - 2016-05-20 14:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:42:15 --> CSRF cookie sent
INFO - 2016-05-20 14:42:15 --> Input Class Initialized
INFO - 2016-05-20 14:42:15 --> Language Class Initialized
INFO - 2016-05-20 14:42:15 --> Loader Class Initialized
INFO - 2016-05-20 14:42:15 --> Helper loaded: form_helper
INFO - 2016-05-20 14:42:15 --> Database Driver Class Initialized
INFO - 2016-05-20 14:42:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:42:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:42:15 --> Email Class Initialized
INFO - 2016-05-20 14:42:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:42:15 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:42:15 --> Helper loaded: language_helper
INFO - 2016-05-20 14:42:15 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:42:15 --> Model Class Initialized
INFO - 2016-05-20 14:42:15 --> Helper loaded: date_helper
INFO - 2016-05-20 14:42:15 --> Controller Class Initialized
INFO - 2016-05-20 14:42:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:42:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:42:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:42:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:42:15 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:42:15 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:42:15 --> Form Validation Class Initialized
INFO - 2016-05-20 14:42:15 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:42:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:42:15 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:42:15 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:42:15 --> Final output sent to browser
DEBUG - 2016-05-20 14:42:15 --> Total execution time: 0.0624
INFO - 2016-05-20 14:42:16 --> Config Class Initialized
INFO - 2016-05-20 14:42:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:42:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:42:16 --> Utf8 Class Initialized
INFO - 2016-05-20 14:42:16 --> URI Class Initialized
INFO - 2016-05-20 14:42:16 --> Router Class Initialized
INFO - 2016-05-20 14:42:16 --> Output Class Initialized
INFO - 2016-05-20 14:42:16 --> Security Class Initialized
DEBUG - 2016-05-20 14:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:42:16 --> CSRF cookie sent
INFO - 2016-05-20 14:42:16 --> Input Class Initialized
INFO - 2016-05-20 14:42:16 --> Language Class Initialized
ERROR - 2016-05-20 14:42:16 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:42:20 --> Config Class Initialized
INFO - 2016-05-20 14:42:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:42:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:42:20 --> Utf8 Class Initialized
INFO - 2016-05-20 14:42:20 --> URI Class Initialized
INFO - 2016-05-20 14:42:20 --> Router Class Initialized
INFO - 2016-05-20 14:42:20 --> Output Class Initialized
INFO - 2016-05-20 14:42:20 --> Security Class Initialized
DEBUG - 2016-05-20 14:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:42:20 --> CSRF cookie sent
INFO - 2016-05-20 14:42:20 --> Input Class Initialized
INFO - 2016-05-20 14:42:20 --> Language Class Initialized
ERROR - 2016-05-20 14:42:20 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:42:34 --> Config Class Initialized
INFO - 2016-05-20 14:42:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:42:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:42:34 --> Utf8 Class Initialized
INFO - 2016-05-20 14:42:34 --> URI Class Initialized
INFO - 2016-05-20 14:42:34 --> Router Class Initialized
INFO - 2016-05-20 14:42:34 --> Output Class Initialized
INFO - 2016-05-20 14:42:34 --> Security Class Initialized
DEBUG - 2016-05-20 14:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:42:34 --> CSRF cookie sent
INFO - 2016-05-20 14:42:34 --> Input Class Initialized
INFO - 2016-05-20 14:42:34 --> Language Class Initialized
INFO - 2016-05-20 14:42:34 --> Loader Class Initialized
INFO - 2016-05-20 14:42:34 --> Helper loaded: form_helper
INFO - 2016-05-20 14:42:34 --> Database Driver Class Initialized
INFO - 2016-05-20 14:42:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:42:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:42:34 --> Email Class Initialized
INFO - 2016-05-20 14:42:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:42:34 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:42:34 --> Helper loaded: language_helper
INFO - 2016-05-20 14:42:34 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:42:34 --> Model Class Initialized
INFO - 2016-05-20 14:42:34 --> Helper loaded: date_helper
INFO - 2016-05-20 14:42:34 --> Controller Class Initialized
INFO - 2016-05-20 14:42:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:42:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:42:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:42:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:42:34 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:42:34 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:42:34 --> Form Validation Class Initialized
INFO - 2016-05-20 14:42:34 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:42:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:42:34 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:42:34 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:42:34 --> Final output sent to browser
DEBUG - 2016-05-20 14:42:34 --> Total execution time: 0.0353
INFO - 2016-05-20 14:42:34 --> Config Class Initialized
INFO - 2016-05-20 14:42:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:42:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:42:34 --> Utf8 Class Initialized
INFO - 2016-05-20 14:42:34 --> URI Class Initialized
INFO - 2016-05-20 14:42:34 --> Router Class Initialized
INFO - 2016-05-20 14:42:34 --> Output Class Initialized
INFO - 2016-05-20 14:42:34 --> Security Class Initialized
DEBUG - 2016-05-20 14:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:42:34 --> CSRF cookie sent
INFO - 2016-05-20 14:42:34 --> Input Class Initialized
INFO - 2016-05-20 14:42:34 --> Language Class Initialized
ERROR - 2016-05-20 14:42:34 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:42:38 --> Config Class Initialized
INFO - 2016-05-20 14:42:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:42:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:42:38 --> Utf8 Class Initialized
INFO - 2016-05-20 14:42:38 --> URI Class Initialized
INFO - 2016-05-20 14:42:38 --> Router Class Initialized
INFO - 2016-05-20 14:42:38 --> Output Class Initialized
INFO - 2016-05-20 14:42:38 --> Security Class Initialized
DEBUG - 2016-05-20 14:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:42:38 --> CSRF cookie sent
INFO - 2016-05-20 14:42:38 --> Input Class Initialized
INFO - 2016-05-20 14:42:38 --> Language Class Initialized
ERROR - 2016-05-20 14:42:38 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:43:10 --> Config Class Initialized
INFO - 2016-05-20 14:43:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:43:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:43:10 --> Utf8 Class Initialized
INFO - 2016-05-20 14:43:10 --> URI Class Initialized
INFO - 2016-05-20 14:43:10 --> Router Class Initialized
INFO - 2016-05-20 14:43:10 --> Output Class Initialized
INFO - 2016-05-20 14:43:10 --> Security Class Initialized
DEBUG - 2016-05-20 14:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:43:10 --> CSRF cookie sent
INFO - 2016-05-20 14:43:10 --> Input Class Initialized
INFO - 2016-05-20 14:43:10 --> Language Class Initialized
INFO - 2016-05-20 14:43:10 --> Loader Class Initialized
INFO - 2016-05-20 14:43:10 --> Helper loaded: form_helper
INFO - 2016-05-20 14:43:10 --> Database Driver Class Initialized
INFO - 2016-05-20 14:43:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:43:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:43:10 --> Email Class Initialized
INFO - 2016-05-20 14:43:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:43:10 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:43:10 --> Helper loaded: language_helper
INFO - 2016-05-20 14:43:10 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:43:10 --> Model Class Initialized
INFO - 2016-05-20 14:43:10 --> Helper loaded: date_helper
INFO - 2016-05-20 14:43:10 --> Controller Class Initialized
INFO - 2016-05-20 14:43:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:43:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:43:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:43:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:43:10 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:43:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:43:10 --> Form Validation Class Initialized
INFO - 2016-05-20 14:43:10 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:43:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:43:10 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:43:10 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:43:10 --> Final output sent to browser
DEBUG - 2016-05-20 14:43:10 --> Total execution time: 0.0393
INFO - 2016-05-20 14:43:11 --> Config Class Initialized
INFO - 2016-05-20 14:43:11 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:43:11 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:43:11 --> Utf8 Class Initialized
INFO - 2016-05-20 14:43:11 --> URI Class Initialized
INFO - 2016-05-20 14:43:11 --> Router Class Initialized
INFO - 2016-05-20 14:43:11 --> Output Class Initialized
INFO - 2016-05-20 14:43:11 --> Security Class Initialized
DEBUG - 2016-05-20 14:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:43:11 --> CSRF cookie sent
INFO - 2016-05-20 14:43:11 --> Input Class Initialized
INFO - 2016-05-20 14:43:11 --> Language Class Initialized
ERROR - 2016-05-20 14:43:11 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:43:16 --> Config Class Initialized
INFO - 2016-05-20 14:43:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:43:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:43:16 --> Utf8 Class Initialized
INFO - 2016-05-20 14:43:16 --> URI Class Initialized
INFO - 2016-05-20 14:43:16 --> Router Class Initialized
INFO - 2016-05-20 14:43:16 --> Output Class Initialized
INFO - 2016-05-20 14:43:16 --> Security Class Initialized
DEBUG - 2016-05-20 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:43:16 --> CSRF cookie sent
INFO - 2016-05-20 14:43:16 --> Input Class Initialized
INFO - 2016-05-20 14:43:16 --> Language Class Initialized
ERROR - 2016-05-20 14:43:16 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:43:26 --> Config Class Initialized
INFO - 2016-05-20 14:43:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:43:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:43:26 --> Utf8 Class Initialized
INFO - 2016-05-20 14:43:26 --> URI Class Initialized
INFO - 2016-05-20 14:43:26 --> Router Class Initialized
INFO - 2016-05-20 14:43:26 --> Output Class Initialized
INFO - 2016-05-20 14:43:26 --> Security Class Initialized
DEBUG - 2016-05-20 14:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:43:26 --> CSRF cookie sent
INFO - 2016-05-20 14:43:26 --> Input Class Initialized
INFO - 2016-05-20 14:43:26 --> Language Class Initialized
INFO - 2016-05-20 14:43:26 --> Loader Class Initialized
INFO - 2016-05-20 14:43:26 --> Helper loaded: form_helper
INFO - 2016-05-20 14:43:26 --> Database Driver Class Initialized
INFO - 2016-05-20 14:43:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:43:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:43:26 --> Email Class Initialized
INFO - 2016-05-20 14:43:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:43:26 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:43:26 --> Helper loaded: language_helper
INFO - 2016-05-20 14:43:26 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:43:26 --> Model Class Initialized
INFO - 2016-05-20 14:43:26 --> Helper loaded: date_helper
INFO - 2016-05-20 14:43:26 --> Controller Class Initialized
INFO - 2016-05-20 14:43:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:43:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:43:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:43:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:43:26 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:43:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:43:26 --> Form Validation Class Initialized
INFO - 2016-05-20 14:43:26 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:43:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:43:26 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:43:26 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:43:26 --> Final output sent to browser
DEBUG - 2016-05-20 14:43:26 --> Total execution time: 0.0137
INFO - 2016-05-20 14:43:28 --> Config Class Initialized
INFO - 2016-05-20 14:43:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:43:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:43:28 --> Utf8 Class Initialized
INFO - 2016-05-20 14:43:28 --> URI Class Initialized
INFO - 2016-05-20 14:43:28 --> Router Class Initialized
INFO - 2016-05-20 14:43:28 --> Output Class Initialized
INFO - 2016-05-20 14:43:28 --> Security Class Initialized
DEBUG - 2016-05-20 14:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:43:28 --> CSRF cookie sent
INFO - 2016-05-20 14:43:28 --> Input Class Initialized
INFO - 2016-05-20 14:43:28 --> Language Class Initialized
ERROR - 2016-05-20 14:43:28 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:44:17 --> Config Class Initialized
INFO - 2016-05-20 14:44:17 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:44:17 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:44:17 --> Utf8 Class Initialized
INFO - 2016-05-20 14:44:17 --> URI Class Initialized
INFO - 2016-05-20 14:44:17 --> Router Class Initialized
INFO - 2016-05-20 14:44:17 --> Output Class Initialized
INFO - 2016-05-20 14:44:17 --> Security Class Initialized
DEBUG - 2016-05-20 14:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:44:17 --> CSRF cookie sent
INFO - 2016-05-20 14:44:17 --> Input Class Initialized
INFO - 2016-05-20 14:44:17 --> Language Class Initialized
INFO - 2016-05-20 14:44:17 --> Loader Class Initialized
INFO - 2016-05-20 14:44:17 --> Helper loaded: form_helper
INFO - 2016-05-20 14:44:17 --> Database Driver Class Initialized
INFO - 2016-05-20 14:44:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:44:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:44:17 --> Email Class Initialized
INFO - 2016-05-20 14:44:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:44:17 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:44:17 --> Helper loaded: language_helper
INFO - 2016-05-20 14:44:17 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:44:17 --> Model Class Initialized
INFO - 2016-05-20 14:44:17 --> Helper loaded: date_helper
INFO - 2016-05-20 14:44:17 --> Controller Class Initialized
INFO - 2016-05-20 14:44:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:44:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:44:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:44:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:44:17 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:44:17 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:44:17 --> Form Validation Class Initialized
INFO - 2016-05-20 14:44:17 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:44:17 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:44:17 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:44:17 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:44:17 --> Final output sent to browser
DEBUG - 2016-05-20 14:44:17 --> Total execution time: 0.0664
INFO - 2016-05-20 14:44:18 --> Config Class Initialized
INFO - 2016-05-20 14:44:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:44:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:44:18 --> Utf8 Class Initialized
INFO - 2016-05-20 14:44:18 --> URI Class Initialized
INFO - 2016-05-20 14:44:18 --> Router Class Initialized
INFO - 2016-05-20 14:44:18 --> Output Class Initialized
INFO - 2016-05-20 14:44:18 --> Security Class Initialized
DEBUG - 2016-05-20 14:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:44:18 --> CSRF cookie sent
INFO - 2016-05-20 14:44:18 --> Input Class Initialized
INFO - 2016-05-20 14:44:18 --> Language Class Initialized
ERROR - 2016-05-20 14:44:18 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:44:38 --> Config Class Initialized
INFO - 2016-05-20 14:44:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:44:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:44:38 --> Utf8 Class Initialized
INFO - 2016-05-20 14:44:38 --> URI Class Initialized
INFO - 2016-05-20 14:44:38 --> Router Class Initialized
INFO - 2016-05-20 14:44:38 --> Output Class Initialized
INFO - 2016-05-20 14:44:38 --> Security Class Initialized
DEBUG - 2016-05-20 14:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:44:38 --> CSRF cookie sent
INFO - 2016-05-20 14:44:38 --> Input Class Initialized
INFO - 2016-05-20 14:44:38 --> Language Class Initialized
ERROR - 2016-05-20 14:44:38 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:45:14 --> Config Class Initialized
INFO - 2016-05-20 14:45:14 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:14 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:14 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:14 --> URI Class Initialized
INFO - 2016-05-20 14:45:14 --> Router Class Initialized
INFO - 2016-05-20 14:45:14 --> Output Class Initialized
INFO - 2016-05-20 14:45:14 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:14 --> CSRF cookie sent
INFO - 2016-05-20 14:45:14 --> Input Class Initialized
INFO - 2016-05-20 14:45:14 --> Language Class Initialized
INFO - 2016-05-20 14:45:14 --> Loader Class Initialized
INFO - 2016-05-20 14:45:14 --> Helper loaded: form_helper
INFO - 2016-05-20 14:45:14 --> Database Driver Class Initialized
INFO - 2016-05-20 14:45:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:45:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:45:14 --> Email Class Initialized
INFO - 2016-05-20 14:45:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:45:14 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:45:14 --> Helper loaded: language_helper
INFO - 2016-05-20 14:45:14 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:14 --> Model Class Initialized
INFO - 2016-05-20 14:45:14 --> Helper loaded: date_helper
INFO - 2016-05-20 14:45:14 --> Controller Class Initialized
INFO - 2016-05-20 14:45:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:45:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:45:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:45:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:45:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:45:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:14 --> Form Validation Class Initialized
INFO - 2016-05-20 14:45:14 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:45:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:45:14 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:45:14 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:45:14 --> Final output sent to browser
DEBUG - 2016-05-20 14:45:14 --> Total execution time: 0.0525
INFO - 2016-05-20 14:45:15 --> Config Class Initialized
INFO - 2016-05-20 14:45:15 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:15 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:15 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:15 --> URI Class Initialized
INFO - 2016-05-20 14:45:15 --> Router Class Initialized
INFO - 2016-05-20 14:45:15 --> Output Class Initialized
INFO - 2016-05-20 14:45:15 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:15 --> CSRF cookie sent
INFO - 2016-05-20 14:45:15 --> Input Class Initialized
INFO - 2016-05-20 14:45:15 --> Language Class Initialized
ERROR - 2016-05-20 14:45:15 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:45:21 --> Config Class Initialized
INFO - 2016-05-20 14:45:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:21 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:21 --> URI Class Initialized
INFO - 2016-05-20 14:45:21 --> Router Class Initialized
INFO - 2016-05-20 14:45:21 --> Output Class Initialized
INFO - 2016-05-20 14:45:21 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:21 --> CSRF cookie sent
INFO - 2016-05-20 14:45:21 --> Input Class Initialized
INFO - 2016-05-20 14:45:21 --> Language Class Initialized
INFO - 2016-05-20 14:45:21 --> Loader Class Initialized
INFO - 2016-05-20 14:45:21 --> Helper loaded: form_helper
INFO - 2016-05-20 14:45:21 --> Database Driver Class Initialized
INFO - 2016-05-20 14:45:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:45:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:45:21 --> Email Class Initialized
INFO - 2016-05-20 14:45:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:45:21 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:45:21 --> Helper loaded: language_helper
INFO - 2016-05-20 14:45:21 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:21 --> Model Class Initialized
INFO - 2016-05-20 14:45:21 --> Helper loaded: date_helper
INFO - 2016-05-20 14:45:21 --> Controller Class Initialized
INFO - 2016-05-20 14:45:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:45:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:45:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:45:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:45:21 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:45:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:21 --> Form Validation Class Initialized
INFO - 2016-05-20 14:45:21 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:45:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:45:21 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/create_user.php
INFO - 2016-05-20 14:45:21 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:45:21 --> Final output sent to browser
DEBUG - 2016-05-20 14:45:21 --> Total execution time: 0.0419
INFO - 2016-05-20 14:45:22 --> Config Class Initialized
INFO - 2016-05-20 14:45:22 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:22 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:22 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:22 --> URI Class Initialized
INFO - 2016-05-20 14:45:22 --> Router Class Initialized
INFO - 2016-05-20 14:45:22 --> Output Class Initialized
INFO - 2016-05-20 14:45:22 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:22 --> CSRF cookie sent
INFO - 2016-05-20 14:45:22 --> Input Class Initialized
INFO - 2016-05-20 14:45:22 --> Language Class Initialized
ERROR - 2016-05-20 14:45:22 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:45:29 --> Config Class Initialized
INFO - 2016-05-20 14:45:29 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:29 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:29 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:29 --> URI Class Initialized
INFO - 2016-05-20 14:45:29 --> Router Class Initialized
INFO - 2016-05-20 14:45:29 --> Output Class Initialized
INFO - 2016-05-20 14:45:29 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:29 --> CSRF cookie sent
INFO - 2016-05-20 14:45:29 --> Input Class Initialized
INFO - 2016-05-20 14:45:29 --> Language Class Initialized
INFO - 2016-05-20 14:45:29 --> Loader Class Initialized
INFO - 2016-05-20 14:45:29 --> Helper loaded: form_helper
INFO - 2016-05-20 14:45:29 --> Database Driver Class Initialized
INFO - 2016-05-20 14:45:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:45:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:45:29 --> Email Class Initialized
INFO - 2016-05-20 14:45:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:45:29 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:45:29 --> Helper loaded: language_helper
INFO - 2016-05-20 14:45:29 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:45:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:29 --> Model Class Initialized
INFO - 2016-05-20 14:45:29 --> Helper loaded: date_helper
INFO - 2016-05-20 14:45:29 --> Controller Class Initialized
INFO - 2016-05-20 14:45:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:45:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:45:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:45:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:45:29 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:45:29 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:29 --> Form Validation Class Initialized
INFO - 2016-05-20 14:45:29 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:45:29 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:45:29 --> Final output sent to browser
DEBUG - 2016-05-20 14:45:29 --> Total execution time: 0.0184
INFO - 2016-05-20 14:45:37 --> Config Class Initialized
INFO - 2016-05-20 14:45:37 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:37 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:37 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:37 --> URI Class Initialized
INFO - 2016-05-20 14:45:37 --> Router Class Initialized
INFO - 2016-05-20 14:45:37 --> Output Class Initialized
INFO - 2016-05-20 14:45:37 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:37 --> CSRF cookie sent
INFO - 2016-05-20 14:45:37 --> Input Class Initialized
INFO - 2016-05-20 14:45:37 --> Language Class Initialized
INFO - 2016-05-20 14:45:37 --> Loader Class Initialized
INFO - 2016-05-20 14:45:37 --> Helper loaded: form_helper
INFO - 2016-05-20 14:45:37 --> Database Driver Class Initialized
INFO - 2016-05-20 14:45:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:45:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:45:37 --> Email Class Initialized
INFO - 2016-05-20 14:45:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:45:37 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:45:37 --> Helper loaded: language_helper
INFO - 2016-05-20 14:45:37 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:37 --> Model Class Initialized
INFO - 2016-05-20 14:45:37 --> Helper loaded: date_helper
INFO - 2016-05-20 14:45:37 --> Controller Class Initialized
INFO - 2016-05-20 14:45:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:45:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:45:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:45:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:45:37 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:45:37 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:37 --> Form Validation Class Initialized
INFO - 2016-05-20 14:45:37 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/forgot_password.php
INFO - 2016-05-20 14:45:37 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:45:37 --> Final output sent to browser
DEBUG - 2016-05-20 14:45:37 --> Total execution time: 0.0885
INFO - 2016-05-20 14:45:39 --> Config Class Initialized
INFO - 2016-05-20 14:45:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:39 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:39 --> URI Class Initialized
INFO - 2016-05-20 14:45:39 --> Router Class Initialized
INFO - 2016-05-20 14:45:39 --> Output Class Initialized
INFO - 2016-05-20 14:45:39 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:39 --> CSRF cookie sent
INFO - 2016-05-20 14:45:39 --> Input Class Initialized
INFO - 2016-05-20 14:45:39 --> Language Class Initialized
ERROR - 2016-05-20 14:45:39 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:45:44 --> Config Class Initialized
INFO - 2016-05-20 14:45:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:44 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:44 --> URI Class Initialized
INFO - 2016-05-20 14:45:44 --> Router Class Initialized
INFO - 2016-05-20 14:45:44 --> Output Class Initialized
INFO - 2016-05-20 14:45:44 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:44 --> CSRF cookie sent
INFO - 2016-05-20 14:45:44 --> Input Class Initialized
INFO - 2016-05-20 14:45:44 --> Language Class Initialized
INFO - 2016-05-20 14:45:44 --> Loader Class Initialized
INFO - 2016-05-20 14:45:44 --> Helper loaded: form_helper
INFO - 2016-05-20 14:45:44 --> Database Driver Class Initialized
INFO - 2016-05-20 14:45:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:45:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:45:44 --> Email Class Initialized
INFO - 2016-05-20 14:45:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:45:44 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:45:44 --> Helper loaded: language_helper
INFO - 2016-05-20 14:45:44 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:45:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:44 --> Model Class Initialized
INFO - 2016-05-20 14:45:44 --> Helper loaded: date_helper
INFO - 2016-05-20 14:45:44 --> Controller Class Initialized
INFO - 2016-05-20 14:45:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:45:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:45:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:45:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:45:44 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:45:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:45:44 --> Form Validation Class Initialized
INFO - 2016-05-20 14:45:44 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:45:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:45:44 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:45:44 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:45:44 --> Final output sent to browser
DEBUG - 2016-05-20 14:45:44 --> Total execution time: 0.0234
INFO - 2016-05-20 14:45:59 --> Config Class Initialized
INFO - 2016-05-20 14:45:59 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:45:59 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:45:59 --> Utf8 Class Initialized
INFO - 2016-05-20 14:45:59 --> URI Class Initialized
INFO - 2016-05-20 14:45:59 --> Router Class Initialized
INFO - 2016-05-20 14:45:59 --> Output Class Initialized
INFO - 2016-05-20 14:45:59 --> Security Class Initialized
DEBUG - 2016-05-20 14:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:45:59 --> CSRF cookie sent
INFO - 2016-05-20 14:45:59 --> Input Class Initialized
INFO - 2016-05-20 14:45:59 --> Language Class Initialized
ERROR - 2016-05-20 14:45:59 --> 404 Page Not Found: Public/css
INFO - 2016-05-20 14:46:18 --> Config Class Initialized
INFO - 2016-05-20 14:46:18 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:18 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:18 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:18 --> URI Class Initialized
INFO - 2016-05-20 14:46:18 --> Router Class Initialized
INFO - 2016-05-20 14:46:18 --> Output Class Initialized
INFO - 2016-05-20 14:46:18 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:18 --> CSRF cookie sent
INFO - 2016-05-20 14:46:18 --> Input Class Initialized
INFO - 2016-05-20 14:46:18 --> Language Class Initialized
INFO - 2016-05-20 14:46:18 --> Loader Class Initialized
INFO - 2016-05-20 14:46:18 --> Helper loaded: form_helper
INFO - 2016-05-20 14:46:18 --> Database Driver Class Initialized
INFO - 2016-05-20 14:46:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:46:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:46:18 --> Email Class Initialized
INFO - 2016-05-20 14:46:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:46:18 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:46:18 --> Helper loaded: language_helper
INFO - 2016-05-20 14:46:18 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:46:18 --> Model Class Initialized
INFO - 2016-05-20 14:46:18 --> Helper loaded: date_helper
INFO - 2016-05-20 14:46:18 --> Controller Class Initialized
INFO - 2016-05-20 14:46:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:46:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:46:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:46:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:46:18 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:46:18 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:46:18 --> Form Validation Class Initialized
INFO - 2016-05-20 14:46:18 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:46:18 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:46:18 --> Final output sent to browser
DEBUG - 2016-05-20 14:46:18 --> Total execution time: 0.0503
INFO - 2016-05-20 14:46:19 --> Config Class Initialized
INFO - 2016-05-20 14:46:19 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:19 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:19 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:19 --> URI Class Initialized
INFO - 2016-05-20 14:46:19 --> Router Class Initialized
INFO - 2016-05-20 14:46:19 --> Output Class Initialized
INFO - 2016-05-20 14:46:19 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:19 --> CSRF cookie sent
INFO - 2016-05-20 14:46:19 --> Input Class Initialized
INFO - 2016-05-20 14:46:19 --> Language Class Initialized
ERROR - 2016-05-20 14:46:19 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:46:30 --> Config Class Initialized
INFO - 2016-05-20 14:46:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:30 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:30 --> URI Class Initialized
DEBUG - 2016-05-20 14:46:30 --> No URI present. Default controller set.
INFO - 2016-05-20 14:46:30 --> Router Class Initialized
INFO - 2016-05-20 14:46:30 --> Output Class Initialized
INFO - 2016-05-20 14:46:30 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:30 --> CSRF cookie sent
INFO - 2016-05-20 14:46:30 --> Input Class Initialized
INFO - 2016-05-20 14:46:30 --> Language Class Initialized
INFO - 2016-05-20 14:46:30 --> Loader Class Initialized
INFO - 2016-05-20 14:46:30 --> Helper loaded: form_helper
INFO - 2016-05-20 14:46:30 --> Database Driver Class Initialized
INFO - 2016-05-20 14:46:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:46:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:46:30 --> Email Class Initialized
INFO - 2016-05-20 14:46:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:46:30 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:46:30 --> Helper loaded: language_helper
INFO - 2016-05-20 14:46:30 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:46:30 --> Model Class Initialized
INFO - 2016-05-20 14:46:30 --> Helper loaded: date_helper
INFO - 2016-05-20 14:46:30 --> Controller Class Initialized
INFO - 2016-05-20 14:46:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:46:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:46:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:46:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:46:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:46:30 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:46:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:46:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:46:30 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:46:30 --> Final output sent to browser
DEBUG - 2016-05-20 14:46:30 --> Total execution time: 0.0633
INFO - 2016-05-20 14:46:32 --> Config Class Initialized
INFO - 2016-05-20 14:46:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:32 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:32 --> URI Class Initialized
INFO - 2016-05-20 14:46:32 --> Router Class Initialized
INFO - 2016-05-20 14:46:32 --> Output Class Initialized
INFO - 2016-05-20 14:46:32 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:32 --> CSRF cookie sent
INFO - 2016-05-20 14:46:32 --> Input Class Initialized
INFO - 2016-05-20 14:46:32 --> Language Class Initialized
ERROR - 2016-05-20 14:46:32 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:46:48 --> Config Class Initialized
INFO - 2016-05-20 14:46:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:48 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:48 --> URI Class Initialized
INFO - 2016-05-20 14:46:48 --> Router Class Initialized
INFO - 2016-05-20 14:46:48 --> Output Class Initialized
INFO - 2016-05-20 14:46:48 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:48 --> CSRF cookie sent
INFO - 2016-05-20 14:46:48 --> CSRF token verified
INFO - 2016-05-20 14:46:48 --> Input Class Initialized
INFO - 2016-05-20 14:46:48 --> Language Class Initialized
INFO - 2016-05-20 14:46:48 --> Loader Class Initialized
INFO - 2016-05-20 14:46:48 --> Helper loaded: form_helper
INFO - 2016-05-20 14:46:48 --> Database Driver Class Initialized
INFO - 2016-05-20 14:46:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:46:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:46:48 --> Email Class Initialized
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:46:48 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:46:48 --> Helper loaded: language_helper
INFO - 2016-05-20 14:46:48 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:46:48 --> Model Class Initialized
INFO - 2016-05-20 14:46:48 --> Helper loaded: date_helper
INFO - 2016-05-20 14:46:48 --> Controller Class Initialized
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:46:48 --> Config Class Initialized
INFO - 2016-05-20 14:46:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:48 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:48 --> URI Class Initialized
DEBUG - 2016-05-20 14:46:48 --> No URI present. Default controller set.
INFO - 2016-05-20 14:46:48 --> Router Class Initialized
INFO - 2016-05-20 14:46:48 --> Output Class Initialized
INFO - 2016-05-20 14:46:48 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:48 --> CSRF cookie sent
INFO - 2016-05-20 14:46:48 --> Input Class Initialized
INFO - 2016-05-20 14:46:48 --> Language Class Initialized
INFO - 2016-05-20 14:46:48 --> Loader Class Initialized
INFO - 2016-05-20 14:46:48 --> Helper loaded: form_helper
INFO - 2016-05-20 14:46:48 --> Database Driver Class Initialized
INFO - 2016-05-20 14:46:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:46:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:46:48 --> Email Class Initialized
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:46:48 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:46:48 --> Helper loaded: language_helper
INFO - 2016-05-20 14:46:48 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:46:48 --> Model Class Initialized
INFO - 2016-05-20 14:46:48 --> Helper loaded: date_helper
INFO - 2016-05-20 14:46:48 --> Controller Class Initialized
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:46:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:46:48 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:46:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:46:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 14:46:48 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:46:48 --> Final output sent to browser
DEBUG - 2016-05-20 14:46:48 --> Total execution time: 0.0233
INFO - 2016-05-20 14:46:49 --> Config Class Initialized
INFO - 2016-05-20 14:46:49 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:49 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:49 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:49 --> URI Class Initialized
INFO - 2016-05-20 14:46:49 --> Router Class Initialized
INFO - 2016-05-20 14:46:49 --> Output Class Initialized
INFO - 2016-05-20 14:46:49 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:49 --> CSRF cookie sent
INFO - 2016-05-20 14:46:49 --> Input Class Initialized
INFO - 2016-05-20 14:46:49 --> Language Class Initialized
ERROR - 2016-05-20 14:46:49 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:46:56 --> Config Class Initialized
INFO - 2016-05-20 14:46:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:56 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:56 --> URI Class Initialized
INFO - 2016-05-20 14:46:56 --> Router Class Initialized
INFO - 2016-05-20 14:46:56 --> Output Class Initialized
INFO - 2016-05-20 14:46:56 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:56 --> CSRF cookie sent
INFO - 2016-05-20 14:46:56 --> Input Class Initialized
INFO - 2016-05-20 14:46:56 --> Language Class Initialized
INFO - 2016-05-20 14:46:56 --> Loader Class Initialized
INFO - 2016-05-20 14:46:56 --> Helper loaded: form_helper
INFO - 2016-05-20 14:46:56 --> Database Driver Class Initialized
INFO - 2016-05-20 14:46:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:46:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:46:56 --> Email Class Initialized
INFO - 2016-05-20 14:46:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:46:56 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:46:56 --> Helper loaded: language_helper
INFO - 2016-05-20 14:46:56 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:46:56 --> Model Class Initialized
INFO - 2016-05-20 14:46:56 --> Helper loaded: date_helper
INFO - 2016-05-20 14:46:56 --> Controller Class Initialized
INFO - 2016-05-20 14:46:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:46:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:46:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:46:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:46:56 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:46:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:46:56 --> Form Validation Class Initialized
INFO - 2016-05-20 14:46:56 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:46:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:46:56 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:46:56 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:46:56 --> Final output sent to browser
DEBUG - 2016-05-20 14:46:56 --> Total execution time: 0.0191
INFO - 2016-05-20 14:46:56 --> Config Class Initialized
INFO - 2016-05-20 14:46:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:46:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:46:56 --> Utf8 Class Initialized
INFO - 2016-05-20 14:46:56 --> URI Class Initialized
INFO - 2016-05-20 14:46:56 --> Router Class Initialized
INFO - 2016-05-20 14:46:56 --> Output Class Initialized
INFO - 2016-05-20 14:46:56 --> Security Class Initialized
DEBUG - 2016-05-20 14:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:46:56 --> CSRF cookie sent
INFO - 2016-05-20 14:46:56 --> Input Class Initialized
INFO - 2016-05-20 14:46:56 --> Language Class Initialized
ERROR - 2016-05-20 14:46:56 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:47:19 --> Config Class Initialized
INFO - 2016-05-20 14:47:19 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:19 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:19 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:19 --> URI Class Initialized
INFO - 2016-05-20 14:47:19 --> Router Class Initialized
INFO - 2016-05-20 14:47:19 --> Output Class Initialized
INFO - 2016-05-20 14:47:19 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:19 --> CSRF cookie sent
INFO - 2016-05-20 14:47:19 --> CSRF token verified
INFO - 2016-05-20 14:47:19 --> Input Class Initialized
INFO - 2016-05-20 14:47:19 --> Language Class Initialized
INFO - 2016-05-20 14:47:19 --> Loader Class Initialized
INFO - 2016-05-20 14:47:19 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:19 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:19 --> Email Class Initialized
INFO - 2016-05-20 14:47:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:19 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:19 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:19 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:19 --> Model Class Initialized
INFO - 2016-05-20 14:47:19 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:19 --> Controller Class Initialized
INFO - 2016-05-20 14:47:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:19 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:47:19 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:19 --> Form Validation Class Initialized
INFO - 2016-05-20 14:47:20 --> Config Class Initialized
INFO - 2016-05-20 14:47:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:20 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:20 --> URI Class Initialized
DEBUG - 2016-05-20 14:47:20 --> No URI present. Default controller set.
INFO - 2016-05-20 14:47:20 --> Router Class Initialized
INFO - 2016-05-20 14:47:20 --> Output Class Initialized
INFO - 2016-05-20 14:47:20 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:20 --> CSRF cookie sent
INFO - 2016-05-20 14:47:20 --> Input Class Initialized
INFO - 2016-05-20 14:47:20 --> Language Class Initialized
INFO - 2016-05-20 14:47:20 --> Loader Class Initialized
INFO - 2016-05-20 14:47:20 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:20 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:20 --> Email Class Initialized
INFO - 2016-05-20 14:47:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:20 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:20 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:20 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:20 --> Model Class Initialized
INFO - 2016-05-20 14:47:20 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:20 --> Controller Class Initialized
INFO - 2016-05-20 14:47:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:47:21 --> Config Class Initialized
INFO - 2016-05-20 14:47:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:21 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:21 --> URI Class Initialized
INFO - 2016-05-20 14:47:21 --> Router Class Initialized
INFO - 2016-05-20 14:47:21 --> Output Class Initialized
INFO - 2016-05-20 14:47:21 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:21 --> CSRF cookie sent
INFO - 2016-05-20 14:47:21 --> Input Class Initialized
INFO - 2016-05-20 14:47:21 --> Language Class Initialized
INFO - 2016-05-20 14:47:21 --> Loader Class Initialized
INFO - 2016-05-20 14:47:21 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:21 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:21 --> Email Class Initialized
INFO - 2016-05-20 14:47:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:21 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:21 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:21 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:21 --> Model Class Initialized
INFO - 2016-05-20 14:47:21 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:21 --> Controller Class Initialized
INFO - 2016-05-20 14:47:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:47:21 --> Model Class Initialized
INFO - 2016-05-20 14:47:21 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:47:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 14:47:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 14:47:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 14:47:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 14:47:21 --> Final output sent to browser
DEBUG - 2016-05-20 14:47:21 --> Total execution time: 0.0504
INFO - 2016-05-20 14:47:28 --> Config Class Initialized
INFO - 2016-05-20 14:47:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:28 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:28 --> URI Class Initialized
INFO - 2016-05-20 14:47:28 --> Router Class Initialized
INFO - 2016-05-20 14:47:28 --> Output Class Initialized
INFO - 2016-05-20 14:47:28 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:28 --> CSRF cookie sent
INFO - 2016-05-20 14:47:28 --> Input Class Initialized
INFO - 2016-05-20 14:47:28 --> Language Class Initialized
INFO - 2016-05-20 14:47:28 --> Loader Class Initialized
INFO - 2016-05-20 14:47:28 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:28 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:28 --> Email Class Initialized
INFO - 2016-05-20 14:47:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:28 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:28 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:28 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:28 --> Model Class Initialized
INFO - 2016-05-20 14:47:28 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:28 --> Controller Class Initialized
INFO - 2016-05-20 14:47:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:28 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:47:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:28 --> Form Validation Class Initialized
INFO - 2016-05-20 14:47:30 --> Config Class Initialized
INFO - 2016-05-20 14:47:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:30 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:30 --> URI Class Initialized
INFO - 2016-05-20 14:47:30 --> Router Class Initialized
INFO - 2016-05-20 14:47:30 --> Output Class Initialized
INFO - 2016-05-20 14:47:30 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:30 --> CSRF cookie sent
INFO - 2016-05-20 14:47:30 --> Input Class Initialized
INFO - 2016-05-20 14:47:30 --> Language Class Initialized
INFO - 2016-05-20 14:47:30 --> Loader Class Initialized
INFO - 2016-05-20 14:47:30 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:30 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:31 --> Email Class Initialized
INFO - 2016-05-20 14:47:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:31 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:31 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:31 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:31 --> Model Class Initialized
INFO - 2016-05-20 14:47:31 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:31 --> Controller Class Initialized
INFO - 2016-05-20 14:47:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:31 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:47:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:31 --> Form Validation Class Initialized
INFO - 2016-05-20 14:47:31 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 14:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 14:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 14:47:31 --> Final output sent to browser
DEBUG - 2016-05-20 14:47:31 --> Total execution time: 0.0232
INFO - 2016-05-20 14:47:31 --> Config Class Initialized
INFO - 2016-05-20 14:47:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:31 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:31 --> URI Class Initialized
INFO - 2016-05-20 14:47:31 --> Router Class Initialized
INFO - 2016-05-20 14:47:31 --> Output Class Initialized
INFO - 2016-05-20 14:47:31 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:31 --> CSRF cookie sent
INFO - 2016-05-20 14:47:31 --> Input Class Initialized
INFO - 2016-05-20 14:47:31 --> Language Class Initialized
ERROR - 2016-05-20 14:47:31 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 14:47:46 --> Config Class Initialized
INFO - 2016-05-20 14:47:46 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:46 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:46 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:46 --> URI Class Initialized
INFO - 2016-05-20 14:47:46 --> Router Class Initialized
INFO - 2016-05-20 14:47:46 --> Output Class Initialized
INFO - 2016-05-20 14:47:46 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:46 --> CSRF cookie sent
INFO - 2016-05-20 14:47:46 --> CSRF token verified
INFO - 2016-05-20 14:47:46 --> Input Class Initialized
INFO - 2016-05-20 14:47:46 --> Language Class Initialized
INFO - 2016-05-20 14:47:46 --> Loader Class Initialized
INFO - 2016-05-20 14:47:46 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:46 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:46 --> Email Class Initialized
INFO - 2016-05-20 14:47:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:46 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:46 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:46 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:46 --> Model Class Initialized
INFO - 2016-05-20 14:47:46 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:46 --> Controller Class Initialized
INFO - 2016-05-20 14:47:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:46 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:47:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:46 --> Form Validation Class Initialized
INFO - 2016-05-20 14:47:47 --> Config Class Initialized
INFO - 2016-05-20 14:47:47 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:47 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:47 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:47 --> URI Class Initialized
DEBUG - 2016-05-20 14:47:47 --> No URI present. Default controller set.
INFO - 2016-05-20 14:47:47 --> Router Class Initialized
INFO - 2016-05-20 14:47:47 --> Output Class Initialized
INFO - 2016-05-20 14:47:47 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:47 --> CSRF cookie sent
INFO - 2016-05-20 14:47:47 --> Input Class Initialized
INFO - 2016-05-20 14:47:47 --> Language Class Initialized
INFO - 2016-05-20 14:47:47 --> Loader Class Initialized
INFO - 2016-05-20 14:47:47 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:47 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:47 --> Email Class Initialized
INFO - 2016-05-20 14:47:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:47 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:47 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:47 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:47 --> Model Class Initialized
INFO - 2016-05-20 14:47:47 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:47 --> Controller Class Initialized
INFO - 2016-05-20 14:47:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:47:48 --> Config Class Initialized
INFO - 2016-05-20 14:47:48 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:47:48 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:47:48 --> Utf8 Class Initialized
INFO - 2016-05-20 14:47:48 --> URI Class Initialized
INFO - 2016-05-20 14:47:48 --> Router Class Initialized
INFO - 2016-05-20 14:47:48 --> Output Class Initialized
INFO - 2016-05-20 14:47:48 --> Security Class Initialized
DEBUG - 2016-05-20 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:47:48 --> CSRF cookie sent
INFO - 2016-05-20 14:47:48 --> Input Class Initialized
INFO - 2016-05-20 14:47:48 --> Language Class Initialized
INFO - 2016-05-20 14:47:48 --> Loader Class Initialized
INFO - 2016-05-20 14:47:48 --> Helper loaded: form_helper
INFO - 2016-05-20 14:47:48 --> Database Driver Class Initialized
INFO - 2016-05-20 14:47:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:47:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:47:48 --> Email Class Initialized
INFO - 2016-05-20 14:47:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:47:48 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:47:48 --> Helper loaded: language_helper
INFO - 2016-05-20 14:47:48 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:47:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:47:48 --> Model Class Initialized
INFO - 2016-05-20 14:47:48 --> Helper loaded: date_helper
INFO - 2016-05-20 14:47:48 --> Controller Class Initialized
INFO - 2016-05-20 14:47:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:47:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:47:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:47:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:47:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:47:48 --> Model Class Initialized
INFO - 2016-05-20 14:47:48 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:47:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 14:47:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 14:47:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 14:47:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 14:47:48 --> Final output sent to browser
DEBUG - 2016-05-20 14:47:48 --> Total execution time: 0.0426
INFO - 2016-05-20 14:48:01 --> Config Class Initialized
INFO - 2016-05-20 14:48:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:48:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:48:01 --> Utf8 Class Initialized
INFO - 2016-05-20 14:48:01 --> URI Class Initialized
INFO - 2016-05-20 14:48:01 --> Router Class Initialized
INFO - 2016-05-20 14:48:01 --> Output Class Initialized
INFO - 2016-05-20 14:48:01 --> Security Class Initialized
DEBUG - 2016-05-20 14:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:48:01 --> CSRF cookie sent
INFO - 2016-05-20 14:48:01 --> Input Class Initialized
INFO - 2016-05-20 14:48:01 --> Language Class Initialized
INFO - 2016-05-20 14:48:01 --> Loader Class Initialized
INFO - 2016-05-20 14:48:01 --> Helper loaded: form_helper
INFO - 2016-05-20 14:48:01 --> Database Driver Class Initialized
INFO - 2016-05-20 14:48:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:48:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:48:01 --> Email Class Initialized
INFO - 2016-05-20 14:48:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:48:01 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:48:01 --> Helper loaded: language_helper
INFO - 2016-05-20 14:48:01 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:48:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:48:01 --> Model Class Initialized
INFO - 2016-05-20 14:48:01 --> Helper loaded: date_helper
INFO - 2016-05-20 14:48:01 --> Controller Class Initialized
INFO - 2016-05-20 14:48:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:48:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:48:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:48:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:48:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:48:01 --> Model Class Initialized
INFO - 2016-05-20 14:48:01 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:48:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 14:48:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 14:48:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 14:48:01 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 14:48:01 --> Final output sent to browser
DEBUG - 2016-05-20 14:48:01 --> Total execution time: 0.0244
INFO - 2016-05-20 14:48:05 --> Config Class Initialized
INFO - 2016-05-20 14:48:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:48:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:48:05 --> Utf8 Class Initialized
INFO - 2016-05-20 14:48:05 --> URI Class Initialized
INFO - 2016-05-20 14:48:05 --> Router Class Initialized
INFO - 2016-05-20 14:48:05 --> Output Class Initialized
INFO - 2016-05-20 14:48:05 --> Security Class Initialized
DEBUG - 2016-05-20 14:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:48:05 --> CSRF cookie sent
INFO - 2016-05-20 14:48:05 --> Input Class Initialized
INFO - 2016-05-20 14:48:05 --> Language Class Initialized
INFO - 2016-05-20 14:48:05 --> Loader Class Initialized
INFO - 2016-05-20 14:48:05 --> Helper loaded: form_helper
INFO - 2016-05-20 14:48:05 --> Database Driver Class Initialized
INFO - 2016-05-20 14:48:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:48:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:48:05 --> Email Class Initialized
INFO - 2016-05-20 14:48:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:48:05 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:48:05 --> Helper loaded: language_helper
INFO - 2016-05-20 14:48:05 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:48:05 --> Model Class Initialized
INFO - 2016-05-20 14:48:05 --> Helper loaded: date_helper
INFO - 2016-05-20 14:48:05 --> Controller Class Initialized
INFO - 2016-05-20 14:48:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:48:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:48:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:48:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:48:05 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:48:05 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:48:05 --> Form Validation Class Initialized
INFO - 2016-05-20 14:48:05 --> Helper loaded: string_helper
INFO - 2016-05-20 14:48:05 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:48:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 14:48:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 14:48:05 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 14:48:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 14:48:05 --> Final output sent to browser
DEBUG - 2016-05-20 14:48:05 --> Total execution time: 0.1524
INFO - 2016-05-20 14:48:51 --> Config Class Initialized
INFO - 2016-05-20 14:48:51 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:48:51 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:48:51 --> Utf8 Class Initialized
INFO - 2016-05-20 14:48:51 --> URI Class Initialized
INFO - 2016-05-20 14:48:51 --> Router Class Initialized
INFO - 2016-05-20 14:48:51 --> Output Class Initialized
INFO - 2016-05-20 14:48:51 --> Security Class Initialized
DEBUG - 2016-05-20 14:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:48:51 --> CSRF cookie sent
INFO - 2016-05-20 14:48:51 --> Input Class Initialized
INFO - 2016-05-20 14:48:51 --> Language Class Initialized
INFO - 2016-05-20 14:48:51 --> Loader Class Initialized
INFO - 2016-05-20 14:48:51 --> Helper loaded: form_helper
INFO - 2016-05-20 14:48:51 --> Database Driver Class Initialized
INFO - 2016-05-20 14:48:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:48:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:48:51 --> Email Class Initialized
INFO - 2016-05-20 14:48:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:48:51 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:48:51 --> Helper loaded: language_helper
INFO - 2016-05-20 14:48:51 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:48:51 --> Model Class Initialized
INFO - 2016-05-20 14:48:51 --> Helper loaded: date_helper
INFO - 2016-05-20 14:48:51 --> Controller Class Initialized
INFO - 2016-05-20 14:48:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:48:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:48:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:48:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:48:51 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 14:48:51 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:48:51 --> Form Validation Class Initialized
INFO - 2016-05-20 14:48:51 --> Helper loaded: string_helper
INFO - 2016-05-20 14:48:51 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:48:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 14:48:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 14:48:51 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 14:48:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 14:48:51 --> Final output sent to browser
DEBUG - 2016-05-20 14:48:51 --> Total execution time: 0.0240
INFO - 2016-05-20 14:49:51 --> Config Class Initialized
INFO - 2016-05-20 14:49:51 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:49:51 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:49:51 --> Utf8 Class Initialized
INFO - 2016-05-20 14:49:51 --> URI Class Initialized
INFO - 2016-05-20 14:49:51 --> Router Class Initialized
INFO - 2016-05-20 14:49:51 --> Output Class Initialized
INFO - 2016-05-20 14:49:51 --> Security Class Initialized
DEBUG - 2016-05-20 14:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:49:51 --> CSRF cookie sent
INFO - 2016-05-20 14:49:51 --> Input Class Initialized
INFO - 2016-05-20 14:49:51 --> Language Class Initialized
INFO - 2016-05-20 14:49:51 --> Loader Class Initialized
INFO - 2016-05-20 14:49:51 --> Helper loaded: form_helper
INFO - 2016-05-20 14:49:51 --> Database Driver Class Initialized
INFO - 2016-05-20 14:49:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:49:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:49:51 --> Email Class Initialized
INFO - 2016-05-20 14:49:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:49:51 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:49:51 --> Helper loaded: language_helper
INFO - 2016-05-20 14:49:51 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:49:51 --> Model Class Initialized
INFO - 2016-05-20 14:49:51 --> Helper loaded: date_helper
INFO - 2016-05-20 14:49:51 --> Controller Class Initialized
INFO - 2016-05-20 14:49:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:49:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:49:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:49:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:49:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:49:51 --> Model Class Initialized
INFO - 2016-05-20 14:49:51 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 14:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 14:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 14:49:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 14:49:51 --> Final output sent to browser
DEBUG - 2016-05-20 14:49:51 --> Total execution time: 0.0315
INFO - 2016-05-20 14:50:07 --> Config Class Initialized
INFO - 2016-05-20 14:50:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 14:50:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 14:50:07 --> Utf8 Class Initialized
INFO - 2016-05-20 14:50:07 --> URI Class Initialized
INFO - 2016-05-20 14:50:07 --> Router Class Initialized
INFO - 2016-05-20 14:50:07 --> Output Class Initialized
INFO - 2016-05-20 14:50:07 --> Security Class Initialized
DEBUG - 2016-05-20 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 14:50:07 --> CSRF cookie sent
INFO - 2016-05-20 14:50:07 --> Input Class Initialized
INFO - 2016-05-20 14:50:07 --> Language Class Initialized
INFO - 2016-05-20 14:50:07 --> Loader Class Initialized
INFO - 2016-05-20 14:50:07 --> Helper loaded: form_helper
INFO - 2016-05-20 14:50:07 --> Database Driver Class Initialized
INFO - 2016-05-20 14:50:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 14:50:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 14:50:07 --> Email Class Initialized
INFO - 2016-05-20 14:50:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 14:50:07 --> Helper loaded: cookie_helper
INFO - 2016-05-20 14:50:07 --> Helper loaded: language_helper
INFO - 2016-05-20 14:50:07 --> Helper loaded: url_helper
DEBUG - 2016-05-20 14:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 14:50:07 --> Model Class Initialized
INFO - 2016-05-20 14:50:07 --> Helper loaded: date_helper
INFO - 2016-05-20 14:50:07 --> Controller Class Initialized
INFO - 2016-05-20 14:50:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 14:50:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 14:50:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 14:50:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 14:50:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 14:50:07 --> Model Class Initialized
INFO - 2016-05-20 14:50:07 --> Helper loaded: languages_helper
INFO - 2016-05-20 14:50:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 14:50:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 14:50:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 14:50:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 14:50:07 --> Final output sent to browser
DEBUG - 2016-05-20 14:50:07 --> Total execution time: 0.0250
INFO - 2016-05-20 15:04:14 --> Config Class Initialized
INFO - 2016-05-20 15:04:14 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:04:14 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:04:14 --> Utf8 Class Initialized
INFO - 2016-05-20 15:04:14 --> URI Class Initialized
INFO - 2016-05-20 15:04:14 --> Router Class Initialized
INFO - 2016-05-20 15:04:14 --> Output Class Initialized
INFO - 2016-05-20 15:04:14 --> Security Class Initialized
DEBUG - 2016-05-20 15:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:04:14 --> CSRF cookie sent
INFO - 2016-05-20 15:04:14 --> Input Class Initialized
INFO - 2016-05-20 15:04:14 --> Language Class Initialized
INFO - 2016-05-20 15:04:14 --> Loader Class Initialized
INFO - 2016-05-20 15:04:14 --> Helper loaded: form_helper
INFO - 2016-05-20 15:04:14 --> Database Driver Class Initialized
INFO - 2016-05-20 15:04:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:04:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:04:14 --> Email Class Initialized
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:04:14 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:04:14 --> Helper loaded: language_helper
INFO - 2016-05-20 15:04:14 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:04:14 --> Model Class Initialized
INFO - 2016-05-20 15:04:14 --> Helper loaded: date_helper
INFO - 2016-05-20 15:04:14 --> Controller Class Initialized
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 15:04:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:04:14 --> Form Validation Class Initialized
INFO - 2016-05-20 15:04:14 --> Config Class Initialized
INFO - 2016-05-20 15:04:14 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:04:14 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:04:14 --> Utf8 Class Initialized
INFO - 2016-05-20 15:04:14 --> URI Class Initialized
INFO - 2016-05-20 15:04:14 --> Router Class Initialized
INFO - 2016-05-20 15:04:14 --> Output Class Initialized
INFO - 2016-05-20 15:04:14 --> Security Class Initialized
DEBUG - 2016-05-20 15:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:04:14 --> CSRF cookie sent
INFO - 2016-05-20 15:04:14 --> Input Class Initialized
INFO - 2016-05-20 15:04:14 --> Language Class Initialized
INFO - 2016-05-20 15:04:14 --> Loader Class Initialized
INFO - 2016-05-20 15:04:14 --> Helper loaded: form_helper
INFO - 2016-05-20 15:04:14 --> Database Driver Class Initialized
INFO - 2016-05-20 15:04:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:04:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:04:14 --> Email Class Initialized
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:04:14 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:04:14 --> Helper loaded: language_helper
INFO - 2016-05-20 15:04:14 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:04:14 --> Model Class Initialized
INFO - 2016-05-20 15:04:14 --> Helper loaded: date_helper
INFO - 2016-05-20 15:04:14 --> Controller Class Initialized
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 15:04:14 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 15:04:14 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:04:14 --> Form Validation Class Initialized
INFO - 2016-05-20 15:15:21 --> Config Class Initialized
INFO - 2016-05-20 15:15:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:15:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:15:21 --> Utf8 Class Initialized
INFO - 2016-05-20 15:15:21 --> URI Class Initialized
INFO - 2016-05-20 15:15:21 --> Router Class Initialized
INFO - 2016-05-20 15:15:21 --> Output Class Initialized
INFO - 2016-05-20 15:15:21 --> Security Class Initialized
DEBUG - 2016-05-20 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:15:21 --> CSRF cookie sent
INFO - 2016-05-20 15:15:21 --> Input Class Initialized
INFO - 2016-05-20 15:15:21 --> Language Class Initialized
INFO - 2016-05-20 15:15:21 --> Loader Class Initialized
INFO - 2016-05-20 15:15:21 --> Helper loaded: form_helper
INFO - 2016-05-20 15:15:21 --> Database Driver Class Initialized
INFO - 2016-05-20 15:15:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:15:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:15:21 --> Email Class Initialized
INFO - 2016-05-20 15:15:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:15:21 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:15:21 --> Helper loaded: language_helper
INFO - 2016-05-20 15:15:21 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:15:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:15:21 --> Model Class Initialized
INFO - 2016-05-20 15:15:21 --> Helper loaded: date_helper
INFO - 2016-05-20 15:15:21 --> Controller Class Initialized
DEBUG - 2016-05-20 15:15:21 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:15:21 --> Form Validation Class Initialized
INFO - 2016-05-20 15:15:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:15:21 --> Config Class Initialized
INFO - 2016-05-20 15:15:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:15:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:15:21 --> Utf8 Class Initialized
INFO - 2016-05-20 15:15:21 --> URI Class Initialized
INFO - 2016-05-20 15:15:21 --> Router Class Initialized
INFO - 2016-05-20 15:15:21 --> Output Class Initialized
INFO - 2016-05-20 15:15:21 --> Security Class Initialized
DEBUG - 2016-05-20 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:15:21 --> CSRF cookie sent
INFO - 2016-05-20 15:15:21 --> Input Class Initialized
INFO - 2016-05-20 15:15:21 --> Language Class Initialized
INFO - 2016-05-20 15:15:21 --> Loader Class Initialized
INFO - 2016-05-20 15:15:21 --> Helper loaded: form_helper
INFO - 2016-05-20 15:15:21 --> Database Driver Class Initialized
INFO - 2016-05-20 15:15:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:15:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:15:22 --> Email Class Initialized
INFO - 2016-05-20 15:15:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:15:22 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:15:22 --> Helper loaded: language_helper
INFO - 2016-05-20 15:15:22 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:15:22 --> Model Class Initialized
INFO - 2016-05-20 15:15:22 --> Helper loaded: date_helper
INFO - 2016-05-20 15:15:22 --> Controller Class Initialized
DEBUG - 2016-05-20 15:15:22 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:15:22 --> Form Validation Class Initialized
INFO - 2016-05-20 15:15:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:18:03 --> Config Class Initialized
INFO - 2016-05-20 15:18:03 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:18:03 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:18:03 --> Utf8 Class Initialized
INFO - 2016-05-20 15:18:03 --> URI Class Initialized
INFO - 2016-05-20 15:18:03 --> Router Class Initialized
INFO - 2016-05-20 15:18:03 --> Output Class Initialized
INFO - 2016-05-20 15:18:03 --> Security Class Initialized
DEBUG - 2016-05-20 15:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:18:03 --> CSRF cookie sent
INFO - 2016-05-20 15:18:03 --> Input Class Initialized
INFO - 2016-05-20 15:18:03 --> Language Class Initialized
INFO - 2016-05-20 15:18:03 --> Loader Class Initialized
INFO - 2016-05-20 15:18:03 --> Helper loaded: form_helper
INFO - 2016-05-20 15:18:03 --> Database Driver Class Initialized
INFO - 2016-05-20 15:18:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:18:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:18:03 --> Email Class Initialized
INFO - 2016-05-20 15:18:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:18:03 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:18:03 --> Helper loaded: language_helper
INFO - 2016-05-20 15:18:03 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:18:03 --> Model Class Initialized
INFO - 2016-05-20 15:18:03 --> Helper loaded: date_helper
INFO - 2016-05-20 15:18:03 --> Controller Class Initialized
DEBUG - 2016-05-20 15:18:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:18:03 --> Form Validation Class Initialized
INFO - 2016-05-20 15:18:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:18:04 --> Config Class Initialized
INFO - 2016-05-20 15:18:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:18:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:18:04 --> Utf8 Class Initialized
INFO - 2016-05-20 15:18:04 --> URI Class Initialized
INFO - 2016-05-20 15:18:04 --> Router Class Initialized
INFO - 2016-05-20 15:18:04 --> Output Class Initialized
INFO - 2016-05-20 15:18:04 --> Security Class Initialized
DEBUG - 2016-05-20 15:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:18:04 --> CSRF cookie sent
INFO - 2016-05-20 15:18:04 --> Input Class Initialized
INFO - 2016-05-20 15:18:04 --> Language Class Initialized
INFO - 2016-05-20 15:18:04 --> Loader Class Initialized
INFO - 2016-05-20 15:18:04 --> Helper loaded: form_helper
INFO - 2016-05-20 15:18:04 --> Database Driver Class Initialized
INFO - 2016-05-20 15:18:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:18:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:18:04 --> Email Class Initialized
INFO - 2016-05-20 15:18:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:18:04 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:18:04 --> Helper loaded: language_helper
INFO - 2016-05-20 15:18:04 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:18:04 --> Model Class Initialized
INFO - 2016-05-20 15:18:04 --> Helper loaded: date_helper
INFO - 2016-05-20 15:18:04 --> Controller Class Initialized
DEBUG - 2016-05-20 15:18:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:18:04 --> Form Validation Class Initialized
INFO - 2016-05-20 15:18:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:32:42 --> Config Class Initialized
INFO - 2016-05-20 15:32:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:32:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:32:42 --> Utf8 Class Initialized
INFO - 2016-05-20 15:32:42 --> URI Class Initialized
INFO - 2016-05-20 15:32:42 --> Router Class Initialized
INFO - 2016-05-20 15:32:42 --> Output Class Initialized
INFO - 2016-05-20 15:32:42 --> Security Class Initialized
DEBUG - 2016-05-20 15:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:32:42 --> CSRF cookie sent
INFO - 2016-05-20 15:32:42 --> Input Class Initialized
INFO - 2016-05-20 15:32:42 --> Language Class Initialized
INFO - 2016-05-20 15:32:42 --> Loader Class Initialized
INFO - 2016-05-20 15:32:42 --> Helper loaded: form_helper
INFO - 2016-05-20 15:32:42 --> Database Driver Class Initialized
INFO - 2016-05-20 15:32:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:32:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:32:42 --> Email Class Initialized
INFO - 2016-05-20 15:32:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:32:42 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:32:42 --> Helper loaded: language_helper
INFO - 2016-05-20 15:32:42 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:32:42 --> Model Class Initialized
INFO - 2016-05-20 15:32:42 --> Helper loaded: date_helper
INFO - 2016-05-20 15:32:42 --> Controller Class Initialized
INFO - 2016-05-20 15:32:42 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:32:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:32:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:32:42 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:32:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:32:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 15:32:42 --> Model Class Initialized
INFO - 2016-05-20 15:32:42 --> Helper loaded: languages_helper
INFO - 2016-05-20 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 15:32:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 15:32:42 --> Final output sent to browser
DEBUG - 2016-05-20 15:32:42 --> Total execution time: 0.1095
INFO - 2016-05-20 15:36:26 --> Config Class Initialized
INFO - 2016-05-20 15:36:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:36:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:36:26 --> Utf8 Class Initialized
INFO - 2016-05-20 15:36:26 --> URI Class Initialized
INFO - 2016-05-20 15:36:26 --> Router Class Initialized
INFO - 2016-05-20 15:36:26 --> Output Class Initialized
INFO - 2016-05-20 15:36:26 --> Security Class Initialized
DEBUG - 2016-05-20 15:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:36:26 --> CSRF cookie sent
INFO - 2016-05-20 15:36:26 --> Input Class Initialized
INFO - 2016-05-20 15:36:26 --> Language Class Initialized
INFO - 2016-05-20 15:36:26 --> Loader Class Initialized
INFO - 2016-05-20 15:36:26 --> Helper loaded: form_helper
INFO - 2016-05-20 15:36:26 --> Database Driver Class Initialized
INFO - 2016-05-20 15:36:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:36:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:36:26 --> Email Class Initialized
INFO - 2016-05-20 15:36:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:36:26 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:36:26 --> Helper loaded: language_helper
INFO - 2016-05-20 15:36:26 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:26 --> Model Class Initialized
INFO - 2016-05-20 15:36:26 --> Helper loaded: date_helper
INFO - 2016-05-20 15:36:26 --> Controller Class Initialized
INFO - 2016-05-20 15:36:26 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:36:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:36:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:36:26 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:36:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:36:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-20 15:36:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:26 --> Form Validation Class Initialized
INFO - 2016-05-20 15:36:27 --> Config Class Initialized
INFO - 2016-05-20 15:36:27 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:36:27 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:36:27 --> Utf8 Class Initialized
INFO - 2016-05-20 15:36:27 --> URI Class Initialized
INFO - 2016-05-20 15:36:27 --> Router Class Initialized
INFO - 2016-05-20 15:36:27 --> Output Class Initialized
INFO - 2016-05-20 15:36:27 --> Security Class Initialized
DEBUG - 2016-05-20 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:36:27 --> CSRF cookie sent
INFO - 2016-05-20 15:36:27 --> Input Class Initialized
INFO - 2016-05-20 15:36:27 --> Language Class Initialized
INFO - 2016-05-20 15:36:27 --> Loader Class Initialized
INFO - 2016-05-20 15:36:27 --> Helper loaded: form_helper
INFO - 2016-05-20 15:36:27 --> Database Driver Class Initialized
INFO - 2016-05-20 15:36:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:36:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:36:27 --> Email Class Initialized
INFO - 2016-05-20 15:36:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:36:27 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:36:27 --> Helper loaded: language_helper
INFO - 2016-05-20 15:36:27 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:36:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:27 --> Model Class Initialized
INFO - 2016-05-20 15:36:27 --> Helper loaded: date_helper
INFO - 2016-05-20 15:36:27 --> Controller Class Initialized
INFO - 2016-05-20 15:36:27 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:36:27 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:36:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:36:27 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:36:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:36:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-20 15:36:27 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:27 --> Form Validation Class Initialized
INFO - 2016-05-20 15:36:27 --> Helper loaded: languages_helper
INFO - 2016-05-20 15:36:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
ERROR - 2016-05-20 15:36:27 --> Could not find the language line "create_user_new"
ERROR - 2016-05-20 15:36:27 --> Could not find the language line "create_user_new_description"
ERROR - 2016-05-20 15:36:27 --> Could not find the language line "create_user_new_register"
INFO - 2016-05-20 15:36:27 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 15:36:27 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 15:36:27 --> Final output sent to browser
DEBUG - 2016-05-20 15:36:27 --> Total execution time: 0.0216
INFO - 2016-05-20 15:36:27 --> Config Class Initialized
INFO - 2016-05-20 15:36:27 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:36:27 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:36:27 --> Utf8 Class Initialized
INFO - 2016-05-20 15:36:27 --> URI Class Initialized
INFO - 2016-05-20 15:36:27 --> Router Class Initialized
INFO - 2016-05-20 15:36:27 --> Output Class Initialized
INFO - 2016-05-20 15:36:27 --> Security Class Initialized
DEBUG - 2016-05-20 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:36:27 --> CSRF cookie sent
INFO - 2016-05-20 15:36:27 --> Input Class Initialized
INFO - 2016-05-20 15:36:27 --> Language Class Initialized
ERROR - 2016-05-20 15:36:27 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 15:36:33 --> Config Class Initialized
INFO - 2016-05-20 15:36:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:36:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:36:33 --> Utf8 Class Initialized
INFO - 2016-05-20 15:36:33 --> URI Class Initialized
INFO - 2016-05-20 15:36:33 --> Router Class Initialized
INFO - 2016-05-20 15:36:33 --> Output Class Initialized
INFO - 2016-05-20 15:36:33 --> Security Class Initialized
DEBUG - 2016-05-20 15:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:36:33 --> CSRF cookie sent
INFO - 2016-05-20 15:36:33 --> CSRF token verified
INFO - 2016-05-20 15:36:33 --> Input Class Initialized
INFO - 2016-05-20 15:36:33 --> Language Class Initialized
INFO - 2016-05-20 15:36:33 --> Loader Class Initialized
INFO - 2016-05-20 15:36:33 --> Helper loaded: form_helper
INFO - 2016-05-20 15:36:33 --> Database Driver Class Initialized
INFO - 2016-05-20 15:36:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:36:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:36:33 --> Email Class Initialized
INFO - 2016-05-20 15:36:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:36:33 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:36:33 --> Helper loaded: language_helper
INFO - 2016-05-20 15:36:33 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:36:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:33 --> Model Class Initialized
INFO - 2016-05-20 15:36:33 --> Helper loaded: date_helper
INFO - 2016-05-20 15:36:33 --> Controller Class Initialized
INFO - 2016-05-20 15:36:33 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:36:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:36:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:36:33 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:36:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:36:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-20 15:36:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:33 --> Form Validation Class Initialized
INFO - 2016-05-20 15:36:34 --> Config Class Initialized
INFO - 2016-05-20 15:36:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:36:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:36:34 --> Utf8 Class Initialized
INFO - 2016-05-20 15:36:34 --> URI Class Initialized
DEBUG - 2016-05-20 15:36:34 --> No URI present. Default controller set.
INFO - 2016-05-20 15:36:34 --> Router Class Initialized
INFO - 2016-05-20 15:36:34 --> Output Class Initialized
INFO - 2016-05-20 15:36:34 --> Security Class Initialized
DEBUG - 2016-05-20 15:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:36:34 --> CSRF cookie sent
INFO - 2016-05-20 15:36:34 --> Input Class Initialized
INFO - 2016-05-20 15:36:34 --> Language Class Initialized
INFO - 2016-05-20 15:36:34 --> Loader Class Initialized
INFO - 2016-05-20 15:36:34 --> Helper loaded: form_helper
INFO - 2016-05-20 15:36:34 --> Database Driver Class Initialized
INFO - 2016-05-20 15:36:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:36:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:36:34 --> Email Class Initialized
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:36:34 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:36:34 --> Helper loaded: language_helper
INFO - 2016-05-20 15:36:34 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:34 --> Model Class Initialized
INFO - 2016-05-20 15:36:34 --> Helper loaded: date_helper
INFO - 2016-05-20 15:36:34 --> Controller Class Initialized
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 15:36:34 --> Config Class Initialized
INFO - 2016-05-20 15:36:34 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:36:34 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:36:34 --> Utf8 Class Initialized
INFO - 2016-05-20 15:36:34 --> URI Class Initialized
INFO - 2016-05-20 15:36:34 --> Router Class Initialized
INFO - 2016-05-20 15:36:34 --> Output Class Initialized
INFO - 2016-05-20 15:36:34 --> Security Class Initialized
DEBUG - 2016-05-20 15:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:36:34 --> CSRF cookie sent
INFO - 2016-05-20 15:36:34 --> Input Class Initialized
INFO - 2016-05-20 15:36:34 --> Language Class Initialized
INFO - 2016-05-20 15:36:34 --> Loader Class Initialized
INFO - 2016-05-20 15:36:34 --> Helper loaded: form_helper
INFO - 2016-05-20 15:36:34 --> Database Driver Class Initialized
INFO - 2016-05-20 15:36:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:36:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:36:34 --> Email Class Initialized
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:36:34 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:36:34 --> Helper loaded: language_helper
INFO - 2016-05-20 15:36:34 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:36:34 --> Model Class Initialized
INFO - 2016-05-20 15:36:34 --> Helper loaded: date_helper
INFO - 2016-05-20 15:36:34 --> Controller Class Initialized
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:36:34 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 15:36:34 --> Model Class Initialized
INFO - 2016-05-20 15:36:34 --> Helper loaded: languages_helper
INFO - 2016-05-20 15:36:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 15:36:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 15:36:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 15:36:34 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 15:36:34 --> Final output sent to browser
DEBUG - 2016-05-20 15:36:34 --> Total execution time: 0.0370
INFO - 2016-05-20 15:39:03 --> Config Class Initialized
INFO - 2016-05-20 15:39:03 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:39:03 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:39:03 --> Utf8 Class Initialized
INFO - 2016-05-20 15:39:03 --> URI Class Initialized
INFO - 2016-05-20 15:39:03 --> Router Class Initialized
INFO - 2016-05-20 15:39:03 --> Output Class Initialized
INFO - 2016-05-20 15:39:03 --> Security Class Initialized
DEBUG - 2016-05-20 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:39:03 --> CSRF cookie sent
INFO - 2016-05-20 15:39:03 --> Input Class Initialized
INFO - 2016-05-20 15:39:03 --> Language Class Initialized
INFO - 2016-05-20 15:39:03 --> Loader Class Initialized
INFO - 2016-05-20 15:39:03 --> Helper loaded: form_helper
INFO - 2016-05-20 15:39:03 --> Database Driver Class Initialized
INFO - 2016-05-20 15:39:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:39:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:39:03 --> Email Class Initialized
INFO - 2016-05-20 15:39:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:39:03 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:39:03 --> Helper loaded: language_helper
INFO - 2016-05-20 15:39:03 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:39:03 --> Model Class Initialized
INFO - 2016-05-20 15:39:03 --> Helper loaded: date_helper
INFO - 2016-05-20 15:39:03 --> Controller Class Initialized
INFO - 2016-05-20 15:39:03 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:39:03 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:39:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:39:03 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:39:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:39:03 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 15:39:03 --> Model Class Initialized
INFO - 2016-05-20 15:39:03 --> Helper loaded: languages_helper
INFO - 2016-05-20 15:39:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 15:39:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 15:39:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 15:39:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 15:39:03 --> Final output sent to browser
DEBUG - 2016-05-20 15:39:03 --> Total execution time: 0.0886
INFO - 2016-05-20 15:39:07 --> Config Class Initialized
INFO - 2016-05-20 15:39:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:39:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:39:07 --> Utf8 Class Initialized
INFO - 2016-05-20 15:39:07 --> URI Class Initialized
INFO - 2016-05-20 15:39:07 --> Router Class Initialized
INFO - 2016-05-20 15:39:07 --> Output Class Initialized
INFO - 2016-05-20 15:39:07 --> Security Class Initialized
DEBUG - 2016-05-20 15:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:39:07 --> CSRF cookie sent
INFO - 2016-05-20 15:39:07 --> Input Class Initialized
INFO - 2016-05-20 15:39:07 --> Language Class Initialized
INFO - 2016-05-20 15:39:07 --> Loader Class Initialized
INFO - 2016-05-20 15:39:07 --> Helper loaded: form_helper
INFO - 2016-05-20 15:39:07 --> Database Driver Class Initialized
INFO - 2016-05-20 15:39:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:39:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:39:07 --> Email Class Initialized
INFO - 2016-05-20 15:39:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:39:07 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:39:07 --> Helper loaded: language_helper
INFO - 2016-05-20 15:39:07 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:39:07 --> Model Class Initialized
INFO - 2016-05-20 15:39:07 --> Helper loaded: date_helper
INFO - 2016-05-20 15:39:07 --> Controller Class Initialized
INFO - 2016-05-20 15:39:07 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:39:07 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:39:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:39:07 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:39:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:39:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-20 15:39:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:39:07 --> Form Validation Class Initialized
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_age_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_sex_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_diabetes_type_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_diabetes_period_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_diabetes_treatment_label"
INFO - 2016-05-20 15:39:07 --> Helper loaded: string_helper
INFO - 2016-05-20 15:39:07 --> Helper loaded: languages_helper
INFO - 2016-05-20 15:39:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 15:39:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_age_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_sex_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_sex_male_option"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_sex_female_option"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_diabetes_type_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_diabetes_period_label"
ERROR - 2016-05-20 15:39:07 --> Could not find the language line "edit_user_validation_diabetes_treatment_label"
INFO - 2016-05-20 15:39:07 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 15:39:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 15:39:07 --> Final output sent to browser
DEBUG - 2016-05-20 15:39:07 --> Total execution time: 0.0733
INFO - 2016-05-20 15:46:07 --> Config Class Initialized
INFO - 2016-05-20 15:46:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:46:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:46:07 --> Utf8 Class Initialized
INFO - 2016-05-20 15:46:07 --> URI Class Initialized
INFO - 2016-05-20 15:46:07 --> Router Class Initialized
INFO - 2016-05-20 15:46:07 --> Output Class Initialized
INFO - 2016-05-20 15:46:07 --> Security Class Initialized
DEBUG - 2016-05-20 15:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:46:07 --> CSRF cookie sent
INFO - 2016-05-20 15:46:07 --> Input Class Initialized
INFO - 2016-05-20 15:46:07 --> Language Class Initialized
INFO - 2016-05-20 15:46:07 --> Loader Class Initialized
INFO - 2016-05-20 15:46:07 --> Helper loaded: form_helper
INFO - 2016-05-20 15:46:07 --> Database Driver Class Initialized
INFO - 2016-05-20 15:46:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:46:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:46:07 --> Email Class Initialized
INFO - 2016-05-20 15:46:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:46:07 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:46:07 --> Helper loaded: language_helper
INFO - 2016-05-20 15:46:07 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:46:07 --> Model Class Initialized
INFO - 2016-05-20 15:46:07 --> Helper loaded: date_helper
INFO - 2016-05-20 15:46:07 --> Controller Class Initialized
DEBUG - 2016-05-20 15:46:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:46:07 --> Form Validation Class Initialized
INFO - 2016-05-20 15:46:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:46:10 --> Config Class Initialized
INFO - 2016-05-20 15:46:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:46:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:46:10 --> Utf8 Class Initialized
INFO - 2016-05-20 15:46:10 --> URI Class Initialized
INFO - 2016-05-20 15:46:10 --> Router Class Initialized
INFO - 2016-05-20 15:46:10 --> Output Class Initialized
INFO - 2016-05-20 15:46:10 --> Security Class Initialized
DEBUG - 2016-05-20 15:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:46:10 --> CSRF cookie sent
INFO - 2016-05-20 15:46:10 --> Input Class Initialized
INFO - 2016-05-20 15:46:10 --> Language Class Initialized
INFO - 2016-05-20 15:46:10 --> Loader Class Initialized
INFO - 2016-05-20 15:46:10 --> Helper loaded: form_helper
INFO - 2016-05-20 15:46:10 --> Database Driver Class Initialized
INFO - 2016-05-20 15:46:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:46:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:46:10 --> Email Class Initialized
INFO - 2016-05-20 15:46:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:46:10 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:46:10 --> Helper loaded: language_helper
INFO - 2016-05-20 15:46:10 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:46:10 --> Model Class Initialized
INFO - 2016-05-20 15:46:10 --> Helper loaded: date_helper
INFO - 2016-05-20 15:46:10 --> Controller Class Initialized
DEBUG - 2016-05-20 15:46:10 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:46:10 --> Form Validation Class Initialized
INFO - 2016-05-20 15:46:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:46:56 --> Config Class Initialized
INFO - 2016-05-20 15:46:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:46:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:46:56 --> Utf8 Class Initialized
INFO - 2016-05-20 15:46:56 --> URI Class Initialized
INFO - 2016-05-20 15:46:56 --> Router Class Initialized
INFO - 2016-05-20 15:46:56 --> Output Class Initialized
INFO - 2016-05-20 15:46:57 --> Security Class Initialized
DEBUG - 2016-05-20 15:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:46:57 --> CSRF cookie sent
INFO - 2016-05-20 15:46:57 --> Input Class Initialized
INFO - 2016-05-20 15:46:57 --> Language Class Initialized
INFO - 2016-05-20 15:46:57 --> Loader Class Initialized
INFO - 2016-05-20 15:46:57 --> Helper loaded: form_helper
INFO - 2016-05-20 15:46:57 --> Database Driver Class Initialized
INFO - 2016-05-20 15:46:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:46:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:46:57 --> Email Class Initialized
INFO - 2016-05-20 15:46:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:46:57 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:46:57 --> Helper loaded: language_helper
INFO - 2016-05-20 15:46:57 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:46:57 --> Model Class Initialized
INFO - 2016-05-20 15:46:57 --> Helper loaded: date_helper
INFO - 2016-05-20 15:46:57 --> Controller Class Initialized
INFO - 2016-05-20 15:46:57 --> Language file loaded: language/english/general_lang.php
ERROR - 2016-05-20 15:46:57 --> Severity: Parsing Error --> syntax error, unexpected 'ge' (T_STRING) /home/demis/www/platformadiabet/application/language/english/auth_lang.php 100
INFO - 2016-05-20 15:47:09 --> Config Class Initialized
INFO - 2016-05-20 15:47:09 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:47:09 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:47:09 --> Utf8 Class Initialized
INFO - 2016-05-20 15:47:09 --> URI Class Initialized
INFO - 2016-05-20 15:47:09 --> Router Class Initialized
INFO - 2016-05-20 15:47:09 --> Output Class Initialized
INFO - 2016-05-20 15:47:09 --> Security Class Initialized
DEBUG - 2016-05-20 15:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:47:09 --> CSRF cookie sent
INFO - 2016-05-20 15:47:09 --> Input Class Initialized
INFO - 2016-05-20 15:47:09 --> Language Class Initialized
INFO - 2016-05-20 15:47:09 --> Loader Class Initialized
INFO - 2016-05-20 15:47:09 --> Helper loaded: form_helper
INFO - 2016-05-20 15:47:09 --> Database Driver Class Initialized
INFO - 2016-05-20 15:47:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:47:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:47:09 --> Email Class Initialized
INFO - 2016-05-20 15:47:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:47:09 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:47:09 --> Helper loaded: language_helper
INFO - 2016-05-20 15:47:09 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:47:09 --> Model Class Initialized
INFO - 2016-05-20 15:47:09 --> Helper loaded: date_helper
INFO - 2016-05-20 15:47:09 --> Controller Class Initialized
INFO - 2016-05-20 15:47:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 15:47:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 15:47:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 15:47:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 15:47:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 15:47:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-20 15:47:09 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:47:09 --> Form Validation Class Initialized
INFO - 2016-05-20 15:47:09 --> Helper loaded: string_helper
INFO - 2016-05-20 15:47:09 --> Helper loaded: languages_helper
INFO - 2016-05-20 15:47:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 15:47:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 15:47:09 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 15:47:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 15:47:09 --> Final output sent to browser
DEBUG - 2016-05-20 15:47:09 --> Total execution time: 0.0249
INFO - 2016-05-20 15:48:16 --> Config Class Initialized
INFO - 2016-05-20 15:48:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:48:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:48:16 --> Utf8 Class Initialized
INFO - 2016-05-20 15:48:16 --> URI Class Initialized
INFO - 2016-05-20 15:48:16 --> Router Class Initialized
INFO - 2016-05-20 15:48:16 --> Output Class Initialized
INFO - 2016-05-20 15:48:16 --> Security Class Initialized
DEBUG - 2016-05-20 15:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:48:16 --> CSRF cookie sent
INFO - 2016-05-20 15:48:16 --> Input Class Initialized
INFO - 2016-05-20 15:48:16 --> Language Class Initialized
INFO - 2016-05-20 15:48:16 --> Loader Class Initialized
INFO - 2016-05-20 15:48:16 --> Helper loaded: form_helper
INFO - 2016-05-20 15:48:16 --> Database Driver Class Initialized
INFO - 2016-05-20 15:48:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:48:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:48:16 --> Email Class Initialized
INFO - 2016-05-20 15:48:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:48:16 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:48:16 --> Helper loaded: language_helper
INFO - 2016-05-20 15:48:16 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:48:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:48:16 --> Model Class Initialized
INFO - 2016-05-20 15:48:16 --> Helper loaded: date_helper
INFO - 2016-05-20 15:48:16 --> Controller Class Initialized
DEBUG - 2016-05-20 15:48:16 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:48:16 --> Form Validation Class Initialized
INFO - 2016-05-20 15:48:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:48:16 --> Config Class Initialized
INFO - 2016-05-20 15:48:16 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:48:16 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:48:16 --> Utf8 Class Initialized
INFO - 2016-05-20 15:48:16 --> URI Class Initialized
INFO - 2016-05-20 15:48:16 --> Router Class Initialized
INFO - 2016-05-20 15:48:16 --> Output Class Initialized
INFO - 2016-05-20 15:48:16 --> Security Class Initialized
DEBUG - 2016-05-20 15:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:48:16 --> CSRF cookie sent
INFO - 2016-05-20 15:48:16 --> Input Class Initialized
INFO - 2016-05-20 15:48:16 --> Language Class Initialized
INFO - 2016-05-20 15:48:16 --> Loader Class Initialized
INFO - 2016-05-20 15:48:16 --> Helper loaded: form_helper
INFO - 2016-05-20 15:48:16 --> Database Driver Class Initialized
INFO - 2016-05-20 15:48:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:48:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:48:17 --> Email Class Initialized
INFO - 2016-05-20 15:48:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:48:17 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:48:17 --> Helper loaded: language_helper
INFO - 2016-05-20 15:48:17 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:48:17 --> Model Class Initialized
INFO - 2016-05-20 15:48:17 --> Helper loaded: date_helper
INFO - 2016-05-20 15:48:17 --> Controller Class Initialized
DEBUG - 2016-05-20 15:48:17 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:48:17 --> Form Validation Class Initialized
INFO - 2016-05-20 15:48:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:51:25 --> Config Class Initialized
INFO - 2016-05-20 15:51:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:51:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:51:25 --> Utf8 Class Initialized
INFO - 2016-05-20 15:51:25 --> URI Class Initialized
INFO - 2016-05-20 15:51:25 --> Router Class Initialized
INFO - 2016-05-20 15:51:25 --> Output Class Initialized
INFO - 2016-05-20 15:51:25 --> Security Class Initialized
DEBUG - 2016-05-20 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:51:25 --> CSRF cookie sent
INFO - 2016-05-20 15:51:25 --> Input Class Initialized
INFO - 2016-05-20 15:51:25 --> Language Class Initialized
INFO - 2016-05-20 15:51:25 --> Loader Class Initialized
INFO - 2016-05-20 15:51:25 --> Helper loaded: form_helper
INFO - 2016-05-20 15:51:25 --> Database Driver Class Initialized
INFO - 2016-05-20 15:51:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:51:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:51:25 --> Email Class Initialized
INFO - 2016-05-20 15:51:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:51:25 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:51:25 --> Helper loaded: language_helper
INFO - 2016-05-20 15:51:25 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:51:25 --> Model Class Initialized
INFO - 2016-05-20 15:51:25 --> Helper loaded: date_helper
INFO - 2016-05-20 15:51:25 --> Controller Class Initialized
DEBUG - 2016-05-20 15:51:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:51:25 --> Form Validation Class Initialized
INFO - 2016-05-20 15:51:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 15:51:28 --> Config Class Initialized
INFO - 2016-05-20 15:51:28 --> Hooks Class Initialized
DEBUG - 2016-05-20 15:51:28 --> UTF-8 Support Enabled
INFO - 2016-05-20 15:51:28 --> Utf8 Class Initialized
INFO - 2016-05-20 15:51:28 --> URI Class Initialized
INFO - 2016-05-20 15:51:28 --> Router Class Initialized
INFO - 2016-05-20 15:51:28 --> Output Class Initialized
INFO - 2016-05-20 15:51:28 --> Security Class Initialized
DEBUG - 2016-05-20 15:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 15:51:28 --> CSRF cookie sent
INFO - 2016-05-20 15:51:28 --> Input Class Initialized
INFO - 2016-05-20 15:51:28 --> Language Class Initialized
INFO - 2016-05-20 15:51:28 --> Loader Class Initialized
INFO - 2016-05-20 15:51:28 --> Helper loaded: form_helper
INFO - 2016-05-20 15:51:28 --> Database Driver Class Initialized
INFO - 2016-05-20 15:51:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 15:51:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 15:51:28 --> Email Class Initialized
INFO - 2016-05-20 15:51:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 15:51:28 --> Helper loaded: cookie_helper
INFO - 2016-05-20 15:51:28 --> Helper loaded: language_helper
INFO - 2016-05-20 15:51:28 --> Helper loaded: url_helper
DEBUG - 2016-05-20 15:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:51:28 --> Model Class Initialized
INFO - 2016-05-20 15:51:28 --> Helper loaded: date_helper
INFO - 2016-05-20 15:51:28 --> Controller Class Initialized
DEBUG - 2016-05-20 15:51:28 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 15:51:28 --> Form Validation Class Initialized
INFO - 2016-05-20 15:51:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:05:43 --> Config Class Initialized
INFO - 2016-05-20 16:05:43 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:05:43 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:05:43 --> Utf8 Class Initialized
INFO - 2016-05-20 16:05:43 --> URI Class Initialized
INFO - 2016-05-20 16:05:43 --> Router Class Initialized
INFO - 2016-05-20 16:05:43 --> Output Class Initialized
INFO - 2016-05-20 16:05:43 --> Security Class Initialized
DEBUG - 2016-05-20 16:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:05:43 --> CSRF cookie sent
INFO - 2016-05-20 16:05:43 --> Input Class Initialized
INFO - 2016-05-20 16:05:43 --> Language Class Initialized
INFO - 2016-05-20 16:05:43 --> Loader Class Initialized
INFO - 2016-05-20 16:05:43 --> Helper loaded: form_helper
INFO - 2016-05-20 16:05:43 --> Database Driver Class Initialized
INFO - 2016-05-20 16:05:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:05:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:05:43 --> Email Class Initialized
INFO - 2016-05-20 16:05:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:05:43 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:05:43 --> Helper loaded: language_helper
INFO - 2016-05-20 16:05:43 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:05:43 --> Model Class Initialized
INFO - 2016-05-20 16:05:43 --> Helper loaded: date_helper
INFO - 2016-05-20 16:05:43 --> Controller Class Initialized
DEBUG - 2016-05-20 16:05:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:05:43 --> Form Validation Class Initialized
INFO - 2016-05-20 16:05:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:05:44 --> Config Class Initialized
INFO - 2016-05-20 16:05:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:05:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:05:44 --> Utf8 Class Initialized
INFO - 2016-05-20 16:05:44 --> URI Class Initialized
INFO - 2016-05-20 16:05:44 --> Router Class Initialized
INFO - 2016-05-20 16:05:44 --> Output Class Initialized
INFO - 2016-05-20 16:05:44 --> Security Class Initialized
DEBUG - 2016-05-20 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:05:44 --> CSRF cookie sent
INFO - 2016-05-20 16:05:44 --> Input Class Initialized
INFO - 2016-05-20 16:05:44 --> Language Class Initialized
INFO - 2016-05-20 16:05:44 --> Loader Class Initialized
INFO - 2016-05-20 16:05:44 --> Helper loaded: form_helper
INFO - 2016-05-20 16:05:44 --> Database Driver Class Initialized
INFO - 2016-05-20 16:05:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:05:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:05:44 --> Email Class Initialized
INFO - 2016-05-20 16:05:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:05:44 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:05:44 --> Helper loaded: language_helper
INFO - 2016-05-20 16:05:44 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:05:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:05:44 --> Model Class Initialized
INFO - 2016-05-20 16:05:44 --> Helper loaded: date_helper
INFO - 2016-05-20 16:05:44 --> Controller Class Initialized
DEBUG - 2016-05-20 16:05:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:05:44 --> Form Validation Class Initialized
INFO - 2016-05-20 16:05:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:08:55 --> Config Class Initialized
INFO - 2016-05-20 16:08:55 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:08:55 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:08:55 --> Utf8 Class Initialized
INFO - 2016-05-20 16:08:55 --> URI Class Initialized
INFO - 2016-05-20 16:08:55 --> Router Class Initialized
INFO - 2016-05-20 16:08:55 --> Output Class Initialized
INFO - 2016-05-20 16:08:55 --> Security Class Initialized
DEBUG - 2016-05-20 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:08:55 --> CSRF cookie sent
INFO - 2016-05-20 16:08:55 --> Input Class Initialized
INFO - 2016-05-20 16:08:55 --> Language Class Initialized
INFO - 2016-05-20 16:08:55 --> Loader Class Initialized
INFO - 2016-05-20 16:08:55 --> Helper loaded: form_helper
INFO - 2016-05-20 16:08:55 --> Database Driver Class Initialized
INFO - 2016-05-20 16:08:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:08:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:08:55 --> Email Class Initialized
INFO - 2016-05-20 16:08:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:08:55 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:08:55 --> Helper loaded: language_helper
INFO - 2016-05-20 16:08:55 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:08:55 --> Model Class Initialized
INFO - 2016-05-20 16:08:55 --> Helper loaded: date_helper
INFO - 2016-05-20 16:08:55 --> Controller Class Initialized
DEBUG - 2016-05-20 16:08:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:08:55 --> Form Validation Class Initialized
INFO - 2016-05-20 16:08:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:08:56 --> Config Class Initialized
INFO - 2016-05-20 16:08:56 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:08:56 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:08:56 --> Utf8 Class Initialized
INFO - 2016-05-20 16:08:56 --> URI Class Initialized
INFO - 2016-05-20 16:08:56 --> Router Class Initialized
INFO - 2016-05-20 16:08:56 --> Output Class Initialized
INFO - 2016-05-20 16:08:56 --> Security Class Initialized
DEBUG - 2016-05-20 16:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:08:56 --> CSRF cookie sent
INFO - 2016-05-20 16:08:56 --> Input Class Initialized
INFO - 2016-05-20 16:08:56 --> Language Class Initialized
INFO - 2016-05-20 16:08:56 --> Loader Class Initialized
INFO - 2016-05-20 16:08:56 --> Helper loaded: form_helper
INFO - 2016-05-20 16:08:56 --> Database Driver Class Initialized
INFO - 2016-05-20 16:08:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:08:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:08:56 --> Email Class Initialized
INFO - 2016-05-20 16:08:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:08:56 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:08:56 --> Helper loaded: language_helper
INFO - 2016-05-20 16:08:56 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:08:56 --> Model Class Initialized
INFO - 2016-05-20 16:08:56 --> Helper loaded: date_helper
INFO - 2016-05-20 16:08:56 --> Controller Class Initialized
DEBUG - 2016-05-20 16:08:56 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:08:56 --> Form Validation Class Initialized
INFO - 2016-05-20 16:08:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:25:25 --> Config Class Initialized
INFO - 2016-05-20 16:25:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:25:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:25:25 --> Utf8 Class Initialized
INFO - 2016-05-20 16:25:25 --> URI Class Initialized
INFO - 2016-05-20 16:25:25 --> Router Class Initialized
INFO - 2016-05-20 16:25:25 --> Output Class Initialized
INFO - 2016-05-20 16:25:25 --> Security Class Initialized
DEBUG - 2016-05-20 16:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:25:25 --> CSRF cookie sent
INFO - 2016-05-20 16:25:25 --> Input Class Initialized
INFO - 2016-05-20 16:25:25 --> Language Class Initialized
INFO - 2016-05-20 16:25:25 --> Loader Class Initialized
INFO - 2016-05-20 16:25:25 --> Helper loaded: form_helper
INFO - 2016-05-20 16:25:25 --> Database Driver Class Initialized
INFO - 2016-05-20 16:25:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:25:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:25:25 --> Email Class Initialized
INFO - 2016-05-20 16:25:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:25:25 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:25:25 --> Helper loaded: language_helper
INFO - 2016-05-20 16:25:25 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:25:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:25:25 --> Model Class Initialized
INFO - 2016-05-20 16:25:25 --> Helper loaded: date_helper
INFO - 2016-05-20 16:25:25 --> Controller Class Initialized
DEBUG - 2016-05-20 16:25:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:25:25 --> Form Validation Class Initialized
INFO - 2016-05-20 16:25:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:25:26 --> Config Class Initialized
INFO - 2016-05-20 16:25:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:25:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:25:26 --> Utf8 Class Initialized
INFO - 2016-05-20 16:25:26 --> URI Class Initialized
INFO - 2016-05-20 16:25:26 --> Router Class Initialized
INFO - 2016-05-20 16:25:26 --> Output Class Initialized
INFO - 2016-05-20 16:25:26 --> Security Class Initialized
DEBUG - 2016-05-20 16:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:25:26 --> CSRF cookie sent
INFO - 2016-05-20 16:25:26 --> Input Class Initialized
INFO - 2016-05-20 16:25:26 --> Language Class Initialized
INFO - 2016-05-20 16:25:26 --> Loader Class Initialized
INFO - 2016-05-20 16:25:26 --> Helper loaded: form_helper
INFO - 2016-05-20 16:25:26 --> Database Driver Class Initialized
INFO - 2016-05-20 16:25:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:25:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:25:26 --> Email Class Initialized
INFO - 2016-05-20 16:25:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:25:26 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:25:26 --> Helper loaded: language_helper
INFO - 2016-05-20 16:25:26 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:25:26 --> Model Class Initialized
INFO - 2016-05-20 16:25:26 --> Helper loaded: date_helper
INFO - 2016-05-20 16:25:26 --> Controller Class Initialized
DEBUG - 2016-05-20 16:25:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:25:26 --> Form Validation Class Initialized
INFO - 2016-05-20 16:25:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:44:32 --> Config Class Initialized
INFO - 2016-05-20 16:44:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:44:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:44:32 --> Utf8 Class Initialized
INFO - 2016-05-20 16:44:32 --> URI Class Initialized
INFO - 2016-05-20 16:44:32 --> Router Class Initialized
INFO - 2016-05-20 16:44:32 --> Output Class Initialized
INFO - 2016-05-20 16:44:32 --> Security Class Initialized
DEBUG - 2016-05-20 16:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:44:32 --> CSRF cookie sent
INFO - 2016-05-20 16:44:32 --> Input Class Initialized
INFO - 2016-05-20 16:44:32 --> Language Class Initialized
INFO - 2016-05-20 16:44:32 --> Loader Class Initialized
INFO - 2016-05-20 16:44:32 --> Helper loaded: form_helper
INFO - 2016-05-20 16:44:32 --> Database Driver Class Initialized
INFO - 2016-05-20 16:44:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:44:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:44:32 --> Email Class Initialized
INFO - 2016-05-20 16:44:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:44:32 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:44:32 --> Helper loaded: language_helper
INFO - 2016-05-20 16:44:32 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:44:32 --> Model Class Initialized
INFO - 2016-05-20 16:44:32 --> Helper loaded: date_helper
INFO - 2016-05-20 16:44:32 --> Controller Class Initialized
DEBUG - 2016-05-20 16:44:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:44:32 --> Form Validation Class Initialized
INFO - 2016-05-20 16:44:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 16:44:32 --> Config Class Initialized
INFO - 2016-05-20 16:44:32 --> Hooks Class Initialized
DEBUG - 2016-05-20 16:44:32 --> UTF-8 Support Enabled
INFO - 2016-05-20 16:44:32 --> Utf8 Class Initialized
INFO - 2016-05-20 16:44:32 --> URI Class Initialized
INFO - 2016-05-20 16:44:32 --> Router Class Initialized
INFO - 2016-05-20 16:44:32 --> Output Class Initialized
INFO - 2016-05-20 16:44:32 --> Security Class Initialized
DEBUG - 2016-05-20 16:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 16:44:32 --> CSRF cookie sent
INFO - 2016-05-20 16:44:32 --> Input Class Initialized
INFO - 2016-05-20 16:44:32 --> Language Class Initialized
INFO - 2016-05-20 16:44:32 --> Loader Class Initialized
INFO - 2016-05-20 16:44:32 --> Helper loaded: form_helper
INFO - 2016-05-20 16:44:32 --> Database Driver Class Initialized
INFO - 2016-05-20 16:44:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 16:44:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 16:44:32 --> Email Class Initialized
INFO - 2016-05-20 16:44:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 16:44:32 --> Helper loaded: cookie_helper
INFO - 2016-05-20 16:44:32 --> Helper loaded: language_helper
INFO - 2016-05-20 16:44:32 --> Helper loaded: url_helper
DEBUG - 2016-05-20 16:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:44:32 --> Model Class Initialized
INFO - 2016-05-20 16:44:32 --> Helper loaded: date_helper
INFO - 2016-05-20 16:44:32 --> Controller Class Initialized
DEBUG - 2016-05-20 16:44:32 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 16:44:32 --> Form Validation Class Initialized
INFO - 2016-05-20 16:44:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 17:06:52 --> Config Class Initialized
INFO - 2016-05-20 17:06:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:06:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:06:52 --> Utf8 Class Initialized
INFO - 2016-05-20 17:06:52 --> URI Class Initialized
DEBUG - 2016-05-20 17:06:52 --> No URI present. Default controller set.
INFO - 2016-05-20 17:06:52 --> Router Class Initialized
INFO - 2016-05-20 17:06:52 --> Output Class Initialized
INFO - 2016-05-20 17:06:52 --> Security Class Initialized
DEBUG - 2016-05-20 17:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:06:52 --> CSRF cookie sent
INFO - 2016-05-20 17:06:52 --> Input Class Initialized
INFO - 2016-05-20 17:06:52 --> Language Class Initialized
INFO - 2016-05-20 17:06:52 --> Loader Class Initialized
INFO - 2016-05-20 17:06:52 --> Helper loaded: form_helper
INFO - 2016-05-20 17:06:52 --> Database Driver Class Initialized
INFO - 2016-05-20 17:06:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:06:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:06:52 --> Email Class Initialized
INFO - 2016-05-20 17:06:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:06:52 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:06:52 --> Helper loaded: language_helper
INFO - 2016-05-20 17:06:52 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:06:52 --> Model Class Initialized
INFO - 2016-05-20 17:06:52 --> Helper loaded: date_helper
INFO - 2016-05-20 17:06:52 --> Controller Class Initialized
INFO - 2016-05-20 17:06:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:06:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:06:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:06:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:06:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:06:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 17:06:53 --> Config Class Initialized
INFO - 2016-05-20 17:06:53 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:06:53 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:06:53 --> Utf8 Class Initialized
INFO - 2016-05-20 17:06:53 --> URI Class Initialized
INFO - 2016-05-20 17:06:53 --> Router Class Initialized
INFO - 2016-05-20 17:06:53 --> Output Class Initialized
INFO - 2016-05-20 17:06:53 --> Security Class Initialized
DEBUG - 2016-05-20 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:06:53 --> CSRF cookie sent
INFO - 2016-05-20 17:06:53 --> Input Class Initialized
INFO - 2016-05-20 17:06:53 --> Language Class Initialized
INFO - 2016-05-20 17:06:53 --> Loader Class Initialized
INFO - 2016-05-20 17:06:53 --> Helper loaded: form_helper
INFO - 2016-05-20 17:06:53 --> Database Driver Class Initialized
INFO - 2016-05-20 17:06:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:06:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:06:53 --> Email Class Initialized
INFO - 2016-05-20 17:06:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:06:53 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:06:53 --> Helper loaded: language_helper
INFO - 2016-05-20 17:06:53 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:06:53 --> Model Class Initialized
INFO - 2016-05-20 17:06:53 --> Helper loaded: date_helper
INFO - 2016-05-20 17:06:53 --> Controller Class Initialized
INFO - 2016-05-20 17:06:53 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:06:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:06:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:06:53 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:06:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:06:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 17:06:53 --> Model Class Initialized
INFO - 2016-05-20 17:06:53 --> Helper loaded: languages_helper
INFO - 2016-05-20 17:06:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 17:06:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 17:06:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 17:06:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 17:06:53 --> Final output sent to browser
DEBUG - 2016-05-20 17:06:53 --> Total execution time: 0.0767
INFO - 2016-05-20 17:09:52 --> Config Class Initialized
INFO - 2016-05-20 17:09:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:09:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:09:52 --> Utf8 Class Initialized
INFO - 2016-05-20 17:09:52 --> URI Class Initialized
INFO - 2016-05-20 17:09:52 --> Router Class Initialized
INFO - 2016-05-20 17:09:52 --> Output Class Initialized
INFO - 2016-05-20 17:09:52 --> Security Class Initialized
DEBUG - 2016-05-20 17:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:09:52 --> CSRF cookie sent
INFO - 2016-05-20 17:09:52 --> Input Class Initialized
INFO - 2016-05-20 17:09:52 --> Language Class Initialized
INFO - 2016-05-20 17:09:52 --> Loader Class Initialized
INFO - 2016-05-20 17:09:52 --> Helper loaded: form_helper
INFO - 2016-05-20 17:09:52 --> Database Driver Class Initialized
INFO - 2016-05-20 17:09:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:09:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:09:52 --> Email Class Initialized
INFO - 2016-05-20 17:09:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:09:52 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:09:52 --> Helper loaded: language_helper
INFO - 2016-05-20 17:09:52 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:09:52 --> Model Class Initialized
INFO - 2016-05-20 17:09:52 --> Helper loaded: date_helper
INFO - 2016-05-20 17:09:52 --> Controller Class Initialized
DEBUG - 2016-05-20 17:09:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:09:52 --> Form Validation Class Initialized
INFO - 2016-05-20 17:09:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 17:09:52 --> Config Class Initialized
INFO - 2016-05-20 17:09:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:09:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:09:52 --> Utf8 Class Initialized
INFO - 2016-05-20 17:09:52 --> URI Class Initialized
INFO - 2016-05-20 17:09:52 --> Router Class Initialized
INFO - 2016-05-20 17:09:52 --> Output Class Initialized
INFO - 2016-05-20 17:09:52 --> Security Class Initialized
DEBUG - 2016-05-20 17:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:09:52 --> CSRF cookie sent
INFO - 2016-05-20 17:09:52 --> Input Class Initialized
INFO - 2016-05-20 17:09:52 --> Language Class Initialized
INFO - 2016-05-20 17:09:52 --> Loader Class Initialized
INFO - 2016-05-20 17:09:52 --> Helper loaded: form_helper
INFO - 2016-05-20 17:09:52 --> Database Driver Class Initialized
INFO - 2016-05-20 17:09:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:09:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:09:52 --> Email Class Initialized
INFO - 2016-05-20 17:09:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:09:52 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:09:52 --> Helper loaded: language_helper
INFO - 2016-05-20 17:09:52 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:09:52 --> Model Class Initialized
INFO - 2016-05-20 17:09:52 --> Helper loaded: date_helper
INFO - 2016-05-20 17:09:52 --> Controller Class Initialized
DEBUG - 2016-05-20 17:09:52 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:09:52 --> Form Validation Class Initialized
INFO - 2016-05-20 17:09:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 17:11:30 --> Config Class Initialized
INFO - 2016-05-20 17:11:30 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:11:30 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:11:30 --> Utf8 Class Initialized
INFO - 2016-05-20 17:11:30 --> URI Class Initialized
INFO - 2016-05-20 17:11:30 --> Router Class Initialized
INFO - 2016-05-20 17:11:30 --> Output Class Initialized
INFO - 2016-05-20 17:11:30 --> Security Class Initialized
DEBUG - 2016-05-20 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:11:30 --> CSRF cookie sent
INFO - 2016-05-20 17:11:30 --> Input Class Initialized
INFO - 2016-05-20 17:11:30 --> Language Class Initialized
INFO - 2016-05-20 17:11:30 --> Loader Class Initialized
INFO - 2016-05-20 17:11:30 --> Helper loaded: form_helper
INFO - 2016-05-20 17:11:30 --> Database Driver Class Initialized
INFO - 2016-05-20 17:11:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:11:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:11:30 --> Email Class Initialized
INFO - 2016-05-20 17:11:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:11:30 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:11:30 --> Helper loaded: language_helper
INFO - 2016-05-20 17:11:30 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:11:30 --> Model Class Initialized
INFO - 2016-05-20 17:11:30 --> Helper loaded: date_helper
INFO - 2016-05-20 17:11:30 --> Controller Class Initialized
DEBUG - 2016-05-20 17:11:30 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:11:30 --> Form Validation Class Initialized
INFO - 2016-05-20 17:11:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 17:11:31 --> Config Class Initialized
INFO - 2016-05-20 17:11:31 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:11:31 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:11:31 --> Utf8 Class Initialized
INFO - 2016-05-20 17:11:31 --> URI Class Initialized
INFO - 2016-05-20 17:11:31 --> Router Class Initialized
INFO - 2016-05-20 17:11:31 --> Output Class Initialized
INFO - 2016-05-20 17:11:31 --> Security Class Initialized
DEBUG - 2016-05-20 17:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:11:31 --> CSRF cookie sent
INFO - 2016-05-20 17:11:31 --> Input Class Initialized
INFO - 2016-05-20 17:11:31 --> Language Class Initialized
INFO - 2016-05-20 17:11:31 --> Loader Class Initialized
INFO - 2016-05-20 17:11:31 --> Helper loaded: form_helper
INFO - 2016-05-20 17:11:31 --> Database Driver Class Initialized
INFO - 2016-05-20 17:11:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:11:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:11:31 --> Email Class Initialized
INFO - 2016-05-20 17:11:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:11:31 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:11:31 --> Helper loaded: language_helper
INFO - 2016-05-20 17:11:31 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:11:31 --> Model Class Initialized
INFO - 2016-05-20 17:11:31 --> Helper loaded: date_helper
INFO - 2016-05-20 17:11:31 --> Controller Class Initialized
DEBUG - 2016-05-20 17:11:31 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:11:31 --> Form Validation Class Initialized
INFO - 2016-05-20 17:11:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 17:49:05 --> Config Class Initialized
INFO - 2016-05-20 17:49:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:49:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:49:05 --> Utf8 Class Initialized
INFO - 2016-05-20 17:49:05 --> URI Class Initialized
DEBUG - 2016-05-20 17:49:05 --> No URI present. Default controller set.
INFO - 2016-05-20 17:49:05 --> Router Class Initialized
INFO - 2016-05-20 17:49:05 --> Output Class Initialized
INFO - 2016-05-20 17:49:05 --> Security Class Initialized
DEBUG - 2016-05-20 17:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:49:05 --> CSRF cookie sent
INFO - 2016-05-20 17:49:05 --> Input Class Initialized
INFO - 2016-05-20 17:49:05 --> Language Class Initialized
INFO - 2016-05-20 17:49:05 --> Loader Class Initialized
INFO - 2016-05-20 17:49:05 --> Helper loaded: form_helper
INFO - 2016-05-20 17:49:05 --> Database Driver Class Initialized
INFO - 2016-05-20 17:49:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:49:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:49:05 --> Email Class Initialized
INFO - 2016-05-20 17:49:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:49:05 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:49:05 --> Helper loaded: language_helper
INFO - 2016-05-20 17:49:05 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:49:05 --> Model Class Initialized
INFO - 2016-05-20 17:49:05 --> Helper loaded: date_helper
INFO - 2016-05-20 17:49:05 --> Controller Class Initialized
INFO - 2016-05-20 17:49:05 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:49:05 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:49:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:49:05 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:49:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:49:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 17:49:06 --> Config Class Initialized
INFO - 2016-05-20 17:49:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:49:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:49:06 --> Utf8 Class Initialized
INFO - 2016-05-20 17:49:06 --> URI Class Initialized
INFO - 2016-05-20 17:49:06 --> Router Class Initialized
INFO - 2016-05-20 17:49:06 --> Output Class Initialized
INFO - 2016-05-20 17:49:06 --> Security Class Initialized
DEBUG - 2016-05-20 17:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:49:06 --> CSRF cookie sent
INFO - 2016-05-20 17:49:06 --> Input Class Initialized
INFO - 2016-05-20 17:49:06 --> Language Class Initialized
INFO - 2016-05-20 17:49:06 --> Loader Class Initialized
INFO - 2016-05-20 17:49:06 --> Helper loaded: form_helper
INFO - 2016-05-20 17:49:06 --> Database Driver Class Initialized
INFO - 2016-05-20 17:49:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:49:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:49:06 --> Email Class Initialized
INFO - 2016-05-20 17:49:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:49:06 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:49:06 --> Helper loaded: language_helper
INFO - 2016-05-20 17:49:06 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:49:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:49:06 --> Model Class Initialized
INFO - 2016-05-20 17:49:06 --> Helper loaded: date_helper
INFO - 2016-05-20 17:49:06 --> Controller Class Initialized
INFO - 2016-05-20 17:49:06 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:49:06 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:49:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:49:06 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:49:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:49:06 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 17:49:06 --> Model Class Initialized
INFO - 2016-05-20 17:49:06 --> Helper loaded: languages_helper
INFO - 2016-05-20 17:49:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 17:49:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 17:49:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 17:49:07 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 17:49:07 --> Final output sent to browser
DEBUG - 2016-05-20 17:49:07 --> Total execution time: 0.1468
INFO - 2016-05-20 17:56:07 --> Config Class Initialized
INFO - 2016-05-20 17:56:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:56:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:56:07 --> Utf8 Class Initialized
INFO - 2016-05-20 17:56:07 --> URI Class Initialized
INFO - 2016-05-20 17:56:07 --> Router Class Initialized
INFO - 2016-05-20 17:56:07 --> Output Class Initialized
INFO - 2016-05-20 17:56:07 --> Security Class Initialized
DEBUG - 2016-05-20 17:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:56:07 --> CSRF cookie sent
INFO - 2016-05-20 17:56:07 --> Input Class Initialized
INFO - 2016-05-20 17:56:07 --> Language Class Initialized
ERROR - 2016-05-20 17:56:07 --> Severity: Compile Error --> Cannot redeclare Diabet::index() /home/demis/www/platformadiabet/application/controllers/Diabet.php 135
INFO - 2016-05-20 17:56:46 --> Config Class Initialized
INFO - 2016-05-20 17:56:46 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:56:46 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:56:46 --> Utf8 Class Initialized
INFO - 2016-05-20 17:56:46 --> URI Class Initialized
INFO - 2016-05-20 17:56:46 --> Router Class Initialized
INFO - 2016-05-20 17:56:46 --> Output Class Initialized
INFO - 2016-05-20 17:56:46 --> Security Class Initialized
DEBUG - 2016-05-20 17:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:56:46 --> CSRF cookie sent
INFO - 2016-05-20 17:56:46 --> Input Class Initialized
INFO - 2016-05-20 17:56:46 --> Language Class Initialized
INFO - 2016-05-20 17:56:46 --> Loader Class Initialized
INFO - 2016-05-20 17:56:46 --> Helper loaded: form_helper
INFO - 2016-05-20 17:56:46 --> Database Driver Class Initialized
INFO - 2016-05-20 17:56:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:56:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:56:46 --> Email Class Initialized
INFO - 2016-05-20 17:56:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:56:46 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:56:46 --> Helper loaded: language_helper
INFO - 2016-05-20 17:56:46 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:56:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:56:46 --> Model Class Initialized
INFO - 2016-05-20 17:56:46 --> Helper loaded: date_helper
INFO - 2016-05-20 17:56:46 --> Controller Class Initialized
INFO - 2016-05-20 17:56:46 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:56:46 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:56:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:56:46 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:56:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:56:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-05-20 17:56:46 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:56:46 --> Form Validation Class Initialized
INFO - 2016-05-20 17:56:46 --> Helper loaded: string_helper
INFO - 2016-05-20 17:56:46 --> Helper loaded: languages_helper
INFO - 2016-05-20 17:56:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 17:56:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 17:56:46 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 17:56:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 17:56:46 --> Final output sent to browser
DEBUG - 2016-05-20 17:56:46 --> Total execution time: 0.1190
INFO - 2016-05-20 17:56:50 --> Config Class Initialized
INFO - 2016-05-20 17:56:50 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:56:50 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:56:50 --> Utf8 Class Initialized
INFO - 2016-05-20 17:56:50 --> URI Class Initialized
DEBUG - 2016-05-20 17:56:50 --> No URI present. Default controller set.
INFO - 2016-05-20 17:56:50 --> Router Class Initialized
INFO - 2016-05-20 17:56:50 --> Output Class Initialized
INFO - 2016-05-20 17:56:50 --> Security Class Initialized
DEBUG - 2016-05-20 17:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:56:50 --> CSRF cookie sent
INFO - 2016-05-20 17:56:50 --> Input Class Initialized
INFO - 2016-05-20 17:56:50 --> Language Class Initialized
INFO - 2016-05-20 17:56:50 --> Loader Class Initialized
INFO - 2016-05-20 17:56:50 --> Helper loaded: form_helper
INFO - 2016-05-20 17:56:50 --> Database Driver Class Initialized
INFO - 2016-05-20 17:56:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:56:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:56:50 --> Email Class Initialized
INFO - 2016-05-20 17:56:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:56:50 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:56:50 --> Helper loaded: language_helper
INFO - 2016-05-20 17:56:50 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:56:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:56:50 --> Model Class Initialized
INFO - 2016-05-20 17:56:50 --> Helper loaded: date_helper
INFO - 2016-05-20 17:56:50 --> Controller Class Initialized
INFO - 2016-05-20 17:56:50 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:56:50 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:56:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:56:51 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:56:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:56:51 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 17:56:53 --> Config Class Initialized
INFO - 2016-05-20 17:56:53 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:56:53 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:56:53 --> Utf8 Class Initialized
INFO - 2016-05-20 17:56:53 --> URI Class Initialized
INFO - 2016-05-20 17:56:53 --> Router Class Initialized
INFO - 2016-05-20 17:56:53 --> Output Class Initialized
INFO - 2016-05-20 17:56:53 --> Security Class Initialized
DEBUG - 2016-05-20 17:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:56:53 --> CSRF cookie sent
INFO - 2016-05-20 17:56:53 --> Input Class Initialized
INFO - 2016-05-20 17:56:53 --> Language Class Initialized
INFO - 2016-05-20 17:56:53 --> Loader Class Initialized
INFO - 2016-05-20 17:56:53 --> Helper loaded: form_helper
INFO - 2016-05-20 17:56:53 --> Database Driver Class Initialized
INFO - 2016-05-20 17:56:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:56:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:56:53 --> Email Class Initialized
INFO - 2016-05-20 17:56:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:56:53 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:56:53 --> Helper loaded: language_helper
INFO - 2016-05-20 17:56:53 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:56:53 --> Model Class Initialized
INFO - 2016-05-20 17:56:53 --> Helper loaded: date_helper
INFO - 2016-05-20 17:56:53 --> Controller Class Initialized
INFO - 2016-05-20 17:56:53 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:56:53 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:56:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:56:53 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:56:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:56:53 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 17:56:53 --> Model Class Initialized
INFO - 2016-05-20 17:56:53 --> Helper loaded: languages_helper
INFO - 2016-05-20 17:56:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 17:56:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 17:56:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 17:56:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 17:56:53 --> Final output sent to browser
DEBUG - 2016-05-20 17:56:53 --> Total execution time: 0.0810
INFO - 2016-05-20 17:59:59 --> Config Class Initialized
INFO - 2016-05-20 17:59:59 --> Hooks Class Initialized
DEBUG - 2016-05-20 17:59:59 --> UTF-8 Support Enabled
INFO - 2016-05-20 17:59:59 --> Utf8 Class Initialized
INFO - 2016-05-20 17:59:59 --> URI Class Initialized
INFO - 2016-05-20 17:59:59 --> Router Class Initialized
INFO - 2016-05-20 17:59:59 --> Output Class Initialized
INFO - 2016-05-20 17:59:59 --> Security Class Initialized
DEBUG - 2016-05-20 17:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 17:59:59 --> CSRF cookie sent
INFO - 2016-05-20 17:59:59 --> Input Class Initialized
INFO - 2016-05-20 17:59:59 --> Language Class Initialized
INFO - 2016-05-20 17:59:59 --> Loader Class Initialized
INFO - 2016-05-20 17:59:59 --> Helper loaded: form_helper
INFO - 2016-05-20 17:59:59 --> Database Driver Class Initialized
INFO - 2016-05-20 17:59:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 17:59:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 17:59:59 --> Email Class Initialized
INFO - 2016-05-20 17:59:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 17:59:59 --> Helper loaded: cookie_helper
INFO - 2016-05-20 17:59:59 --> Helper loaded: language_helper
INFO - 2016-05-20 17:59:59 --> Helper loaded: url_helper
DEBUG - 2016-05-20 17:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 17:59:59 --> Model Class Initialized
INFO - 2016-05-20 17:59:59 --> Helper loaded: date_helper
INFO - 2016-05-20 17:59:59 --> Controller Class Initialized
INFO - 2016-05-20 17:59:59 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 17:59:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 17:59:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 17:59:59 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 17:59:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 17:59:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 17:59:59 --> Model Class Initialized
INFO - 2016-05-20 17:59:59 --> Helper loaded: languages_helper
INFO - 2016-05-20 17:59:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 17:59:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 17:59:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 17:59:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 17:59:59 --> Final output sent to browser
DEBUG - 2016-05-20 17:59:59 --> Total execution time: 0.0578
INFO - 2016-05-20 18:00:39 --> Config Class Initialized
INFO - 2016-05-20 18:00:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:00:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:00:39 --> Utf8 Class Initialized
INFO - 2016-05-20 18:00:39 --> URI Class Initialized
INFO - 2016-05-20 18:00:39 --> Router Class Initialized
INFO - 2016-05-20 18:00:39 --> Output Class Initialized
INFO - 2016-05-20 18:00:39 --> Security Class Initialized
DEBUG - 2016-05-20 18:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:00:39 --> CSRF cookie sent
INFO - 2016-05-20 18:00:39 --> Input Class Initialized
INFO - 2016-05-20 18:00:39 --> Language Class Initialized
INFO - 2016-05-20 18:00:39 --> Loader Class Initialized
INFO - 2016-05-20 18:00:39 --> Helper loaded: form_helper
INFO - 2016-05-20 18:00:39 --> Database Driver Class Initialized
INFO - 2016-05-20 18:00:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:00:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:00:39 --> Email Class Initialized
INFO - 2016-05-20 18:00:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:00:39 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:00:39 --> Helper loaded: language_helper
INFO - 2016-05-20 18:00:39 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:00:39 --> Model Class Initialized
INFO - 2016-05-20 18:00:39 --> Helper loaded: date_helper
INFO - 2016-05-20 18:00:39 --> Controller Class Initialized
INFO - 2016-05-20 18:00:39 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 18:00:39 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 18:00:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 18:00:39 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 18:00:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 18:00:39 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 18:00:39 --> Model Class Initialized
INFO - 2016-05-20 18:00:39 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:00:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:00:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 18:00:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 18:00:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:00:39 --> Final output sent to browser
DEBUG - 2016-05-20 18:00:39 --> Total execution time: 0.0650
INFO - 2016-05-20 18:00:57 --> Config Class Initialized
INFO - 2016-05-20 18:00:57 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:00:57 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:00:57 --> Utf8 Class Initialized
INFO - 2016-05-20 18:00:57 --> URI Class Initialized
INFO - 2016-05-20 18:00:57 --> Router Class Initialized
INFO - 2016-05-20 18:00:57 --> Output Class Initialized
INFO - 2016-05-20 18:00:57 --> Security Class Initialized
DEBUG - 2016-05-20 18:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:00:57 --> CSRF cookie sent
INFO - 2016-05-20 18:00:57 --> CSRF token verified
INFO - 2016-05-20 18:00:57 --> Input Class Initialized
INFO - 2016-05-20 18:00:57 --> Language Class Initialized
INFO - 2016-05-20 18:00:57 --> Loader Class Initialized
INFO - 2016-05-20 18:00:57 --> Helper loaded: form_helper
INFO - 2016-05-20 18:00:57 --> Database Driver Class Initialized
INFO - 2016-05-20 18:00:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:00:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:00:57 --> Email Class Initialized
INFO - 2016-05-20 18:00:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:00:57 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:00:57 --> Helper loaded: language_helper
INFO - 2016-05-20 18:00:57 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:00:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:00:57 --> Model Class Initialized
INFO - 2016-05-20 18:00:57 --> Helper loaded: date_helper
INFO - 2016-05-20 18:00:58 --> Controller Class Initialized
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/english/general_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-05-20 18:00:58 --> Config Class Initialized
INFO - 2016-05-20 18:00:58 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:00:58 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:00:58 --> Utf8 Class Initialized
INFO - 2016-05-20 18:00:58 --> URI Class Initialized
INFO - 2016-05-20 18:00:58 --> Router Class Initialized
INFO - 2016-05-20 18:00:58 --> Output Class Initialized
INFO - 2016-05-20 18:00:58 --> Security Class Initialized
DEBUG - 2016-05-20 18:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:00:58 --> CSRF cookie sent
INFO - 2016-05-20 18:00:58 --> Input Class Initialized
INFO - 2016-05-20 18:00:58 --> Language Class Initialized
INFO - 2016-05-20 18:00:58 --> Loader Class Initialized
INFO - 2016-05-20 18:00:58 --> Helper loaded: form_helper
INFO - 2016-05-20 18:00:58 --> Database Driver Class Initialized
INFO - 2016-05-20 18:00:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:00:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:00:58 --> Email Class Initialized
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:00:58 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:00:58 --> Helper loaded: language_helper
INFO - 2016-05-20 18:00:58 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:00:58 --> Model Class Initialized
INFO - 2016-05-20 18:00:58 --> Helper loaded: date_helper
INFO - 2016-05-20 18:00:58 --> Controller Class Initialized
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 18:00:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 18:00:58 --> Model Class Initialized
INFO - 2016-05-20 18:00:58 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-20 18:00:58 --> Could not find the language line "dashboard_4_units_button"
ERROR - 2016-05-20 18:00:58 --> Could not find the language line "dashboard_3_units_button"
INFO - 2016-05-20 18:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 18:00:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:00:58 --> Final output sent to browser
DEBUG - 2016-05-20 18:00:58 --> Total execution time: 0.0296
INFO - 2016-05-20 18:03:06 --> Config Class Initialized
INFO - 2016-05-20 18:03:06 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:03:06 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:03:06 --> Utf8 Class Initialized
INFO - 2016-05-20 18:03:06 --> URI Class Initialized
INFO - 2016-05-20 18:03:06 --> Router Class Initialized
INFO - 2016-05-20 18:03:06 --> Output Class Initialized
INFO - 2016-05-20 18:03:06 --> Security Class Initialized
DEBUG - 2016-05-20 18:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:03:06 --> CSRF cookie sent
INFO - 2016-05-20 18:03:06 --> Input Class Initialized
INFO - 2016-05-20 18:03:06 --> Language Class Initialized
INFO - 2016-05-20 18:03:06 --> Loader Class Initialized
INFO - 2016-05-20 18:03:06 --> Helper loaded: form_helper
INFO - 2016-05-20 18:03:06 --> Database Driver Class Initialized
INFO - 2016-05-20 18:03:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:03:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:03:06 --> Email Class Initialized
INFO - 2016-05-20 18:03:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:03:06 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:03:06 --> Helper loaded: language_helper
INFO - 2016-05-20 18:03:06 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:03:06 --> Model Class Initialized
INFO - 2016-05-20 18:03:06 --> Helper loaded: date_helper
INFO - 2016-05-20 18:03:06 --> Controller Class Initialized
INFO - 2016-05-20 18:03:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 18:03:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:03:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 18:03:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 18:03:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 18:03:06 --> Model Class Initialized
INFO - 2016-05-20 18:03:06 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:03:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:03:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
ERROR - 2016-05-20 18:03:06 --> Could not find the language line "dashboard_3_units_button"
INFO - 2016-05-20 18:03:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 18:03:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:03:06 --> Final output sent to browser
DEBUG - 2016-05-20 18:03:06 --> Total execution time: 0.0641
INFO - 2016-05-20 18:03:20 --> Config Class Initialized
INFO - 2016-05-20 18:03:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:03:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:03:20 --> Utf8 Class Initialized
INFO - 2016-05-20 18:03:20 --> URI Class Initialized
INFO - 2016-05-20 18:03:20 --> Router Class Initialized
INFO - 2016-05-20 18:03:20 --> Output Class Initialized
INFO - 2016-05-20 18:03:20 --> Security Class Initialized
DEBUG - 2016-05-20 18:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:03:20 --> CSRF cookie sent
INFO - 2016-05-20 18:03:20 --> Input Class Initialized
INFO - 2016-05-20 18:03:20 --> Language Class Initialized
INFO - 2016-05-20 18:03:20 --> Loader Class Initialized
INFO - 2016-05-20 18:03:20 --> Helper loaded: form_helper
INFO - 2016-05-20 18:03:20 --> Database Driver Class Initialized
INFO - 2016-05-20 18:03:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:03:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:03:20 --> Email Class Initialized
INFO - 2016-05-20 18:03:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:03:20 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:03:20 --> Helper loaded: language_helper
INFO - 2016-05-20 18:03:20 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:03:20 --> Model Class Initialized
INFO - 2016-05-20 18:03:20 --> Helper loaded: date_helper
INFO - 2016-05-20 18:03:20 --> Controller Class Initialized
INFO - 2016-05-20 18:03:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 18:03:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:03:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 18:03:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 18:03:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 18:03:20 --> Model Class Initialized
INFO - 2016-05-20 18:03:20 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:03:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:03:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 18:03:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 18:03:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:03:20 --> Final output sent to browser
DEBUG - 2016-05-20 18:03:20 --> Total execution time: 0.0873
INFO - 2016-05-20 18:03:52 --> Config Class Initialized
INFO - 2016-05-20 18:03:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:03:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:03:52 --> Utf8 Class Initialized
INFO - 2016-05-20 18:03:52 --> URI Class Initialized
INFO - 2016-05-20 18:03:52 --> Router Class Initialized
INFO - 2016-05-20 18:03:52 --> Output Class Initialized
INFO - 2016-05-20 18:03:52 --> Security Class Initialized
DEBUG - 2016-05-20 18:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:03:52 --> CSRF cookie sent
INFO - 2016-05-20 18:03:52 --> Input Class Initialized
INFO - 2016-05-20 18:03:52 --> Language Class Initialized
ERROR - 2016-05-20 18:03:52 --> 404 Page Not Found: Diabet/add_values
INFO - 2016-05-20 18:04:10 --> Config Class Initialized
INFO - 2016-05-20 18:04:10 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:04:10 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:04:10 --> Utf8 Class Initialized
INFO - 2016-05-20 18:04:10 --> URI Class Initialized
INFO - 2016-05-20 18:04:10 --> Router Class Initialized
INFO - 2016-05-20 18:04:10 --> Output Class Initialized
INFO - 2016-05-20 18:04:10 --> Security Class Initialized
DEBUG - 2016-05-20 18:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:04:10 --> CSRF cookie sent
INFO - 2016-05-20 18:04:10 --> Input Class Initialized
INFO - 2016-05-20 18:04:10 --> Language Class Initialized
INFO - 2016-05-20 18:04:10 --> Loader Class Initialized
INFO - 2016-05-20 18:04:10 --> Helper loaded: form_helper
INFO - 2016-05-20 18:04:10 --> Database Driver Class Initialized
INFO - 2016-05-20 18:04:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:04:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:04:11 --> Email Class Initialized
INFO - 2016-05-20 18:04:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:04:11 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:04:11 --> Helper loaded: language_helper
INFO - 2016-05-20 18:04:11 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:04:11 --> Model Class Initialized
INFO - 2016-05-20 18:04:11 --> Helper loaded: date_helper
INFO - 2016-05-20 18:04:11 --> Controller Class Initialized
INFO - 2016-05-20 18:04:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 18:04:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:04:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 18:04:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 18:04:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 18:04:11 --> Model Class Initialized
INFO - 2016-05-20 18:04:11 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 18:04:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:04:11 --> Final output sent to browser
DEBUG - 2016-05-20 18:04:11 --> Total execution time: 0.0630
INFO - 2016-05-20 18:04:19 --> Config Class Initialized
INFO - 2016-05-20 18:04:19 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:04:19 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:04:19 --> Utf8 Class Initialized
INFO - 2016-05-20 18:04:19 --> URI Class Initialized
INFO - 2016-05-20 18:04:19 --> Router Class Initialized
INFO - 2016-05-20 18:04:19 --> Output Class Initialized
INFO - 2016-05-20 18:04:19 --> Security Class Initialized
DEBUG - 2016-05-20 18:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:04:19 --> CSRF cookie sent
INFO - 2016-05-20 18:04:19 --> Input Class Initialized
INFO - 2016-05-20 18:04:19 --> Language Class Initialized
INFO - 2016-05-20 18:04:19 --> Loader Class Initialized
INFO - 2016-05-20 18:04:19 --> Helper loaded: form_helper
INFO - 2016-05-20 18:04:19 --> Database Driver Class Initialized
INFO - 2016-05-20 18:04:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:04:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:04:19 --> Email Class Initialized
INFO - 2016-05-20 18:04:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:04:19 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:04:19 --> Helper loaded: language_helper
INFO - 2016-05-20 18:04:19 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:04:19 --> Model Class Initialized
INFO - 2016-05-20 18:04:19 --> Helper loaded: date_helper
INFO - 2016-05-20 18:04:19 --> Controller Class Initialized
INFO - 2016-05-20 18:04:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 18:04:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:04:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 18:04:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 18:04:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 18:04:19 --> Model Class Initialized
INFO - 2016-05-20 18:04:19 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:04:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:04:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 18:04:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 18:04:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:04:19 --> Final output sent to browser
DEBUG - 2016-05-20 18:04:19 --> Total execution time: 0.0265
INFO - 2016-05-20 18:05:20 --> Config Class Initialized
INFO - 2016-05-20 18:05:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:05:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:05:20 --> Utf8 Class Initialized
INFO - 2016-05-20 18:05:20 --> URI Class Initialized
INFO - 2016-05-20 18:05:20 --> Router Class Initialized
INFO - 2016-05-20 18:05:20 --> Output Class Initialized
INFO - 2016-05-20 18:05:20 --> Security Class Initialized
DEBUG - 2016-05-20 18:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:05:20 --> CSRF cookie sent
INFO - 2016-05-20 18:05:20 --> Input Class Initialized
INFO - 2016-05-20 18:05:20 --> Language Class Initialized
INFO - 2016-05-20 18:05:20 --> Loader Class Initialized
INFO - 2016-05-20 18:05:20 --> Helper loaded: form_helper
INFO - 2016-05-20 18:05:20 --> Database Driver Class Initialized
INFO - 2016-05-20 18:05:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:05:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:05:20 --> Email Class Initialized
INFO - 2016-05-20 18:05:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:05:20 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:05:20 --> Helper loaded: language_helper
INFO - 2016-05-20 18:05:20 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:05:20 --> Model Class Initialized
INFO - 2016-05-20 18:05:20 --> Helper loaded: date_helper
INFO - 2016-05-20 18:05:20 --> Controller Class Initialized
INFO - 2016-05-20 18:05:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 18:05:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:05:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 18:05:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 18:05:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 18:05:20 --> Model Class Initialized
INFO - 2016-05-20 18:05:20 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 18:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-20 18:05:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:05:20 --> Final output sent to browser
DEBUG - 2016-05-20 18:05:20 --> Total execution time: 0.0783
INFO - 2016-05-20 18:07:04 --> Config Class Initialized
INFO - 2016-05-20 18:07:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:07:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:07:04 --> Utf8 Class Initialized
INFO - 2016-05-20 18:07:04 --> URI Class Initialized
INFO - 2016-05-20 18:07:04 --> Router Class Initialized
INFO - 2016-05-20 18:07:04 --> Output Class Initialized
INFO - 2016-05-20 18:07:04 --> Security Class Initialized
DEBUG - 2016-05-20 18:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:07:04 --> CSRF cookie sent
INFO - 2016-05-20 18:07:04 --> Input Class Initialized
INFO - 2016-05-20 18:07:04 --> Language Class Initialized
INFO - 2016-05-20 18:07:04 --> Loader Class Initialized
INFO - 2016-05-20 18:07:04 --> Helper loaded: form_helper
INFO - 2016-05-20 18:07:04 --> Database Driver Class Initialized
INFO - 2016-05-20 18:07:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:07:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:07:04 --> Email Class Initialized
INFO - 2016-05-20 18:07:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:07:04 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:07:04 --> Helper loaded: language_helper
INFO - 2016-05-20 18:07:04 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:07:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:07:04 --> Model Class Initialized
INFO - 2016-05-20 18:07:04 --> Helper loaded: date_helper
INFO - 2016-05-20 18:07:04 --> Controller Class Initialized
INFO - 2016-05-20 18:07:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 18:07:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:07:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 18:07:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 18:07:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 18:07:04 --> Model Class Initialized
INFO - 2016-05-20 18:07:04 --> Helper loaded: languages_helper
INFO - 2016-05-20 18:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 18:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 18:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/add_values.php
INFO - 2016-05-20 18:07:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 18:07:04 --> Final output sent to browser
DEBUG - 2016-05-20 18:07:04 --> Total execution time: 0.0590
INFO - 2016-05-20 18:11:44 --> Config Class Initialized
INFO - 2016-05-20 18:11:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:11:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:11:44 --> Utf8 Class Initialized
INFO - 2016-05-20 18:11:44 --> URI Class Initialized
INFO - 2016-05-20 18:11:44 --> Router Class Initialized
INFO - 2016-05-20 18:11:44 --> Output Class Initialized
INFO - 2016-05-20 18:11:44 --> Security Class Initialized
DEBUG - 2016-05-20 18:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:11:44 --> CSRF cookie sent
INFO - 2016-05-20 18:11:44 --> Input Class Initialized
INFO - 2016-05-20 18:11:44 --> Language Class Initialized
INFO - 2016-05-20 18:11:44 --> Loader Class Initialized
INFO - 2016-05-20 18:11:44 --> Helper loaded: form_helper
INFO - 2016-05-20 18:11:44 --> Database Driver Class Initialized
INFO - 2016-05-20 18:11:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:11:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:11:44 --> Email Class Initialized
INFO - 2016-05-20 18:11:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:11:44 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:11:44 --> Helper loaded: language_helper
INFO - 2016-05-20 18:11:44 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:11:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:11:44 --> Model Class Initialized
INFO - 2016-05-20 18:11:44 --> Helper loaded: date_helper
INFO - 2016-05-20 18:11:44 --> Controller Class Initialized
DEBUG - 2016-05-20 18:11:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:11:44 --> Form Validation Class Initialized
INFO - 2016-05-20 18:11:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:11:45 --> Config Class Initialized
INFO - 2016-05-20 18:11:45 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:11:45 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:11:45 --> Utf8 Class Initialized
INFO - 2016-05-20 18:11:45 --> URI Class Initialized
INFO - 2016-05-20 18:11:45 --> Router Class Initialized
INFO - 2016-05-20 18:11:45 --> Output Class Initialized
INFO - 2016-05-20 18:11:45 --> Security Class Initialized
DEBUG - 2016-05-20 18:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:11:45 --> CSRF cookie sent
INFO - 2016-05-20 18:11:45 --> Input Class Initialized
INFO - 2016-05-20 18:11:45 --> Language Class Initialized
INFO - 2016-05-20 18:11:45 --> Loader Class Initialized
INFO - 2016-05-20 18:11:45 --> Helper loaded: form_helper
INFO - 2016-05-20 18:11:45 --> Database Driver Class Initialized
INFO - 2016-05-20 18:11:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:11:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:11:45 --> Email Class Initialized
INFO - 2016-05-20 18:11:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:11:45 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:11:45 --> Helper loaded: language_helper
INFO - 2016-05-20 18:11:45 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:11:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:11:45 --> Model Class Initialized
INFO - 2016-05-20 18:11:45 --> Helper loaded: date_helper
INFO - 2016-05-20 18:11:45 --> Controller Class Initialized
DEBUG - 2016-05-20 18:11:45 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:11:45 --> Form Validation Class Initialized
INFO - 2016-05-20 18:11:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:21:07 --> Config Class Initialized
INFO - 2016-05-20 18:21:07 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:21:07 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:21:07 --> Utf8 Class Initialized
INFO - 2016-05-20 18:21:07 --> URI Class Initialized
INFO - 2016-05-20 18:21:07 --> Router Class Initialized
INFO - 2016-05-20 18:21:07 --> Output Class Initialized
INFO - 2016-05-20 18:21:07 --> Security Class Initialized
DEBUG - 2016-05-20 18:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:21:07 --> CSRF cookie sent
INFO - 2016-05-20 18:21:07 --> Input Class Initialized
INFO - 2016-05-20 18:21:07 --> Language Class Initialized
INFO - 2016-05-20 18:21:07 --> Loader Class Initialized
INFO - 2016-05-20 18:21:07 --> Helper loaded: form_helper
INFO - 2016-05-20 18:21:07 --> Database Driver Class Initialized
INFO - 2016-05-20 18:21:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:21:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:21:07 --> Email Class Initialized
INFO - 2016-05-20 18:21:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:21:07 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:21:07 --> Helper loaded: language_helper
INFO - 2016-05-20 18:21:07 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:21:07 --> Model Class Initialized
INFO - 2016-05-20 18:21:07 --> Helper loaded: date_helper
INFO - 2016-05-20 18:21:07 --> Controller Class Initialized
DEBUG - 2016-05-20 18:21:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:21:07 --> Form Validation Class Initialized
INFO - 2016-05-20 18:21:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:21:08 --> Config Class Initialized
INFO - 2016-05-20 18:21:08 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:21:08 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:21:08 --> Utf8 Class Initialized
INFO - 2016-05-20 18:21:08 --> URI Class Initialized
INFO - 2016-05-20 18:21:08 --> Router Class Initialized
INFO - 2016-05-20 18:21:08 --> Output Class Initialized
INFO - 2016-05-20 18:21:08 --> Security Class Initialized
DEBUG - 2016-05-20 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:21:08 --> CSRF cookie sent
INFO - 2016-05-20 18:21:08 --> Input Class Initialized
INFO - 2016-05-20 18:21:08 --> Language Class Initialized
INFO - 2016-05-20 18:21:08 --> Loader Class Initialized
INFO - 2016-05-20 18:21:08 --> Helper loaded: form_helper
INFO - 2016-05-20 18:21:08 --> Database Driver Class Initialized
INFO - 2016-05-20 18:21:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:21:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:21:08 --> Email Class Initialized
INFO - 2016-05-20 18:21:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:21:08 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:21:08 --> Helper loaded: language_helper
INFO - 2016-05-20 18:21:08 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:21:08 --> Model Class Initialized
INFO - 2016-05-20 18:21:08 --> Helper loaded: date_helper
INFO - 2016-05-20 18:21:08 --> Controller Class Initialized
DEBUG - 2016-05-20 18:21:08 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:21:08 --> Form Validation Class Initialized
INFO - 2016-05-20 18:21:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:25:38 --> Config Class Initialized
INFO - 2016-05-20 18:25:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:25:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:25:38 --> Utf8 Class Initialized
INFO - 2016-05-20 18:25:38 --> URI Class Initialized
INFO - 2016-05-20 18:25:38 --> Router Class Initialized
INFO - 2016-05-20 18:25:38 --> Output Class Initialized
INFO - 2016-05-20 18:25:38 --> Security Class Initialized
DEBUG - 2016-05-20 18:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:25:38 --> CSRF cookie sent
INFO - 2016-05-20 18:25:38 --> Input Class Initialized
INFO - 2016-05-20 18:25:38 --> Language Class Initialized
INFO - 2016-05-20 18:25:38 --> Loader Class Initialized
INFO - 2016-05-20 18:25:38 --> Helper loaded: form_helper
INFO - 2016-05-20 18:25:38 --> Database Driver Class Initialized
INFO - 2016-05-20 18:25:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:25:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:25:38 --> Email Class Initialized
INFO - 2016-05-20 18:25:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:25:38 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:25:38 --> Helper loaded: language_helper
INFO - 2016-05-20 18:25:38 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:25:38 --> Model Class Initialized
INFO - 2016-05-20 18:25:38 --> Helper loaded: date_helper
INFO - 2016-05-20 18:25:38 --> Controller Class Initialized
DEBUG - 2016-05-20 18:25:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:25:38 --> Form Validation Class Initialized
INFO - 2016-05-20 18:25:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:25:38 --> Config Class Initialized
INFO - 2016-05-20 18:25:38 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:25:38 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:25:38 --> Utf8 Class Initialized
INFO - 2016-05-20 18:25:38 --> URI Class Initialized
INFO - 2016-05-20 18:25:38 --> Router Class Initialized
INFO - 2016-05-20 18:25:38 --> Output Class Initialized
INFO - 2016-05-20 18:25:38 --> Security Class Initialized
DEBUG - 2016-05-20 18:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:25:38 --> CSRF cookie sent
INFO - 2016-05-20 18:25:38 --> Input Class Initialized
INFO - 2016-05-20 18:25:38 --> Language Class Initialized
INFO - 2016-05-20 18:25:38 --> Loader Class Initialized
INFO - 2016-05-20 18:25:38 --> Helper loaded: form_helper
INFO - 2016-05-20 18:25:38 --> Database Driver Class Initialized
INFO - 2016-05-20 18:25:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:25:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:25:38 --> Email Class Initialized
INFO - 2016-05-20 18:25:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:25:38 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:25:38 --> Helper loaded: language_helper
INFO - 2016-05-20 18:25:38 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:25:38 --> Model Class Initialized
INFO - 2016-05-20 18:25:38 --> Helper loaded: date_helper
INFO - 2016-05-20 18:25:38 --> Controller Class Initialized
DEBUG - 2016-05-20 18:25:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:25:38 --> Form Validation Class Initialized
INFO - 2016-05-20 18:25:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:52:44 --> Config Class Initialized
INFO - 2016-05-20 18:52:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:52:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:52:44 --> Utf8 Class Initialized
INFO - 2016-05-20 18:52:44 --> URI Class Initialized
INFO - 2016-05-20 18:52:44 --> Router Class Initialized
INFO - 2016-05-20 18:52:44 --> Output Class Initialized
INFO - 2016-05-20 18:52:44 --> Security Class Initialized
DEBUG - 2016-05-20 18:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:52:44 --> CSRF cookie sent
INFO - 2016-05-20 18:52:44 --> Input Class Initialized
INFO - 2016-05-20 18:52:44 --> Language Class Initialized
INFO - 2016-05-20 18:52:44 --> Loader Class Initialized
INFO - 2016-05-20 18:52:44 --> Helper loaded: form_helper
INFO - 2016-05-20 18:52:44 --> Database Driver Class Initialized
INFO - 2016-05-20 18:52:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:52:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:52:44 --> Email Class Initialized
INFO - 2016-05-20 18:52:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:52:44 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:52:44 --> Helper loaded: language_helper
INFO - 2016-05-20 18:52:44 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:52:44 --> Model Class Initialized
INFO - 2016-05-20 18:52:44 --> Helper loaded: date_helper
INFO - 2016-05-20 18:52:44 --> Controller Class Initialized
DEBUG - 2016-05-20 18:52:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:52:44 --> Form Validation Class Initialized
INFO - 2016-05-20 18:52:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:52:44 --> Config Class Initialized
INFO - 2016-05-20 18:52:44 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:52:44 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:52:44 --> Utf8 Class Initialized
INFO - 2016-05-20 18:52:44 --> URI Class Initialized
INFO - 2016-05-20 18:52:44 --> Router Class Initialized
INFO - 2016-05-20 18:52:44 --> Output Class Initialized
INFO - 2016-05-20 18:52:44 --> Security Class Initialized
DEBUG - 2016-05-20 18:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:52:44 --> CSRF cookie sent
INFO - 2016-05-20 18:52:44 --> Input Class Initialized
INFO - 2016-05-20 18:52:44 --> Language Class Initialized
INFO - 2016-05-20 18:52:44 --> Loader Class Initialized
INFO - 2016-05-20 18:52:44 --> Helper loaded: form_helper
INFO - 2016-05-20 18:52:44 --> Database Driver Class Initialized
INFO - 2016-05-20 18:52:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:52:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:52:44 --> Email Class Initialized
INFO - 2016-05-20 18:52:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:52:44 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:52:44 --> Helper loaded: language_helper
INFO - 2016-05-20 18:52:44 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:52:44 --> Model Class Initialized
INFO - 2016-05-20 18:52:44 --> Helper loaded: date_helper
INFO - 2016-05-20 18:52:44 --> Controller Class Initialized
DEBUG - 2016-05-20 18:52:44 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:52:44 --> Form Validation Class Initialized
INFO - 2016-05-20 18:52:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:59:25 --> Config Class Initialized
INFO - 2016-05-20 18:59:25 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:59:25 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:59:25 --> Utf8 Class Initialized
INFO - 2016-05-20 18:59:25 --> URI Class Initialized
INFO - 2016-05-20 18:59:25 --> Router Class Initialized
INFO - 2016-05-20 18:59:25 --> Output Class Initialized
INFO - 2016-05-20 18:59:25 --> Security Class Initialized
DEBUG - 2016-05-20 18:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:59:25 --> CSRF cookie sent
INFO - 2016-05-20 18:59:25 --> Input Class Initialized
INFO - 2016-05-20 18:59:25 --> Language Class Initialized
INFO - 2016-05-20 18:59:25 --> Loader Class Initialized
INFO - 2016-05-20 18:59:25 --> Helper loaded: form_helper
INFO - 2016-05-20 18:59:25 --> Database Driver Class Initialized
INFO - 2016-05-20 18:59:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:59:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:59:25 --> Email Class Initialized
INFO - 2016-05-20 18:59:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:59:25 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:59:25 --> Helper loaded: language_helper
INFO - 2016-05-20 18:59:25 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:59:25 --> Model Class Initialized
INFO - 2016-05-20 18:59:25 --> Helper loaded: date_helper
INFO - 2016-05-20 18:59:25 --> Controller Class Initialized
DEBUG - 2016-05-20 18:59:25 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:59:25 --> Form Validation Class Initialized
INFO - 2016-05-20 18:59:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 18:59:26 --> Config Class Initialized
INFO - 2016-05-20 18:59:26 --> Hooks Class Initialized
DEBUG - 2016-05-20 18:59:26 --> UTF-8 Support Enabled
INFO - 2016-05-20 18:59:26 --> Utf8 Class Initialized
INFO - 2016-05-20 18:59:26 --> URI Class Initialized
INFO - 2016-05-20 18:59:26 --> Router Class Initialized
INFO - 2016-05-20 18:59:26 --> Output Class Initialized
INFO - 2016-05-20 18:59:26 --> Security Class Initialized
DEBUG - 2016-05-20 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 18:59:26 --> CSRF cookie sent
INFO - 2016-05-20 18:59:26 --> Input Class Initialized
INFO - 2016-05-20 18:59:26 --> Language Class Initialized
INFO - 2016-05-20 18:59:26 --> Loader Class Initialized
INFO - 2016-05-20 18:59:26 --> Helper loaded: form_helper
INFO - 2016-05-20 18:59:26 --> Database Driver Class Initialized
INFO - 2016-05-20 18:59:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 18:59:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 18:59:26 --> Email Class Initialized
INFO - 2016-05-20 18:59:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 18:59:26 --> Helper loaded: cookie_helper
INFO - 2016-05-20 18:59:26 --> Helper loaded: language_helper
INFO - 2016-05-20 18:59:26 --> Helper loaded: url_helper
DEBUG - 2016-05-20 18:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:59:26 --> Model Class Initialized
INFO - 2016-05-20 18:59:26 --> Helper loaded: date_helper
INFO - 2016-05-20 18:59:26 --> Controller Class Initialized
DEBUG - 2016-05-20 18:59:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 18:59:26 --> Form Validation Class Initialized
INFO - 2016-05-20 18:59:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:00:01 --> Config Class Initialized
INFO - 2016-05-20 19:00:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:00:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:00:01 --> Utf8 Class Initialized
INFO - 2016-05-20 19:00:01 --> URI Class Initialized
INFO - 2016-05-20 19:00:01 --> Router Class Initialized
INFO - 2016-05-20 19:00:01 --> Output Class Initialized
INFO - 2016-05-20 19:00:01 --> Security Class Initialized
DEBUG - 2016-05-20 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:00:01 --> CSRF cookie sent
INFO - 2016-05-20 19:00:01 --> Input Class Initialized
INFO - 2016-05-20 19:00:01 --> Language Class Initialized
INFO - 2016-05-20 19:00:01 --> Loader Class Initialized
INFO - 2016-05-20 19:00:01 --> Helper loaded: form_helper
INFO - 2016-05-20 19:00:01 --> Database Driver Class Initialized
INFO - 2016-05-20 19:00:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:00:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:00:01 --> Email Class Initialized
INFO - 2016-05-20 19:00:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:00:01 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:00:01 --> Helper loaded: language_helper
INFO - 2016-05-20 19:00:01 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:01 --> Model Class Initialized
INFO - 2016-05-20 19:00:01 --> Helper loaded: date_helper
INFO - 2016-05-20 19:00:01 --> Controller Class Initialized
DEBUG - 2016-05-20 19:00:01 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:01 --> Form Validation Class Initialized
INFO - 2016-05-20 19:00:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:00:01 --> Config Class Initialized
INFO - 2016-05-20 19:00:01 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:00:01 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:00:01 --> Utf8 Class Initialized
INFO - 2016-05-20 19:00:01 --> URI Class Initialized
INFO - 2016-05-20 19:00:01 --> Router Class Initialized
INFO - 2016-05-20 19:00:01 --> Output Class Initialized
INFO - 2016-05-20 19:00:01 --> Security Class Initialized
DEBUG - 2016-05-20 19:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:00:01 --> CSRF cookie sent
INFO - 2016-05-20 19:00:01 --> Input Class Initialized
INFO - 2016-05-20 19:00:01 --> Language Class Initialized
INFO - 2016-05-20 19:00:01 --> Loader Class Initialized
INFO - 2016-05-20 19:00:01 --> Helper loaded: form_helper
INFO - 2016-05-20 19:00:01 --> Database Driver Class Initialized
INFO - 2016-05-20 19:00:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:00:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:00:01 --> Email Class Initialized
INFO - 2016-05-20 19:00:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:00:01 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:00:01 --> Helper loaded: language_helper
INFO - 2016-05-20 19:00:01 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:01 --> Model Class Initialized
INFO - 2016-05-20 19:00:01 --> Helper loaded: date_helper
INFO - 2016-05-20 19:00:01 --> Controller Class Initialized
DEBUG - 2016-05-20 19:00:01 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:01 --> Form Validation Class Initialized
INFO - 2016-05-20 19:00:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:00:20 --> Config Class Initialized
INFO - 2016-05-20 19:00:20 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:00:20 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:00:20 --> Utf8 Class Initialized
INFO - 2016-05-20 19:00:20 --> URI Class Initialized
DEBUG - 2016-05-20 19:00:20 --> No URI present. Default controller set.
INFO - 2016-05-20 19:00:20 --> Router Class Initialized
INFO - 2016-05-20 19:00:20 --> Output Class Initialized
INFO - 2016-05-20 19:00:20 --> Security Class Initialized
DEBUG - 2016-05-20 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:00:20 --> CSRF cookie sent
INFO - 2016-05-20 19:00:20 --> Input Class Initialized
INFO - 2016-05-20 19:00:20 --> Language Class Initialized
INFO - 2016-05-20 19:00:20 --> Loader Class Initialized
INFO - 2016-05-20 19:00:20 --> Helper loaded: form_helper
INFO - 2016-05-20 19:00:20 --> Database Driver Class Initialized
INFO - 2016-05-20 19:00:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:00:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:00:20 --> Email Class Initialized
INFO - 2016-05-20 19:00:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:00:20 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:00:20 --> Helper loaded: language_helper
INFO - 2016-05-20 19:00:20 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:20 --> Model Class Initialized
INFO - 2016-05-20 19:00:20 --> Helper loaded: date_helper
INFO - 2016-05-20 19:00:20 --> Controller Class Initialized
INFO - 2016-05-20 19:00:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:00:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:00:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:00:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:00:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 19:00:21 --> Config Class Initialized
INFO - 2016-05-20 19:00:21 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:00:21 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:00:21 --> Utf8 Class Initialized
INFO - 2016-05-20 19:00:21 --> URI Class Initialized
INFO - 2016-05-20 19:00:21 --> Router Class Initialized
INFO - 2016-05-20 19:00:21 --> Output Class Initialized
INFO - 2016-05-20 19:00:21 --> Security Class Initialized
DEBUG - 2016-05-20 19:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:00:21 --> CSRF cookie sent
INFO - 2016-05-20 19:00:21 --> Input Class Initialized
INFO - 2016-05-20 19:00:21 --> Language Class Initialized
INFO - 2016-05-20 19:00:21 --> Loader Class Initialized
INFO - 2016-05-20 19:00:21 --> Helper loaded: form_helper
INFO - 2016-05-20 19:00:21 --> Database Driver Class Initialized
INFO - 2016-05-20 19:00:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:00:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:00:21 --> Email Class Initialized
INFO - 2016-05-20 19:00:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:00:21 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:00:21 --> Helper loaded: language_helper
INFO - 2016-05-20 19:00:21 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:00:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:21 --> Model Class Initialized
INFO - 2016-05-20 19:00:21 --> Helper loaded: date_helper
INFO - 2016-05-20 19:00:21 --> Controller Class Initialized
INFO - 2016-05-20 19:00:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:00:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:00:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:00:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:00:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 19:00:21 --> Model Class Initialized
INFO - 2016-05-20 19:00:21 --> Helper loaded: languages_helper
INFO - 2016-05-20 19:00:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 19:00:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 19:00:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 19:00:21 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 19:00:21 --> Final output sent to browser
DEBUG - 2016-05-20 19:00:21 --> Total execution time: 0.1044
INFO - 2016-05-20 19:00:35 --> Config Class Initialized
INFO - 2016-05-20 19:00:35 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:00:35 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:00:35 --> Utf8 Class Initialized
INFO - 2016-05-20 19:00:35 --> URI Class Initialized
INFO - 2016-05-20 19:00:35 --> Router Class Initialized
INFO - 2016-05-20 19:00:35 --> Output Class Initialized
INFO - 2016-05-20 19:00:35 --> Security Class Initialized
DEBUG - 2016-05-20 19:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:00:35 --> CSRF cookie sent
INFO - 2016-05-20 19:00:35 --> Input Class Initialized
INFO - 2016-05-20 19:00:35 --> Language Class Initialized
INFO - 2016-05-20 19:00:35 --> Loader Class Initialized
INFO - 2016-05-20 19:00:35 --> Helper loaded: form_helper
INFO - 2016-05-20 19:00:35 --> Database Driver Class Initialized
INFO - 2016-05-20 19:00:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:00:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:00:35 --> Email Class Initialized
INFO - 2016-05-20 19:00:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:00:35 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:00:35 --> Helper loaded: language_helper
INFO - 2016-05-20 19:00:35 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:35 --> Model Class Initialized
INFO - 2016-05-20 19:00:35 --> Helper loaded: date_helper
INFO - 2016-05-20 19:00:35 --> Controller Class Initialized
INFO - 2016-05-20 19:00:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:00:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:00:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:00:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:00:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 19:00:35 --> Model Class Initialized
INFO - 2016-05-20 19:00:35 --> Helper loaded: languages_helper
INFO - 2016-05-20 19:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 19:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 19:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/access.php
INFO - 2016-05-20 19:00:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 19:00:35 --> Final output sent to browser
DEBUG - 2016-05-20 19:00:35 --> Total execution time: 0.1903
INFO - 2016-05-20 19:00:42 --> Config Class Initialized
INFO - 2016-05-20 19:00:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:00:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:00:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:00:42 --> URI Class Initialized
INFO - 2016-05-20 19:00:42 --> Router Class Initialized
INFO - 2016-05-20 19:00:42 --> Output Class Initialized
INFO - 2016-05-20 19:00:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:00:42 --> CSRF cookie sent
INFO - 2016-05-20 19:00:42 --> Input Class Initialized
INFO - 2016-05-20 19:00:42 --> Language Class Initialized
INFO - 2016-05-20 19:00:42 --> Loader Class Initialized
INFO - 2016-05-20 19:00:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:00:42 --> Database Driver Class Initialized
INFO - 2016-05-20 19:00:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:00:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:00:42 --> Email Class Initialized
INFO - 2016-05-20 19:00:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:00:42 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:00:42 --> Helper loaded: language_helper
INFO - 2016-05-20 19:00:42 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:42 --> Model Class Initialized
INFO - 2016-05-20 19:00:42 --> Helper loaded: date_helper
INFO - 2016-05-20 19:00:42 --> Controller Class Initialized
INFO - 2016-05-20 19:00:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:00:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:00:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:00:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:00:42 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 19:00:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:00:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:00:42 --> Helper loaded: string_helper
INFO - 2016-05-20 19:00:42 --> Helper loaded: languages_helper
INFO - 2016-05-20 19:00:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 19:00:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 19:00:42 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 19:00:42 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 19:00:42 --> Final output sent to browser
DEBUG - 2016-05-20 19:00:42 --> Total execution time: 0.1253
INFO - 2016-05-20 19:01:23 --> Config Class Initialized
INFO - 2016-05-20 19:01:23 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:01:23 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:01:23 --> Utf8 Class Initialized
INFO - 2016-05-20 19:01:23 --> URI Class Initialized
INFO - 2016-05-20 19:01:23 --> Router Class Initialized
INFO - 2016-05-20 19:01:23 --> Output Class Initialized
INFO - 2016-05-20 19:01:23 --> Security Class Initialized
DEBUG - 2016-05-20 19:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:01:23 --> CSRF cookie sent
INFO - 2016-05-20 19:01:23 --> CSRF token verified
INFO - 2016-05-20 19:01:23 --> Input Class Initialized
INFO - 2016-05-20 19:01:23 --> Language Class Initialized
INFO - 2016-05-20 19:01:23 --> Loader Class Initialized
INFO - 2016-05-20 19:01:23 --> Helper loaded: form_helper
INFO - 2016-05-20 19:01:23 --> Database Driver Class Initialized
INFO - 2016-05-20 19:01:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:01:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:01:23 --> Email Class Initialized
INFO - 2016-05-20 19:01:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:01:23 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:01:23 --> Helper loaded: language_helper
INFO - 2016-05-20 19:01:23 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:01:23 --> Model Class Initialized
INFO - 2016-05-20 19:01:23 --> Helper loaded: date_helper
INFO - 2016-05-20 19:01:23 --> Controller Class Initialized
INFO - 2016-05-20 19:01:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:01:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:01:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:01:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:01:23 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 19:01:23 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:01:23 --> Form Validation Class Initialized
INFO - 2016-05-20 19:01:29 --> Config Class Initialized
INFO - 2016-05-20 19:01:29 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:01:29 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:01:29 --> Utf8 Class Initialized
INFO - 2016-05-20 19:01:29 --> URI Class Initialized
INFO - 2016-05-20 19:01:29 --> Router Class Initialized
INFO - 2016-05-20 19:01:29 --> Output Class Initialized
INFO - 2016-05-20 19:01:29 --> Security Class Initialized
DEBUG - 2016-05-20 19:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:01:29 --> CSRF cookie sent
INFO - 2016-05-20 19:01:29 --> Input Class Initialized
INFO - 2016-05-20 19:01:29 --> Language Class Initialized
INFO - 2016-05-20 19:01:29 --> Loader Class Initialized
INFO - 2016-05-20 19:01:29 --> Helper loaded: form_helper
INFO - 2016-05-20 19:01:29 --> Database Driver Class Initialized
INFO - 2016-05-20 19:01:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:01:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:01:29 --> Email Class Initialized
INFO - 2016-05-20 19:01:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:01:29 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:01:29 --> Helper loaded: language_helper
INFO - 2016-05-20 19:01:29 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:01:29 --> Model Class Initialized
INFO - 2016-05-20 19:01:29 --> Helper loaded: date_helper
INFO - 2016-05-20 19:01:29 --> Controller Class Initialized
INFO - 2016-05-20 19:01:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:01:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:01:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:01:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:01:29 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 19:01:29 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:01:29 --> Form Validation Class Initialized
INFO - 2016-05-20 19:01:29 --> Helper loaded: string_helper
INFO - 2016-05-20 19:01:29 --> Helper loaded: languages_helper
INFO - 2016-05-20 19:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 19:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 19:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/edit_user.php
INFO - 2016-05-20 19:01:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 19:01:29 --> Final output sent to browser
DEBUG - 2016-05-20 19:01:29 --> Total execution time: 0.0681
INFO - 2016-05-20 19:03:52 --> Config Class Initialized
INFO - 2016-05-20 19:03:52 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:03:52 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:03:52 --> Utf8 Class Initialized
INFO - 2016-05-20 19:03:52 --> URI Class Initialized
DEBUG - 2016-05-20 19:03:52 --> No URI present. Default controller set.
INFO - 2016-05-20 19:03:52 --> Router Class Initialized
INFO - 2016-05-20 19:03:52 --> Output Class Initialized
INFO - 2016-05-20 19:03:52 --> Security Class Initialized
DEBUG - 2016-05-20 19:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:03:52 --> CSRF cookie sent
INFO - 2016-05-20 19:03:52 --> Input Class Initialized
INFO - 2016-05-20 19:03:52 --> Language Class Initialized
INFO - 2016-05-20 19:03:52 --> Loader Class Initialized
INFO - 2016-05-20 19:03:52 --> Helper loaded: form_helper
INFO - 2016-05-20 19:03:52 --> Database Driver Class Initialized
INFO - 2016-05-20 19:03:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:03:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:03:52 --> Email Class Initialized
INFO - 2016-05-20 19:03:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:03:52 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:03:52 --> Helper loaded: language_helper
INFO - 2016-05-20 19:03:52 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:03:52 --> Model Class Initialized
INFO - 2016-05-20 19:03:52 --> Helper loaded: date_helper
INFO - 2016-05-20 19:03:52 --> Controller Class Initialized
INFO - 2016-05-20 19:03:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:03:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:03:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:03:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:03:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 19:03:53 --> Config Class Initialized
INFO - 2016-05-20 19:03:53 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:03:53 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:03:53 --> Utf8 Class Initialized
INFO - 2016-05-20 19:03:53 --> URI Class Initialized
INFO - 2016-05-20 19:03:53 --> Router Class Initialized
INFO - 2016-05-20 19:03:53 --> Output Class Initialized
INFO - 2016-05-20 19:03:53 --> Security Class Initialized
DEBUG - 2016-05-20 19:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:03:53 --> CSRF cookie sent
INFO - 2016-05-20 19:03:53 --> Input Class Initialized
INFO - 2016-05-20 19:03:53 --> Language Class Initialized
INFO - 2016-05-20 19:03:53 --> Loader Class Initialized
INFO - 2016-05-20 19:03:53 --> Helper loaded: form_helper
INFO - 2016-05-20 19:03:53 --> Database Driver Class Initialized
INFO - 2016-05-20 19:03:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:03:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:03:53 --> Email Class Initialized
INFO - 2016-05-20 19:03:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:03:53 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:03:53 --> Helper loaded: language_helper
INFO - 2016-05-20 19:03:53 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:03:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:03:53 --> Model Class Initialized
INFO - 2016-05-20 19:03:53 --> Helper loaded: date_helper
INFO - 2016-05-20 19:03:53 --> Controller Class Initialized
INFO - 2016-05-20 19:03:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:03:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:03:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:03:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:03:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 19:03:53 --> Model Class Initialized
INFO - 2016-05-20 19:03:53 --> Helper loaded: languages_helper
INFO - 2016-05-20 19:03:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-05-20 19:03:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-05-20 19:03:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-05-20 19:03:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-05-20 19:03:53 --> Final output sent to browser
DEBUG - 2016-05-20 19:03:53 --> Total execution time: 0.0506
INFO - 2016-05-20 19:04:03 --> Config Class Initialized
INFO - 2016-05-20 19:04:03 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:04:03 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:04:03 --> Utf8 Class Initialized
INFO - 2016-05-20 19:04:03 --> URI Class Initialized
INFO - 2016-05-20 19:04:03 --> Router Class Initialized
INFO - 2016-05-20 19:04:03 --> Output Class Initialized
INFO - 2016-05-20 19:04:03 --> Security Class Initialized
DEBUG - 2016-05-20 19:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:04:03 --> CSRF cookie sent
INFO - 2016-05-20 19:04:03 --> Input Class Initialized
INFO - 2016-05-20 19:04:03 --> Language Class Initialized
INFO - 2016-05-20 19:04:03 --> Loader Class Initialized
INFO - 2016-05-20 19:04:03 --> Helper loaded: form_helper
INFO - 2016-05-20 19:04:03 --> Database Driver Class Initialized
INFO - 2016-05-20 19:04:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:04:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:04:03 --> Email Class Initialized
INFO - 2016-05-20 19:04:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:04:03 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:04:03 --> Helper loaded: language_helper
INFO - 2016-05-20 19:04:03 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:04:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:04:03 --> Model Class Initialized
INFO - 2016-05-20 19:04:03 --> Helper loaded: date_helper
INFO - 2016-05-20 19:04:03 --> Controller Class Initialized
INFO - 2016-05-20 19:04:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:04:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:04:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:04:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:04:03 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 19:04:03 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:04:03 --> Form Validation Class Initialized
INFO - 2016-05-20 19:04:04 --> Config Class Initialized
INFO - 2016-05-20 19:04:04 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:04:04 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:04:04 --> Utf8 Class Initialized
INFO - 2016-05-20 19:04:04 --> URI Class Initialized
INFO - 2016-05-20 19:04:04 --> Router Class Initialized
INFO - 2016-05-20 19:04:04 --> Output Class Initialized
INFO - 2016-05-20 19:04:04 --> Security Class Initialized
DEBUG - 2016-05-20 19:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:04:04 --> CSRF cookie sent
INFO - 2016-05-20 19:04:04 --> Input Class Initialized
INFO - 2016-05-20 19:04:04 --> Language Class Initialized
INFO - 2016-05-20 19:04:04 --> Loader Class Initialized
INFO - 2016-05-20 19:04:04 --> Helper loaded: form_helper
INFO - 2016-05-20 19:04:04 --> Database Driver Class Initialized
INFO - 2016-05-20 19:04:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:04:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:04:04 --> Email Class Initialized
INFO - 2016-05-20 19:04:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:04:04 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:04:04 --> Helper loaded: language_helper
INFO - 2016-05-20 19:04:04 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:04:04 --> Model Class Initialized
INFO - 2016-05-20 19:04:04 --> Helper loaded: date_helper
INFO - 2016-05-20 19:04:04 --> Controller Class Initialized
INFO - 2016-05-20 19:04:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:04:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:04:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:04:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:04:04 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-05-20 19:04:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:04:04 --> Form Validation Class Initialized
INFO - 2016-05-20 19:04:04 --> Helper loaded: languages_helper
INFO - 2016-05-20 19:04:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 19:04:04 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-05-20 19:04:04 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 19:04:04 --> Final output sent to browser
DEBUG - 2016-05-20 19:04:04 --> Total execution time: 0.0675
INFO - 2016-05-20 19:04:05 --> Config Class Initialized
INFO - 2016-05-20 19:04:05 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:04:05 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:04:05 --> Utf8 Class Initialized
INFO - 2016-05-20 19:04:05 --> URI Class Initialized
INFO - 2016-05-20 19:04:05 --> Router Class Initialized
INFO - 2016-05-20 19:04:05 --> Output Class Initialized
INFO - 2016-05-20 19:04:05 --> Security Class Initialized
DEBUG - 2016-05-20 19:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:04:05 --> CSRF cookie sent
INFO - 2016-05-20 19:04:05 --> Input Class Initialized
INFO - 2016-05-20 19:04:05 --> Language Class Initialized
ERROR - 2016-05-20 19:04:05 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 19:04:12 --> Config Class Initialized
INFO - 2016-05-20 19:04:12 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:04:12 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:04:12 --> Utf8 Class Initialized
INFO - 2016-05-20 19:04:12 --> URI Class Initialized
DEBUG - 2016-05-20 19:04:12 --> No URI present. Default controller set.
INFO - 2016-05-20 19:04:12 --> Router Class Initialized
INFO - 2016-05-20 19:04:12 --> Output Class Initialized
INFO - 2016-05-20 19:04:12 --> Security Class Initialized
DEBUG - 2016-05-20 19:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:04:12 --> CSRF cookie sent
INFO - 2016-05-20 19:04:12 --> Input Class Initialized
INFO - 2016-05-20 19:04:12 --> Language Class Initialized
INFO - 2016-05-20 19:04:12 --> Loader Class Initialized
INFO - 2016-05-20 19:04:12 --> Helper loaded: form_helper
INFO - 2016-05-20 19:04:12 --> Database Driver Class Initialized
INFO - 2016-05-20 19:04:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:04:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:04:12 --> Email Class Initialized
INFO - 2016-05-20 19:04:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:04:12 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:04:12 --> Helper loaded: language_helper
INFO - 2016-05-20 19:04:12 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:04:12 --> Model Class Initialized
INFO - 2016-05-20 19:04:12 --> Helper loaded: date_helper
INFO - 2016-05-20 19:04:12 --> Controller Class Initialized
INFO - 2016-05-20 19:04:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-05-20 19:04:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:04:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-05-20 19:04:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-05-20 19:04:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-05-20 19:04:12 --> Helper loaded: languages_helper
INFO - 2016-05-20 19:04:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-05-20 19:04:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-05-20 19:04:12 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-05-20 19:04:12 --> Final output sent to browser
DEBUG - 2016-05-20 19:04:12 --> Total execution time: 0.0918
INFO - 2016-05-20 19:04:13 --> Config Class Initialized
INFO - 2016-05-20 19:04:13 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:04:13 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:04:13 --> Utf8 Class Initialized
INFO - 2016-05-20 19:04:13 --> URI Class Initialized
INFO - 2016-05-20 19:04:13 --> Router Class Initialized
INFO - 2016-05-20 19:04:13 --> Output Class Initialized
INFO - 2016-05-20 19:04:13 --> Security Class Initialized
DEBUG - 2016-05-20 19:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:04:13 --> CSRF cookie sent
INFO - 2016-05-20 19:04:13 --> Input Class Initialized
INFO - 2016-05-20 19:04:13 --> Language Class Initialized
ERROR - 2016-05-20 19:04:13 --> 404 Page Not Found: Public/js
INFO - 2016-05-20 19:16:33 --> Config Class Initialized
INFO - 2016-05-20 19:16:33 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:33 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:33 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:33 --> URI Class Initialized
INFO - 2016-05-20 19:16:33 --> Router Class Initialized
INFO - 2016-05-20 19:16:33 --> Output Class Initialized
INFO - 2016-05-20 19:16:33 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:33 --> CSRF cookie sent
INFO - 2016-05-20 19:16:33 --> Input Class Initialized
INFO - 2016-05-20 19:16:33 --> Language Class Initialized
INFO - 2016-05-20 19:16:33 --> Loader Class Initialized
INFO - 2016-05-20 19:16:33 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:33 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:16:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:16:33 --> Email Class Initialized
INFO - 2016-05-20 19:16:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:16:33 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:16:33 --> Helper loaded: language_helper
INFO - 2016-05-20 19:16:33 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:16:33 --> Model Class Initialized
INFO - 2016-05-20 19:16:33 --> Helper loaded: date_helper
INFO - 2016-05-20 19:16:33 --> Controller Class Initialized
DEBUG - 2016-05-20 19:16:33 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:16:33 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:16:40 --> Config Class Initialized
INFO - 2016-05-20 19:16:40 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:16:40 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:16:40 --> Utf8 Class Initialized
INFO - 2016-05-20 19:16:40 --> URI Class Initialized
INFO - 2016-05-20 19:16:40 --> Router Class Initialized
INFO - 2016-05-20 19:16:40 --> Output Class Initialized
INFO - 2016-05-20 19:16:40 --> Security Class Initialized
DEBUG - 2016-05-20 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:16:40 --> CSRF cookie sent
INFO - 2016-05-20 19:16:40 --> Input Class Initialized
INFO - 2016-05-20 19:16:40 --> Language Class Initialized
INFO - 2016-05-20 19:16:40 --> Loader Class Initialized
INFO - 2016-05-20 19:16:40 --> Helper loaded: form_helper
INFO - 2016-05-20 19:16:40 --> Database Driver Class Initialized
INFO - 2016-05-20 19:16:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:16:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:16:40 --> Email Class Initialized
INFO - 2016-05-20 19:16:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:16:40 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:16:40 --> Helper loaded: language_helper
INFO - 2016-05-20 19:16:40 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:16:40 --> Model Class Initialized
INFO - 2016-05-20 19:16:40 --> Helper loaded: date_helper
INFO - 2016-05-20 19:16:40 --> Controller Class Initialized
DEBUG - 2016-05-20 19:16:40 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:16:40 --> Form Validation Class Initialized
INFO - 2016-05-20 19:16:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:26:39 --> Config Class Initialized
INFO - 2016-05-20 19:26:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:39 --> URI Class Initialized
INFO - 2016-05-20 19:26:39 --> Router Class Initialized
INFO - 2016-05-20 19:26:39 --> Output Class Initialized
INFO - 2016-05-20 19:26:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:39 --> CSRF cookie sent
INFO - 2016-05-20 19:26:39 --> Input Class Initialized
INFO - 2016-05-20 19:26:39 --> Language Class Initialized
INFO - 2016-05-20 19:26:39 --> Loader Class Initialized
INFO - 2016-05-20 19:26:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:39 --> Database Driver Class Initialized
INFO - 2016-05-20 19:26:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:26:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:26:39 --> Email Class Initialized
INFO - 2016-05-20 19:26:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:26:39 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:26:39 --> Helper loaded: language_helper
INFO - 2016-05-20 19:26:39 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:26:39 --> Model Class Initialized
INFO - 2016-05-20 19:26:39 --> Helper loaded: date_helper
INFO - 2016-05-20 19:26:39 --> Controller Class Initialized
DEBUG - 2016-05-20 19:26:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:26:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:26:39 --> Config Class Initialized
INFO - 2016-05-20 19:26:39 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:26:39 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:26:39 --> Utf8 Class Initialized
INFO - 2016-05-20 19:26:39 --> URI Class Initialized
INFO - 2016-05-20 19:26:39 --> Router Class Initialized
INFO - 2016-05-20 19:26:39 --> Output Class Initialized
INFO - 2016-05-20 19:26:39 --> Security Class Initialized
DEBUG - 2016-05-20 19:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:26:39 --> CSRF cookie sent
INFO - 2016-05-20 19:26:39 --> Input Class Initialized
INFO - 2016-05-20 19:26:39 --> Language Class Initialized
INFO - 2016-05-20 19:26:39 --> Loader Class Initialized
INFO - 2016-05-20 19:26:39 --> Helper loaded: form_helper
INFO - 2016-05-20 19:26:39 --> Database Driver Class Initialized
INFO - 2016-05-20 19:26:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:26:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:26:39 --> Email Class Initialized
INFO - 2016-05-20 19:26:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:26:39 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:26:39 --> Helper loaded: language_helper
INFO - 2016-05-20 19:26:39 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:26:39 --> Model Class Initialized
INFO - 2016-05-20 19:26:39 --> Helper loaded: date_helper
INFO - 2016-05-20 19:26:39 --> Controller Class Initialized
DEBUG - 2016-05-20 19:26:39 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:26:39 --> Form Validation Class Initialized
INFO - 2016-05-20 19:26:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:36:42 --> Config Class Initialized
INFO - 2016-05-20 19:36:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:36:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:36:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:36:42 --> URI Class Initialized
INFO - 2016-05-20 19:36:42 --> Router Class Initialized
INFO - 2016-05-20 19:36:42 --> Output Class Initialized
INFO - 2016-05-20 19:36:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:36:42 --> CSRF cookie sent
INFO - 2016-05-20 19:36:42 --> Input Class Initialized
INFO - 2016-05-20 19:36:42 --> Language Class Initialized
INFO - 2016-05-20 19:36:42 --> Loader Class Initialized
INFO - 2016-05-20 19:36:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:36:42 --> Database Driver Class Initialized
INFO - 2016-05-20 19:36:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:36:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:36:42 --> Email Class Initialized
INFO - 2016-05-20 19:36:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:36:42 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:36:42 --> Helper loaded: language_helper
INFO - 2016-05-20 19:36:42 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:36:42 --> Model Class Initialized
INFO - 2016-05-20 19:36:42 --> Helper loaded: date_helper
INFO - 2016-05-20 19:36:42 --> Controller Class Initialized
DEBUG - 2016-05-20 19:36:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:36:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:36:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-05-20 19:36:42 --> Config Class Initialized
INFO - 2016-05-20 19:36:42 --> Hooks Class Initialized
DEBUG - 2016-05-20 19:36:42 --> UTF-8 Support Enabled
INFO - 2016-05-20 19:36:42 --> Utf8 Class Initialized
INFO - 2016-05-20 19:36:42 --> URI Class Initialized
INFO - 2016-05-20 19:36:42 --> Router Class Initialized
INFO - 2016-05-20 19:36:42 --> Output Class Initialized
INFO - 2016-05-20 19:36:42 --> Security Class Initialized
DEBUG - 2016-05-20 19:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-05-20 19:36:42 --> CSRF cookie sent
INFO - 2016-05-20 19:36:42 --> Input Class Initialized
INFO - 2016-05-20 19:36:42 --> Language Class Initialized
INFO - 2016-05-20 19:36:42 --> Loader Class Initialized
INFO - 2016-05-20 19:36:42 --> Helper loaded: form_helper
INFO - 2016-05-20 19:36:42 --> Database Driver Class Initialized
INFO - 2016-05-20 19:36:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-05-20 19:36:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-05-20 19:36:42 --> Email Class Initialized
INFO - 2016-05-20 19:36:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-05-20 19:36:42 --> Helper loaded: cookie_helper
INFO - 2016-05-20 19:36:42 --> Helper loaded: language_helper
INFO - 2016-05-20 19:36:42 --> Helper loaded: url_helper
DEBUG - 2016-05-20 19:36:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:36:42 --> Model Class Initialized
INFO - 2016-05-20 19:36:42 --> Helper loaded: date_helper
INFO - 2016-05-20 19:36:42 --> Controller Class Initialized
DEBUG - 2016-05-20 19:36:42 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-05-20 19:36:42 --> Form Validation Class Initialized
INFO - 2016-05-20 19:36:42 --> Language file loaded: language/romanian/auth_lang.php
