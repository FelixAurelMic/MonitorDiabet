<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-22 04:06:42 --> Config Class Initialized
INFO - 2016-06-22 04:06:42 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:06:42 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:06:42 --> Utf8 Class Initialized
INFO - 2016-06-22 04:06:42 --> URI Class Initialized
DEBUG - 2016-06-22 04:06:42 --> No URI present. Default controller set.
INFO - 2016-06-22 04:06:42 --> Router Class Initialized
INFO - 2016-06-22 04:06:42 --> Output Class Initialized
INFO - 2016-06-22 04:06:42 --> Security Class Initialized
DEBUG - 2016-06-22 04:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:06:42 --> Input Class Initialized
INFO - 2016-06-22 04:06:42 --> Language Class Initialized
INFO - 2016-06-22 04:06:42 --> Loader Class Initialized
INFO - 2016-06-22 04:06:42 --> Helper loaded: form_helper
INFO - 2016-06-22 04:06:43 --> Database Driver Class Initialized
INFO - 2016-06-22 04:06:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:06:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:06:43 --> Email Class Initialized
INFO - 2016-06-22 04:06:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:06:43 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:06:43 --> Helper loaded: language_helper
INFO - 2016-06-22 04:06:43 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:06:43 --> Model Class Initialized
INFO - 2016-06-22 04:06:43 --> Helper loaded: date_helper
INFO - 2016-06-22 04:06:43 --> Controller Class Initialized
INFO - 2016-06-22 04:06:43 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:06:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:06:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:06:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:06:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:06:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:06:43 --> Model Class Initialized
INFO - 2016-06-22 07:06:43 --> Form Validation Class Initialized
INFO - 2016-06-22 07:06:43 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-22 07:06:43 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-22 07:06:43 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-22 07:06:43 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-22 07:06:43 --> Final output sent to browser
DEBUG - 2016-06-22 07:06:43 --> Total execution time: 1.5594
INFO - 2016-06-22 04:06:52 --> Config Class Initialized
INFO - 2016-06-22 04:06:52 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:06:52 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:06:52 --> Utf8 Class Initialized
INFO - 2016-06-22 04:06:52 --> URI Class Initialized
INFO - 2016-06-22 04:06:52 --> Router Class Initialized
INFO - 2016-06-22 04:06:52 --> Output Class Initialized
INFO - 2016-06-22 04:06:52 --> Security Class Initialized
DEBUG - 2016-06-22 04:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:06:52 --> Input Class Initialized
INFO - 2016-06-22 04:06:52 --> Language Class Initialized
INFO - 2016-06-22 04:06:52 --> Loader Class Initialized
INFO - 2016-06-22 04:06:52 --> Helper loaded: form_helper
INFO - 2016-06-22 04:06:52 --> Database Driver Class Initialized
INFO - 2016-06-22 04:06:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:06:52 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:06:52 --> Email Class Initialized
INFO - 2016-06-22 04:06:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:06:52 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:06:52 --> Helper loaded: language_helper
INFO - 2016-06-22 04:06:52 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:06:52 --> Model Class Initialized
INFO - 2016-06-22 04:06:52 --> Helper loaded: date_helper
INFO - 2016-06-22 04:06:52 --> Controller Class Initialized
INFO - 2016-06-22 04:06:52 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:06:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:06:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:06:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:06:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:06:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:06:52 --> Model Class Initialized
INFO - 2016-06-22 07:06:52 --> Final output sent to browser
DEBUG - 2016-06-22 07:06:52 --> Total execution time: 0.1333
INFO - 2016-06-22 04:06:52 --> Config Class Initialized
INFO - 2016-06-22 04:06:52 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:06:52 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:06:52 --> Utf8 Class Initialized
INFO - 2016-06-22 04:06:52 --> URI Class Initialized
INFO - 2016-06-22 04:06:52 --> Router Class Initialized
INFO - 2016-06-22 04:06:52 --> Output Class Initialized
INFO - 2016-06-22 04:06:52 --> Security Class Initialized
DEBUG - 2016-06-22 04:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:06:52 --> Input Class Initialized
INFO - 2016-06-22 04:06:52 --> Language Class Initialized
ERROR - 2016-06-22 04:06:52 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-22 04:06:53 --> Config Class Initialized
INFO - 2016-06-22 04:06:53 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:06:53 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:06:53 --> Utf8 Class Initialized
INFO - 2016-06-22 04:06:53 --> URI Class Initialized
INFO - 2016-06-22 04:06:53 --> Router Class Initialized
INFO - 2016-06-22 04:06:53 --> Output Class Initialized
INFO - 2016-06-22 04:06:53 --> Security Class Initialized
DEBUG - 2016-06-22 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:06:53 --> Input Class Initialized
INFO - 2016-06-22 04:06:53 --> Language Class Initialized
ERROR - 2016-06-22 04:06:53 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-22 04:07:43 --> Config Class Initialized
INFO - 2016-06-22 04:07:43 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:07:43 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:07:43 --> Utf8 Class Initialized
INFO - 2016-06-22 04:07:43 --> URI Class Initialized
INFO - 2016-06-22 04:07:43 --> Router Class Initialized
INFO - 2016-06-22 04:07:43 --> Output Class Initialized
INFO - 2016-06-22 04:07:43 --> Security Class Initialized
DEBUG - 2016-06-22 04:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:07:43 --> Input Class Initialized
INFO - 2016-06-22 04:07:43 --> Language Class Initialized
INFO - 2016-06-22 04:07:43 --> Loader Class Initialized
INFO - 2016-06-22 04:07:43 --> Helper loaded: form_helper
INFO - 2016-06-22 04:07:43 --> Database Driver Class Initialized
INFO - 2016-06-22 04:07:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:07:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:07:43 --> Email Class Initialized
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:07:43 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:07:43 --> Helper loaded: language_helper
INFO - 2016-06-22 04:07:43 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:07:43 --> Model Class Initialized
INFO - 2016-06-22 04:07:43 --> Helper loaded: date_helper
INFO - 2016-06-22 04:07:43 --> Controller Class Initialized
INFO - 2016-06-22 04:07:43 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-22 07:07:43 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-22 07:07:43 --> Form Validation Class Initialized
DEBUG - 2016-06-22 07:07:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:07:43 --> Config Class Initialized
INFO - 2016-06-22 04:07:43 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:07:43 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:07:43 --> Utf8 Class Initialized
INFO - 2016-06-22 04:07:43 --> URI Class Initialized
DEBUG - 2016-06-22 04:07:43 --> No URI present. Default controller set.
INFO - 2016-06-22 04:07:43 --> Router Class Initialized
INFO - 2016-06-22 04:07:43 --> Output Class Initialized
INFO - 2016-06-22 04:07:43 --> Security Class Initialized
DEBUG - 2016-06-22 04:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:07:43 --> Input Class Initialized
INFO - 2016-06-22 04:07:43 --> Language Class Initialized
INFO - 2016-06-22 04:07:43 --> Loader Class Initialized
INFO - 2016-06-22 04:07:43 --> Helper loaded: form_helper
INFO - 2016-06-22 04:07:43 --> Database Driver Class Initialized
INFO - 2016-06-22 04:07:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:07:43 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:07:43 --> Email Class Initialized
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:07:43 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:07:43 --> Helper loaded: language_helper
INFO - 2016-06-22 04:07:43 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:07:43 --> Model Class Initialized
INFO - 2016-06-22 04:07:43 --> Helper loaded: date_helper
INFO - 2016-06-22 04:07:43 --> Controller Class Initialized
INFO - 2016-06-22 04:07:43 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:07:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 04:07:44 --> Config Class Initialized
INFO - 2016-06-22 04:07:44 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:07:44 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:07:44 --> Utf8 Class Initialized
INFO - 2016-06-22 04:07:44 --> URI Class Initialized
INFO - 2016-06-22 04:07:44 --> Router Class Initialized
INFO - 2016-06-22 04:07:44 --> Output Class Initialized
INFO - 2016-06-22 04:07:44 --> Security Class Initialized
DEBUG - 2016-06-22 04:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:07:44 --> Input Class Initialized
INFO - 2016-06-22 04:07:44 --> Language Class Initialized
INFO - 2016-06-22 04:07:44 --> Loader Class Initialized
INFO - 2016-06-22 04:07:44 --> Helper loaded: form_helper
INFO - 2016-06-22 04:07:44 --> Database Driver Class Initialized
INFO - 2016-06-22 04:07:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:07:44 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:07:44 --> Email Class Initialized
INFO - 2016-06-22 04:07:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:07:44 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:07:44 --> Helper loaded: language_helper
INFO - 2016-06-22 04:07:44 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:07:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:07:44 --> Model Class Initialized
INFO - 2016-06-22 04:07:44 --> Helper loaded: date_helper
INFO - 2016-06-22 04:07:44 --> Controller Class Initialized
INFO - 2016-06-22 04:07:44 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:07:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:07:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:07:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:07:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:07:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:07:44 --> Model Class Initialized
INFO - 2016-06-22 07:07:44 --> Form Validation Class Initialized
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-22 07:07:44 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:07:44 --> Final output sent to browser
DEBUG - 2016-06-22 07:07:44 --> Total execution time: 0.2545
INFO - 2016-06-22 04:07:47 --> Config Class Initialized
INFO - 2016-06-22 04:07:47 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:07:47 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:07:47 --> Utf8 Class Initialized
INFO - 2016-06-22 04:07:47 --> URI Class Initialized
INFO - 2016-06-22 04:07:47 --> Router Class Initialized
INFO - 2016-06-22 04:07:47 --> Output Class Initialized
INFO - 2016-06-22 04:07:47 --> Security Class Initialized
DEBUG - 2016-06-22 04:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:07:47 --> Input Class Initialized
INFO - 2016-06-22 04:07:47 --> Language Class Initialized
INFO - 2016-06-22 04:07:47 --> Loader Class Initialized
INFO - 2016-06-22 04:07:47 --> Helper loaded: form_helper
INFO - 2016-06-22 04:07:47 --> Database Driver Class Initialized
INFO - 2016-06-22 04:07:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:07:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:07:47 --> Email Class Initialized
INFO - 2016-06-22 04:07:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:07:47 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:07:47 --> Helper loaded: language_helper
INFO - 2016-06-22 04:07:47 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:07:47 --> Model Class Initialized
INFO - 2016-06-22 04:07:47 --> Helper loaded: date_helper
INFO - 2016-06-22 04:07:47 --> Controller Class Initialized
INFO - 2016-06-22 04:07:47 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:07:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:07:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:07:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:07:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:07:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:07:47 --> Model Class Initialized
INFO - 2016-06-22 07:07:47 --> Form Validation Class Initialized
INFO - 2016-06-22 07:07:47 --> Final output sent to browser
DEBUG - 2016-06-22 07:07:47 --> Total execution time: 0.0841
INFO - 2016-06-22 04:07:54 --> Config Class Initialized
INFO - 2016-06-22 04:07:54 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:07:54 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:07:54 --> Utf8 Class Initialized
INFO - 2016-06-22 04:07:54 --> URI Class Initialized
INFO - 2016-06-22 04:07:54 --> Router Class Initialized
INFO - 2016-06-22 04:07:54 --> Output Class Initialized
INFO - 2016-06-22 04:07:54 --> Security Class Initialized
DEBUG - 2016-06-22 04:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:07:54 --> Input Class Initialized
INFO - 2016-06-22 04:07:54 --> Language Class Initialized
INFO - 2016-06-22 04:07:54 --> Loader Class Initialized
INFO - 2016-06-22 04:07:54 --> Helper loaded: form_helper
INFO - 2016-06-22 04:07:54 --> Database Driver Class Initialized
INFO - 2016-06-22 04:07:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:07:54 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:07:54 --> Email Class Initialized
INFO - 2016-06-22 04:07:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:07:54 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:07:54 --> Helper loaded: language_helper
INFO - 2016-06-22 04:07:54 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:07:54 --> Model Class Initialized
INFO - 2016-06-22 04:07:54 --> Helper loaded: date_helper
INFO - 2016-06-22 04:07:54 --> Controller Class Initialized
INFO - 2016-06-22 04:07:54 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:07:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:07:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:07:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:07:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:07:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:07:54 --> Model Class Initialized
INFO - 2016-06-22 07:07:54 --> Form Validation Class Initialized
INFO - 2016-06-22 07:07:54 --> Helper loaded: sort_array_helper
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/adaugare_date_glicemie.php
INFO - 2016-06-22 07:07:54 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:07:54 --> Final output sent to browser
DEBUG - 2016-06-22 07:07:54 --> Total execution time: 0.1136
INFO - 2016-06-22 04:08:12 --> Config Class Initialized
INFO - 2016-06-22 04:08:12 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:08:12 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:08:12 --> Utf8 Class Initialized
INFO - 2016-06-22 04:08:12 --> URI Class Initialized
INFO - 2016-06-22 04:08:12 --> Router Class Initialized
INFO - 2016-06-22 04:08:12 --> Output Class Initialized
INFO - 2016-06-22 04:08:13 --> Security Class Initialized
DEBUG - 2016-06-22 04:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:08:13 --> Input Class Initialized
INFO - 2016-06-22 04:08:13 --> Language Class Initialized
INFO - 2016-06-22 04:08:13 --> Loader Class Initialized
INFO - 2016-06-22 04:08:13 --> Helper loaded: form_helper
INFO - 2016-06-22 04:08:13 --> Database Driver Class Initialized
INFO - 2016-06-22 04:08:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:08:13 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:08:13 --> Email Class Initialized
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:08:13 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:08:13 --> Helper loaded: language_helper
INFO - 2016-06-22 04:08:13 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:08:13 --> Model Class Initialized
INFO - 2016-06-22 04:08:13 --> Helper loaded: date_helper
INFO - 2016-06-22 04:08:13 --> Controller Class Initialized
INFO - 2016-06-22 04:08:13 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:08:13 --> Model Class Initialized
INFO - 2016-06-22 07:08:13 --> Form Validation Class Initialized
DEBUG - 2016-06-22 07:08:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:08:13 --> Config Class Initialized
INFO - 2016-06-22 04:08:13 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:08:13 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:08:13 --> Utf8 Class Initialized
INFO - 2016-06-22 04:08:13 --> URI Class Initialized
INFO - 2016-06-22 04:08:13 --> Router Class Initialized
INFO - 2016-06-22 04:08:13 --> Output Class Initialized
INFO - 2016-06-22 04:08:13 --> Security Class Initialized
DEBUG - 2016-06-22 04:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:08:13 --> Input Class Initialized
INFO - 2016-06-22 04:08:13 --> Language Class Initialized
INFO - 2016-06-22 04:08:13 --> Loader Class Initialized
INFO - 2016-06-22 04:08:13 --> Helper loaded: form_helper
INFO - 2016-06-22 04:08:13 --> Database Driver Class Initialized
INFO - 2016-06-22 04:08:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:08:13 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:08:13 --> Email Class Initialized
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:08:13 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:08:13 --> Helper loaded: language_helper
INFO - 2016-06-22 04:08:13 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:08:13 --> Model Class Initialized
INFO - 2016-06-22 04:08:13 --> Helper loaded: date_helper
INFO - 2016-06-22 04:08:13 --> Controller Class Initialized
INFO - 2016-06-22 04:08:13 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:08:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:08:13 --> Model Class Initialized
INFO - 2016-06-22 07:08:13 --> Form Validation Class Initialized
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/home.php
INFO - 2016-06-22 07:08:13 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:08:13 --> Final output sent to browser
DEBUG - 2016-06-22 07:08:13 --> Total execution time: 0.2673
INFO - 2016-06-22 04:08:15 --> Config Class Initialized
INFO - 2016-06-22 04:08:15 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:08:15 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:08:15 --> Utf8 Class Initialized
INFO - 2016-06-22 04:08:15 --> URI Class Initialized
INFO - 2016-06-22 04:08:15 --> Router Class Initialized
INFO - 2016-06-22 04:08:15 --> Output Class Initialized
INFO - 2016-06-22 04:08:15 --> Security Class Initialized
DEBUG - 2016-06-22 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:08:15 --> Input Class Initialized
INFO - 2016-06-22 04:08:15 --> Language Class Initialized
INFO - 2016-06-22 04:08:15 --> Loader Class Initialized
INFO - 2016-06-22 04:08:15 --> Helper loaded: form_helper
INFO - 2016-06-22 04:08:15 --> Database Driver Class Initialized
INFO - 2016-06-22 04:08:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:08:15 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:08:15 --> Email Class Initialized
INFO - 2016-06-22 04:08:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:08:15 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:08:15 --> Helper loaded: language_helper
INFO - 2016-06-22 04:08:15 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:08:15 --> Model Class Initialized
INFO - 2016-06-22 04:08:15 --> Helper loaded: date_helper
INFO - 2016-06-22 04:08:15 --> Controller Class Initialized
INFO - 2016-06-22 04:08:15 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:08:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:08:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:08:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:08:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:08:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:08:15 --> Model Class Initialized
INFO - 2016-06-22 07:08:15 --> Form Validation Class Initialized
INFO - 2016-06-22 07:08:15 --> Final output sent to browser
DEBUG - 2016-06-22 07:08:15 --> Total execution time: 0.2519
INFO - 2016-06-22 04:08:52 --> Config Class Initialized
INFO - 2016-06-22 04:08:52 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:08:52 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:08:52 --> Utf8 Class Initialized
INFO - 2016-06-22 04:08:52 --> URI Class Initialized
INFO - 2016-06-22 04:08:52 --> Router Class Initialized
INFO - 2016-06-22 04:08:52 --> Output Class Initialized
INFO - 2016-06-22 04:08:52 --> Security Class Initialized
DEBUG - 2016-06-22 04:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:08:52 --> Input Class Initialized
INFO - 2016-06-22 04:08:52 --> Language Class Initialized
INFO - 2016-06-22 04:08:52 --> Loader Class Initialized
INFO - 2016-06-22 04:08:52 --> Helper loaded: form_helper
INFO - 2016-06-22 04:08:52 --> Database Driver Class Initialized
INFO - 2016-06-22 04:08:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:08:52 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:08:52 --> Email Class Initialized
INFO - 2016-06-22 04:08:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:08:52 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:08:52 --> Helper loaded: language_helper
INFO - 2016-06-22 04:08:52 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:08:52 --> Model Class Initialized
INFO - 2016-06-22 04:08:52 --> Helper loaded: date_helper
INFO - 2016-06-22 04:08:52 --> Controller Class Initialized
INFO - 2016-06-22 04:08:52 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:08:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:08:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:08:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:08:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:08:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:08:52 --> Model Class Initialized
INFO - 2016-06-22 07:08:52 --> Form Validation Class Initialized
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:08:52 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:08:52 --> Final output sent to browser
DEBUG - 2016-06-22 07:08:52 --> Total execution time: 0.1430
INFO - 2016-06-22 04:09:00 --> Config Class Initialized
INFO - 2016-06-22 04:09:00 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:00 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:00 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:00 --> URI Class Initialized
INFO - 2016-06-22 04:09:00 --> Router Class Initialized
INFO - 2016-06-22 04:09:00 --> Output Class Initialized
INFO - 2016-06-22 04:09:00 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:00 --> Input Class Initialized
INFO - 2016-06-22 04:09:00 --> Language Class Initialized
INFO - 2016-06-22 04:09:00 --> Loader Class Initialized
INFO - 2016-06-22 04:09:00 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:00 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:00 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:00 --> Email Class Initialized
INFO - 2016-06-22 04:09:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:00 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:00 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:00 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:00 --> Model Class Initialized
INFO - 2016-06-22 04:09:00 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:00 --> Controller Class Initialized
INFO - 2016-06-22 04:09:00 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:00 --> Model Class Initialized
INFO - 2016-06-22 07:09:00 --> Form Validation Class Initialized
INFO - 2016-06-22 04:09:00 --> Config Class Initialized
INFO - 2016-06-22 04:09:00 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:00 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:00 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:00 --> URI Class Initialized
INFO - 2016-06-22 04:09:00 --> Router Class Initialized
INFO - 2016-06-22 04:09:00 --> Output Class Initialized
INFO - 2016-06-22 04:09:01 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:01 --> Input Class Initialized
INFO - 2016-06-22 04:09:01 --> Language Class Initialized
INFO - 2016-06-22 04:09:01 --> Loader Class Initialized
INFO - 2016-06-22 04:09:01 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:01 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:01 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:01 --> Email Class Initialized
INFO - 2016-06-22 04:09:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:01 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:01 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:01 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:01 --> Model Class Initialized
INFO - 2016-06-22 04:09:01 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:01 --> Controller Class Initialized
INFO - 2016-06-22 04:09:01 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:01 --> Model Class Initialized
INFO - 2016-06-22 07:09:01 --> Form Validation Class Initialized
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:09:01 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:09:01 --> Final output sent to browser
DEBUG - 2016-06-22 07:09:01 --> Total execution time: 0.0991
INFO - 2016-06-22 04:09:05 --> Config Class Initialized
INFO - 2016-06-22 04:09:05 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:05 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:05 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:05 --> URI Class Initialized
INFO - 2016-06-22 04:09:05 --> Router Class Initialized
INFO - 2016-06-22 04:09:05 --> Output Class Initialized
INFO - 2016-06-22 04:09:05 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:05 --> Input Class Initialized
INFO - 2016-06-22 04:09:05 --> Language Class Initialized
INFO - 2016-06-22 04:09:06 --> Loader Class Initialized
INFO - 2016-06-22 04:09:06 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:06 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:06 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:06 --> Email Class Initialized
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:06 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:06 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:06 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:06 --> Model Class Initialized
INFO - 2016-06-22 04:09:06 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:06 --> Controller Class Initialized
INFO - 2016-06-22 04:09:06 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:06 --> Model Class Initialized
INFO - 2016-06-22 07:09:06 --> Form Validation Class Initialized
INFO - 2016-06-22 04:09:06 --> Config Class Initialized
INFO - 2016-06-22 04:09:06 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:06 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:06 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:06 --> URI Class Initialized
INFO - 2016-06-22 04:09:06 --> Router Class Initialized
INFO - 2016-06-22 04:09:06 --> Output Class Initialized
INFO - 2016-06-22 04:09:06 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:06 --> Input Class Initialized
INFO - 2016-06-22 04:09:06 --> Language Class Initialized
INFO - 2016-06-22 04:09:06 --> Loader Class Initialized
INFO - 2016-06-22 04:09:06 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:06 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:06 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:06 --> Email Class Initialized
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:06 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:06 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:06 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:06 --> Model Class Initialized
INFO - 2016-06-22 04:09:06 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:06 --> Controller Class Initialized
INFO - 2016-06-22 04:09:06 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:06 --> Model Class Initialized
INFO - 2016-06-22 07:09:06 --> Form Validation Class Initialized
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:09:06 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:09:06 --> Final output sent to browser
DEBUG - 2016-06-22 07:09:06 --> Total execution time: 0.0967
INFO - 2016-06-22 04:09:16 --> Config Class Initialized
INFO - 2016-06-22 04:09:16 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:16 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:16 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:16 --> URI Class Initialized
INFO - 2016-06-22 04:09:16 --> Router Class Initialized
INFO - 2016-06-22 04:09:16 --> Output Class Initialized
INFO - 2016-06-22 04:09:16 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:16 --> Input Class Initialized
INFO - 2016-06-22 04:09:16 --> Language Class Initialized
INFO - 2016-06-22 04:09:16 --> Loader Class Initialized
INFO - 2016-06-22 04:09:16 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:16 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:16 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:16 --> Email Class Initialized
INFO - 2016-06-22 04:09:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:16 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:16 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:16 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:16 --> Model Class Initialized
INFO - 2016-06-22 04:09:16 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:16 --> Controller Class Initialized
INFO - 2016-06-22 04:09:16 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:16 --> Model Class Initialized
INFO - 2016-06-22 07:09:16 --> Form Validation Class Initialized
INFO - 2016-06-22 04:09:17 --> Config Class Initialized
INFO - 2016-06-22 04:09:17 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:17 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:17 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:17 --> URI Class Initialized
INFO - 2016-06-22 04:09:17 --> Router Class Initialized
INFO - 2016-06-22 04:09:17 --> Output Class Initialized
INFO - 2016-06-22 04:09:17 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:17 --> Input Class Initialized
INFO - 2016-06-22 04:09:17 --> Language Class Initialized
INFO - 2016-06-22 04:09:17 --> Loader Class Initialized
INFO - 2016-06-22 04:09:17 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:17 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:17 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:17 --> Email Class Initialized
INFO - 2016-06-22 04:09:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:17 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:17 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:17 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:17 --> Model Class Initialized
INFO - 2016-06-22 04:09:17 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:17 --> Controller Class Initialized
INFO - 2016-06-22 04:09:17 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:17 --> Model Class Initialized
INFO - 2016-06-22 07:09:17 --> Form Validation Class Initialized
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:09:17 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:09:17 --> Final output sent to browser
DEBUG - 2016-06-22 07:09:17 --> Total execution time: 0.0931
INFO - 2016-06-22 04:09:21 --> Config Class Initialized
INFO - 2016-06-22 04:09:21 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:21 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:21 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:21 --> URI Class Initialized
INFO - 2016-06-22 04:09:21 --> Router Class Initialized
INFO - 2016-06-22 04:09:21 --> Output Class Initialized
INFO - 2016-06-22 04:09:21 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:21 --> Input Class Initialized
INFO - 2016-06-22 04:09:21 --> Language Class Initialized
INFO - 2016-06-22 04:09:21 --> Loader Class Initialized
INFO - 2016-06-22 04:09:21 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:21 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:21 --> Email Class Initialized
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:21 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:21 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:21 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:21 --> Model Class Initialized
INFO - 2016-06-22 04:09:21 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:21 --> Controller Class Initialized
INFO - 2016-06-22 04:09:21 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:21 --> Model Class Initialized
INFO - 2016-06-22 07:09:21 --> Form Validation Class Initialized
INFO - 2016-06-22 04:09:21 --> Config Class Initialized
INFO - 2016-06-22 04:09:21 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:21 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:21 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:21 --> URI Class Initialized
INFO - 2016-06-22 04:09:21 --> Router Class Initialized
INFO - 2016-06-22 04:09:21 --> Output Class Initialized
INFO - 2016-06-22 04:09:21 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:21 --> Input Class Initialized
INFO - 2016-06-22 04:09:21 --> Language Class Initialized
INFO - 2016-06-22 04:09:21 --> Loader Class Initialized
INFO - 2016-06-22 04:09:21 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:21 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:21 --> Email Class Initialized
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:21 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:21 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:21 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:21 --> Model Class Initialized
INFO - 2016-06-22 04:09:21 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:21 --> Controller Class Initialized
INFO - 2016-06-22 04:09:21 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:21 --> Model Class Initialized
INFO - 2016-06-22 07:09:21 --> Form Validation Class Initialized
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:09:21 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:09:21 --> Final output sent to browser
DEBUG - 2016-06-22 07:09:21 --> Total execution time: 0.0973
INFO - 2016-06-22 04:09:25 --> Config Class Initialized
INFO - 2016-06-22 04:09:25 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:25 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:25 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:25 --> URI Class Initialized
INFO - 2016-06-22 04:09:25 --> Router Class Initialized
INFO - 2016-06-22 04:09:25 --> Output Class Initialized
INFO - 2016-06-22 04:09:25 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:25 --> Input Class Initialized
INFO - 2016-06-22 04:09:25 --> Language Class Initialized
INFO - 2016-06-22 04:09:25 --> Loader Class Initialized
INFO - 2016-06-22 04:09:25 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:25 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:25 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:25 --> Email Class Initialized
INFO - 2016-06-22 04:09:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:25 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:25 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:25 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:25 --> Model Class Initialized
INFO - 2016-06-22 04:09:25 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:25 --> Controller Class Initialized
INFO - 2016-06-22 04:09:25 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:25 --> Model Class Initialized
INFO - 2016-06-22 07:09:25 --> Form Validation Class Initialized
INFO - 2016-06-22 04:09:26 --> Config Class Initialized
INFO - 2016-06-22 04:09:26 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:26 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:26 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:26 --> URI Class Initialized
INFO - 2016-06-22 04:09:26 --> Router Class Initialized
INFO - 2016-06-22 04:09:26 --> Output Class Initialized
INFO - 2016-06-22 04:09:26 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:26 --> Input Class Initialized
INFO - 2016-06-22 04:09:26 --> Language Class Initialized
INFO - 2016-06-22 04:09:26 --> Loader Class Initialized
INFO - 2016-06-22 04:09:26 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:26 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:26 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:26 --> Email Class Initialized
INFO - 2016-06-22 04:09:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:26 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:26 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:26 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:26 --> Model Class Initialized
INFO - 2016-06-22 04:09:26 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:26 --> Controller Class Initialized
INFO - 2016-06-22 04:09:26 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:26 --> Model Class Initialized
INFO - 2016-06-22 07:09:26 --> Form Validation Class Initialized
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:09:26 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:09:26 --> Final output sent to browser
DEBUG - 2016-06-22 07:09:26 --> Total execution time: 0.0992
INFO - 2016-06-22 04:09:29 --> Config Class Initialized
INFO - 2016-06-22 04:09:29 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:29 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:29 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:29 --> URI Class Initialized
INFO - 2016-06-22 04:09:29 --> Router Class Initialized
INFO - 2016-06-22 04:09:29 --> Output Class Initialized
INFO - 2016-06-22 04:09:29 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:29 --> Input Class Initialized
INFO - 2016-06-22 04:09:29 --> Language Class Initialized
INFO - 2016-06-22 04:09:29 --> Loader Class Initialized
INFO - 2016-06-22 04:09:29 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:29 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:29 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:29 --> Email Class Initialized
INFO - 2016-06-22 04:09:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:29 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:29 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:29 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:29 --> Model Class Initialized
INFO - 2016-06-22 04:09:29 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:29 --> Controller Class Initialized
INFO - 2016-06-22 04:09:29 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:29 --> Model Class Initialized
INFO - 2016-06-22 07:09:29 --> Form Validation Class Initialized
INFO - 2016-06-22 04:09:29 --> Config Class Initialized
INFO - 2016-06-22 04:09:29 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:29 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:29 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:29 --> URI Class Initialized
INFO - 2016-06-22 04:09:29 --> Router Class Initialized
INFO - 2016-06-22 04:09:29 --> Output Class Initialized
INFO - 2016-06-22 04:09:29 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:29 --> Input Class Initialized
INFO - 2016-06-22 04:09:29 --> Language Class Initialized
INFO - 2016-06-22 04:09:29 --> Loader Class Initialized
INFO - 2016-06-22 04:09:29 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:29 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:30 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:30 --> Email Class Initialized
INFO - 2016-06-22 04:09:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:30 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:30 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:30 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:30 --> Model Class Initialized
INFO - 2016-06-22 04:09:30 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:30 --> Controller Class Initialized
INFO - 2016-06-22 04:09:30 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:30 --> Model Class Initialized
INFO - 2016-06-22 07:09:30 --> Form Validation Class Initialized
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:09:30 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:09:30 --> Final output sent to browser
DEBUG - 2016-06-22 07:09:30 --> Total execution time: 0.0956
INFO - 2016-06-22 04:09:45 --> Config Class Initialized
INFO - 2016-06-22 04:09:45 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:45 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:45 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:45 --> URI Class Initialized
INFO - 2016-06-22 04:09:45 --> Router Class Initialized
INFO - 2016-06-22 04:09:45 --> Output Class Initialized
INFO - 2016-06-22 04:09:45 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:45 --> Input Class Initialized
INFO - 2016-06-22 04:09:45 --> Language Class Initialized
INFO - 2016-06-22 04:09:45 --> Loader Class Initialized
INFO - 2016-06-22 04:09:45 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:45 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:45 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:45 --> Email Class Initialized
INFO - 2016-06-22 04:09:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:45 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:45 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:45 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:45 --> Model Class Initialized
INFO - 2016-06-22 04:09:45 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:45 --> Controller Class Initialized
INFO - 2016-06-22 04:09:45 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:45 --> Model Class Initialized
INFO - 2016-06-22 07:09:45 --> Form Validation Class Initialized
DEBUG - 2016-06-22 07:09:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-22 07:09:45 --> Email class already loaded. Second attempt ignored.
INFO - 2016-06-22 07:09:46 --> Language file loaded: language/romanian/email_lang.php
INFO - 2016-06-22 04:09:47 --> Config Class Initialized
INFO - 2016-06-22 04:09:47 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:09:47 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:09:47 --> Utf8 Class Initialized
INFO - 2016-06-22 04:09:47 --> URI Class Initialized
INFO - 2016-06-22 04:09:47 --> Router Class Initialized
INFO - 2016-06-22 04:09:47 --> Output Class Initialized
INFO - 2016-06-22 04:09:47 --> Security Class Initialized
DEBUG - 2016-06-22 04:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:09:47 --> Input Class Initialized
INFO - 2016-06-22 04:09:47 --> Language Class Initialized
INFO - 2016-06-22 04:09:47 --> Loader Class Initialized
INFO - 2016-06-22 04:09:47 --> Helper loaded: form_helper
INFO - 2016-06-22 04:09:47 --> Database Driver Class Initialized
INFO - 2016-06-22 04:09:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:09:47 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:09:47 --> Email Class Initialized
INFO - 2016-06-22 04:09:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:09:47 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:09:47 --> Helper loaded: language_helper
INFO - 2016-06-22 04:09:47 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:09:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:09:47 --> Model Class Initialized
INFO - 2016-06-22 04:09:47 --> Helper loaded: date_helper
INFO - 2016-06-22 04:09:47 --> Controller Class Initialized
INFO - 2016-06-22 04:09:47 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:09:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:09:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:09:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:09:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:09:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:09:47 --> Model Class Initialized
INFO - 2016-06-22 07:09:47 --> Form Validation Class Initialized
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/header.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/menu/logout.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/left_bar.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/editare_privilegii.php
INFO - 2016-06-22 07:09:47 --> File loaded: /home/diabet/public_html/application/views/user_area/res/footer.php
INFO - 2016-06-22 07:09:47 --> Final output sent to browser
DEBUG - 2016-06-22 07:09:47 --> Total execution time: 0.1102
INFO - 2016-06-22 04:11:07 --> Config Class Initialized
INFO - 2016-06-22 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:11:07 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:11:07 --> Utf8 Class Initialized
INFO - 2016-06-22 04:11:07 --> URI Class Initialized
INFO - 2016-06-22 04:11:07 --> Router Class Initialized
INFO - 2016-06-22 04:11:07 --> Output Class Initialized
INFO - 2016-06-22 04:11:07 --> Security Class Initialized
DEBUG - 2016-06-22 04:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:11:07 --> Input Class Initialized
INFO - 2016-06-22 04:11:07 --> Language Class Initialized
INFO - 2016-06-22 04:11:07 --> Loader Class Initialized
INFO - 2016-06-22 04:11:07 --> Helper loaded: form_helper
INFO - 2016-06-22 04:11:07 --> Database Driver Class Initialized
INFO - 2016-06-22 04:11:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:11:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:11:07 --> Email Class Initialized
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:11:07 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:11:07 --> Helper loaded: language_helper
INFO - 2016-06-22 04:11:07 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:11:07 --> Model Class Initialized
INFO - 2016-06-22 04:11:07 --> Helper loaded: date_helper
INFO - 2016-06-22 04:11:07 --> Controller Class Initialized
INFO - 2016-06-22 04:11:07 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-22 07:11:07 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-22 07:11:07 --> Form Validation Class Initialized
INFO - 2016-06-22 04:11:07 --> Config Class Initialized
INFO - 2016-06-22 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:11:07 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:11:07 --> Utf8 Class Initialized
INFO - 2016-06-22 04:11:07 --> URI Class Initialized
DEBUG - 2016-06-22 04:11:07 --> No URI present. Default controller set.
INFO - 2016-06-22 04:11:07 --> Router Class Initialized
INFO - 2016-06-22 04:11:07 --> Output Class Initialized
INFO - 2016-06-22 04:11:07 --> Security Class Initialized
DEBUG - 2016-06-22 04:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:11:07 --> Input Class Initialized
INFO - 2016-06-22 04:11:07 --> Language Class Initialized
INFO - 2016-06-22 04:11:07 --> Loader Class Initialized
INFO - 2016-06-22 04:11:07 --> Helper loaded: form_helper
INFO - 2016-06-22 04:11:07 --> Database Driver Class Initialized
INFO - 2016-06-22 04:11:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:11:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:11:07 --> Email Class Initialized
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:11:07 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:11:07 --> Helper loaded: language_helper
INFO - 2016-06-22 04:11:07 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:11:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:11:07 --> Model Class Initialized
INFO - 2016-06-22 04:11:07 --> Helper loaded: date_helper
INFO - 2016-06-22 04:11:07 --> Controller Class Initialized
INFO - 2016-06-22 04:11:07 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:11:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:11:07 --> Model Class Initialized
INFO - 2016-06-22 07:11:07 --> Form Validation Class Initialized
INFO - 2016-06-22 07:11:07 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-22 07:11:07 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-22 07:11:07 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-22 07:11:07 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-22 07:11:07 --> Final output sent to browser
DEBUG - 2016-06-22 07:11:07 --> Total execution time: 0.0834
INFO - 2016-06-22 04:11:11 --> Config Class Initialized
INFO - 2016-06-22 04:11:11 --> Hooks Class Initialized
DEBUG - 2016-06-22 04:11:11 --> UTF-8 Support Enabled
INFO - 2016-06-22 04:11:11 --> Utf8 Class Initialized
INFO - 2016-06-22 04:11:11 --> URI Class Initialized
INFO - 2016-06-22 04:11:11 --> Router Class Initialized
INFO - 2016-06-22 04:11:11 --> Output Class Initialized
INFO - 2016-06-22 04:11:11 --> Security Class Initialized
DEBUG - 2016-06-22 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 04:11:11 --> Input Class Initialized
INFO - 2016-06-22 04:11:11 --> Language Class Initialized
INFO - 2016-06-22 04:11:11 --> Loader Class Initialized
INFO - 2016-06-22 04:11:11 --> Helper loaded: form_helper
INFO - 2016-06-22 04:11:11 --> Database Driver Class Initialized
INFO - 2016-06-22 04:11:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 04:11:11 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 04:11:11 --> Email Class Initialized
INFO - 2016-06-22 04:11:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 04:11:11 --> Helper loaded: cookie_helper
INFO - 2016-06-22 04:11:11 --> Helper loaded: language_helper
INFO - 2016-06-22 04:11:11 --> Helper loaded: url_helper
DEBUG - 2016-06-22 04:11:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 04:11:11 --> Model Class Initialized
INFO - 2016-06-22 04:11:11 --> Helper loaded: date_helper
INFO - 2016-06-22 04:11:11 --> Controller Class Initialized
INFO - 2016-06-22 04:11:11 --> Helper loaded: languages_helper
INFO - 2016-06-22 04:11:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 04:11:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 04:11:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 04:11:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 04:11:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 07:11:11 --> Model Class Initialized
INFO - 2016-06-22 07:11:11 --> Final output sent to browser
DEBUG - 2016-06-22 07:11:11 --> Total execution time: 0.0906
INFO - 2016-06-22 06:49:25 --> Config Class Initialized
INFO - 2016-06-22 06:49:25 --> Hooks Class Initialized
DEBUG - 2016-06-22 06:49:25 --> UTF-8 Support Enabled
INFO - 2016-06-22 06:49:25 --> Utf8 Class Initialized
INFO - 2016-06-22 06:49:25 --> URI Class Initialized
INFO - 2016-06-22 06:49:25 --> Router Class Initialized
INFO - 2016-06-22 06:49:25 --> Output Class Initialized
INFO - 2016-06-22 06:49:25 --> Security Class Initialized
DEBUG - 2016-06-22 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 06:49:25 --> Input Class Initialized
INFO - 2016-06-22 06:49:25 --> Language Class Initialized
INFO - 2016-06-22 06:49:25 --> Loader Class Initialized
INFO - 2016-06-22 06:49:25 --> Helper loaded: form_helper
INFO - 2016-06-22 06:49:25 --> Database Driver Class Initialized
INFO - 2016-06-22 06:49:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 06:49:25 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 06:49:25 --> Email Class Initialized
INFO - 2016-06-22 06:49:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 06:49:25 --> Helper loaded: cookie_helper
INFO - 2016-06-22 06:49:25 --> Helper loaded: language_helper
INFO - 2016-06-22 06:49:25 --> Helper loaded: url_helper
DEBUG - 2016-06-22 06:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 06:49:25 --> Model Class Initialized
INFO - 2016-06-22 06:49:25 --> Helper loaded: date_helper
INFO - 2016-06-22 06:49:25 --> Controller Class Initialized
INFO - 2016-06-22 06:49:25 --> Helper loaded: languages_helper
INFO - 2016-06-22 06:49:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 06:49:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 06:49:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 06:49:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 06:49:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 09:49:25 --> Model Class Initialized
INFO - 2016-06-22 09:49:25 --> Form Validation Class Initialized
INFO - 2016-06-22 06:49:26 --> Config Class Initialized
INFO - 2016-06-22 06:49:26 --> Hooks Class Initialized
DEBUG - 2016-06-22 06:49:26 --> UTF-8 Support Enabled
INFO - 2016-06-22 06:49:26 --> Utf8 Class Initialized
INFO - 2016-06-22 06:49:26 --> Config Class Initialized
INFO - 2016-06-22 06:49:26 --> Hooks Class Initialized
INFO - 2016-06-22 06:49:26 --> URI Class Initialized
INFO - 2016-06-22 06:49:26 --> Router Class Initialized
DEBUG - 2016-06-22 06:49:26 --> UTF-8 Support Enabled
INFO - 2016-06-22 06:49:26 --> Utf8 Class Initialized
INFO - 2016-06-22 06:49:26 --> URI Class Initialized
INFO - 2016-06-22 06:49:26 --> Output Class Initialized
INFO - 2016-06-22 06:49:26 --> Router Class Initialized
INFO - 2016-06-22 06:49:26 --> Security Class Initialized
INFO - 2016-06-22 06:49:26 --> Output Class Initialized
DEBUG - 2016-06-22 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 06:49:26 --> Input Class Initialized
INFO - 2016-06-22 06:49:26 --> Language Class Initialized
INFO - 2016-06-22 06:49:26 --> Security Class Initialized
DEBUG - 2016-06-22 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 06:49:26 --> Input Class Initialized
INFO - 2016-06-22 06:49:26 --> Language Class Initialized
ERROR - 2016-06-22 06:49:26 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-22 06:49:26 --> Loader Class Initialized
INFO - 2016-06-22 06:49:26 --> Helper loaded: form_helper
INFO - 2016-06-22 06:49:26 --> Database Driver Class Initialized
INFO - 2016-06-22 06:49:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 06:49:26 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 06:49:26 --> Email Class Initialized
INFO - 2016-06-22 06:49:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 06:49:26 --> Helper loaded: cookie_helper
INFO - 2016-06-22 06:49:26 --> Helper loaded: language_helper
INFO - 2016-06-22 06:49:26 --> Helper loaded: url_helper
DEBUG - 2016-06-22 06:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 06:49:26 --> Model Class Initialized
INFO - 2016-06-22 06:49:26 --> Helper loaded: date_helper
INFO - 2016-06-22 06:49:26 --> Controller Class Initialized
INFO - 2016-06-22 06:49:26 --> Helper loaded: languages_helper
INFO - 2016-06-22 06:49:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 06:49:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 06:49:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 06:49:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 06:49:26 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-22 09:49:26 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-22 09:49:26 --> Form Validation Class Initialized
DEBUG - 2016-06-22 09:49:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-22 09:49:26 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-22 09:49:26 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-22 09:49:26 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-22 09:49:26 --> Final output sent to browser
DEBUG - 2016-06-22 09:49:26 --> Total execution time: 0.0933
INFO - 2016-06-22 06:49:28 --> Config Class Initialized
INFO - 2016-06-22 06:49:28 --> Hooks Class Initialized
DEBUG - 2016-06-22 06:49:28 --> UTF-8 Support Enabled
INFO - 2016-06-22 06:49:28 --> Utf8 Class Initialized
INFO - 2016-06-22 06:49:28 --> URI Class Initialized
INFO - 2016-06-22 06:49:28 --> Router Class Initialized
INFO - 2016-06-22 06:49:28 --> Output Class Initialized
INFO - 2016-06-22 06:49:28 --> Security Class Initialized
DEBUG - 2016-06-22 06:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 06:49:28 --> Input Class Initialized
INFO - 2016-06-22 06:49:28 --> Language Class Initialized
INFO - 2016-06-22 06:49:28 --> Loader Class Initialized
INFO - 2016-06-22 06:49:28 --> Helper loaded: form_helper
INFO - 2016-06-22 06:49:28 --> Database Driver Class Initialized
INFO - 2016-06-22 06:49:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 06:49:28 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 06:49:28 --> Email Class Initialized
INFO - 2016-06-22 06:49:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 06:49:28 --> Helper loaded: cookie_helper
INFO - 2016-06-22 06:49:28 --> Helper loaded: language_helper
INFO - 2016-06-22 06:49:28 --> Helper loaded: url_helper
DEBUG - 2016-06-22 06:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 06:49:28 --> Model Class Initialized
INFO - 2016-06-22 06:49:28 --> Helper loaded: date_helper
INFO - 2016-06-22 06:49:28 --> Controller Class Initialized
INFO - 2016-06-22 06:49:28 --> Helper loaded: languages_helper
INFO - 2016-06-22 06:49:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 06:49:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 06:49:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 06:49:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 06:49:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 09:49:28 --> Model Class Initialized
INFO - 2016-06-22 09:49:28 --> Final output sent to browser
DEBUG - 2016-06-22 09:49:28 --> Total execution time: 0.1272
INFO - 2016-06-22 13:47:05 --> Config Class Initialized
INFO - 2016-06-22 13:47:05 --> Hooks Class Initialized
DEBUG - 2016-06-22 13:47:05 --> UTF-8 Support Enabled
INFO - 2016-06-22 13:47:05 --> Utf8 Class Initialized
INFO - 2016-06-22 13:47:05 --> URI Class Initialized
INFO - 2016-06-22 13:47:05 --> Router Class Initialized
INFO - 2016-06-22 13:47:05 --> Output Class Initialized
INFO - 2016-06-22 13:47:05 --> Security Class Initialized
DEBUG - 2016-06-22 13:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 13:47:05 --> Input Class Initialized
INFO - 2016-06-22 13:47:05 --> Language Class Initialized
ERROR - 2016-06-22 13:47:05 --> 404 Page Not Found: Robotstxt/index
INFO - 2016-06-22 13:47:07 --> Config Class Initialized
INFO - 2016-06-22 13:47:07 --> Hooks Class Initialized
DEBUG - 2016-06-22 13:47:07 --> UTF-8 Support Enabled
INFO - 2016-06-22 13:47:07 --> Utf8 Class Initialized
INFO - 2016-06-22 13:47:07 --> URI Class Initialized
DEBUG - 2016-06-22 13:47:07 --> No URI present. Default controller set.
INFO - 2016-06-22 13:47:07 --> Router Class Initialized
INFO - 2016-06-22 13:47:07 --> Output Class Initialized
INFO - 2016-06-22 13:47:07 --> Security Class Initialized
DEBUG - 2016-06-22 13:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 13:47:07 --> Input Class Initialized
INFO - 2016-06-22 13:47:07 --> Language Class Initialized
INFO - 2016-06-22 13:47:07 --> Loader Class Initialized
INFO - 2016-06-22 13:47:07 --> Helper loaded: form_helper
INFO - 2016-06-22 13:47:07 --> Database Driver Class Initialized
INFO - 2016-06-22 13:47:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 13:47:07 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 13:47:07 --> Email Class Initialized
INFO - 2016-06-22 13:47:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 13:47:07 --> Helper loaded: cookie_helper
INFO - 2016-06-22 13:47:07 --> Helper loaded: language_helper
INFO - 2016-06-22 13:47:07 --> Helper loaded: url_helper
DEBUG - 2016-06-22 13:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 13:47:07 --> Model Class Initialized
INFO - 2016-06-22 13:47:07 --> Helper loaded: date_helper
INFO - 2016-06-22 13:47:07 --> Controller Class Initialized
INFO - 2016-06-22 13:47:07 --> Helper loaded: languages_helper
INFO - 2016-06-22 13:47:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 13:47:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 13:47:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 13:47:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 13:47:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 16:47:07 --> Model Class Initialized
INFO - 2016-06-22 16:47:07 --> Form Validation Class Initialized
INFO - 2016-06-22 16:47:07 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-22 16:47:07 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-22 16:47:07 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-22 16:47:07 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-22 16:47:07 --> Final output sent to browser
DEBUG - 2016-06-22 16:47:07 --> Total execution time: 0.0832
INFO - 2016-06-22 16:09:03 --> Config Class Initialized
INFO - 2016-06-22 16:09:03 --> Hooks Class Initialized
DEBUG - 2016-06-22 16:09:03 --> UTF-8 Support Enabled
INFO - 2016-06-22 16:09:03 --> Utf8 Class Initialized
INFO - 2016-06-22 16:09:03 --> URI Class Initialized
DEBUG - 2016-06-22 16:09:03 --> No URI present. Default controller set.
INFO - 2016-06-22 16:09:03 --> Router Class Initialized
INFO - 2016-06-22 16:09:03 --> Output Class Initialized
INFO - 2016-06-22 16:09:03 --> Security Class Initialized
DEBUG - 2016-06-22 16:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 16:09:03 --> Input Class Initialized
INFO - 2016-06-22 16:09:03 --> Language Class Initialized
INFO - 2016-06-22 16:09:03 --> Loader Class Initialized
INFO - 2016-06-22 16:09:03 --> Helper loaded: form_helper
INFO - 2016-06-22 16:09:03 --> Database Driver Class Initialized
INFO - 2016-06-22 16:09:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 16:09:03 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 16:09:03 --> Email Class Initialized
INFO - 2016-06-22 16:09:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 16:09:03 --> Helper loaded: cookie_helper
INFO - 2016-06-22 16:09:04 --> Helper loaded: language_helper
INFO - 2016-06-22 16:09:04 --> Helper loaded: url_helper
DEBUG - 2016-06-22 16:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 16:09:04 --> Model Class Initialized
INFO - 2016-06-22 16:09:04 --> Helper loaded: date_helper
INFO - 2016-06-22 16:09:04 --> Controller Class Initialized
INFO - 2016-06-22 16:09:04 --> Helper loaded: languages_helper
INFO - 2016-06-22 16:09:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 16:09:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 16:09:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 16:09:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 16:09:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 19:09:04 --> Model Class Initialized
INFO - 2016-06-22 19:09:04 --> Form Validation Class Initialized
INFO - 2016-06-22 19:09:04 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-22 19:09:04 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-22 19:09:04 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-22 19:09:04 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-22 19:09:04 --> Final output sent to browser
DEBUG - 2016-06-22 19:09:04 --> Total execution time: 0.0829
INFO - 2016-06-22 16:09:05 --> Config Class Initialized
INFO - 2016-06-22 16:09:05 --> Hooks Class Initialized
DEBUG - 2016-06-22 16:09:05 --> UTF-8 Support Enabled
INFO - 2016-06-22 16:09:05 --> Utf8 Class Initialized
INFO - 2016-06-22 16:09:05 --> URI Class Initialized
INFO - 2016-06-22 16:09:05 --> Router Class Initialized
INFO - 2016-06-22 16:09:05 --> Output Class Initialized
INFO - 2016-06-22 16:09:05 --> Security Class Initialized
DEBUG - 2016-06-22 16:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 16:09:05 --> Input Class Initialized
INFO - 2016-06-22 16:09:05 --> Language Class Initialized
INFO - 2016-06-22 16:09:05 --> Loader Class Initialized
INFO - 2016-06-22 16:09:05 --> Helper loaded: form_helper
INFO - 2016-06-22 16:09:05 --> Database Driver Class Initialized
INFO - 2016-06-22 16:09:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-22 16:09:05 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-22 16:09:05 --> Email Class Initialized
INFO - 2016-06-22 16:09:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-22 16:09:05 --> Helper loaded: cookie_helper
INFO - 2016-06-22 16:09:05 --> Helper loaded: language_helper
INFO - 2016-06-22 16:09:05 --> Helper loaded: url_helper
DEBUG - 2016-06-22 16:09:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-22 16:09:05 --> Model Class Initialized
INFO - 2016-06-22 16:09:05 --> Helper loaded: date_helper
INFO - 2016-06-22 16:09:05 --> Controller Class Initialized
INFO - 2016-06-22 16:09:05 --> Helper loaded: languages_helper
INFO - 2016-06-22 16:09:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-22 16:09:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-22 16:09:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-22 16:09:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-22 16:09:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-22 19:09:05 --> Model Class Initialized
INFO - 2016-06-22 19:09:05 --> Final output sent to browser
DEBUG - 2016-06-22 19:09:05 --> Total execution time: 0.0836
INFO - 2016-06-22 16:09:05 --> Config Class Initialized
INFO - 2016-06-22 16:09:05 --> Hooks Class Initialized
DEBUG - 2016-06-22 16:09:05 --> UTF-8 Support Enabled
INFO - 2016-06-22 16:09:05 --> Utf8 Class Initialized
INFO - 2016-06-22 16:09:05 --> URI Class Initialized
INFO - 2016-06-22 16:09:05 --> Router Class Initialized
INFO - 2016-06-22 16:09:05 --> Output Class Initialized
INFO - 2016-06-22 16:09:05 --> Security Class Initialized
DEBUG - 2016-06-22 16:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-22 16:09:05 --> Input Class Initialized
INFO - 2016-06-22 16:09:05 --> Language Class Initialized
ERROR - 2016-06-22 16:09:05 --> 404 Page Not Found: Faviconico/index
