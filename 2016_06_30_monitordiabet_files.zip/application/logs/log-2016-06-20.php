<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-20 21:47:08 --> Config Class Initialized
INFO - 2016-06-20 21:47:08 --> Hooks Class Initialized
DEBUG - 2016-06-20 21:47:08 --> UTF-8 Support Enabled
INFO - 2016-06-20 21:47:08 --> Utf8 Class Initialized
INFO - 2016-06-20 21:47:08 --> URI Class Initialized
INFO - 2016-06-20 21:47:08 --> Router Class Initialized
INFO - 2016-06-20 21:47:08 --> Output Class Initialized
INFO - 2016-06-20 21:47:08 --> Security Class Initialized
DEBUG - 2016-06-20 21:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-20 21:47:08 --> Input Class Initialized
INFO - 2016-06-20 21:47:08 --> Language Class Initialized
ERROR - 2016-06-20 21:47:08 --> 404 Page Not Found: Robotstxt/index
INFO - 2016-06-20 21:47:10 --> Config Class Initialized
INFO - 2016-06-20 21:47:10 --> Hooks Class Initialized
DEBUG - 2016-06-20 21:47:10 --> UTF-8 Support Enabled
INFO - 2016-06-20 21:47:10 --> Utf8 Class Initialized
INFO - 2016-06-20 21:47:10 --> URI Class Initialized
DEBUG - 2016-06-20 21:47:10 --> No URI present. Default controller set.
INFO - 2016-06-20 21:47:10 --> Router Class Initialized
INFO - 2016-06-20 21:47:10 --> Output Class Initialized
INFO - 2016-06-20 21:47:10 --> Security Class Initialized
DEBUG - 2016-06-20 21:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-20 21:47:10 --> Input Class Initialized
INFO - 2016-06-20 21:47:10 --> Language Class Initialized
INFO - 2016-06-20 21:47:10 --> Loader Class Initialized
INFO - 2016-06-20 21:47:10 --> Helper loaded: form_helper
INFO - 2016-06-20 21:47:10 --> Database Driver Class Initialized
INFO - 2016-06-20 21:47:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-20 21:47:10 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-20 21:47:10 --> Email Class Initialized
INFO - 2016-06-20 21:47:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-20 21:47:10 --> Helper loaded: cookie_helper
INFO - 2016-06-20 21:47:10 --> Helper loaded: language_helper
INFO - 2016-06-20 21:47:10 --> Helper loaded: url_helper
DEBUG - 2016-06-20 21:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-20 21:47:10 --> Model Class Initialized
INFO - 2016-06-20 21:47:10 --> Helper loaded: date_helper
INFO - 2016-06-20 21:47:10 --> Controller Class Initialized
INFO - 2016-06-20 21:47:10 --> Helper loaded: languages_helper
INFO - 2016-06-20 21:47:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-20 21:47:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-20 21:47:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-20 21:47:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-20 21:47:10 --> Language file loaded: language/romanian/form_validation_lang.php
