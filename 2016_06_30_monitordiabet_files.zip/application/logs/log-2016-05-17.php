<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-05-17 14:37:21 --> 404 Page Not Found: Auth/edit
DEBUG - 2016-05-17 14:38:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-17 14:38:43 --> 404 Page Not Found: Auth/edit
DEBUG - 2016-05-17 14:42:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:42:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:49 --> Total execution time: 0.1575
DEBUG - 2016-05-17 14:42:56 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:42:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:56 --> Total execution time: 0.0894
DEBUG - 2016-05-17 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:42:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:42:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:42:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:42:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:42:59 --> Total execution time: 0.0117
DEBUG - 2016-05-17 14:43:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:43:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:43:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:43:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:43:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:43:04 --> Total execution time: 0.0204
DEBUG - 2016-05-17 14:46:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:46:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:46:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:46:25 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:46:25 --> Total execution time: 0.0550
DEBUG - 2016-05-17 14:46:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:46:29 --> No URI present. Default controller set.
DEBUG - 2016-05-17 14:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:46:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:46:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:46:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:46:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:46:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:46:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:46:29 --> Total execution time: 0.0141
DEBUG - 2016-05-17 14:48:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:48:02 --> No URI present. Default controller set.
DEBUG - 2016-05-17 14:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:48:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:48:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:48:02 --> Total execution time: 0.0386
DEBUG - 2016-05-17 14:48:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:48:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:48:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:48:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:48:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:48:12 --> Total execution time: 0.0681
DEBUG - 2016-05-17 14:48:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:48:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:48:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:48:27 --> Total execution time: 0.0500
DEBUG - 2016-05-17 14:48:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:48:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:48:55 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 14:48:55 --> Severity: Error --> Call to undefined method Auth::view() /home/demis/www/platformadiabet/application/controllers/Auth.php 845
DEBUG - 2016-05-17 14:49:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:49:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:49:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:49:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:49:02 --> Total execution time: 0.0154
DEBUG - 2016-05-17 14:59:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:59:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:36 --> Total execution time: 0.0664
DEBUG - 2016-05-17 14:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:59:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:59:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:40 --> Total execution time: 0.0600
DEBUG - 2016-05-17 14:59:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:59:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:59:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:49 --> Total execution time: 0.0484
DEBUG - 2016-05-17 14:59:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 14:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 14:59:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 14:59:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 14:59:53 --> Total execution time: 0.0306
DEBUG - 2016-05-17 15:00:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:00:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:00:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:00:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:00:02 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:00:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:00:02 --> Total execution time: 0.0351
DEBUG - 2016-05-17 15:00:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:00:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:00:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:00:07 --> File '/home/demis/www/platformadiabet/application/views/home2.php' doesn't exist.
ERROR - 2016-05-17 15:00:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:00:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:00:07 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:00:07 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:00:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:00:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:00:21 --> Total execution time: 0.0261
DEBUG - 2016-05-17 15:00:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:00:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:00:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:00:27 --> File '/home/demis/www/platformadiabet/application/views/home2.php' doesn't exist.
ERROR - 2016-05-17 15:00:27 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:00:27 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:00:27 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:00:27 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:00:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:00:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:00:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:00:55 --> File '/home/demis/www/platformadiabet/application/views/home2.php' doesn't exist.
ERROR - 2016-05-17 15:00:55 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:00:55 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:00:55 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:00:55 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:00:55 --> Total execution time: 0.0503
DEBUG - 2016-05-17 15:03:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:03:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:03:11 --> Total execution time: 0.0744
DEBUG - 2016-05-17 15:05:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:05:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:05:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:05:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:05:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:05:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:07:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:07:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:07:03 --> Total execution time: 0.0734
DEBUG - 2016-05-17 15:12:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:12:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:12:54 --> Total execution time: 0.0526
DEBUG - 2016-05-17 15:13:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:13:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:13:18 --> Total execution time: 0.0421
DEBUG - 2016-05-17 15:13:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:13:21 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:13:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:13:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:13:21 --> Total execution time: 0.0284
DEBUG - 2016-05-17 15:13:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:13:40 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:13:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:13:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:13:40 --> Severity: Notice --> Undefined variable: data /home/demis/www/platformadiabet/application/controllers/Website.php 9
ERROR - 2016-05-17 15:13:40 --> Severity: Warning --> array_merge(): Argument #1 is not an array /home/demis/www/platformadiabet/application/core/SVS_Controller.php 35
ERROR - 2016-05-17 15:13:40 --> Severity: Notice --> Undefined variable: page_title /home/demis/www/platformadiabet/application/views/res/user_area_header.php 6
ERROR - 2016-05-17 15:13:40 --> Severity: Notice --> Undefined variable: page_class /home/demis/www/platformadiabet/application/views/res/user_area_header.php 22
ERROR - 2016-05-17 15:13:40 --> Severity: Error --> Call to undefined function form_open() /home/demis/www/platformadiabet/application/views/home.php 13
DEBUG - 2016-05-17 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:13:52 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:13:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:13:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:13:52 --> Severity: Error --> Call to undefined function form_open() /home/demis/www/platformadiabet/application/views/home.php 13
DEBUG - 2016-05-17 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:14:45 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:14:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:14:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:14:45 --> Unable to load the requested class: Form
DEBUG - 2016-05-17 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:14:55 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:14:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:14:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:14:55 --> Unable to load the requested class: Form
DEBUG - 2016-05-17 15:15:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:15:07 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:15:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:15:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:15:07 --> Total execution time: 0.0363
DEBUG - 2016-05-17 15:15:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:15:39 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:15:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:15:39 --> Total execution time: 0.0379
DEBUG - 2016-05-17 15:15:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:15:49 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:15:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:15:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:15:49 --> Total execution time: 0.0450
DEBUG - 2016-05-17 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:15:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:15:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:15:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:15:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:15:55 --> Total execution time: 0.0368
DEBUG - 2016-05-17 15:16:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:16:02 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:16:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:16:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:16:02 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/home.php 27
ERROR - 2016-05-17 15:16:02 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/home.php 42
DEBUG - 2016-05-17 15:16:02 --> Total execution time: 0.0354
DEBUG - 2016-05-17 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:17:17 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:17:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:17:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:17:17 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/home.php 27
ERROR - 2016-05-17 15:17:17 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/home.php 42
DEBUG - 2016-05-17 15:17:17 --> Total execution time: 0.0420
DEBUG - 2016-05-17 15:17:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:17:27 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:17:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:17:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:17:27 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/home.php 27
ERROR - 2016-05-17 15:17:27 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/home.php 42
DEBUG - 2016-05-17 15:17:27 --> Total execution time: 0.0408
DEBUG - 2016-05-17 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:28:04 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-17 15:28:04 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/demis/www/platformadiabet/application/core/SVS_Controller.php 25
DEBUG - 2016-05-17 15:28:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:28:19 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:28:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:28:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:28:19 --> Severity: Notice --> Use of undefined constant file - assumed 'file' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 25
ERROR - 2016-05-17 15:28:19 --> File '/home/demis/www/platformadiabet/application/views/public/home.php' doesn't exist.
ERROR - 2016-05-17 15:28:19 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:28:19 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:28:19 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:28:19 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:28:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:28:28 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:28:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:28:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:28:28 --> File '/home/demis/www/platformadiabet/application/views/public/home.php' doesn't exist.
ERROR - 2016-05-17 15:28:28 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:28:28 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:28:28 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:28:28 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:29:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:29:02 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:29:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:29:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:29:02 --> File '/home/demis/www/platformadiabet/application/views/public/home.php' doesn't exist.
ERROR - 2016-05-17 15:29:02 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:29:02 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:29:02 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:29:02 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:29:34 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:29:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:29:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:29:34 --> File '/home/demis/www/platformadiabet/application/views/public/home.php' doesn't exist.
ERROR - 2016-05-17 15:29:34 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:29:34 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:29:34 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:29:34 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:29:34 --> Total execution time: 0.0383
DEBUG - 2016-05-17 15:29:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:29:40 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:29:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:29:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:29:40 --> File '/home/demis/www/platformadiabet/application/views/public/home.php' doesn't exist.
ERROR - 2016-05-17 15:29:40 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:29:40 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:29:40 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:29:40 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:30:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:30:15 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:30:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:32:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:32:03 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:32:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:32:23 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:32:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:32:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:32:23 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/public/home.php 27
ERROR - 2016-05-17 15:32:23 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/public/home.php 42
DEBUG - 2016-05-17 15:32:23 --> Total execution time: 0.0138
DEBUG - 2016-05-17 15:33:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:33:15 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:33:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:33:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:33:15 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/public/home.php 27
ERROR - 2016-05-17 15:33:15 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/public/home.php 42
DEBUG - 2016-05-17 15:33:15 --> Total execution time: 0.0134
DEBUG - 2016-05-17 15:34:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:34:25 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:34:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:34:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:34:25 --> Total execution time: 0.0240
DEBUG - 2016-05-17 15:34:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:34:29 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:34:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:34:29 --> Total execution time: 0.0280
DEBUG - 2016-05-17 15:34:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:34:35 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:34:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:34:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:34:35 --> Total execution time: 0.0240
DEBUG - 2016-05-17 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:35:23 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:35:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:35:23 --> Total execution time: 0.0090
DEBUG - 2016-05-17 15:35:30 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:35:30 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:35:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:35:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:35:30 --> Total execution time: 0.0107
DEBUG - 2016-05-17 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:35:37 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:35:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:35:37 --> Total execution time: 0.0106
DEBUG - 2016-05-17 15:35:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:35:50 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:35:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:35:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:35:50 --> Total execution time: 0.0085
DEBUG - 2016-05-17 15:35:56 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:35:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:35:56 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:35:56 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:35:56 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:35:56 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:35:56 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:35:56 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:38:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:38:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:38:29 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:38:29 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:38:29 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:38:29 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:38:29 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:38:29 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:38:30 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:38:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:38:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:38:30 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:38:30 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:38:30 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:38:30 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:38:30 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:38:30 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:42:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:42:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:42:49 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:42:49 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:42:49 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:42:49 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:42:49 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:42:49 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:42:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:42:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:42:50 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:42:50 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:42:50 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:42:50 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:42:50 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:42:50 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:43:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:43:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:43:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:43:09 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:43:09 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:43:09 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:09 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:09 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:43:09 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:43:09 --> Total execution time: 0.0106
DEBUG - 2016-05-17 15:43:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:43:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:43:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:43:10 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:43:10 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:43:10 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:10 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:10 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:43:10 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:43:10 --> Total execution time: 0.0297
DEBUG - 2016-05-17 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:43:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:43:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:43:11 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:43:11 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:43:11 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:11 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:11 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:43:11 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:43:11 --> Total execution time: 0.0071
DEBUG - 2016-05-17 15:43:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:43:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:43:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:43:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:43:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:43:19 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:43:19 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:43:19 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:19 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:43:19 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:43:19 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:43:19 --> Total execution time: 0.0089
DEBUG - 2016-05-17 15:44:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:44:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:44:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:44:58 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:44:58 --> File 'public/auth/login' doesn't exist.
ERROR - 2016-05-17 15:44:58 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:44:58 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:44:58 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:44:58 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:44:58 --> Total execution time: 0.0412
DEBUG - 2016-05-17 15:45:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:45:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:45:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:45:41 --> Total execution time: 0.0298
DEBUG - 2016-05-17 15:46:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:46:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:46:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:46:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:46:01 --> Total execution time: 0.0122
DEBUG - 2016-05-17 15:46:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:46:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:46:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:46:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:46:08 --> Total execution time: 0.0220
DEBUG - 2016-05-17 15:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:47:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:47:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:47:00 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:47:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:47:00 --> Total execution time: 0.0267
DEBUG - 2016-05-17 15:47:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:47:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:47:07 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:47:07 --> File 'user_area/auth/edit_user' doesn't exist.
ERROR - 2016-05-17 15:47:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:47:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:47:07 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:47:07 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:47:07 --> Total execution time: 0.0373
DEBUG - 2016-05-17 15:48:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:48:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:48:07 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 15:48:07 --> File 'user_area/auth/edit_user' doesn't exist.
ERROR - 2016-05-17 15:48:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:48:07 --> Could not find the language line "error_general_message"
ERROR - 2016-05-17 15:48:07 --> Could not find the language line "error_general_title"
ERROR - 2016-05-17 15:48:07 --> Could not find the language line "error_page_title"
DEBUG - 2016-05-17 15:48:07 --> Total execution time: 0.0201
DEBUG - 2016-05-17 15:53:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:53:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:53:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:53:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:53:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:53:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:53:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:53:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:53:50 --> Total execution time: 0.0560
DEBUG - 2016-05-17 15:54:14 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:14 --> Total execution time: 0.0447
DEBUG - 2016-05-17 15:54:15 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:15 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:15 --> Total execution time: 0.0145
DEBUG - 2016-05-17 15:54:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-17 15:54:20 --> 404 Page Not Found: Auth/edit
DEBUG - 2016-05-17 15:54:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:21 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:21 --> Total execution time: 0.0155
DEBUG - 2016-05-17 15:54:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:27 --> Total execution time: 0.0388
DEBUG - 2016-05-17 15:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:35 --> Total execution time: 0.0103
DEBUG - 2016-05-17 15:54:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:55 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:54:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:54:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:54:55 --> Total execution time: 0.0089
DEBUG - 2016-05-17 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:55:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:55:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:55:04 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:55:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:55:04 --> Total execution time: 0.0154
DEBUG - 2016-05-17 15:55:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:55:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:55:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:55:25 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:55:26 --> Total execution time: 0.0629
DEBUG - 2016-05-17 15:55:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:55:29 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:55:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:55:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:55:29 --> Total execution time: 0.0439
DEBUG - 2016-05-17 15:55:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:55:40 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:55:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:55:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:55:40 --> Total execution time: 0.0130
DEBUG - 2016-05-17 15:56:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:56:32 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:56:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:56:32 --> Total execution time: 0.0327
DEBUG - 2016-05-17 15:56:34 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 15:56:34 --> No URI present. Default controller set.
DEBUG - 2016-05-17 15:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 15:56:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 15:56:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 15:56:34 --> Total execution time: 0.0186
DEBUG - 2016-05-17 16:00:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:00:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:00:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:00:29 --> Total execution time: 0.0626
DEBUG - 2016-05-17 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:00:35 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:00:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:00:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:00:35 --> Total execution time: 0.0670
DEBUG - 2016-05-17 16:02:20 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:02:20 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:02:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:02:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:02:20 --> Total execution time: 0.0401
DEBUG - 2016-05-17 16:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:02:26 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:02:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:02:26 --> Total execution time: 0.0184
DEBUG - 2016-05-17 16:04:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:17 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:17 --> Total execution time: 0.0572
DEBUG - 2016-05-17 16:04:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:19 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:19 --> Total execution time: 0.0380
DEBUG - 2016-05-17 16:04:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:36 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:46 --> Total execution time: 0.0157
DEBUG - 2016-05-17 16:04:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:54 --> Total execution time: 0.0420
DEBUG - 2016-05-17 16:04:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:59 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:04:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:04:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:04:59 --> Total execution time: 0.0245
DEBUG - 2016-05-17 16:06:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:06:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:06:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:06:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:06:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:06:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:06:48 --> Total execution time: 0.0109
DEBUG - 2016-05-17 16:06:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:06:53 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:06:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:06:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:06:53 --> Total execution time: 0.0713
DEBUG - 2016-05-17 16:07:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:07:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:07:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:07:03 --> Total execution time: 0.0337
DEBUG - 2016-05-17 16:15:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:15:53 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:15:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:15:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:15:53 --> Total execution time: 0.0551
DEBUG - 2016-05-17 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:17:00 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:17:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:17:01 --> Total execution time: 0.0356
DEBUG - 2016-05-17 16:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:17:35 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:17:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:17:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:17:35 --> Total execution time: 0.0392
DEBUG - 2016-05-17 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:18:28 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:18:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:18:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 16:18:28 --> Severity: Notice --> Undefined index: page_title /home/demis/www/platformadiabet/application/core/SVS_Controller.php 33
DEBUG - 2016-05-17 16:19:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:19:19 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:19:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:21:01 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:21:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:21:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:21:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:21:13 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:21:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:21:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:21:57 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:21:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:22:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:22:21 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:22:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:22:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:23:17 --> No URI present. Default controller set.
DEBUG - 2016-05-17 16:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:23:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:23:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:23:17 --> Total execution time: 0.0304
DEBUG - 2016-05-17 16:23:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:23:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-17 16:23:22 --> 404 Page Not Found: Contact/index
DEBUG - 2016-05-17 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-17 16:23:39 --> 404 Page Not Found: Contact/index
DEBUG - 2016-05-17 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-05-17 16:23:40 --> 404 Page Not Found: Contact/index
DEBUG - 2016-05-17 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:23:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:23:48 --> Total execution time: 0.0402
DEBUG - 2016-05-17 16:24:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:24:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:24:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:24:37 --> Total execution time: 0.0419
DEBUG - 2016-05-17 16:24:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:24:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:24:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:24:39 --> Total execution time: 0.0211
DEBUG - 2016-05-17 16:25:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:25:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:25:24 --> Total execution time: 0.0310
DEBUG - 2016-05-17 16:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:25:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:25:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:25:26 --> Total execution time: 0.0094
DEBUG - 2016-05-17 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:25:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:25:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:25:54 --> Total execution time: 0.0494
DEBUG - 2016-05-17 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:26:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:26:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:26:51 --> Total execution time: 0.0506
DEBUG - 2016-05-17 16:54:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:54:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:54:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 16:54:04 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/home.php 27
ERROR - 2016-05-17 16:54:04 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/views/user_area/home.php 42
DEBUG - 2016-05-17 16:54:04 --> Total execution time: 0.0377
DEBUG - 2016-05-17 16:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:54:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:54:35 --> Total execution time: 0.0303
DEBUG - 2016-05-17 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:54:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:54:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:54:47 --> Total execution time: 0.0425
DEBUG - 2016-05-17 16:55:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:08 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:08 --> Total execution time: 0.0094
DEBUG - 2016-05-17 16:55:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:11 --> Total execution time: 0.0218
DEBUG - 2016-05-17 16:55:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:23 --> Total execution time: 0.0439
DEBUG - 2016-05-17 16:55:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:28 --> Total execution time: 0.0510
DEBUG - 2016-05-17 16:55:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:36 --> Total execution time: 0.0190
DEBUG - 2016-05-17 16:55:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:37 --> Total execution time: 0.0207
DEBUG - 2016-05-17 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:38 --> Total execution time: 0.0248
DEBUG - 2016-05-17 16:55:47 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:55:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:55:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:55:47 --> Total execution time: 0.0309
DEBUG - 2016-05-17 16:56:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:56:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:56:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:56:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:56:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:56:48 --> Total execution time: 0.0282
DEBUG - 2016-05-17 16:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:57:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:57:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 16:57:02 --> Severity: Notice --> Undefined property: Api::$get /home/demis/www/platformadiabet/application/controllers/Api.php 8
DEBUG - 2016-05-17 16:57:02 --> Total execution time: 0.0331
DEBUG - 2016-05-17 16:57:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:57:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:57:28 --> Total execution time: 0.0620
DEBUG - 2016-05-17 16:57:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:57:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:57:54 --> Total execution time: 0.0374
DEBUG - 2016-05-17 16:58:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:58:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:58:41 --> Total execution time: 0.0358
DEBUG - 2016-05-17 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:59:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:59:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 16:59:13 --> Total execution time: 0.0380
DEBUG - 2016-05-17 16:59:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 16:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 16:59:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 16:59:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 16:59:52 --> Severity: Notice --> Undefined property: Api::$diabet_model /home/demis/www/platformadiabet/application/controllers/Api.php 11
ERROR - 2016-05-17 16:59:52 --> Severity: Error --> Call to undefined function checkApi() /home/demis/www/platformadiabet/application/controllers/Api.php 11
DEBUG - 2016-05-17 17:01:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:01:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:01:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 17:01:05 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/demis/www/platformadiabet/application/models/Diabet_model.php 16
DEBUG - 2016-05-17 17:01:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:01:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:01:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 17:01:24 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/demis/www/platformadiabet/application/models/Diabet_model.php 16
DEBUG - 2016-05-17 17:01:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:01:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:01:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 17:01:25 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /home/demis/www/platformadiabet/application/models/Diabet_model.php 16
DEBUG - 2016-05-17 17:01:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:01:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:01:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 17:01:29 --> Severity: Notice --> Undefined property: Api::$diabet_model /home/demis/www/platformadiabet/application/controllers/Api.php 12
ERROR - 2016-05-17 17:01:29 --> Severity: Error --> Call to undefined function checkapi() /home/demis/www/platformadiabet/application/controllers/Api.php 12
DEBUG - 2016-05-17 17:02:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:02:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:02:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 17:02:22 --> Severity: Notice --> Undefined property: Api::$diabet_model /home/demis/www/platformadiabet/application/controllers/Api.php 12
ERROR - 2016-05-17 17:02:22 --> Severity: Error --> Call to undefined function checkApi() /home/demis/www/platformadiabet/application/controllers/Api.php 12
DEBUG - 2016-05-17 17:02:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:02:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:02:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 17:02:36 --> Severity: Notice --> Undefined property: Api::$diabet_model /home/demis/www/platformadiabet/application/controllers/Api.php 12
ERROR - 2016-05-17 17:02:36 --> Severity: Error --> Call to a member function checkApi() on null /home/demis/www/platformadiabet/application/controllers/Api.php 12
DEBUG - 2016-05-17 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:03:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:03:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 17:03:04 --> Severity: Notice --> Trying to get property of non-object /home/demis/www/platformadiabet/application/controllers/Api.php 12
DEBUG - 2016-05-17 17:03:04 --> Total execution time: 0.0570
DEBUG - 2016-05-17 17:03:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:03:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 17:03:46 --> Total execution time: 0.0297
DEBUG - 2016-05-17 17:10:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:10:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:10:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 17:10:53 --> Total execution time: 0.0374
DEBUG - 2016-05-17 17:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:10:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:10:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 17:10:55 --> Total execution time: 0.0331
DEBUG - 2016-05-17 17:11:12 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:11:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 17:11:12 --> Total execution time: 0.0578
DEBUG - 2016-05-17 17:11:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 17:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 17:11:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 17:11:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 17:11:23 --> Total execution time: 0.0333
DEBUG - 2016-05-17 18:24:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:24:44 --> No URI present. Default controller set.
DEBUG - 2016-05-17 18:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:24:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:24:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:24:44 --> Total execution time: 0.0241
DEBUG - 2016-05-17 18:24:51 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:24:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:24:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:24:51 --> Total execution time: 0.0824
DEBUG - 2016-05-17 18:27:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:27:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:27:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:27:09 --> Total execution time: 0.0695
DEBUG - 2016-05-17 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:27:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:27:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:27:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:27:43 --> Total execution time: 0.0090
DEBUG - 2016-05-17 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:29:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:29:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:29:01 --> Total execution time: 0.0532
DEBUG - 2016-05-17 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:35:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:35:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-05-17 18:35:11 --> Severity: Notice --> Use of undefined constant COOKIE_EXPIRATION - assumed 'COOKIE_EXPIRATION' /home/demis/www/platformadiabet/application/core/SVS_Controller.php 18
DEBUG - 2016-05-17 18:35:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:35:11 --> Total execution time: 0.0673
DEBUG - 2016-05-17 18:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:36:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:36:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:36:33 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:36:33 --> Total execution time: 0.0305
DEBUG - 2016-05-17 18:39:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:39:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:39:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:39:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:39:11 --> Total execution time: 0.0538
DEBUG - 2016-05-17 18:51:33 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:51:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:51:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:33 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:33 --> Total execution time: 0.0443
DEBUG - 2016-05-17 18:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:51:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:51:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:35 --> Total execution time: 0.0134
DEBUG - 2016-05-17 18:51:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:51:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:51:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:48 --> Total execution time: 0.0371
DEBUG - 2016-05-17 18:51:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:51:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:51:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:51:50 --> Total execution time: 0.0096
DEBUG - 2016-05-17 18:55:07 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:55:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:55:07 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 18:55:07 --> Could not find the language line "create_user_new"
ERROR - 2016-05-17 18:55:07 --> Could not find the language line "create_user_new_description"
ERROR - 2016-05-17 18:55:07 --> Could not find the language line "create_user_new_register"
DEBUG - 2016-05-17 18:55:07 --> Total execution time: 0.0430
DEBUG - 2016-05-17 18:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-17 18:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-05-17 18:55:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
DEBUG - 2016-05-17 18:55:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-05-17 18:55:57 --> Ion_auth class already loaded. Second attempt ignored.
ERROR - 2016-05-17 18:55:57 --> Could not find the language line "create_user_new"
ERROR - 2016-05-17 18:55:57 --> Could not find the language line "create_user_new_description"
ERROR - 2016-05-17 18:55:57 --> Could not find the language line "create_user_new_register"
DEBUG - 2016-05-17 18:55:57 --> Total execution time: 0.0401
