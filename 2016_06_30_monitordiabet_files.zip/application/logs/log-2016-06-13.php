<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-13 09:50:34 --> Config Class Initialized
INFO - 2016-06-13 09:50:34 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:50:34 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:50:34 --> Utf8 Class Initialized
INFO - 2016-06-13 09:50:34 --> URI Class Initialized
INFO - 2016-06-13 09:50:34 --> Router Class Initialized
INFO - 2016-06-13 09:50:34 --> Output Class Initialized
INFO - 2016-06-13 09:50:34 --> Security Class Initialized
DEBUG - 2016-06-13 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:50:35 --> Input Class Initialized
INFO - 2016-06-13 09:50:35 --> Language Class Initialized
INFO - 2016-06-13 09:50:35 --> Loader Class Initialized
INFO - 2016-06-13 09:50:35 --> Helper loaded: form_helper
INFO - 2016-06-13 09:50:35 --> Database Driver Class Initialized
INFO - 2016-06-13 09:50:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:50:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:50:35 --> Email Class Initialized
INFO - 2016-06-13 09:50:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:50:36 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:50:36 --> Helper loaded: language_helper
INFO - 2016-06-13 09:50:36 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:50:36 --> Model Class Initialized
INFO - 2016-06-13 09:50:36 --> Helper loaded: date_helper
INFO - 2016-06-13 09:50:36 --> Controller Class Initialized
INFO - 2016-06-13 09:50:36 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:50:36 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:50:36 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:50:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:50:36 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:50:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:50:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-13 09:50:36 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:50:36 --> Form Validation Class Initialized
DEBUG - 2016-06-13 09:50:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:50:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-13 09:50:36 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-13 09:50:36 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-13 09:50:36 --> Final output sent to browser
DEBUG - 2016-06-13 09:50:36 --> Total execution time: 2.9360
INFO - 2016-06-13 09:50:42 --> Config Class Initialized
INFO - 2016-06-13 09:50:42 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:50:42 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:50:42 --> Utf8 Class Initialized
INFO - 2016-06-13 09:50:42 --> URI Class Initialized
INFO - 2016-06-13 09:50:42 --> Router Class Initialized
INFO - 2016-06-13 09:50:42 --> Output Class Initialized
INFO - 2016-06-13 09:50:42 --> Security Class Initialized
DEBUG - 2016-06-13 09:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:50:42 --> Input Class Initialized
INFO - 2016-06-13 09:50:42 --> Language Class Initialized
ERROR - 2016-06-13 09:50:42 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 09:50:55 --> Config Class Initialized
INFO - 2016-06-13 09:50:55 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:50:55 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:50:55 --> Utf8 Class Initialized
INFO - 2016-06-13 09:50:55 --> URI Class Initialized
INFO - 2016-06-13 09:50:55 --> Router Class Initialized
INFO - 2016-06-13 09:50:55 --> Output Class Initialized
INFO - 2016-06-13 09:50:55 --> Security Class Initialized
DEBUG - 2016-06-13 09:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:50:55 --> Input Class Initialized
INFO - 2016-06-13 09:50:55 --> Language Class Initialized
INFO - 2016-06-13 09:50:55 --> Loader Class Initialized
INFO - 2016-06-13 09:50:55 --> Helper loaded: form_helper
INFO - 2016-06-13 09:50:55 --> Database Driver Class Initialized
INFO - 2016-06-13 09:50:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:50:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:50:55 --> Email Class Initialized
INFO - 2016-06-13 09:50:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:50:55 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:50:55 --> Helper loaded: language_helper
INFO - 2016-06-13 09:50:55 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:50:55 --> Model Class Initialized
INFO - 2016-06-13 09:50:55 --> Helper loaded: date_helper
INFO - 2016-06-13 09:50:55 --> Controller Class Initialized
INFO - 2016-06-13 09:50:55 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:50:55 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:50:55 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:50:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:50:55 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:50:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:50:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-13 09:50:55 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:50:55 --> Form Validation Class Initialized
DEBUG - 2016-06-13 09:50:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:50:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-13 09:50:55 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-13 09:50:55 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-13 09:50:55 --> Final output sent to browser
DEBUG - 2016-06-13 09:50:55 --> Total execution time: 0.1025
INFO - 2016-06-13 09:51:04 --> Config Class Initialized
INFO - 2016-06-13 09:51:04 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:04 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:04 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:04 --> URI Class Initialized
INFO - 2016-06-13 09:51:04 --> Router Class Initialized
INFO - 2016-06-13 09:51:04 --> Output Class Initialized
INFO - 2016-06-13 09:51:04 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:04 --> Input Class Initialized
INFO - 2016-06-13 09:51:04 --> Language Class Initialized
INFO - 2016-06-13 09:51:04 --> Loader Class Initialized
INFO - 2016-06-13 09:51:04 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:04 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:04 --> Email Class Initialized
INFO - 2016-06-13 09:51:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:04 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:04 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:04 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:04 --> Model Class Initialized
INFO - 2016-06-13 09:51:04 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:04 --> Controller Class Initialized
INFO - 2016-06-13 09:51:04 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:04 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:04 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:04 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2016-06-13 09:51:04 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:04 --> Form Validation Class Initialized
DEBUG - 2016-06-13 09:51:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:05 --> Config Class Initialized
INFO - 2016-06-13 09:51:05 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:05 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:05 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:05 --> URI Class Initialized
DEBUG - 2016-06-13 09:51:05 --> No URI present. Default controller set.
INFO - 2016-06-13 09:51:05 --> Router Class Initialized
INFO - 2016-06-13 09:51:05 --> Output Class Initialized
INFO - 2016-06-13 09:51:05 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:05 --> Input Class Initialized
INFO - 2016-06-13 09:51:05 --> Language Class Initialized
INFO - 2016-06-13 09:51:05 --> Loader Class Initialized
INFO - 2016-06-13 09:51:05 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:05 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:05 --> Email Class Initialized
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:05 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:05 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:05 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:05 --> Model Class Initialized
INFO - 2016-06-13 09:51:05 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:05 --> Controller Class Initialized
INFO - 2016-06-13 09:51:05 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:51:05 --> Config Class Initialized
INFO - 2016-06-13 09:51:05 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:05 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:05 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:05 --> URI Class Initialized
INFO - 2016-06-13 09:51:05 --> Router Class Initialized
INFO - 2016-06-13 09:51:05 --> Output Class Initialized
INFO - 2016-06-13 09:51:05 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:05 --> Input Class Initialized
INFO - 2016-06-13 09:51:05 --> Language Class Initialized
INFO - 2016-06-13 09:51:05 --> Loader Class Initialized
INFO - 2016-06-13 09:51:05 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:05 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:05 --> Email Class Initialized
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:05 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:05 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:05 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:05 --> Model Class Initialized
INFO - 2016-06-13 09:51:05 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:05 --> Controller Class Initialized
INFO - 2016-06-13 09:51:05 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:51:05 --> Model Class Initialized
INFO - 2016-06-13 09:51:05 --> Form Validation Class Initialized
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:51:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:51:05 --> Final output sent to browser
DEBUG - 2016-06-13 09:51:05 --> Total execution time: 0.4638
INFO - 2016-06-13 09:51:08 --> Config Class Initialized
INFO - 2016-06-13 09:51:08 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:08 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:08 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:08 --> URI Class Initialized
INFO - 2016-06-13 09:51:08 --> Router Class Initialized
INFO - 2016-06-13 09:51:08 --> Output Class Initialized
INFO - 2016-06-13 09:51:08 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:08 --> Input Class Initialized
INFO - 2016-06-13 09:51:08 --> Language Class Initialized
INFO - 2016-06-13 09:51:08 --> Loader Class Initialized
INFO - 2016-06-13 09:51:08 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:08 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:08 --> Email Class Initialized
INFO - 2016-06-13 09:51:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:08 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:08 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:08 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:08 --> Model Class Initialized
INFO - 2016-06-13 09:51:08 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:08 --> Controller Class Initialized
INFO - 2016-06-13 09:51:08 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:08 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:08 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:08 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:08 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:08 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:51:08 --> Model Class Initialized
INFO - 2016-06-13 09:51:08 --> Form Validation Class Initialized
INFO - 2016-06-13 09:51:08 --> Final output sent to browser
DEBUG - 2016-06-13 09:51:08 --> Total execution time: 0.0299
INFO - 2016-06-13 09:51:11 --> Config Class Initialized
INFO - 2016-06-13 09:51:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:11 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:11 --> URI Class Initialized
INFO - 2016-06-13 09:51:11 --> Router Class Initialized
INFO - 2016-06-13 09:51:11 --> Output Class Initialized
INFO - 2016-06-13 09:51:11 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:11 --> Input Class Initialized
INFO - 2016-06-13 09:51:11 --> Language Class Initialized
INFO - 2016-06-13 09:51:11 --> Loader Class Initialized
INFO - 2016-06-13 09:51:11 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:11 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:11 --> Email Class Initialized
INFO - 2016-06-13 09:51:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:11 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:11 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:11 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:11 --> Model Class Initialized
INFO - 2016-06-13 09:51:11 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:11 --> Controller Class Initialized
INFO - 2016-06-13 09:51:11 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:51:11 --> Model Class Initialized
INFO - 2016-06-13 09:51:11 --> Form Validation Class Initialized
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:51:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:51:11 --> Final output sent to browser
DEBUG - 2016-06-13 09:51:11 --> Total execution time: 0.0941
INFO - 2016-06-13 09:51:13 --> Config Class Initialized
INFO - 2016-06-13 09:51:13 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:13 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:13 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:13 --> URI Class Initialized
INFO - 2016-06-13 09:51:13 --> Router Class Initialized
INFO - 2016-06-13 09:51:13 --> Output Class Initialized
INFO - 2016-06-13 09:51:13 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:13 --> Input Class Initialized
INFO - 2016-06-13 09:51:13 --> Language Class Initialized
INFO - 2016-06-13 09:51:13 --> Loader Class Initialized
INFO - 2016-06-13 09:51:13 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:13 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:13 --> Email Class Initialized
INFO - 2016-06-13 09:51:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:13 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:13 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:13 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:13 --> Model Class Initialized
INFO - 2016-06-13 09:51:13 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:13 --> Controller Class Initialized
INFO - 2016-06-13 09:51:13 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:13 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:13 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:13 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:13 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:51:13 --> Model Class Initialized
INFO - 2016-06-13 09:51:13 --> Form Validation Class Initialized
INFO - 2016-06-13 09:51:13 --> Final output sent to browser
DEBUG - 2016-06-13 09:51:13 --> Total execution time: 0.0154
INFO - 2016-06-13 09:51:40 --> Config Class Initialized
INFO - 2016-06-13 09:51:40 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:40 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:40 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:40 --> URI Class Initialized
INFO - 2016-06-13 09:51:40 --> Router Class Initialized
INFO - 2016-06-13 09:51:40 --> Output Class Initialized
INFO - 2016-06-13 09:51:40 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:40 --> Input Class Initialized
INFO - 2016-06-13 09:51:40 --> Language Class Initialized
INFO - 2016-06-13 09:51:40 --> Loader Class Initialized
INFO - 2016-06-13 09:51:40 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:40 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:40 --> Email Class Initialized
INFO - 2016-06-13 09:51:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:40 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:40 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:40 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:40 --> Model Class Initialized
INFO - 2016-06-13 09:51:40 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:40 --> Controller Class Initialized
INFO - 2016-06-13 09:51:40 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:40 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:40 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:40 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:40 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:51:40 --> Model Class Initialized
INFO - 2016-06-13 09:51:40 --> Form Validation Class Initialized
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:51:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:51:40 --> Final output sent to browser
DEBUG - 2016-06-13 09:51:40 --> Total execution time: 0.0474
INFO - 2016-06-13 09:51:45 --> Config Class Initialized
INFO - 2016-06-13 09:51:45 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:51:45 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:51:45 --> Utf8 Class Initialized
INFO - 2016-06-13 09:51:45 --> URI Class Initialized
INFO - 2016-06-13 09:51:45 --> Router Class Initialized
INFO - 2016-06-13 09:51:45 --> Output Class Initialized
INFO - 2016-06-13 09:51:45 --> Security Class Initialized
DEBUG - 2016-06-13 09:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:51:45 --> Input Class Initialized
INFO - 2016-06-13 09:51:45 --> Language Class Initialized
INFO - 2016-06-13 09:51:45 --> Loader Class Initialized
INFO - 2016-06-13 09:51:45 --> Helper loaded: form_helper
INFO - 2016-06-13 09:51:45 --> Database Driver Class Initialized
INFO - 2016-06-13 09:51:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:51:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:51:45 --> Email Class Initialized
INFO - 2016-06-13 09:51:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:51:45 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:51:45 --> Helper loaded: language_helper
INFO - 2016-06-13 09:51:45 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:51:45 --> Model Class Initialized
INFO - 2016-06-13 09:51:45 --> Helper loaded: date_helper
INFO - 2016-06-13 09:51:45 --> Controller Class Initialized
INFO - 2016-06-13 09:51:45 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:51:45 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:51:45 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:51:45 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:51:45 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:51:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:51:45 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:51:45 --> Model Class Initialized
INFO - 2016-06-13 09:51:45 --> Form Validation Class Initialized
INFO - 2016-06-13 09:51:45 --> Final output sent to browser
DEBUG - 2016-06-13 09:51:45 --> Total execution time: 0.0402
INFO - 2016-06-13 09:52:05 --> Config Class Initialized
INFO - 2016-06-13 09:52:05 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:52:05 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:52:05 --> Utf8 Class Initialized
INFO - 2016-06-13 09:52:05 --> URI Class Initialized
INFO - 2016-06-13 09:52:05 --> Router Class Initialized
INFO - 2016-06-13 09:52:05 --> Output Class Initialized
INFO - 2016-06-13 09:52:05 --> Security Class Initialized
DEBUG - 2016-06-13 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:52:05 --> Input Class Initialized
INFO - 2016-06-13 09:52:05 --> Language Class Initialized
INFO - 2016-06-13 09:52:05 --> Loader Class Initialized
INFO - 2016-06-13 09:52:05 --> Helper loaded: form_helper
INFO - 2016-06-13 09:52:05 --> Database Driver Class Initialized
INFO - 2016-06-13 09:52:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:52:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:52:05 --> Email Class Initialized
INFO - 2016-06-13 09:52:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:52:05 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:52:05 --> Helper loaded: language_helper
INFO - 2016-06-13 09:52:05 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:52:05 --> Model Class Initialized
INFO - 2016-06-13 09:52:05 --> Helper loaded: date_helper
INFO - 2016-06-13 09:52:05 --> Controller Class Initialized
INFO - 2016-06-13 09:52:05 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:52:05 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:52:05 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:52:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:52:05 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:52:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:52:05 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:52:05 --> Model Class Initialized
INFO - 2016-06-13 09:52:05 --> Form Validation Class Initialized
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:52:05 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:52:05 --> Final output sent to browser
DEBUG - 2016-06-13 09:52:05 --> Total execution time: 0.0980
INFO - 2016-06-13 09:52:11 --> Config Class Initialized
INFO - 2016-06-13 09:52:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:52:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:52:11 --> Utf8 Class Initialized
INFO - 2016-06-13 09:52:11 --> URI Class Initialized
INFO - 2016-06-13 09:52:11 --> Router Class Initialized
INFO - 2016-06-13 09:52:11 --> Output Class Initialized
INFO - 2016-06-13 09:52:11 --> Security Class Initialized
DEBUG - 2016-06-13 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:52:11 --> Input Class Initialized
INFO - 2016-06-13 09:52:11 --> Language Class Initialized
INFO - 2016-06-13 09:52:11 --> Loader Class Initialized
INFO - 2016-06-13 09:52:11 --> Helper loaded: form_helper
INFO - 2016-06-13 09:52:11 --> Database Driver Class Initialized
INFO - 2016-06-13 09:52:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:52:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:52:11 --> Email Class Initialized
INFO - 2016-06-13 09:52:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:52:11 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:52:11 --> Helper loaded: language_helper
INFO - 2016-06-13 09:52:11 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:52:11 --> Model Class Initialized
INFO - 2016-06-13 09:52:11 --> Helper loaded: date_helper
INFO - 2016-06-13 09:52:11 --> Controller Class Initialized
INFO - 2016-06-13 09:52:11 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:52:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:52:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:52:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:52:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:52:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:52:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:52:11 --> Model Class Initialized
INFO - 2016-06-13 09:52:11 --> Form Validation Class Initialized
INFO - 2016-06-13 09:52:11 --> Final output sent to browser
DEBUG - 2016-06-13 09:52:11 --> Total execution time: 0.0433
INFO - 2016-06-13 09:52:38 --> Config Class Initialized
INFO - 2016-06-13 09:52:38 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:52:38 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:52:38 --> Utf8 Class Initialized
INFO - 2016-06-13 09:52:38 --> URI Class Initialized
INFO - 2016-06-13 09:52:38 --> Router Class Initialized
INFO - 2016-06-13 09:52:38 --> Output Class Initialized
INFO - 2016-06-13 09:52:38 --> Security Class Initialized
DEBUG - 2016-06-13 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:52:38 --> Input Class Initialized
INFO - 2016-06-13 09:52:38 --> Language Class Initialized
INFO - 2016-06-13 09:52:38 --> Loader Class Initialized
INFO - 2016-06-13 09:52:38 --> Helper loaded: form_helper
INFO - 2016-06-13 09:52:38 --> Database Driver Class Initialized
INFO - 2016-06-13 09:52:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:52:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:52:38 --> Email Class Initialized
INFO - 2016-06-13 09:52:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:52:38 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:52:38 --> Helper loaded: language_helper
INFO - 2016-06-13 09:52:38 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:52:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:52:38 --> Model Class Initialized
INFO - 2016-06-13 09:52:38 --> Helper loaded: date_helper
INFO - 2016-06-13 09:52:38 --> Controller Class Initialized
INFO - 2016-06-13 09:52:38 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:52:38 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:52:38 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:52:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:52:38 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:52:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:52:38 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:52:38 --> Model Class Initialized
INFO - 2016-06-13 09:52:39 --> Form Validation Class Initialized
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:52:39 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:52:39 --> Final output sent to browser
DEBUG - 2016-06-13 09:52:39 --> Total execution time: 0.1211
INFO - 2016-06-13 09:52:42 --> Config Class Initialized
INFO - 2016-06-13 09:52:42 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:52:42 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:52:42 --> Utf8 Class Initialized
INFO - 2016-06-13 09:52:42 --> URI Class Initialized
INFO - 2016-06-13 09:52:42 --> Router Class Initialized
INFO - 2016-06-13 09:52:42 --> Output Class Initialized
INFO - 2016-06-13 09:52:42 --> Security Class Initialized
DEBUG - 2016-06-13 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:52:42 --> Input Class Initialized
INFO - 2016-06-13 09:52:42 --> Language Class Initialized
INFO - 2016-06-13 09:52:42 --> Loader Class Initialized
INFO - 2016-06-13 09:52:42 --> Helper loaded: form_helper
INFO - 2016-06-13 09:52:42 --> Database Driver Class Initialized
INFO - 2016-06-13 09:52:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:52:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:52:42 --> Email Class Initialized
INFO - 2016-06-13 09:52:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:52:42 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:52:42 --> Helper loaded: language_helper
INFO - 2016-06-13 09:52:42 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:52:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:52:42 --> Model Class Initialized
INFO - 2016-06-13 09:52:42 --> Helper loaded: date_helper
INFO - 2016-06-13 09:52:42 --> Controller Class Initialized
INFO - 2016-06-13 09:52:42 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:52:42 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:52:42 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:52:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:52:42 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:52:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:52:42 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:52:42 --> Model Class Initialized
INFO - 2016-06-13 09:52:42 --> Form Validation Class Initialized
INFO - 2016-06-13 09:52:43 --> Final output sent to browser
DEBUG - 2016-06-13 09:52:43 --> Total execution time: 0.0181
INFO - 2016-06-13 09:56:37 --> Config Class Initialized
INFO - 2016-06-13 09:56:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:56:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:56:37 --> Utf8 Class Initialized
INFO - 2016-06-13 09:56:37 --> URI Class Initialized
INFO - 2016-06-13 09:56:37 --> Router Class Initialized
INFO - 2016-06-13 09:56:37 --> Output Class Initialized
INFO - 2016-06-13 09:56:37 --> Security Class Initialized
DEBUG - 2016-06-13 09:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:56:37 --> Input Class Initialized
INFO - 2016-06-13 09:56:37 --> Language Class Initialized
INFO - 2016-06-13 09:56:37 --> Loader Class Initialized
INFO - 2016-06-13 09:56:37 --> Helper loaded: form_helper
INFO - 2016-06-13 09:56:37 --> Database Driver Class Initialized
INFO - 2016-06-13 09:56:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:56:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:56:37 --> Email Class Initialized
INFO - 2016-06-13 09:56:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:56:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:56:37 --> Helper loaded: language_helper
INFO - 2016-06-13 09:56:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:56:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:56:37 --> Model Class Initialized
INFO - 2016-06-13 09:56:37 --> Helper loaded: date_helper
INFO - 2016-06-13 09:56:37 --> Controller Class Initialized
INFO - 2016-06-13 09:56:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:56:37 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:56:37 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:56:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:56:37 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:56:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:56:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:56:37 --> Model Class Initialized
INFO - 2016-06-13 09:56:37 --> Form Validation Class Initialized
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:56:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:56:37 --> Final output sent to browser
DEBUG - 2016-06-13 09:56:37 --> Total execution time: 0.0295
INFO - 2016-06-13 09:56:41 --> Config Class Initialized
INFO - 2016-06-13 09:56:41 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:56:41 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:56:41 --> Utf8 Class Initialized
INFO - 2016-06-13 09:56:41 --> URI Class Initialized
INFO - 2016-06-13 09:56:41 --> Router Class Initialized
INFO - 2016-06-13 09:56:41 --> Output Class Initialized
INFO - 2016-06-13 09:56:41 --> Security Class Initialized
DEBUG - 2016-06-13 09:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:56:41 --> Input Class Initialized
INFO - 2016-06-13 09:56:41 --> Language Class Initialized
INFO - 2016-06-13 09:56:41 --> Loader Class Initialized
INFO - 2016-06-13 09:56:41 --> Helper loaded: form_helper
INFO - 2016-06-13 09:56:41 --> Database Driver Class Initialized
INFO - 2016-06-13 09:56:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:56:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:56:41 --> Email Class Initialized
INFO - 2016-06-13 09:56:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:56:41 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:56:41 --> Helper loaded: language_helper
INFO - 2016-06-13 09:56:41 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:56:41 --> Model Class Initialized
INFO - 2016-06-13 09:56:41 --> Helper loaded: date_helper
INFO - 2016-06-13 09:56:41 --> Controller Class Initialized
INFO - 2016-06-13 09:56:41 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:56:41 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:56:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:56:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:56:41 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:56:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:56:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:56:41 --> Model Class Initialized
INFO - 2016-06-13 09:56:41 --> Form Validation Class Initialized
INFO - 2016-06-13 09:56:41 --> Final output sent to browser
DEBUG - 2016-06-13 09:56:41 --> Total execution time: 0.0400
INFO - 2016-06-13 09:57:25 --> Config Class Initialized
INFO - 2016-06-13 09:57:25 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:57:25 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:57:25 --> Utf8 Class Initialized
INFO - 2016-06-13 09:57:25 --> URI Class Initialized
INFO - 2016-06-13 09:57:25 --> Router Class Initialized
INFO - 2016-06-13 09:57:25 --> Output Class Initialized
INFO - 2016-06-13 09:57:25 --> Security Class Initialized
DEBUG - 2016-06-13 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:57:25 --> Input Class Initialized
INFO - 2016-06-13 09:57:25 --> Language Class Initialized
INFO - 2016-06-13 09:57:25 --> Loader Class Initialized
INFO - 2016-06-13 09:57:25 --> Helper loaded: form_helper
INFO - 2016-06-13 09:57:25 --> Database Driver Class Initialized
INFO - 2016-06-13 09:57:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:57:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:57:25 --> Email Class Initialized
INFO - 2016-06-13 09:57:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:57:25 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:57:25 --> Helper loaded: language_helper
INFO - 2016-06-13 09:57:25 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:57:25 --> Model Class Initialized
INFO - 2016-06-13 09:57:25 --> Helper loaded: date_helper
INFO - 2016-06-13 09:57:25 --> Controller Class Initialized
INFO - 2016-06-13 09:57:25 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:57:25 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:57:25 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:57:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:57:25 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:57:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:57:25 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:57:25 --> Model Class Initialized
INFO - 2016-06-13 09:57:25 --> Form Validation Class Initialized
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:57:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:57:25 --> Final output sent to browser
DEBUG - 2016-06-13 09:57:25 --> Total execution time: 0.0359
INFO - 2016-06-13 09:57:30 --> Config Class Initialized
INFO - 2016-06-13 09:57:30 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:57:30 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:57:30 --> Utf8 Class Initialized
INFO - 2016-06-13 09:57:30 --> URI Class Initialized
INFO - 2016-06-13 09:57:30 --> Router Class Initialized
INFO - 2016-06-13 09:57:30 --> Output Class Initialized
INFO - 2016-06-13 09:57:30 --> Security Class Initialized
DEBUG - 2016-06-13 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:57:30 --> Input Class Initialized
INFO - 2016-06-13 09:57:30 --> Language Class Initialized
INFO - 2016-06-13 09:57:30 --> Loader Class Initialized
INFO - 2016-06-13 09:57:30 --> Helper loaded: form_helper
INFO - 2016-06-13 09:57:30 --> Database Driver Class Initialized
INFO - 2016-06-13 09:57:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:57:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:57:30 --> Email Class Initialized
INFO - 2016-06-13 09:57:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:57:30 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:57:30 --> Helper loaded: language_helper
INFO - 2016-06-13 09:57:30 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:57:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:57:30 --> Model Class Initialized
INFO - 2016-06-13 09:57:30 --> Helper loaded: date_helper
INFO - 2016-06-13 09:57:30 --> Controller Class Initialized
INFO - 2016-06-13 09:57:30 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:57:30 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:57:30 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:57:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:57:30 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:57:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:57:30 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:57:30 --> Model Class Initialized
INFO - 2016-06-13 09:57:30 --> Form Validation Class Initialized
INFO - 2016-06-13 09:57:30 --> Final output sent to browser
DEBUG - 2016-06-13 09:57:30 --> Total execution time: 0.0576
INFO - 2016-06-13 09:57:54 --> Config Class Initialized
INFO - 2016-06-13 09:57:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:57:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:57:54 --> Utf8 Class Initialized
INFO - 2016-06-13 09:57:54 --> URI Class Initialized
INFO - 2016-06-13 09:57:54 --> Router Class Initialized
INFO - 2016-06-13 09:57:54 --> Output Class Initialized
INFO - 2016-06-13 09:57:54 --> Security Class Initialized
DEBUG - 2016-06-13 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:57:54 --> Input Class Initialized
INFO - 2016-06-13 09:57:54 --> Language Class Initialized
INFO - 2016-06-13 09:57:54 --> Loader Class Initialized
INFO - 2016-06-13 09:57:54 --> Helper loaded: form_helper
INFO - 2016-06-13 09:57:54 --> Database Driver Class Initialized
INFO - 2016-06-13 09:57:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:57:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:57:54 --> Email Class Initialized
INFO - 2016-06-13 09:57:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:57:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:57:54 --> Helper loaded: language_helper
INFO - 2016-06-13 09:57:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:57:54 --> Model Class Initialized
INFO - 2016-06-13 09:57:54 --> Helper loaded: date_helper
INFO - 2016-06-13 09:57:54 --> Controller Class Initialized
INFO - 2016-06-13 09:57:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:57:54 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:57:54 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:57:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:57:54 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:57:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:57:54 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:57:54 --> Model Class Initialized
INFO - 2016-06-13 09:57:54 --> Form Validation Class Initialized
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:57:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:57:54 --> Final output sent to browser
DEBUG - 2016-06-13 09:57:54 --> Total execution time: 0.0982
INFO - 2016-06-13 09:57:59 --> Config Class Initialized
INFO - 2016-06-13 09:57:59 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:57:59 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:57:59 --> Utf8 Class Initialized
INFO - 2016-06-13 09:57:59 --> URI Class Initialized
INFO - 2016-06-13 09:57:59 --> Router Class Initialized
INFO - 2016-06-13 09:57:59 --> Output Class Initialized
INFO - 2016-06-13 09:57:59 --> Security Class Initialized
DEBUG - 2016-06-13 09:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:57:59 --> Input Class Initialized
INFO - 2016-06-13 09:57:59 --> Language Class Initialized
INFO - 2016-06-13 09:57:59 --> Loader Class Initialized
INFO - 2016-06-13 09:57:59 --> Helper loaded: form_helper
INFO - 2016-06-13 09:57:59 --> Database Driver Class Initialized
INFO - 2016-06-13 09:57:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:57:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:57:59 --> Email Class Initialized
INFO - 2016-06-13 09:57:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:57:59 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:57:59 --> Helper loaded: language_helper
INFO - 2016-06-13 09:57:59 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:57:59 --> Model Class Initialized
INFO - 2016-06-13 09:57:59 --> Helper loaded: date_helper
INFO - 2016-06-13 09:57:59 --> Controller Class Initialized
INFO - 2016-06-13 09:57:59 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:57:59 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:57:59 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:57:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:57:59 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:57:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:57:59 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:57:59 --> Model Class Initialized
INFO - 2016-06-13 09:57:59 --> Form Validation Class Initialized
INFO - 2016-06-13 09:57:59 --> Final output sent to browser
DEBUG - 2016-06-13 09:57:59 --> Total execution time: 0.0597
INFO - 2016-06-13 09:59:57 --> Config Class Initialized
INFO - 2016-06-13 09:59:57 --> Hooks Class Initialized
DEBUG - 2016-06-13 09:59:57 --> UTF-8 Support Enabled
INFO - 2016-06-13 09:59:57 --> Utf8 Class Initialized
INFO - 2016-06-13 09:59:57 --> URI Class Initialized
INFO - 2016-06-13 09:59:57 --> Router Class Initialized
INFO - 2016-06-13 09:59:57 --> Output Class Initialized
INFO - 2016-06-13 09:59:57 --> Security Class Initialized
DEBUG - 2016-06-13 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 09:59:57 --> Input Class Initialized
INFO - 2016-06-13 09:59:57 --> Language Class Initialized
INFO - 2016-06-13 09:59:57 --> Loader Class Initialized
INFO - 2016-06-13 09:59:57 --> Helper loaded: form_helper
INFO - 2016-06-13 09:59:57 --> Database Driver Class Initialized
INFO - 2016-06-13 09:59:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 09:59:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 09:59:57 --> Email Class Initialized
INFO - 2016-06-13 09:59:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 09:59:57 --> Helper loaded: cookie_helper
INFO - 2016-06-13 09:59:57 --> Helper loaded: language_helper
INFO - 2016-06-13 09:59:57 --> Helper loaded: url_helper
DEBUG - 2016-06-13 09:59:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 09:59:57 --> Model Class Initialized
INFO - 2016-06-13 09:59:57 --> Helper loaded: date_helper
INFO - 2016-06-13 09:59:57 --> Controller Class Initialized
INFO - 2016-06-13 09:59:57 --> Helper loaded: languages_helper
INFO - 2016-06-13 09:59:57 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 09:59:57 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 09:59:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 09:59:57 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 09:59:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 09:59:57 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 09:59:57 --> Model Class Initialized
INFO - 2016-06-13 09:59:57 --> Form Validation Class Initialized
INFO - 2016-06-13 09:59:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 09:59:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 09:59:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 09:59:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 09:59:57 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 09:59:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 09:59:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 09:59:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 09:59:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 09:59:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 09:59:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 09:59:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 09:59:58 --> Final output sent to browser
DEBUG - 2016-06-13 09:59:58 --> Total execution time: 0.0956
INFO - 2016-06-13 10:00:02 --> Config Class Initialized
INFO - 2016-06-13 10:00:02 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:00:02 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:00:02 --> Utf8 Class Initialized
INFO - 2016-06-13 10:00:02 --> URI Class Initialized
INFO - 2016-06-13 10:00:02 --> Router Class Initialized
INFO - 2016-06-13 10:00:02 --> Output Class Initialized
INFO - 2016-06-13 10:00:02 --> Security Class Initialized
DEBUG - 2016-06-13 10:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:00:02 --> Input Class Initialized
INFO - 2016-06-13 10:00:02 --> Language Class Initialized
INFO - 2016-06-13 10:00:02 --> Loader Class Initialized
INFO - 2016-06-13 10:00:02 --> Helper loaded: form_helper
INFO - 2016-06-13 10:00:02 --> Database Driver Class Initialized
INFO - 2016-06-13 10:00:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:00:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:00:02 --> Email Class Initialized
INFO - 2016-06-13 10:00:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:00:02 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:00:02 --> Helper loaded: language_helper
INFO - 2016-06-13 10:00:02 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:00:02 --> Model Class Initialized
INFO - 2016-06-13 10:00:02 --> Helper loaded: date_helper
INFO - 2016-06-13 10:00:02 --> Controller Class Initialized
INFO - 2016-06-13 10:00:02 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:00:02 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:00:02 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:00:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:00:02 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:00:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:00:02 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:00:02 --> Model Class Initialized
INFO - 2016-06-13 10:00:02 --> Form Validation Class Initialized
INFO - 2016-06-13 10:00:02 --> Final output sent to browser
DEBUG - 2016-06-13 10:00:02 --> Total execution time: 0.0625
INFO - 2016-06-13 10:04:48 --> Config Class Initialized
INFO - 2016-06-13 10:04:48 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:04:48 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:04:48 --> Utf8 Class Initialized
INFO - 2016-06-13 10:04:48 --> URI Class Initialized
INFO - 2016-06-13 10:04:48 --> Router Class Initialized
INFO - 2016-06-13 10:04:48 --> Output Class Initialized
INFO - 2016-06-13 10:04:48 --> Security Class Initialized
DEBUG - 2016-06-13 10:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:04:48 --> Input Class Initialized
INFO - 2016-06-13 10:04:48 --> Language Class Initialized
INFO - 2016-06-13 10:04:48 --> Loader Class Initialized
INFO - 2016-06-13 10:04:48 --> Helper loaded: form_helper
INFO - 2016-06-13 10:04:48 --> Database Driver Class Initialized
INFO - 2016-06-13 10:04:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:04:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:04:48 --> Email Class Initialized
INFO - 2016-06-13 10:04:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:04:48 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:04:48 --> Helper loaded: language_helper
INFO - 2016-06-13 10:04:48 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:04:48 --> Model Class Initialized
INFO - 2016-06-13 10:04:48 --> Helper loaded: date_helper
INFO - 2016-06-13 10:04:48 --> Controller Class Initialized
INFO - 2016-06-13 10:04:48 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:04:48 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:04:48 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:04:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:04:48 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:04:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:04:48 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:04:48 --> Model Class Initialized
INFO - 2016-06-13 10:04:48 --> Form Validation Class Initialized
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:04:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:04:48 --> Final output sent to browser
DEBUG - 2016-06-13 10:04:48 --> Total execution time: 0.0389
INFO - 2016-06-13 10:04:52 --> Config Class Initialized
INFO - 2016-06-13 10:04:52 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:04:52 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:04:52 --> Utf8 Class Initialized
INFO - 2016-06-13 10:04:52 --> URI Class Initialized
INFO - 2016-06-13 10:04:52 --> Router Class Initialized
INFO - 2016-06-13 10:04:52 --> Output Class Initialized
INFO - 2016-06-13 10:04:52 --> Security Class Initialized
DEBUG - 2016-06-13 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:04:52 --> Input Class Initialized
INFO - 2016-06-13 10:04:52 --> Language Class Initialized
INFO - 2016-06-13 10:04:52 --> Loader Class Initialized
INFO - 2016-06-13 10:04:52 --> Helper loaded: form_helper
INFO - 2016-06-13 10:04:52 --> Database Driver Class Initialized
INFO - 2016-06-13 10:04:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:04:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:04:52 --> Email Class Initialized
INFO - 2016-06-13 10:04:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:04:52 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:04:52 --> Helper loaded: language_helper
INFO - 2016-06-13 10:04:52 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:04:52 --> Model Class Initialized
INFO - 2016-06-13 10:04:52 --> Helper loaded: date_helper
INFO - 2016-06-13 10:04:52 --> Controller Class Initialized
INFO - 2016-06-13 10:04:52 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:04:52 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:04:52 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:04:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:04:52 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:04:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:04:52 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:04:52 --> Model Class Initialized
INFO - 2016-06-13 10:04:52 --> Form Validation Class Initialized
INFO - 2016-06-13 10:04:52 --> Final output sent to browser
DEBUG - 2016-06-13 10:04:52 --> Total execution time: 0.0349
INFO - 2016-06-13 10:05:41 --> Config Class Initialized
INFO - 2016-06-13 10:05:41 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:05:41 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:05:41 --> Utf8 Class Initialized
INFO - 2016-06-13 10:05:41 --> URI Class Initialized
INFO - 2016-06-13 10:05:41 --> Router Class Initialized
INFO - 2016-06-13 10:05:41 --> Output Class Initialized
INFO - 2016-06-13 10:05:41 --> Security Class Initialized
DEBUG - 2016-06-13 10:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:05:41 --> Input Class Initialized
INFO - 2016-06-13 10:05:41 --> Language Class Initialized
INFO - 2016-06-13 10:05:41 --> Loader Class Initialized
INFO - 2016-06-13 10:05:41 --> Helper loaded: form_helper
INFO - 2016-06-13 10:05:41 --> Database Driver Class Initialized
INFO - 2016-06-13 10:05:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:05:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:05:41 --> Email Class Initialized
INFO - 2016-06-13 10:05:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:05:41 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:05:41 --> Helper loaded: language_helper
INFO - 2016-06-13 10:05:41 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:05:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:05:41 --> Model Class Initialized
INFO - 2016-06-13 10:05:41 --> Helper loaded: date_helper
INFO - 2016-06-13 10:05:41 --> Controller Class Initialized
INFO - 2016-06-13 10:05:41 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:05:41 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:05:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:05:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:05:41 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:05:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:05:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:05:41 --> Model Class Initialized
INFO - 2016-06-13 10:05:41 --> Form Validation Class Initialized
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:05:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:05:41 --> Final output sent to browser
DEBUG - 2016-06-13 10:05:41 --> Total execution time: 0.0831
INFO - 2016-06-13 10:05:47 --> Config Class Initialized
INFO - 2016-06-13 10:05:47 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:05:47 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:05:47 --> Utf8 Class Initialized
INFO - 2016-06-13 10:05:47 --> URI Class Initialized
INFO - 2016-06-13 10:05:47 --> Router Class Initialized
INFO - 2016-06-13 10:05:47 --> Output Class Initialized
INFO - 2016-06-13 10:05:47 --> Security Class Initialized
DEBUG - 2016-06-13 10:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:05:47 --> Input Class Initialized
INFO - 2016-06-13 10:05:47 --> Language Class Initialized
INFO - 2016-06-13 10:05:47 --> Loader Class Initialized
INFO - 2016-06-13 10:05:47 --> Helper loaded: form_helper
INFO - 2016-06-13 10:05:47 --> Database Driver Class Initialized
INFO - 2016-06-13 10:05:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:05:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:05:47 --> Email Class Initialized
INFO - 2016-06-13 10:05:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:05:47 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:05:47 --> Helper loaded: language_helper
INFO - 2016-06-13 10:05:47 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:05:47 --> Model Class Initialized
INFO - 2016-06-13 10:05:47 --> Helper loaded: date_helper
INFO - 2016-06-13 10:05:47 --> Controller Class Initialized
INFO - 2016-06-13 10:05:47 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:05:47 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:05:47 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:05:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:05:47 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:05:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:05:47 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:05:47 --> Model Class Initialized
INFO - 2016-06-13 10:05:47 --> Form Validation Class Initialized
INFO - 2016-06-13 10:05:47 --> Final output sent to browser
DEBUG - 2016-06-13 10:05:47 --> Total execution time: 0.0594
INFO - 2016-06-13 10:06:37 --> Config Class Initialized
INFO - 2016-06-13 10:06:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:06:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:06:37 --> Utf8 Class Initialized
INFO - 2016-06-13 10:06:37 --> URI Class Initialized
INFO - 2016-06-13 10:06:37 --> Router Class Initialized
INFO - 2016-06-13 10:06:37 --> Output Class Initialized
INFO - 2016-06-13 10:06:37 --> Security Class Initialized
DEBUG - 2016-06-13 10:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:06:37 --> Input Class Initialized
INFO - 2016-06-13 10:06:37 --> Language Class Initialized
INFO - 2016-06-13 10:06:37 --> Loader Class Initialized
INFO - 2016-06-13 10:06:37 --> Helper loaded: form_helper
INFO - 2016-06-13 10:06:37 --> Database Driver Class Initialized
INFO - 2016-06-13 10:06:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:06:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:06:37 --> Email Class Initialized
INFO - 2016-06-13 10:06:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:06:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:06:37 --> Helper loaded: language_helper
INFO - 2016-06-13 10:06:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:06:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:06:37 --> Model Class Initialized
INFO - 2016-06-13 10:06:37 --> Helper loaded: date_helper
INFO - 2016-06-13 10:06:37 --> Controller Class Initialized
INFO - 2016-06-13 10:06:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:06:37 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:06:37 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:06:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:06:37 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:06:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:06:37 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:06:37 --> Model Class Initialized
INFO - 2016-06-13 10:06:37 --> Form Validation Class Initialized
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:06:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:06:37 --> Final output sent to browser
DEBUG - 2016-06-13 10:06:37 --> Total execution time: 0.0528
INFO - 2016-06-13 10:06:41 --> Config Class Initialized
INFO - 2016-06-13 10:06:41 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:06:41 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:06:41 --> Utf8 Class Initialized
INFO - 2016-06-13 10:06:41 --> URI Class Initialized
INFO - 2016-06-13 10:06:41 --> Router Class Initialized
INFO - 2016-06-13 10:06:41 --> Output Class Initialized
INFO - 2016-06-13 10:06:41 --> Security Class Initialized
DEBUG - 2016-06-13 10:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:06:41 --> Input Class Initialized
INFO - 2016-06-13 10:06:41 --> Language Class Initialized
INFO - 2016-06-13 10:06:41 --> Loader Class Initialized
INFO - 2016-06-13 10:06:41 --> Helper loaded: form_helper
INFO - 2016-06-13 10:06:41 --> Database Driver Class Initialized
INFO - 2016-06-13 10:06:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:06:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:06:41 --> Email Class Initialized
INFO - 2016-06-13 10:06:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:06:41 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:06:41 --> Helper loaded: language_helper
INFO - 2016-06-13 10:06:41 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:06:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:06:41 --> Model Class Initialized
INFO - 2016-06-13 10:06:41 --> Helper loaded: date_helper
INFO - 2016-06-13 10:06:41 --> Controller Class Initialized
INFO - 2016-06-13 10:06:41 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:06:41 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:06:41 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:06:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:06:41 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:06:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:06:41 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:06:41 --> Model Class Initialized
INFO - 2016-06-13 10:06:41 --> Form Validation Class Initialized
INFO - 2016-06-13 10:06:41 --> Final output sent to browser
DEBUG - 2016-06-13 10:06:41 --> Total execution time: 0.0581
INFO - 2016-06-13 10:07:09 --> Config Class Initialized
INFO - 2016-06-13 10:07:09 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:07:09 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:07:09 --> Utf8 Class Initialized
INFO - 2016-06-13 10:07:09 --> URI Class Initialized
INFO - 2016-06-13 10:07:09 --> Router Class Initialized
INFO - 2016-06-13 10:07:09 --> Output Class Initialized
INFO - 2016-06-13 10:07:09 --> Security Class Initialized
DEBUG - 2016-06-13 10:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:07:09 --> Input Class Initialized
INFO - 2016-06-13 10:07:09 --> Language Class Initialized
INFO - 2016-06-13 10:07:09 --> Loader Class Initialized
INFO - 2016-06-13 10:07:09 --> Helper loaded: form_helper
INFO - 2016-06-13 10:07:09 --> Database Driver Class Initialized
INFO - 2016-06-13 10:07:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:07:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:07:09 --> Email Class Initialized
INFO - 2016-06-13 10:07:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:07:09 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:07:09 --> Helper loaded: language_helper
INFO - 2016-06-13 10:07:09 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:07:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:07:09 --> Model Class Initialized
INFO - 2016-06-13 10:07:09 --> Helper loaded: date_helper
INFO - 2016-06-13 10:07:09 --> Controller Class Initialized
INFO - 2016-06-13 10:07:09 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:07:09 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:07:09 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:07:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:07:09 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:07:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:07:09 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:07:09 --> Model Class Initialized
INFO - 2016-06-13 10:07:09 --> Form Validation Class Initialized
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:07:09 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:07:09 --> Final output sent to browser
DEBUG - 2016-06-13 10:07:09 --> Total execution time: 0.0997
INFO - 2016-06-13 10:07:16 --> Config Class Initialized
INFO - 2016-06-13 10:07:16 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:07:16 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:07:16 --> Utf8 Class Initialized
INFO - 2016-06-13 10:07:16 --> URI Class Initialized
INFO - 2016-06-13 10:07:16 --> Router Class Initialized
INFO - 2016-06-13 10:07:16 --> Output Class Initialized
INFO - 2016-06-13 10:07:16 --> Security Class Initialized
DEBUG - 2016-06-13 10:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:07:16 --> Input Class Initialized
INFO - 2016-06-13 10:07:16 --> Language Class Initialized
INFO - 2016-06-13 10:07:16 --> Loader Class Initialized
INFO - 2016-06-13 10:07:16 --> Helper loaded: form_helper
INFO - 2016-06-13 10:07:16 --> Database Driver Class Initialized
INFO - 2016-06-13 10:07:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:07:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:07:16 --> Email Class Initialized
INFO - 2016-06-13 10:07:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:07:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:07:16 --> Helper loaded: language_helper
INFO - 2016-06-13 10:07:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:07:16 --> Model Class Initialized
INFO - 2016-06-13 10:07:16 --> Helper loaded: date_helper
INFO - 2016-06-13 10:07:16 --> Controller Class Initialized
INFO - 2016-06-13 10:07:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:07:16 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:07:16 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:07:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:07:16 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:07:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:07:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:07:16 --> Model Class Initialized
INFO - 2016-06-13 10:07:16 --> Form Validation Class Initialized
INFO - 2016-06-13 10:07:16 --> Final output sent to browser
DEBUG - 2016-06-13 10:07:16 --> Total execution time: 0.0366
INFO - 2016-06-13 10:10:26 --> Config Class Initialized
INFO - 2016-06-13 10:10:26 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:10:26 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:10:26 --> Utf8 Class Initialized
INFO - 2016-06-13 10:10:26 --> URI Class Initialized
INFO - 2016-06-13 10:10:26 --> Router Class Initialized
INFO - 2016-06-13 10:10:26 --> Output Class Initialized
INFO - 2016-06-13 10:10:26 --> Security Class Initialized
DEBUG - 2016-06-13 10:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:10:26 --> Input Class Initialized
INFO - 2016-06-13 10:10:26 --> Language Class Initialized
INFO - 2016-06-13 10:10:26 --> Loader Class Initialized
INFO - 2016-06-13 10:10:26 --> Helper loaded: form_helper
INFO - 2016-06-13 10:10:26 --> Database Driver Class Initialized
INFO - 2016-06-13 10:10:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:10:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:10:26 --> Email Class Initialized
INFO - 2016-06-13 10:10:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:10:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:10:26 --> Helper loaded: language_helper
INFO - 2016-06-13 10:10:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:10:26 --> Model Class Initialized
INFO - 2016-06-13 10:10:26 --> Helper loaded: date_helper
INFO - 2016-06-13 10:10:26 --> Controller Class Initialized
INFO - 2016-06-13 10:10:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:10:26 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:10:26 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:10:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:10:26 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:10:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:10:26 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:10:26 --> Model Class Initialized
INFO - 2016-06-13 10:10:26 --> Form Validation Class Initialized
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:10:26 --> Final output sent to browser
DEBUG - 2016-06-13 10:10:26 --> Total execution time: 0.0480
INFO - 2016-06-13 10:10:33 --> Config Class Initialized
INFO - 2016-06-13 10:10:33 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:10:33 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:10:33 --> Utf8 Class Initialized
INFO - 2016-06-13 10:10:33 --> URI Class Initialized
INFO - 2016-06-13 10:10:33 --> Router Class Initialized
INFO - 2016-06-13 10:10:33 --> Output Class Initialized
INFO - 2016-06-13 10:10:33 --> Security Class Initialized
DEBUG - 2016-06-13 10:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:10:33 --> Input Class Initialized
INFO - 2016-06-13 10:10:33 --> Language Class Initialized
INFO - 2016-06-13 10:10:33 --> Loader Class Initialized
INFO - 2016-06-13 10:10:33 --> Helper loaded: form_helper
INFO - 2016-06-13 10:10:33 --> Database Driver Class Initialized
INFO - 2016-06-13 10:10:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:10:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:10:33 --> Email Class Initialized
INFO - 2016-06-13 10:10:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:10:33 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:10:33 --> Helper loaded: language_helper
INFO - 2016-06-13 10:10:33 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:10:33 --> Model Class Initialized
INFO - 2016-06-13 10:10:33 --> Helper loaded: date_helper
INFO - 2016-06-13 10:10:33 --> Controller Class Initialized
INFO - 2016-06-13 10:10:33 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:10:33 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:10:33 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:10:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:10:33 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:10:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:10:33 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:10:33 --> Model Class Initialized
INFO - 2016-06-13 10:10:33 --> Form Validation Class Initialized
INFO - 2016-06-13 10:10:33 --> Final output sent to browser
DEBUG - 2016-06-13 10:10:33 --> Total execution time: 0.0169
INFO - 2016-06-13 10:13:23 --> Config Class Initialized
INFO - 2016-06-13 10:13:23 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:13:23 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:13:23 --> Utf8 Class Initialized
INFO - 2016-06-13 10:13:23 --> URI Class Initialized
INFO - 2016-06-13 10:13:23 --> Router Class Initialized
INFO - 2016-06-13 10:13:23 --> Output Class Initialized
INFO - 2016-06-13 10:13:23 --> Security Class Initialized
DEBUG - 2016-06-13 10:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:13:23 --> Input Class Initialized
INFO - 2016-06-13 10:13:23 --> Language Class Initialized
INFO - 2016-06-13 10:13:23 --> Loader Class Initialized
INFO - 2016-06-13 10:13:23 --> Helper loaded: form_helper
INFO - 2016-06-13 10:13:23 --> Database Driver Class Initialized
INFO - 2016-06-13 10:13:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:13:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:13:23 --> Email Class Initialized
INFO - 2016-06-13 10:13:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:13:23 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:13:23 --> Helper loaded: language_helper
INFO - 2016-06-13 10:13:23 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:13:23 --> Model Class Initialized
INFO - 2016-06-13 10:13:23 --> Helper loaded: date_helper
INFO - 2016-06-13 10:13:23 --> Controller Class Initialized
INFO - 2016-06-13 10:13:23 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:13:23 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:13:23 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:13:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:13:23 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:13:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:13:23 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:13:23 --> Model Class Initialized
INFO - 2016-06-13 10:13:23 --> Form Validation Class Initialized
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:13:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:13:23 --> Final output sent to browser
DEBUG - 2016-06-13 10:13:23 --> Total execution time: 0.0774
INFO - 2016-06-13 10:13:29 --> Config Class Initialized
INFO - 2016-06-13 10:13:29 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:13:29 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:13:29 --> Utf8 Class Initialized
INFO - 2016-06-13 10:13:29 --> URI Class Initialized
INFO - 2016-06-13 10:13:29 --> Router Class Initialized
INFO - 2016-06-13 10:13:29 --> Output Class Initialized
INFO - 2016-06-13 10:13:29 --> Security Class Initialized
DEBUG - 2016-06-13 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:13:29 --> Input Class Initialized
INFO - 2016-06-13 10:13:29 --> Language Class Initialized
INFO - 2016-06-13 10:13:29 --> Loader Class Initialized
INFO - 2016-06-13 10:13:29 --> Helper loaded: form_helper
INFO - 2016-06-13 10:13:29 --> Database Driver Class Initialized
INFO - 2016-06-13 10:13:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:13:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:13:29 --> Email Class Initialized
INFO - 2016-06-13 10:13:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:13:29 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:13:29 --> Helper loaded: language_helper
INFO - 2016-06-13 10:13:29 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:13:29 --> Model Class Initialized
INFO - 2016-06-13 10:13:29 --> Helper loaded: date_helper
INFO - 2016-06-13 10:13:29 --> Controller Class Initialized
INFO - 2016-06-13 10:13:29 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:13:29 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:13:29 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:13:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:13:29 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:13:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:13:29 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:13:29 --> Model Class Initialized
INFO - 2016-06-13 10:13:29 --> Form Validation Class Initialized
INFO - 2016-06-13 10:13:29 --> Final output sent to browser
DEBUG - 2016-06-13 10:13:29 --> Total execution time: 0.0235
INFO - 2016-06-13 10:14:04 --> Config Class Initialized
INFO - 2016-06-13 10:14:04 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:14:04 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:14:04 --> Utf8 Class Initialized
INFO - 2016-06-13 10:14:04 --> URI Class Initialized
INFO - 2016-06-13 10:14:04 --> Router Class Initialized
INFO - 2016-06-13 10:14:04 --> Output Class Initialized
INFO - 2016-06-13 10:14:04 --> Security Class Initialized
DEBUG - 2016-06-13 10:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:14:04 --> Input Class Initialized
INFO - 2016-06-13 10:14:04 --> Language Class Initialized
INFO - 2016-06-13 10:14:04 --> Loader Class Initialized
INFO - 2016-06-13 10:14:04 --> Helper loaded: form_helper
INFO - 2016-06-13 10:14:04 --> Database Driver Class Initialized
INFO - 2016-06-13 10:14:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:14:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:14:04 --> Email Class Initialized
INFO - 2016-06-13 10:14:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:14:04 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:14:04 --> Helper loaded: language_helper
INFO - 2016-06-13 10:14:04 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:14:04 --> Model Class Initialized
INFO - 2016-06-13 10:14:04 --> Helper loaded: date_helper
INFO - 2016-06-13 10:14:04 --> Controller Class Initialized
INFO - 2016-06-13 10:14:04 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:14:04 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:14:04 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:14:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:14:04 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:14:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:14:04 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:14:04 --> Model Class Initialized
INFO - 2016-06-13 10:14:04 --> Form Validation Class Initialized
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:14:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:14:04 --> Final output sent to browser
DEBUG - 2016-06-13 10:14:04 --> Total execution time: 0.0928
INFO - 2016-06-13 10:14:11 --> Config Class Initialized
INFO - 2016-06-13 10:14:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:14:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:14:11 --> Utf8 Class Initialized
INFO - 2016-06-13 10:14:11 --> URI Class Initialized
INFO - 2016-06-13 10:14:11 --> Router Class Initialized
INFO - 2016-06-13 10:14:11 --> Output Class Initialized
INFO - 2016-06-13 10:14:11 --> Security Class Initialized
DEBUG - 2016-06-13 10:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:14:11 --> Input Class Initialized
INFO - 2016-06-13 10:14:11 --> Language Class Initialized
INFO - 2016-06-13 10:14:11 --> Loader Class Initialized
INFO - 2016-06-13 10:14:11 --> Helper loaded: form_helper
INFO - 2016-06-13 10:14:11 --> Database Driver Class Initialized
INFO - 2016-06-13 10:14:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:14:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:14:11 --> Email Class Initialized
INFO - 2016-06-13 10:14:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:14:11 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:14:11 --> Helper loaded: language_helper
INFO - 2016-06-13 10:14:11 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:14:11 --> Model Class Initialized
INFO - 2016-06-13 10:14:11 --> Helper loaded: date_helper
INFO - 2016-06-13 10:14:11 --> Controller Class Initialized
INFO - 2016-06-13 10:14:11 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:14:11 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:14:11 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:14:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:14:11 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:14:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:14:11 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:14:11 --> Model Class Initialized
INFO - 2016-06-13 10:14:11 --> Form Validation Class Initialized
INFO - 2016-06-13 10:14:11 --> Final output sent to browser
DEBUG - 2016-06-13 10:14:11 --> Total execution time: 0.0229
INFO - 2016-06-13 10:19:16 --> Config Class Initialized
INFO - 2016-06-13 10:19:16 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:19:16 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:19:16 --> Utf8 Class Initialized
INFO - 2016-06-13 10:19:16 --> URI Class Initialized
INFO - 2016-06-13 10:19:16 --> Router Class Initialized
INFO - 2016-06-13 10:19:16 --> Output Class Initialized
INFO - 2016-06-13 10:19:16 --> Security Class Initialized
DEBUG - 2016-06-13 10:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:19:16 --> Input Class Initialized
INFO - 2016-06-13 10:19:16 --> Language Class Initialized
INFO - 2016-06-13 10:19:16 --> Loader Class Initialized
INFO - 2016-06-13 10:19:16 --> Helper loaded: form_helper
INFO - 2016-06-13 10:19:16 --> Database Driver Class Initialized
INFO - 2016-06-13 10:19:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:19:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:19:16 --> Email Class Initialized
INFO - 2016-06-13 10:19:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:19:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:19:16 --> Helper loaded: language_helper
INFO - 2016-06-13 10:19:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:19:16 --> Model Class Initialized
INFO - 2016-06-13 10:19:16 --> Helper loaded: date_helper
INFO - 2016-06-13 10:19:16 --> Controller Class Initialized
INFO - 2016-06-13 10:19:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:19:16 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:19:16 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:19:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:19:16 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:19:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:19:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:19:16 --> Model Class Initialized
INFO - 2016-06-13 10:19:16 --> Form Validation Class Initialized
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:19:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:19:16 --> Final output sent to browser
DEBUG - 2016-06-13 10:19:16 --> Total execution time: 0.1768
INFO - 2016-06-13 10:19:22 --> Config Class Initialized
INFO - 2016-06-13 10:19:22 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:19:22 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:19:22 --> Utf8 Class Initialized
INFO - 2016-06-13 10:19:22 --> URI Class Initialized
INFO - 2016-06-13 10:19:22 --> Router Class Initialized
INFO - 2016-06-13 10:19:22 --> Output Class Initialized
INFO - 2016-06-13 10:19:22 --> Security Class Initialized
DEBUG - 2016-06-13 10:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:19:22 --> Input Class Initialized
INFO - 2016-06-13 10:19:22 --> Language Class Initialized
INFO - 2016-06-13 10:19:22 --> Loader Class Initialized
INFO - 2016-06-13 10:19:22 --> Helper loaded: form_helper
INFO - 2016-06-13 10:19:22 --> Database Driver Class Initialized
INFO - 2016-06-13 10:19:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:19:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:19:22 --> Email Class Initialized
INFO - 2016-06-13 10:19:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:19:22 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:19:22 --> Helper loaded: language_helper
INFO - 2016-06-13 10:19:22 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:19:22 --> Model Class Initialized
INFO - 2016-06-13 10:19:22 --> Helper loaded: date_helper
INFO - 2016-06-13 10:19:22 --> Controller Class Initialized
INFO - 2016-06-13 10:19:22 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:19:22 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:19:22 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:19:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:19:22 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:19:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:19:22 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:19:22 --> Model Class Initialized
INFO - 2016-06-13 10:19:22 --> Form Validation Class Initialized
INFO - 2016-06-13 10:19:22 --> Final output sent to browser
DEBUG - 2016-06-13 10:19:22 --> Total execution time: 0.0148
INFO - 2016-06-13 10:20:16 --> Config Class Initialized
INFO - 2016-06-13 10:20:16 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:20:16 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:20:16 --> Utf8 Class Initialized
INFO - 2016-06-13 10:20:16 --> URI Class Initialized
INFO - 2016-06-13 10:20:16 --> Router Class Initialized
INFO - 2016-06-13 10:20:16 --> Output Class Initialized
INFO - 2016-06-13 10:20:16 --> Security Class Initialized
DEBUG - 2016-06-13 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:20:16 --> Input Class Initialized
INFO - 2016-06-13 10:20:16 --> Language Class Initialized
INFO - 2016-06-13 10:20:16 --> Loader Class Initialized
INFO - 2016-06-13 10:20:16 --> Helper loaded: form_helper
INFO - 2016-06-13 10:20:16 --> Database Driver Class Initialized
INFO - 2016-06-13 10:20:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:20:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:20:16 --> Email Class Initialized
INFO - 2016-06-13 10:20:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:20:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:20:16 --> Helper loaded: language_helper
INFO - 2016-06-13 10:20:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:20:16 --> Model Class Initialized
INFO - 2016-06-13 10:20:16 --> Helper loaded: date_helper
INFO - 2016-06-13 10:20:16 --> Controller Class Initialized
INFO - 2016-06-13 10:20:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:20:16 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:20:16 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:20:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:20:16 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:20:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:20:16 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:20:16 --> Model Class Initialized
INFO - 2016-06-13 10:20:16 --> Form Validation Class Initialized
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 10:20:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 10:20:16 --> Final output sent to browser
DEBUG - 2016-06-13 10:20:16 --> Total execution time: 0.0895
INFO - 2016-06-13 10:20:31 --> Config Class Initialized
INFO - 2016-06-13 10:20:31 --> Hooks Class Initialized
DEBUG - 2016-06-13 10:20:31 --> UTF-8 Support Enabled
INFO - 2016-06-13 10:20:31 --> Utf8 Class Initialized
INFO - 2016-06-13 10:20:31 --> URI Class Initialized
INFO - 2016-06-13 10:20:31 --> Router Class Initialized
INFO - 2016-06-13 10:20:31 --> Output Class Initialized
INFO - 2016-06-13 10:20:31 --> Security Class Initialized
DEBUG - 2016-06-13 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 10:20:31 --> Input Class Initialized
INFO - 2016-06-13 10:20:31 --> Language Class Initialized
INFO - 2016-06-13 10:20:31 --> Loader Class Initialized
INFO - 2016-06-13 10:20:31 --> Helper loaded: form_helper
INFO - 2016-06-13 10:20:31 --> Database Driver Class Initialized
INFO - 2016-06-13 10:20:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 10:20:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 10:20:31 --> Email Class Initialized
INFO - 2016-06-13 10:20:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 10:20:31 --> Helper loaded: cookie_helper
INFO - 2016-06-13 10:20:31 --> Helper loaded: language_helper
INFO - 2016-06-13 10:20:31 --> Helper loaded: url_helper
DEBUG - 2016-06-13 10:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 10:20:31 --> Model Class Initialized
INFO - 2016-06-13 10:20:31 --> Helper loaded: date_helper
INFO - 2016-06-13 10:20:31 --> Controller Class Initialized
INFO - 2016-06-13 10:20:31 --> Helper loaded: languages_helper
INFO - 2016-06-13 10:20:31 --> Language file loaded: language/english/general_lang.php
INFO - 2016-06-13 10:20:31 --> Language file loaded: language/english/auth_lang.php
INFO - 2016-06-13 10:20:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-06-13 10:20:31 --> Language file loaded: language/english/errors_generals_lang.php
INFO - 2016-06-13 10:20:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-06-13 10:20:31 --> Language file loaded: language/english/ion_auth_lang.php
INFO - 2016-06-13 10:20:31 --> Model Class Initialized
INFO - 2016-06-13 10:20:31 --> Form Validation Class Initialized
INFO - 2016-06-13 10:20:31 --> Final output sent to browser
DEBUG - 2016-06-13 10:20:31 --> Total execution time: 0.0601
INFO - 2016-06-13 13:42:34 --> Config Class Initialized
INFO - 2016-06-13 13:42:34 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:42:34 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:42:34 --> Utf8 Class Initialized
INFO - 2016-06-13 13:42:34 --> URI Class Initialized
DEBUG - 2016-06-13 13:42:34 --> No URI present. Default controller set.
INFO - 2016-06-13 13:42:34 --> Router Class Initialized
INFO - 2016-06-13 13:42:34 --> Output Class Initialized
INFO - 2016-06-13 13:42:34 --> Security Class Initialized
DEBUG - 2016-06-13 13:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:42:34 --> Input Class Initialized
INFO - 2016-06-13 13:42:34 --> Language Class Initialized
INFO - 2016-06-13 13:42:34 --> Loader Class Initialized
INFO - 2016-06-13 13:42:34 --> Helper loaded: form_helper
INFO - 2016-06-13 13:42:34 --> Database Driver Class Initialized
INFO - 2016-06-13 13:42:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:42:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:42:34 --> Email Class Initialized
INFO - 2016-06-13 13:42:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:42:34 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:42:34 --> Helper loaded: language_helper
INFO - 2016-06-13 13:42:34 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:34 --> Model Class Initialized
INFO - 2016-06-13 13:42:34 --> Helper loaded: date_helper
INFO - 2016-06-13 13:42:34 --> Controller Class Initialized
INFO - 2016-06-13 13:42:34 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:42:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:42:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:42:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:42:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:42:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:42:34 --> Model Class Initialized
INFO - 2016-06-13 13:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-13 13:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/home.php
INFO - 2016-06-13 13:42:35 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-13 13:42:35 --> Final output sent to browser
DEBUG - 2016-06-13 13:42:35 --> Total execution time: 1.0122
INFO - 2016-06-13 13:42:36 --> Config Class Initialized
INFO - 2016-06-13 13:42:36 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:42:36 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:42:36 --> Utf8 Class Initialized
INFO - 2016-06-13 13:42:36 --> URI Class Initialized
INFO - 2016-06-13 13:42:36 --> Router Class Initialized
INFO - 2016-06-13 13:42:36 --> Output Class Initialized
INFO - 2016-06-13 13:42:36 --> Security Class Initialized
DEBUG - 2016-06-13 13:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:42:36 --> Input Class Initialized
INFO - 2016-06-13 13:42:36 --> Language Class Initialized
ERROR - 2016-06-13 13:42:36 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 13:42:38 --> Config Class Initialized
INFO - 2016-06-13 13:42:38 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:42:38 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:42:38 --> Utf8 Class Initialized
INFO - 2016-06-13 13:42:38 --> URI Class Initialized
INFO - 2016-06-13 13:42:38 --> Router Class Initialized
INFO - 2016-06-13 13:42:38 --> Output Class Initialized
INFO - 2016-06-13 13:42:38 --> Security Class Initialized
DEBUG - 2016-06-13 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:42:38 --> Input Class Initialized
INFO - 2016-06-13 13:42:38 --> Language Class Initialized
INFO - 2016-06-13 13:42:38 --> Loader Class Initialized
INFO - 2016-06-13 13:42:38 --> Helper loaded: form_helper
INFO - 2016-06-13 13:42:38 --> Database Driver Class Initialized
INFO - 2016-06-13 13:42:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:42:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:42:38 --> Email Class Initialized
INFO - 2016-06-13 13:42:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:42:38 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:42:38 --> Helper loaded: language_helper
INFO - 2016-06-13 13:42:38 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:38 --> Model Class Initialized
INFO - 2016-06-13 13:42:38 --> Helper loaded: date_helper
INFO - 2016-06-13 13:42:38 --> Controller Class Initialized
INFO - 2016-06-13 13:42:38 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:42:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:42:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:42:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:42:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:42:38 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-13 13:42:38 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:38 --> Form Validation Class Initialized
DEBUG - 2016-06-13 13:42:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/header.php
INFO - 2016-06-13 13:42:38 --> File loaded: /home/demis/www/platformadiabet/application/views/auth/login.php
INFO - 2016-06-13 13:42:38 --> File loaded: /home/demis/www/platformadiabet/application/views/public/res/footer.php
INFO - 2016-06-13 13:42:38 --> Final output sent to browser
DEBUG - 2016-06-13 13:42:38 --> Total execution time: 0.2043
INFO - 2016-06-13 13:42:53 --> Config Class Initialized
INFO - 2016-06-13 13:42:53 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:42:53 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:42:53 --> Utf8 Class Initialized
INFO - 2016-06-13 13:42:53 --> URI Class Initialized
INFO - 2016-06-13 13:42:53 --> Router Class Initialized
INFO - 2016-06-13 13:42:53 --> Output Class Initialized
INFO - 2016-06-13 13:42:53 --> Security Class Initialized
DEBUG - 2016-06-13 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:42:53 --> Input Class Initialized
INFO - 2016-06-13 13:42:53 --> Language Class Initialized
INFO - 2016-06-13 13:42:53 --> Loader Class Initialized
INFO - 2016-06-13 13:42:53 --> Helper loaded: form_helper
INFO - 2016-06-13 13:42:53 --> Database Driver Class Initialized
INFO - 2016-06-13 13:42:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:42:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:42:53 --> Email Class Initialized
INFO - 2016-06-13 13:42:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:42:53 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:42:53 --> Helper loaded: language_helper
INFO - 2016-06-13 13:42:53 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:53 --> Model Class Initialized
INFO - 2016-06-13 13:42:53 --> Helper loaded: date_helper
INFO - 2016-06-13 13:42:53 --> Controller Class Initialized
INFO - 2016-06-13 13:42:53 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:42:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:42:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:42:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:42:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:42:53 --> Language file loaded: language/romanian/form_validation_lang.php
DEBUG - 2016-06-13 13:42:53 --> Ion_auth class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:53 --> Form Validation Class Initialized
DEBUG - 2016-06-13 13:42:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:54 --> Config Class Initialized
INFO - 2016-06-13 13:42:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:42:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:42:54 --> Utf8 Class Initialized
INFO - 2016-06-13 13:42:54 --> URI Class Initialized
DEBUG - 2016-06-13 13:42:54 --> No URI present. Default controller set.
INFO - 2016-06-13 13:42:54 --> Router Class Initialized
INFO - 2016-06-13 13:42:54 --> Output Class Initialized
INFO - 2016-06-13 13:42:54 --> Security Class Initialized
DEBUG - 2016-06-13 13:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:42:54 --> Input Class Initialized
INFO - 2016-06-13 13:42:54 --> Language Class Initialized
INFO - 2016-06-13 13:42:54 --> Loader Class Initialized
INFO - 2016-06-13 13:42:54 --> Helper loaded: form_helper
INFO - 2016-06-13 13:42:54 --> Database Driver Class Initialized
INFO - 2016-06-13 13:42:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:42:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:42:54 --> Email Class Initialized
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:42:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:42:54 --> Helper loaded: language_helper
INFO - 2016-06-13 13:42:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:54 --> Model Class Initialized
INFO - 2016-06-13 13:42:54 --> Helper loaded: date_helper
INFO - 2016-06-13 13:42:54 --> Controller Class Initialized
INFO - 2016-06-13 13:42:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:42:54 --> Config Class Initialized
INFO - 2016-06-13 13:42:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:42:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:42:54 --> Utf8 Class Initialized
INFO - 2016-06-13 13:42:54 --> URI Class Initialized
INFO - 2016-06-13 13:42:54 --> Router Class Initialized
INFO - 2016-06-13 13:42:54 --> Output Class Initialized
INFO - 2016-06-13 13:42:54 --> Security Class Initialized
DEBUG - 2016-06-13 13:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:42:54 --> Input Class Initialized
INFO - 2016-06-13 13:42:54 --> Language Class Initialized
INFO - 2016-06-13 13:42:54 --> Loader Class Initialized
INFO - 2016-06-13 13:42:54 --> Helper loaded: form_helper
INFO - 2016-06-13 13:42:54 --> Database Driver Class Initialized
INFO - 2016-06-13 13:42:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:42:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:42:54 --> Email Class Initialized
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:42:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:42:54 --> Helper loaded: language_helper
INFO - 2016-06-13 13:42:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:54 --> Model Class Initialized
INFO - 2016-06-13 13:42:54 --> Helper loaded: date_helper
INFO - 2016-06-13 13:42:54 --> Controller Class Initialized
INFO - 2016-06-13 13:42:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:42:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:42:54 --> Model Class Initialized
INFO - 2016-06-13 13:42:54 --> Form Validation Class Initialized
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:42:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:42:55 --> Final output sent to browser
DEBUG - 2016-06-13 13:42:55 --> Total execution time: 0.3979
INFO - 2016-06-13 13:42:56 --> Config Class Initialized
INFO - 2016-06-13 13:42:56 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:42:56 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:42:56 --> Utf8 Class Initialized
INFO - 2016-06-13 13:42:56 --> URI Class Initialized
INFO - 2016-06-13 13:42:56 --> Router Class Initialized
INFO - 2016-06-13 13:42:56 --> Output Class Initialized
INFO - 2016-06-13 13:42:56 --> Security Class Initialized
DEBUG - 2016-06-13 13:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:42:56 --> Input Class Initialized
INFO - 2016-06-13 13:42:56 --> Language Class Initialized
INFO - 2016-06-13 13:42:56 --> Loader Class Initialized
INFO - 2016-06-13 13:42:56 --> Helper loaded: form_helper
INFO - 2016-06-13 13:42:56 --> Database Driver Class Initialized
INFO - 2016-06-13 13:42:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:42:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:42:56 --> Email Class Initialized
INFO - 2016-06-13 13:42:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:42:56 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:42:56 --> Helper loaded: language_helper
INFO - 2016-06-13 13:42:56 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:42:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:42:56 --> Model Class Initialized
INFO - 2016-06-13 13:42:56 --> Helper loaded: date_helper
INFO - 2016-06-13 13:42:56 --> Controller Class Initialized
INFO - 2016-06-13 13:42:56 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:42:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:42:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:42:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:42:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:42:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:42:56 --> Model Class Initialized
INFO - 2016-06-13 13:42:56 --> Form Validation Class Initialized
INFO - 2016-06-13 13:42:56 --> Final output sent to browser
DEBUG - 2016-06-13 13:42:56 --> Total execution time: 0.0822
INFO - 2016-06-13 13:44:11 --> Config Class Initialized
INFO - 2016-06-13 13:44:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:44:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:44:11 --> Utf8 Class Initialized
INFO - 2016-06-13 13:44:11 --> URI Class Initialized
INFO - 2016-06-13 13:44:11 --> Router Class Initialized
INFO - 2016-06-13 13:44:11 --> Output Class Initialized
INFO - 2016-06-13 13:44:11 --> Security Class Initialized
DEBUG - 2016-06-13 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:44:11 --> Input Class Initialized
INFO - 2016-06-13 13:44:11 --> Language Class Initialized
INFO - 2016-06-13 13:44:11 --> Loader Class Initialized
INFO - 2016-06-13 13:44:11 --> Helper loaded: form_helper
INFO - 2016-06-13 13:44:11 --> Database Driver Class Initialized
INFO - 2016-06-13 13:44:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:44:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:44:11 --> Email Class Initialized
INFO - 2016-06-13 13:44:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:44:11 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:44:11 --> Helper loaded: language_helper
INFO - 2016-06-13 13:44:11 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:44:11 --> Model Class Initialized
INFO - 2016-06-13 13:44:11 --> Helper loaded: date_helper
INFO - 2016-06-13 13:44:11 --> Controller Class Initialized
INFO - 2016-06-13 13:44:11 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:44:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:44:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:44:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:44:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:44:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:44:11 --> Model Class Initialized
INFO - 2016-06-13 13:44:11 --> Form Validation Class Initialized
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:44:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:44:11 --> Final output sent to browser
DEBUG - 2016-06-13 13:44:11 --> Total execution time: 0.1362
INFO - 2016-06-13 13:44:12 --> Config Class Initialized
INFO - 2016-06-13 13:44:12 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:44:12 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:44:12 --> Utf8 Class Initialized
INFO - 2016-06-13 13:44:12 --> URI Class Initialized
INFO - 2016-06-13 13:44:12 --> Router Class Initialized
INFO - 2016-06-13 13:44:12 --> Output Class Initialized
INFO - 2016-06-13 13:44:12 --> Security Class Initialized
DEBUG - 2016-06-13 13:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:44:12 --> Input Class Initialized
INFO - 2016-06-13 13:44:12 --> Language Class Initialized
INFO - 2016-06-13 13:44:12 --> Loader Class Initialized
INFO - 2016-06-13 13:44:12 --> Helper loaded: form_helper
INFO - 2016-06-13 13:44:12 --> Database Driver Class Initialized
INFO - 2016-06-13 13:44:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:44:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:44:12 --> Email Class Initialized
INFO - 2016-06-13 13:44:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:44:12 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:44:12 --> Helper loaded: language_helper
INFO - 2016-06-13 13:44:12 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:44:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:44:12 --> Model Class Initialized
INFO - 2016-06-13 13:44:12 --> Helper loaded: date_helper
INFO - 2016-06-13 13:44:12 --> Controller Class Initialized
INFO - 2016-06-13 13:44:12 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:44:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:44:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:44:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:44:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:44:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:44:12 --> Model Class Initialized
INFO - 2016-06-13 13:44:12 --> Form Validation Class Initialized
INFO - 2016-06-13 13:44:12 --> Final output sent to browser
DEBUG - 2016-06-13 13:44:12 --> Total execution time: 0.0939
INFO - 2016-06-13 13:44:56 --> Config Class Initialized
INFO - 2016-06-13 13:44:56 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:44:56 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:44:56 --> Utf8 Class Initialized
INFO - 2016-06-13 13:44:56 --> URI Class Initialized
INFO - 2016-06-13 13:44:56 --> Router Class Initialized
INFO - 2016-06-13 13:44:56 --> Output Class Initialized
INFO - 2016-06-13 13:44:56 --> Security Class Initialized
DEBUG - 2016-06-13 13:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:44:56 --> Input Class Initialized
INFO - 2016-06-13 13:44:56 --> Language Class Initialized
INFO - 2016-06-13 13:44:56 --> Loader Class Initialized
INFO - 2016-06-13 13:44:56 --> Helper loaded: form_helper
INFO - 2016-06-13 13:44:56 --> Database Driver Class Initialized
INFO - 2016-06-13 13:44:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:44:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:44:56 --> Email Class Initialized
INFO - 2016-06-13 13:44:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:44:56 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:44:56 --> Helper loaded: language_helper
INFO - 2016-06-13 13:44:56 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:44:56 --> Model Class Initialized
INFO - 2016-06-13 13:44:56 --> Helper loaded: date_helper
INFO - 2016-06-13 13:44:56 --> Controller Class Initialized
INFO - 2016-06-13 13:44:56 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:44:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:44:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:44:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:44:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:44:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:44:56 --> Model Class Initialized
INFO - 2016-06-13 13:44:56 --> Form Validation Class Initialized
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:44:56 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:44:56 --> Final output sent to browser
DEBUG - 2016-06-13 13:44:56 --> Total execution time: 0.1166
INFO - 2016-06-13 13:44:58 --> Config Class Initialized
INFO - 2016-06-13 13:44:58 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:44:58 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:44:58 --> Utf8 Class Initialized
INFO - 2016-06-13 13:44:58 --> URI Class Initialized
INFO - 2016-06-13 13:44:58 --> Router Class Initialized
INFO - 2016-06-13 13:44:58 --> Output Class Initialized
INFO - 2016-06-13 13:44:58 --> Security Class Initialized
DEBUG - 2016-06-13 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:44:58 --> Input Class Initialized
INFO - 2016-06-13 13:44:58 --> Language Class Initialized
INFO - 2016-06-13 13:44:58 --> Loader Class Initialized
INFO - 2016-06-13 13:44:58 --> Helper loaded: form_helper
INFO - 2016-06-13 13:44:58 --> Database Driver Class Initialized
INFO - 2016-06-13 13:44:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:44:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:44:58 --> Email Class Initialized
INFO - 2016-06-13 13:44:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:44:58 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:44:58 --> Helper loaded: language_helper
INFO - 2016-06-13 13:44:58 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:44:58 --> Model Class Initialized
INFO - 2016-06-13 13:44:58 --> Helper loaded: date_helper
INFO - 2016-06-13 13:44:58 --> Controller Class Initialized
INFO - 2016-06-13 13:44:58 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:44:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:44:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:44:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:44:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:44:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:44:58 --> Model Class Initialized
INFO - 2016-06-13 13:44:58 --> Form Validation Class Initialized
INFO - 2016-06-13 13:44:58 --> Final output sent to browser
DEBUG - 2016-06-13 13:44:58 --> Total execution time: 0.0587
INFO - 2016-06-13 13:47:31 --> Config Class Initialized
INFO - 2016-06-13 13:47:31 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:47:31 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:47:31 --> Utf8 Class Initialized
INFO - 2016-06-13 13:47:31 --> URI Class Initialized
INFO - 2016-06-13 13:47:31 --> Router Class Initialized
INFO - 2016-06-13 13:47:31 --> Output Class Initialized
INFO - 2016-06-13 13:47:31 --> Security Class Initialized
DEBUG - 2016-06-13 13:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:47:31 --> Input Class Initialized
INFO - 2016-06-13 13:47:31 --> Language Class Initialized
INFO - 2016-06-13 13:47:31 --> Loader Class Initialized
INFO - 2016-06-13 13:47:31 --> Helper loaded: form_helper
INFO - 2016-06-13 13:47:31 --> Database Driver Class Initialized
INFO - 2016-06-13 13:47:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:47:31 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:47:31 --> Email Class Initialized
INFO - 2016-06-13 13:47:31 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:47:31 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:47:31 --> Helper loaded: language_helper
INFO - 2016-06-13 13:47:31 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:47:31 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:47:31 --> Model Class Initialized
INFO - 2016-06-13 13:47:31 --> Helper loaded: date_helper
INFO - 2016-06-13 13:47:31 --> Controller Class Initialized
INFO - 2016-06-13 13:47:31 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:47:31 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:47:31 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:47:31 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:47:31 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:47:31 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:47:31 --> Model Class Initialized
INFO - 2016-06-13 13:47:31 --> Form Validation Class Initialized
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:47:31 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:47:31 --> Final output sent to browser
DEBUG - 2016-06-13 13:47:31 --> Total execution time: 0.1430
INFO - 2016-06-13 13:47:32 --> Config Class Initialized
INFO - 2016-06-13 13:47:32 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:47:32 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:47:32 --> Utf8 Class Initialized
INFO - 2016-06-13 13:47:32 --> URI Class Initialized
INFO - 2016-06-13 13:47:32 --> Router Class Initialized
INFO - 2016-06-13 13:47:32 --> Output Class Initialized
INFO - 2016-06-13 13:47:32 --> Security Class Initialized
DEBUG - 2016-06-13 13:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:47:32 --> Input Class Initialized
INFO - 2016-06-13 13:47:32 --> Language Class Initialized
INFO - 2016-06-13 13:47:32 --> Loader Class Initialized
INFO - 2016-06-13 13:47:32 --> Helper loaded: form_helper
INFO - 2016-06-13 13:47:32 --> Database Driver Class Initialized
INFO - 2016-06-13 13:47:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:47:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:47:32 --> Email Class Initialized
INFO - 2016-06-13 13:47:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:47:32 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:47:32 --> Helper loaded: language_helper
INFO - 2016-06-13 13:47:32 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:47:32 --> Model Class Initialized
INFO - 2016-06-13 13:47:32 --> Helper loaded: date_helper
INFO - 2016-06-13 13:47:32 --> Controller Class Initialized
INFO - 2016-06-13 13:47:32 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:47:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:47:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:47:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:47:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:47:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:47:32 --> Model Class Initialized
INFO - 2016-06-13 13:47:32 --> Form Validation Class Initialized
INFO - 2016-06-13 13:47:33 --> Final output sent to browser
DEBUG - 2016-06-13 13:47:33 --> Total execution time: 0.1041
INFO - 2016-06-13 13:48:40 --> Config Class Initialized
INFO - 2016-06-13 13:48:40 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:48:40 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:48:40 --> Utf8 Class Initialized
INFO - 2016-06-13 13:48:40 --> URI Class Initialized
INFO - 2016-06-13 13:48:40 --> Router Class Initialized
INFO - 2016-06-13 13:48:40 --> Output Class Initialized
INFO - 2016-06-13 13:48:40 --> Security Class Initialized
DEBUG - 2016-06-13 13:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:48:40 --> Input Class Initialized
INFO - 2016-06-13 13:48:40 --> Language Class Initialized
INFO - 2016-06-13 13:48:40 --> Loader Class Initialized
INFO - 2016-06-13 13:48:40 --> Helper loaded: form_helper
INFO - 2016-06-13 13:48:40 --> Database Driver Class Initialized
INFO - 2016-06-13 13:48:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:48:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:48:40 --> Email Class Initialized
INFO - 2016-06-13 13:48:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:48:40 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:48:40 --> Helper loaded: language_helper
INFO - 2016-06-13 13:48:40 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:48:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:48:40 --> Model Class Initialized
INFO - 2016-06-13 13:48:40 --> Helper loaded: date_helper
INFO - 2016-06-13 13:48:40 --> Controller Class Initialized
INFO - 2016-06-13 13:48:40 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:48:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:48:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:48:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:48:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:48:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:48:40 --> Model Class Initialized
INFO - 2016-06-13 13:48:40 --> Form Validation Class Initialized
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:48:40 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:48:40 --> Final output sent to browser
DEBUG - 2016-06-13 13:48:40 --> Total execution time: 0.1447
INFO - 2016-06-13 13:48:42 --> Config Class Initialized
INFO - 2016-06-13 13:48:42 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:48:42 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:48:42 --> Utf8 Class Initialized
INFO - 2016-06-13 13:48:42 --> URI Class Initialized
INFO - 2016-06-13 13:48:42 --> Router Class Initialized
INFO - 2016-06-13 13:48:42 --> Output Class Initialized
INFO - 2016-06-13 13:48:42 --> Security Class Initialized
DEBUG - 2016-06-13 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:48:42 --> Input Class Initialized
INFO - 2016-06-13 13:48:42 --> Language Class Initialized
INFO - 2016-06-13 13:48:42 --> Loader Class Initialized
INFO - 2016-06-13 13:48:42 --> Helper loaded: form_helper
INFO - 2016-06-13 13:48:42 --> Database Driver Class Initialized
INFO - 2016-06-13 13:48:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:48:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:48:42 --> Email Class Initialized
INFO - 2016-06-13 13:48:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:48:42 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:48:42 --> Helper loaded: language_helper
INFO - 2016-06-13 13:48:42 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:48:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:48:42 --> Model Class Initialized
INFO - 2016-06-13 13:48:42 --> Helper loaded: date_helper
INFO - 2016-06-13 13:48:42 --> Controller Class Initialized
INFO - 2016-06-13 13:48:42 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:48:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:48:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:48:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:48:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:48:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:48:42 --> Model Class Initialized
INFO - 2016-06-13 13:48:42 --> Form Validation Class Initialized
INFO - 2016-06-13 13:48:42 --> Final output sent to browser
DEBUG - 2016-06-13 13:48:42 --> Total execution time: 0.0525
INFO - 2016-06-13 13:49:28 --> Config Class Initialized
INFO - 2016-06-13 13:49:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:49:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:49:28 --> Utf8 Class Initialized
INFO - 2016-06-13 13:49:28 --> URI Class Initialized
INFO - 2016-06-13 13:49:28 --> Router Class Initialized
INFO - 2016-06-13 13:49:28 --> Output Class Initialized
INFO - 2016-06-13 13:49:28 --> Security Class Initialized
DEBUG - 2016-06-13 13:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:49:28 --> Input Class Initialized
INFO - 2016-06-13 13:49:28 --> Language Class Initialized
INFO - 2016-06-13 13:49:28 --> Loader Class Initialized
INFO - 2016-06-13 13:49:28 --> Helper loaded: form_helper
INFO - 2016-06-13 13:49:28 --> Database Driver Class Initialized
INFO - 2016-06-13 13:49:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:49:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:49:28 --> Email Class Initialized
INFO - 2016-06-13 13:49:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:49:28 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:49:28 --> Helper loaded: language_helper
INFO - 2016-06-13 13:49:28 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:49:28 --> Model Class Initialized
INFO - 2016-06-13 13:49:28 --> Helper loaded: date_helper
INFO - 2016-06-13 13:49:28 --> Controller Class Initialized
INFO - 2016-06-13 13:49:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:49:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:49:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:49:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:49:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:49:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:49:28 --> Model Class Initialized
INFO - 2016-06-13 13:49:28 --> Form Validation Class Initialized
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:49:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:49:28 --> Final output sent to browser
DEBUG - 2016-06-13 13:49:28 --> Total execution time: 0.0324
INFO - 2016-06-13 13:49:29 --> Config Class Initialized
INFO - 2016-06-13 13:49:29 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:49:29 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:49:29 --> Utf8 Class Initialized
INFO - 2016-06-13 13:49:29 --> URI Class Initialized
INFO - 2016-06-13 13:49:29 --> Router Class Initialized
INFO - 2016-06-13 13:49:29 --> Output Class Initialized
INFO - 2016-06-13 13:49:29 --> Security Class Initialized
DEBUG - 2016-06-13 13:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:49:29 --> Input Class Initialized
INFO - 2016-06-13 13:49:29 --> Language Class Initialized
INFO - 2016-06-13 13:49:29 --> Loader Class Initialized
INFO - 2016-06-13 13:49:29 --> Helper loaded: form_helper
INFO - 2016-06-13 13:49:29 --> Database Driver Class Initialized
INFO - 2016-06-13 13:49:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:49:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:49:29 --> Email Class Initialized
INFO - 2016-06-13 13:49:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:49:29 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:49:29 --> Helper loaded: language_helper
INFO - 2016-06-13 13:49:29 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:49:29 --> Model Class Initialized
INFO - 2016-06-13 13:49:29 --> Helper loaded: date_helper
INFO - 2016-06-13 13:49:29 --> Controller Class Initialized
INFO - 2016-06-13 13:49:29 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:49:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:49:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:49:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:49:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:49:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:49:29 --> Model Class Initialized
INFO - 2016-06-13 13:49:29 --> Form Validation Class Initialized
INFO - 2016-06-13 13:49:29 --> Final output sent to browser
DEBUG - 2016-06-13 13:49:29 --> Total execution time: 0.0737
INFO - 2016-06-13 13:50:02 --> Config Class Initialized
INFO - 2016-06-13 13:50:02 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:50:02 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:50:02 --> Utf8 Class Initialized
INFO - 2016-06-13 13:50:02 --> URI Class Initialized
INFO - 2016-06-13 13:50:02 --> Router Class Initialized
INFO - 2016-06-13 13:50:02 --> Output Class Initialized
INFO - 2016-06-13 13:50:02 --> Security Class Initialized
DEBUG - 2016-06-13 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:50:02 --> Input Class Initialized
INFO - 2016-06-13 13:50:02 --> Language Class Initialized
INFO - 2016-06-13 13:50:02 --> Loader Class Initialized
INFO - 2016-06-13 13:50:02 --> Helper loaded: form_helper
INFO - 2016-06-13 13:50:02 --> Database Driver Class Initialized
INFO - 2016-06-13 13:50:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:50:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:50:02 --> Email Class Initialized
INFO - 2016-06-13 13:50:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:50:02 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:50:02 --> Helper loaded: language_helper
INFO - 2016-06-13 13:50:02 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:50:02 --> Model Class Initialized
INFO - 2016-06-13 13:50:02 --> Helper loaded: date_helper
INFO - 2016-06-13 13:50:02 --> Controller Class Initialized
INFO - 2016-06-13 13:50:02 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:50:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:50:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:50:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:50:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:50:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:50:02 --> Model Class Initialized
INFO - 2016-06-13 13:50:02 --> Form Validation Class Initialized
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:50:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:50:02 --> Final output sent to browser
DEBUG - 2016-06-13 13:50:02 --> Total execution time: 0.1080
INFO - 2016-06-13 13:50:03 --> Config Class Initialized
INFO - 2016-06-13 13:50:03 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:50:03 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:50:03 --> Utf8 Class Initialized
INFO - 2016-06-13 13:50:03 --> URI Class Initialized
INFO - 2016-06-13 13:50:03 --> Router Class Initialized
INFO - 2016-06-13 13:50:03 --> Output Class Initialized
INFO - 2016-06-13 13:50:03 --> Security Class Initialized
DEBUG - 2016-06-13 13:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:50:03 --> Input Class Initialized
INFO - 2016-06-13 13:50:03 --> Language Class Initialized
INFO - 2016-06-13 13:50:03 --> Loader Class Initialized
INFO - 2016-06-13 13:50:03 --> Helper loaded: form_helper
INFO - 2016-06-13 13:50:03 --> Database Driver Class Initialized
INFO - 2016-06-13 13:50:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:50:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:50:03 --> Email Class Initialized
INFO - 2016-06-13 13:50:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:50:03 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:50:03 --> Helper loaded: language_helper
INFO - 2016-06-13 13:50:03 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:50:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:50:03 --> Model Class Initialized
INFO - 2016-06-13 13:50:03 --> Helper loaded: date_helper
INFO - 2016-06-13 13:50:03 --> Controller Class Initialized
INFO - 2016-06-13 13:50:03 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:50:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:50:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:50:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:50:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:50:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:50:03 --> Model Class Initialized
INFO - 2016-06-13 13:50:03 --> Form Validation Class Initialized
INFO - 2016-06-13 13:50:03 --> Final output sent to browser
DEBUG - 2016-06-13 13:50:03 --> Total execution time: 0.1016
INFO - 2016-06-13 13:51:28 --> Config Class Initialized
INFO - 2016-06-13 13:51:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:51:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:51:28 --> Utf8 Class Initialized
INFO - 2016-06-13 13:51:28 --> URI Class Initialized
INFO - 2016-06-13 13:51:28 --> Router Class Initialized
INFO - 2016-06-13 13:51:28 --> Output Class Initialized
INFO - 2016-06-13 13:51:28 --> Security Class Initialized
DEBUG - 2016-06-13 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:51:28 --> Input Class Initialized
INFO - 2016-06-13 13:51:28 --> Language Class Initialized
INFO - 2016-06-13 13:51:28 --> Loader Class Initialized
INFO - 2016-06-13 13:51:28 --> Helper loaded: form_helper
INFO - 2016-06-13 13:51:28 --> Database Driver Class Initialized
INFO - 2016-06-13 13:51:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:51:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:51:28 --> Email Class Initialized
INFO - 2016-06-13 13:51:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:51:28 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:51:28 --> Helper loaded: language_helper
INFO - 2016-06-13 13:51:28 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:51:28 --> Model Class Initialized
INFO - 2016-06-13 13:51:28 --> Helper loaded: date_helper
INFO - 2016-06-13 13:51:28 --> Controller Class Initialized
INFO - 2016-06-13 13:51:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:51:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:51:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:51:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:51:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:51:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:51:28 --> Model Class Initialized
INFO - 2016-06-13 13:51:28 --> Form Validation Class Initialized
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:51:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:51:28 --> Final output sent to browser
DEBUG - 2016-06-13 13:51:28 --> Total execution time: 0.1259
INFO - 2016-06-13 13:51:29 --> Config Class Initialized
INFO - 2016-06-13 13:51:29 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:51:29 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:51:29 --> Utf8 Class Initialized
INFO - 2016-06-13 13:51:29 --> URI Class Initialized
INFO - 2016-06-13 13:51:29 --> Router Class Initialized
INFO - 2016-06-13 13:51:29 --> Output Class Initialized
INFO - 2016-06-13 13:51:29 --> Security Class Initialized
DEBUG - 2016-06-13 13:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:51:29 --> Input Class Initialized
INFO - 2016-06-13 13:51:29 --> Language Class Initialized
INFO - 2016-06-13 13:51:29 --> Loader Class Initialized
INFO - 2016-06-13 13:51:29 --> Helper loaded: form_helper
INFO - 2016-06-13 13:51:29 --> Database Driver Class Initialized
INFO - 2016-06-13 13:51:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:51:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:51:29 --> Email Class Initialized
INFO - 2016-06-13 13:51:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:51:29 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:51:29 --> Helper loaded: language_helper
INFO - 2016-06-13 13:51:29 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:51:29 --> Model Class Initialized
INFO - 2016-06-13 13:51:29 --> Helper loaded: date_helper
INFO - 2016-06-13 13:51:29 --> Controller Class Initialized
INFO - 2016-06-13 13:51:29 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:51:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:51:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:51:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:51:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:51:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:51:29 --> Model Class Initialized
INFO - 2016-06-13 13:51:29 --> Form Validation Class Initialized
INFO - 2016-06-13 13:51:29 --> Final output sent to browser
DEBUG - 2016-06-13 13:51:29 --> Total execution time: 0.0536
INFO - 2016-06-13 13:51:44 --> Config Class Initialized
INFO - 2016-06-13 13:51:44 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:51:44 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:51:44 --> Utf8 Class Initialized
INFO - 2016-06-13 13:51:44 --> URI Class Initialized
INFO - 2016-06-13 13:51:44 --> Router Class Initialized
INFO - 2016-06-13 13:51:44 --> Output Class Initialized
INFO - 2016-06-13 13:51:44 --> Security Class Initialized
DEBUG - 2016-06-13 13:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:51:44 --> Input Class Initialized
INFO - 2016-06-13 13:51:44 --> Language Class Initialized
INFO - 2016-06-13 13:51:44 --> Loader Class Initialized
INFO - 2016-06-13 13:51:44 --> Helper loaded: form_helper
INFO - 2016-06-13 13:51:44 --> Database Driver Class Initialized
INFO - 2016-06-13 13:51:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:51:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:51:44 --> Email Class Initialized
INFO - 2016-06-13 13:51:44 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:51:44 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:51:44 --> Helper loaded: language_helper
INFO - 2016-06-13 13:51:44 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:51:44 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:51:44 --> Model Class Initialized
INFO - 2016-06-13 13:51:44 --> Helper loaded: date_helper
INFO - 2016-06-13 13:51:44 --> Controller Class Initialized
INFO - 2016-06-13 13:51:44 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:51:44 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:51:44 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:51:44 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:51:44 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:51:44 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:51:44 --> Model Class Initialized
INFO - 2016-06-13 13:51:44 --> Form Validation Class Initialized
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:51:44 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:51:44 --> Final output sent to browser
DEBUG - 2016-06-13 13:51:44 --> Total execution time: 0.1974
INFO - 2016-06-13 13:51:45 --> Config Class Initialized
INFO - 2016-06-13 13:51:45 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:51:45 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:51:45 --> Utf8 Class Initialized
INFO - 2016-06-13 13:51:45 --> URI Class Initialized
INFO - 2016-06-13 13:51:45 --> Router Class Initialized
INFO - 2016-06-13 13:51:45 --> Output Class Initialized
INFO - 2016-06-13 13:51:45 --> Security Class Initialized
DEBUG - 2016-06-13 13:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:51:45 --> Input Class Initialized
INFO - 2016-06-13 13:51:45 --> Language Class Initialized
INFO - 2016-06-13 13:51:45 --> Loader Class Initialized
INFO - 2016-06-13 13:51:45 --> Helper loaded: form_helper
INFO - 2016-06-13 13:51:45 --> Database Driver Class Initialized
INFO - 2016-06-13 13:51:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:51:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:51:45 --> Email Class Initialized
INFO - 2016-06-13 13:51:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:51:45 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:51:45 --> Helper loaded: language_helper
INFO - 2016-06-13 13:51:45 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:51:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:51:45 --> Model Class Initialized
INFO - 2016-06-13 13:51:45 --> Helper loaded: date_helper
INFO - 2016-06-13 13:51:45 --> Controller Class Initialized
INFO - 2016-06-13 13:51:45 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:51:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:51:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:51:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:51:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:51:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:51:45 --> Model Class Initialized
INFO - 2016-06-13 13:51:45 --> Form Validation Class Initialized
INFO - 2016-06-13 13:51:45 --> Final output sent to browser
DEBUG - 2016-06-13 13:51:45 --> Total execution time: 0.0525
INFO - 2016-06-13 13:52:24 --> Config Class Initialized
INFO - 2016-06-13 13:52:24 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:52:24 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:52:24 --> Utf8 Class Initialized
INFO - 2016-06-13 13:52:24 --> URI Class Initialized
INFO - 2016-06-13 13:52:24 --> Router Class Initialized
INFO - 2016-06-13 13:52:24 --> Output Class Initialized
INFO - 2016-06-13 13:52:24 --> Security Class Initialized
DEBUG - 2016-06-13 13:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:52:24 --> Input Class Initialized
INFO - 2016-06-13 13:52:24 --> Language Class Initialized
INFO - 2016-06-13 13:52:24 --> Loader Class Initialized
INFO - 2016-06-13 13:52:24 --> Helper loaded: form_helper
INFO - 2016-06-13 13:52:24 --> Database Driver Class Initialized
INFO - 2016-06-13 13:52:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:52:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:52:24 --> Email Class Initialized
INFO - 2016-06-13 13:52:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:52:24 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:52:24 --> Helper loaded: language_helper
INFO - 2016-06-13 13:52:24 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:52:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:52:24 --> Model Class Initialized
INFO - 2016-06-13 13:52:24 --> Helper loaded: date_helper
INFO - 2016-06-13 13:52:24 --> Controller Class Initialized
INFO - 2016-06-13 13:52:24 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:52:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:52:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:52:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:52:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:52:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:52:24 --> Model Class Initialized
INFO - 2016-06-13 13:52:24 --> Form Validation Class Initialized
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:52:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:52:24 --> Final output sent to browser
DEBUG - 2016-06-13 13:52:24 --> Total execution time: 0.1748
INFO - 2016-06-13 13:52:25 --> Config Class Initialized
INFO - 2016-06-13 13:52:25 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:52:25 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:52:25 --> Utf8 Class Initialized
INFO - 2016-06-13 13:52:25 --> URI Class Initialized
INFO - 2016-06-13 13:52:25 --> Router Class Initialized
INFO - 2016-06-13 13:52:25 --> Output Class Initialized
INFO - 2016-06-13 13:52:25 --> Security Class Initialized
DEBUG - 2016-06-13 13:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:52:25 --> Input Class Initialized
INFO - 2016-06-13 13:52:25 --> Language Class Initialized
INFO - 2016-06-13 13:52:25 --> Loader Class Initialized
INFO - 2016-06-13 13:52:25 --> Helper loaded: form_helper
INFO - 2016-06-13 13:52:25 --> Database Driver Class Initialized
INFO - 2016-06-13 13:52:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:52:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:52:25 --> Email Class Initialized
INFO - 2016-06-13 13:52:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:52:25 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:52:25 --> Helper loaded: language_helper
INFO - 2016-06-13 13:52:25 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:52:25 --> Model Class Initialized
INFO - 2016-06-13 13:52:25 --> Helper loaded: date_helper
INFO - 2016-06-13 13:52:25 --> Controller Class Initialized
INFO - 2016-06-13 13:52:25 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:52:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:52:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:52:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:52:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:52:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:52:25 --> Model Class Initialized
INFO - 2016-06-13 13:52:25 --> Form Validation Class Initialized
INFO - 2016-06-13 13:52:25 --> Final output sent to browser
DEBUG - 2016-06-13 13:52:25 --> Total execution time: 0.1021
INFO - 2016-06-13 13:52:35 --> Config Class Initialized
INFO - 2016-06-13 13:52:35 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:52:35 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:52:35 --> Utf8 Class Initialized
INFO - 2016-06-13 13:52:35 --> URI Class Initialized
INFO - 2016-06-13 13:52:35 --> Router Class Initialized
INFO - 2016-06-13 13:52:35 --> Output Class Initialized
INFO - 2016-06-13 13:52:35 --> Security Class Initialized
DEBUG - 2016-06-13 13:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:52:35 --> Input Class Initialized
INFO - 2016-06-13 13:52:35 --> Language Class Initialized
INFO - 2016-06-13 13:52:35 --> Loader Class Initialized
INFO - 2016-06-13 13:52:35 --> Helper loaded: form_helper
INFO - 2016-06-13 13:52:36 --> Database Driver Class Initialized
INFO - 2016-06-13 13:52:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:52:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:52:36 --> Email Class Initialized
INFO - 2016-06-13 13:52:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:52:36 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:52:36 --> Helper loaded: language_helper
INFO - 2016-06-13 13:52:36 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:52:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:52:36 --> Model Class Initialized
INFO - 2016-06-13 13:52:36 --> Helper loaded: date_helper
INFO - 2016-06-13 13:52:36 --> Controller Class Initialized
INFO - 2016-06-13 13:52:36 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:52:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:52:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:52:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:52:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:52:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:52:36 --> Model Class Initialized
INFO - 2016-06-13 13:52:36 --> Form Validation Class Initialized
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:52:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:52:36 --> Final output sent to browser
DEBUG - 2016-06-13 13:52:36 --> Total execution time: 0.0910
INFO - 2016-06-13 13:52:37 --> Config Class Initialized
INFO - 2016-06-13 13:52:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:52:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:52:37 --> Utf8 Class Initialized
INFO - 2016-06-13 13:52:37 --> URI Class Initialized
INFO - 2016-06-13 13:52:37 --> Router Class Initialized
INFO - 2016-06-13 13:52:37 --> Output Class Initialized
INFO - 2016-06-13 13:52:37 --> Security Class Initialized
DEBUG - 2016-06-13 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:52:37 --> Input Class Initialized
INFO - 2016-06-13 13:52:37 --> Language Class Initialized
INFO - 2016-06-13 13:52:37 --> Loader Class Initialized
INFO - 2016-06-13 13:52:37 --> Helper loaded: form_helper
INFO - 2016-06-13 13:52:37 --> Database Driver Class Initialized
INFO - 2016-06-13 13:52:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:52:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:52:37 --> Email Class Initialized
INFO - 2016-06-13 13:52:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:52:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:52:37 --> Helper loaded: language_helper
INFO - 2016-06-13 13:52:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:52:37 --> Model Class Initialized
INFO - 2016-06-13 13:52:37 --> Helper loaded: date_helper
INFO - 2016-06-13 13:52:37 --> Controller Class Initialized
INFO - 2016-06-13 13:52:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:52:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:52:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:52:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:52:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:52:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:52:37 --> Model Class Initialized
INFO - 2016-06-13 13:52:37 --> Form Validation Class Initialized
INFO - 2016-06-13 13:52:37 --> Final output sent to browser
DEBUG - 2016-06-13 13:52:37 --> Total execution time: 0.0864
INFO - 2016-06-13 13:56:43 --> Config Class Initialized
INFO - 2016-06-13 13:56:43 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:56:43 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:56:43 --> Utf8 Class Initialized
INFO - 2016-06-13 13:56:43 --> URI Class Initialized
INFO - 2016-06-13 13:56:43 --> Router Class Initialized
INFO - 2016-06-13 13:56:43 --> Output Class Initialized
INFO - 2016-06-13 13:56:43 --> Security Class Initialized
DEBUG - 2016-06-13 13:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:56:43 --> Input Class Initialized
INFO - 2016-06-13 13:56:43 --> Language Class Initialized
INFO - 2016-06-13 13:56:43 --> Loader Class Initialized
INFO - 2016-06-13 13:56:43 --> Helper loaded: form_helper
INFO - 2016-06-13 13:56:43 --> Database Driver Class Initialized
INFO - 2016-06-13 13:56:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:56:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:56:43 --> Email Class Initialized
INFO - 2016-06-13 13:56:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:56:43 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:56:43 --> Helper loaded: language_helper
INFO - 2016-06-13 13:56:43 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:56:43 --> Model Class Initialized
INFO - 2016-06-13 13:56:43 --> Helper loaded: date_helper
INFO - 2016-06-13 13:56:43 --> Controller Class Initialized
INFO - 2016-06-13 13:56:43 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:56:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:56:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:56:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:56:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:56:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:56:43 --> Model Class Initialized
INFO - 2016-06-13 13:56:43 --> Form Validation Class Initialized
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:56:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:56:43 --> Final output sent to browser
DEBUG - 2016-06-13 13:56:43 --> Total execution time: 0.1384
INFO - 2016-06-13 13:56:45 --> Config Class Initialized
INFO - 2016-06-13 13:56:45 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:56:45 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:56:45 --> Utf8 Class Initialized
INFO - 2016-06-13 13:56:45 --> URI Class Initialized
INFO - 2016-06-13 13:56:45 --> Router Class Initialized
INFO - 2016-06-13 13:56:45 --> Output Class Initialized
INFO - 2016-06-13 13:56:45 --> Security Class Initialized
DEBUG - 2016-06-13 13:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:56:45 --> Input Class Initialized
INFO - 2016-06-13 13:56:45 --> Language Class Initialized
INFO - 2016-06-13 13:56:45 --> Loader Class Initialized
INFO - 2016-06-13 13:56:45 --> Helper loaded: form_helper
INFO - 2016-06-13 13:56:45 --> Database Driver Class Initialized
INFO - 2016-06-13 13:56:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:56:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:56:45 --> Email Class Initialized
INFO - 2016-06-13 13:56:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:56:45 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:56:45 --> Helper loaded: language_helper
INFO - 2016-06-13 13:56:45 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:56:45 --> Model Class Initialized
INFO - 2016-06-13 13:56:45 --> Helper loaded: date_helper
INFO - 2016-06-13 13:56:45 --> Controller Class Initialized
INFO - 2016-06-13 13:56:45 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:56:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:56:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:56:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:56:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:56:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:56:45 --> Model Class Initialized
INFO - 2016-06-13 13:56:45 --> Form Validation Class Initialized
INFO - 2016-06-13 13:56:45 --> Final output sent to browser
DEBUG - 2016-06-13 13:56:45 --> Total execution time: 0.1002
INFO - 2016-06-13 13:58:45 --> Config Class Initialized
INFO - 2016-06-13 13:58:45 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:58:45 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:58:45 --> Utf8 Class Initialized
INFO - 2016-06-13 13:58:45 --> URI Class Initialized
INFO - 2016-06-13 13:58:45 --> Router Class Initialized
INFO - 2016-06-13 13:58:45 --> Output Class Initialized
INFO - 2016-06-13 13:58:45 --> Security Class Initialized
DEBUG - 2016-06-13 13:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:58:45 --> Input Class Initialized
INFO - 2016-06-13 13:58:45 --> Language Class Initialized
INFO - 2016-06-13 13:58:45 --> Loader Class Initialized
INFO - 2016-06-13 13:58:45 --> Helper loaded: form_helper
INFO - 2016-06-13 13:58:45 --> Database Driver Class Initialized
INFO - 2016-06-13 13:58:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:58:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:58:45 --> Email Class Initialized
INFO - 2016-06-13 13:58:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:58:45 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:58:45 --> Helper loaded: language_helper
INFO - 2016-06-13 13:58:45 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:58:45 --> Model Class Initialized
INFO - 2016-06-13 13:58:45 --> Helper loaded: date_helper
INFO - 2016-06-13 13:58:45 --> Controller Class Initialized
INFO - 2016-06-13 13:58:45 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:58:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:58:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:58:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:58:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:58:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:58:45 --> Model Class Initialized
INFO - 2016-06-13 13:58:45 --> Form Validation Class Initialized
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:58:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:58:45 --> Final output sent to browser
DEBUG - 2016-06-13 13:58:45 --> Total execution time: 0.1258
INFO - 2016-06-13 13:58:47 --> Config Class Initialized
INFO - 2016-06-13 13:58:47 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:58:47 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:58:47 --> Utf8 Class Initialized
INFO - 2016-06-13 13:58:47 --> URI Class Initialized
INFO - 2016-06-13 13:58:47 --> Router Class Initialized
INFO - 2016-06-13 13:58:47 --> Output Class Initialized
INFO - 2016-06-13 13:58:47 --> Security Class Initialized
DEBUG - 2016-06-13 13:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:58:47 --> Input Class Initialized
INFO - 2016-06-13 13:58:47 --> Language Class Initialized
INFO - 2016-06-13 13:58:47 --> Loader Class Initialized
INFO - 2016-06-13 13:58:47 --> Helper loaded: form_helper
INFO - 2016-06-13 13:58:47 --> Database Driver Class Initialized
INFO - 2016-06-13 13:58:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:58:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:58:47 --> Email Class Initialized
INFO - 2016-06-13 13:58:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:58:47 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:58:47 --> Helper loaded: language_helper
INFO - 2016-06-13 13:58:47 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:58:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:58:47 --> Model Class Initialized
INFO - 2016-06-13 13:58:47 --> Helper loaded: date_helper
INFO - 2016-06-13 13:58:47 --> Controller Class Initialized
INFO - 2016-06-13 13:58:47 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:58:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:58:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:58:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:58:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:58:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:58:47 --> Model Class Initialized
INFO - 2016-06-13 13:58:47 --> Form Validation Class Initialized
INFO - 2016-06-13 13:58:47 --> Final output sent to browser
DEBUG - 2016-06-13 13:58:47 --> Total execution time: 0.1195
INFO - 2016-06-13 13:58:54 --> Config Class Initialized
INFO - 2016-06-13 13:58:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:58:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:58:54 --> Utf8 Class Initialized
INFO - 2016-06-13 13:58:54 --> URI Class Initialized
INFO - 2016-06-13 13:58:54 --> Router Class Initialized
INFO - 2016-06-13 13:58:54 --> Output Class Initialized
INFO - 2016-06-13 13:58:54 --> Security Class Initialized
DEBUG - 2016-06-13 13:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:58:54 --> Input Class Initialized
INFO - 2016-06-13 13:58:54 --> Language Class Initialized
INFO - 2016-06-13 13:58:54 --> Loader Class Initialized
INFO - 2016-06-13 13:58:54 --> Helper loaded: form_helper
INFO - 2016-06-13 13:58:54 --> Database Driver Class Initialized
INFO - 2016-06-13 13:58:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:58:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:58:54 --> Email Class Initialized
INFO - 2016-06-13 13:58:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:58:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:58:54 --> Helper loaded: language_helper
INFO - 2016-06-13 13:58:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:58:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:58:54 --> Model Class Initialized
INFO - 2016-06-13 13:58:54 --> Helper loaded: date_helper
INFO - 2016-06-13 13:58:54 --> Controller Class Initialized
INFO - 2016-06-13 13:58:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:58:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:58:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:58:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:58:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:58:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:58:54 --> Model Class Initialized
INFO - 2016-06-13 13:58:54 --> Form Validation Class Initialized
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:58:54 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:58:54 --> Final output sent to browser
DEBUG - 2016-06-13 13:58:54 --> Total execution time: 0.1266
INFO - 2016-06-13 13:58:55 --> Config Class Initialized
INFO - 2016-06-13 13:58:55 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:58:55 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:58:55 --> Utf8 Class Initialized
INFO - 2016-06-13 13:58:55 --> URI Class Initialized
INFO - 2016-06-13 13:58:55 --> Router Class Initialized
INFO - 2016-06-13 13:58:55 --> Output Class Initialized
INFO - 2016-06-13 13:58:55 --> Security Class Initialized
DEBUG - 2016-06-13 13:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:58:55 --> Input Class Initialized
INFO - 2016-06-13 13:58:55 --> Language Class Initialized
INFO - 2016-06-13 13:58:55 --> Loader Class Initialized
INFO - 2016-06-13 13:58:55 --> Helper loaded: form_helper
INFO - 2016-06-13 13:58:55 --> Database Driver Class Initialized
INFO - 2016-06-13 13:58:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:58:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:58:55 --> Email Class Initialized
INFO - 2016-06-13 13:58:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:58:55 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:58:55 --> Helper loaded: language_helper
INFO - 2016-06-13 13:58:55 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:58:55 --> Model Class Initialized
INFO - 2016-06-13 13:58:55 --> Helper loaded: date_helper
INFO - 2016-06-13 13:58:55 --> Controller Class Initialized
INFO - 2016-06-13 13:58:55 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:58:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:58:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:58:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:58:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:58:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:58:55 --> Model Class Initialized
INFO - 2016-06-13 13:58:55 --> Form Validation Class Initialized
INFO - 2016-06-13 13:58:55 --> Final output sent to browser
DEBUG - 2016-06-13 13:58:55 --> Total execution time: 0.1848
INFO - 2016-06-13 13:59:17 --> Config Class Initialized
INFO - 2016-06-13 13:59:17 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:59:17 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:59:17 --> Utf8 Class Initialized
INFO - 2016-06-13 13:59:17 --> URI Class Initialized
INFO - 2016-06-13 13:59:17 --> Router Class Initialized
INFO - 2016-06-13 13:59:17 --> Output Class Initialized
INFO - 2016-06-13 13:59:17 --> Security Class Initialized
DEBUG - 2016-06-13 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:59:17 --> Input Class Initialized
INFO - 2016-06-13 13:59:17 --> Language Class Initialized
INFO - 2016-06-13 13:59:17 --> Loader Class Initialized
INFO - 2016-06-13 13:59:17 --> Helper loaded: form_helper
INFO - 2016-06-13 13:59:17 --> Database Driver Class Initialized
INFO - 2016-06-13 13:59:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:59:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:59:17 --> Email Class Initialized
INFO - 2016-06-13 13:59:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:59:17 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:59:17 --> Helper loaded: language_helper
INFO - 2016-06-13 13:59:17 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:59:17 --> Model Class Initialized
INFO - 2016-06-13 13:59:17 --> Helper loaded: date_helper
INFO - 2016-06-13 13:59:17 --> Controller Class Initialized
INFO - 2016-06-13 13:59:17 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:59:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:59:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:59:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:59:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:59:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:59:17 --> Model Class Initialized
INFO - 2016-06-13 13:59:17 --> Form Validation Class Initialized
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:59:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:59:17 --> Final output sent to browser
DEBUG - 2016-06-13 13:59:17 --> Total execution time: 0.1778
INFO - 2016-06-13 13:59:18 --> Config Class Initialized
INFO - 2016-06-13 13:59:18 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:59:18 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:59:18 --> Utf8 Class Initialized
INFO - 2016-06-13 13:59:18 --> URI Class Initialized
INFO - 2016-06-13 13:59:18 --> Router Class Initialized
INFO - 2016-06-13 13:59:18 --> Output Class Initialized
INFO - 2016-06-13 13:59:18 --> Security Class Initialized
DEBUG - 2016-06-13 13:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:59:18 --> Input Class Initialized
INFO - 2016-06-13 13:59:18 --> Language Class Initialized
INFO - 2016-06-13 13:59:18 --> Loader Class Initialized
INFO - 2016-06-13 13:59:18 --> Helper loaded: form_helper
INFO - 2016-06-13 13:59:18 --> Database Driver Class Initialized
INFO - 2016-06-13 13:59:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:59:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:59:18 --> Email Class Initialized
INFO - 2016-06-13 13:59:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:59:18 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:59:18 --> Helper loaded: language_helper
INFO - 2016-06-13 13:59:18 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:59:18 --> Model Class Initialized
INFO - 2016-06-13 13:59:18 --> Helper loaded: date_helper
INFO - 2016-06-13 13:59:18 --> Controller Class Initialized
INFO - 2016-06-13 13:59:18 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:59:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:59:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:59:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:59:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:59:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:59:18 --> Model Class Initialized
INFO - 2016-06-13 13:59:18 --> Form Validation Class Initialized
INFO - 2016-06-13 13:59:18 --> Final output sent to browser
DEBUG - 2016-06-13 13:59:18 --> Total execution time: 0.1112
INFO - 2016-06-13 13:59:27 --> Config Class Initialized
INFO - 2016-06-13 13:59:27 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:59:27 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:59:27 --> Utf8 Class Initialized
INFO - 2016-06-13 13:59:27 --> URI Class Initialized
INFO - 2016-06-13 13:59:27 --> Router Class Initialized
INFO - 2016-06-13 13:59:27 --> Output Class Initialized
INFO - 2016-06-13 13:59:27 --> Security Class Initialized
DEBUG - 2016-06-13 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:59:27 --> Input Class Initialized
INFO - 2016-06-13 13:59:27 --> Language Class Initialized
INFO - 2016-06-13 13:59:27 --> Loader Class Initialized
INFO - 2016-06-13 13:59:27 --> Helper loaded: form_helper
INFO - 2016-06-13 13:59:27 --> Database Driver Class Initialized
INFO - 2016-06-13 13:59:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:59:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:59:27 --> Email Class Initialized
INFO - 2016-06-13 13:59:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:59:27 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:59:27 --> Helper loaded: language_helper
INFO - 2016-06-13 13:59:27 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:59:27 --> Model Class Initialized
INFO - 2016-06-13 13:59:27 --> Helper loaded: date_helper
INFO - 2016-06-13 13:59:27 --> Controller Class Initialized
INFO - 2016-06-13 13:59:27 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:59:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:59:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:59:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:59:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:59:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:59:27 --> Model Class Initialized
INFO - 2016-06-13 13:59:27 --> Form Validation Class Initialized
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:59:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:59:27 --> Final output sent to browser
DEBUG - 2016-06-13 13:59:27 --> Total execution time: 0.1206
INFO - 2016-06-13 13:59:28 --> Config Class Initialized
INFO - 2016-06-13 13:59:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:59:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:59:28 --> Utf8 Class Initialized
INFO - 2016-06-13 13:59:28 --> URI Class Initialized
INFO - 2016-06-13 13:59:28 --> Router Class Initialized
INFO - 2016-06-13 13:59:28 --> Output Class Initialized
INFO - 2016-06-13 13:59:28 --> Security Class Initialized
DEBUG - 2016-06-13 13:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:59:28 --> Input Class Initialized
INFO - 2016-06-13 13:59:28 --> Language Class Initialized
INFO - 2016-06-13 13:59:28 --> Loader Class Initialized
INFO - 2016-06-13 13:59:28 --> Helper loaded: form_helper
INFO - 2016-06-13 13:59:28 --> Database Driver Class Initialized
INFO - 2016-06-13 13:59:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:59:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:59:28 --> Email Class Initialized
INFO - 2016-06-13 13:59:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:59:28 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:59:28 --> Helper loaded: language_helper
INFO - 2016-06-13 13:59:28 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:59:28 --> Model Class Initialized
INFO - 2016-06-13 13:59:28 --> Helper loaded: date_helper
INFO - 2016-06-13 13:59:28 --> Controller Class Initialized
INFO - 2016-06-13 13:59:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:59:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:59:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:59:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:59:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:59:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:59:28 --> Model Class Initialized
INFO - 2016-06-13 13:59:28 --> Form Validation Class Initialized
INFO - 2016-06-13 13:59:28 --> Final output sent to browser
DEBUG - 2016-06-13 13:59:28 --> Total execution time: 0.0563
INFO - 2016-06-13 13:59:51 --> Config Class Initialized
INFO - 2016-06-13 13:59:51 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:59:51 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:59:51 --> Utf8 Class Initialized
INFO - 2016-06-13 13:59:51 --> URI Class Initialized
INFO - 2016-06-13 13:59:51 --> Router Class Initialized
INFO - 2016-06-13 13:59:51 --> Output Class Initialized
INFO - 2016-06-13 13:59:51 --> Security Class Initialized
DEBUG - 2016-06-13 13:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:59:51 --> Input Class Initialized
INFO - 2016-06-13 13:59:51 --> Language Class Initialized
INFO - 2016-06-13 13:59:51 --> Loader Class Initialized
INFO - 2016-06-13 13:59:51 --> Helper loaded: form_helper
INFO - 2016-06-13 13:59:51 --> Database Driver Class Initialized
INFO - 2016-06-13 13:59:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:59:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:59:51 --> Email Class Initialized
INFO - 2016-06-13 13:59:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:59:51 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:59:51 --> Helper loaded: language_helper
INFO - 2016-06-13 13:59:51 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:59:51 --> Model Class Initialized
INFO - 2016-06-13 13:59:51 --> Helper loaded: date_helper
INFO - 2016-06-13 13:59:51 --> Controller Class Initialized
INFO - 2016-06-13 13:59:51 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:59:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:59:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:59:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:59:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:59:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:59:51 --> Model Class Initialized
INFO - 2016-06-13 13:59:51 --> Form Validation Class Initialized
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 13:59:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 13:59:51 --> Final output sent to browser
DEBUG - 2016-06-13 13:59:51 --> Total execution time: 0.1403
INFO - 2016-06-13 13:59:52 --> Config Class Initialized
INFO - 2016-06-13 13:59:52 --> Hooks Class Initialized
DEBUG - 2016-06-13 13:59:52 --> UTF-8 Support Enabled
INFO - 2016-06-13 13:59:52 --> Utf8 Class Initialized
INFO - 2016-06-13 13:59:52 --> URI Class Initialized
INFO - 2016-06-13 13:59:52 --> Router Class Initialized
INFO - 2016-06-13 13:59:52 --> Output Class Initialized
INFO - 2016-06-13 13:59:52 --> Security Class Initialized
DEBUG - 2016-06-13 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 13:59:52 --> Input Class Initialized
INFO - 2016-06-13 13:59:53 --> Language Class Initialized
INFO - 2016-06-13 13:59:53 --> Loader Class Initialized
INFO - 2016-06-13 13:59:53 --> Helper loaded: form_helper
INFO - 2016-06-13 13:59:53 --> Database Driver Class Initialized
INFO - 2016-06-13 13:59:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 13:59:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 13:59:53 --> Email Class Initialized
INFO - 2016-06-13 13:59:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 13:59:53 --> Helper loaded: cookie_helper
INFO - 2016-06-13 13:59:53 --> Helper loaded: language_helper
INFO - 2016-06-13 13:59:53 --> Helper loaded: url_helper
DEBUG - 2016-06-13 13:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 13:59:53 --> Model Class Initialized
INFO - 2016-06-13 13:59:53 --> Helper loaded: date_helper
INFO - 2016-06-13 13:59:53 --> Controller Class Initialized
INFO - 2016-06-13 13:59:53 --> Helper loaded: languages_helper
INFO - 2016-06-13 13:59:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 13:59:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 13:59:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 13:59:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 13:59:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 13:59:53 --> Model Class Initialized
INFO - 2016-06-13 13:59:53 --> Form Validation Class Initialized
INFO - 2016-06-13 13:59:53 --> Final output sent to browser
DEBUG - 2016-06-13 13:59:53 --> Total execution time: 0.1176
INFO - 2016-06-13 14:00:14 --> Config Class Initialized
INFO - 2016-06-13 14:00:14 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:00:14 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:00:14 --> Utf8 Class Initialized
INFO - 2016-06-13 14:00:14 --> URI Class Initialized
INFO - 2016-06-13 14:00:14 --> Router Class Initialized
INFO - 2016-06-13 14:00:14 --> Output Class Initialized
INFO - 2016-06-13 14:00:14 --> Security Class Initialized
DEBUG - 2016-06-13 14:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:00:14 --> Input Class Initialized
INFO - 2016-06-13 14:00:14 --> Language Class Initialized
INFO - 2016-06-13 14:00:14 --> Loader Class Initialized
INFO - 2016-06-13 14:00:14 --> Helper loaded: form_helper
INFO - 2016-06-13 14:00:14 --> Database Driver Class Initialized
INFO - 2016-06-13 14:00:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:00:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:00:14 --> Email Class Initialized
INFO - 2016-06-13 14:00:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:00:14 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:00:14 --> Helper loaded: language_helper
INFO - 2016-06-13 14:00:14 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:00:14 --> Model Class Initialized
INFO - 2016-06-13 14:00:14 --> Helper loaded: date_helper
INFO - 2016-06-13 14:00:14 --> Controller Class Initialized
INFO - 2016-06-13 14:00:14 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:00:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:00:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:00:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:00:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:00:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:00:14 --> Model Class Initialized
INFO - 2016-06-13 14:00:14 --> Form Validation Class Initialized
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 14:00:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 14:00:14 --> Final output sent to browser
DEBUG - 2016-06-13 14:00:14 --> Total execution time: 0.0966
INFO - 2016-06-13 14:00:15 --> Config Class Initialized
INFO - 2016-06-13 14:00:15 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:00:15 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:00:15 --> Utf8 Class Initialized
INFO - 2016-06-13 14:00:15 --> URI Class Initialized
INFO - 2016-06-13 14:00:15 --> Router Class Initialized
INFO - 2016-06-13 14:00:15 --> Output Class Initialized
INFO - 2016-06-13 14:00:15 --> Security Class Initialized
DEBUG - 2016-06-13 14:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:00:15 --> Input Class Initialized
INFO - 2016-06-13 14:00:15 --> Language Class Initialized
INFO - 2016-06-13 14:00:15 --> Loader Class Initialized
INFO - 2016-06-13 14:00:15 --> Helper loaded: form_helper
INFO - 2016-06-13 14:00:15 --> Database Driver Class Initialized
INFO - 2016-06-13 14:00:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:00:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:00:16 --> Email Class Initialized
INFO - 2016-06-13 14:00:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:00:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:00:16 --> Helper loaded: language_helper
INFO - 2016-06-13 14:00:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:00:16 --> Model Class Initialized
INFO - 2016-06-13 14:00:16 --> Helper loaded: date_helper
INFO - 2016-06-13 14:00:16 --> Controller Class Initialized
INFO - 2016-06-13 14:00:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:00:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:00:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:00:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:00:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:00:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:00:16 --> Model Class Initialized
INFO - 2016-06-13 14:00:16 --> Form Validation Class Initialized
INFO - 2016-06-13 14:00:16 --> Final output sent to browser
DEBUG - 2016-06-13 14:00:16 --> Total execution time: 0.0847
INFO - 2016-06-13 14:00:41 --> Config Class Initialized
INFO - 2016-06-13 14:00:41 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:00:41 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:00:41 --> Utf8 Class Initialized
INFO - 2016-06-13 14:00:41 --> URI Class Initialized
INFO - 2016-06-13 14:00:41 --> Router Class Initialized
INFO - 2016-06-13 14:00:41 --> Output Class Initialized
INFO - 2016-06-13 14:00:41 --> Security Class Initialized
DEBUG - 2016-06-13 14:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:00:41 --> Input Class Initialized
INFO - 2016-06-13 14:00:41 --> Language Class Initialized
INFO - 2016-06-13 14:00:41 --> Loader Class Initialized
INFO - 2016-06-13 14:00:41 --> Helper loaded: form_helper
INFO - 2016-06-13 14:00:41 --> Database Driver Class Initialized
INFO - 2016-06-13 14:00:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:00:41 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:00:41 --> Email Class Initialized
INFO - 2016-06-13 14:00:41 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:00:41 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:00:41 --> Helper loaded: language_helper
INFO - 2016-06-13 14:00:41 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:00:41 --> Model Class Initialized
INFO - 2016-06-13 14:00:41 --> Helper loaded: date_helper
INFO - 2016-06-13 14:00:41 --> Controller Class Initialized
INFO - 2016-06-13 14:00:41 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:00:41 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:00:41 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:00:41 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:00:41 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:00:41 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:00:41 --> Model Class Initialized
INFO - 2016-06-13 14:00:41 --> Form Validation Class Initialized
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 14:00:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 14:00:41 --> Final output sent to browser
DEBUG - 2016-06-13 14:00:41 --> Total execution time: 0.1015
INFO - 2016-06-13 14:00:42 --> Config Class Initialized
INFO - 2016-06-13 14:00:42 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:00:42 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:00:42 --> Utf8 Class Initialized
INFO - 2016-06-13 14:00:42 --> URI Class Initialized
INFO - 2016-06-13 14:00:42 --> Router Class Initialized
INFO - 2016-06-13 14:00:42 --> Output Class Initialized
INFO - 2016-06-13 14:00:42 --> Security Class Initialized
DEBUG - 2016-06-13 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:00:42 --> Input Class Initialized
INFO - 2016-06-13 14:00:42 --> Language Class Initialized
INFO - 2016-06-13 14:00:42 --> Loader Class Initialized
INFO - 2016-06-13 14:00:42 --> Helper loaded: form_helper
INFO - 2016-06-13 14:00:42 --> Database Driver Class Initialized
INFO - 2016-06-13 14:00:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:00:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:00:42 --> Email Class Initialized
INFO - 2016-06-13 14:00:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:00:42 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:00:42 --> Helper loaded: language_helper
INFO - 2016-06-13 14:00:42 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:00:42 --> Model Class Initialized
INFO - 2016-06-13 14:00:42 --> Helper loaded: date_helper
INFO - 2016-06-13 14:00:42 --> Controller Class Initialized
INFO - 2016-06-13 14:00:42 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:00:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:00:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:00:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:00:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:00:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:00:42 --> Model Class Initialized
INFO - 2016-06-13 14:00:42 --> Form Validation Class Initialized
INFO - 2016-06-13 14:00:42 --> Final output sent to browser
DEBUG - 2016-06-13 14:00:42 --> Total execution time: 0.0829
INFO - 2016-06-13 14:02:32 --> Config Class Initialized
INFO - 2016-06-13 14:02:32 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:02:32 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:02:32 --> Utf8 Class Initialized
INFO - 2016-06-13 14:02:32 --> URI Class Initialized
INFO - 2016-06-13 14:02:32 --> Router Class Initialized
INFO - 2016-06-13 14:02:32 --> Output Class Initialized
INFO - 2016-06-13 14:02:32 --> Security Class Initialized
DEBUG - 2016-06-13 14:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:02:32 --> Input Class Initialized
INFO - 2016-06-13 14:02:32 --> Language Class Initialized
INFO - 2016-06-13 14:02:32 --> Loader Class Initialized
INFO - 2016-06-13 14:02:32 --> Helper loaded: form_helper
INFO - 2016-06-13 14:02:32 --> Database Driver Class Initialized
INFO - 2016-06-13 14:02:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:02:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:02:33 --> Email Class Initialized
INFO - 2016-06-13 14:02:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:02:33 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:02:33 --> Helper loaded: language_helper
INFO - 2016-06-13 14:02:33 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:02:33 --> Model Class Initialized
INFO - 2016-06-13 14:02:33 --> Helper loaded: date_helper
INFO - 2016-06-13 14:02:33 --> Controller Class Initialized
INFO - 2016-06-13 14:02:33 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:02:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:02:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:02:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:02:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:02:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:02:33 --> Model Class Initialized
INFO - 2016-06-13 14:02:33 --> Form Validation Class Initialized
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 14:02:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 14:02:33 --> Final output sent to browser
DEBUG - 2016-06-13 14:02:33 --> Total execution time: 0.1815
INFO - 2016-06-13 14:02:34 --> Config Class Initialized
INFO - 2016-06-13 14:02:34 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:02:34 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:02:34 --> Utf8 Class Initialized
INFO - 2016-06-13 14:02:34 --> URI Class Initialized
INFO - 2016-06-13 14:02:34 --> Router Class Initialized
INFO - 2016-06-13 14:02:34 --> Output Class Initialized
INFO - 2016-06-13 14:02:34 --> Security Class Initialized
DEBUG - 2016-06-13 14:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:02:34 --> Input Class Initialized
INFO - 2016-06-13 14:02:34 --> Language Class Initialized
INFO - 2016-06-13 14:02:34 --> Loader Class Initialized
INFO - 2016-06-13 14:02:34 --> Helper loaded: form_helper
INFO - 2016-06-13 14:02:34 --> Database Driver Class Initialized
INFO - 2016-06-13 14:02:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:02:34 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:02:34 --> Email Class Initialized
INFO - 2016-06-13 14:02:34 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:02:34 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:02:34 --> Helper loaded: language_helper
INFO - 2016-06-13 14:02:34 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:02:34 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:02:34 --> Model Class Initialized
INFO - 2016-06-13 14:02:34 --> Helper loaded: date_helper
INFO - 2016-06-13 14:02:34 --> Controller Class Initialized
INFO - 2016-06-13 14:02:34 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:02:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:02:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:02:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:02:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:02:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:02:34 --> Model Class Initialized
INFO - 2016-06-13 14:02:34 --> Form Validation Class Initialized
INFO - 2016-06-13 14:02:34 --> Final output sent to browser
DEBUG - 2016-06-13 14:02:34 --> Total execution time: 0.0599
INFO - 2016-06-13 14:02:46 --> Config Class Initialized
INFO - 2016-06-13 14:02:46 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:02:46 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:02:46 --> Utf8 Class Initialized
INFO - 2016-06-13 14:02:46 --> URI Class Initialized
INFO - 2016-06-13 14:02:46 --> Router Class Initialized
INFO - 2016-06-13 14:02:46 --> Output Class Initialized
INFO - 2016-06-13 14:02:46 --> Security Class Initialized
DEBUG - 2016-06-13 14:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:02:46 --> Input Class Initialized
INFO - 2016-06-13 14:02:46 --> Language Class Initialized
INFO - 2016-06-13 14:02:46 --> Loader Class Initialized
INFO - 2016-06-13 14:02:46 --> Helper loaded: form_helper
INFO - 2016-06-13 14:02:46 --> Database Driver Class Initialized
INFO - 2016-06-13 14:02:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:02:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:02:46 --> Email Class Initialized
INFO - 2016-06-13 14:02:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:02:46 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:02:46 --> Helper loaded: language_helper
INFO - 2016-06-13 14:02:46 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:02:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:02:46 --> Model Class Initialized
INFO - 2016-06-13 14:02:46 --> Helper loaded: date_helper
INFO - 2016-06-13 14:02:46 --> Controller Class Initialized
INFO - 2016-06-13 14:02:46 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:02:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:02:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:02:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:02:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:02:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:02:46 --> Model Class Initialized
INFO - 2016-06-13 14:02:46 --> Form Validation Class Initialized
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 14:02:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 14:02:46 --> Final output sent to browser
DEBUG - 2016-06-13 14:02:46 --> Total execution time: 0.0709
INFO - 2016-06-13 14:02:47 --> Config Class Initialized
INFO - 2016-06-13 14:02:47 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:02:47 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:02:47 --> Utf8 Class Initialized
INFO - 2016-06-13 14:02:47 --> URI Class Initialized
INFO - 2016-06-13 14:02:47 --> Router Class Initialized
INFO - 2016-06-13 14:02:47 --> Output Class Initialized
INFO - 2016-06-13 14:02:47 --> Security Class Initialized
DEBUG - 2016-06-13 14:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:02:47 --> Input Class Initialized
INFO - 2016-06-13 14:02:47 --> Language Class Initialized
INFO - 2016-06-13 14:02:47 --> Loader Class Initialized
INFO - 2016-06-13 14:02:47 --> Helper loaded: form_helper
INFO - 2016-06-13 14:02:47 --> Database Driver Class Initialized
INFO - 2016-06-13 14:02:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:02:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:02:47 --> Email Class Initialized
INFO - 2016-06-13 14:02:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:02:47 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:02:47 --> Helper loaded: language_helper
INFO - 2016-06-13 14:02:47 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:02:47 --> Model Class Initialized
INFO - 2016-06-13 14:02:47 --> Helper loaded: date_helper
INFO - 2016-06-13 14:02:47 --> Controller Class Initialized
INFO - 2016-06-13 14:02:47 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:02:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:02:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:02:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:02:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:02:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:02:47 --> Model Class Initialized
INFO - 2016-06-13 14:02:47 --> Form Validation Class Initialized
INFO - 2016-06-13 14:02:47 --> Final output sent to browser
DEBUG - 2016-06-13 14:02:47 --> Total execution time: 0.0580
INFO - 2016-06-13 14:03:35 --> Config Class Initialized
INFO - 2016-06-13 14:03:35 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:03:35 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:03:35 --> Utf8 Class Initialized
INFO - 2016-06-13 14:03:35 --> URI Class Initialized
INFO - 2016-06-13 14:03:35 --> Router Class Initialized
INFO - 2016-06-13 14:03:35 --> Output Class Initialized
INFO - 2016-06-13 14:03:35 --> Security Class Initialized
DEBUG - 2016-06-13 14:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:03:35 --> Input Class Initialized
INFO - 2016-06-13 14:03:35 --> Language Class Initialized
INFO - 2016-06-13 14:03:35 --> Loader Class Initialized
INFO - 2016-06-13 14:03:35 --> Helper loaded: form_helper
INFO - 2016-06-13 14:03:35 --> Database Driver Class Initialized
INFO - 2016-06-13 14:03:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:03:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:03:35 --> Email Class Initialized
INFO - 2016-06-13 14:03:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:03:35 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:03:35 --> Helper loaded: language_helper
INFO - 2016-06-13 14:03:35 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:03:35 --> Model Class Initialized
INFO - 2016-06-13 14:03:35 --> Helper loaded: date_helper
INFO - 2016-06-13 14:03:35 --> Controller Class Initialized
INFO - 2016-06-13 14:03:35 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:03:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:03:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:03:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:03:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:03:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:03:35 --> Model Class Initialized
INFO - 2016-06-13 14:03:35 --> Form Validation Class Initialized
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 14:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 14:03:35 --> Final output sent to browser
DEBUG - 2016-06-13 14:03:35 --> Total execution time: 0.0696
INFO - 2016-06-13 14:03:48 --> Config Class Initialized
INFO - 2016-06-13 14:03:48 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:03:48 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:03:48 --> Utf8 Class Initialized
INFO - 2016-06-13 14:03:48 --> URI Class Initialized
INFO - 2016-06-13 14:03:48 --> Router Class Initialized
INFO - 2016-06-13 14:03:48 --> Output Class Initialized
INFO - 2016-06-13 14:03:48 --> Security Class Initialized
DEBUG - 2016-06-13 14:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:03:48 --> Input Class Initialized
INFO - 2016-06-13 14:03:48 --> Language Class Initialized
INFO - 2016-06-13 14:03:48 --> Loader Class Initialized
INFO - 2016-06-13 14:03:48 --> Helper loaded: form_helper
INFO - 2016-06-13 14:03:48 --> Database Driver Class Initialized
INFO - 2016-06-13 14:03:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:03:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:03:48 --> Email Class Initialized
INFO - 2016-06-13 14:03:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:03:48 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:03:48 --> Helper loaded: language_helper
INFO - 2016-06-13 14:03:48 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:03:48 --> Model Class Initialized
INFO - 2016-06-13 14:03:48 --> Helper loaded: date_helper
INFO - 2016-06-13 14:03:48 --> Controller Class Initialized
INFO - 2016-06-13 14:03:48 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:03:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:03:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:03:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:03:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:03:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:03:48 --> Model Class Initialized
INFO - 2016-06-13 14:03:48 --> Form Validation Class Initialized
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 14:03:48 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 14:03:48 --> Final output sent to browser
DEBUG - 2016-06-13 14:03:48 --> Total execution time: 0.0728
INFO - 2016-06-13 14:03:49 --> Config Class Initialized
INFO - 2016-06-13 14:03:49 --> Hooks Class Initialized
DEBUG - 2016-06-13 14:03:49 --> UTF-8 Support Enabled
INFO - 2016-06-13 14:03:49 --> Utf8 Class Initialized
INFO - 2016-06-13 14:03:49 --> URI Class Initialized
INFO - 2016-06-13 14:03:49 --> Router Class Initialized
INFO - 2016-06-13 14:03:49 --> Output Class Initialized
INFO - 2016-06-13 14:03:49 --> Security Class Initialized
DEBUG - 2016-06-13 14:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 14:03:49 --> Input Class Initialized
INFO - 2016-06-13 14:03:49 --> Language Class Initialized
INFO - 2016-06-13 14:03:49 --> Loader Class Initialized
INFO - 2016-06-13 14:03:49 --> Helper loaded: form_helper
INFO - 2016-06-13 14:03:49 --> Database Driver Class Initialized
INFO - 2016-06-13 14:03:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 14:03:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 14:03:49 --> Email Class Initialized
INFO - 2016-06-13 14:03:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 14:03:49 --> Helper loaded: cookie_helper
INFO - 2016-06-13 14:03:49 --> Helper loaded: language_helper
INFO - 2016-06-13 14:03:49 --> Helper loaded: url_helper
DEBUG - 2016-06-13 14:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 14:03:49 --> Model Class Initialized
INFO - 2016-06-13 14:03:49 --> Helper loaded: date_helper
INFO - 2016-06-13 14:03:49 --> Controller Class Initialized
INFO - 2016-06-13 14:03:49 --> Helper loaded: languages_helper
INFO - 2016-06-13 14:03:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 14:03:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 14:03:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 14:03:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 14:03:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 14:03:49 --> Model Class Initialized
INFO - 2016-06-13 14:03:49 --> Form Validation Class Initialized
INFO - 2016-06-13 14:03:49 --> Final output sent to browser
DEBUG - 2016-06-13 14:03:49 --> Total execution time: 0.0202
INFO - 2016-06-13 15:04:26 --> Config Class Initialized
INFO - 2016-06-13 15:04:26 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:04:26 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:04:26 --> Utf8 Class Initialized
INFO - 2016-06-13 15:04:26 --> URI Class Initialized
INFO - 2016-06-13 15:04:26 --> Router Class Initialized
INFO - 2016-06-13 15:04:26 --> Output Class Initialized
INFO - 2016-06-13 15:04:26 --> Security Class Initialized
DEBUG - 2016-06-13 15:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:04:26 --> Input Class Initialized
INFO - 2016-06-13 15:04:26 --> Language Class Initialized
INFO - 2016-06-13 15:04:26 --> Loader Class Initialized
INFO - 2016-06-13 15:04:26 --> Helper loaded: form_helper
INFO - 2016-06-13 15:04:26 --> Database Driver Class Initialized
INFO - 2016-06-13 15:04:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:04:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:04:26 --> Email Class Initialized
INFO - 2016-06-13 15:04:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:04:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:04:26 --> Helper loaded: language_helper
INFO - 2016-06-13 15:04:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:04:26 --> Model Class Initialized
INFO - 2016-06-13 15:04:26 --> Helper loaded: date_helper
INFO - 2016-06-13 15:04:26 --> Controller Class Initialized
INFO - 2016-06-13 15:04:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:04:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:04:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:04:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:04:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:04:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:04:26 --> Model Class Initialized
INFO - 2016-06-13 15:04:26 --> Form Validation Class Initialized
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:04:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:04:26 --> Final output sent to browser
DEBUG - 2016-06-13 15:04:26 --> Total execution time: 0.1037
INFO - 2016-06-13 15:04:43 --> Config Class Initialized
INFO - 2016-06-13 15:04:43 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:04:43 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:04:43 --> Utf8 Class Initialized
INFO - 2016-06-13 15:04:43 --> URI Class Initialized
INFO - 2016-06-13 15:04:43 --> Router Class Initialized
INFO - 2016-06-13 15:04:43 --> Output Class Initialized
INFO - 2016-06-13 15:04:43 --> Security Class Initialized
DEBUG - 2016-06-13 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:04:43 --> Input Class Initialized
INFO - 2016-06-13 15:04:43 --> Language Class Initialized
INFO - 2016-06-13 15:04:43 --> Loader Class Initialized
INFO - 2016-06-13 15:04:43 --> Helper loaded: form_helper
INFO - 2016-06-13 15:04:43 --> Database Driver Class Initialized
INFO - 2016-06-13 15:04:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:04:43 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:04:43 --> Email Class Initialized
INFO - 2016-06-13 15:04:43 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:04:43 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:04:43 --> Helper loaded: language_helper
INFO - 2016-06-13 15:04:43 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:04:43 --> Model Class Initialized
INFO - 2016-06-13 15:04:43 --> Helper loaded: date_helper
INFO - 2016-06-13 15:04:43 --> Controller Class Initialized
INFO - 2016-06-13 15:04:43 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:04:43 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:04:43 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:04:43 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:04:43 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:04:43 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:04:43 --> Model Class Initialized
INFO - 2016-06-13 15:04:43 --> Form Validation Class Initialized
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:04:43 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:04:43 --> Final output sent to browser
DEBUG - 2016-06-13 15:04:43 --> Total execution time: 0.0948
INFO - 2016-06-13 15:04:44 --> Config Class Initialized
INFO - 2016-06-13 15:04:44 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:04:44 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:04:44 --> Utf8 Class Initialized
INFO - 2016-06-13 15:04:44 --> URI Class Initialized
INFO - 2016-06-13 15:04:44 --> Router Class Initialized
INFO - 2016-06-13 15:04:44 --> Output Class Initialized
INFO - 2016-06-13 15:04:44 --> Security Class Initialized
DEBUG - 2016-06-13 15:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:04:44 --> Input Class Initialized
INFO - 2016-06-13 15:04:44 --> Language Class Initialized
INFO - 2016-06-13 15:04:44 --> Loader Class Initialized
INFO - 2016-06-13 15:04:44 --> Helper loaded: form_helper
INFO - 2016-06-13 15:04:44 --> Database Driver Class Initialized
INFO - 2016-06-13 15:04:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:04:44 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:04:45 --> Email Class Initialized
INFO - 2016-06-13 15:04:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:04:45 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:04:45 --> Helper loaded: language_helper
INFO - 2016-06-13 15:04:45 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:04:45 --> Model Class Initialized
INFO - 2016-06-13 15:04:45 --> Helper loaded: date_helper
INFO - 2016-06-13 15:04:45 --> Controller Class Initialized
INFO - 2016-06-13 15:04:45 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:04:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:04:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:04:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:04:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:04:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:04:45 --> Model Class Initialized
INFO - 2016-06-13 15:04:45 --> Form Validation Class Initialized
INFO - 2016-06-13 15:04:45 --> Final output sent to browser
DEBUG - 2016-06-13 15:04:45 --> Total execution time: 0.0767
INFO - 2016-06-13 15:05:14 --> Config Class Initialized
INFO - 2016-06-13 15:05:14 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:05:14 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:05:14 --> Utf8 Class Initialized
INFO - 2016-06-13 15:05:14 --> URI Class Initialized
INFO - 2016-06-13 15:05:14 --> Router Class Initialized
INFO - 2016-06-13 15:05:14 --> Output Class Initialized
INFO - 2016-06-13 15:05:14 --> Security Class Initialized
DEBUG - 2016-06-13 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:05:14 --> Input Class Initialized
INFO - 2016-06-13 15:05:14 --> Language Class Initialized
INFO - 2016-06-13 15:05:14 --> Loader Class Initialized
INFO - 2016-06-13 15:05:14 --> Helper loaded: form_helper
INFO - 2016-06-13 15:05:14 --> Database Driver Class Initialized
INFO - 2016-06-13 15:05:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:05:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:05:14 --> Email Class Initialized
INFO - 2016-06-13 15:05:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:05:14 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:05:14 --> Helper loaded: language_helper
INFO - 2016-06-13 15:05:14 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:05:14 --> Model Class Initialized
INFO - 2016-06-13 15:05:14 --> Helper loaded: date_helper
INFO - 2016-06-13 15:05:14 --> Controller Class Initialized
INFO - 2016-06-13 15:05:14 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:05:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:05:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:05:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:05:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:05:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:05:14 --> Model Class Initialized
INFO - 2016-06-13 15:05:14 --> Form Validation Class Initialized
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:05:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:05:14 --> Final output sent to browser
DEBUG - 2016-06-13 15:05:14 --> Total execution time: 0.1792
INFO - 2016-06-13 15:05:15 --> Config Class Initialized
INFO - 2016-06-13 15:05:15 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:05:15 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:05:15 --> Utf8 Class Initialized
INFO - 2016-06-13 15:05:15 --> URI Class Initialized
INFO - 2016-06-13 15:05:15 --> Router Class Initialized
INFO - 2016-06-13 15:05:15 --> Output Class Initialized
INFO - 2016-06-13 15:05:15 --> Security Class Initialized
DEBUG - 2016-06-13 15:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:05:15 --> Input Class Initialized
INFO - 2016-06-13 15:05:15 --> Language Class Initialized
INFO - 2016-06-13 15:05:15 --> Loader Class Initialized
INFO - 2016-06-13 15:05:15 --> Helper loaded: form_helper
INFO - 2016-06-13 15:05:15 --> Database Driver Class Initialized
INFO - 2016-06-13 15:05:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:05:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:05:15 --> Email Class Initialized
INFO - 2016-06-13 15:05:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:05:15 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:05:15 --> Helper loaded: language_helper
INFO - 2016-06-13 15:05:15 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:05:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:05:15 --> Model Class Initialized
INFO - 2016-06-13 15:05:15 --> Helper loaded: date_helper
INFO - 2016-06-13 15:05:15 --> Controller Class Initialized
INFO - 2016-06-13 15:05:15 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:05:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:05:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:05:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:05:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:05:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:05:15 --> Model Class Initialized
INFO - 2016-06-13 15:05:15 --> Form Validation Class Initialized
INFO - 2016-06-13 15:05:15 --> Final output sent to browser
DEBUG - 2016-06-13 15:05:15 --> Total execution time: 0.0955
INFO - 2016-06-13 15:09:18 --> Config Class Initialized
INFO - 2016-06-13 15:09:18 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:09:18 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:09:18 --> Utf8 Class Initialized
INFO - 2016-06-13 15:09:18 --> URI Class Initialized
INFO - 2016-06-13 15:09:18 --> Router Class Initialized
INFO - 2016-06-13 15:09:18 --> Output Class Initialized
INFO - 2016-06-13 15:09:18 --> Security Class Initialized
DEBUG - 2016-06-13 15:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:09:18 --> Input Class Initialized
INFO - 2016-06-13 15:09:18 --> Language Class Initialized
INFO - 2016-06-13 15:09:18 --> Loader Class Initialized
INFO - 2016-06-13 15:09:18 --> Helper loaded: form_helper
INFO - 2016-06-13 15:09:18 --> Database Driver Class Initialized
INFO - 2016-06-13 15:09:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:09:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:09:18 --> Email Class Initialized
INFO - 2016-06-13 15:09:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:09:18 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:09:18 --> Helper loaded: language_helper
INFO - 2016-06-13 15:09:18 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:09:18 --> Model Class Initialized
INFO - 2016-06-13 15:09:18 --> Helper loaded: date_helper
INFO - 2016-06-13 15:09:18 --> Controller Class Initialized
INFO - 2016-06-13 15:09:18 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:09:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:09:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:09:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:09:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:09:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:09:18 --> Model Class Initialized
INFO - 2016-06-13 15:09:18 --> Form Validation Class Initialized
INFO - 2016-06-13 15:09:18 --> Final output sent to browser
DEBUG - 2016-06-13 15:09:18 --> Total execution time: 0.1860
INFO - 2016-06-13 15:09:20 --> Config Class Initialized
INFO - 2016-06-13 15:09:20 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:09:20 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:09:20 --> Utf8 Class Initialized
INFO - 2016-06-13 15:09:20 --> URI Class Initialized
INFO - 2016-06-13 15:09:20 --> Router Class Initialized
INFO - 2016-06-13 15:09:20 --> Output Class Initialized
INFO - 2016-06-13 15:09:20 --> Security Class Initialized
DEBUG - 2016-06-13 15:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:09:20 --> Input Class Initialized
INFO - 2016-06-13 15:09:20 --> Language Class Initialized
INFO - 2016-06-13 15:09:20 --> Loader Class Initialized
INFO - 2016-06-13 15:09:20 --> Helper loaded: form_helper
INFO - 2016-06-13 15:09:20 --> Database Driver Class Initialized
INFO - 2016-06-13 15:09:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:09:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:09:20 --> Email Class Initialized
INFO - 2016-06-13 15:09:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:09:20 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:09:20 --> Helper loaded: language_helper
INFO - 2016-06-13 15:09:20 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:09:20 --> Model Class Initialized
INFO - 2016-06-13 15:09:20 --> Helper loaded: date_helper
INFO - 2016-06-13 15:09:20 --> Controller Class Initialized
INFO - 2016-06-13 15:09:20 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:09:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:09:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:09:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:09:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:09:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:09:20 --> Model Class Initialized
INFO - 2016-06-13 15:09:20 --> Form Validation Class Initialized
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:09:20 --> Could not find the language line "interval_$i"
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:09:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:09:20 --> Final output sent to browser
DEBUG - 2016-06-13 15:09:20 --> Total execution time: 0.0922
INFO - 2016-06-13 15:09:21 --> Config Class Initialized
INFO - 2016-06-13 15:09:21 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:09:21 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:09:21 --> Utf8 Class Initialized
INFO - 2016-06-13 15:09:21 --> URI Class Initialized
INFO - 2016-06-13 15:09:21 --> Router Class Initialized
INFO - 2016-06-13 15:09:21 --> Output Class Initialized
INFO - 2016-06-13 15:09:21 --> Security Class Initialized
DEBUG - 2016-06-13 15:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:09:21 --> Input Class Initialized
INFO - 2016-06-13 15:09:21 --> Language Class Initialized
INFO - 2016-06-13 15:09:21 --> Loader Class Initialized
INFO - 2016-06-13 15:09:21 --> Helper loaded: form_helper
INFO - 2016-06-13 15:09:21 --> Database Driver Class Initialized
INFO - 2016-06-13 15:09:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:09:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:09:21 --> Email Class Initialized
INFO - 2016-06-13 15:09:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:09:21 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:09:21 --> Helper loaded: language_helper
INFO - 2016-06-13 15:09:21 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:09:21 --> Model Class Initialized
INFO - 2016-06-13 15:09:21 --> Helper loaded: date_helper
INFO - 2016-06-13 15:09:21 --> Controller Class Initialized
INFO - 2016-06-13 15:09:21 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:09:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:09:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:09:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:09:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:09:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:09:21 --> Model Class Initialized
INFO - 2016-06-13 15:09:21 --> Form Validation Class Initialized
INFO - 2016-06-13 15:09:21 --> Final output sent to browser
DEBUG - 2016-06-13 15:09:21 --> Total execution time: 0.0707
INFO - 2016-06-13 15:10:24 --> Config Class Initialized
INFO - 2016-06-13 15:10:24 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:10:24 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:10:24 --> Utf8 Class Initialized
INFO - 2016-06-13 15:10:24 --> URI Class Initialized
INFO - 2016-06-13 15:10:24 --> Router Class Initialized
INFO - 2016-06-13 15:10:24 --> Output Class Initialized
INFO - 2016-06-13 15:10:24 --> Security Class Initialized
DEBUG - 2016-06-13 15:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:10:24 --> Input Class Initialized
INFO - 2016-06-13 15:10:24 --> Language Class Initialized
INFO - 2016-06-13 15:10:24 --> Loader Class Initialized
INFO - 2016-06-13 15:10:24 --> Helper loaded: form_helper
INFO - 2016-06-13 15:10:24 --> Database Driver Class Initialized
INFO - 2016-06-13 15:10:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:10:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:10:24 --> Email Class Initialized
INFO - 2016-06-13 15:10:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:10:24 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:10:24 --> Helper loaded: language_helper
INFO - 2016-06-13 15:10:24 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:10:24 --> Model Class Initialized
INFO - 2016-06-13 15:10:24 --> Helper loaded: date_helper
INFO - 2016-06-13 15:10:24 --> Controller Class Initialized
INFO - 2016-06-13 15:10:24 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:10:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:10:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:10:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:10:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:10:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:10:24 --> Model Class Initialized
INFO - 2016-06-13 15:10:24 --> Form Validation Class Initialized
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
ERROR - 2016-06-13 15:10:24 --> Could not find the language line "interval_$i"
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:10:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:10:24 --> Final output sent to browser
DEBUG - 2016-06-13 15:10:24 --> Total execution time: 0.1285
INFO - 2016-06-13 15:10:25 --> Config Class Initialized
INFO - 2016-06-13 15:10:25 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:10:25 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:10:25 --> Utf8 Class Initialized
INFO - 2016-06-13 15:10:25 --> URI Class Initialized
INFO - 2016-06-13 15:10:25 --> Router Class Initialized
INFO - 2016-06-13 15:10:26 --> Output Class Initialized
INFO - 2016-06-13 15:10:26 --> Security Class Initialized
DEBUG - 2016-06-13 15:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:10:26 --> Input Class Initialized
INFO - 2016-06-13 15:10:26 --> Language Class Initialized
INFO - 2016-06-13 15:10:26 --> Loader Class Initialized
INFO - 2016-06-13 15:10:26 --> Helper loaded: form_helper
INFO - 2016-06-13 15:10:26 --> Database Driver Class Initialized
INFO - 2016-06-13 15:10:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:10:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:10:26 --> Email Class Initialized
INFO - 2016-06-13 15:10:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:10:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:10:26 --> Helper loaded: language_helper
INFO - 2016-06-13 15:10:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:10:26 --> Model Class Initialized
INFO - 2016-06-13 15:10:26 --> Helper loaded: date_helper
INFO - 2016-06-13 15:10:26 --> Controller Class Initialized
INFO - 2016-06-13 15:10:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:10:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:10:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:10:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:10:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:10:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:10:26 --> Model Class Initialized
INFO - 2016-06-13 15:10:26 --> Form Validation Class Initialized
INFO - 2016-06-13 15:10:26 --> Final output sent to browser
DEBUG - 2016-06-13 15:10:26 --> Total execution time: 0.1107
INFO - 2016-06-13 15:10:40 --> Config Class Initialized
INFO - 2016-06-13 15:10:40 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:10:40 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:10:40 --> Utf8 Class Initialized
INFO - 2016-06-13 15:10:40 --> URI Class Initialized
INFO - 2016-06-13 15:10:40 --> Router Class Initialized
INFO - 2016-06-13 15:10:40 --> Output Class Initialized
INFO - 2016-06-13 15:10:40 --> Security Class Initialized
DEBUG - 2016-06-13 15:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:10:40 --> Input Class Initialized
INFO - 2016-06-13 15:10:40 --> Language Class Initialized
INFO - 2016-06-13 15:10:40 --> Loader Class Initialized
INFO - 2016-06-13 15:10:40 --> Helper loaded: form_helper
INFO - 2016-06-13 15:10:40 --> Database Driver Class Initialized
INFO - 2016-06-13 15:10:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:10:40 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:10:40 --> Email Class Initialized
INFO - 2016-06-13 15:10:40 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:10:40 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:10:40 --> Helper loaded: language_helper
INFO - 2016-06-13 15:10:40 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:10:40 --> Model Class Initialized
INFO - 2016-06-13 15:10:40 --> Helper loaded: date_helper
INFO - 2016-06-13 15:10:40 --> Controller Class Initialized
INFO - 2016-06-13 15:10:40 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:10:40 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:10:40 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:10:40 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:10:40 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:10:40 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:10:40 --> Model Class Initialized
INFO - 2016-06-13 15:10:40 --> Form Validation Class Initialized
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:10:41 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:10:41 --> Final output sent to browser
DEBUG - 2016-06-13 15:10:41 --> Total execution time: 0.1275
INFO - 2016-06-13 15:10:42 --> Config Class Initialized
INFO - 2016-06-13 15:10:42 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:10:42 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:10:42 --> Utf8 Class Initialized
INFO - 2016-06-13 15:10:42 --> URI Class Initialized
INFO - 2016-06-13 15:10:42 --> Router Class Initialized
INFO - 2016-06-13 15:10:42 --> Output Class Initialized
INFO - 2016-06-13 15:10:42 --> Security Class Initialized
DEBUG - 2016-06-13 15:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:10:42 --> Input Class Initialized
INFO - 2016-06-13 15:10:42 --> Language Class Initialized
INFO - 2016-06-13 15:10:42 --> Loader Class Initialized
INFO - 2016-06-13 15:10:42 --> Helper loaded: form_helper
INFO - 2016-06-13 15:10:42 --> Database Driver Class Initialized
INFO - 2016-06-13 15:10:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:10:42 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:10:42 --> Email Class Initialized
INFO - 2016-06-13 15:10:42 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:10:42 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:10:42 --> Helper loaded: language_helper
INFO - 2016-06-13 15:10:42 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:10:42 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:10:42 --> Model Class Initialized
INFO - 2016-06-13 15:10:42 --> Helper loaded: date_helper
INFO - 2016-06-13 15:10:42 --> Controller Class Initialized
INFO - 2016-06-13 15:10:42 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:10:42 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:10:42 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:10:42 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:10:42 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:10:42 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:10:42 --> Model Class Initialized
INFO - 2016-06-13 15:10:42 --> Form Validation Class Initialized
INFO - 2016-06-13 15:10:42 --> Final output sent to browser
DEBUG - 2016-06-13 15:10:42 --> Total execution time: 0.0527
INFO - 2016-06-13 15:10:52 --> Config Class Initialized
INFO - 2016-06-13 15:10:52 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:10:52 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:10:52 --> Utf8 Class Initialized
INFO - 2016-06-13 15:10:52 --> URI Class Initialized
INFO - 2016-06-13 15:10:52 --> Router Class Initialized
INFO - 2016-06-13 15:10:52 --> Output Class Initialized
INFO - 2016-06-13 15:10:52 --> Security Class Initialized
DEBUG - 2016-06-13 15:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:10:52 --> Input Class Initialized
INFO - 2016-06-13 15:10:52 --> Language Class Initialized
INFO - 2016-06-13 15:10:52 --> Loader Class Initialized
INFO - 2016-06-13 15:10:52 --> Helper loaded: form_helper
INFO - 2016-06-13 15:10:52 --> Database Driver Class Initialized
INFO - 2016-06-13 15:10:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:10:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:10:52 --> Email Class Initialized
INFO - 2016-06-13 15:10:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:10:52 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:10:52 --> Helper loaded: language_helper
INFO - 2016-06-13 15:10:52 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:10:52 --> Model Class Initialized
INFO - 2016-06-13 15:10:52 --> Helper loaded: date_helper
INFO - 2016-06-13 15:10:52 --> Controller Class Initialized
INFO - 2016-06-13 15:10:52 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:10:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:10:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:10:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:10:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:10:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:10:52 --> Model Class Initialized
INFO - 2016-06-13 15:10:52 --> Form Validation Class Initialized
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:10:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:10:52 --> Final output sent to browser
DEBUG - 2016-06-13 15:10:52 --> Total execution time: 0.1444
INFO - 2016-06-13 15:10:54 --> Config Class Initialized
INFO - 2016-06-13 15:10:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:10:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:10:54 --> Utf8 Class Initialized
INFO - 2016-06-13 15:10:54 --> URI Class Initialized
INFO - 2016-06-13 15:10:54 --> Router Class Initialized
INFO - 2016-06-13 15:10:54 --> Output Class Initialized
INFO - 2016-06-13 15:10:54 --> Security Class Initialized
DEBUG - 2016-06-13 15:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:10:54 --> Input Class Initialized
INFO - 2016-06-13 15:10:54 --> Language Class Initialized
INFO - 2016-06-13 15:10:54 --> Loader Class Initialized
INFO - 2016-06-13 15:10:54 --> Helper loaded: form_helper
INFO - 2016-06-13 15:10:54 --> Database Driver Class Initialized
INFO - 2016-06-13 15:10:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:10:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:10:54 --> Email Class Initialized
INFO - 2016-06-13 15:10:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:10:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:10:54 --> Helper loaded: language_helper
INFO - 2016-06-13 15:10:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:10:54 --> Model Class Initialized
INFO - 2016-06-13 15:10:54 --> Helper loaded: date_helper
INFO - 2016-06-13 15:10:54 --> Controller Class Initialized
INFO - 2016-06-13 15:10:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:10:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:10:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:10:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:10:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:10:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:10:54 --> Model Class Initialized
INFO - 2016-06-13 15:10:54 --> Form Validation Class Initialized
INFO - 2016-06-13 15:10:54 --> Final output sent to browser
DEBUG - 2016-06-13 15:10:54 --> Total execution time: 0.0854
INFO - 2016-06-13 15:12:24 --> Config Class Initialized
INFO - 2016-06-13 15:12:24 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:12:24 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:12:24 --> Utf8 Class Initialized
INFO - 2016-06-13 15:12:24 --> URI Class Initialized
INFO - 2016-06-13 15:12:24 --> Router Class Initialized
INFO - 2016-06-13 15:12:24 --> Output Class Initialized
INFO - 2016-06-13 15:12:24 --> Security Class Initialized
DEBUG - 2016-06-13 15:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:12:24 --> Input Class Initialized
INFO - 2016-06-13 15:12:24 --> Language Class Initialized
INFO - 2016-06-13 15:12:24 --> Loader Class Initialized
INFO - 2016-06-13 15:12:24 --> Helper loaded: form_helper
INFO - 2016-06-13 15:12:24 --> Database Driver Class Initialized
INFO - 2016-06-13 15:12:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:12:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:12:24 --> Email Class Initialized
INFO - 2016-06-13 15:12:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:12:24 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:12:24 --> Helper loaded: language_helper
INFO - 2016-06-13 15:12:24 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:12:24 --> Model Class Initialized
INFO - 2016-06-13 15:12:24 --> Helper loaded: date_helper
INFO - 2016-06-13 15:12:24 --> Controller Class Initialized
INFO - 2016-06-13 15:12:24 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:12:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:12:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:12:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:12:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:12:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:12:24 --> Model Class Initialized
INFO - 2016-06-13 15:12:24 --> Form Validation Class Initialized
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:12:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
ERROR - 2016-06-13 15:12:24 --> Severity: Parsing Error --> syntax error, unexpected '}' /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php 34
INFO - 2016-06-13 15:12:37 --> Config Class Initialized
INFO - 2016-06-13 15:12:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:12:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:12:37 --> Utf8 Class Initialized
INFO - 2016-06-13 15:12:37 --> URI Class Initialized
INFO - 2016-06-13 15:12:37 --> Router Class Initialized
INFO - 2016-06-13 15:12:37 --> Output Class Initialized
INFO - 2016-06-13 15:12:37 --> Security Class Initialized
DEBUG - 2016-06-13 15:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:12:37 --> Input Class Initialized
INFO - 2016-06-13 15:12:37 --> Language Class Initialized
INFO - 2016-06-13 15:12:37 --> Loader Class Initialized
INFO - 2016-06-13 15:12:37 --> Helper loaded: form_helper
INFO - 2016-06-13 15:12:37 --> Database Driver Class Initialized
INFO - 2016-06-13 15:12:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:12:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:12:37 --> Email Class Initialized
INFO - 2016-06-13 15:12:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:12:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:12:37 --> Helper loaded: language_helper
INFO - 2016-06-13 15:12:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:12:37 --> Model Class Initialized
INFO - 2016-06-13 15:12:37 --> Helper loaded: date_helper
INFO - 2016-06-13 15:12:37 --> Controller Class Initialized
INFO - 2016-06-13 15:12:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:12:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:12:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:12:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:12:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:12:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:12:37 --> Model Class Initialized
INFO - 2016-06-13 15:12:37 --> Form Validation Class Initialized
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:12:38 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:12:38 --> Final output sent to browser
DEBUG - 2016-06-13 15:12:38 --> Total execution time: 0.1005
INFO - 2016-06-13 15:12:39 --> Config Class Initialized
INFO - 2016-06-13 15:12:39 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:12:39 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:12:39 --> Utf8 Class Initialized
INFO - 2016-06-13 15:12:39 --> URI Class Initialized
INFO - 2016-06-13 15:12:39 --> Router Class Initialized
INFO - 2016-06-13 15:12:39 --> Output Class Initialized
INFO - 2016-06-13 15:12:39 --> Security Class Initialized
DEBUG - 2016-06-13 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:12:39 --> Input Class Initialized
INFO - 2016-06-13 15:12:39 --> Language Class Initialized
INFO - 2016-06-13 15:12:39 --> Loader Class Initialized
INFO - 2016-06-13 15:12:39 --> Helper loaded: form_helper
INFO - 2016-06-13 15:12:39 --> Database Driver Class Initialized
INFO - 2016-06-13 15:12:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:12:39 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:12:39 --> Email Class Initialized
INFO - 2016-06-13 15:12:39 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:12:39 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:12:39 --> Helper loaded: language_helper
INFO - 2016-06-13 15:12:39 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:12:39 --> Model Class Initialized
INFO - 2016-06-13 15:12:39 --> Helper loaded: date_helper
INFO - 2016-06-13 15:12:39 --> Controller Class Initialized
INFO - 2016-06-13 15:12:39 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:12:39 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:12:39 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:12:39 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:12:39 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:12:39 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:12:39 --> Model Class Initialized
INFO - 2016-06-13 15:12:39 --> Form Validation Class Initialized
INFO - 2016-06-13 15:12:39 --> Final output sent to browser
DEBUG - 2016-06-13 15:12:39 --> Total execution time: 0.0429
INFO - 2016-06-13 15:12:49 --> Config Class Initialized
INFO - 2016-06-13 15:12:49 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:12:49 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:12:49 --> Utf8 Class Initialized
INFO - 2016-06-13 15:12:49 --> URI Class Initialized
INFO - 2016-06-13 15:12:49 --> Router Class Initialized
INFO - 2016-06-13 15:12:49 --> Output Class Initialized
INFO - 2016-06-13 15:12:49 --> Security Class Initialized
DEBUG - 2016-06-13 15:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:12:49 --> Input Class Initialized
INFO - 2016-06-13 15:12:49 --> Language Class Initialized
INFO - 2016-06-13 15:12:49 --> Loader Class Initialized
INFO - 2016-06-13 15:12:49 --> Helper loaded: form_helper
INFO - 2016-06-13 15:12:49 --> Database Driver Class Initialized
INFO - 2016-06-13 15:12:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:12:49 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:12:49 --> Email Class Initialized
INFO - 2016-06-13 15:12:49 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:12:49 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:12:49 --> Helper loaded: language_helper
INFO - 2016-06-13 15:12:49 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:12:49 --> Model Class Initialized
INFO - 2016-06-13 15:12:49 --> Helper loaded: date_helper
INFO - 2016-06-13 15:12:49 --> Controller Class Initialized
INFO - 2016-06-13 15:12:49 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:12:49 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:12:49 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:12:49 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:12:49 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:12:49 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:12:49 --> Model Class Initialized
INFO - 2016-06-13 15:12:49 --> Form Validation Class Initialized
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:12:49 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:12:49 --> Final output sent to browser
DEBUG - 2016-06-13 15:12:49 --> Total execution time: 0.0609
INFO - 2016-06-13 15:12:50 --> Config Class Initialized
INFO - 2016-06-13 15:12:50 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:12:50 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:12:50 --> Utf8 Class Initialized
INFO - 2016-06-13 15:12:50 --> URI Class Initialized
INFO - 2016-06-13 15:12:50 --> Router Class Initialized
INFO - 2016-06-13 15:12:50 --> Output Class Initialized
INFO - 2016-06-13 15:12:50 --> Security Class Initialized
DEBUG - 2016-06-13 15:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:12:50 --> Input Class Initialized
INFO - 2016-06-13 15:12:50 --> Language Class Initialized
INFO - 2016-06-13 15:12:50 --> Loader Class Initialized
INFO - 2016-06-13 15:12:50 --> Helper loaded: form_helper
INFO - 2016-06-13 15:12:50 --> Database Driver Class Initialized
INFO - 2016-06-13 15:12:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:12:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:12:50 --> Email Class Initialized
INFO - 2016-06-13 15:12:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:12:50 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:12:50 --> Helper loaded: language_helper
INFO - 2016-06-13 15:12:50 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:12:50 --> Model Class Initialized
INFO - 2016-06-13 15:12:50 --> Helper loaded: date_helper
INFO - 2016-06-13 15:12:50 --> Controller Class Initialized
INFO - 2016-06-13 15:12:50 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:12:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:12:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:12:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:12:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:12:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:12:50 --> Model Class Initialized
INFO - 2016-06-13 15:12:50 --> Form Validation Class Initialized
INFO - 2016-06-13 15:12:50 --> Final output sent to browser
DEBUG - 2016-06-13 15:12:50 --> Total execution time: 0.0631
INFO - 2016-06-13 15:13:03 --> Config Class Initialized
INFO - 2016-06-13 15:13:03 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:13:03 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:13:03 --> Utf8 Class Initialized
INFO - 2016-06-13 15:13:03 --> URI Class Initialized
INFO - 2016-06-13 15:13:03 --> Router Class Initialized
INFO - 2016-06-13 15:13:03 --> Output Class Initialized
INFO - 2016-06-13 15:13:03 --> Security Class Initialized
DEBUG - 2016-06-13 15:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:13:03 --> Input Class Initialized
INFO - 2016-06-13 15:13:03 --> Language Class Initialized
INFO - 2016-06-13 15:13:03 --> Loader Class Initialized
INFO - 2016-06-13 15:13:03 --> Helper loaded: form_helper
INFO - 2016-06-13 15:13:03 --> Database Driver Class Initialized
INFO - 2016-06-13 15:13:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:13:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:13:03 --> Email Class Initialized
INFO - 2016-06-13 15:13:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:13:03 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:13:03 --> Helper loaded: language_helper
INFO - 2016-06-13 15:13:03 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:13:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:13:03 --> Model Class Initialized
INFO - 2016-06-13 15:13:03 --> Helper loaded: date_helper
INFO - 2016-06-13 15:13:03 --> Controller Class Initialized
INFO - 2016-06-13 15:13:03 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:13:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:13:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:13:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:13:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:13:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:13:03 --> Model Class Initialized
INFO - 2016-06-13 15:13:03 --> Form Validation Class Initialized
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:13:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:13:03 --> Final output sent to browser
DEBUG - 2016-06-13 15:13:03 --> Total execution time: 0.1506
INFO - 2016-06-13 15:13:05 --> Config Class Initialized
INFO - 2016-06-13 15:13:05 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:13:05 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:13:05 --> Utf8 Class Initialized
INFO - 2016-06-13 15:13:05 --> URI Class Initialized
INFO - 2016-06-13 15:13:05 --> Router Class Initialized
INFO - 2016-06-13 15:13:05 --> Output Class Initialized
INFO - 2016-06-13 15:13:05 --> Security Class Initialized
DEBUG - 2016-06-13 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:13:05 --> Input Class Initialized
INFO - 2016-06-13 15:13:05 --> Language Class Initialized
INFO - 2016-06-13 15:13:05 --> Loader Class Initialized
INFO - 2016-06-13 15:13:05 --> Helper loaded: form_helper
INFO - 2016-06-13 15:13:05 --> Database Driver Class Initialized
INFO - 2016-06-13 15:13:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:13:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:13:05 --> Email Class Initialized
INFO - 2016-06-13 15:13:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:13:05 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:13:05 --> Helper loaded: language_helper
INFO - 2016-06-13 15:13:05 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:13:05 --> Model Class Initialized
INFO - 2016-06-13 15:13:05 --> Helper loaded: date_helper
INFO - 2016-06-13 15:13:05 --> Controller Class Initialized
INFO - 2016-06-13 15:13:05 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:13:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:13:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:13:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:13:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:13:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:13:05 --> Model Class Initialized
INFO - 2016-06-13 15:13:05 --> Form Validation Class Initialized
INFO - 2016-06-13 15:13:05 --> Final output sent to browser
DEBUG - 2016-06-13 15:13:05 --> Total execution time: 0.1111
INFO - 2016-06-13 15:14:17 --> Config Class Initialized
INFO - 2016-06-13 15:14:17 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:14:17 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:14:17 --> Utf8 Class Initialized
INFO - 2016-06-13 15:14:17 --> URI Class Initialized
INFO - 2016-06-13 15:14:17 --> Router Class Initialized
INFO - 2016-06-13 15:14:17 --> Output Class Initialized
INFO - 2016-06-13 15:14:17 --> Security Class Initialized
DEBUG - 2016-06-13 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:14:17 --> Input Class Initialized
INFO - 2016-06-13 15:14:17 --> Language Class Initialized
INFO - 2016-06-13 15:14:17 --> Loader Class Initialized
INFO - 2016-06-13 15:14:17 --> Helper loaded: form_helper
INFO - 2016-06-13 15:14:17 --> Database Driver Class Initialized
INFO - 2016-06-13 15:14:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:14:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:14:17 --> Email Class Initialized
INFO - 2016-06-13 15:14:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:14:17 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:14:17 --> Helper loaded: language_helper
INFO - 2016-06-13 15:14:17 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:14:17 --> Model Class Initialized
INFO - 2016-06-13 15:14:17 --> Helper loaded: date_helper
INFO - 2016-06-13 15:14:17 --> Controller Class Initialized
INFO - 2016-06-13 15:14:17 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:14:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:14:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:14:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:14:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:14:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:14:17 --> Model Class Initialized
INFO - 2016-06-13 15:14:17 --> Form Validation Class Initialized
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:14:17 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:14:17 --> Final output sent to browser
DEBUG - 2016-06-13 15:14:17 --> Total execution time: 0.0838
INFO - 2016-06-13 15:14:18 --> Config Class Initialized
INFO - 2016-06-13 15:14:18 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:14:18 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:14:18 --> Utf8 Class Initialized
INFO - 2016-06-13 15:14:18 --> URI Class Initialized
INFO - 2016-06-13 15:14:18 --> Router Class Initialized
INFO - 2016-06-13 15:14:18 --> Output Class Initialized
INFO - 2016-06-13 15:14:18 --> Security Class Initialized
DEBUG - 2016-06-13 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:14:18 --> Input Class Initialized
INFO - 2016-06-13 15:14:18 --> Language Class Initialized
INFO - 2016-06-13 15:14:18 --> Loader Class Initialized
INFO - 2016-06-13 15:14:18 --> Helper loaded: form_helper
INFO - 2016-06-13 15:14:18 --> Database Driver Class Initialized
INFO - 2016-06-13 15:14:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:14:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:14:18 --> Email Class Initialized
INFO - 2016-06-13 15:14:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:14:18 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:14:18 --> Helper loaded: language_helper
INFO - 2016-06-13 15:14:18 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:14:18 --> Model Class Initialized
INFO - 2016-06-13 15:14:18 --> Helper loaded: date_helper
INFO - 2016-06-13 15:14:18 --> Controller Class Initialized
INFO - 2016-06-13 15:14:18 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:14:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:14:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:14:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:14:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:14:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:14:18 --> Model Class Initialized
INFO - 2016-06-13 15:14:18 --> Form Validation Class Initialized
INFO - 2016-06-13 15:14:18 --> Final output sent to browser
DEBUG - 2016-06-13 15:14:18 --> Total execution time: 0.0530
INFO - 2016-06-13 15:16:03 --> Config Class Initialized
INFO - 2016-06-13 15:16:03 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:16:03 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:16:03 --> Utf8 Class Initialized
INFO - 2016-06-13 15:16:03 --> URI Class Initialized
INFO - 2016-06-13 15:16:03 --> Router Class Initialized
INFO - 2016-06-13 15:16:03 --> Output Class Initialized
INFO - 2016-06-13 15:16:03 --> Security Class Initialized
DEBUG - 2016-06-13 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:16:03 --> Input Class Initialized
INFO - 2016-06-13 15:16:03 --> Language Class Initialized
INFO - 2016-06-13 15:16:03 --> Loader Class Initialized
INFO - 2016-06-13 15:16:03 --> Helper loaded: form_helper
INFO - 2016-06-13 15:16:03 --> Database Driver Class Initialized
INFO - 2016-06-13 15:16:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:16:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:16:03 --> Email Class Initialized
INFO - 2016-06-13 15:16:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:16:03 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:16:03 --> Helper loaded: language_helper
INFO - 2016-06-13 15:16:03 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:16:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:16:03 --> Model Class Initialized
INFO - 2016-06-13 15:16:03 --> Helper loaded: date_helper
INFO - 2016-06-13 15:16:03 --> Controller Class Initialized
INFO - 2016-06-13 15:16:03 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:16:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:16:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:16:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:16:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:16:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:16:03 --> Model Class Initialized
INFO - 2016-06-13 15:16:03 --> Form Validation Class Initialized
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:16:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:16:03 --> Final output sent to browser
DEBUG - 2016-06-13 15:16:03 --> Total execution time: 0.0398
INFO - 2016-06-13 15:16:04 --> Config Class Initialized
INFO - 2016-06-13 15:16:04 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:16:04 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:16:04 --> Utf8 Class Initialized
INFO - 2016-06-13 15:16:04 --> URI Class Initialized
INFO - 2016-06-13 15:16:04 --> Router Class Initialized
INFO - 2016-06-13 15:16:04 --> Output Class Initialized
INFO - 2016-06-13 15:16:04 --> Security Class Initialized
DEBUG - 2016-06-13 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:16:04 --> Input Class Initialized
INFO - 2016-06-13 15:16:04 --> Language Class Initialized
INFO - 2016-06-13 15:16:04 --> Loader Class Initialized
INFO - 2016-06-13 15:16:04 --> Helper loaded: form_helper
INFO - 2016-06-13 15:16:04 --> Database Driver Class Initialized
INFO - 2016-06-13 15:16:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:16:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:16:04 --> Email Class Initialized
INFO - 2016-06-13 15:16:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:16:04 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:16:04 --> Helper loaded: language_helper
INFO - 2016-06-13 15:16:04 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:16:04 --> Model Class Initialized
INFO - 2016-06-13 15:16:04 --> Helper loaded: date_helper
INFO - 2016-06-13 15:16:04 --> Controller Class Initialized
INFO - 2016-06-13 15:16:04 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:16:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:16:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:16:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:16:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:16:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:16:04 --> Model Class Initialized
INFO - 2016-06-13 15:16:04 --> Form Validation Class Initialized
INFO - 2016-06-13 15:16:04 --> Final output sent to browser
DEBUG - 2016-06-13 15:16:04 --> Total execution time: 0.0196
INFO - 2016-06-13 15:16:24 --> Config Class Initialized
INFO - 2016-06-13 15:16:24 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:16:24 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:16:24 --> Utf8 Class Initialized
INFO - 2016-06-13 15:16:24 --> URI Class Initialized
INFO - 2016-06-13 15:16:24 --> Router Class Initialized
INFO - 2016-06-13 15:16:24 --> Output Class Initialized
INFO - 2016-06-13 15:16:24 --> Security Class Initialized
DEBUG - 2016-06-13 15:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:16:24 --> Input Class Initialized
INFO - 2016-06-13 15:16:24 --> Language Class Initialized
INFO - 2016-06-13 15:16:24 --> Loader Class Initialized
INFO - 2016-06-13 15:16:24 --> Helper loaded: form_helper
INFO - 2016-06-13 15:16:24 --> Database Driver Class Initialized
INFO - 2016-06-13 15:16:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:16:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:16:24 --> Email Class Initialized
INFO - 2016-06-13 15:16:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:16:24 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:16:24 --> Helper loaded: language_helper
INFO - 2016-06-13 15:16:24 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:16:24 --> Model Class Initialized
INFO - 2016-06-13 15:16:24 --> Helper loaded: date_helper
INFO - 2016-06-13 15:16:24 --> Controller Class Initialized
INFO - 2016-06-13 15:16:24 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:16:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:16:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:16:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:16:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:16:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:16:24 --> Model Class Initialized
INFO - 2016-06-13 15:16:24 --> Form Validation Class Initialized
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:16:24 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:16:24 --> Final output sent to browser
DEBUG - 2016-06-13 15:16:24 --> Total execution time: 0.1292
INFO - 2016-06-13 15:16:25 --> Config Class Initialized
INFO - 2016-06-13 15:16:25 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:16:25 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:16:25 --> Utf8 Class Initialized
INFO - 2016-06-13 15:16:25 --> URI Class Initialized
INFO - 2016-06-13 15:16:25 --> Router Class Initialized
INFO - 2016-06-13 15:16:25 --> Output Class Initialized
INFO - 2016-06-13 15:16:25 --> Security Class Initialized
DEBUG - 2016-06-13 15:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:16:25 --> Input Class Initialized
INFO - 2016-06-13 15:16:25 --> Language Class Initialized
INFO - 2016-06-13 15:16:25 --> Loader Class Initialized
INFO - 2016-06-13 15:16:25 --> Helper loaded: form_helper
INFO - 2016-06-13 15:16:25 --> Database Driver Class Initialized
INFO - 2016-06-13 15:16:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:16:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:16:25 --> Email Class Initialized
INFO - 2016-06-13 15:16:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:16:25 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:16:25 --> Helper loaded: language_helper
INFO - 2016-06-13 15:16:25 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:16:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:16:25 --> Model Class Initialized
INFO - 2016-06-13 15:16:25 --> Helper loaded: date_helper
INFO - 2016-06-13 15:16:25 --> Controller Class Initialized
INFO - 2016-06-13 15:16:25 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:16:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:16:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:16:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:16:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:16:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:16:25 --> Model Class Initialized
INFO - 2016-06-13 15:16:25 --> Form Validation Class Initialized
INFO - 2016-06-13 15:16:25 --> Final output sent to browser
DEBUG - 2016-06-13 15:16:25 --> Total execution time: 0.0304
INFO - 2016-06-13 15:16:35 --> Config Class Initialized
INFO - 2016-06-13 15:16:35 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:16:35 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:16:35 --> Utf8 Class Initialized
INFO - 2016-06-13 15:16:35 --> URI Class Initialized
INFO - 2016-06-13 15:16:35 --> Router Class Initialized
INFO - 2016-06-13 15:16:35 --> Output Class Initialized
INFO - 2016-06-13 15:16:35 --> Security Class Initialized
DEBUG - 2016-06-13 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:16:35 --> Input Class Initialized
INFO - 2016-06-13 15:16:35 --> Language Class Initialized
INFO - 2016-06-13 15:16:35 --> Loader Class Initialized
INFO - 2016-06-13 15:16:35 --> Helper loaded: form_helper
INFO - 2016-06-13 15:16:35 --> Database Driver Class Initialized
INFO - 2016-06-13 15:16:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:16:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:16:35 --> Email Class Initialized
INFO - 2016-06-13 15:16:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:16:35 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:16:35 --> Helper loaded: language_helper
INFO - 2016-06-13 15:16:35 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:16:35 --> Model Class Initialized
INFO - 2016-06-13 15:16:35 --> Helper loaded: date_helper
INFO - 2016-06-13 15:16:35 --> Controller Class Initialized
INFO - 2016-06-13 15:16:35 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:16:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:16:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:16:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:16:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:16:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:16:35 --> Model Class Initialized
INFO - 2016-06-13 15:16:35 --> Form Validation Class Initialized
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:16:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:16:35 --> Final output sent to browser
DEBUG - 2016-06-13 15:16:35 --> Total execution time: 0.0894
INFO - 2016-06-13 15:16:37 --> Config Class Initialized
INFO - 2016-06-13 15:16:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:16:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:16:37 --> Utf8 Class Initialized
INFO - 2016-06-13 15:16:37 --> URI Class Initialized
INFO - 2016-06-13 15:16:37 --> Router Class Initialized
INFO - 2016-06-13 15:16:37 --> Output Class Initialized
INFO - 2016-06-13 15:16:37 --> Security Class Initialized
DEBUG - 2016-06-13 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:16:37 --> Input Class Initialized
INFO - 2016-06-13 15:16:37 --> Language Class Initialized
INFO - 2016-06-13 15:16:37 --> Loader Class Initialized
INFO - 2016-06-13 15:16:37 --> Helper loaded: form_helper
INFO - 2016-06-13 15:16:37 --> Database Driver Class Initialized
INFO - 2016-06-13 15:16:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:16:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:16:37 --> Email Class Initialized
INFO - 2016-06-13 15:16:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:16:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:16:37 --> Helper loaded: language_helper
INFO - 2016-06-13 15:16:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:16:37 --> Model Class Initialized
INFO - 2016-06-13 15:16:37 --> Helper loaded: date_helper
INFO - 2016-06-13 15:16:37 --> Controller Class Initialized
INFO - 2016-06-13 15:16:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:16:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:16:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:16:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:16:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:16:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:16:37 --> Model Class Initialized
INFO - 2016-06-13 15:16:37 --> Form Validation Class Initialized
INFO - 2016-06-13 15:16:37 --> Final output sent to browser
DEBUG - 2016-06-13 15:16:37 --> Total execution time: 0.0999
INFO - 2016-06-13 15:16:51 --> Config Class Initialized
INFO - 2016-06-13 15:16:51 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:16:51 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:16:51 --> Utf8 Class Initialized
INFO - 2016-06-13 15:16:51 --> URI Class Initialized
INFO - 2016-06-13 15:16:51 --> Router Class Initialized
INFO - 2016-06-13 15:16:51 --> Output Class Initialized
INFO - 2016-06-13 15:16:51 --> Security Class Initialized
DEBUG - 2016-06-13 15:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:16:51 --> Input Class Initialized
INFO - 2016-06-13 15:16:51 --> Language Class Initialized
INFO - 2016-06-13 15:16:51 --> Loader Class Initialized
INFO - 2016-06-13 15:16:51 --> Helper loaded: form_helper
INFO - 2016-06-13 15:16:51 --> Database Driver Class Initialized
INFO - 2016-06-13 15:16:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:16:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:16:51 --> Email Class Initialized
INFO - 2016-06-13 15:16:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:16:51 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:16:51 --> Helper loaded: language_helper
INFO - 2016-06-13 15:16:51 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:16:51 --> Model Class Initialized
INFO - 2016-06-13 15:16:51 --> Helper loaded: date_helper
INFO - 2016-06-13 15:16:51 --> Controller Class Initialized
INFO - 2016-06-13 15:16:51 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:16:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:16:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:16:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:16:51 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:16:51 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:16:51 --> Model Class Initialized
INFO - 2016-06-13 15:16:51 --> Form Validation Class Initialized
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:16:51 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:16:51 --> Final output sent to browser
DEBUG - 2016-06-13 15:16:51 --> Total execution time: 0.1432
INFO - 2016-06-13 15:17:04 --> Config Class Initialized
INFO - 2016-06-13 15:17:04 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:17:04 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:17:04 --> Utf8 Class Initialized
INFO - 2016-06-13 15:17:04 --> URI Class Initialized
INFO - 2016-06-13 15:17:04 --> Router Class Initialized
INFO - 2016-06-13 15:17:04 --> Output Class Initialized
INFO - 2016-06-13 15:17:04 --> Security Class Initialized
DEBUG - 2016-06-13 15:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:17:04 --> Input Class Initialized
INFO - 2016-06-13 15:17:04 --> Language Class Initialized
INFO - 2016-06-13 15:17:04 --> Loader Class Initialized
INFO - 2016-06-13 15:17:04 --> Helper loaded: form_helper
INFO - 2016-06-13 15:17:04 --> Database Driver Class Initialized
INFO - 2016-06-13 15:17:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:17:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:17:04 --> Email Class Initialized
INFO - 2016-06-13 15:17:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:17:04 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:17:04 --> Helper loaded: language_helper
INFO - 2016-06-13 15:17:04 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:17:04 --> Model Class Initialized
INFO - 2016-06-13 15:17:04 --> Helper loaded: date_helper
INFO - 2016-06-13 15:17:04 --> Controller Class Initialized
INFO - 2016-06-13 15:17:04 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:17:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:17:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:17:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:17:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:17:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:17:04 --> Model Class Initialized
INFO - 2016-06-13 15:17:04 --> Form Validation Class Initialized
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:17:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:17:04 --> Final output sent to browser
DEBUG - 2016-06-13 15:17:04 --> Total execution time: 0.1188
INFO - 2016-06-13 15:17:06 --> Config Class Initialized
INFO - 2016-06-13 15:17:06 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:17:06 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:17:06 --> Utf8 Class Initialized
INFO - 2016-06-13 15:17:06 --> URI Class Initialized
INFO - 2016-06-13 15:17:06 --> Router Class Initialized
INFO - 2016-06-13 15:17:06 --> Output Class Initialized
INFO - 2016-06-13 15:17:06 --> Security Class Initialized
DEBUG - 2016-06-13 15:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:17:06 --> Input Class Initialized
INFO - 2016-06-13 15:17:06 --> Language Class Initialized
INFO - 2016-06-13 15:17:06 --> Loader Class Initialized
INFO - 2016-06-13 15:17:06 --> Helper loaded: form_helper
INFO - 2016-06-13 15:17:06 --> Database Driver Class Initialized
INFO - 2016-06-13 15:17:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:17:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:17:06 --> Email Class Initialized
INFO - 2016-06-13 15:17:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:17:06 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:17:06 --> Helper loaded: language_helper
INFO - 2016-06-13 15:17:06 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:17:06 --> Model Class Initialized
INFO - 2016-06-13 15:17:06 --> Helper loaded: date_helper
INFO - 2016-06-13 15:17:06 --> Controller Class Initialized
INFO - 2016-06-13 15:17:06 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:17:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:17:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:17:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:17:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:17:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:17:06 --> Model Class Initialized
INFO - 2016-06-13 15:17:06 --> Form Validation Class Initialized
INFO - 2016-06-13 15:17:06 --> Final output sent to browser
DEBUG - 2016-06-13 15:17:06 --> Total execution time: 0.0595
INFO - 2016-06-13 15:17:53 --> Config Class Initialized
INFO - 2016-06-13 15:17:53 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:17:53 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:17:53 --> Utf8 Class Initialized
INFO - 2016-06-13 15:17:53 --> URI Class Initialized
INFO - 2016-06-13 15:17:53 --> Router Class Initialized
INFO - 2016-06-13 15:17:53 --> Output Class Initialized
INFO - 2016-06-13 15:17:53 --> Security Class Initialized
DEBUG - 2016-06-13 15:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:17:53 --> Input Class Initialized
INFO - 2016-06-13 15:17:53 --> Language Class Initialized
INFO - 2016-06-13 15:17:53 --> Loader Class Initialized
INFO - 2016-06-13 15:17:53 --> Helper loaded: form_helper
INFO - 2016-06-13 15:17:53 --> Database Driver Class Initialized
INFO - 2016-06-13 15:17:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:17:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:17:53 --> Email Class Initialized
INFO - 2016-06-13 15:17:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:17:53 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:17:53 --> Helper loaded: language_helper
INFO - 2016-06-13 15:17:53 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:17:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:17:53 --> Model Class Initialized
INFO - 2016-06-13 15:17:53 --> Helper loaded: date_helper
INFO - 2016-06-13 15:17:53 --> Controller Class Initialized
INFO - 2016-06-13 15:17:53 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:17:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:17:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:17:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:17:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:17:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:17:53 --> Model Class Initialized
INFO - 2016-06-13 15:17:53 --> Form Validation Class Initialized
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:17:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:17:53 --> Final output sent to browser
DEBUG - 2016-06-13 15:17:53 --> Total execution time: 0.1495
INFO - 2016-06-13 15:19:08 --> Config Class Initialized
INFO - 2016-06-13 15:19:08 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:19:08 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:19:08 --> Utf8 Class Initialized
INFO - 2016-06-13 15:19:08 --> URI Class Initialized
INFO - 2016-06-13 15:19:08 --> Router Class Initialized
INFO - 2016-06-13 15:19:08 --> Output Class Initialized
INFO - 2016-06-13 15:19:08 --> Security Class Initialized
DEBUG - 2016-06-13 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:19:08 --> Input Class Initialized
INFO - 2016-06-13 15:19:08 --> Language Class Initialized
INFO - 2016-06-13 15:19:08 --> Loader Class Initialized
INFO - 2016-06-13 15:19:08 --> Helper loaded: form_helper
INFO - 2016-06-13 15:19:08 --> Database Driver Class Initialized
INFO - 2016-06-13 15:19:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:19:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:19:08 --> Email Class Initialized
INFO - 2016-06-13 15:19:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:19:08 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:19:08 --> Helper loaded: language_helper
INFO - 2016-06-13 15:19:08 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:19:08 --> Model Class Initialized
INFO - 2016-06-13 15:19:08 --> Helper loaded: date_helper
INFO - 2016-06-13 15:19:08 --> Controller Class Initialized
INFO - 2016-06-13 15:19:08 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:19:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:19:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:19:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:19:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:19:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:19:08 --> Model Class Initialized
INFO - 2016-06-13 15:19:08 --> Form Validation Class Initialized
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:19:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:19:08 --> Final output sent to browser
DEBUG - 2016-06-13 15:19:08 --> Total execution time: 0.0837
INFO - 2016-06-13 15:19:10 --> Config Class Initialized
INFO - 2016-06-13 15:19:10 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:19:10 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:19:10 --> Utf8 Class Initialized
INFO - 2016-06-13 15:19:10 --> URI Class Initialized
INFO - 2016-06-13 15:19:10 --> Router Class Initialized
INFO - 2016-06-13 15:19:10 --> Output Class Initialized
INFO - 2016-06-13 15:19:10 --> Security Class Initialized
DEBUG - 2016-06-13 15:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:19:10 --> Input Class Initialized
INFO - 2016-06-13 15:19:10 --> Language Class Initialized
INFO - 2016-06-13 15:19:10 --> Loader Class Initialized
INFO - 2016-06-13 15:19:10 --> Helper loaded: form_helper
INFO - 2016-06-13 15:19:10 --> Database Driver Class Initialized
INFO - 2016-06-13 15:19:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:19:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:19:10 --> Email Class Initialized
INFO - 2016-06-13 15:19:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:19:10 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:19:10 --> Helper loaded: language_helper
INFO - 2016-06-13 15:19:10 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:19:10 --> Model Class Initialized
INFO - 2016-06-13 15:19:10 --> Helper loaded: date_helper
INFO - 2016-06-13 15:19:10 --> Controller Class Initialized
INFO - 2016-06-13 15:19:10 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:19:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:19:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:19:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:19:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:19:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:19:10 --> Model Class Initialized
INFO - 2016-06-13 15:19:10 --> Form Validation Class Initialized
INFO - 2016-06-13 15:19:10 --> Final output sent to browser
DEBUG - 2016-06-13 15:19:10 --> Total execution time: 0.0558
INFO - 2016-06-13 15:20:06 --> Config Class Initialized
INFO - 2016-06-13 15:20:06 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:20:06 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:20:06 --> Utf8 Class Initialized
INFO - 2016-06-13 15:20:06 --> URI Class Initialized
INFO - 2016-06-13 15:20:06 --> Router Class Initialized
INFO - 2016-06-13 15:20:06 --> Output Class Initialized
INFO - 2016-06-13 15:20:06 --> Security Class Initialized
DEBUG - 2016-06-13 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:20:06 --> Input Class Initialized
INFO - 2016-06-13 15:20:06 --> Language Class Initialized
INFO - 2016-06-13 15:20:06 --> Loader Class Initialized
INFO - 2016-06-13 15:20:06 --> Helper loaded: form_helper
INFO - 2016-06-13 15:20:06 --> Database Driver Class Initialized
INFO - 2016-06-13 15:20:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:20:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:20:06 --> Email Class Initialized
INFO - 2016-06-13 15:20:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:20:06 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:20:06 --> Helper loaded: language_helper
INFO - 2016-06-13 15:20:06 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:20:06 --> Model Class Initialized
INFO - 2016-06-13 15:20:06 --> Helper loaded: date_helper
INFO - 2016-06-13 15:20:06 --> Controller Class Initialized
INFO - 2016-06-13 15:20:06 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:20:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:20:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:20:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:20:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:20:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:20:06 --> Model Class Initialized
INFO - 2016-06-13 15:20:06 --> Form Validation Class Initialized
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:20:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:20:06 --> Final output sent to browser
DEBUG - 2016-06-13 15:20:06 --> Total execution time: 0.0988
INFO - 2016-06-13 15:20:07 --> Config Class Initialized
INFO - 2016-06-13 15:20:07 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:20:07 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:20:07 --> Utf8 Class Initialized
INFO - 2016-06-13 15:20:07 --> URI Class Initialized
INFO - 2016-06-13 15:20:07 --> Router Class Initialized
INFO - 2016-06-13 15:20:07 --> Output Class Initialized
INFO - 2016-06-13 15:20:07 --> Security Class Initialized
DEBUG - 2016-06-13 15:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:20:07 --> Input Class Initialized
INFO - 2016-06-13 15:20:07 --> Language Class Initialized
INFO - 2016-06-13 15:20:07 --> Loader Class Initialized
INFO - 2016-06-13 15:20:07 --> Helper loaded: form_helper
INFO - 2016-06-13 15:20:07 --> Database Driver Class Initialized
INFO - 2016-06-13 15:20:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:20:07 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:20:07 --> Email Class Initialized
INFO - 2016-06-13 15:20:07 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:20:07 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:20:07 --> Helper loaded: language_helper
INFO - 2016-06-13 15:20:07 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:20:07 --> Model Class Initialized
INFO - 2016-06-13 15:20:07 --> Helper loaded: date_helper
INFO - 2016-06-13 15:20:07 --> Controller Class Initialized
INFO - 2016-06-13 15:20:07 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:20:07 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:20:07 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:20:07 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:20:07 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:20:07 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:20:07 --> Model Class Initialized
INFO - 2016-06-13 15:20:07 --> Form Validation Class Initialized
INFO - 2016-06-13 15:20:07 --> Final output sent to browser
DEBUG - 2016-06-13 15:20:07 --> Total execution time: 0.0188
INFO - 2016-06-13 15:20:22 --> Config Class Initialized
INFO - 2016-06-13 15:20:22 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:20:22 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:20:22 --> Utf8 Class Initialized
INFO - 2016-06-13 15:20:22 --> URI Class Initialized
INFO - 2016-06-13 15:20:22 --> Router Class Initialized
INFO - 2016-06-13 15:20:22 --> Output Class Initialized
INFO - 2016-06-13 15:20:22 --> Security Class Initialized
DEBUG - 2016-06-13 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:20:22 --> Input Class Initialized
INFO - 2016-06-13 15:20:22 --> Language Class Initialized
INFO - 2016-06-13 15:20:22 --> Loader Class Initialized
INFO - 2016-06-13 15:20:22 --> Helper loaded: form_helper
INFO - 2016-06-13 15:20:22 --> Database Driver Class Initialized
INFO - 2016-06-13 15:20:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:20:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:20:22 --> Email Class Initialized
INFO - 2016-06-13 15:20:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:20:22 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:20:22 --> Helper loaded: language_helper
INFO - 2016-06-13 15:20:22 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:20:22 --> Model Class Initialized
INFO - 2016-06-13 15:20:22 --> Helper loaded: date_helper
INFO - 2016-06-13 15:20:22 --> Controller Class Initialized
INFO - 2016-06-13 15:20:22 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:20:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:20:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:20:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:20:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:20:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:20:22 --> Model Class Initialized
INFO - 2016-06-13 15:20:22 --> Form Validation Class Initialized
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:20:22 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:20:22 --> Final output sent to browser
DEBUG - 2016-06-13 15:20:22 --> Total execution time: 0.1012
INFO - 2016-06-13 15:20:23 --> Config Class Initialized
INFO - 2016-06-13 15:20:23 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:20:23 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:20:23 --> Utf8 Class Initialized
INFO - 2016-06-13 15:20:23 --> URI Class Initialized
INFO - 2016-06-13 15:20:23 --> Router Class Initialized
INFO - 2016-06-13 15:20:23 --> Output Class Initialized
INFO - 2016-06-13 15:20:23 --> Security Class Initialized
DEBUG - 2016-06-13 15:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:20:23 --> Input Class Initialized
INFO - 2016-06-13 15:20:23 --> Language Class Initialized
INFO - 2016-06-13 15:20:23 --> Loader Class Initialized
INFO - 2016-06-13 15:20:23 --> Helper loaded: form_helper
INFO - 2016-06-13 15:20:23 --> Database Driver Class Initialized
INFO - 2016-06-13 15:20:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:20:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:20:23 --> Email Class Initialized
INFO - 2016-06-13 15:20:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:20:23 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:20:23 --> Helper loaded: language_helper
INFO - 2016-06-13 15:20:23 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:20:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:20:23 --> Model Class Initialized
INFO - 2016-06-13 15:20:23 --> Helper loaded: date_helper
INFO - 2016-06-13 15:20:23 --> Controller Class Initialized
INFO - 2016-06-13 15:20:23 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:20:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:20:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:20:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:20:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:20:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:20:23 --> Model Class Initialized
INFO - 2016-06-13 15:20:23 --> Form Validation Class Initialized
INFO - 2016-06-13 15:20:23 --> Final output sent to browser
DEBUG - 2016-06-13 15:20:23 --> Total execution time: 0.0641
INFO - 2016-06-13 15:20:33 --> Config Class Initialized
INFO - 2016-06-13 15:20:33 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:20:33 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:20:33 --> Utf8 Class Initialized
INFO - 2016-06-13 15:20:33 --> URI Class Initialized
INFO - 2016-06-13 15:20:33 --> Router Class Initialized
INFO - 2016-06-13 15:20:33 --> Output Class Initialized
INFO - 2016-06-13 15:20:33 --> Security Class Initialized
DEBUG - 2016-06-13 15:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:20:33 --> Input Class Initialized
INFO - 2016-06-13 15:20:33 --> Language Class Initialized
INFO - 2016-06-13 15:20:33 --> Loader Class Initialized
INFO - 2016-06-13 15:20:33 --> Helper loaded: form_helper
INFO - 2016-06-13 15:20:33 --> Database Driver Class Initialized
INFO - 2016-06-13 15:20:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:20:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:20:33 --> Email Class Initialized
INFO - 2016-06-13 15:20:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:20:33 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:20:33 --> Helper loaded: language_helper
INFO - 2016-06-13 15:20:33 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:20:33 --> Model Class Initialized
INFO - 2016-06-13 15:20:33 --> Helper loaded: date_helper
INFO - 2016-06-13 15:20:33 --> Controller Class Initialized
INFO - 2016-06-13 15:20:33 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:20:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:20:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:20:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:20:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:20:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:20:33 --> Model Class Initialized
INFO - 2016-06-13 15:20:33 --> Form Validation Class Initialized
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:20:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:20:33 --> Final output sent to browser
DEBUG - 2016-06-13 15:20:33 --> Total execution time: 0.1401
INFO - 2016-06-13 15:20:35 --> Config Class Initialized
INFO - 2016-06-13 15:20:35 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:20:35 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:20:35 --> Utf8 Class Initialized
INFO - 2016-06-13 15:20:35 --> URI Class Initialized
INFO - 2016-06-13 15:20:35 --> Router Class Initialized
INFO - 2016-06-13 15:20:35 --> Output Class Initialized
INFO - 2016-06-13 15:20:35 --> Security Class Initialized
DEBUG - 2016-06-13 15:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:20:35 --> Input Class Initialized
INFO - 2016-06-13 15:20:35 --> Language Class Initialized
INFO - 2016-06-13 15:20:35 --> Loader Class Initialized
INFO - 2016-06-13 15:20:35 --> Helper loaded: form_helper
INFO - 2016-06-13 15:20:35 --> Database Driver Class Initialized
INFO - 2016-06-13 15:20:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:20:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:20:35 --> Email Class Initialized
INFO - 2016-06-13 15:20:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:20:35 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:20:35 --> Helper loaded: language_helper
INFO - 2016-06-13 15:20:35 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:20:35 --> Model Class Initialized
INFO - 2016-06-13 15:20:35 --> Helper loaded: date_helper
INFO - 2016-06-13 15:20:35 --> Controller Class Initialized
INFO - 2016-06-13 15:20:35 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:20:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:20:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:20:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:20:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:20:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:20:35 --> Model Class Initialized
INFO - 2016-06-13 15:20:35 --> Form Validation Class Initialized
INFO - 2016-06-13 15:20:35 --> Final output sent to browser
DEBUG - 2016-06-13 15:20:35 --> Total execution time: 0.0892
INFO - 2016-06-13 15:21:26 --> Config Class Initialized
INFO - 2016-06-13 15:21:26 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:21:26 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:21:26 --> Utf8 Class Initialized
INFO - 2016-06-13 15:21:26 --> URI Class Initialized
INFO - 2016-06-13 15:21:26 --> Router Class Initialized
INFO - 2016-06-13 15:21:26 --> Output Class Initialized
INFO - 2016-06-13 15:21:26 --> Security Class Initialized
DEBUG - 2016-06-13 15:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:21:26 --> Input Class Initialized
INFO - 2016-06-13 15:21:26 --> Language Class Initialized
INFO - 2016-06-13 15:21:26 --> Loader Class Initialized
INFO - 2016-06-13 15:21:26 --> Helper loaded: form_helper
INFO - 2016-06-13 15:21:26 --> Database Driver Class Initialized
INFO - 2016-06-13 15:21:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:21:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:21:26 --> Email Class Initialized
INFO - 2016-06-13 15:21:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:21:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:21:26 --> Helper loaded: language_helper
INFO - 2016-06-13 15:21:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:21:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:21:26 --> Model Class Initialized
INFO - 2016-06-13 15:21:26 --> Helper loaded: date_helper
INFO - 2016-06-13 15:21:26 --> Controller Class Initialized
INFO - 2016-06-13 15:21:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:21:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:21:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:21:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:21:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:21:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:21:26 --> Model Class Initialized
INFO - 2016-06-13 15:21:26 --> Form Validation Class Initialized
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:21:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:21:26 --> Final output sent to browser
DEBUG - 2016-06-13 15:21:26 --> Total execution time: 0.1472
INFO - 2016-06-13 15:21:27 --> Config Class Initialized
INFO - 2016-06-13 15:21:27 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:21:27 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:21:27 --> Utf8 Class Initialized
INFO - 2016-06-13 15:21:27 --> URI Class Initialized
INFO - 2016-06-13 15:21:27 --> Router Class Initialized
INFO - 2016-06-13 15:21:27 --> Output Class Initialized
INFO - 2016-06-13 15:21:27 --> Security Class Initialized
DEBUG - 2016-06-13 15:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:21:27 --> Input Class Initialized
INFO - 2016-06-13 15:21:27 --> Language Class Initialized
INFO - 2016-06-13 15:21:27 --> Loader Class Initialized
INFO - 2016-06-13 15:21:27 --> Helper loaded: form_helper
INFO - 2016-06-13 15:21:27 --> Database Driver Class Initialized
INFO - 2016-06-13 15:21:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:21:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:21:27 --> Email Class Initialized
INFO - 2016-06-13 15:21:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:21:27 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:21:27 --> Helper loaded: language_helper
INFO - 2016-06-13 15:21:27 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:21:27 --> Model Class Initialized
INFO - 2016-06-13 15:21:27 --> Helper loaded: date_helper
INFO - 2016-06-13 15:21:27 --> Controller Class Initialized
INFO - 2016-06-13 15:21:27 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:21:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:21:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:21:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:21:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:21:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:21:27 --> Model Class Initialized
INFO - 2016-06-13 15:21:27 --> Form Validation Class Initialized
INFO - 2016-06-13 15:21:27 --> Final output sent to browser
DEBUG - 2016-06-13 15:21:27 --> Total execution time: 0.0978
INFO - 2016-06-13 15:21:59 --> Config Class Initialized
INFO - 2016-06-13 15:21:59 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:21:59 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:21:59 --> Utf8 Class Initialized
INFO - 2016-06-13 15:21:59 --> URI Class Initialized
INFO - 2016-06-13 15:21:59 --> Router Class Initialized
INFO - 2016-06-13 15:21:59 --> Output Class Initialized
INFO - 2016-06-13 15:21:59 --> Security Class Initialized
DEBUG - 2016-06-13 15:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:21:59 --> Input Class Initialized
INFO - 2016-06-13 15:21:59 --> Language Class Initialized
INFO - 2016-06-13 15:21:59 --> Loader Class Initialized
INFO - 2016-06-13 15:21:59 --> Helper loaded: form_helper
INFO - 2016-06-13 15:21:59 --> Database Driver Class Initialized
INFO - 2016-06-13 15:21:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:21:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:21:59 --> Email Class Initialized
INFO - 2016-06-13 15:21:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:21:59 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:21:59 --> Helper loaded: language_helper
INFO - 2016-06-13 15:21:59 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:21:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:21:59 --> Model Class Initialized
INFO - 2016-06-13 15:21:59 --> Helper loaded: date_helper
INFO - 2016-06-13 15:21:59 --> Controller Class Initialized
INFO - 2016-06-13 15:21:59 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:21:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:21:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:21:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:21:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:21:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:21:59 --> Model Class Initialized
INFO - 2016-06-13 15:21:59 --> Form Validation Class Initialized
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:21:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:21:59 --> Final output sent to browser
DEBUG - 2016-06-13 15:21:59 --> Total execution time: 0.1232
INFO - 2016-06-13 15:22:01 --> Config Class Initialized
INFO - 2016-06-13 15:22:01 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:22:01 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:22:01 --> Utf8 Class Initialized
INFO - 2016-06-13 15:22:01 --> URI Class Initialized
INFO - 2016-06-13 15:22:01 --> Router Class Initialized
INFO - 2016-06-13 15:22:01 --> Output Class Initialized
INFO - 2016-06-13 15:22:01 --> Security Class Initialized
DEBUG - 2016-06-13 15:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:22:01 --> Input Class Initialized
INFO - 2016-06-13 15:22:01 --> Language Class Initialized
INFO - 2016-06-13 15:22:01 --> Loader Class Initialized
INFO - 2016-06-13 15:22:01 --> Helper loaded: form_helper
INFO - 2016-06-13 15:22:01 --> Database Driver Class Initialized
INFO - 2016-06-13 15:22:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:22:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:22:01 --> Email Class Initialized
INFO - 2016-06-13 15:22:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:22:01 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:22:01 --> Helper loaded: language_helper
INFO - 2016-06-13 15:22:01 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:22:01 --> Model Class Initialized
INFO - 2016-06-13 15:22:01 --> Helper loaded: date_helper
INFO - 2016-06-13 15:22:01 --> Controller Class Initialized
INFO - 2016-06-13 15:22:01 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:22:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:22:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:22:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:22:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:22:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:22:01 --> Model Class Initialized
INFO - 2016-06-13 15:22:01 --> Form Validation Class Initialized
INFO - 2016-06-13 15:22:01 --> Final output sent to browser
DEBUG - 2016-06-13 15:22:01 --> Total execution time: 0.0805
INFO - 2016-06-13 15:22:15 --> Config Class Initialized
INFO - 2016-06-13 15:22:15 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:22:15 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:22:15 --> Utf8 Class Initialized
INFO - 2016-06-13 15:22:15 --> URI Class Initialized
INFO - 2016-06-13 15:22:15 --> Router Class Initialized
INFO - 2016-06-13 15:22:15 --> Output Class Initialized
INFO - 2016-06-13 15:22:15 --> Security Class Initialized
DEBUG - 2016-06-13 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:22:15 --> Input Class Initialized
INFO - 2016-06-13 15:22:15 --> Language Class Initialized
INFO - 2016-06-13 15:22:15 --> Loader Class Initialized
INFO - 2016-06-13 15:22:15 --> Helper loaded: form_helper
INFO - 2016-06-13 15:22:15 --> Database Driver Class Initialized
INFO - 2016-06-13 15:22:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:22:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:22:15 --> Email Class Initialized
INFO - 2016-06-13 15:22:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:22:15 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:22:15 --> Helper loaded: language_helper
INFO - 2016-06-13 15:22:15 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:22:15 --> Model Class Initialized
INFO - 2016-06-13 15:22:15 --> Helper loaded: date_helper
INFO - 2016-06-13 15:22:15 --> Controller Class Initialized
INFO - 2016-06-13 15:22:15 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:22:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:22:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:22:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:22:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:22:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:22:15 --> Model Class Initialized
INFO - 2016-06-13 15:22:15 --> Form Validation Class Initialized
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:22:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:22:15 --> Final output sent to browser
DEBUG - 2016-06-13 15:22:15 --> Total execution time: 0.1055
INFO - 2016-06-13 15:22:16 --> Config Class Initialized
INFO - 2016-06-13 15:22:16 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:22:16 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:22:16 --> Utf8 Class Initialized
INFO - 2016-06-13 15:22:16 --> URI Class Initialized
INFO - 2016-06-13 15:22:16 --> Router Class Initialized
INFO - 2016-06-13 15:22:16 --> Output Class Initialized
INFO - 2016-06-13 15:22:16 --> Security Class Initialized
DEBUG - 2016-06-13 15:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:22:16 --> Input Class Initialized
INFO - 2016-06-13 15:22:16 --> Language Class Initialized
INFO - 2016-06-13 15:22:16 --> Loader Class Initialized
INFO - 2016-06-13 15:22:16 --> Helper loaded: form_helper
INFO - 2016-06-13 15:22:16 --> Database Driver Class Initialized
INFO - 2016-06-13 15:22:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:22:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:22:16 --> Email Class Initialized
INFO - 2016-06-13 15:22:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:22:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:22:16 --> Helper loaded: language_helper
INFO - 2016-06-13 15:22:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:22:16 --> Model Class Initialized
INFO - 2016-06-13 15:22:16 --> Helper loaded: date_helper
INFO - 2016-06-13 15:22:16 --> Controller Class Initialized
INFO - 2016-06-13 15:22:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:22:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:22:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:22:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:22:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:22:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:22:16 --> Model Class Initialized
INFO - 2016-06-13 15:22:16 --> Form Validation Class Initialized
INFO - 2016-06-13 15:22:16 --> Final output sent to browser
DEBUG - 2016-06-13 15:22:16 --> Total execution time: 0.0546
INFO - 2016-06-13 15:22:19 --> Config Class Initialized
INFO - 2016-06-13 15:22:19 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:22:19 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:22:19 --> Utf8 Class Initialized
INFO - 2016-06-13 15:22:19 --> URI Class Initialized
INFO - 2016-06-13 15:22:19 --> Router Class Initialized
INFO - 2016-06-13 15:22:19 --> Output Class Initialized
INFO - 2016-06-13 15:22:19 --> Security Class Initialized
DEBUG - 2016-06-13 15:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:22:19 --> Input Class Initialized
INFO - 2016-06-13 15:22:19 --> Language Class Initialized
INFO - 2016-06-13 15:22:19 --> Loader Class Initialized
INFO - 2016-06-13 15:22:19 --> Helper loaded: form_helper
INFO - 2016-06-13 15:22:19 --> Database Driver Class Initialized
INFO - 2016-06-13 15:22:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:22:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:22:19 --> Email Class Initialized
INFO - 2016-06-13 15:22:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:22:19 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:22:19 --> Helper loaded: language_helper
INFO - 2016-06-13 15:22:19 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:22:19 --> Model Class Initialized
INFO - 2016-06-13 15:22:19 --> Helper loaded: date_helper
INFO - 2016-06-13 15:22:19 --> Controller Class Initialized
INFO - 2016-06-13 15:22:19 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:22:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:22:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:22:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:22:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:22:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:22:19 --> Model Class Initialized
INFO - 2016-06-13 15:22:19 --> Form Validation Class Initialized
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:22:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:22:19 --> Final output sent to browser
DEBUG - 2016-06-13 15:22:19 --> Total execution time: 0.0954
INFO - 2016-06-13 15:22:20 --> Config Class Initialized
INFO - 2016-06-13 15:22:20 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:22:20 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:22:20 --> Utf8 Class Initialized
INFO - 2016-06-13 15:22:20 --> URI Class Initialized
INFO - 2016-06-13 15:22:20 --> Router Class Initialized
INFO - 2016-06-13 15:22:20 --> Output Class Initialized
INFO - 2016-06-13 15:22:20 --> Security Class Initialized
DEBUG - 2016-06-13 15:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:22:20 --> Input Class Initialized
INFO - 2016-06-13 15:22:20 --> Language Class Initialized
INFO - 2016-06-13 15:22:20 --> Loader Class Initialized
INFO - 2016-06-13 15:22:20 --> Helper loaded: form_helper
INFO - 2016-06-13 15:22:20 --> Database Driver Class Initialized
INFO - 2016-06-13 15:22:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:22:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:22:20 --> Email Class Initialized
INFO - 2016-06-13 15:22:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:22:20 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:22:20 --> Helper loaded: language_helper
INFO - 2016-06-13 15:22:20 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:22:20 --> Model Class Initialized
INFO - 2016-06-13 15:22:20 --> Helper loaded: date_helper
INFO - 2016-06-13 15:22:20 --> Controller Class Initialized
INFO - 2016-06-13 15:22:20 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:22:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:22:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:22:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:22:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:22:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:22:20 --> Model Class Initialized
INFO - 2016-06-13 15:22:20 --> Form Validation Class Initialized
INFO - 2016-06-13 15:22:20 --> Final output sent to browser
DEBUG - 2016-06-13 15:22:20 --> Total execution time: 0.0295
INFO - 2016-06-13 15:22:57 --> Config Class Initialized
INFO - 2016-06-13 15:22:57 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:22:57 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:22:57 --> Utf8 Class Initialized
INFO - 2016-06-13 15:22:57 --> URI Class Initialized
INFO - 2016-06-13 15:22:57 --> Router Class Initialized
INFO - 2016-06-13 15:22:57 --> Output Class Initialized
INFO - 2016-06-13 15:22:57 --> Security Class Initialized
DEBUG - 2016-06-13 15:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:22:57 --> Input Class Initialized
INFO - 2016-06-13 15:22:57 --> Language Class Initialized
INFO - 2016-06-13 15:22:57 --> Loader Class Initialized
INFO - 2016-06-13 15:22:57 --> Helper loaded: form_helper
INFO - 2016-06-13 15:22:57 --> Database Driver Class Initialized
INFO - 2016-06-13 15:22:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:22:57 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:22:57 --> Email Class Initialized
INFO - 2016-06-13 15:22:57 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:22:57 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:22:57 --> Helper loaded: language_helper
INFO - 2016-06-13 15:22:57 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:22:57 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:22:57 --> Model Class Initialized
INFO - 2016-06-13 15:22:57 --> Helper loaded: date_helper
INFO - 2016-06-13 15:22:57 --> Controller Class Initialized
INFO - 2016-06-13 15:22:57 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:22:57 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:22:57 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:22:57 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:22:57 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:22:57 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:22:57 --> Model Class Initialized
INFO - 2016-06-13 15:22:57 --> Form Validation Class Initialized
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:22:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:22:58 --> Final output sent to browser
DEBUG - 2016-06-13 15:22:58 --> Total execution time: 0.1254
INFO - 2016-06-13 15:22:59 --> Config Class Initialized
INFO - 2016-06-13 15:22:59 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:22:59 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:22:59 --> Utf8 Class Initialized
INFO - 2016-06-13 15:22:59 --> URI Class Initialized
INFO - 2016-06-13 15:22:59 --> Router Class Initialized
INFO - 2016-06-13 15:22:59 --> Output Class Initialized
INFO - 2016-06-13 15:22:59 --> Security Class Initialized
DEBUG - 2016-06-13 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:22:59 --> Input Class Initialized
INFO - 2016-06-13 15:22:59 --> Language Class Initialized
INFO - 2016-06-13 15:22:59 --> Loader Class Initialized
INFO - 2016-06-13 15:22:59 --> Helper loaded: form_helper
INFO - 2016-06-13 15:22:59 --> Database Driver Class Initialized
INFO - 2016-06-13 15:22:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:22:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:22:59 --> Email Class Initialized
INFO - 2016-06-13 15:22:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:22:59 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:22:59 --> Helper loaded: language_helper
INFO - 2016-06-13 15:22:59 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:22:59 --> Model Class Initialized
INFO - 2016-06-13 15:22:59 --> Helper loaded: date_helper
INFO - 2016-06-13 15:22:59 --> Controller Class Initialized
INFO - 2016-06-13 15:22:59 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:22:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:22:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:22:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:22:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:22:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:22:59 --> Model Class Initialized
INFO - 2016-06-13 15:22:59 --> Form Validation Class Initialized
INFO - 2016-06-13 15:22:59 --> Final output sent to browser
DEBUG - 2016-06-13 15:22:59 --> Total execution time: 0.1003
INFO - 2016-06-13 15:23:14 --> Config Class Initialized
INFO - 2016-06-13 15:23:14 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:23:14 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:23:14 --> Utf8 Class Initialized
INFO - 2016-06-13 15:23:14 --> URI Class Initialized
INFO - 2016-06-13 15:23:14 --> Router Class Initialized
INFO - 2016-06-13 15:23:14 --> Output Class Initialized
INFO - 2016-06-13 15:23:14 --> Security Class Initialized
DEBUG - 2016-06-13 15:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:23:14 --> Input Class Initialized
INFO - 2016-06-13 15:23:14 --> Language Class Initialized
INFO - 2016-06-13 15:23:14 --> Loader Class Initialized
INFO - 2016-06-13 15:23:14 --> Helper loaded: form_helper
INFO - 2016-06-13 15:23:14 --> Database Driver Class Initialized
INFO - 2016-06-13 15:23:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:23:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:23:14 --> Email Class Initialized
INFO - 2016-06-13 15:23:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:23:14 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:23:14 --> Helper loaded: language_helper
INFO - 2016-06-13 15:23:14 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:23:14 --> Model Class Initialized
INFO - 2016-06-13 15:23:14 --> Helper loaded: date_helper
INFO - 2016-06-13 15:23:14 --> Controller Class Initialized
INFO - 2016-06-13 15:23:14 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:23:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:23:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:23:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:23:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:23:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:23:14 --> Model Class Initialized
INFO - 2016-06-13 15:23:14 --> Form Validation Class Initialized
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:23:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:23:14 --> Final output sent to browser
DEBUG - 2016-06-13 15:23:14 --> Total execution time: 0.0933
INFO - 2016-06-13 15:23:15 --> Config Class Initialized
INFO - 2016-06-13 15:23:15 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:23:15 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:23:15 --> Utf8 Class Initialized
INFO - 2016-06-13 15:23:15 --> URI Class Initialized
INFO - 2016-06-13 15:23:15 --> Router Class Initialized
INFO - 2016-06-13 15:23:15 --> Output Class Initialized
INFO - 2016-06-13 15:23:15 --> Security Class Initialized
DEBUG - 2016-06-13 15:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:23:15 --> Input Class Initialized
INFO - 2016-06-13 15:23:15 --> Language Class Initialized
INFO - 2016-06-13 15:23:15 --> Loader Class Initialized
INFO - 2016-06-13 15:23:15 --> Helper loaded: form_helper
INFO - 2016-06-13 15:23:15 --> Database Driver Class Initialized
INFO - 2016-06-13 15:23:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:23:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:23:15 --> Email Class Initialized
INFO - 2016-06-13 15:23:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:23:15 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:23:15 --> Helper loaded: language_helper
INFO - 2016-06-13 15:23:15 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:23:15 --> Model Class Initialized
INFO - 2016-06-13 15:23:15 --> Helper loaded: date_helper
INFO - 2016-06-13 15:23:15 --> Controller Class Initialized
INFO - 2016-06-13 15:23:15 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:23:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:23:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:23:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:23:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:23:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:23:15 --> Model Class Initialized
INFO - 2016-06-13 15:23:15 --> Form Validation Class Initialized
INFO - 2016-06-13 15:23:15 --> Final output sent to browser
DEBUG - 2016-06-13 15:23:15 --> Total execution time: 0.0427
INFO - 2016-06-13 15:23:26 --> Config Class Initialized
INFO - 2016-06-13 15:23:26 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:23:26 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:23:26 --> Utf8 Class Initialized
INFO - 2016-06-13 15:23:26 --> URI Class Initialized
INFO - 2016-06-13 15:23:26 --> Router Class Initialized
INFO - 2016-06-13 15:23:26 --> Output Class Initialized
INFO - 2016-06-13 15:23:26 --> Security Class Initialized
DEBUG - 2016-06-13 15:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:23:26 --> Input Class Initialized
INFO - 2016-06-13 15:23:26 --> Language Class Initialized
INFO - 2016-06-13 15:23:26 --> Loader Class Initialized
INFO - 2016-06-13 15:23:26 --> Helper loaded: form_helper
INFO - 2016-06-13 15:23:26 --> Database Driver Class Initialized
INFO - 2016-06-13 15:23:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:23:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:23:26 --> Email Class Initialized
INFO - 2016-06-13 15:23:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:23:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:23:26 --> Helper loaded: language_helper
INFO - 2016-06-13 15:23:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:23:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:23:26 --> Model Class Initialized
INFO - 2016-06-13 15:23:26 --> Helper loaded: date_helper
INFO - 2016-06-13 15:23:26 --> Controller Class Initialized
INFO - 2016-06-13 15:23:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:23:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:23:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:23:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:23:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:23:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:23:26 --> Model Class Initialized
INFO - 2016-06-13 15:23:26 --> Form Validation Class Initialized
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:23:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:23:26 --> Final output sent to browser
DEBUG - 2016-06-13 15:23:26 --> Total execution time: 0.1264
INFO - 2016-06-13 15:23:28 --> Config Class Initialized
INFO - 2016-06-13 15:23:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:23:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:23:28 --> Utf8 Class Initialized
INFO - 2016-06-13 15:23:28 --> URI Class Initialized
INFO - 2016-06-13 15:23:28 --> Router Class Initialized
INFO - 2016-06-13 15:23:28 --> Output Class Initialized
INFO - 2016-06-13 15:23:28 --> Security Class Initialized
DEBUG - 2016-06-13 15:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:23:28 --> Input Class Initialized
INFO - 2016-06-13 15:23:28 --> Language Class Initialized
INFO - 2016-06-13 15:23:28 --> Loader Class Initialized
INFO - 2016-06-13 15:23:28 --> Helper loaded: form_helper
INFO - 2016-06-13 15:23:28 --> Database Driver Class Initialized
INFO - 2016-06-13 15:23:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:23:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:23:28 --> Email Class Initialized
INFO - 2016-06-13 15:23:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:23:28 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:23:28 --> Helper loaded: language_helper
INFO - 2016-06-13 15:23:28 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:23:28 --> Model Class Initialized
INFO - 2016-06-13 15:23:28 --> Helper loaded: date_helper
INFO - 2016-06-13 15:23:28 --> Controller Class Initialized
INFO - 2016-06-13 15:23:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:23:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:23:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:23:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:23:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:23:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:23:28 --> Model Class Initialized
INFO - 2016-06-13 15:23:28 --> Form Validation Class Initialized
INFO - 2016-06-13 15:23:28 --> Final output sent to browser
DEBUG - 2016-06-13 15:23:28 --> Total execution time: 0.1008
INFO - 2016-06-13 15:23:45 --> Config Class Initialized
INFO - 2016-06-13 15:23:45 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:23:45 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:23:45 --> Utf8 Class Initialized
INFO - 2016-06-13 15:23:45 --> URI Class Initialized
INFO - 2016-06-13 15:23:45 --> Router Class Initialized
INFO - 2016-06-13 15:23:45 --> Output Class Initialized
INFO - 2016-06-13 15:23:45 --> Security Class Initialized
DEBUG - 2016-06-13 15:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:23:45 --> Input Class Initialized
INFO - 2016-06-13 15:23:45 --> Language Class Initialized
INFO - 2016-06-13 15:23:45 --> Loader Class Initialized
INFO - 2016-06-13 15:23:45 --> Helper loaded: form_helper
INFO - 2016-06-13 15:23:45 --> Database Driver Class Initialized
INFO - 2016-06-13 15:23:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:23:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:23:45 --> Email Class Initialized
INFO - 2016-06-13 15:23:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:23:45 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:23:45 --> Helper loaded: language_helper
INFO - 2016-06-13 15:23:45 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:23:45 --> Model Class Initialized
INFO - 2016-06-13 15:23:45 --> Helper loaded: date_helper
INFO - 2016-06-13 15:23:45 --> Controller Class Initialized
INFO - 2016-06-13 15:23:45 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:23:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:23:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:23:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:23:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:23:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:23:45 --> Model Class Initialized
INFO - 2016-06-13 15:23:45 --> Form Validation Class Initialized
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:23:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:23:45 --> Final output sent to browser
DEBUG - 2016-06-13 15:23:45 --> Total execution time: 0.1053
INFO - 2016-06-13 15:23:47 --> Config Class Initialized
INFO - 2016-06-13 15:23:47 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:23:47 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:23:47 --> Utf8 Class Initialized
INFO - 2016-06-13 15:23:47 --> URI Class Initialized
INFO - 2016-06-13 15:23:47 --> Router Class Initialized
INFO - 2016-06-13 15:23:47 --> Output Class Initialized
INFO - 2016-06-13 15:23:47 --> Security Class Initialized
DEBUG - 2016-06-13 15:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:23:47 --> Input Class Initialized
INFO - 2016-06-13 15:23:47 --> Language Class Initialized
INFO - 2016-06-13 15:23:47 --> Loader Class Initialized
INFO - 2016-06-13 15:23:47 --> Helper loaded: form_helper
INFO - 2016-06-13 15:23:47 --> Database Driver Class Initialized
INFO - 2016-06-13 15:23:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:23:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:23:47 --> Email Class Initialized
INFO - 2016-06-13 15:23:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:23:47 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:23:47 --> Helper loaded: language_helper
INFO - 2016-06-13 15:23:47 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:23:47 --> Model Class Initialized
INFO - 2016-06-13 15:23:47 --> Helper loaded: date_helper
INFO - 2016-06-13 15:23:47 --> Controller Class Initialized
INFO - 2016-06-13 15:23:47 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:23:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:23:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:23:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:23:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:23:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:23:47 --> Model Class Initialized
INFO - 2016-06-13 15:23:47 --> Form Validation Class Initialized
INFO - 2016-06-13 15:23:47 --> Final output sent to browser
DEBUG - 2016-06-13 15:23:47 --> Total execution time: 0.0540
INFO - 2016-06-13 15:23:59 --> Config Class Initialized
INFO - 2016-06-13 15:23:59 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:23:59 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:23:59 --> Utf8 Class Initialized
INFO - 2016-06-13 15:23:59 --> URI Class Initialized
INFO - 2016-06-13 15:23:59 --> Router Class Initialized
INFO - 2016-06-13 15:23:59 --> Output Class Initialized
INFO - 2016-06-13 15:23:59 --> Security Class Initialized
DEBUG - 2016-06-13 15:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:23:59 --> Input Class Initialized
INFO - 2016-06-13 15:23:59 --> Language Class Initialized
INFO - 2016-06-13 15:23:59 --> Loader Class Initialized
INFO - 2016-06-13 15:23:59 --> Helper loaded: form_helper
INFO - 2016-06-13 15:23:59 --> Database Driver Class Initialized
INFO - 2016-06-13 15:23:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:23:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:23:59 --> Email Class Initialized
INFO - 2016-06-13 15:23:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:23:59 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:23:59 --> Helper loaded: language_helper
INFO - 2016-06-13 15:23:59 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:23:59 --> Model Class Initialized
INFO - 2016-06-13 15:23:59 --> Helper loaded: date_helper
INFO - 2016-06-13 15:23:59 --> Controller Class Initialized
INFO - 2016-06-13 15:23:59 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:23:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:23:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:23:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:23:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:23:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:23:59 --> Model Class Initialized
INFO - 2016-06-13 15:23:59 --> Form Validation Class Initialized
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:23:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:23:59 --> Final output sent to browser
DEBUG - 2016-06-13 15:23:59 --> Total execution time: 0.0991
INFO - 2016-06-13 15:24:00 --> Config Class Initialized
INFO - 2016-06-13 15:24:00 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:24:00 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:24:00 --> Utf8 Class Initialized
INFO - 2016-06-13 15:24:00 --> URI Class Initialized
INFO - 2016-06-13 15:24:00 --> Router Class Initialized
INFO - 2016-06-13 15:24:00 --> Output Class Initialized
INFO - 2016-06-13 15:24:00 --> Security Class Initialized
DEBUG - 2016-06-13 15:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:24:00 --> Input Class Initialized
INFO - 2016-06-13 15:24:00 --> Language Class Initialized
INFO - 2016-06-13 15:24:00 --> Loader Class Initialized
INFO - 2016-06-13 15:24:00 --> Helper loaded: form_helper
INFO - 2016-06-13 15:24:00 --> Database Driver Class Initialized
INFO - 2016-06-13 15:24:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:24:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:24:00 --> Email Class Initialized
INFO - 2016-06-13 15:24:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:24:00 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:24:00 --> Helper loaded: language_helper
INFO - 2016-06-13 15:24:00 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:24:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:24:00 --> Model Class Initialized
INFO - 2016-06-13 15:24:00 --> Helper loaded: date_helper
INFO - 2016-06-13 15:24:00 --> Controller Class Initialized
INFO - 2016-06-13 15:24:00 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:24:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:24:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:24:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:24:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:24:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:24:00 --> Model Class Initialized
INFO - 2016-06-13 15:24:00 --> Form Validation Class Initialized
INFO - 2016-06-13 15:24:00 --> Final output sent to browser
DEBUG - 2016-06-13 15:24:00 --> Total execution time: 0.0993
INFO - 2016-06-13 15:24:18 --> Config Class Initialized
INFO - 2016-06-13 15:24:18 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:24:18 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:24:18 --> Utf8 Class Initialized
INFO - 2016-06-13 15:24:18 --> URI Class Initialized
INFO - 2016-06-13 15:24:18 --> Router Class Initialized
INFO - 2016-06-13 15:24:18 --> Output Class Initialized
INFO - 2016-06-13 15:24:18 --> Security Class Initialized
DEBUG - 2016-06-13 15:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:24:18 --> Input Class Initialized
INFO - 2016-06-13 15:24:18 --> Language Class Initialized
INFO - 2016-06-13 15:24:18 --> Loader Class Initialized
INFO - 2016-06-13 15:24:18 --> Helper loaded: form_helper
INFO - 2016-06-13 15:24:18 --> Database Driver Class Initialized
INFO - 2016-06-13 15:24:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:24:18 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:24:18 --> Email Class Initialized
INFO - 2016-06-13 15:24:18 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:24:18 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:24:18 --> Helper loaded: language_helper
INFO - 2016-06-13 15:24:18 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:24:18 --> Model Class Initialized
INFO - 2016-06-13 15:24:18 --> Helper loaded: date_helper
INFO - 2016-06-13 15:24:18 --> Controller Class Initialized
INFO - 2016-06-13 15:24:18 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:24:18 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:24:18 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:24:18 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:24:18 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:24:18 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:24:18 --> Model Class Initialized
INFO - 2016-06-13 15:24:18 --> Form Validation Class Initialized
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:24:18 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:24:18 --> Final output sent to browser
DEBUG - 2016-06-13 15:24:18 --> Total execution time: 0.1365
INFO - 2016-06-13 15:24:19 --> Config Class Initialized
INFO - 2016-06-13 15:24:19 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:24:19 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:24:19 --> Utf8 Class Initialized
INFO - 2016-06-13 15:24:19 --> URI Class Initialized
INFO - 2016-06-13 15:24:19 --> Router Class Initialized
INFO - 2016-06-13 15:24:19 --> Output Class Initialized
INFO - 2016-06-13 15:24:19 --> Security Class Initialized
DEBUG - 2016-06-13 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:24:19 --> Input Class Initialized
INFO - 2016-06-13 15:24:19 --> Language Class Initialized
INFO - 2016-06-13 15:24:19 --> Loader Class Initialized
INFO - 2016-06-13 15:24:19 --> Helper loaded: form_helper
INFO - 2016-06-13 15:24:19 --> Database Driver Class Initialized
INFO - 2016-06-13 15:24:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:24:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:24:19 --> Email Class Initialized
INFO - 2016-06-13 15:24:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:24:19 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:24:19 --> Helper loaded: language_helper
INFO - 2016-06-13 15:24:19 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:24:19 --> Model Class Initialized
INFO - 2016-06-13 15:24:19 --> Helper loaded: date_helper
INFO - 2016-06-13 15:24:19 --> Controller Class Initialized
INFO - 2016-06-13 15:24:19 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:24:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:24:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:24:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:24:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:24:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:24:19 --> Model Class Initialized
INFO - 2016-06-13 15:24:19 --> Form Validation Class Initialized
INFO - 2016-06-13 15:24:19 --> Final output sent to browser
DEBUG - 2016-06-13 15:24:19 --> Total execution time: 0.0577
INFO - 2016-06-13 15:24:26 --> Config Class Initialized
INFO - 2016-06-13 15:24:26 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:24:26 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:24:26 --> Utf8 Class Initialized
INFO - 2016-06-13 15:24:26 --> URI Class Initialized
INFO - 2016-06-13 15:24:26 --> Router Class Initialized
INFO - 2016-06-13 15:24:26 --> Output Class Initialized
INFO - 2016-06-13 15:24:26 --> Security Class Initialized
DEBUG - 2016-06-13 15:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:24:26 --> Input Class Initialized
INFO - 2016-06-13 15:24:26 --> Language Class Initialized
INFO - 2016-06-13 15:24:26 --> Loader Class Initialized
INFO - 2016-06-13 15:24:26 --> Helper loaded: form_helper
INFO - 2016-06-13 15:24:26 --> Database Driver Class Initialized
INFO - 2016-06-13 15:24:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:24:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:24:26 --> Email Class Initialized
INFO - 2016-06-13 15:24:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:24:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:24:26 --> Helper loaded: language_helper
INFO - 2016-06-13 15:24:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:24:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:24:26 --> Model Class Initialized
INFO - 2016-06-13 15:24:26 --> Helper loaded: date_helper
INFO - 2016-06-13 15:24:26 --> Controller Class Initialized
INFO - 2016-06-13 15:24:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:24:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:24:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:24:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:24:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:24:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:24:26 --> Model Class Initialized
INFO - 2016-06-13 15:24:26 --> Form Validation Class Initialized
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:24:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:24:26 --> Final output sent to browser
DEBUG - 2016-06-13 15:24:26 --> Total execution time: 0.0882
INFO - 2016-06-13 15:24:27 --> Config Class Initialized
INFO - 2016-06-13 15:24:27 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:24:27 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:24:27 --> Utf8 Class Initialized
INFO - 2016-06-13 15:24:27 --> URI Class Initialized
INFO - 2016-06-13 15:24:27 --> Router Class Initialized
INFO - 2016-06-13 15:24:27 --> Output Class Initialized
INFO - 2016-06-13 15:24:27 --> Security Class Initialized
DEBUG - 2016-06-13 15:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:24:27 --> Input Class Initialized
INFO - 2016-06-13 15:24:27 --> Language Class Initialized
INFO - 2016-06-13 15:24:27 --> Loader Class Initialized
INFO - 2016-06-13 15:24:27 --> Helper loaded: form_helper
INFO - 2016-06-13 15:24:27 --> Database Driver Class Initialized
INFO - 2016-06-13 15:24:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:24:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:24:27 --> Email Class Initialized
INFO - 2016-06-13 15:24:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:24:27 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:24:27 --> Helper loaded: language_helper
INFO - 2016-06-13 15:24:27 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:24:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:24:27 --> Model Class Initialized
INFO - 2016-06-13 15:24:28 --> Helper loaded: date_helper
INFO - 2016-06-13 15:24:28 --> Controller Class Initialized
INFO - 2016-06-13 15:24:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:24:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:24:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:24:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:24:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:24:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:24:28 --> Model Class Initialized
INFO - 2016-06-13 15:24:28 --> Form Validation Class Initialized
INFO - 2016-06-13 15:24:28 --> Final output sent to browser
DEBUG - 2016-06-13 15:24:28 --> Total execution time: 0.0535
INFO - 2016-06-13 15:26:14 --> Config Class Initialized
INFO - 2016-06-13 15:26:14 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:26:14 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:26:14 --> Utf8 Class Initialized
INFO - 2016-06-13 15:26:14 --> URI Class Initialized
INFO - 2016-06-13 15:26:14 --> Router Class Initialized
INFO - 2016-06-13 15:26:14 --> Output Class Initialized
INFO - 2016-06-13 15:26:14 --> Security Class Initialized
DEBUG - 2016-06-13 15:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:26:14 --> Input Class Initialized
INFO - 2016-06-13 15:26:14 --> Language Class Initialized
INFO - 2016-06-13 15:26:14 --> Loader Class Initialized
INFO - 2016-06-13 15:26:14 --> Helper loaded: form_helper
INFO - 2016-06-13 15:26:14 --> Database Driver Class Initialized
INFO - 2016-06-13 15:26:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:26:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:26:14 --> Email Class Initialized
INFO - 2016-06-13 15:26:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:26:14 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:26:14 --> Helper loaded: language_helper
INFO - 2016-06-13 15:26:14 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:26:14 --> Model Class Initialized
INFO - 2016-06-13 15:26:14 --> Helper loaded: date_helper
INFO - 2016-06-13 15:26:14 --> Controller Class Initialized
INFO - 2016-06-13 15:26:14 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:26:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:26:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:26:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:26:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:26:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:26:14 --> Model Class Initialized
INFO - 2016-06-13 15:26:14 --> Form Validation Class Initialized
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:26:14 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:26:14 --> Final output sent to browser
DEBUG - 2016-06-13 15:26:14 --> Total execution time: 0.0976
INFO - 2016-06-13 15:26:15 --> Config Class Initialized
INFO - 2016-06-13 15:26:15 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:26:15 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:26:15 --> Utf8 Class Initialized
INFO - 2016-06-13 15:26:15 --> URI Class Initialized
INFO - 2016-06-13 15:26:15 --> Router Class Initialized
INFO - 2016-06-13 15:26:15 --> Output Class Initialized
INFO - 2016-06-13 15:26:15 --> Security Class Initialized
DEBUG - 2016-06-13 15:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:26:15 --> Input Class Initialized
INFO - 2016-06-13 15:26:15 --> Language Class Initialized
INFO - 2016-06-13 15:26:15 --> Loader Class Initialized
INFO - 2016-06-13 15:26:15 --> Helper loaded: form_helper
INFO - 2016-06-13 15:26:15 --> Database Driver Class Initialized
INFO - 2016-06-13 15:26:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:26:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:26:15 --> Email Class Initialized
INFO - 2016-06-13 15:26:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:26:15 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:26:15 --> Helper loaded: language_helper
INFO - 2016-06-13 15:26:15 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:26:15 --> Model Class Initialized
INFO - 2016-06-13 15:26:15 --> Helper loaded: date_helper
INFO - 2016-06-13 15:26:15 --> Controller Class Initialized
INFO - 2016-06-13 15:26:15 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:26:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:26:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:26:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:26:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:26:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:26:15 --> Model Class Initialized
INFO - 2016-06-13 15:26:15 --> Form Validation Class Initialized
INFO - 2016-06-13 15:26:15 --> Final output sent to browser
DEBUG - 2016-06-13 15:26:15 --> Total execution time: 0.0614
INFO - 2016-06-13 15:27:46 --> Config Class Initialized
INFO - 2016-06-13 15:27:46 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:27:46 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:27:46 --> Utf8 Class Initialized
INFO - 2016-06-13 15:27:46 --> URI Class Initialized
INFO - 2016-06-13 15:27:46 --> Router Class Initialized
INFO - 2016-06-13 15:27:46 --> Output Class Initialized
INFO - 2016-06-13 15:27:46 --> Security Class Initialized
DEBUG - 2016-06-13 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:27:46 --> Input Class Initialized
INFO - 2016-06-13 15:27:46 --> Language Class Initialized
INFO - 2016-06-13 15:27:46 --> Loader Class Initialized
INFO - 2016-06-13 15:27:46 --> Helper loaded: form_helper
INFO - 2016-06-13 15:27:46 --> Database Driver Class Initialized
INFO - 2016-06-13 15:27:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:27:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:27:46 --> Email Class Initialized
INFO - 2016-06-13 15:27:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:27:46 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:27:46 --> Helper loaded: language_helper
INFO - 2016-06-13 15:27:46 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:27:46 --> Model Class Initialized
INFO - 2016-06-13 15:27:46 --> Helper loaded: date_helper
INFO - 2016-06-13 15:27:46 --> Controller Class Initialized
INFO - 2016-06-13 15:27:46 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:27:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:27:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:27:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:27:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:27:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:27:46 --> Model Class Initialized
INFO - 2016-06-13 15:27:46 --> Form Validation Class Initialized
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:27:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:27:46 --> Final output sent to browser
DEBUG - 2016-06-13 15:27:46 --> Total execution time: 0.1021
INFO - 2016-06-13 15:27:48 --> Config Class Initialized
INFO - 2016-06-13 15:27:48 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:27:48 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:27:48 --> Utf8 Class Initialized
INFO - 2016-06-13 15:27:48 --> URI Class Initialized
INFO - 2016-06-13 15:27:48 --> Router Class Initialized
INFO - 2016-06-13 15:27:48 --> Output Class Initialized
INFO - 2016-06-13 15:27:48 --> Security Class Initialized
DEBUG - 2016-06-13 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:27:48 --> Input Class Initialized
INFO - 2016-06-13 15:27:48 --> Language Class Initialized
INFO - 2016-06-13 15:27:48 --> Loader Class Initialized
INFO - 2016-06-13 15:27:48 --> Helper loaded: form_helper
INFO - 2016-06-13 15:27:48 --> Database Driver Class Initialized
INFO - 2016-06-13 15:27:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:27:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:27:48 --> Email Class Initialized
INFO - 2016-06-13 15:27:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:27:48 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:27:48 --> Helper loaded: language_helper
INFO - 2016-06-13 15:27:48 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:27:48 --> Model Class Initialized
INFO - 2016-06-13 15:27:48 --> Helper loaded: date_helper
INFO - 2016-06-13 15:27:48 --> Controller Class Initialized
INFO - 2016-06-13 15:27:48 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:27:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:27:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:27:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:27:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:27:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:27:48 --> Model Class Initialized
INFO - 2016-06-13 15:27:48 --> Form Validation Class Initialized
INFO - 2016-06-13 15:27:48 --> Final output sent to browser
DEBUG - 2016-06-13 15:27:48 --> Total execution time: 0.0560
INFO - 2016-06-13 15:28:20 --> Config Class Initialized
INFO - 2016-06-13 15:28:20 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:20 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:20 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:20 --> URI Class Initialized
INFO - 2016-06-13 15:28:20 --> Router Class Initialized
INFO - 2016-06-13 15:28:20 --> Output Class Initialized
INFO - 2016-06-13 15:28:20 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:20 --> Input Class Initialized
INFO - 2016-06-13 15:28:20 --> Language Class Initialized
INFO - 2016-06-13 15:28:20 --> Loader Class Initialized
INFO - 2016-06-13 15:28:20 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:20 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:20 --> Email Class Initialized
INFO - 2016-06-13 15:28:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:20 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:20 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:20 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:20 --> Model Class Initialized
INFO - 2016-06-13 15:28:20 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:20 --> Controller Class Initialized
INFO - 2016-06-13 15:28:20 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:20 --> Model Class Initialized
INFO - 2016-06-13 15:28:20 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:28:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:28:20 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:20 --> Total execution time: 0.1066
INFO - 2016-06-13 15:28:22 --> Config Class Initialized
INFO - 2016-06-13 15:28:22 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:22 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:22 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:22 --> URI Class Initialized
INFO - 2016-06-13 15:28:22 --> Router Class Initialized
INFO - 2016-06-13 15:28:22 --> Output Class Initialized
INFO - 2016-06-13 15:28:22 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:22 --> Input Class Initialized
INFO - 2016-06-13 15:28:22 --> Language Class Initialized
INFO - 2016-06-13 15:28:22 --> Loader Class Initialized
INFO - 2016-06-13 15:28:22 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:22 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:22 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:22 --> Email Class Initialized
INFO - 2016-06-13 15:28:22 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:22 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:22 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:22 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:22 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:22 --> Model Class Initialized
INFO - 2016-06-13 15:28:22 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:22 --> Controller Class Initialized
INFO - 2016-06-13 15:28:22 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:22 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:22 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:22 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:22 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:22 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:22 --> Model Class Initialized
INFO - 2016-06-13 15:28:22 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:22 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:22 --> Total execution time: 0.0468
INFO - 2016-06-13 15:28:25 --> Config Class Initialized
INFO - 2016-06-13 15:28:25 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:25 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:25 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:25 --> URI Class Initialized
INFO - 2016-06-13 15:28:25 --> Router Class Initialized
INFO - 2016-06-13 15:28:25 --> Output Class Initialized
INFO - 2016-06-13 15:28:25 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:25 --> Input Class Initialized
INFO - 2016-06-13 15:28:25 --> Language Class Initialized
INFO - 2016-06-13 15:28:25 --> Loader Class Initialized
INFO - 2016-06-13 15:28:25 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:25 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:25 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:25 --> Email Class Initialized
INFO - 2016-06-13 15:28:25 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:25 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:25 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:25 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:25 --> Model Class Initialized
INFO - 2016-06-13 15:28:25 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:25 --> Controller Class Initialized
INFO - 2016-06-13 15:28:25 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:25 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:25 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:25 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:25 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:25 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:25 --> Model Class Initialized
INFO - 2016-06-13 15:28:25 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:28:25 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:28:25 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:25 --> Total execution time: 0.0985
INFO - 2016-06-13 15:28:26 --> Config Class Initialized
INFO - 2016-06-13 15:28:26 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:26 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:26 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:26 --> URI Class Initialized
INFO - 2016-06-13 15:28:26 --> Router Class Initialized
INFO - 2016-06-13 15:28:26 --> Output Class Initialized
INFO - 2016-06-13 15:28:26 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:26 --> Input Class Initialized
INFO - 2016-06-13 15:28:26 --> Language Class Initialized
INFO - 2016-06-13 15:28:26 --> Loader Class Initialized
INFO - 2016-06-13 15:28:26 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:26 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:26 --> Email Class Initialized
INFO - 2016-06-13 15:28:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:26 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:26 --> Model Class Initialized
INFO - 2016-06-13 15:28:26 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:26 --> Controller Class Initialized
INFO - 2016-06-13 15:28:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:26 --> Model Class Initialized
INFO - 2016-06-13 15:28:26 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:26 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:26 --> Total execution time: 0.0565
INFO - 2016-06-13 15:28:37 --> Config Class Initialized
INFO - 2016-06-13 15:28:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:37 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:37 --> URI Class Initialized
INFO - 2016-06-13 15:28:37 --> Router Class Initialized
INFO - 2016-06-13 15:28:37 --> Output Class Initialized
INFO - 2016-06-13 15:28:37 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:37 --> Input Class Initialized
INFO - 2016-06-13 15:28:37 --> Language Class Initialized
INFO - 2016-06-13 15:28:37 --> Loader Class Initialized
INFO - 2016-06-13 15:28:37 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:37 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:37 --> Email Class Initialized
INFO - 2016-06-13 15:28:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:37 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:37 --> Model Class Initialized
INFO - 2016-06-13 15:28:37 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:37 --> Controller Class Initialized
INFO - 2016-06-13 15:28:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:37 --> Model Class Initialized
INFO - 2016-06-13 15:28:37 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:28:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:28:37 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:37 --> Total execution time: 0.1431
INFO - 2016-06-13 15:28:38 --> Config Class Initialized
INFO - 2016-06-13 15:28:38 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:38 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:38 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:38 --> URI Class Initialized
INFO - 2016-06-13 15:28:38 --> Router Class Initialized
INFO - 2016-06-13 15:28:38 --> Output Class Initialized
INFO - 2016-06-13 15:28:38 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:38 --> Input Class Initialized
INFO - 2016-06-13 15:28:38 --> Language Class Initialized
INFO - 2016-06-13 15:28:38 --> Loader Class Initialized
INFO - 2016-06-13 15:28:38 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:38 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:38 --> Email Class Initialized
INFO - 2016-06-13 15:28:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:38 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:38 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:38 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:38 --> Model Class Initialized
INFO - 2016-06-13 15:28:38 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:38 --> Controller Class Initialized
INFO - 2016-06-13 15:28:38 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:38 --> Model Class Initialized
INFO - 2016-06-13 15:28:38 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:38 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:38 --> Total execution time: 0.0566
INFO - 2016-06-13 15:28:45 --> Config Class Initialized
INFO - 2016-06-13 15:28:45 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:45 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:45 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:45 --> URI Class Initialized
INFO - 2016-06-13 15:28:45 --> Router Class Initialized
INFO - 2016-06-13 15:28:45 --> Output Class Initialized
INFO - 2016-06-13 15:28:45 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:45 --> Input Class Initialized
INFO - 2016-06-13 15:28:45 --> Language Class Initialized
INFO - 2016-06-13 15:28:45 --> Loader Class Initialized
INFO - 2016-06-13 15:28:45 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:45 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:45 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:45 --> Email Class Initialized
INFO - 2016-06-13 15:28:45 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:45 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:45 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:45 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:45 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:45 --> Model Class Initialized
INFO - 2016-06-13 15:28:45 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:45 --> Controller Class Initialized
INFO - 2016-06-13 15:28:45 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:45 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:45 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:45 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:45 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:45 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:45 --> Model Class Initialized
INFO - 2016-06-13 15:28:45 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:28:45 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:28:45 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:45 --> Total execution time: 0.1000
INFO - 2016-06-13 15:28:47 --> Config Class Initialized
INFO - 2016-06-13 15:28:47 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:47 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:47 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:47 --> URI Class Initialized
INFO - 2016-06-13 15:28:47 --> Router Class Initialized
INFO - 2016-06-13 15:28:47 --> Output Class Initialized
INFO - 2016-06-13 15:28:47 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:47 --> Input Class Initialized
INFO - 2016-06-13 15:28:47 --> Language Class Initialized
INFO - 2016-06-13 15:28:47 --> Loader Class Initialized
INFO - 2016-06-13 15:28:47 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:47 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:47 --> Email Class Initialized
INFO - 2016-06-13 15:28:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:47 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:47 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:47 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:47 --> Model Class Initialized
INFO - 2016-06-13 15:28:47 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:47 --> Controller Class Initialized
INFO - 2016-06-13 15:28:47 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:47 --> Model Class Initialized
INFO - 2016-06-13 15:28:47 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:47 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:47 --> Total execution time: 0.0982
INFO - 2016-06-13 15:28:50 --> Config Class Initialized
INFO - 2016-06-13 15:28:50 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:50 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:50 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:50 --> URI Class Initialized
INFO - 2016-06-13 15:28:50 --> Router Class Initialized
INFO - 2016-06-13 15:28:50 --> Output Class Initialized
INFO - 2016-06-13 15:28:50 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:50 --> Input Class Initialized
INFO - 2016-06-13 15:28:50 --> Language Class Initialized
INFO - 2016-06-13 15:28:50 --> Loader Class Initialized
INFO - 2016-06-13 15:28:50 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:50 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:50 --> Email Class Initialized
INFO - 2016-06-13 15:28:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:50 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:50 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:50 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:50 --> Model Class Initialized
INFO - 2016-06-13 15:28:50 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:50 --> Controller Class Initialized
INFO - 2016-06-13 15:28:50 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:50 --> Model Class Initialized
INFO - 2016-06-13 15:28:50 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:28:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:28:50 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:50 --> Total execution time: 0.0358
INFO - 2016-06-13 15:28:51 --> Config Class Initialized
INFO - 2016-06-13 15:28:51 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:51 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:51 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:51 --> URI Class Initialized
INFO - 2016-06-13 15:28:51 --> Router Class Initialized
INFO - 2016-06-13 15:28:51 --> Output Class Initialized
INFO - 2016-06-13 15:28:51 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:51 --> Input Class Initialized
INFO - 2016-06-13 15:28:51 --> Language Class Initialized
INFO - 2016-06-13 15:28:51 --> Loader Class Initialized
INFO - 2016-06-13 15:28:51 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:51 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:51 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:51 --> Email Class Initialized
INFO - 2016-06-13 15:28:51 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:51 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:51 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:51 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:51 --> Model Class Initialized
INFO - 2016-06-13 15:28:51 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:51 --> Controller Class Initialized
INFO - 2016-06-13 15:28:51 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:51 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:51 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:51 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:52 --> Model Class Initialized
INFO - 2016-06-13 15:28:52 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:52 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:52 --> Total execution time: 0.0623
INFO - 2016-06-13 15:28:55 --> Config Class Initialized
INFO - 2016-06-13 15:28:55 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:55 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:55 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:55 --> URI Class Initialized
INFO - 2016-06-13 15:28:55 --> Router Class Initialized
INFO - 2016-06-13 15:28:55 --> Output Class Initialized
INFO - 2016-06-13 15:28:55 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:55 --> Input Class Initialized
INFO - 2016-06-13 15:28:55 --> Language Class Initialized
INFO - 2016-06-13 15:28:55 --> Loader Class Initialized
INFO - 2016-06-13 15:28:55 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:55 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:55 --> Email Class Initialized
INFO - 2016-06-13 15:28:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:55 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:55 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:55 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:55 --> Model Class Initialized
INFO - 2016-06-13 15:28:55 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:55 --> Controller Class Initialized
INFO - 2016-06-13 15:28:55 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:55 --> Model Class Initialized
INFO - 2016-06-13 15:28:55 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:28:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:28:55 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:55 --> Total execution time: 0.0868
INFO - 2016-06-13 15:28:56 --> Config Class Initialized
INFO - 2016-06-13 15:28:56 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:28:56 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:28:56 --> Utf8 Class Initialized
INFO - 2016-06-13 15:28:56 --> URI Class Initialized
INFO - 2016-06-13 15:28:56 --> Router Class Initialized
INFO - 2016-06-13 15:28:56 --> Output Class Initialized
INFO - 2016-06-13 15:28:56 --> Security Class Initialized
DEBUG - 2016-06-13 15:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:28:56 --> Input Class Initialized
INFO - 2016-06-13 15:28:56 --> Language Class Initialized
INFO - 2016-06-13 15:28:56 --> Loader Class Initialized
INFO - 2016-06-13 15:28:56 --> Helper loaded: form_helper
INFO - 2016-06-13 15:28:56 --> Database Driver Class Initialized
INFO - 2016-06-13 15:28:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:28:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:28:56 --> Email Class Initialized
INFO - 2016-06-13 15:28:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:28:56 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:28:56 --> Helper loaded: language_helper
INFO - 2016-06-13 15:28:56 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:28:56 --> Model Class Initialized
INFO - 2016-06-13 15:28:56 --> Helper loaded: date_helper
INFO - 2016-06-13 15:28:56 --> Controller Class Initialized
INFO - 2016-06-13 15:28:56 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:28:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:28:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:28:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:28:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:28:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:28:56 --> Model Class Initialized
INFO - 2016-06-13 15:28:56 --> Form Validation Class Initialized
INFO - 2016-06-13 15:28:56 --> Final output sent to browser
DEBUG - 2016-06-13 15:28:56 --> Total execution time: 0.0560
INFO - 2016-06-13 15:29:46 --> Config Class Initialized
INFO - 2016-06-13 15:29:46 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:29:46 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:29:46 --> Utf8 Class Initialized
INFO - 2016-06-13 15:29:46 --> URI Class Initialized
INFO - 2016-06-13 15:29:46 --> Router Class Initialized
INFO - 2016-06-13 15:29:46 --> Output Class Initialized
INFO - 2016-06-13 15:29:46 --> Security Class Initialized
DEBUG - 2016-06-13 15:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:29:46 --> Input Class Initialized
INFO - 2016-06-13 15:29:46 --> Language Class Initialized
INFO - 2016-06-13 15:29:46 --> Loader Class Initialized
INFO - 2016-06-13 15:29:46 --> Helper loaded: form_helper
INFO - 2016-06-13 15:29:46 --> Database Driver Class Initialized
INFO - 2016-06-13 15:29:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:29:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:29:46 --> Email Class Initialized
INFO - 2016-06-13 15:29:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:29:46 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:29:46 --> Helper loaded: language_helper
INFO - 2016-06-13 15:29:46 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:29:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:29:46 --> Model Class Initialized
INFO - 2016-06-13 15:29:46 --> Helper loaded: date_helper
INFO - 2016-06-13 15:29:46 --> Controller Class Initialized
INFO - 2016-06-13 15:29:46 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:29:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:29:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:29:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:29:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:29:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:29:46 --> Model Class Initialized
INFO - 2016-06-13 15:29:46 --> Form Validation Class Initialized
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:29:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:29:46 --> Final output sent to browser
DEBUG - 2016-06-13 15:29:46 --> Total execution time: 0.1343
INFO - 2016-06-13 15:29:48 --> Config Class Initialized
INFO - 2016-06-13 15:29:48 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:29:48 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:29:48 --> Utf8 Class Initialized
INFO - 2016-06-13 15:29:48 --> URI Class Initialized
INFO - 2016-06-13 15:29:48 --> Router Class Initialized
INFO - 2016-06-13 15:29:48 --> Output Class Initialized
INFO - 2016-06-13 15:29:48 --> Security Class Initialized
DEBUG - 2016-06-13 15:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:29:48 --> Input Class Initialized
INFO - 2016-06-13 15:29:48 --> Language Class Initialized
INFO - 2016-06-13 15:29:48 --> Loader Class Initialized
INFO - 2016-06-13 15:29:48 --> Helper loaded: form_helper
INFO - 2016-06-13 15:29:48 --> Database Driver Class Initialized
INFO - 2016-06-13 15:29:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:29:48 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:29:48 --> Email Class Initialized
INFO - 2016-06-13 15:29:48 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:29:48 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:29:48 --> Helper loaded: language_helper
INFO - 2016-06-13 15:29:48 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:29:48 --> Model Class Initialized
INFO - 2016-06-13 15:29:48 --> Helper loaded: date_helper
INFO - 2016-06-13 15:29:48 --> Controller Class Initialized
INFO - 2016-06-13 15:29:48 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:29:48 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:29:48 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:29:48 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:29:48 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:29:48 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:29:48 --> Model Class Initialized
INFO - 2016-06-13 15:29:48 --> Form Validation Class Initialized
INFO - 2016-06-13 15:29:48 --> Final output sent to browser
DEBUG - 2016-06-13 15:29:48 --> Total execution time: 0.0540
INFO - 2016-06-13 15:31:52 --> Config Class Initialized
INFO - 2016-06-13 15:31:52 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:31:52 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:31:52 --> Utf8 Class Initialized
INFO - 2016-06-13 15:31:52 --> URI Class Initialized
INFO - 2016-06-13 15:31:52 --> Router Class Initialized
INFO - 2016-06-13 15:31:52 --> Output Class Initialized
INFO - 2016-06-13 15:31:52 --> Security Class Initialized
DEBUG - 2016-06-13 15:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:31:52 --> Input Class Initialized
INFO - 2016-06-13 15:31:52 --> Language Class Initialized
INFO - 2016-06-13 15:31:52 --> Loader Class Initialized
INFO - 2016-06-13 15:31:52 --> Helper loaded: form_helper
INFO - 2016-06-13 15:31:52 --> Database Driver Class Initialized
INFO - 2016-06-13 15:31:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:31:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:31:52 --> Email Class Initialized
INFO - 2016-06-13 15:31:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:31:52 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:31:52 --> Helper loaded: language_helper
INFO - 2016-06-13 15:31:52 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:31:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:31:52 --> Model Class Initialized
INFO - 2016-06-13 15:31:52 --> Helper loaded: date_helper
INFO - 2016-06-13 15:31:52 --> Controller Class Initialized
INFO - 2016-06-13 15:31:52 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:31:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:31:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:31:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:31:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:31:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:31:52 --> Model Class Initialized
INFO - 2016-06-13 15:31:52 --> Form Validation Class Initialized
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:31:52 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:31:52 --> Final output sent to browser
DEBUG - 2016-06-13 15:31:52 --> Total execution time: 0.1194
INFO - 2016-06-13 15:31:54 --> Config Class Initialized
INFO - 2016-06-13 15:31:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:31:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:31:54 --> Utf8 Class Initialized
INFO - 2016-06-13 15:31:54 --> URI Class Initialized
INFO - 2016-06-13 15:31:54 --> Router Class Initialized
INFO - 2016-06-13 15:31:54 --> Output Class Initialized
INFO - 2016-06-13 15:31:54 --> Security Class Initialized
DEBUG - 2016-06-13 15:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:31:54 --> Input Class Initialized
INFO - 2016-06-13 15:31:54 --> Language Class Initialized
INFO - 2016-06-13 15:31:54 --> Loader Class Initialized
INFO - 2016-06-13 15:31:54 --> Helper loaded: form_helper
INFO - 2016-06-13 15:31:54 --> Database Driver Class Initialized
INFO - 2016-06-13 15:31:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:31:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:31:54 --> Email Class Initialized
INFO - 2016-06-13 15:31:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:31:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:31:54 --> Helper loaded: language_helper
INFO - 2016-06-13 15:31:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:31:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:31:54 --> Model Class Initialized
INFO - 2016-06-13 15:31:54 --> Helper loaded: date_helper
INFO - 2016-06-13 15:31:54 --> Controller Class Initialized
INFO - 2016-06-13 15:31:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:31:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:31:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:31:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:31:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:31:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:31:54 --> Model Class Initialized
INFO - 2016-06-13 15:31:54 --> Form Validation Class Initialized
INFO - 2016-06-13 15:31:54 --> Final output sent to browser
DEBUG - 2016-06-13 15:31:54 --> Total execution time: 0.0453
INFO - 2016-06-13 15:32:04 --> Config Class Initialized
INFO - 2016-06-13 15:32:04 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:32:04 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:32:04 --> Utf8 Class Initialized
INFO - 2016-06-13 15:32:04 --> URI Class Initialized
INFO - 2016-06-13 15:32:04 --> Router Class Initialized
INFO - 2016-06-13 15:32:04 --> Output Class Initialized
INFO - 2016-06-13 15:32:04 --> Security Class Initialized
DEBUG - 2016-06-13 15:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:32:04 --> Input Class Initialized
INFO - 2016-06-13 15:32:04 --> Language Class Initialized
INFO - 2016-06-13 15:32:04 --> Loader Class Initialized
INFO - 2016-06-13 15:32:04 --> Helper loaded: form_helper
INFO - 2016-06-13 15:32:04 --> Database Driver Class Initialized
INFO - 2016-06-13 15:32:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:32:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:32:04 --> Email Class Initialized
INFO - 2016-06-13 15:32:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:32:04 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:32:04 --> Helper loaded: language_helper
INFO - 2016-06-13 15:32:04 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:32:04 --> Model Class Initialized
INFO - 2016-06-13 15:32:04 --> Helper loaded: date_helper
INFO - 2016-06-13 15:32:04 --> Controller Class Initialized
INFO - 2016-06-13 15:32:04 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:32:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:32:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:32:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:32:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:32:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:32:04 --> Model Class Initialized
INFO - 2016-06-13 15:32:04 --> Form Validation Class Initialized
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:32:04 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:32:04 --> Final output sent to browser
DEBUG - 2016-06-13 15:32:04 --> Total execution time: 0.1392
INFO - 2016-06-13 15:32:05 --> Config Class Initialized
INFO - 2016-06-13 15:32:05 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:32:05 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:32:05 --> Utf8 Class Initialized
INFO - 2016-06-13 15:32:05 --> URI Class Initialized
INFO - 2016-06-13 15:32:05 --> Router Class Initialized
INFO - 2016-06-13 15:32:05 --> Output Class Initialized
INFO - 2016-06-13 15:32:05 --> Security Class Initialized
DEBUG - 2016-06-13 15:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:32:05 --> Input Class Initialized
INFO - 2016-06-13 15:32:05 --> Language Class Initialized
INFO - 2016-06-13 15:32:05 --> Loader Class Initialized
INFO - 2016-06-13 15:32:05 --> Helper loaded: form_helper
INFO - 2016-06-13 15:32:05 --> Database Driver Class Initialized
INFO - 2016-06-13 15:32:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:32:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:32:05 --> Email Class Initialized
INFO - 2016-06-13 15:32:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:32:05 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:32:05 --> Helper loaded: language_helper
INFO - 2016-06-13 15:32:05 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:32:05 --> Model Class Initialized
INFO - 2016-06-13 15:32:05 --> Helper loaded: date_helper
INFO - 2016-06-13 15:32:05 --> Controller Class Initialized
INFO - 2016-06-13 15:32:05 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:32:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:32:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:32:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:32:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:32:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:32:05 --> Model Class Initialized
INFO - 2016-06-13 15:32:05 --> Form Validation Class Initialized
INFO - 2016-06-13 15:32:05 --> Final output sent to browser
DEBUG - 2016-06-13 15:32:05 --> Total execution time: 0.0255
INFO - 2016-06-13 15:32:15 --> Config Class Initialized
INFO - 2016-06-13 15:32:15 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:32:15 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:32:15 --> Utf8 Class Initialized
INFO - 2016-06-13 15:32:15 --> URI Class Initialized
INFO - 2016-06-13 15:32:15 --> Router Class Initialized
INFO - 2016-06-13 15:32:15 --> Output Class Initialized
INFO - 2016-06-13 15:32:15 --> Security Class Initialized
DEBUG - 2016-06-13 15:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:32:15 --> Input Class Initialized
INFO - 2016-06-13 15:32:15 --> Language Class Initialized
INFO - 2016-06-13 15:32:15 --> Loader Class Initialized
INFO - 2016-06-13 15:32:15 --> Helper loaded: form_helper
INFO - 2016-06-13 15:32:15 --> Database Driver Class Initialized
INFO - 2016-06-13 15:32:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:32:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:32:15 --> Email Class Initialized
INFO - 2016-06-13 15:32:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:32:15 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:32:15 --> Helper loaded: language_helper
INFO - 2016-06-13 15:32:15 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:32:15 --> Model Class Initialized
INFO - 2016-06-13 15:32:15 --> Helper loaded: date_helper
INFO - 2016-06-13 15:32:15 --> Controller Class Initialized
INFO - 2016-06-13 15:32:15 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:32:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:32:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:32:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:32:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:32:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:32:15 --> Model Class Initialized
INFO - 2016-06-13 15:32:15 --> Form Validation Class Initialized
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:32:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:32:15 --> Final output sent to browser
DEBUG - 2016-06-13 15:32:15 --> Total execution time: 0.0451
INFO - 2016-06-13 15:32:16 --> Config Class Initialized
INFO - 2016-06-13 15:32:16 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:32:16 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:32:16 --> Utf8 Class Initialized
INFO - 2016-06-13 15:32:16 --> URI Class Initialized
INFO - 2016-06-13 15:32:16 --> Router Class Initialized
INFO - 2016-06-13 15:32:16 --> Output Class Initialized
INFO - 2016-06-13 15:32:16 --> Security Class Initialized
DEBUG - 2016-06-13 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:32:16 --> Input Class Initialized
INFO - 2016-06-13 15:32:16 --> Language Class Initialized
INFO - 2016-06-13 15:32:16 --> Loader Class Initialized
INFO - 2016-06-13 15:32:16 --> Helper loaded: form_helper
INFO - 2016-06-13 15:32:16 --> Database Driver Class Initialized
INFO - 2016-06-13 15:32:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:32:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:32:16 --> Email Class Initialized
INFO - 2016-06-13 15:32:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:32:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:32:16 --> Helper loaded: language_helper
INFO - 2016-06-13 15:32:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:32:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:32:16 --> Model Class Initialized
INFO - 2016-06-13 15:32:16 --> Helper loaded: date_helper
INFO - 2016-06-13 15:32:16 --> Controller Class Initialized
INFO - 2016-06-13 15:32:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:32:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:32:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:32:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:32:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:32:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:32:16 --> Model Class Initialized
INFO - 2016-06-13 15:32:16 --> Form Validation Class Initialized
INFO - 2016-06-13 15:32:16 --> Final output sent to browser
DEBUG - 2016-06-13 15:32:16 --> Total execution time: 0.0404
INFO - 2016-06-13 15:33:36 --> Config Class Initialized
INFO - 2016-06-13 15:33:36 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:33:36 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:33:36 --> Utf8 Class Initialized
INFO - 2016-06-13 15:33:36 --> URI Class Initialized
INFO - 2016-06-13 15:33:36 --> Router Class Initialized
INFO - 2016-06-13 15:33:36 --> Output Class Initialized
INFO - 2016-06-13 15:33:36 --> Security Class Initialized
DEBUG - 2016-06-13 15:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:33:36 --> Input Class Initialized
INFO - 2016-06-13 15:33:36 --> Language Class Initialized
INFO - 2016-06-13 15:33:36 --> Loader Class Initialized
INFO - 2016-06-13 15:33:36 --> Helper loaded: form_helper
INFO - 2016-06-13 15:33:36 --> Database Driver Class Initialized
INFO - 2016-06-13 15:33:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:33:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:33:36 --> Email Class Initialized
INFO - 2016-06-13 15:33:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:33:36 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:33:36 --> Helper loaded: language_helper
INFO - 2016-06-13 15:33:36 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:33:36 --> Model Class Initialized
INFO - 2016-06-13 15:33:36 --> Helper loaded: date_helper
INFO - 2016-06-13 15:33:36 --> Controller Class Initialized
INFO - 2016-06-13 15:33:36 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:33:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:33:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:33:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:33:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:33:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:33:36 --> Model Class Initialized
INFO - 2016-06-13 15:33:36 --> Form Validation Class Initialized
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:33:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:33:36 --> Final output sent to browser
DEBUG - 2016-06-13 15:33:36 --> Total execution time: 0.1042
INFO - 2016-06-13 15:33:38 --> Config Class Initialized
INFO - 2016-06-13 15:33:38 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:33:38 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:33:38 --> Utf8 Class Initialized
INFO - 2016-06-13 15:33:38 --> URI Class Initialized
INFO - 2016-06-13 15:33:38 --> Router Class Initialized
INFO - 2016-06-13 15:33:38 --> Output Class Initialized
INFO - 2016-06-13 15:33:38 --> Security Class Initialized
DEBUG - 2016-06-13 15:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:33:38 --> Input Class Initialized
INFO - 2016-06-13 15:33:38 --> Language Class Initialized
INFO - 2016-06-13 15:33:38 --> Loader Class Initialized
INFO - 2016-06-13 15:33:38 --> Helper loaded: form_helper
INFO - 2016-06-13 15:33:38 --> Database Driver Class Initialized
INFO - 2016-06-13 15:33:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:33:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:33:38 --> Email Class Initialized
INFO - 2016-06-13 15:33:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:33:38 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:33:38 --> Helper loaded: language_helper
INFO - 2016-06-13 15:33:38 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:33:38 --> Model Class Initialized
INFO - 2016-06-13 15:33:38 --> Helper loaded: date_helper
INFO - 2016-06-13 15:33:38 --> Controller Class Initialized
INFO - 2016-06-13 15:33:38 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:33:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:33:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:33:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:33:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:33:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:33:38 --> Model Class Initialized
INFO - 2016-06-13 15:33:38 --> Form Validation Class Initialized
INFO - 2016-06-13 15:33:38 --> Final output sent to browser
DEBUG - 2016-06-13 15:33:38 --> Total execution time: 0.0460
INFO - 2016-06-13 15:42:58 --> Config Class Initialized
INFO - 2016-06-13 15:42:58 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:42:58 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:42:58 --> Utf8 Class Initialized
INFO - 2016-06-13 15:42:58 --> URI Class Initialized
INFO - 2016-06-13 15:42:58 --> Router Class Initialized
INFO - 2016-06-13 15:42:58 --> Output Class Initialized
INFO - 2016-06-13 15:42:58 --> Security Class Initialized
DEBUG - 2016-06-13 15:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:42:58 --> Input Class Initialized
INFO - 2016-06-13 15:42:58 --> Language Class Initialized
INFO - 2016-06-13 15:42:58 --> Loader Class Initialized
INFO - 2016-06-13 15:42:58 --> Helper loaded: form_helper
INFO - 2016-06-13 15:42:58 --> Database Driver Class Initialized
INFO - 2016-06-13 15:42:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:42:58 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:42:58 --> Email Class Initialized
INFO - 2016-06-13 15:42:58 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:42:58 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:42:58 --> Helper loaded: language_helper
INFO - 2016-06-13 15:42:58 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:42:58 --> Model Class Initialized
INFO - 2016-06-13 15:42:58 --> Helper loaded: date_helper
INFO - 2016-06-13 15:42:58 --> Controller Class Initialized
INFO - 2016-06-13 15:42:58 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:42:58 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:42:58 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:42:58 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:42:58 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:42:58 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:42:58 --> Model Class Initialized
INFO - 2016-06-13 15:42:58 --> Form Validation Class Initialized
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:42:58 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:42:58 --> Final output sent to browser
DEBUG - 2016-06-13 15:42:58 --> Total execution time: 0.1064
INFO - 2016-06-13 15:43:00 --> Config Class Initialized
INFO - 2016-06-13 15:43:00 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:43:00 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:43:00 --> Utf8 Class Initialized
INFO - 2016-06-13 15:43:00 --> URI Class Initialized
INFO - 2016-06-13 15:43:00 --> Router Class Initialized
INFO - 2016-06-13 15:43:00 --> Output Class Initialized
INFO - 2016-06-13 15:43:00 --> Security Class Initialized
DEBUG - 2016-06-13 15:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:43:00 --> Input Class Initialized
INFO - 2016-06-13 15:43:00 --> Language Class Initialized
INFO - 2016-06-13 15:43:00 --> Loader Class Initialized
INFO - 2016-06-13 15:43:00 --> Helper loaded: form_helper
INFO - 2016-06-13 15:43:00 --> Database Driver Class Initialized
INFO - 2016-06-13 15:43:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:43:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:43:00 --> Email Class Initialized
INFO - 2016-06-13 15:43:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:43:00 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:43:00 --> Helper loaded: language_helper
INFO - 2016-06-13 15:43:00 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:43:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:43:00 --> Model Class Initialized
INFO - 2016-06-13 15:43:00 --> Helper loaded: date_helper
INFO - 2016-06-13 15:43:00 --> Controller Class Initialized
INFO - 2016-06-13 15:43:00 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:43:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:43:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:43:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:43:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:43:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:43:00 --> Model Class Initialized
INFO - 2016-06-13 15:43:00 --> Form Validation Class Initialized
INFO - 2016-06-13 15:43:00 --> Final output sent to browser
DEBUG - 2016-06-13 15:43:00 --> Total execution time: 0.0581
INFO - 2016-06-13 15:43:32 --> Config Class Initialized
INFO - 2016-06-13 15:43:32 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:43:32 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:43:32 --> Utf8 Class Initialized
INFO - 2016-06-13 15:43:32 --> URI Class Initialized
INFO - 2016-06-13 15:43:32 --> Router Class Initialized
INFO - 2016-06-13 15:43:32 --> Output Class Initialized
INFO - 2016-06-13 15:43:32 --> Security Class Initialized
DEBUG - 2016-06-13 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:43:32 --> Input Class Initialized
INFO - 2016-06-13 15:43:32 --> Language Class Initialized
INFO - 2016-06-13 15:43:32 --> Loader Class Initialized
INFO - 2016-06-13 15:43:32 --> Helper loaded: form_helper
INFO - 2016-06-13 15:43:32 --> Database Driver Class Initialized
INFO - 2016-06-13 15:43:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:43:32 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:43:32 --> Email Class Initialized
INFO - 2016-06-13 15:43:32 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:43:32 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:43:32 --> Helper loaded: language_helper
INFO - 2016-06-13 15:43:32 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:43:32 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:43:32 --> Model Class Initialized
INFO - 2016-06-13 15:43:32 --> Helper loaded: date_helper
INFO - 2016-06-13 15:43:32 --> Controller Class Initialized
INFO - 2016-06-13 15:43:32 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:43:32 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:43:32 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:43:32 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:43:32 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:43:32 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:43:32 --> Model Class Initialized
INFO - 2016-06-13 15:43:32 --> Form Validation Class Initialized
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:43:32 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:43:32 --> Final output sent to browser
DEBUG - 2016-06-13 15:43:32 --> Total execution time: 0.0977
INFO - 2016-06-13 15:43:33 --> Config Class Initialized
INFO - 2016-06-13 15:43:33 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:43:33 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:43:33 --> Utf8 Class Initialized
INFO - 2016-06-13 15:43:33 --> URI Class Initialized
INFO - 2016-06-13 15:43:33 --> Router Class Initialized
INFO - 2016-06-13 15:43:33 --> Output Class Initialized
INFO - 2016-06-13 15:43:33 --> Security Class Initialized
DEBUG - 2016-06-13 15:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:43:33 --> Input Class Initialized
INFO - 2016-06-13 15:43:33 --> Language Class Initialized
INFO - 2016-06-13 15:43:33 --> Loader Class Initialized
INFO - 2016-06-13 15:43:33 --> Helper loaded: form_helper
INFO - 2016-06-13 15:43:33 --> Database Driver Class Initialized
INFO - 2016-06-13 15:43:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:43:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:43:33 --> Email Class Initialized
INFO - 2016-06-13 15:43:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:43:33 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:43:33 --> Helper loaded: language_helper
INFO - 2016-06-13 15:43:33 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:43:33 --> Model Class Initialized
INFO - 2016-06-13 15:43:33 --> Helper loaded: date_helper
INFO - 2016-06-13 15:43:33 --> Controller Class Initialized
INFO - 2016-06-13 15:43:33 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:43:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:43:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:43:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:43:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:43:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:43:33 --> Model Class Initialized
INFO - 2016-06-13 15:43:33 --> Form Validation Class Initialized
INFO - 2016-06-13 15:43:33 --> Final output sent to browser
DEBUG - 2016-06-13 15:43:33 --> Total execution time: 0.0918
INFO - 2016-06-13 15:43:37 --> Config Class Initialized
INFO - 2016-06-13 15:43:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:43:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:43:37 --> Utf8 Class Initialized
INFO - 2016-06-13 15:43:37 --> URI Class Initialized
INFO - 2016-06-13 15:43:37 --> Router Class Initialized
INFO - 2016-06-13 15:43:37 --> Output Class Initialized
INFO - 2016-06-13 15:43:37 --> Security Class Initialized
DEBUG - 2016-06-13 15:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:43:37 --> Input Class Initialized
INFO - 2016-06-13 15:43:37 --> Language Class Initialized
INFO - 2016-06-13 15:43:37 --> Loader Class Initialized
INFO - 2016-06-13 15:43:37 --> Helper loaded: form_helper
INFO - 2016-06-13 15:43:37 --> Database Driver Class Initialized
INFO - 2016-06-13 15:43:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:43:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:43:37 --> Email Class Initialized
INFO - 2016-06-13 15:43:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:43:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:43:37 --> Helper loaded: language_helper
INFO - 2016-06-13 15:43:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:43:37 --> Model Class Initialized
INFO - 2016-06-13 15:43:37 --> Helper loaded: date_helper
INFO - 2016-06-13 15:43:37 --> Controller Class Initialized
INFO - 2016-06-13 15:43:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:43:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:43:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:43:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:43:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:43:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:43:37 --> Model Class Initialized
INFO - 2016-06-13 15:43:37 --> Form Validation Class Initialized
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:43:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:43:37 --> Final output sent to browser
DEBUG - 2016-06-13 15:43:37 --> Total execution time: 0.1030
INFO - 2016-06-13 15:43:38 --> Config Class Initialized
INFO - 2016-06-13 15:43:38 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:43:38 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:43:38 --> Utf8 Class Initialized
INFO - 2016-06-13 15:43:38 --> URI Class Initialized
INFO - 2016-06-13 15:43:38 --> Router Class Initialized
INFO - 2016-06-13 15:43:38 --> Output Class Initialized
INFO - 2016-06-13 15:43:38 --> Security Class Initialized
DEBUG - 2016-06-13 15:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:43:38 --> Input Class Initialized
INFO - 2016-06-13 15:43:38 --> Language Class Initialized
INFO - 2016-06-13 15:43:38 --> Loader Class Initialized
INFO - 2016-06-13 15:43:38 --> Helper loaded: form_helper
INFO - 2016-06-13 15:43:38 --> Database Driver Class Initialized
INFO - 2016-06-13 15:43:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:43:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:43:38 --> Email Class Initialized
INFO - 2016-06-13 15:43:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:43:38 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:43:38 --> Helper loaded: language_helper
INFO - 2016-06-13 15:43:38 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:43:38 --> Model Class Initialized
INFO - 2016-06-13 15:43:38 --> Helper loaded: date_helper
INFO - 2016-06-13 15:43:38 --> Controller Class Initialized
INFO - 2016-06-13 15:43:38 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:43:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:43:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:43:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:43:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:43:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:43:38 --> Model Class Initialized
INFO - 2016-06-13 15:43:38 --> Form Validation Class Initialized
INFO - 2016-06-13 15:43:38 --> Final output sent to browser
DEBUG - 2016-06-13 15:43:38 --> Total execution time: 0.0562
INFO - 2016-06-13 15:46:28 --> Config Class Initialized
INFO - 2016-06-13 15:46:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:28 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:28 --> URI Class Initialized
INFO - 2016-06-13 15:46:28 --> Router Class Initialized
INFO - 2016-06-13 15:46:28 --> Output Class Initialized
INFO - 2016-06-13 15:46:28 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:28 --> Input Class Initialized
INFO - 2016-06-13 15:46:28 --> Language Class Initialized
INFO - 2016-06-13 15:46:28 --> Loader Class Initialized
INFO - 2016-06-13 15:46:28 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:28 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:28 --> Email Class Initialized
INFO - 2016-06-13 15:46:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:28 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:28 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:28 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:28 --> Model Class Initialized
INFO - 2016-06-13 15:46:28 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:28 --> Controller Class Initialized
INFO - 2016-06-13 15:46:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:28 --> Model Class Initialized
INFO - 2016-06-13 15:46:28 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:46:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:46:28 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:28 --> Total execution time: 0.1250
INFO - 2016-06-13 15:46:30 --> Config Class Initialized
INFO - 2016-06-13 15:46:30 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:30 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:30 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:30 --> URI Class Initialized
INFO - 2016-06-13 15:46:30 --> Router Class Initialized
INFO - 2016-06-13 15:46:30 --> Output Class Initialized
INFO - 2016-06-13 15:46:30 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:30 --> Input Class Initialized
INFO - 2016-06-13 15:46:30 --> Language Class Initialized
INFO - 2016-06-13 15:46:30 --> Loader Class Initialized
INFO - 2016-06-13 15:46:30 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:30 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:30 --> Email Class Initialized
INFO - 2016-06-13 15:46:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:30 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:30 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:30 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:30 --> Model Class Initialized
INFO - 2016-06-13 15:46:30 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:30 --> Controller Class Initialized
INFO - 2016-06-13 15:46:30 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:30 --> Model Class Initialized
INFO - 2016-06-13 15:46:30 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:30 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:30 --> Total execution time: 0.0544
INFO - 2016-06-13 15:46:35 --> Config Class Initialized
INFO - 2016-06-13 15:46:35 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:35 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:35 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:35 --> URI Class Initialized
INFO - 2016-06-13 15:46:35 --> Router Class Initialized
INFO - 2016-06-13 15:46:35 --> Output Class Initialized
INFO - 2016-06-13 15:46:35 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:35 --> Input Class Initialized
INFO - 2016-06-13 15:46:35 --> Language Class Initialized
INFO - 2016-06-13 15:46:35 --> Loader Class Initialized
INFO - 2016-06-13 15:46:35 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:35 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:35 --> Email Class Initialized
INFO - 2016-06-13 15:46:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:35 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:35 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:35 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:35 --> Model Class Initialized
INFO - 2016-06-13 15:46:35 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:35 --> Controller Class Initialized
INFO - 2016-06-13 15:46:35 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:35 --> Model Class Initialized
INFO - 2016-06-13 15:46:35 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:46:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:46:35 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:35 --> Total execution time: 0.1051
INFO - 2016-06-13 15:46:37 --> Config Class Initialized
INFO - 2016-06-13 15:46:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:37 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:37 --> URI Class Initialized
INFO - 2016-06-13 15:46:37 --> Router Class Initialized
INFO - 2016-06-13 15:46:37 --> Output Class Initialized
INFO - 2016-06-13 15:46:37 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:37 --> Input Class Initialized
INFO - 2016-06-13 15:46:37 --> Language Class Initialized
INFO - 2016-06-13 15:46:37 --> Loader Class Initialized
INFO - 2016-06-13 15:46:37 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:37 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:37 --> Email Class Initialized
INFO - 2016-06-13 15:46:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:37 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:37 --> Model Class Initialized
INFO - 2016-06-13 15:46:37 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:37 --> Controller Class Initialized
INFO - 2016-06-13 15:46:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:37 --> Model Class Initialized
INFO - 2016-06-13 15:46:37 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:37 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:37 --> Total execution time: 0.0443
INFO - 2016-06-13 15:46:50 --> Config Class Initialized
INFO - 2016-06-13 15:46:50 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:50 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:50 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:50 --> URI Class Initialized
INFO - 2016-06-13 15:46:50 --> Router Class Initialized
INFO - 2016-06-13 15:46:50 --> Output Class Initialized
INFO - 2016-06-13 15:46:50 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:50 --> Input Class Initialized
INFO - 2016-06-13 15:46:50 --> Language Class Initialized
INFO - 2016-06-13 15:46:50 --> Loader Class Initialized
INFO - 2016-06-13 15:46:50 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:50 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:50 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:50 --> Email Class Initialized
INFO - 2016-06-13 15:46:50 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:50 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:50 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:50 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:50 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:50 --> Model Class Initialized
INFO - 2016-06-13 15:46:50 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:50 --> Controller Class Initialized
INFO - 2016-06-13 15:46:50 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:50 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:50 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:50 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:50 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:50 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:50 --> Model Class Initialized
INFO - 2016-06-13 15:46:50 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:46:50 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:46:50 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:50 --> Total execution time: 0.0989
INFO - 2016-06-13 15:46:52 --> Config Class Initialized
INFO - 2016-06-13 15:46:52 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:52 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:52 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:52 --> URI Class Initialized
INFO - 2016-06-13 15:46:52 --> Router Class Initialized
INFO - 2016-06-13 15:46:52 --> Output Class Initialized
INFO - 2016-06-13 15:46:52 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:52 --> Input Class Initialized
INFO - 2016-06-13 15:46:52 --> Language Class Initialized
INFO - 2016-06-13 15:46:52 --> Loader Class Initialized
INFO - 2016-06-13 15:46:52 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:52 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:52 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:52 --> Email Class Initialized
INFO - 2016-06-13 15:46:52 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:52 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:52 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:52 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:52 --> Model Class Initialized
INFO - 2016-06-13 15:46:52 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:52 --> Controller Class Initialized
INFO - 2016-06-13 15:46:52 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:52 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:52 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:52 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:52 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:52 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:52 --> Model Class Initialized
INFO - 2016-06-13 15:46:52 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:52 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:52 --> Total execution time: 0.1003
INFO - 2016-06-13 15:46:55 --> Config Class Initialized
INFO - 2016-06-13 15:46:55 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:55 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:55 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:55 --> URI Class Initialized
INFO - 2016-06-13 15:46:55 --> Router Class Initialized
INFO - 2016-06-13 15:46:55 --> Output Class Initialized
INFO - 2016-06-13 15:46:55 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:55 --> Input Class Initialized
INFO - 2016-06-13 15:46:55 --> Language Class Initialized
INFO - 2016-06-13 15:46:55 --> Loader Class Initialized
INFO - 2016-06-13 15:46:55 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:55 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:55 --> Email Class Initialized
INFO - 2016-06-13 15:46:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:55 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:55 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:55 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:55 --> Model Class Initialized
INFO - 2016-06-13 15:46:55 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:55 --> Controller Class Initialized
INFO - 2016-06-13 15:46:55 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:55 --> Model Class Initialized
INFO - 2016-06-13 15:46:55 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:46:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:46:55 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:55 --> Total execution time: 0.0991
INFO - 2016-06-13 15:46:56 --> Config Class Initialized
INFO - 2016-06-13 15:46:56 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:56 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:56 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:56 --> URI Class Initialized
INFO - 2016-06-13 15:46:56 --> Router Class Initialized
INFO - 2016-06-13 15:46:56 --> Output Class Initialized
INFO - 2016-06-13 15:46:56 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:56 --> Input Class Initialized
INFO - 2016-06-13 15:46:56 --> Language Class Initialized
INFO - 2016-06-13 15:46:56 --> Loader Class Initialized
INFO - 2016-06-13 15:46:56 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:56 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:56 --> Email Class Initialized
INFO - 2016-06-13 15:46:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:56 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:56 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:56 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:56 --> Model Class Initialized
INFO - 2016-06-13 15:46:56 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:56 --> Controller Class Initialized
INFO - 2016-06-13 15:46:56 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:56 --> Model Class Initialized
INFO - 2016-06-13 15:46:56 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:56 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:56 --> Total execution time: 0.0570
INFO - 2016-06-13 15:46:59 --> Config Class Initialized
INFO - 2016-06-13 15:46:59 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:46:59 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:46:59 --> Utf8 Class Initialized
INFO - 2016-06-13 15:46:59 --> URI Class Initialized
INFO - 2016-06-13 15:46:59 --> Router Class Initialized
INFO - 2016-06-13 15:46:59 --> Output Class Initialized
INFO - 2016-06-13 15:46:59 --> Security Class Initialized
DEBUG - 2016-06-13 15:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:46:59 --> Input Class Initialized
INFO - 2016-06-13 15:46:59 --> Language Class Initialized
INFO - 2016-06-13 15:46:59 --> Loader Class Initialized
INFO - 2016-06-13 15:46:59 --> Helper loaded: form_helper
INFO - 2016-06-13 15:46:59 --> Database Driver Class Initialized
INFO - 2016-06-13 15:46:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:46:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:46:59 --> Email Class Initialized
INFO - 2016-06-13 15:46:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:46:59 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:46:59 --> Helper loaded: language_helper
INFO - 2016-06-13 15:46:59 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:46:59 --> Model Class Initialized
INFO - 2016-06-13 15:46:59 --> Helper loaded: date_helper
INFO - 2016-06-13 15:46:59 --> Controller Class Initialized
INFO - 2016-06-13 15:46:59 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:46:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:46:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:46:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:46:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:46:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:46:59 --> Model Class Initialized
INFO - 2016-06-13 15:46:59 --> Form Validation Class Initialized
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:46:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:46:59 --> Final output sent to browser
DEBUG - 2016-06-13 15:46:59 --> Total execution time: 0.1003
INFO - 2016-06-13 15:47:01 --> Config Class Initialized
INFO - 2016-06-13 15:47:01 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:47:01 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:47:01 --> Utf8 Class Initialized
INFO - 2016-06-13 15:47:01 --> URI Class Initialized
INFO - 2016-06-13 15:47:01 --> Router Class Initialized
INFO - 2016-06-13 15:47:01 --> Output Class Initialized
INFO - 2016-06-13 15:47:01 --> Security Class Initialized
DEBUG - 2016-06-13 15:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:47:01 --> Input Class Initialized
INFO - 2016-06-13 15:47:01 --> Language Class Initialized
INFO - 2016-06-13 15:47:01 --> Loader Class Initialized
INFO - 2016-06-13 15:47:01 --> Helper loaded: form_helper
INFO - 2016-06-13 15:47:01 --> Database Driver Class Initialized
INFO - 2016-06-13 15:47:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:47:01 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:47:01 --> Email Class Initialized
INFO - 2016-06-13 15:47:01 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:47:01 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:47:01 --> Helper loaded: language_helper
INFO - 2016-06-13 15:47:01 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:47:01 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:47:01 --> Model Class Initialized
INFO - 2016-06-13 15:47:01 --> Helper loaded: date_helper
INFO - 2016-06-13 15:47:01 --> Controller Class Initialized
INFO - 2016-06-13 15:47:01 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:47:01 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:47:01 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:47:01 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:47:01 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:47:01 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:47:01 --> Model Class Initialized
INFO - 2016-06-13 15:47:01 --> Form Validation Class Initialized
INFO - 2016-06-13 15:47:01 --> Final output sent to browser
DEBUG - 2016-06-13 15:47:01 --> Total execution time: 0.0346
INFO - 2016-06-13 15:47:55 --> Config Class Initialized
INFO - 2016-06-13 15:47:55 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:47:55 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:47:55 --> Utf8 Class Initialized
INFO - 2016-06-13 15:47:55 --> URI Class Initialized
INFO - 2016-06-13 15:47:55 --> Router Class Initialized
INFO - 2016-06-13 15:47:55 --> Output Class Initialized
INFO - 2016-06-13 15:47:55 --> Security Class Initialized
DEBUG - 2016-06-13 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:47:55 --> Input Class Initialized
INFO - 2016-06-13 15:47:55 --> Language Class Initialized
INFO - 2016-06-13 15:47:55 --> Loader Class Initialized
INFO - 2016-06-13 15:47:55 --> Helper loaded: form_helper
INFO - 2016-06-13 15:47:55 --> Database Driver Class Initialized
INFO - 2016-06-13 15:47:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:47:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:47:55 --> Email Class Initialized
INFO - 2016-06-13 15:47:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:47:55 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:47:55 --> Helper loaded: language_helper
INFO - 2016-06-13 15:47:55 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:47:55 --> Model Class Initialized
INFO - 2016-06-13 15:47:55 --> Helper loaded: date_helper
INFO - 2016-06-13 15:47:55 --> Controller Class Initialized
INFO - 2016-06-13 15:47:55 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:47:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:47:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:47:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:47:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:47:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:47:55 --> Model Class Initialized
INFO - 2016-06-13 15:47:55 --> Form Validation Class Initialized
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:47:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:47:55 --> Final output sent to browser
DEBUG - 2016-06-13 15:47:55 --> Total execution time: 0.0947
INFO - 2016-06-13 15:47:56 --> Config Class Initialized
INFO - 2016-06-13 15:47:56 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:47:56 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:47:56 --> Utf8 Class Initialized
INFO - 2016-06-13 15:47:56 --> URI Class Initialized
INFO - 2016-06-13 15:47:56 --> Router Class Initialized
INFO - 2016-06-13 15:47:56 --> Output Class Initialized
INFO - 2016-06-13 15:47:56 --> Security Class Initialized
DEBUG - 2016-06-13 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:47:56 --> Input Class Initialized
INFO - 2016-06-13 15:47:56 --> Language Class Initialized
INFO - 2016-06-13 15:47:56 --> Loader Class Initialized
INFO - 2016-06-13 15:47:56 --> Helper loaded: form_helper
INFO - 2016-06-13 15:47:56 --> Database Driver Class Initialized
INFO - 2016-06-13 15:47:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:47:56 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:47:56 --> Email Class Initialized
INFO - 2016-06-13 15:47:56 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:47:56 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:47:56 --> Helper loaded: language_helper
INFO - 2016-06-13 15:47:56 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:47:56 --> Model Class Initialized
INFO - 2016-06-13 15:47:56 --> Helper loaded: date_helper
INFO - 2016-06-13 15:47:56 --> Controller Class Initialized
INFO - 2016-06-13 15:47:56 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:47:56 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:47:56 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:47:56 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:47:56 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:47:56 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:47:56 --> Model Class Initialized
INFO - 2016-06-13 15:47:56 --> Form Validation Class Initialized
INFO - 2016-06-13 15:47:56 --> Final output sent to browser
DEBUG - 2016-06-13 15:47:56 --> Total execution time: 0.0559
INFO - 2016-06-13 15:47:59 --> Config Class Initialized
INFO - 2016-06-13 15:47:59 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:47:59 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:47:59 --> Utf8 Class Initialized
INFO - 2016-06-13 15:47:59 --> URI Class Initialized
INFO - 2016-06-13 15:47:59 --> Router Class Initialized
INFO - 2016-06-13 15:47:59 --> Output Class Initialized
INFO - 2016-06-13 15:47:59 --> Security Class Initialized
DEBUG - 2016-06-13 15:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:47:59 --> Input Class Initialized
INFO - 2016-06-13 15:47:59 --> Language Class Initialized
INFO - 2016-06-13 15:47:59 --> Loader Class Initialized
INFO - 2016-06-13 15:47:59 --> Helper loaded: form_helper
INFO - 2016-06-13 15:47:59 --> Database Driver Class Initialized
INFO - 2016-06-13 15:47:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:47:59 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:47:59 --> Email Class Initialized
INFO - 2016-06-13 15:47:59 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:47:59 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:47:59 --> Helper loaded: language_helper
INFO - 2016-06-13 15:47:59 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:47:59 --> Model Class Initialized
INFO - 2016-06-13 15:47:59 --> Helper loaded: date_helper
INFO - 2016-06-13 15:47:59 --> Controller Class Initialized
INFO - 2016-06-13 15:47:59 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:47:59 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:47:59 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:47:59 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:47:59 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:47:59 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:47:59 --> Model Class Initialized
INFO - 2016-06-13 15:47:59 --> Form Validation Class Initialized
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:47:59 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:47:59 --> Final output sent to browser
DEBUG - 2016-06-13 15:47:59 --> Total execution time: 0.0956
INFO - 2016-06-13 15:48:00 --> Config Class Initialized
INFO - 2016-06-13 15:48:00 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:48:00 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:48:00 --> Utf8 Class Initialized
INFO - 2016-06-13 15:48:00 --> URI Class Initialized
INFO - 2016-06-13 15:48:00 --> Router Class Initialized
INFO - 2016-06-13 15:48:00 --> Output Class Initialized
INFO - 2016-06-13 15:48:00 --> Security Class Initialized
DEBUG - 2016-06-13 15:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:48:00 --> Input Class Initialized
INFO - 2016-06-13 15:48:00 --> Language Class Initialized
INFO - 2016-06-13 15:48:00 --> Loader Class Initialized
INFO - 2016-06-13 15:48:00 --> Helper loaded: form_helper
INFO - 2016-06-13 15:48:00 --> Database Driver Class Initialized
INFO - 2016-06-13 15:48:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:48:00 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:48:00 --> Email Class Initialized
INFO - 2016-06-13 15:48:00 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:48:00 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:48:00 --> Helper loaded: language_helper
INFO - 2016-06-13 15:48:00 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:48:00 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:48:00 --> Model Class Initialized
INFO - 2016-06-13 15:48:00 --> Helper loaded: date_helper
INFO - 2016-06-13 15:48:00 --> Controller Class Initialized
INFO - 2016-06-13 15:48:00 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:48:00 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:48:00 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:48:00 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:48:00 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:48:00 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:48:00 --> Model Class Initialized
INFO - 2016-06-13 15:48:00 --> Form Validation Class Initialized
INFO - 2016-06-13 15:48:00 --> Final output sent to browser
DEBUG - 2016-06-13 15:48:00 --> Total execution time: 0.0240
INFO - 2016-06-13 15:48:03 --> Config Class Initialized
INFO - 2016-06-13 15:48:03 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:48:03 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:48:03 --> Utf8 Class Initialized
INFO - 2016-06-13 15:48:03 --> URI Class Initialized
INFO - 2016-06-13 15:48:03 --> Router Class Initialized
INFO - 2016-06-13 15:48:03 --> Output Class Initialized
INFO - 2016-06-13 15:48:03 --> Security Class Initialized
DEBUG - 2016-06-13 15:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:48:03 --> Input Class Initialized
INFO - 2016-06-13 15:48:03 --> Language Class Initialized
INFO - 2016-06-13 15:48:03 --> Loader Class Initialized
INFO - 2016-06-13 15:48:03 --> Helper loaded: form_helper
INFO - 2016-06-13 15:48:03 --> Database Driver Class Initialized
INFO - 2016-06-13 15:48:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:48:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:48:03 --> Email Class Initialized
INFO - 2016-06-13 15:48:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:48:03 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:48:03 --> Helper loaded: language_helper
INFO - 2016-06-13 15:48:03 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:48:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:48:03 --> Model Class Initialized
INFO - 2016-06-13 15:48:03 --> Helper loaded: date_helper
INFO - 2016-06-13 15:48:03 --> Controller Class Initialized
INFO - 2016-06-13 15:48:03 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:48:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:48:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:48:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:48:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:48:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:48:03 --> Model Class Initialized
INFO - 2016-06-13 15:48:03 --> Form Validation Class Initialized
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:48:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:48:03 --> Final output sent to browser
DEBUG - 2016-06-13 15:48:03 --> Total execution time: 0.0293
INFO - 2016-06-13 15:48:05 --> Config Class Initialized
INFO - 2016-06-13 15:48:05 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:48:05 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:48:05 --> Utf8 Class Initialized
INFO - 2016-06-13 15:48:05 --> URI Class Initialized
INFO - 2016-06-13 15:48:05 --> Router Class Initialized
INFO - 2016-06-13 15:48:05 --> Output Class Initialized
INFO - 2016-06-13 15:48:05 --> Security Class Initialized
DEBUG - 2016-06-13 15:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:48:05 --> Input Class Initialized
INFO - 2016-06-13 15:48:05 --> Language Class Initialized
INFO - 2016-06-13 15:48:05 --> Loader Class Initialized
INFO - 2016-06-13 15:48:05 --> Helper loaded: form_helper
INFO - 2016-06-13 15:48:05 --> Database Driver Class Initialized
INFO - 2016-06-13 15:48:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:48:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:48:05 --> Email Class Initialized
INFO - 2016-06-13 15:48:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:48:05 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:48:05 --> Helper loaded: language_helper
INFO - 2016-06-13 15:48:05 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:48:05 --> Model Class Initialized
INFO - 2016-06-13 15:48:05 --> Helper loaded: date_helper
INFO - 2016-06-13 15:48:05 --> Controller Class Initialized
INFO - 2016-06-13 15:48:05 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:48:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:48:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:48:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:48:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:48:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:48:05 --> Model Class Initialized
INFO - 2016-06-13 15:48:05 --> Form Validation Class Initialized
INFO - 2016-06-13 15:48:05 --> Final output sent to browser
DEBUG - 2016-06-13 15:48:05 --> Total execution time: 0.0554
INFO - 2016-06-13 15:48:08 --> Config Class Initialized
INFO - 2016-06-13 15:48:08 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:48:08 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:48:08 --> Utf8 Class Initialized
INFO - 2016-06-13 15:48:08 --> URI Class Initialized
INFO - 2016-06-13 15:48:08 --> Router Class Initialized
INFO - 2016-06-13 15:48:08 --> Output Class Initialized
INFO - 2016-06-13 15:48:08 --> Security Class Initialized
DEBUG - 2016-06-13 15:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:48:08 --> Input Class Initialized
INFO - 2016-06-13 15:48:08 --> Language Class Initialized
INFO - 2016-06-13 15:48:08 --> Loader Class Initialized
INFO - 2016-06-13 15:48:08 --> Helper loaded: form_helper
INFO - 2016-06-13 15:48:08 --> Database Driver Class Initialized
INFO - 2016-06-13 15:48:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:48:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:48:08 --> Email Class Initialized
INFO - 2016-06-13 15:48:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:48:08 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:48:08 --> Helper loaded: language_helper
INFO - 2016-06-13 15:48:08 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:48:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:48:08 --> Model Class Initialized
INFO - 2016-06-13 15:48:08 --> Helper loaded: date_helper
INFO - 2016-06-13 15:48:08 --> Controller Class Initialized
INFO - 2016-06-13 15:48:08 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:48:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:48:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:48:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:48:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:48:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:48:08 --> Model Class Initialized
INFO - 2016-06-13 15:48:08 --> Form Validation Class Initialized
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:48:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:48:08 --> Final output sent to browser
DEBUG - 2016-06-13 15:48:08 --> Total execution time: 0.0340
INFO - 2016-06-13 15:48:09 --> Config Class Initialized
INFO - 2016-06-13 15:48:09 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:48:09 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:48:09 --> Utf8 Class Initialized
INFO - 2016-06-13 15:48:09 --> URI Class Initialized
INFO - 2016-06-13 15:48:09 --> Router Class Initialized
INFO - 2016-06-13 15:48:09 --> Output Class Initialized
INFO - 2016-06-13 15:48:09 --> Security Class Initialized
DEBUG - 2016-06-13 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:48:09 --> Input Class Initialized
INFO - 2016-06-13 15:48:09 --> Language Class Initialized
INFO - 2016-06-13 15:48:09 --> Loader Class Initialized
INFO - 2016-06-13 15:48:09 --> Helper loaded: form_helper
INFO - 2016-06-13 15:48:09 --> Database Driver Class Initialized
INFO - 2016-06-13 15:48:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:48:09 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:48:09 --> Email Class Initialized
INFO - 2016-06-13 15:48:09 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:48:09 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:48:09 --> Helper loaded: language_helper
INFO - 2016-06-13 15:48:09 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:48:09 --> Model Class Initialized
INFO - 2016-06-13 15:48:09 --> Helper loaded: date_helper
INFO - 2016-06-13 15:48:09 --> Controller Class Initialized
INFO - 2016-06-13 15:48:09 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:48:09 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:48:09 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:48:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:48:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:48:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:48:10 --> Model Class Initialized
INFO - 2016-06-13 15:48:10 --> Form Validation Class Initialized
INFO - 2016-06-13 15:48:10 --> Final output sent to browser
DEBUG - 2016-06-13 15:48:10 --> Total execution time: 0.0331
INFO - 2016-06-13 15:49:02 --> Config Class Initialized
INFO - 2016-06-13 15:49:02 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:49:02 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:49:02 --> Utf8 Class Initialized
INFO - 2016-06-13 15:49:02 --> URI Class Initialized
INFO - 2016-06-13 15:49:02 --> Router Class Initialized
INFO - 2016-06-13 15:49:02 --> Output Class Initialized
INFO - 2016-06-13 15:49:02 --> Security Class Initialized
DEBUG - 2016-06-13 15:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:49:02 --> Input Class Initialized
INFO - 2016-06-13 15:49:02 --> Language Class Initialized
INFO - 2016-06-13 15:49:02 --> Loader Class Initialized
INFO - 2016-06-13 15:49:02 --> Helper loaded: form_helper
INFO - 2016-06-13 15:49:02 --> Database Driver Class Initialized
INFO - 2016-06-13 15:49:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:49:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:49:02 --> Email Class Initialized
INFO - 2016-06-13 15:49:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:49:02 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:49:02 --> Helper loaded: language_helper
INFO - 2016-06-13 15:49:02 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:49:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:49:02 --> Model Class Initialized
INFO - 2016-06-13 15:49:02 --> Helper loaded: date_helper
INFO - 2016-06-13 15:49:02 --> Controller Class Initialized
INFO - 2016-06-13 15:49:02 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:49:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:49:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:49:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:49:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:49:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:49:02 --> Model Class Initialized
INFO - 2016-06-13 15:49:02 --> Form Validation Class Initialized
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:49:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:49:03 --> Final output sent to browser
DEBUG - 2016-06-13 15:49:03 --> Total execution time: 0.0901
INFO - 2016-06-13 15:49:04 --> Config Class Initialized
INFO - 2016-06-13 15:49:04 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:49:04 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:49:04 --> Utf8 Class Initialized
INFO - 2016-06-13 15:49:04 --> URI Class Initialized
INFO - 2016-06-13 15:49:04 --> Router Class Initialized
INFO - 2016-06-13 15:49:04 --> Output Class Initialized
INFO - 2016-06-13 15:49:04 --> Security Class Initialized
DEBUG - 2016-06-13 15:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:49:04 --> Input Class Initialized
INFO - 2016-06-13 15:49:04 --> Language Class Initialized
INFO - 2016-06-13 15:49:04 --> Loader Class Initialized
INFO - 2016-06-13 15:49:04 --> Helper loaded: form_helper
INFO - 2016-06-13 15:49:04 --> Database Driver Class Initialized
INFO - 2016-06-13 15:49:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:49:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:49:04 --> Email Class Initialized
INFO - 2016-06-13 15:49:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:49:04 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:49:04 --> Helper loaded: language_helper
INFO - 2016-06-13 15:49:04 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:49:04 --> Model Class Initialized
INFO - 2016-06-13 15:49:04 --> Helper loaded: date_helper
INFO - 2016-06-13 15:49:04 --> Controller Class Initialized
INFO - 2016-06-13 15:49:04 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:49:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:49:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:49:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:49:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:49:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:49:04 --> Model Class Initialized
INFO - 2016-06-13 15:49:04 --> Form Validation Class Initialized
INFO - 2016-06-13 15:49:04 --> Final output sent to browser
DEBUG - 2016-06-13 15:49:04 --> Total execution time: 0.0160
INFO - 2016-06-13 15:50:46 --> Config Class Initialized
INFO - 2016-06-13 15:50:46 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:50:46 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:50:46 --> Utf8 Class Initialized
INFO - 2016-06-13 15:50:46 --> URI Class Initialized
INFO - 2016-06-13 15:50:46 --> Router Class Initialized
INFO - 2016-06-13 15:50:46 --> Output Class Initialized
INFO - 2016-06-13 15:50:46 --> Security Class Initialized
DEBUG - 2016-06-13 15:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:50:46 --> Input Class Initialized
INFO - 2016-06-13 15:50:46 --> Language Class Initialized
INFO - 2016-06-13 15:50:46 --> Loader Class Initialized
INFO - 2016-06-13 15:50:46 --> Helper loaded: form_helper
INFO - 2016-06-13 15:50:46 --> Database Driver Class Initialized
INFO - 2016-06-13 15:50:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:50:46 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:50:46 --> Email Class Initialized
INFO - 2016-06-13 15:50:46 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:50:46 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:50:46 --> Helper loaded: language_helper
INFO - 2016-06-13 15:50:46 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:50:46 --> Model Class Initialized
INFO - 2016-06-13 15:50:46 --> Helper loaded: date_helper
INFO - 2016-06-13 15:50:46 --> Controller Class Initialized
INFO - 2016-06-13 15:50:46 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:50:46 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:50:46 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:50:46 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:50:46 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:50:46 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:50:46 --> Model Class Initialized
INFO - 2016-06-13 15:50:46 --> Form Validation Class Initialized
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
ERROR - 2016-06-13 15:50:46 --> Could not find the language line "1"
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:50:46 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:50:46 --> Final output sent to browser
DEBUG - 2016-06-13 15:50:46 --> Total execution time: 0.0606
INFO - 2016-06-13 15:50:47 --> Config Class Initialized
INFO - 2016-06-13 15:50:47 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:50:47 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:50:47 --> Utf8 Class Initialized
INFO - 2016-06-13 15:50:47 --> URI Class Initialized
INFO - 2016-06-13 15:50:47 --> Router Class Initialized
INFO - 2016-06-13 15:50:47 --> Output Class Initialized
INFO - 2016-06-13 15:50:47 --> Security Class Initialized
DEBUG - 2016-06-13 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:50:47 --> Input Class Initialized
INFO - 2016-06-13 15:50:47 --> Language Class Initialized
INFO - 2016-06-13 15:50:47 --> Loader Class Initialized
INFO - 2016-06-13 15:50:47 --> Helper loaded: form_helper
INFO - 2016-06-13 15:50:47 --> Database Driver Class Initialized
INFO - 2016-06-13 15:50:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:50:47 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:50:47 --> Email Class Initialized
INFO - 2016-06-13 15:50:47 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:50:47 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:50:47 --> Helper loaded: language_helper
INFO - 2016-06-13 15:50:47 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:50:47 --> Model Class Initialized
INFO - 2016-06-13 15:50:47 --> Helper loaded: date_helper
INFO - 2016-06-13 15:50:47 --> Controller Class Initialized
INFO - 2016-06-13 15:50:47 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:50:47 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:50:47 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:50:47 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:50:47 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:50:47 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:50:47 --> Model Class Initialized
INFO - 2016-06-13 15:50:47 --> Form Validation Class Initialized
INFO - 2016-06-13 15:50:47 --> Final output sent to browser
DEBUG - 2016-06-13 15:50:47 --> Total execution time: 0.0314
INFO - 2016-06-13 15:51:15 --> Config Class Initialized
INFO - 2016-06-13 15:51:15 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:51:15 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:51:15 --> Utf8 Class Initialized
INFO - 2016-06-13 15:51:15 --> URI Class Initialized
INFO - 2016-06-13 15:51:15 --> Router Class Initialized
INFO - 2016-06-13 15:51:15 --> Output Class Initialized
INFO - 2016-06-13 15:51:15 --> Security Class Initialized
DEBUG - 2016-06-13 15:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:51:15 --> Input Class Initialized
INFO - 2016-06-13 15:51:15 --> Language Class Initialized
INFO - 2016-06-13 15:51:15 --> Loader Class Initialized
INFO - 2016-06-13 15:51:15 --> Helper loaded: form_helper
INFO - 2016-06-13 15:51:15 --> Database Driver Class Initialized
INFO - 2016-06-13 15:51:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:51:15 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:51:15 --> Email Class Initialized
INFO - 2016-06-13 15:51:15 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:51:15 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:51:15 --> Helper loaded: language_helper
INFO - 2016-06-13 15:51:15 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:51:15 --> Model Class Initialized
INFO - 2016-06-13 15:51:15 --> Helper loaded: date_helper
INFO - 2016-06-13 15:51:15 --> Controller Class Initialized
INFO - 2016-06-13 15:51:15 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:51:15 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:51:15 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:51:15 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:51:15 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:51:15 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:51:15 --> Model Class Initialized
INFO - 2016-06-13 15:51:15 --> Form Validation Class Initialized
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:51:15 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:51:15 --> Final output sent to browser
DEBUG - 2016-06-13 15:51:15 --> Total execution time: 0.0295
INFO - 2016-06-13 15:51:16 --> Config Class Initialized
INFO - 2016-06-13 15:51:16 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:51:16 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:51:16 --> Utf8 Class Initialized
INFO - 2016-06-13 15:51:16 --> URI Class Initialized
INFO - 2016-06-13 15:51:16 --> Router Class Initialized
INFO - 2016-06-13 15:51:16 --> Output Class Initialized
INFO - 2016-06-13 15:51:16 --> Security Class Initialized
DEBUG - 2016-06-13 15:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:51:16 --> Input Class Initialized
INFO - 2016-06-13 15:51:16 --> Language Class Initialized
INFO - 2016-06-13 15:51:16 --> Loader Class Initialized
INFO - 2016-06-13 15:51:16 --> Helper loaded: form_helper
INFO - 2016-06-13 15:51:16 --> Database Driver Class Initialized
INFO - 2016-06-13 15:51:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:51:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:51:16 --> Email Class Initialized
INFO - 2016-06-13 15:51:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:51:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:51:16 --> Helper loaded: language_helper
INFO - 2016-06-13 15:51:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:51:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:51:16 --> Model Class Initialized
INFO - 2016-06-13 15:51:16 --> Helper loaded: date_helper
INFO - 2016-06-13 15:51:16 --> Controller Class Initialized
INFO - 2016-06-13 15:51:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:51:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:51:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:51:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:51:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:51:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:51:16 --> Model Class Initialized
INFO - 2016-06-13 15:51:16 --> Form Validation Class Initialized
INFO - 2016-06-13 15:51:16 --> Final output sent to browser
DEBUG - 2016-06-13 15:51:16 --> Total execution time: 0.0264
INFO - 2016-06-13 15:51:36 --> Config Class Initialized
INFO - 2016-06-13 15:51:36 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:51:36 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:51:36 --> Utf8 Class Initialized
INFO - 2016-06-13 15:51:36 --> URI Class Initialized
INFO - 2016-06-13 15:51:36 --> Router Class Initialized
INFO - 2016-06-13 15:51:36 --> Output Class Initialized
INFO - 2016-06-13 15:51:36 --> Security Class Initialized
DEBUG - 2016-06-13 15:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:51:36 --> Input Class Initialized
INFO - 2016-06-13 15:51:36 --> Language Class Initialized
INFO - 2016-06-13 15:51:36 --> Loader Class Initialized
INFO - 2016-06-13 15:51:36 --> Helper loaded: form_helper
INFO - 2016-06-13 15:51:36 --> Database Driver Class Initialized
INFO - 2016-06-13 15:51:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:51:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:51:36 --> Email Class Initialized
INFO - 2016-06-13 15:51:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:51:36 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:51:36 --> Helper loaded: language_helper
INFO - 2016-06-13 15:51:36 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:51:36 --> Model Class Initialized
INFO - 2016-06-13 15:51:36 --> Helper loaded: date_helper
INFO - 2016-06-13 15:51:36 --> Controller Class Initialized
INFO - 2016-06-13 15:51:36 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:51:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:51:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:51:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:51:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:51:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:51:36 --> Model Class Initialized
INFO - 2016-06-13 15:51:36 --> Form Validation Class Initialized
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
ERROR - 2016-06-13 15:51:36 --> Could not find the language line "interval_0"
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:51:36 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:51:36 --> Final output sent to browser
DEBUG - 2016-06-13 15:51:36 --> Total execution time: 0.1502
INFO - 2016-06-13 15:51:37 --> Config Class Initialized
INFO - 2016-06-13 15:51:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:51:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:51:37 --> Utf8 Class Initialized
INFO - 2016-06-13 15:51:37 --> URI Class Initialized
INFO - 2016-06-13 15:51:37 --> Router Class Initialized
INFO - 2016-06-13 15:51:37 --> Output Class Initialized
INFO - 2016-06-13 15:51:37 --> Security Class Initialized
DEBUG - 2016-06-13 15:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:51:37 --> Input Class Initialized
INFO - 2016-06-13 15:51:37 --> Language Class Initialized
INFO - 2016-06-13 15:51:37 --> Loader Class Initialized
INFO - 2016-06-13 15:51:37 --> Helper loaded: form_helper
INFO - 2016-06-13 15:51:37 --> Database Driver Class Initialized
INFO - 2016-06-13 15:51:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:51:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:51:37 --> Email Class Initialized
INFO - 2016-06-13 15:51:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:51:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:51:37 --> Helper loaded: language_helper
INFO - 2016-06-13 15:51:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:51:37 --> Model Class Initialized
INFO - 2016-06-13 15:51:37 --> Helper loaded: date_helper
INFO - 2016-06-13 15:51:37 --> Controller Class Initialized
INFO - 2016-06-13 15:51:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:51:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:51:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:51:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:51:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:51:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:51:37 --> Model Class Initialized
INFO - 2016-06-13 15:51:37 --> Form Validation Class Initialized
INFO - 2016-06-13 15:51:37 --> Final output sent to browser
DEBUG - 2016-06-13 15:51:37 --> Total execution time: 0.0492
INFO - 2016-06-13 15:52:03 --> Config Class Initialized
INFO - 2016-06-13 15:52:03 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:52:03 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:52:03 --> Utf8 Class Initialized
INFO - 2016-06-13 15:52:03 --> URI Class Initialized
INFO - 2016-06-13 15:52:03 --> Router Class Initialized
INFO - 2016-06-13 15:52:03 --> Output Class Initialized
INFO - 2016-06-13 15:52:03 --> Security Class Initialized
DEBUG - 2016-06-13 15:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:52:03 --> Input Class Initialized
INFO - 2016-06-13 15:52:03 --> Language Class Initialized
INFO - 2016-06-13 15:52:03 --> Loader Class Initialized
INFO - 2016-06-13 15:52:03 --> Helper loaded: form_helper
INFO - 2016-06-13 15:52:03 --> Database Driver Class Initialized
INFO - 2016-06-13 15:52:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:52:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:52:03 --> Email Class Initialized
INFO - 2016-06-13 15:52:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:52:03 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:52:03 --> Helper loaded: language_helper
INFO - 2016-06-13 15:52:03 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:52:03 --> Model Class Initialized
INFO - 2016-06-13 15:52:03 --> Helper loaded: date_helper
INFO - 2016-06-13 15:52:03 --> Controller Class Initialized
INFO - 2016-06-13 15:52:03 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:52:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:52:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:52:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:52:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:52:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:52:03 --> Model Class Initialized
INFO - 2016-06-13 15:52:03 --> Form Validation Class Initialized
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:52:03 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:52:03 --> Final output sent to browser
DEBUG - 2016-06-13 15:52:03 --> Total execution time: 0.0921
INFO - 2016-06-13 15:52:05 --> Config Class Initialized
INFO - 2016-06-13 15:52:05 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:52:05 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:52:05 --> Utf8 Class Initialized
INFO - 2016-06-13 15:52:05 --> URI Class Initialized
INFO - 2016-06-13 15:52:05 --> Router Class Initialized
INFO - 2016-06-13 15:52:05 --> Output Class Initialized
INFO - 2016-06-13 15:52:05 --> Security Class Initialized
DEBUG - 2016-06-13 15:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:52:05 --> Input Class Initialized
INFO - 2016-06-13 15:52:05 --> Language Class Initialized
INFO - 2016-06-13 15:52:05 --> Loader Class Initialized
INFO - 2016-06-13 15:52:05 --> Helper loaded: form_helper
INFO - 2016-06-13 15:52:05 --> Database Driver Class Initialized
INFO - 2016-06-13 15:52:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:52:05 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:52:05 --> Email Class Initialized
INFO - 2016-06-13 15:52:05 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:52:05 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:52:05 --> Helper loaded: language_helper
INFO - 2016-06-13 15:52:05 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:52:05 --> Model Class Initialized
INFO - 2016-06-13 15:52:05 --> Helper loaded: date_helper
INFO - 2016-06-13 15:52:05 --> Controller Class Initialized
INFO - 2016-06-13 15:52:05 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:52:05 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:52:05 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:52:05 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:52:05 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:52:05 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:52:05 --> Model Class Initialized
INFO - 2016-06-13 15:52:05 --> Form Validation Class Initialized
INFO - 2016-06-13 15:52:05 --> Final output sent to browser
DEBUG - 2016-06-13 15:52:05 --> Total execution time: 0.0824
INFO - 2016-06-13 15:52:13 --> Config Class Initialized
INFO - 2016-06-13 15:52:13 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:52:13 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:52:13 --> Utf8 Class Initialized
INFO - 2016-06-13 15:52:13 --> URI Class Initialized
INFO - 2016-06-13 15:52:13 --> Router Class Initialized
INFO - 2016-06-13 15:52:13 --> Output Class Initialized
INFO - 2016-06-13 15:52:13 --> Security Class Initialized
DEBUG - 2016-06-13 15:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:52:13 --> Input Class Initialized
INFO - 2016-06-13 15:52:13 --> Language Class Initialized
INFO - 2016-06-13 15:52:13 --> Loader Class Initialized
INFO - 2016-06-13 15:52:13 --> Helper loaded: form_helper
INFO - 2016-06-13 15:52:13 --> Database Driver Class Initialized
INFO - 2016-06-13 15:52:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:52:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:52:13 --> Email Class Initialized
INFO - 2016-06-13 15:52:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:52:13 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:52:13 --> Helper loaded: language_helper
INFO - 2016-06-13 15:52:13 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:52:13 --> Model Class Initialized
INFO - 2016-06-13 15:52:13 --> Helper loaded: date_helper
INFO - 2016-06-13 15:52:13 --> Controller Class Initialized
INFO - 2016-06-13 15:52:13 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:52:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:52:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:52:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:52:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:52:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:52:13 --> Model Class Initialized
INFO - 2016-06-13 15:52:13 --> Form Validation Class Initialized
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:52:13 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:52:13 --> Final output sent to browser
DEBUG - 2016-06-13 15:52:13 --> Total execution time: 0.1006
INFO - 2016-06-13 15:52:14 --> Config Class Initialized
INFO - 2016-06-13 15:52:14 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:52:14 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:52:14 --> Utf8 Class Initialized
INFO - 2016-06-13 15:52:14 --> URI Class Initialized
INFO - 2016-06-13 15:52:14 --> Router Class Initialized
INFO - 2016-06-13 15:52:14 --> Output Class Initialized
INFO - 2016-06-13 15:52:14 --> Security Class Initialized
DEBUG - 2016-06-13 15:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:52:14 --> Input Class Initialized
INFO - 2016-06-13 15:52:14 --> Language Class Initialized
INFO - 2016-06-13 15:52:14 --> Loader Class Initialized
INFO - 2016-06-13 15:52:14 --> Helper loaded: form_helper
INFO - 2016-06-13 15:52:14 --> Database Driver Class Initialized
INFO - 2016-06-13 15:52:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:52:14 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:52:14 --> Email Class Initialized
INFO - 2016-06-13 15:52:14 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:52:14 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:52:14 --> Helper loaded: language_helper
INFO - 2016-06-13 15:52:14 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:52:14 --> Model Class Initialized
INFO - 2016-06-13 15:52:14 --> Helper loaded: date_helper
INFO - 2016-06-13 15:52:14 --> Controller Class Initialized
INFO - 2016-06-13 15:52:14 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:52:14 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:52:14 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:52:14 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:52:14 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:52:14 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:52:14 --> Model Class Initialized
INFO - 2016-06-13 15:52:14 --> Form Validation Class Initialized
INFO - 2016-06-13 15:52:14 --> Final output sent to browser
DEBUG - 2016-06-13 15:52:14 --> Total execution time: 0.0516
INFO - 2016-06-13 15:54:28 --> Config Class Initialized
INFO - 2016-06-13 15:54:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:54:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:54:28 --> Utf8 Class Initialized
INFO - 2016-06-13 15:54:28 --> URI Class Initialized
INFO - 2016-06-13 15:54:28 --> Router Class Initialized
INFO - 2016-06-13 15:54:28 --> Output Class Initialized
INFO - 2016-06-13 15:54:28 --> Security Class Initialized
DEBUG - 2016-06-13 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:54:28 --> Input Class Initialized
INFO - 2016-06-13 15:54:28 --> Language Class Initialized
INFO - 2016-06-13 15:54:28 --> Loader Class Initialized
INFO - 2016-06-13 15:54:28 --> Helper loaded: form_helper
INFO - 2016-06-13 15:54:28 --> Database Driver Class Initialized
INFO - 2016-06-13 15:54:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:54:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:54:28 --> Email Class Initialized
INFO - 2016-06-13 15:54:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:54:28 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:54:28 --> Helper loaded: language_helper
INFO - 2016-06-13 15:54:28 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:54:28 --> Model Class Initialized
INFO - 2016-06-13 15:54:28 --> Helper loaded: date_helper
INFO - 2016-06-13 15:54:28 --> Controller Class Initialized
INFO - 2016-06-13 15:54:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:54:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:54:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:54:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:54:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:54:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:54:28 --> Model Class Initialized
INFO - 2016-06-13 15:54:28 --> Form Validation Class Initialized
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:54:28 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:54:28 --> Final output sent to browser
DEBUG - 2016-06-13 15:54:28 --> Total execution time: 0.1215
INFO - 2016-06-13 15:54:29 --> Config Class Initialized
INFO - 2016-06-13 15:54:29 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:54:29 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:54:29 --> Utf8 Class Initialized
INFO - 2016-06-13 15:54:29 --> URI Class Initialized
INFO - 2016-06-13 15:54:29 --> Router Class Initialized
INFO - 2016-06-13 15:54:29 --> Output Class Initialized
INFO - 2016-06-13 15:54:29 --> Security Class Initialized
DEBUG - 2016-06-13 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:54:29 --> Input Class Initialized
INFO - 2016-06-13 15:54:29 --> Language Class Initialized
ERROR - 2016-06-13 15:54:29 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 15:54:29 --> Config Class Initialized
INFO - 2016-06-13 15:54:29 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:54:29 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:54:29 --> Utf8 Class Initialized
INFO - 2016-06-13 15:54:29 --> URI Class Initialized
INFO - 2016-06-13 15:54:29 --> Router Class Initialized
INFO - 2016-06-13 15:54:29 --> Output Class Initialized
INFO - 2016-06-13 15:54:29 --> Security Class Initialized
DEBUG - 2016-06-13 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:54:29 --> Input Class Initialized
INFO - 2016-06-13 15:54:29 --> Language Class Initialized
INFO - 2016-06-13 15:54:29 --> Loader Class Initialized
INFO - 2016-06-13 15:54:29 --> Helper loaded: form_helper
INFO - 2016-06-13 15:54:29 --> Database Driver Class Initialized
INFO - 2016-06-13 15:54:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:54:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:54:29 --> Email Class Initialized
INFO - 2016-06-13 15:54:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:54:29 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:54:29 --> Helper loaded: language_helper
INFO - 2016-06-13 15:54:29 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:54:29 --> Model Class Initialized
INFO - 2016-06-13 15:54:29 --> Helper loaded: date_helper
INFO - 2016-06-13 15:54:29 --> Controller Class Initialized
INFO - 2016-06-13 15:54:29 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:54:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:54:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:54:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:54:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:54:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:54:29 --> Model Class Initialized
INFO - 2016-06-13 15:54:29 --> Form Validation Class Initialized
INFO - 2016-06-13 15:54:29 --> Final output sent to browser
DEBUG - 2016-06-13 15:54:29 --> Total execution time: 0.0669
INFO - 2016-06-13 15:55:11 --> Config Class Initialized
INFO - 2016-06-13 15:55:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:55:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:55:11 --> Utf8 Class Initialized
INFO - 2016-06-13 15:55:11 --> URI Class Initialized
INFO - 2016-06-13 15:55:11 --> Router Class Initialized
INFO - 2016-06-13 15:55:11 --> Output Class Initialized
INFO - 2016-06-13 15:55:11 --> Security Class Initialized
DEBUG - 2016-06-13 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:55:11 --> Input Class Initialized
INFO - 2016-06-13 15:55:11 --> Language Class Initialized
INFO - 2016-06-13 15:55:11 --> Loader Class Initialized
INFO - 2016-06-13 15:55:11 --> Helper loaded: form_helper
INFO - 2016-06-13 15:55:11 --> Database Driver Class Initialized
INFO - 2016-06-13 15:55:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:55:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:55:11 --> Email Class Initialized
INFO - 2016-06-13 15:55:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:55:11 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:55:11 --> Helper loaded: language_helper
INFO - 2016-06-13 15:55:11 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:55:11 --> Model Class Initialized
INFO - 2016-06-13 15:55:11 --> Helper loaded: date_helper
INFO - 2016-06-13 15:55:11 --> Controller Class Initialized
INFO - 2016-06-13 15:55:11 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:55:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:55:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:55:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:55:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:55:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:55:11 --> Model Class Initialized
INFO - 2016-06-13 15:55:11 --> Form Validation Class Initialized
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:55:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:55:11 --> Final output sent to browser
DEBUG - 2016-06-13 15:55:11 --> Total execution time: 0.1017
INFO - 2016-06-13 15:55:12 --> Config Class Initialized
INFO - 2016-06-13 15:55:12 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:55:12 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:55:12 --> Utf8 Class Initialized
INFO - 2016-06-13 15:55:12 --> URI Class Initialized
INFO - 2016-06-13 15:55:12 --> Router Class Initialized
INFO - 2016-06-13 15:55:12 --> Output Class Initialized
INFO - 2016-06-13 15:55:12 --> Security Class Initialized
DEBUG - 2016-06-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:55:12 --> Input Class Initialized
INFO - 2016-06-13 15:55:12 --> Language Class Initialized
ERROR - 2016-06-13 15:55:12 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 15:55:12 --> Config Class Initialized
INFO - 2016-06-13 15:55:12 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:55:12 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:55:12 --> Utf8 Class Initialized
INFO - 2016-06-13 15:55:12 --> URI Class Initialized
INFO - 2016-06-13 15:55:12 --> Router Class Initialized
INFO - 2016-06-13 15:55:12 --> Output Class Initialized
INFO - 2016-06-13 15:55:12 --> Security Class Initialized
DEBUG - 2016-06-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:55:12 --> Input Class Initialized
INFO - 2016-06-13 15:55:12 --> Language Class Initialized
INFO - 2016-06-13 15:55:12 --> Loader Class Initialized
INFO - 2016-06-13 15:55:12 --> Helper loaded: form_helper
INFO - 2016-06-13 15:55:12 --> Database Driver Class Initialized
INFO - 2016-06-13 15:55:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:55:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:55:12 --> Email Class Initialized
INFO - 2016-06-13 15:55:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:55:12 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:55:12 --> Helper loaded: language_helper
INFO - 2016-06-13 15:55:12 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:55:12 --> Model Class Initialized
INFO - 2016-06-13 15:55:12 --> Helper loaded: date_helper
INFO - 2016-06-13 15:55:12 --> Controller Class Initialized
INFO - 2016-06-13 15:55:12 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:55:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:55:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:55:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:55:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:55:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:55:12 --> Model Class Initialized
INFO - 2016-06-13 15:55:12 --> Form Validation Class Initialized
INFO - 2016-06-13 15:55:12 --> Final output sent to browser
DEBUG - 2016-06-13 15:55:12 --> Total execution time: 0.0595
INFO - 2016-06-13 15:55:36 --> Config Class Initialized
INFO - 2016-06-13 15:55:36 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:55:36 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:55:36 --> Utf8 Class Initialized
INFO - 2016-06-13 15:55:36 --> URI Class Initialized
INFO - 2016-06-13 15:55:36 --> Router Class Initialized
INFO - 2016-06-13 15:55:36 --> Output Class Initialized
INFO - 2016-06-13 15:55:36 --> Security Class Initialized
DEBUG - 2016-06-13 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:55:36 --> Input Class Initialized
INFO - 2016-06-13 15:55:36 --> Language Class Initialized
INFO - 2016-06-13 15:55:36 --> Loader Class Initialized
INFO - 2016-06-13 15:55:36 --> Helper loaded: form_helper
INFO - 2016-06-13 15:55:36 --> Database Driver Class Initialized
INFO - 2016-06-13 15:55:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:55:36 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:55:36 --> Email Class Initialized
INFO - 2016-06-13 15:55:36 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:55:36 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:55:36 --> Helper loaded: language_helper
INFO - 2016-06-13 15:55:36 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:55:36 --> Model Class Initialized
INFO - 2016-06-13 15:55:36 --> Helper loaded: date_helper
INFO - 2016-06-13 15:55:36 --> Controller Class Initialized
INFO - 2016-06-13 15:55:36 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:55:36 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:55:36 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:55:36 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:55:36 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:55:36 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:55:36 --> Model Class Initialized
INFO - 2016-06-13 15:55:36 --> Form Validation Class Initialized
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 15:55:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:55:37 --> Final output sent to browser
DEBUG - 2016-06-13 15:55:37 --> Total execution time: 0.0969
INFO - 2016-06-13 15:55:37 --> Config Class Initialized
INFO - 2016-06-13 15:55:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:55:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:55:37 --> Utf8 Class Initialized
INFO - 2016-06-13 15:55:37 --> URI Class Initialized
INFO - 2016-06-13 15:55:37 --> Router Class Initialized
INFO - 2016-06-13 15:55:37 --> Output Class Initialized
INFO - 2016-06-13 15:55:37 --> Security Class Initialized
DEBUG - 2016-06-13 15:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:55:37 --> Input Class Initialized
INFO - 2016-06-13 15:55:37 --> Language Class Initialized
ERROR - 2016-06-13 15:55:37 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 15:55:38 --> Config Class Initialized
INFO - 2016-06-13 15:55:38 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:55:38 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:55:38 --> Utf8 Class Initialized
INFO - 2016-06-13 15:55:38 --> URI Class Initialized
INFO - 2016-06-13 15:55:38 --> Router Class Initialized
INFO - 2016-06-13 15:55:38 --> Output Class Initialized
INFO - 2016-06-13 15:55:38 --> Security Class Initialized
DEBUG - 2016-06-13 15:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:55:38 --> Input Class Initialized
INFO - 2016-06-13 15:55:38 --> Language Class Initialized
INFO - 2016-06-13 15:55:38 --> Loader Class Initialized
INFO - 2016-06-13 15:55:38 --> Helper loaded: form_helper
INFO - 2016-06-13 15:55:38 --> Database Driver Class Initialized
INFO - 2016-06-13 15:55:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:55:38 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:55:38 --> Email Class Initialized
INFO - 2016-06-13 15:55:38 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:55:38 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:55:38 --> Helper loaded: language_helper
INFO - 2016-06-13 15:55:38 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:55:38 --> Model Class Initialized
INFO - 2016-06-13 15:55:38 --> Helper loaded: date_helper
INFO - 2016-06-13 15:55:38 --> Controller Class Initialized
INFO - 2016-06-13 15:55:38 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:55:38 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:55:38 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:55:38 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:55:38 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:55:38 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:55:38 --> Model Class Initialized
INFO - 2016-06-13 15:55:38 --> Form Validation Class Initialized
INFO - 2016-06-13 15:55:38 --> Final output sent to browser
DEBUG - 2016-06-13 15:55:38 --> Total execution time: 0.0594
INFO - 2016-06-13 15:58:58 --> Config Class Initialized
INFO - 2016-06-13 15:58:58 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:58:58 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:58:58 --> Utf8 Class Initialized
INFO - 2016-06-13 15:58:58 --> URI Class Initialized
INFO - 2016-06-13 15:58:58 --> Router Class Initialized
INFO - 2016-06-13 15:58:58 --> Output Class Initialized
INFO - 2016-06-13 15:58:58 --> Security Class Initialized
DEBUG - 2016-06-13 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:58:58 --> Input Class Initialized
INFO - 2016-06-13 15:58:58 --> Language Class Initialized
ERROR - 2016-06-13 15:58:58 --> Severity: Parsing Error --> syntax error, unexpected 'catch' (T_CATCH) /home/demis/www/platformadiabet/application/controllers/Diabet.php 203
INFO - 2016-06-13 15:58:58 --> Config Class Initialized
INFO - 2016-06-13 15:58:58 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:58:58 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:58:58 --> Utf8 Class Initialized
INFO - 2016-06-13 15:58:58 --> URI Class Initialized
INFO - 2016-06-13 15:58:58 --> Router Class Initialized
INFO - 2016-06-13 15:58:58 --> Output Class Initialized
INFO - 2016-06-13 15:58:58 --> Security Class Initialized
DEBUG - 2016-06-13 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:58:58 --> Input Class Initialized
INFO - 2016-06-13 15:58:58 --> Language Class Initialized
ERROR - 2016-06-13 15:58:58 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 15:59:08 --> Config Class Initialized
INFO - 2016-06-13 15:59:08 --> Hooks Class Initialized
DEBUG - 2016-06-13 15:59:08 --> UTF-8 Support Enabled
INFO - 2016-06-13 15:59:08 --> Utf8 Class Initialized
INFO - 2016-06-13 15:59:08 --> URI Class Initialized
INFO - 2016-06-13 15:59:08 --> Router Class Initialized
INFO - 2016-06-13 15:59:08 --> Output Class Initialized
INFO - 2016-06-13 15:59:08 --> Security Class Initialized
DEBUG - 2016-06-13 15:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 15:59:08 --> Input Class Initialized
INFO - 2016-06-13 15:59:08 --> Language Class Initialized
INFO - 2016-06-13 15:59:08 --> Loader Class Initialized
INFO - 2016-06-13 15:59:08 --> Helper loaded: form_helper
INFO - 2016-06-13 15:59:08 --> Database Driver Class Initialized
INFO - 2016-06-13 15:59:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 15:59:08 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 15:59:08 --> Email Class Initialized
INFO - 2016-06-13 15:59:08 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 15:59:08 --> Helper loaded: cookie_helper
INFO - 2016-06-13 15:59:08 --> Helper loaded: language_helper
INFO - 2016-06-13 15:59:08 --> Helper loaded: url_helper
DEBUG - 2016-06-13 15:59:08 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 15:59:08 --> Model Class Initialized
INFO - 2016-06-13 15:59:08 --> Helper loaded: date_helper
INFO - 2016-06-13 15:59:08 --> Controller Class Initialized
INFO - 2016-06-13 15:59:08 --> Helper loaded: languages_helper
INFO - 2016-06-13 15:59:08 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 15:59:08 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 15:59:08 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 15:59:08 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 15:59:08 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 15:59:08 --> Model Class Initialized
INFO - 2016-06-13 15:59:08 --> Form Validation Class Initialized
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-13 15:59:08 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 15:59:08 --> Final output sent to browser
DEBUG - 2016-06-13 15:59:08 --> Total execution time: 0.1047
INFO - 2016-06-13 16:00:10 --> Config Class Initialized
INFO - 2016-06-13 16:00:10 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:00:10 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:00:10 --> Utf8 Class Initialized
INFO - 2016-06-13 16:00:10 --> URI Class Initialized
DEBUG - 2016-06-13 16:00:10 --> No URI present. Default controller set.
INFO - 2016-06-13 16:00:10 --> Router Class Initialized
INFO - 2016-06-13 16:00:10 --> Output Class Initialized
INFO - 2016-06-13 16:00:10 --> Security Class Initialized
DEBUG - 2016-06-13 16:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:00:10 --> Input Class Initialized
INFO - 2016-06-13 16:00:10 --> Language Class Initialized
INFO - 2016-06-13 16:00:10 --> Loader Class Initialized
INFO - 2016-06-13 16:00:10 --> Helper loaded: form_helper
INFO - 2016-06-13 16:00:10 --> Database Driver Class Initialized
INFO - 2016-06-13 16:00:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:00:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:00:10 --> Email Class Initialized
INFO - 2016-06-13 16:00:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:00:10 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:00:10 --> Helper loaded: language_helper
INFO - 2016-06-13 16:00:10 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:00:10 --> Model Class Initialized
INFO - 2016-06-13 16:00:10 --> Helper loaded: date_helper
INFO - 2016-06-13 16:00:10 --> Controller Class Initialized
INFO - 2016-06-13 16:00:10 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:00:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:00:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:00:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:00:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:00:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:00:11 --> Config Class Initialized
INFO - 2016-06-13 16:00:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:00:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:00:11 --> Utf8 Class Initialized
INFO - 2016-06-13 16:00:11 --> URI Class Initialized
INFO - 2016-06-13 16:00:11 --> Router Class Initialized
INFO - 2016-06-13 16:00:11 --> Output Class Initialized
INFO - 2016-06-13 16:00:11 --> Security Class Initialized
DEBUG - 2016-06-13 16:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:00:11 --> Input Class Initialized
INFO - 2016-06-13 16:00:11 --> Language Class Initialized
INFO - 2016-06-13 16:00:11 --> Loader Class Initialized
INFO - 2016-06-13 16:00:11 --> Helper loaded: form_helper
INFO - 2016-06-13 16:00:11 --> Database Driver Class Initialized
INFO - 2016-06-13 16:00:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:00:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:00:11 --> Email Class Initialized
INFO - 2016-06-13 16:00:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:00:11 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:00:11 --> Helper loaded: language_helper
INFO - 2016-06-13 16:00:11 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:00:11 --> Model Class Initialized
INFO - 2016-06-13 16:00:11 --> Helper loaded: date_helper
INFO - 2016-06-13 16:00:11 --> Controller Class Initialized
INFO - 2016-06-13 16:00:11 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:00:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:00:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:00:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:00:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:00:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:00:11 --> Model Class Initialized
INFO - 2016-06-13 16:00:11 --> Form Validation Class Initialized
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:00:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:00:11 --> Final output sent to browser
DEBUG - 2016-06-13 16:00:11 --> Total execution time: 0.1125
INFO - 2016-06-13 16:00:13 --> Config Class Initialized
INFO - 2016-06-13 16:00:13 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:00:13 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:00:13 --> Utf8 Class Initialized
INFO - 2016-06-13 16:00:13 --> URI Class Initialized
INFO - 2016-06-13 16:00:13 --> Router Class Initialized
INFO - 2016-06-13 16:00:13 --> Output Class Initialized
INFO - 2016-06-13 16:00:13 --> Security Class Initialized
DEBUG - 2016-06-13 16:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:00:13 --> Input Class Initialized
INFO - 2016-06-13 16:00:13 --> Language Class Initialized
INFO - 2016-06-13 16:00:13 --> Loader Class Initialized
INFO - 2016-06-13 16:00:13 --> Helper loaded: form_helper
INFO - 2016-06-13 16:00:13 --> Database Driver Class Initialized
INFO - 2016-06-13 16:00:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:00:13 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:00:13 --> Email Class Initialized
INFO - 2016-06-13 16:00:13 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:00:13 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:00:13 --> Helper loaded: language_helper
INFO - 2016-06-13 16:00:13 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:00:13 --> Model Class Initialized
INFO - 2016-06-13 16:00:13 --> Helper loaded: date_helper
INFO - 2016-06-13 16:00:13 --> Controller Class Initialized
INFO - 2016-06-13 16:00:13 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:00:13 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:00:13 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:00:13 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:00:13 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:00:13 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:00:13 --> Model Class Initialized
INFO - 2016-06-13 16:00:13 --> Form Validation Class Initialized
INFO - 2016-06-13 16:00:13 --> Final output sent to browser
DEBUG - 2016-06-13 16:00:13 --> Total execution time: 0.0535
INFO - 2016-06-13 16:00:37 --> Config Class Initialized
INFO - 2016-06-13 16:00:37 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:00:37 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:00:37 --> Utf8 Class Initialized
INFO - 2016-06-13 16:00:37 --> URI Class Initialized
INFO - 2016-06-13 16:00:37 --> Router Class Initialized
INFO - 2016-06-13 16:00:37 --> Output Class Initialized
INFO - 2016-06-13 16:00:37 --> Security Class Initialized
DEBUG - 2016-06-13 16:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:00:37 --> Input Class Initialized
INFO - 2016-06-13 16:00:37 --> Language Class Initialized
INFO - 2016-06-13 16:00:37 --> Loader Class Initialized
INFO - 2016-06-13 16:00:37 --> Helper loaded: form_helper
INFO - 2016-06-13 16:00:37 --> Database Driver Class Initialized
INFO - 2016-06-13 16:00:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:00:37 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:00:37 --> Email Class Initialized
INFO - 2016-06-13 16:00:37 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:00:37 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:00:37 --> Helper loaded: language_helper
INFO - 2016-06-13 16:00:37 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:00:37 --> Model Class Initialized
INFO - 2016-06-13 16:00:37 --> Helper loaded: date_helper
INFO - 2016-06-13 16:00:37 --> Controller Class Initialized
INFO - 2016-06-13 16:00:37 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:00:37 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:00:37 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:00:37 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:00:37 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:00:37 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:00:37 --> Model Class Initialized
INFO - 2016-06-13 16:00:37 --> Form Validation Class Initialized
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-13 16:00:37 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:00:37 --> Final output sent to browser
DEBUG - 2016-06-13 16:00:37 --> Total execution time: 0.1023
INFO - 2016-06-13 16:00:54 --> Config Class Initialized
INFO - 2016-06-13 16:00:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:00:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:00:54 --> Utf8 Class Initialized
INFO - 2016-06-13 16:00:54 --> URI Class Initialized
INFO - 2016-06-13 16:00:54 --> Router Class Initialized
INFO - 2016-06-13 16:00:54 --> Output Class Initialized
INFO - 2016-06-13 16:00:54 --> Security Class Initialized
DEBUG - 2016-06-13 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:00:54 --> Input Class Initialized
INFO - 2016-06-13 16:00:54 --> Language Class Initialized
INFO - 2016-06-13 16:00:54 --> Loader Class Initialized
INFO - 2016-06-13 16:00:54 --> Helper loaded: form_helper
INFO - 2016-06-13 16:00:54 --> Database Driver Class Initialized
INFO - 2016-06-13 16:00:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:00:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:00:54 --> Email Class Initialized
INFO - 2016-06-13 16:00:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:00:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:00:54 --> Helper loaded: language_helper
INFO - 2016-06-13 16:00:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:00:54 --> Model Class Initialized
INFO - 2016-06-13 16:00:54 --> Helper loaded: date_helper
INFO - 2016-06-13 16:00:54 --> Controller Class Initialized
INFO - 2016-06-13 16:00:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:00:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:00:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:00:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:00:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:00:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:00:54 --> Model Class Initialized
INFO - 2016-06-13 16:00:54 --> Form Validation Class Initialized
DEBUG - 2016-06-13 16:00:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-13 16:00:55 --> Email class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:03:35 --> Config Class Initialized
INFO - 2016-06-13 16:03:35 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:03:35 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:03:35 --> Utf8 Class Initialized
INFO - 2016-06-13 16:03:35 --> URI Class Initialized
INFO - 2016-06-13 16:03:35 --> Router Class Initialized
INFO - 2016-06-13 16:03:35 --> Output Class Initialized
INFO - 2016-06-13 16:03:35 --> Security Class Initialized
DEBUG - 2016-06-13 16:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:03:35 --> Input Class Initialized
INFO - 2016-06-13 16:03:35 --> Language Class Initialized
INFO - 2016-06-13 16:03:35 --> Loader Class Initialized
INFO - 2016-06-13 16:03:35 --> Helper loaded: form_helper
INFO - 2016-06-13 16:03:35 --> Database Driver Class Initialized
INFO - 2016-06-13 16:03:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:03:35 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:03:35 --> Email Class Initialized
INFO - 2016-06-13 16:03:35 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:03:35 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:03:35 --> Helper loaded: language_helper
INFO - 2016-06-13 16:03:35 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:03:35 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:03:35 --> Model Class Initialized
INFO - 2016-06-13 16:03:35 --> Helper loaded: date_helper
INFO - 2016-06-13 16:03:35 --> Controller Class Initialized
INFO - 2016-06-13 16:03:35 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:03:35 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:03:35 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:03:35 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:03:35 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:03:35 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:03:35 --> Model Class Initialized
INFO - 2016-06-13 16:03:35 --> Form Validation Class Initialized
DEBUG - 2016-06-13 16:03:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-13 16:03:35 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:03:35 --> Final output sent to browser
DEBUG - 2016-06-13 16:03:35 --> Total execution time: 0.0864
INFO - 2016-06-13 16:03:54 --> Config Class Initialized
INFO - 2016-06-13 16:03:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:03:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:03:54 --> Utf8 Class Initialized
INFO - 2016-06-13 16:03:54 --> URI Class Initialized
INFO - 2016-06-13 16:03:54 --> Router Class Initialized
INFO - 2016-06-13 16:03:54 --> Output Class Initialized
INFO - 2016-06-13 16:03:54 --> Security Class Initialized
DEBUG - 2016-06-13 16:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:03:54 --> Input Class Initialized
INFO - 2016-06-13 16:03:54 --> Language Class Initialized
INFO - 2016-06-13 16:03:54 --> Loader Class Initialized
INFO - 2016-06-13 16:03:54 --> Helper loaded: form_helper
INFO - 2016-06-13 16:03:54 --> Database Driver Class Initialized
INFO - 2016-06-13 16:03:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:03:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:03:54 --> Email Class Initialized
INFO - 2016-06-13 16:03:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:03:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:03:54 --> Helper loaded: language_helper
INFO - 2016-06-13 16:03:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:03:54 --> Model Class Initialized
INFO - 2016-06-13 16:03:54 --> Helper loaded: date_helper
INFO - 2016-06-13 16:03:54 --> Controller Class Initialized
INFO - 2016-06-13 16:03:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:03:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:03:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:03:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:03:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:03:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:03:54 --> Model Class Initialized
INFO - 2016-06-13 16:03:54 --> Form Validation Class Initialized
INFO - 2016-06-13 16:03:55 --> Config Class Initialized
INFO - 2016-06-13 16:03:55 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:03:55 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:03:55 --> Utf8 Class Initialized
INFO - 2016-06-13 16:03:55 --> URI Class Initialized
INFO - 2016-06-13 16:03:55 --> Router Class Initialized
INFO - 2016-06-13 16:03:55 --> Output Class Initialized
INFO - 2016-06-13 16:03:55 --> Security Class Initialized
DEBUG - 2016-06-13 16:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:03:55 --> Input Class Initialized
INFO - 2016-06-13 16:03:55 --> Language Class Initialized
INFO - 2016-06-13 16:03:55 --> Loader Class Initialized
INFO - 2016-06-13 16:03:55 --> Helper loaded: form_helper
INFO - 2016-06-13 16:03:55 --> Database Driver Class Initialized
INFO - 2016-06-13 16:03:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:03:55 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:03:55 --> Email Class Initialized
INFO - 2016-06-13 16:03:55 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:03:55 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:03:55 --> Helper loaded: language_helper
INFO - 2016-06-13 16:03:55 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:03:55 --> Model Class Initialized
INFO - 2016-06-13 16:03:55 --> Helper loaded: date_helper
INFO - 2016-06-13 16:03:55 --> Controller Class Initialized
INFO - 2016-06-13 16:03:55 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:03:55 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:03:55 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:03:55 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:03:55 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:03:55 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:03:55 --> Model Class Initialized
INFO - 2016-06-13 16:03:55 --> Form Validation Class Initialized
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-13 16:03:55 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:03:55 --> Final output sent to browser
DEBUG - 2016-06-13 16:03:55 --> Total execution time: 0.0744
INFO - 2016-06-13 16:04:04 --> Config Class Initialized
INFO - 2016-06-13 16:04:04 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:04:04 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:04:04 --> Utf8 Class Initialized
INFO - 2016-06-13 16:04:04 --> URI Class Initialized
INFO - 2016-06-13 16:04:04 --> Router Class Initialized
INFO - 2016-06-13 16:04:04 --> Output Class Initialized
INFO - 2016-06-13 16:04:04 --> Security Class Initialized
DEBUG - 2016-06-13 16:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:04:04 --> Input Class Initialized
INFO - 2016-06-13 16:04:04 --> Language Class Initialized
INFO - 2016-06-13 16:04:04 --> Loader Class Initialized
INFO - 2016-06-13 16:04:04 --> Helper loaded: form_helper
INFO - 2016-06-13 16:04:04 --> Database Driver Class Initialized
INFO - 2016-06-13 16:04:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:04:04 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:04:04 --> Email Class Initialized
INFO - 2016-06-13 16:04:04 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:04:04 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:04:04 --> Helper loaded: language_helper
INFO - 2016-06-13 16:04:04 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:04:04 --> Model Class Initialized
INFO - 2016-06-13 16:04:04 --> Helper loaded: date_helper
INFO - 2016-06-13 16:04:04 --> Controller Class Initialized
INFO - 2016-06-13 16:04:04 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:04:04 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:04:04 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:04:04 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:04:04 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:04:04 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:04:04 --> Model Class Initialized
INFO - 2016-06-13 16:04:04 --> Form Validation Class Initialized
DEBUG - 2016-06-13 16:04:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-13 16:04:04 --> Email class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:04:04 --> Language file loaded: language/romanian/email_lang.php
INFO - 2016-06-13 16:04:06 --> Config Class Initialized
INFO - 2016-06-13 16:04:06 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:04:06 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:04:06 --> Utf8 Class Initialized
INFO - 2016-06-13 16:04:06 --> URI Class Initialized
INFO - 2016-06-13 16:04:06 --> Router Class Initialized
INFO - 2016-06-13 16:04:06 --> Output Class Initialized
INFO - 2016-06-13 16:04:06 --> Security Class Initialized
DEBUG - 2016-06-13 16:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:04:06 --> Input Class Initialized
INFO - 2016-06-13 16:04:06 --> Language Class Initialized
INFO - 2016-06-13 16:04:06 --> Loader Class Initialized
INFO - 2016-06-13 16:04:06 --> Helper loaded: form_helper
INFO - 2016-06-13 16:04:06 --> Database Driver Class Initialized
INFO - 2016-06-13 16:04:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:04:06 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:04:06 --> Email Class Initialized
INFO - 2016-06-13 16:04:06 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:04:06 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:04:06 --> Helper loaded: language_helper
INFO - 2016-06-13 16:04:06 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:04:06 --> Model Class Initialized
INFO - 2016-06-13 16:04:06 --> Helper loaded: date_helper
INFO - 2016-06-13 16:04:06 --> Controller Class Initialized
INFO - 2016-06-13 16:04:06 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:04:06 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:04:06 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:04:06 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:04:06 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:04:06 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:04:06 --> Model Class Initialized
INFO - 2016-06-13 16:04:06 --> Form Validation Class Initialized
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-13 16:04:06 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:04:06 --> Final output sent to browser
DEBUG - 2016-06-13 16:04:06 --> Total execution time: 0.0767
INFO - 2016-06-13 16:10:10 --> Config Class Initialized
INFO - 2016-06-13 16:10:10 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:10 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:10 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:10 --> URI Class Initialized
INFO - 2016-06-13 16:10:10 --> Router Class Initialized
INFO - 2016-06-13 16:10:10 --> Output Class Initialized
INFO - 2016-06-13 16:10:10 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:10 --> Input Class Initialized
INFO - 2016-06-13 16:10:10 --> Language Class Initialized
INFO - 2016-06-13 16:10:10 --> Loader Class Initialized
INFO - 2016-06-13 16:10:10 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:10 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:10 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:10 --> Email Class Initialized
INFO - 2016-06-13 16:10:10 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:10 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:10 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:10 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:10 --> Model Class Initialized
INFO - 2016-06-13 16:10:10 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:10 --> Controller Class Initialized
INFO - 2016-06-13 16:10:10 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:10 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:10 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:10 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:10 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:10 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:10 --> Model Class Initialized
INFO - 2016-06-13 16:10:10 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/editare_privilegii.php
INFO - 2016-06-13 16:10:10 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:10:10 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:10 --> Total execution time: 0.0895
INFO - 2016-06-13 16:10:11 --> Config Class Initialized
INFO - 2016-06-13 16:10:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:11 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:11 --> URI Class Initialized
INFO - 2016-06-13 16:10:11 --> Router Class Initialized
INFO - 2016-06-13 16:10:11 --> Output Class Initialized
INFO - 2016-06-13 16:10:11 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:11 --> Input Class Initialized
INFO - 2016-06-13 16:10:11 --> Language Class Initialized
ERROR - 2016-06-13 16:10:11 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 16:10:16 --> Config Class Initialized
INFO - 2016-06-13 16:10:16 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:16 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:16 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:16 --> URI Class Initialized
INFO - 2016-06-13 16:10:16 --> Router Class Initialized
INFO - 2016-06-13 16:10:16 --> Output Class Initialized
INFO - 2016-06-13 16:10:16 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:16 --> Input Class Initialized
INFO - 2016-06-13 16:10:16 --> Language Class Initialized
INFO - 2016-06-13 16:10:16 --> Loader Class Initialized
INFO - 2016-06-13 16:10:16 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:16 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:16 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:16 --> Email Class Initialized
INFO - 2016-06-13 16:10:16 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:16 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:16 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:16 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:16 --> Model Class Initialized
INFO - 2016-06-13 16:10:16 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:16 --> Controller Class Initialized
INFO - 2016-06-13 16:10:16 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:16 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:16 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:16 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:16 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:16 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:16 --> Model Class Initialized
INFO - 2016-06-13 16:10:16 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:10:16 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:10:16 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:16 --> Total execution time: 0.0987
INFO - 2016-06-13 16:10:17 --> Config Class Initialized
INFO - 2016-06-13 16:10:17 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:17 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:17 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:17 --> URI Class Initialized
INFO - 2016-06-13 16:10:17 --> Router Class Initialized
INFO - 2016-06-13 16:10:17 --> Output Class Initialized
INFO - 2016-06-13 16:10:17 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:17 --> Input Class Initialized
INFO - 2016-06-13 16:10:17 --> Language Class Initialized
INFO - 2016-06-13 16:10:17 --> Loader Class Initialized
INFO - 2016-06-13 16:10:17 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:17 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:17 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:17 --> Email Class Initialized
INFO - 2016-06-13 16:10:17 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:17 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:17 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:17 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:17 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:17 --> Model Class Initialized
INFO - 2016-06-13 16:10:17 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:17 --> Controller Class Initialized
INFO - 2016-06-13 16:10:17 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:17 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:17 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:17 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:17 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:17 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:17 --> Model Class Initialized
INFO - 2016-06-13 16:10:17 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:17 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:17 --> Total execution time: 0.0588
INFO - 2016-06-13 16:10:22 --> Config Class Initialized
INFO - 2016-06-13 16:10:22 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:22 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:22 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:22 --> URI Class Initialized
INFO - 2016-06-13 16:10:22 --> Router Class Initialized
INFO - 2016-06-13 16:10:22 --> Output Class Initialized
INFO - 2016-06-13 16:10:22 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:22 --> Input Class Initialized
INFO - 2016-06-13 16:10:22 --> Language Class Initialized
INFO - 2016-06-13 16:10:22 --> Loader Class Initialized
INFO - 2016-06-13 16:10:22 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:22 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:23 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:23 --> Email Class Initialized
INFO - 2016-06-13 16:10:23 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:23 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:23 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:23 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:23 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:23 --> Model Class Initialized
INFO - 2016-06-13 16:10:23 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:23 --> Controller Class Initialized
INFO - 2016-06-13 16:10:23 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:23 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:23 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:23 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:23 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:23 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:23 --> Model Class Initialized
INFO - 2016-06-13 16:10:23 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:10:23 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:10:23 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:23 --> Total execution time: 0.1450
INFO - 2016-06-13 16:10:23 --> Config Class Initialized
INFO - 2016-06-13 16:10:23 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:23 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:23 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:24 --> URI Class Initialized
INFO - 2016-06-13 16:10:24 --> Router Class Initialized
INFO - 2016-06-13 16:10:24 --> Output Class Initialized
INFO - 2016-06-13 16:10:24 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:24 --> Input Class Initialized
INFO - 2016-06-13 16:10:24 --> Language Class Initialized
INFO - 2016-06-13 16:10:24 --> Loader Class Initialized
INFO - 2016-06-13 16:10:24 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:24 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:24 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:24 --> Email Class Initialized
INFO - 2016-06-13 16:10:24 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:24 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:24 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:24 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:24 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:24 --> Model Class Initialized
INFO - 2016-06-13 16:10:24 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:24 --> Controller Class Initialized
INFO - 2016-06-13 16:10:24 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:24 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:24 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:24 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:24 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:24 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:24 --> Model Class Initialized
INFO - 2016-06-13 16:10:24 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:24 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:24 --> Total execution time: 0.0539
INFO - 2016-06-13 16:10:26 --> Config Class Initialized
INFO - 2016-06-13 16:10:26 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:26 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:26 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:26 --> URI Class Initialized
INFO - 2016-06-13 16:10:26 --> Router Class Initialized
INFO - 2016-06-13 16:10:26 --> Output Class Initialized
INFO - 2016-06-13 16:10:26 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:26 --> Input Class Initialized
INFO - 2016-06-13 16:10:26 --> Language Class Initialized
INFO - 2016-06-13 16:10:26 --> Loader Class Initialized
INFO - 2016-06-13 16:10:26 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:26 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:26 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:26 --> Email Class Initialized
INFO - 2016-06-13 16:10:26 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:26 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:26 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:26 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:26 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:26 --> Model Class Initialized
INFO - 2016-06-13 16:10:26 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:26 --> Controller Class Initialized
INFO - 2016-06-13 16:10:26 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:26 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:26 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:26 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:26 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:26 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:26 --> Model Class Initialized
INFO - 2016-06-13 16:10:26 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:10:26 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:10:26 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:26 --> Total execution time: 0.0492
INFO - 2016-06-13 16:10:27 --> Config Class Initialized
INFO - 2016-06-13 16:10:27 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:27 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:27 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:27 --> URI Class Initialized
INFO - 2016-06-13 16:10:27 --> Router Class Initialized
INFO - 2016-06-13 16:10:27 --> Output Class Initialized
INFO - 2016-06-13 16:10:27 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:27 --> Input Class Initialized
INFO - 2016-06-13 16:10:27 --> Language Class Initialized
INFO - 2016-06-13 16:10:27 --> Loader Class Initialized
INFO - 2016-06-13 16:10:27 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:27 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:27 --> Email Class Initialized
INFO - 2016-06-13 16:10:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:27 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:27 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:27 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:27 --> Model Class Initialized
INFO - 2016-06-13 16:10:27 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:27 --> Controller Class Initialized
INFO - 2016-06-13 16:10:27 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:27 --> Model Class Initialized
INFO - 2016-06-13 16:10:27 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:27 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:27 --> Total execution time: 0.0705
INFO - 2016-06-13 16:10:29 --> Config Class Initialized
INFO - 2016-06-13 16:10:29 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:29 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:29 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:29 --> URI Class Initialized
INFO - 2016-06-13 16:10:29 --> Router Class Initialized
INFO - 2016-06-13 16:10:29 --> Output Class Initialized
INFO - 2016-06-13 16:10:29 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:29 --> Input Class Initialized
INFO - 2016-06-13 16:10:29 --> Language Class Initialized
INFO - 2016-06-13 16:10:29 --> Loader Class Initialized
INFO - 2016-06-13 16:10:29 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:29 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:29 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:29 --> Email Class Initialized
INFO - 2016-06-13 16:10:29 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:29 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:29 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:29 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:29 --> Model Class Initialized
INFO - 2016-06-13 16:10:29 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:29 --> Controller Class Initialized
INFO - 2016-06-13 16:10:29 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:29 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:29 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:29 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:29 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:29 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:29 --> Model Class Initialized
INFO - 2016-06-13 16:10:29 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:10:29 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:10:29 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:29 --> Total execution time: 0.0991
INFO - 2016-06-13 16:10:30 --> Config Class Initialized
INFO - 2016-06-13 16:10:30 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:30 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:30 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:30 --> URI Class Initialized
INFO - 2016-06-13 16:10:30 --> Router Class Initialized
INFO - 2016-06-13 16:10:30 --> Output Class Initialized
INFO - 2016-06-13 16:10:30 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:30 --> Input Class Initialized
INFO - 2016-06-13 16:10:30 --> Language Class Initialized
INFO - 2016-06-13 16:10:30 --> Loader Class Initialized
INFO - 2016-06-13 16:10:30 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:30 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:30 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:30 --> Email Class Initialized
INFO - 2016-06-13 16:10:30 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:30 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:30 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:30 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:30 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:30 --> Model Class Initialized
INFO - 2016-06-13 16:10:30 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:30 --> Controller Class Initialized
INFO - 2016-06-13 16:10:30 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:30 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:30 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:30 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:30 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:30 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:30 --> Model Class Initialized
INFO - 2016-06-13 16:10:30 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:30 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:30 --> Total execution time: 0.0551
INFO - 2016-06-13 16:10:33 --> Config Class Initialized
INFO - 2016-06-13 16:10:33 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:33 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:33 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:33 --> URI Class Initialized
INFO - 2016-06-13 16:10:33 --> Router Class Initialized
INFO - 2016-06-13 16:10:33 --> Output Class Initialized
INFO - 2016-06-13 16:10:33 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:33 --> Input Class Initialized
INFO - 2016-06-13 16:10:33 --> Language Class Initialized
INFO - 2016-06-13 16:10:33 --> Loader Class Initialized
INFO - 2016-06-13 16:10:33 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:33 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:33 --> Email Class Initialized
INFO - 2016-06-13 16:10:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:33 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:33 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:33 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:33 --> Model Class Initialized
INFO - 2016-06-13 16:10:33 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:33 --> Controller Class Initialized
INFO - 2016-06-13 16:10:33 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:33 --> Model Class Initialized
INFO - 2016-06-13 16:10:33 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:10:33 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:10:33 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:33 --> Total execution time: 0.0883
INFO - 2016-06-13 16:10:33 --> Config Class Initialized
INFO - 2016-06-13 16:10:33 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:10:33 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:10:33 --> Utf8 Class Initialized
INFO - 2016-06-13 16:10:33 --> URI Class Initialized
INFO - 2016-06-13 16:10:33 --> Router Class Initialized
INFO - 2016-06-13 16:10:33 --> Output Class Initialized
INFO - 2016-06-13 16:10:33 --> Security Class Initialized
DEBUG - 2016-06-13 16:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:10:33 --> Input Class Initialized
INFO - 2016-06-13 16:10:33 --> Language Class Initialized
INFO - 2016-06-13 16:10:33 --> Loader Class Initialized
INFO - 2016-06-13 16:10:33 --> Helper loaded: form_helper
INFO - 2016-06-13 16:10:33 --> Database Driver Class Initialized
INFO - 2016-06-13 16:10:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:10:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:10:33 --> Email Class Initialized
INFO - 2016-06-13 16:10:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:10:33 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:10:33 --> Helper loaded: language_helper
INFO - 2016-06-13 16:10:33 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:10:33 --> Model Class Initialized
INFO - 2016-06-13 16:10:33 --> Helper loaded: date_helper
INFO - 2016-06-13 16:10:33 --> Controller Class Initialized
INFO - 2016-06-13 16:10:33 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:10:34 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:10:34 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:10:34 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:10:34 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:10:34 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:10:34 --> Model Class Initialized
INFO - 2016-06-13 16:10:34 --> Form Validation Class Initialized
INFO - 2016-06-13 16:10:34 --> Final output sent to browser
DEBUG - 2016-06-13 16:10:34 --> Total execution time: 0.0568
INFO - 2016-06-13 16:12:27 --> Config Class Initialized
INFO - 2016-06-13 16:12:27 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:12:27 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:12:27 --> Utf8 Class Initialized
INFO - 2016-06-13 16:12:27 --> URI Class Initialized
INFO - 2016-06-13 16:12:27 --> Router Class Initialized
INFO - 2016-06-13 16:12:27 --> Output Class Initialized
INFO - 2016-06-13 16:12:27 --> Security Class Initialized
DEBUG - 2016-06-13 16:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:12:27 --> Input Class Initialized
INFO - 2016-06-13 16:12:27 --> Language Class Initialized
INFO - 2016-06-13 16:12:27 --> Loader Class Initialized
INFO - 2016-06-13 16:12:27 --> Helper loaded: form_helper
INFO - 2016-06-13 16:12:27 --> Database Driver Class Initialized
INFO - 2016-06-13 16:12:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:12:27 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:12:27 --> Email Class Initialized
INFO - 2016-06-13 16:12:27 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:12:27 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:12:27 --> Helper loaded: language_helper
INFO - 2016-06-13 16:12:27 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:12:27 --> Model Class Initialized
INFO - 2016-06-13 16:12:27 --> Helper loaded: date_helper
INFO - 2016-06-13 16:12:27 --> Controller Class Initialized
INFO - 2016-06-13 16:12:27 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:12:27 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:12:27 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:12:27 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:12:27 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:12:27 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:12:27 --> Model Class Initialized
INFO - 2016-06-13 16:12:27 --> Form Validation Class Initialized
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:12:27 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:12:27 --> Final output sent to browser
DEBUG - 2016-06-13 16:12:27 --> Total execution time: 0.0883
INFO - 2016-06-13 16:12:28 --> Config Class Initialized
INFO - 2016-06-13 16:12:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:12:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:12:28 --> Utf8 Class Initialized
INFO - 2016-06-13 16:12:28 --> URI Class Initialized
INFO - 2016-06-13 16:12:28 --> Router Class Initialized
INFO - 2016-06-13 16:12:28 --> Output Class Initialized
INFO - 2016-06-13 16:12:28 --> Security Class Initialized
DEBUG - 2016-06-13 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:12:28 --> Input Class Initialized
INFO - 2016-06-13 16:12:28 --> Language Class Initialized
ERROR - 2016-06-13 16:12:28 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 16:12:28 --> Config Class Initialized
INFO - 2016-06-13 16:12:28 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:12:28 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:12:28 --> Utf8 Class Initialized
INFO - 2016-06-13 16:12:28 --> URI Class Initialized
INFO - 2016-06-13 16:12:28 --> Router Class Initialized
INFO - 2016-06-13 16:12:28 --> Output Class Initialized
INFO - 2016-06-13 16:12:28 --> Security Class Initialized
DEBUG - 2016-06-13 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:12:28 --> Input Class Initialized
INFO - 2016-06-13 16:12:28 --> Language Class Initialized
INFO - 2016-06-13 16:12:28 --> Loader Class Initialized
INFO - 2016-06-13 16:12:28 --> Helper loaded: form_helper
INFO - 2016-06-13 16:12:28 --> Database Driver Class Initialized
INFO - 2016-06-13 16:12:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:12:28 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:12:28 --> Email Class Initialized
INFO - 2016-06-13 16:12:28 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:12:28 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:12:28 --> Helper loaded: language_helper
INFO - 2016-06-13 16:12:28 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:12:28 --> Model Class Initialized
INFO - 2016-06-13 16:12:28 --> Helper loaded: date_helper
INFO - 2016-06-13 16:12:28 --> Controller Class Initialized
INFO - 2016-06-13 16:12:28 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:12:28 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:12:28 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:12:28 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:12:28 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:12:28 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:12:28 --> Model Class Initialized
INFO - 2016-06-13 16:12:28 --> Form Validation Class Initialized
INFO - 2016-06-13 16:12:28 --> Final output sent to browser
DEBUG - 2016-06-13 16:12:28 --> Total execution time: 0.0574
INFO - 2016-06-13 16:13:11 --> Config Class Initialized
INFO - 2016-06-13 16:13:11 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:13:11 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:13:11 --> Utf8 Class Initialized
INFO - 2016-06-13 16:13:11 --> URI Class Initialized
INFO - 2016-06-13 16:13:11 --> Router Class Initialized
INFO - 2016-06-13 16:13:11 --> Output Class Initialized
INFO - 2016-06-13 16:13:11 --> Security Class Initialized
DEBUG - 2016-06-13 16:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:13:11 --> Input Class Initialized
INFO - 2016-06-13 16:13:11 --> Language Class Initialized
INFO - 2016-06-13 16:13:11 --> Loader Class Initialized
INFO - 2016-06-13 16:13:11 --> Helper loaded: form_helper
INFO - 2016-06-13 16:13:11 --> Database Driver Class Initialized
INFO - 2016-06-13 16:13:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:13:11 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:13:11 --> Email Class Initialized
INFO - 2016-06-13 16:13:11 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:13:11 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:13:11 --> Helper loaded: language_helper
INFO - 2016-06-13 16:13:11 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:13:11 --> Model Class Initialized
INFO - 2016-06-13 16:13:11 --> Helper loaded: date_helper
INFO - 2016-06-13 16:13:11 --> Controller Class Initialized
INFO - 2016-06-13 16:13:11 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:13:11 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:13:11 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:13:11 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:13:11 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:13:11 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:13:11 --> Model Class Initialized
INFO - 2016-06-13 16:13:11 --> Form Validation Class Initialized
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:13:11 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:13:11 --> Final output sent to browser
DEBUG - 2016-06-13 16:13:11 --> Total execution time: 0.1002
INFO - 2016-06-13 16:13:12 --> Config Class Initialized
INFO - 2016-06-13 16:13:12 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:13:12 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:13:12 --> Utf8 Class Initialized
INFO - 2016-06-13 16:13:12 --> URI Class Initialized
INFO - 2016-06-13 16:13:12 --> Router Class Initialized
INFO - 2016-06-13 16:13:12 --> Output Class Initialized
INFO - 2016-06-13 16:13:12 --> Security Class Initialized
DEBUG - 2016-06-13 16:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:13:12 --> Input Class Initialized
INFO - 2016-06-13 16:13:12 --> Language Class Initialized
ERROR - 2016-06-13 16:13:12 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 16:13:12 --> Config Class Initialized
INFO - 2016-06-13 16:13:12 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:13:12 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:13:12 --> Utf8 Class Initialized
INFO - 2016-06-13 16:13:12 --> URI Class Initialized
INFO - 2016-06-13 16:13:12 --> Router Class Initialized
INFO - 2016-06-13 16:13:12 --> Output Class Initialized
INFO - 2016-06-13 16:13:12 --> Security Class Initialized
DEBUG - 2016-06-13 16:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:13:12 --> Input Class Initialized
INFO - 2016-06-13 16:13:12 --> Language Class Initialized
INFO - 2016-06-13 16:13:12 --> Loader Class Initialized
INFO - 2016-06-13 16:13:12 --> Helper loaded: form_helper
INFO - 2016-06-13 16:13:12 --> Database Driver Class Initialized
INFO - 2016-06-13 16:13:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:13:12 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:13:12 --> Email Class Initialized
INFO - 2016-06-13 16:13:12 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:13:12 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:13:12 --> Helper loaded: language_helper
INFO - 2016-06-13 16:13:12 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:13:12 --> Model Class Initialized
INFO - 2016-06-13 16:13:12 --> Helper loaded: date_helper
INFO - 2016-06-13 16:13:12 --> Controller Class Initialized
INFO - 2016-06-13 16:13:12 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:13:12 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:13:12 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:13:12 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:13:12 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:13:12 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:13:12 --> Model Class Initialized
INFO - 2016-06-13 16:13:12 --> Form Validation Class Initialized
INFO - 2016-06-13 16:13:12 --> Final output sent to browser
DEBUG - 2016-06-13 16:13:12 --> Total execution time: 0.0560
INFO - 2016-06-13 16:22:20 --> Config Class Initialized
INFO - 2016-06-13 16:22:20 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:22:20 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:22:20 --> Utf8 Class Initialized
INFO - 2016-06-13 16:22:20 --> URI Class Initialized
INFO - 2016-06-13 16:22:20 --> Router Class Initialized
INFO - 2016-06-13 16:22:20 --> Output Class Initialized
INFO - 2016-06-13 16:22:20 --> Security Class Initialized
DEBUG - 2016-06-13 16:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:22:20 --> Input Class Initialized
INFO - 2016-06-13 16:22:20 --> Language Class Initialized
INFO - 2016-06-13 16:22:20 --> Loader Class Initialized
INFO - 2016-06-13 16:22:20 --> Helper loaded: form_helper
INFO - 2016-06-13 16:22:20 --> Database Driver Class Initialized
INFO - 2016-06-13 16:22:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:22:20 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:22:20 --> Email Class Initialized
INFO - 2016-06-13 16:22:20 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:22:20 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:22:20 --> Helper loaded: language_helper
INFO - 2016-06-13 16:22:20 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:22:20 --> Model Class Initialized
INFO - 2016-06-13 16:22:20 --> Helper loaded: date_helper
INFO - 2016-06-13 16:22:20 --> Controller Class Initialized
INFO - 2016-06-13 16:22:20 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:22:20 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:22:20 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:22:20 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:22:20 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:22:20 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:22:20 --> Model Class Initialized
INFO - 2016-06-13 16:22:20 --> Form Validation Class Initialized
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:22:20 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:22:20 --> Final output sent to browser
DEBUG - 2016-06-13 16:22:20 --> Total execution time: 0.1338
INFO - 2016-06-13 16:22:21 --> Config Class Initialized
INFO - 2016-06-13 16:22:21 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:22:21 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:22:21 --> Utf8 Class Initialized
INFO - 2016-06-13 16:22:21 --> URI Class Initialized
INFO - 2016-06-13 16:22:21 --> Router Class Initialized
INFO - 2016-06-13 16:22:21 --> Output Class Initialized
INFO - 2016-06-13 16:22:21 --> Security Class Initialized
DEBUG - 2016-06-13 16:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:22:21 --> Input Class Initialized
INFO - 2016-06-13 16:22:21 --> Language Class Initialized
INFO - 2016-06-13 16:22:21 --> Loader Class Initialized
INFO - 2016-06-13 16:22:21 --> Helper loaded: form_helper
INFO - 2016-06-13 16:22:21 --> Database Driver Class Initialized
INFO - 2016-06-13 16:22:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:22:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:22:21 --> Email Class Initialized
INFO - 2016-06-13 16:22:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:22:21 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:22:21 --> Helper loaded: language_helper
INFO - 2016-06-13 16:22:21 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:22:21 --> Model Class Initialized
INFO - 2016-06-13 16:22:21 --> Helper loaded: date_helper
INFO - 2016-06-13 16:22:21 --> Controller Class Initialized
INFO - 2016-06-13 16:22:21 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:22:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:22:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:22:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:22:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:22:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:22:21 --> Model Class Initialized
INFO - 2016-06-13 16:22:21 --> Form Validation Class Initialized
INFO - 2016-06-13 16:22:21 --> Final output sent to browser
DEBUG - 2016-06-13 16:22:21 --> Total execution time: 0.0568
INFO - 2016-06-13 16:22:53 --> Config Class Initialized
INFO - 2016-06-13 16:22:53 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:22:53 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:22:53 --> Utf8 Class Initialized
INFO - 2016-06-13 16:22:53 --> URI Class Initialized
INFO - 2016-06-13 16:22:53 --> Router Class Initialized
INFO - 2016-06-13 16:22:53 --> Output Class Initialized
INFO - 2016-06-13 16:22:53 --> Security Class Initialized
DEBUG - 2016-06-13 16:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:22:53 --> Input Class Initialized
INFO - 2016-06-13 16:22:53 --> Language Class Initialized
INFO - 2016-06-13 16:22:53 --> Loader Class Initialized
INFO - 2016-06-13 16:22:53 --> Helper loaded: form_helper
INFO - 2016-06-13 16:22:53 --> Database Driver Class Initialized
INFO - 2016-06-13 16:22:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:22:53 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:22:53 --> Email Class Initialized
INFO - 2016-06-13 16:22:53 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:22:53 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:22:53 --> Helper loaded: language_helper
INFO - 2016-06-13 16:22:53 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:22:53 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:22:53 --> Model Class Initialized
INFO - 2016-06-13 16:22:53 --> Helper loaded: date_helper
INFO - 2016-06-13 16:22:53 --> Controller Class Initialized
INFO - 2016-06-13 16:22:53 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:22:53 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:22:53 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:22:53 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:22:53 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:22:53 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:22:53 --> Model Class Initialized
INFO - 2016-06-13 16:22:53 --> Form Validation Class Initialized
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:22:53 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:22:53 --> Final output sent to browser
DEBUG - 2016-06-13 16:22:53 --> Total execution time: 0.1008
INFO - 2016-06-13 16:22:54 --> Config Class Initialized
INFO - 2016-06-13 16:22:54 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:22:54 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:22:54 --> Utf8 Class Initialized
INFO - 2016-06-13 16:22:54 --> URI Class Initialized
INFO - 2016-06-13 16:22:54 --> Router Class Initialized
INFO - 2016-06-13 16:22:54 --> Output Class Initialized
INFO - 2016-06-13 16:22:54 --> Security Class Initialized
DEBUG - 2016-06-13 16:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:22:54 --> Input Class Initialized
INFO - 2016-06-13 16:22:54 --> Language Class Initialized
INFO - 2016-06-13 16:22:54 --> Loader Class Initialized
INFO - 2016-06-13 16:22:54 --> Helper loaded: form_helper
INFO - 2016-06-13 16:22:54 --> Database Driver Class Initialized
INFO - 2016-06-13 16:22:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:22:54 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:22:54 --> Email Class Initialized
INFO - 2016-06-13 16:22:54 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:22:54 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:22:54 --> Helper loaded: language_helper
INFO - 2016-06-13 16:22:54 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:22:54 --> Model Class Initialized
INFO - 2016-06-13 16:22:54 --> Helper loaded: date_helper
INFO - 2016-06-13 16:22:54 --> Controller Class Initialized
INFO - 2016-06-13 16:22:54 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:22:54 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:22:54 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:22:54 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:22:54 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:22:54 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:22:54 --> Model Class Initialized
INFO - 2016-06-13 16:22:54 --> Form Validation Class Initialized
INFO - 2016-06-13 16:22:54 --> Final output sent to browser
DEBUG - 2016-06-13 16:22:54 --> Total execution time: 0.0531
INFO - 2016-06-13 16:23:02 --> Config Class Initialized
INFO - 2016-06-13 16:23:02 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:23:02 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:23:02 --> Utf8 Class Initialized
INFO - 2016-06-13 16:23:02 --> URI Class Initialized
INFO - 2016-06-13 16:23:02 --> Router Class Initialized
INFO - 2016-06-13 16:23:02 --> Output Class Initialized
INFO - 2016-06-13 16:23:02 --> Security Class Initialized
DEBUG - 2016-06-13 16:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:23:02 --> Input Class Initialized
INFO - 2016-06-13 16:23:02 --> Language Class Initialized
INFO - 2016-06-13 16:23:02 --> Loader Class Initialized
INFO - 2016-06-13 16:23:02 --> Helper loaded: form_helper
INFO - 2016-06-13 16:23:02 --> Database Driver Class Initialized
INFO - 2016-06-13 16:23:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:23:02 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:23:02 --> Email Class Initialized
INFO - 2016-06-13 16:23:02 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:23:02 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:23:02 --> Helper loaded: language_helper
INFO - 2016-06-13 16:23:02 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:23:02 --> Model Class Initialized
INFO - 2016-06-13 16:23:02 --> Helper loaded: date_helper
INFO - 2016-06-13 16:23:02 --> Controller Class Initialized
INFO - 2016-06-13 16:23:02 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:23:02 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:23:02 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:23:02 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:23:02 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:23:02 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:23:02 --> Model Class Initialized
INFO - 2016-06-13 16:23:02 --> Form Validation Class Initialized
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:23:02 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:23:02 --> Final output sent to browser
DEBUG - 2016-06-13 16:23:02 --> Total execution time: 0.0949
INFO - 2016-06-13 16:23:03 --> Config Class Initialized
INFO - 2016-06-13 16:23:03 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:23:03 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:23:03 --> Utf8 Class Initialized
INFO - 2016-06-13 16:23:03 --> URI Class Initialized
INFO - 2016-06-13 16:23:03 --> Router Class Initialized
INFO - 2016-06-13 16:23:03 --> Output Class Initialized
INFO - 2016-06-13 16:23:03 --> Security Class Initialized
DEBUG - 2016-06-13 16:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:23:03 --> Input Class Initialized
INFO - 2016-06-13 16:23:03 --> Language Class Initialized
INFO - 2016-06-13 16:23:03 --> Loader Class Initialized
INFO - 2016-06-13 16:23:03 --> Helper loaded: form_helper
INFO - 2016-06-13 16:23:03 --> Database Driver Class Initialized
INFO - 2016-06-13 16:23:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:23:03 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:23:03 --> Email Class Initialized
INFO - 2016-06-13 16:23:03 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:23:03 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:23:03 --> Helper loaded: language_helper
INFO - 2016-06-13 16:23:03 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:23:03 --> Model Class Initialized
INFO - 2016-06-13 16:23:03 --> Helper loaded: date_helper
INFO - 2016-06-13 16:23:03 --> Controller Class Initialized
INFO - 2016-06-13 16:23:03 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:23:03 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:23:03 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:23:03 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:23:03 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:23:03 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:23:03 --> Model Class Initialized
INFO - 2016-06-13 16:23:03 --> Form Validation Class Initialized
INFO - 2016-06-13 16:23:03 --> Final output sent to browser
DEBUG - 2016-06-13 16:23:03 --> Total execution time: 0.0998
INFO - 2016-06-13 16:56:19 --> Config Class Initialized
INFO - 2016-06-13 16:56:19 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:56:19 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:56:19 --> Utf8 Class Initialized
INFO - 2016-06-13 16:56:19 --> URI Class Initialized
INFO - 2016-06-13 16:56:19 --> Router Class Initialized
INFO - 2016-06-13 16:56:19 --> Output Class Initialized
INFO - 2016-06-13 16:56:19 --> Security Class Initialized
DEBUG - 2016-06-13 16:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:56:19 --> Input Class Initialized
INFO - 2016-06-13 16:56:19 --> Language Class Initialized
INFO - 2016-06-13 16:56:19 --> Loader Class Initialized
INFO - 2016-06-13 16:56:19 --> Helper loaded: form_helper
INFO - 2016-06-13 16:56:19 --> Database Driver Class Initialized
INFO - 2016-06-13 16:56:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:56:19 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:56:19 --> Email Class Initialized
INFO - 2016-06-13 16:56:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:56:19 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:56:19 --> Helper loaded: language_helper
INFO - 2016-06-13 16:56:19 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:56:19 --> Model Class Initialized
INFO - 2016-06-13 16:56:19 --> Helper loaded: date_helper
INFO - 2016-06-13 16:56:19 --> Controller Class Initialized
INFO - 2016-06-13 16:56:19 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:56:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:56:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:56:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:56:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:56:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:56:19 --> Model Class Initialized
INFO - 2016-06-13 16:56:19 --> Form Validation Class Initialized
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/header.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/date_diabet.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/editare_privilegii_access.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/informatii_cont.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/schimba_parola.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/menu/logout.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/left_bar.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_adaugare.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_grafic.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/partial_glicemie_tabel.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/home.php
INFO - 2016-06-13 16:56:19 --> File loaded: /home/demis/www/platformadiabet/application/views/user_area/res/footer.php
INFO - 2016-06-13 16:56:19 --> Final output sent to browser
DEBUG - 2016-06-13 16:56:19 --> Total execution time: 0.1028
INFO - 2016-06-13 16:56:21 --> Config Class Initialized
INFO - 2016-06-13 16:56:21 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:56:21 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:56:21 --> Utf8 Class Initialized
INFO - 2016-06-13 16:56:21 --> URI Class Initialized
INFO - 2016-06-13 16:56:21 --> Router Class Initialized
INFO - 2016-06-13 16:56:21 --> Output Class Initialized
INFO - 2016-06-13 16:56:21 --> Security Class Initialized
DEBUG - 2016-06-13 16:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:56:21 --> Input Class Initialized
INFO - 2016-06-13 16:56:21 --> Language Class Initialized
ERROR - 2016-06-13 16:56:21 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-13 16:56:21 --> Config Class Initialized
INFO - 2016-06-13 16:56:21 --> Hooks Class Initialized
DEBUG - 2016-06-13 16:56:21 --> UTF-8 Support Enabled
INFO - 2016-06-13 16:56:21 --> Utf8 Class Initialized
INFO - 2016-06-13 16:56:21 --> URI Class Initialized
INFO - 2016-06-13 16:56:21 --> Router Class Initialized
INFO - 2016-06-13 16:56:21 --> Output Class Initialized
INFO - 2016-06-13 16:56:21 --> Security Class Initialized
DEBUG - 2016-06-13 16:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 16:56:21 --> Input Class Initialized
INFO - 2016-06-13 16:56:21 --> Language Class Initialized
INFO - 2016-06-13 16:56:21 --> Loader Class Initialized
INFO - 2016-06-13 16:56:21 --> Helper loaded: form_helper
INFO - 2016-06-13 16:56:21 --> Database Driver Class Initialized
INFO - 2016-06-13 16:56:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 16:56:21 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 16:56:21 --> Email Class Initialized
INFO - 2016-06-13 16:56:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 16:56:21 --> Helper loaded: cookie_helper
INFO - 2016-06-13 16:56:21 --> Helper loaded: language_helper
INFO - 2016-06-13 16:56:21 --> Helper loaded: url_helper
DEBUG - 2016-06-13 16:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 16:56:21 --> Model Class Initialized
INFO - 2016-06-13 16:56:21 --> Helper loaded: date_helper
INFO - 2016-06-13 16:56:21 --> Controller Class Initialized
INFO - 2016-06-13 16:56:21 --> Helper loaded: languages_helper
INFO - 2016-06-13 16:56:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 16:56:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 16:56:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 16:56:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 16:56:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 16:56:21 --> Model Class Initialized
INFO - 2016-06-13 16:56:21 --> Form Validation Class Initialized
INFO - 2016-06-13 16:56:21 --> Final output sent to browser
DEBUG - 2016-06-13 16:56:21 --> Total execution time: 0.0551
INFO - 2016-06-13 19:07:31 --> Config Class Initialized
INFO - 2016-06-13 19:07:32 --> Hooks Class Initialized
DEBUG - 2016-06-13 19:07:32 --> UTF-8 Support Enabled
INFO - 2016-06-13 19:07:32 --> Utf8 Class Initialized
INFO - 2016-06-13 19:07:32 --> URI Class Initialized
INFO - 2016-06-13 19:07:32 --> Router Class Initialized
INFO - 2016-06-13 19:07:32 --> Output Class Initialized
INFO - 2016-06-13 19:07:32 --> Security Class Initialized
DEBUG - 2016-06-13 19:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-13 19:07:32 --> Input Class Initialized
INFO - 2016-06-13 19:07:32 --> Language Class Initialized
INFO - 2016-06-13 19:07:32 --> Loader Class Initialized
INFO - 2016-06-13 19:07:32 --> Helper loaded: form_helper
INFO - 2016-06-13 19:07:32 --> Database Driver Class Initialized
INFO - 2016-06-13 19:07:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-13 19:07:33 --> Config file loaded: /home/demis/www/platformadiabet/application/config/ion_auth.php
INFO - 2016-06-13 19:07:33 --> Email Class Initialized
INFO - 2016-06-13 19:07:33 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-13 19:07:33 --> Helper loaded: cookie_helper
INFO - 2016-06-13 19:07:33 --> Helper loaded: language_helper
INFO - 2016-06-13 19:07:33 --> Helper loaded: url_helper
DEBUG - 2016-06-13 19:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-13 19:07:33 --> Model Class Initialized
INFO - 2016-06-13 19:07:33 --> Helper loaded: date_helper
INFO - 2016-06-13 19:07:33 --> Controller Class Initialized
INFO - 2016-06-13 19:07:33 --> Helper loaded: languages_helper
INFO - 2016-06-13 19:07:33 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-13 19:07:33 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-13 19:07:33 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-13 19:07:33 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-13 19:07:33 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-13 19:07:33 --> Model Class Initialized
INFO - 2016-06-13 19:07:33 --> Form Validation Class Initialized
