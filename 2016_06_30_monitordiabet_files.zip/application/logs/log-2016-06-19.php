<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-19 14:39:18 --> Config Class Initialized
INFO - 2016-06-19 14:39:18 --> Hooks Class Initialized
DEBUG - 2016-06-19 14:39:18 --> UTF-8 Support Enabled
INFO - 2016-06-19 14:39:18 --> Utf8 Class Initialized
INFO - 2016-06-19 14:39:18 --> URI Class Initialized
DEBUG - 2016-06-19 14:39:18 --> No URI present. Default controller set.
INFO - 2016-06-19 14:39:18 --> Router Class Initialized
INFO - 2016-06-19 14:39:18 --> Output Class Initialized
INFO - 2016-06-19 14:39:18 --> Security Class Initialized
DEBUG - 2016-06-19 14:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-19 14:39:18 --> Input Class Initialized
INFO - 2016-06-19 14:39:18 --> Language Class Initialized
INFO - 2016-06-19 14:39:18 --> Loader Class Initialized
INFO - 2016-06-19 14:39:18 --> Helper loaded: form_helper
INFO - 2016-06-19 14:39:18 --> Database Driver Class Initialized
INFO - 2016-06-19 14:39:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-19 14:39:19 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-19 14:39:19 --> Email Class Initialized
INFO - 2016-06-19 14:39:19 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-19 14:39:19 --> Helper loaded: cookie_helper
INFO - 2016-06-19 14:39:19 --> Helper loaded: language_helper
INFO - 2016-06-19 14:39:19 --> Helper loaded: url_helper
DEBUG - 2016-06-19 14:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-19 14:39:19 --> Model Class Initialized
INFO - 2016-06-19 14:39:19 --> Helper loaded: date_helper
INFO - 2016-06-19 14:39:19 --> Controller Class Initialized
INFO - 2016-06-19 14:39:19 --> Helper loaded: languages_helper
INFO - 2016-06-19 14:39:19 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-19 14:39:19 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-19 14:39:19 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-19 14:39:19 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-19 14:39:19 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-19 17:39:19 --> Model Class Initialized
INFO - 2016-06-19 17:39:19 --> Form Validation Class Initialized
INFO - 2016-06-19 17:39:20 --> File loaded: /home/diabet/public_html/application/views/public/res/header.php
INFO - 2016-06-19 17:39:20 --> File loaded: /home/diabet/public_html/application/views/auth/login.php
INFO - 2016-06-19 17:39:20 --> File loaded: /home/diabet/public_html/application/views/public/home.php
INFO - 2016-06-19 17:39:20 --> File loaded: /home/diabet/public_html/application/views/public/res/footer.php
INFO - 2016-06-19 17:39:20 --> Final output sent to browser
DEBUG - 2016-06-19 17:39:20 --> Total execution time: 1.9580
INFO - 2016-06-19 14:39:21 --> Config Class Initialized
INFO - 2016-06-19 14:39:21 --> Hooks Class Initialized
DEBUG - 2016-06-19 14:39:21 --> UTF-8 Support Enabled
INFO - 2016-06-19 14:39:21 --> Utf8 Class Initialized
INFO - 2016-06-19 14:39:21 --> URI Class Initialized
INFO - 2016-06-19 14:39:21 --> Router Class Initialized
INFO - 2016-06-19 14:39:21 --> Output Class Initialized
INFO - 2016-06-19 14:39:21 --> Security Class Initialized
DEBUG - 2016-06-19 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-19 14:39:21 --> Input Class Initialized
INFO - 2016-06-19 14:39:21 --> Language Class Initialized
INFO - 2016-06-19 14:39:21 --> Loader Class Initialized
INFO - 2016-06-19 14:39:21 --> Helper loaded: form_helper
INFO - 2016-06-19 14:39:21 --> Database Driver Class Initialized
INFO - 2016-06-19 14:39:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-19 14:39:21 --> Config file loaded: /home/diabet/public_html/application/config/ion_auth.php
INFO - 2016-06-19 14:39:21 --> Email Class Initialized
INFO - 2016-06-19 14:39:21 --> Language file loaded: language/romanian/ion_auth_lang.php
INFO - 2016-06-19 14:39:21 --> Helper loaded: cookie_helper
INFO - 2016-06-19 14:39:21 --> Helper loaded: language_helper
INFO - 2016-06-19 14:39:21 --> Helper loaded: url_helper
DEBUG - 2016-06-19 14:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2016-06-19 14:39:21 --> Model Class Initialized
INFO - 2016-06-19 14:39:21 --> Helper loaded: date_helper
INFO - 2016-06-19 14:39:21 --> Controller Class Initialized
INFO - 2016-06-19 14:39:21 --> Helper loaded: languages_helper
INFO - 2016-06-19 14:39:21 --> Language file loaded: language/romanian/general_lang.php
INFO - 2016-06-19 14:39:21 --> Language file loaded: language/romanian/auth_lang.php
INFO - 2016-06-19 14:39:21 --> Language file loaded: language/romanian/db_lang.php
INFO - 2016-06-19 14:39:21 --> Language file loaded: language/romanian/errors_generals_lang.php
INFO - 2016-06-19 14:39:21 --> Language file loaded: language/romanian/form_validation_lang.php
INFO - 2016-06-19 17:39:21 --> Model Class Initialized
INFO - 2016-06-19 17:39:21 --> Final output sent to browser
DEBUG - 2016-06-19 17:39:21 --> Total execution time: 0.1304
INFO - 2016-06-19 14:39:21 --> Config Class Initialized
INFO - 2016-06-19 14:39:21 --> Hooks Class Initialized
DEBUG - 2016-06-19 14:39:21 --> UTF-8 Support Enabled
INFO - 2016-06-19 14:39:21 --> Utf8 Class Initialized
INFO - 2016-06-19 14:39:21 --> URI Class Initialized
INFO - 2016-06-19 14:39:21 --> Router Class Initialized
INFO - 2016-06-19 14:39:21 --> Output Class Initialized
INFO - 2016-06-19 14:39:21 --> Security Class Initialized
DEBUG - 2016-06-19 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-19 14:39:21 --> Input Class Initialized
INFO - 2016-06-19 14:39:21 --> Language Class Initialized
ERROR - 2016-06-19 14:39:21 --> 404 Page Not Found: Faviconico/index
